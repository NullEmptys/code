package com.gamedo.loginServer.message;

public class RegistAccountResponseMessage extends CommonMessage{

}
