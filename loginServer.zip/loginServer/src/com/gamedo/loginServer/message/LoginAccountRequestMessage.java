package com.gamedo.loginServer.message;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 登录账号
 * 客户端请求服务器消息内容
 * @author libm
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LoginAccountRequestMessage {

	private String userName;

	private String passward;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassward() {
		return passward;
	}

	public void setPassward(String passward) {
		this.passward = passward;
	}
	
	
}
