package com.gamedo.loginServer.message;

public class AnnouncementData {

	private int id;
	/**公告标题*/
	private String title;
	/**公告内容*/
	private String content;
	/**公告类型 1、文字  2、图片*/
	private int type;
	/**公告背景图片id*/
	private String backGroundId;
	/**公告显示顺序*/
	private int sequence;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getBackGroundId() {
		return backGroundId;
	}
	public void setBackGroundId(String backGroundId) {
		this.backGroundId = backGroundId;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
}
