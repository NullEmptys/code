package com.gamedo.loginServer.message;

public class GetAnnouncementResponseMessage extends CommonMessage{

	private AnnouncementData announcementData;

	public AnnouncementData getAnnouncementData() {
		return announcementData;
	}

	public void setAnnouncementData(AnnouncementData announcementData) {
		this.announcementData = announcementData;
	}
	
}
