package com.gamedo.loginServer.message;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 创建账号
 * 客户端请求服务器消息内容
 * @author libm
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RegistAccountRequestMessage {

	/**账号名称*/
	private String userName;
	/**账号密码*/
	private String passward;
	/**渠道号*/
	private String channelId;
	/**子渠道号*/
	private String subChannelId;
	/**渠道账号对应唯一id*/
	private String uid;
	/**唯一设备号*/
	private String deviceNumber;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassward() {
		return passward;
	}

	public void setPassward(String passward) {
		this.passward = passward;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getSubChannelId() {
		return subChannelId;
	}

	public void setSubChannelId(String subChannelId) {
		this.subChannelId = subChannelId;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getDeviceNumber() {
		return deviceNumber;
	}

	public void setDeviceNumber(String deviceNumber) {
		this.deviceNumber = deviceNumber;
	}
	
}
