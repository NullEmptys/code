package com.gamedo.loginServer.message;

/**
 * 基础消息类
 * 
 * @author libm
 *
 */
public class CommonMessage {

	public static final String TRUE = "0";

	public static final String FALSE = "1";
	
	public static final String SERVER_NOT_OPEN = "2";

	/** 求服务器处理客户端请求结果 1：成功 0：失败 */
	private String code = FALSE;

	/** 状态描述 */
	private String desc;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
