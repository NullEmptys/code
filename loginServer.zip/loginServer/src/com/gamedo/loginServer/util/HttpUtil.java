package com.gamedo.loginServer.util;

import javax.servlet.http.HttpServletRequest;

public class HttpUtil {
	/**
	 * 获取IP地址
	 * 
	 * @param request
	 * @return
	 */
	public static String getIp(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}

		if (ip != null)
			ip = getFirstIp(ip);

		return ip;
	}

	private static String getFirstIp(String ipString) {
		String ip = null;
		String[] ipList = ipString.split(",");
		if (ipList != null && ipList.length > 1) {
			ip = ipList[0];
		} else {
			ip = ipString;
		}
		return ip;
	}
}
