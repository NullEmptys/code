package com.gamedo.loginServer.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;

import org.codehaus.jackson.annotate.JsonMethod;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.map.ObjectMapper;

import com.gamedo.loginServer.message.RegistAccountRequestMessage;

/**
 * json工具类
 * 
 * @author libm
 * 
 */
public class JsonUtil {

private static ObjectMapper objectMapper = new ObjectMapper();
	
	static {
		objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS Z"));
		objectMapper.setVisibility(JsonMethod.FIELD, Visibility.ANY);
	}

	/**
	 * 使用对象进行json反序列化。
	 * 
	 * @param json
	 *            json串
	 * @param pojoClass
	 *            类类型
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static Object decodeJson(String json, Class pojoClass)
			throws Exception {
		try {
			return objectMapper.readValue(json, pojoClass);
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * 将对象序列化。
	 * 
	 * @param o
	 *            实体对象
	 * @return 序列化后json
	 * @throws Exception
	 */
	public static String encodeJson(Object o) throws Exception {
		try {
			return objectMapper.writeValueAsString(o);
		} catch (Exception e) {
			throw e;
		}
	}
	
	/** 
     * MD5 加密 
     */  
    public static String getMD5Str(String str) {  
        MessageDigest messageDigest = null;  
  
        try {  
            messageDigest = MessageDigest.getInstance("MD5");  
  
            messageDigest.reset();  
  
            messageDigest.update(str.getBytes("UTF-8"));  
        } catch (NoSuchAlgorithmException e) {  
            System.out.println("NoSuchAlgorithmException caught!");  
            System.exit(-1);  
        } catch (UnsupportedEncodingException e) {  
            e.printStackTrace();  
        }  
  
        byte[] byteArray = messageDigest.digest();  
  
        StringBuffer md5StrBuff = new StringBuffer();  
  
        for (int i = 0; i < byteArray.length; i++) {              
            if (Integer.toHexString(0xFF & byteArray[i]).length() == 1)  
                md5StrBuff.append("0").append(Integer.toHexString(0xFF & byteArray[i]));  
            else  
                md5StrBuff.append(Integer.toHexString(0xFF & byteArray[i]));  
        }  
  
        return md5StrBuff.toString();  
    }
    
    public static void main(String args[]) {
    	RegistAccountRequestMessage message = new RegistAccountRequestMessage();
    	message.setUserName("libiming");
    	message.setPassward("123456");
    	message.setChannelId("91");
    	message.setSubChannelId("1");
    	message.setUid("332612");
    	message.setDeviceNumber("asdfrc1343");
    	
    	try {
			String content = encodeJson(message);
			System.out.println(content);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
