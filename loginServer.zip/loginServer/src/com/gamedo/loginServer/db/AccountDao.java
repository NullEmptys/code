package com.gamedo.loginServer.db;

import org.springframework.stereotype.Component;

import com.gamedo.loginServer.entity.Account;

@Component
public class AccountDao extends GenericHibernateDAO<Account, Integer>{

	/**
	 * 根据账号名称获取指定账号
	 * @param userName
	 * @return
	 */
	public Account getAccountByName(String userName) {
		return (Account) uniqueResult("from Account a where a.userName=?", userName);
	}
	
}
