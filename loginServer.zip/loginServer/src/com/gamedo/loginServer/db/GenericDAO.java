package com.gamedo.loginServer.db;

import java.io.Serializable;
import java.util.List;

/**
 * @author libm
 *
 * @param <T>
 * @param <ID>
 */
public interface GenericDAO<T, ID extends Serializable> {


    List<T> findAll();

    List<T> findByExample(T exampleInstance, String... excludeProperty);

    T makePersistent(T entity);

    void makeTransient(T entity);
    
    T newEntity(T entity);
    
    T updateEntity(T entity);

    void flush();

    void clear();

}
