package com.gamedo.loginServer.db;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.loginServer.data.announcement.Announcement;

/**
 * 
 * @author libm
 *
 */
@Repository
public class AnnouncementDao extends DataGenericHibernateDAO<Announcement, Integer>{
 
	@SuppressWarnings("unchecked")
	public List<Announcement> laodAnnouncements() {
		String hql = "from Announcement t where t.broadcastStartTime < ? and t.broadcastEndTime > ?";
		return list(hql, new Date(),new Date());
	}
}
