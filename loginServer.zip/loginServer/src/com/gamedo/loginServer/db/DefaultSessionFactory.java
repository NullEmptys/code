package com.gamedo.loginServer.db;

import org.hibernate.SessionFactory;

public class DefaultSessionFactory {

	private static SessionFactory accountSessionFactory;

	private static SessionFactory dataSessionFactory;

	public static SessionFactory getAccountSessionFactory() {
		return accountSessionFactory;
	}

	public static void setAccountSessionFactory(SessionFactory accountSessionFactory) {
		DefaultSessionFactory.accountSessionFactory = accountSessionFactory;
	}

	public static SessionFactory getDataSessionFactory() {
		return dataSessionFactory;
	}

	public static void setDataSessionFactory(SessionFactory dataSessionFactory) {
		DefaultSessionFactory.dataSessionFactory = dataSessionFactory;
	}


}
