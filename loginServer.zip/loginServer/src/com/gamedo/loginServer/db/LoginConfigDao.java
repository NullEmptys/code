package com.gamedo.loginServer.db;

import org.springframework.stereotype.Repository;

import com.gamedo.loginServer.data.config.LoginConfig;

/**
 * 
 * @author libm
 *
 */
@Repository
public class LoginConfigDao extends DataGenericHibernateDAO<LoginConfig, Integer> {

	public LoginConfig loadLoginConfig() {
		String hql = "from LoginConfig t where t.id = ?";
		return (LoginConfig) uniqueResult(hql, 1);
	}
}
