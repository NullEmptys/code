package com.gamedo.loginServer.service;

public interface BaseService {

	public String getId();
	
	public void startup() throws Exception;
	
	public void reloadData() throws Exception;
	
	public void shutdown() throws Exception;
}
