package com.gamedo.loginServer.service;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gamedo.loginServer.data.announcement.Announcement;
import com.gamedo.loginServer.db.AnnouncementDao;
import com.gamedo.loginServer.message.AnnouncementData;

/**
 * 
 * @author libm
 *
 */
@Service
public class AnnouncementService implements AnnouncementServiceMBean{

	private Logger logger = LoggerFactory.getLogger(AnnouncementService.class);
	
	private List<Announcement> announcements = new ArrayList<>();
	
	private ObjectName objectName;
	
	@Autowired
	private AnnouncementDao announcementDao;
	
	@PostConstruct
	public void startup() throws Exception {
		loadAnnouncements();
		try {
			MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
			this.objectName = new ObjectName("掌上纵横-IPOC-LOVELIVE:type=服务,name=游戏外公告服务");
			mbs.registerMBean(this, objectName);
		}catch (Exception e) {
			logger.warn("注册MBean异常", e);
		}
	}

	@PreDestroy
	public void shutdown() throws Exception {
		
	}

	@Override
	public void loadAnnouncements() {
		announcements = announcementDao.laodAnnouncements();
	}

	/**
	 * 获取有效公告列表
	 * @return
	 */
	public AnnouncementData getAnnouncementData() {
		for(int i = 0; i < announcements.size(); i++) {
			Announcement announcement = announcements.get(i);
			if(announcement != null && announcement.getStartTime().before(new Date()) && announcement.getEndTime().after(new Date()) && announcement.getCategory() == 1) {
				AnnouncementData data = new AnnouncementData();
				data.setId(announcement.getId());
				data.setTitle(announcement.getTitle());
				data.setContent(announcement.getContent());
				data.setType(announcement.getType());
				data.setBackGroundId(announcement.getBackGroundId());
				data.setSequence(announcement.getSequence());
				return data;
			}
		}
		return null;
	}
	
}
