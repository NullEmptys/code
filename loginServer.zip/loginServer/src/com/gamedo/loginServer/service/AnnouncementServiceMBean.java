package com.gamedo.loginServer.service;

public interface AnnouncementServiceMBean {

	public void loadAnnouncements();
}
