package com.gamedo.loginServer.service;

import java.lang.management.ManagementFactory;

import javax.annotation.PostConstruct;
import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gamedo.loginServer.data.config.LoginConfig;
import com.gamedo.loginServer.db.LoginConfigDao;

@Service
public class LoginConfigService implements LoginConfigServiceMBean{

	private Logger logger = LoggerFactory.getLogger(LoginConfigService.class);
	
	@Autowired
	private LoginConfigDao loginConfigDao;
	
	public LoginConfig loginConfig;
	
	private ObjectName objectName;
	
	@PostConstruct
	public void start() {
		loadLoginConfig();
		try {
			MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
			this.objectName = new ObjectName("掌上纵横-IPOC-LOVELIVE:type=认证,name=loginConfig");
			mbs.registerMBean(this, objectName);
		}catch (Exception e) {
			logger.warn("注册MBean异常", e);
		}
	}

	@Override
	public void loadLoginConfig() {
		loginConfig = loginConfigDao.loadLoginConfig();
	}

	public LoginConfig getLoginConfig() {
		return loginConfig;
	}

	public void setLoginConfig(LoginConfig loginConfig) {
		this.loginConfig = loginConfig;
	}
	
}
