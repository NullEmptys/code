package com.gamedo.loginServer.service;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gamedo.loginServer.db.AccountDao;
import com.gamedo.loginServer.entity.Account;

/**
 * 账号服务
 * 
 * @author libm
 *
 */
@Service
public class AccountService implements Runnable{

	protected static final Logger log = LoggerFactory.getLogger(AccountService.class);

	@Autowired
	private AccountDao accountDao;

	private ConcurrentHashMap<String, Account> accounts = new ConcurrentHashMap<>();

	/**
	 * 根据账号名称获取账号
	 * 
	 * @param userName
	 * @return
	 */
	public Account getAccountByName(String userName) {
		Account account = accounts.get(userName);
		if (account != null) {
			return account;
		}
		account = accountDao.getAccountByName(userName);
		if (account != null) {
			account.setLoadTime();
			Account _account = accounts.get(userName);
			if (_account == null) {
				accounts.put(account.getUserName(), account);
				return account;
			} else {
				return _account;
			}
		}
		return null;
	}

	public void updateAcount(Account account) {
		accountDao.updateEntity(account);
	}

	@Override
	public void run() {
		while (true) {
			try {
				Thread.sleep(60 * 1000L);
			} catch (InterruptedException e) {
			}
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MINUTE, -30);
			Date checkTime = cal.getTime();
			for (Account account : accounts.values()) {
				Date loadTime = account.getLoadTime();
				if (loadTime.before(checkTime))
					accounts.remove(account.getId());
			}
			log.info("[online]count[" + accounts.size() + "]");
		}
	}

	/**
	 * 创建账号
	 * @param userName
	 * @param passward
	 * @param uid
	 * @param channelId
	 * @param subChannelId
	 * @param deviceNumber
	 */
	public Account createAccount(String userName, String passward, String uid, String channelId, String subChannelId,
			String deviceNumber) {
		Account account = new Account();
		account.setUserName(userName);
		account.setPassward(passward);
		account.setUid(uid);
		account.setCreateTime(new Date());
		account.setChannelId(channelId);
		account.setSubChannelId(subChannelId);
		account.setDeviceNumber(deviceNumber);
		
		accountDao.newEntity(account);
		return account;
	}

}
