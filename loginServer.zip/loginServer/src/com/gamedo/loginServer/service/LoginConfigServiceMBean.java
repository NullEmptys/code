package com.gamedo.loginServer.service;

public interface LoginConfigServiceMBean {

	public void loadLoginConfig();
}
