package com.gamedo.loginServer.data.announcement;

import java.util.Date;

public class Announcement {

	private int id;
	/**公告标题*/
	private String title;
	/**公告内容*/
	private String content;
	/**1、外部公告  2、游戏内部公告*/
	private int category;
	/**公告类型 1、文字   2、图片*/
	private int type;
	/**广播开始时间*/
	private Date broadcastStartTime;
	/**广播结束时间*/
	private Date broadcastEndTime;
	/**开始时间*/
	private Date startTime;
	/**结束时间*/
	private Date endTime;
	/**公告背景图片id*/
	private String backGroundId;
	/**显示顺序*/
	private int sequence;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getBroadcastStartTime() {
		return broadcastStartTime;
	}
	public void setBroadcastStartTime(Date broadcastStartTime) {
		this.broadcastStartTime = broadcastStartTime;
	}
	public Date getBroadcastEndTime() {
		return broadcastEndTime;
	}
	public void setBroadcastEndTime(Date broadcastEndTime) {
		this.broadcastEndTime = broadcastEndTime;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public String getBackGroundId() {
		return backGroundId;
	}
	public void setBackGroundId(String backGroundId) {
		this.backGroundId = backGroundId;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	
}
