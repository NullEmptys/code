package com.gamedo.loginServer.entity;

import java.util.Date;

/**
 * 账号实体类
 * @author libm
 *
 */
public class Account {

	/** 账号状态 **/
	public final static byte STATUS_NORMAL = 0;
	
	private long id;
	
	/**渠道账号唯一id*/
	private String uid;
	
	/**账号名称*/
	private String userName;
	
	/**密码*/
	private String passward;
	
	/**账号创建时间*/
	private Date createTime;
	
	/**账号最后登陆时间*/
	private Date lastLoginTime;
	
	/**加载时间*/
	private Date loadTime;
	
	/**渠道号*/
	private String channelId;
	
	/**子渠道号*/
	private String subChannelId;
	
	/**设备唯一号*/
	private String deviceNumber;
	
	/**账号状态*/
	private byte status = 0;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassward() {
		return passward;
	}

	public void setPassward(String passward) {
		this.passward = passward;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getSubChannelId() {
		return subChannelId;
	}

	public void setSubChannelId(String subChannelId) {
		this.subChannelId = subChannelId;
	}

	public String getDeviceNumber() {
		return deviceNumber;
	}

	public void setDeviceNumber(String deviceNumber) {
		this.deviceNumber = deviceNumber;
	}

	public byte getStatus() {
		return status;
	}

	public void setStatus(byte status) {
		this.status = status;
	}

	public Date getLoadTime() {
		return loadTime;
	}

	public void setLoadTime() {
		this.loadTime = new Date();
	}
	
}
