package com.gamedo.loginServer.io;

/**
 * 消息协议号
 * @author libm
 *
 */
public class OpCode {

	/*创建账号*/
	public static final String REGISTACCOUNT = "/registAccount";
	/*登录账号*/
	public static final String LOGINACCOUNT = "/loginAccount";
	/*外部公告*/
	public static final String ANNOUNCEMENT = "/announcement";
	/*服务器状态*/
	public static final String SERVER_STATE = "serverState";
}
