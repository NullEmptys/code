package com.gamedo.loginServer.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gamedo.loginServer.entity.Account;

/**
 * 日志统一管理类
 * @author libm
 *
 */
@Component
public class Log {

	public Logger log = LoggerFactory.getLogger(Log.class);
	
	/**注册账号*/
	public void logAccountRegist(Account account) {
		StringBuilder out = new StringBuilder();
		out.append("[registAccount]");
		getAccountString(out, account);
		log.info(out.toString());
	}

	/**账号登陆
	 * @param ip 客户端ip地址
	 * @param date 账号最后登陆时间 
	 * 
	 */
	@SuppressWarnings("deprecation")
	public void logAccountLogin(Account account, String ip) {
		StringBuilder out = new StringBuilder();
		out.append("[loginAccount]");
		getAccountString(out, account);
		out.append("lastLoginTime[");
		out.append(account.getLastLoginTime().toLocaleString());
		out.append("]ip[");
		out.append(ip).append("]");
		log.info(out.toString());
	}
	
	/**获取账号信息*/
	public StringBuilder getAccountString(StringBuilder out,Account account) {
		out.append("username[").append(account.getUserName()).append("]");
		out.append("passward[").append(account.getPassward()).append("]");
		out.append("uid[").append(account.getUid()).append("]");
		out.append("channelId[").append(account.getChannelId()).append("]");
		out.append("subChannelId[").append(account.getSubChannelId()).append("]");
		return out;
	}
}
