package com.gamedo.loginServer.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.loginServer.entity.Account;
import com.gamedo.loginServer.io.OpCode;
import com.gamedo.loginServer.log.Log;
import com.gamedo.loginServer.message.CommonMessage;
import com.gamedo.loginServer.message.RegistAccountRequestMessage;
import com.gamedo.loginServer.service.AccountService;
import com.gamedo.loginServer.util.JsonUtil;

/**
 * 注册账号
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.REGISTACCOUNT)
public class RegistAccountController extends AbstractController<RegistAccountRequestMessage>{

	@Autowired
	private Log log;
	
	@Autowired
	private AccountService accountService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response,RegistAccountRequestMessage requestMessage) {

		requestMessage = getRequestMessage(request, requestMessage);
		String userName = requestMessage.getUserName();//账号名称
		String passward = requestMessage.getPassward();//账号密码
		String channelId = requestMessage.getChannelId();//渠道号
		String subChannelId = requestMessage.getSubChannelId();//子渠道号
		String uid = requestMessage.getUid();//渠道账号唯一id
		String deviceNumber = requestMessage.getDeviceNumber();//设备唯一号

		CommonMessage message = new CommonMessage();
		
		Account account = accountService.getAccountByName(userName);
		if (account == null) {
			
			account = accountService.createAccount(userName,passward,uid,channelId,subChannelId,deviceNumber);
			
			message.setCode(CommonMessage.TRUE);
			message.setDesc("创建成功");
			
			log.logAccountRegist(account);
		} else {
			message.setCode(CommonMessage.FALSE);
			message.setDesc("该名称已被占用了");
		}
		try {
			this.sendMessage(response,JsonUtil.encodeJson(message));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@RequestMapping(method = RequestMethod.GET)
	public void execute1(HttpServletRequest request, HttpServletResponse response,RegistAccountRequestMessage requestMessage) {

		String userName = request.getParameter("userName");//账号名称
		String passward = null;
		String channelId = null;
		String subChannelId = null;
		String uid = null;
		String deviceNumber = null;

		CommonMessage message = new CommonMessage();
		
		Account account = accountService.getAccountByName(userName);
		if (account == null) {
			
			account = accountService.createAccount(userName,passward,uid,channelId,subChannelId,deviceNumber);
			
			message.setCode(CommonMessage.TRUE);
			message.setDesc("创建成功");
			
			log.logAccountRegist(account);
		} else {
			message.setCode(CommonMessage.FALSE);
			message.setDesc("该名称已被占用了");
		}
		try {
			this.sendMessage(response,JsonUtil.encodeJson(message));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
