package com.gamedo.loginServer.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.loginServer.data.config.LoginConfig;
import com.gamedo.loginServer.io.OpCode;
import com.gamedo.loginServer.message.CommonMessage;
import com.gamedo.loginServer.service.LoginConfigService;
import com.gamedo.loginServer.util.JsonUtil;

/**
 * 更新资源之前获取服务器状态
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.SERVER_STATE)
public class ServerStateController {

	@Autowired
	private LoginConfigService loginConfigService;

	@RequestMapping(method = RequestMethod.POST)
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String remoteIp = getIpAddr(request);
		LoginConfig loginConfig = loginConfigService.getLoginConfig();
		CommonMessage message = new CommonMessage();
		System.out.println("remoteIp=" + remoteIp);
		if (!loginConfig.isSafetyIp(remoteIp)) {
			if (!loginConfig.isOpenNow()) { // 不在开放时间
				Date openTime = loginConfig.getFutureOpenTime();
				if (openTime != null) {
					SimpleDateFormat formatter = new SimpleDateFormat(LoginConfig.TIME_STYLE);
					message.setDesc(loginConfig.getUpdateDesc());
				} else {
					message.setDesc(LoginConfig.MAINTANCE);
				}
				message.setCode(CommonMessage.SERVER_NOT_OPEN);
			}else {
				message.setCode(CommonMessage.TRUE);
				message.setDesc("");
			}
		} else {
			message.setCode(CommonMessage.TRUE);
			message.setDesc("");
		}
		try {
			response.getOutputStream().write(JsonUtil.encodeJson(message).getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}

		if (ip != null) {
			ip = getFirstIp(ip);
		}
		return ip;
	}

	public String getFirstIp(String ipString) {
		String ip = null;
		String[] ipList = ipString.split(",");
		if (ipList != null && ipList.length > 1) {
			ip = ipList[0];
		} else {
			ip = ipString;
		}
		return ip;
	}
}
