package com.gamedo.loginServer.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gamedo.loginServer.util.JsonUtil;

public abstract class AbstractController<T> {
	
	private Logger loger = LoggerFactory.getLogger(AbstractController.class);
	
	public abstract void execute(HttpServletRequest request, HttpServletResponse response,T requestMessage);

	@SuppressWarnings("unchecked")
	public T getRequestMessage(HttpServletRequest request,T requestMessage) {
		String content = "";
		java.io.BufferedReader reader = null;
		try {
			reader = request.getReader();// 获得字符流
			StringBuffer sb = new StringBuffer();
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\r\n");
			}
			content = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
				reader = null;
			} catch (Exception e) {
			}
		}
		
		try {
			requestMessage = (T) JsonUtil.decodeJson(content, requestMessage.getClass());
			return requestMessage;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 给客户端返回消息
	 * @param response
	 * @param message 消息内容
	 */
	public void sendMessage(HttpServletResponse response,String message) {
		try {
			loger.info("sendClientMessage=" + message);
			response.getOutputStream().write(message.getBytes("utf-8"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
