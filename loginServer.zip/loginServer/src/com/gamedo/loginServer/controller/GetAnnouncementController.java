package com.gamedo.loginServer.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.loginServer.io.OpCode;
import com.gamedo.loginServer.message.AnnouncementData;
import com.gamedo.loginServer.message.CommonMessage;
import com.gamedo.loginServer.message.GetAnnouncementResponseMessage;
import com.gamedo.loginServer.service.AnnouncementService;
import com.gamedo.loginServer.util.JsonUtil;

/**
 * 获取公告
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.ANNOUNCEMENT)
public class GetAnnouncementController {

	@Autowired
	private AnnouncementService announcementService;

	@RequestMapping(method = RequestMethod.POST)
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		GetAnnouncementResponseMessage message = new GetAnnouncementResponseMessage();
		AnnouncementData data = announcementService.getAnnouncementData();
		if (data != null) {
			message.setCode(CommonMessage.TRUE);
			message.setAnnouncementData(data);
		} else {
			message.setCode(CommonMessage.FALSE);
		}
		try {
			response.getOutputStream().write(JsonUtil.encodeJson(message).getBytes("utf-8"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
