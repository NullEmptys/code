package com.gamedo.loginServer.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.loginServer.entity.Account;
import com.gamedo.loginServer.io.OpCode;
import com.gamedo.loginServer.log.Log;
import com.gamedo.loginServer.message.CommonMessage;
import com.gamedo.loginServer.message.LoginAccountRequestMessage;
import com.gamedo.loginServer.service.AccountService;
import com.gamedo.loginServer.util.HttpUtil;
import com.gamedo.loginServer.util.JsonUtil;

/**
 * 账号登录
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.LOGINACCOUNT)
public class LoginAccountController extends AbstractController<LoginAccountRequestMessage> {

	@Autowired
	private AccountService accountService;

	@Autowired
	private Log log;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response,
			LoginAccountRequestMessage requestMessage) {

		CommonMessage message = new CommonMessage();
		
		requestMessage = getRequestMessage(request, requestMessage);

		String userName = requestMessage.getUserName();// 账号名称
		String passward = requestMessage.getPassward();// 密码

		Account account = accountService.getAccountByName(userName);
		if (account == null) {
			message.setCode(CommonMessage.FALSE);
			message.setDesc("账号不存在");
		} else {
			if (!account.getUserName().equals(userName) || !account.getPassward().equals(passward)) {
				message.setCode(CommonMessage.FALSE);
				message.setDesc("请确认账号名称或密码");
			} else {
				message.setCode(CommonMessage.TRUE);
				message.setDesc("登陆成功");

				account.setLastLoginTime(new Date());
				accountService.updateAcount(account);
				log.logAccountLogin(account, HttpUtil.getIp(request));
			}
		}
		try {
			sendMessage(response, JsonUtil.encodeJson(message));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}