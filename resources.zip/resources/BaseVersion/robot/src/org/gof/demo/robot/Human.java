package org.gof.demo.robot;

import org.gof.demo.worldsrv.msg.Msg.DVector2;
import org.gof.demo.worldsrv.support.Vector2;
import org.jboss.netty.channel.Channel;

public class Human {
	
	private Channel channel = null;
	
	public long id;
	public String name;
	public int level;
	public int sex;
	public int hpCur;
	public int mpCur;
	public int profession;
	public Vector2 posNow;
	public long stageId;
	public int stageSn;
	
	public float speed;
	
	
	public Channel getChannel() {
		return channel;
	}
	public void setChannel(Channel channel) {
		this.channel = channel;
	}
}
