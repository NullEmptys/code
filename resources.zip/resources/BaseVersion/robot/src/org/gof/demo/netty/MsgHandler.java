package org.gof.demo.netty;

import java.util.Scanner;

import org.gof.core.support.RandomUtils;
import org.gof.core.support.SysException;
import org.gof.core.support.Utils;
import org.gof.demo.robot.Human;
import org.gof.demo.robot.RobotStartup;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.MsgIds;
import org.gof.demo.worldsrv.msg.Msg.SCLoginResult;
import org.gof.demo.worldsrv.msg.Msg.SCQueryCharactersResult;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.Vector2;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelStateEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelUpstreamHandler;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;

public class MsgHandler extends SimpleChannelUpstreamHandler {
	@Override
	public void messageReceived(ChannelHandlerContext ctx, MessageEvent e) {
		try {
			received(ctx, e);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private void saveChannel(Channel channel) {
		if(RobotStartup.game.human.getChannel() == null || !RobotStartup.game.human.getChannel().equals(channel)) {
			RobotStartup.game.human.setChannel(channel);
		}
	}
	
	private void beginGame() {
		RobotStartup.game.setGameRunning(true);
	}
	private void received(ChannelHandlerContext ctx, MessageEvent e) throws InvalidProtocolBufferException, InterruptedException {
		//消息
		byte[] buf = (byte[]) e.getMessage();
		
		int len = Utils.bytesToInt(buf, 0);
		int msgId = Utils.bytesToInt(buf, 4);
		byte[] msgbuf = new byte[len - 8];
		System.arraycopy(buf, 8, msgbuf, 0, len - 8);
		
		saveChannel(e.getChannel());
		Log.coreMsg.info("收到服务器端消息：id={}, name={}", msgId, MsgIds.getNameById(msgId));
		
		switch(msgId) {
			case MsgIds.SCLoginResult: {
				SCLoginResult msg = SCLoginResult.parseFrom(msgbuf);
				if(msg.getResultCode() < 0) {
					Log.temp.info("登陆返回信息={}", msg.getResultReason());
					return;
				}
				
				Msg.CSQueryCharacters.Builder querymsg = Msg.CSQueryCharacters.newBuilder();
				sendMsgToServer(e.getChannel(), querymsg);	
			}
			break;
			
			case MsgIds.SCQueryCharactersResult: {
					Msg.SCQueryCharactersResult msg = Msg.SCQueryCharactersResult.parseFrom(msgbuf);
					//玩家角色已创建 进行登录
					int count = msg.getCharactersCount();
					if(count > 0) {
						Msg.CSCharacterLogin.Builder sendmsg = Msg.CSCharacterLogin.newBuilder();
						sendmsg.setHumanId(msg.getCharacters(0).getId());
						sendMsgToServer(e.getChannel(), sendmsg);
					} else {	//玩家角色未创建 进行创建
						Msg.CSCharacterCreate.Builder msgSend = Msg.CSCharacterCreate.newBuilder();
						msgSend.setName("角色名" + RandomUtils.nextInt(999));
						msgSend.setProfession(1);
						msgSend.setSex(1);
						
						sendMsgToServer(e.getChannel(), msgSend);
					}
			}
			break;
			
			case MsgIds.SCCharacterCreateResult: {
				Msg.SCCharacterCreateResult msg = Msg.SCCharacterCreateResult.parseFrom(msgbuf);
				
				int code = msg.getResultCode();
				
				//创建失败
				if(code < 0) {
					throw new SysException("创建角色失败。");
				} else {	//创建成功 登录
					Msg.CSCharacterLogin.Builder sendmsg = Msg.CSCharacterLogin.newBuilder();
					sendmsg.setHumanId(msg.getHumanId());
					sendMsgToServer(e.getChannel(), sendmsg);
				}
			}
			break;
			
			case MsgIds.SCCharacterLoginResult: {
				Msg.SCCharacterLoginResult msg = Msg.SCCharacterLoginResult.parseFrom(msgbuf);
				
				//进入游戏
				beginGame();
				Log.coreMsg.info("登录游戏结果返回编号：{}", msg.getResultCode());
			}
			break;
			
			case MsgIds.SCInitData: {
				Msg.SCInitData msg = Msg.SCInitData.parseFrom(msgbuf);
				
				Log.coreMsg.info("服务器返回玩家的初始属性:{}", msg);
				
				setHumanMsg(msg);
				
				//进入地图
				Msg.CSStageEnter.Builder sendmsg = Msg.CSStageEnter.newBuilder();
				sendMsgToServer(e.getChannel(), sendmsg);
			}
			break;
			
			case MsgIds.SCAccountReconnectResult: {
				Msg.SCAccountReconnectResult msg = Msg.SCAccountReconnectResult.parseFrom(msgbuf);
				
				Log.coreMsg.info("SCAccountReconnectResult={}", msg);
			}
			break;
			
			case MsgIds.SCStageEnterResult: {
				Msg.SCStageEnterResult msg = Msg.SCStageEnterResult.parseFrom(msgbuf);
				Log.coreMsg.info("SCStageEnterResult={}", msg);
			}
			break;
			
			case MsgIds.SCStageSwitch: {
				Msg.SCStageSwitch msg = Msg.SCStageSwitch.parseFrom(msgbuf);
				
				Log.coreMsg.info("SCStageSwitch={}", msg);
				
				Msg.CSStageEnter.Builder sendmsg = Msg.CSStageEnter.newBuilder();
				sendMsgToServer(e.getChannel(), sendmsg);
			}
			break;
			case MsgIds.SCStageObjectAppear: {
				Msg.SCStageObjectAppear msg = Msg.SCStageObjectAppear.parseFrom(msgbuf);
				
				Log.coreMsg.info("SCStageObjectAppear = {}", msg);
				
//				Msg.CSStageSwitch.Builder sendMsg = Msg.CSStageSwitch.newBuilder();
//				sendMsg.setAreaSwitchKey("10001");
//				sendMsgToServer(e.getChannel(), sendMsg);
			}
			break;
			case MsgIds.SCHumanKick : {
				Log.temp.debug("收到踢人信息!!!!!!");
			}
			break;
		}
		
		
	}
	
	private void setHumanMsg(Msg.SCInitData msg) {
		Human human = RobotStartup.game.human;
		human.id = msg.getHuman().getId();
		human.name = msg.getHuman().getName();
		human.level = msg.getHuman().getLevel();
		human.sex = msg.getHuman().getSex();
		human.profession = msg.getHuman().getProfession();
		human.stageId = msg.getStage().getId();
		human.stageSn = msg.getStage().getSn();
		
		human.posNow = new Vector2(msg.getStage().getPosNow());
		human.speed = msg.getHuman().getProp().getSpeed();
		
	}
	private void sendMsgToServer(Channel channel, com.google.protobuf.Message.Builder builder) {
		Message msg = builder.build();
		int msgId = MsgIds.getIdByClass(msg.getClass());

		byte[] buf = msg.toByteArray();
		byte[] header = new byte[8];
		Utils.intToBytes(header, 0, buf.length + 8);
		Utils.intToBytes(header, 4, msgId);
		
		channel.write(header);
		channel.write(buf);
		
		Log.coreMsg.info("发送消息至服务器：id={}, name={}", msgId, MsgIds.getNameById(msgId));
	}
	
	/**
	 * 新建立一个channel
	 */
	@Override
	public void channelConnected(ChannelHandlerContext ctx, ChannelStateEvent e) {
		Msg.CSLogin.Builder sendmsg = Msg.CSLogin.newBuilder();
		sendmsg.setName("gh2");
		sendmsg.setPassword("1");
		sendMsgToServer(e.getChannel(), sendmsg);
		
//		Msg.CSAccountReconnect.Builder rc = Msg.CSAccountReconnect.newBuilder();
//		rc.setSessionKey(-105554269);
//		sendMsgToServer(e.getChannel(), rc);
	}

	@Override
	public void channelDisconnected(ChannelHandlerContext ctx, ChannelStateEvent e) throws Exception {
		super.channelDisconnected(ctx, e);
		
		Log.temp.info("连接已断开");
	}
}
