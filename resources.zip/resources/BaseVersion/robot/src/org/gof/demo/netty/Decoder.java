package org.gof.demo.netty;

import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.handler.codec.frame.LengthFieldBasedFrameDecoder;

/**
 * 消息结构
 * +----------+
 * |  总长度  |
 * +----------+
 * |  消息ID  |
 * +----------+
 * | 主体数据 |
 * +----------+
 * 总长度 = 消息ID + 主体数据
 */
public class Decoder extends LengthFieldBasedFrameDecoder {  

	public Decoder() {
		//[1]最大程度不限 
		//[2-3]4位为长度头 
		//[4]由于总长度包含头长度，所以需要进行修正 
		//[5]不跳过任何字节（比如头长度），客户端发什么就接什么
		super(Integer.MAX_VALUE, 0, 4, -4, 0);
	}

	@Override
	protected Object decode(ChannelHandlerContext ctx, Channel channel, ChannelBuffer buffer) throws Exception {
		ChannelBuffer buffs = (ChannelBuffer)super.decode(ctx, channel, buffer);
		if(buffs == null) return null;

		//主体数据
		byte[] decoded = new byte[buffs.readableBytes()];  
        buffs.readBytes(decoded);
        
		return decoded;
	}
}