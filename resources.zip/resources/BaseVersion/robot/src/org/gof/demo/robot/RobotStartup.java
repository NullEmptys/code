package org.gof.demo.robot;

import java.net.InetSocketAddress;
import java.util.concurrent.Executors;

import org.gof.demo.netty.Decoder;
import org.gof.demo.netty.Encoder;
import org.gof.demo.netty.MsgHandler;
import org.jboss.netty.bootstrap.ClientBootstrap;
import org.jboss.netty.channel.ChannelFactory;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.socket.nio.NioClientSocketChannelFactory;

public class RobotStartup {
	
	public static RobotGame game = new RobotGame();
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.setProperty("logFileName", "robot");
		

		ChannelFactory factory = new NioClientSocketChannelFactory(
				Executors.newCachedThreadPool(),
				Executors.newCachedThreadPool());

		ClientBootstrap bootstrap = new ClientBootstrap(factory);

		bootstrap.setPipelineFactory(new ChannelPipelineFactory() {
			public ChannelPipeline getPipeline() {  
		        ChannelPipeline p = Channels.pipeline();
		        p.addLast("decoder", new Decoder());
				p.addLast("encoder", new Encoder());
				
				p.addLast("handler", new MsgHandler());
		        
		        return p;  
		    }
		});
		
		bootstrap.setOption("tcpNoDelay", true);
		bootstrap.setOption("keepAlive", true);
		
		bootstrap.connect(new InetSocketAddress(8888));
		
	}
}
