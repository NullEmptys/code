package org.gof.demo.netty;

import static org.jboss.netty.buffer.ChannelBuffers.wrappedBuffer;

import org.gof.core.support.SysException;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.handler.codec.oneone.OneToOneEncoder;

/**
 * 消息结构
 * +----------+
 * |  总长度  |
 * +----------+
 * |  消息ID  |
 * +----------+
 * | 主体数据 |
 * +----------+
 * 总长度 = 消息ID + 主体数据
 */
public class Encoder extends OneToOneEncoder {
	
	@Override  
    protected Object encode(ChannelHandlerContext cxt, Channel channel, Object msg) throws Exception {
		if (!(msg instanceof byte[])) {
			throw new SysException("只能发送byte[]类型数据: 当前数据=" + msg);
        }

		//主体数据
		ChannelBuffer body = wrappedBuffer((byte[])msg);
		
        //将头和主体合并起来
		return body;
	}
}