package org.gof.demo.robot;

import java.util.HashMap;
import java.util.Map;

import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.DVector2;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.Vector2;

import com.google.protobuf.GeneratedMessage;

public class RobotStageManager {

	private RobotGame game;

	public RobotStageManager(RobotGame game) {
		this.game = game;
	}

	public boolean msgHandle(String[] strArray, int size) {
		switch (strArray[0]) {
		case "stageSwitch": {
			stageSwich(strArray, size);
		}
			break;
		case "stageMove": {
			stageMove(strArray, size);
		}
			break;
		case "StageMoveStop": {
			stageMoveStop(strArray, size);
		}
			break;
		default: {
			return false;
		}
		}
		return true;
	}

	private void stageSwich(String[] strArray, int size) {
		Msg.CSStageSwitch.Builder sendMsg = Msg.CSStageSwitch.newBuilder();
		sendMsg.setAreaSwitchKey(strArray[1]);
		game.sendMsgToServer(game.human.getChannel(), sendMsg);
	}
	
	private void stageMove(String[] strArray, int size) {
		Msg.CSStageMove.Builder sendMsg = Msg.CSStageMove.newBuilder();
		float x = Utils.floatValue(strArray[1]);
		float y = Utils.floatValue(strArray[2]);
		if(x == 0 || y == 0) {
			Log.temp.info("坐标输入错误");
		}
		
		sendMsg.addPosEnd(new Vector2(x, y).toMsg());
		game.sendMsgToServer(game.human.getChannel(), sendMsg);
	}
	
	private void stageMoveStop(String[] strArray, int size) {
		Msg.CSStageMoveStop.Builder sendMsg = Msg.CSStageMoveStop.newBuilder();
		game.sendMsgToServer(game.human.getChannel(), sendMsg);
	}
	
}
