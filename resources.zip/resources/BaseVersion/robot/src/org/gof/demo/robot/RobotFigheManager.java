package org.gof.demo.robot;

public class RobotFigheManager {
	private RobotGame game;
	public RobotFigheManager(RobotGame game) {
		this.game = game;
	}
	
	public boolean msgHandle(String[] strArray, int size) {
		switch (strArray[0]) {
		case "": {
		}
		break;
		default: {
			return false;
		}
		}
		return true;
	}
}
