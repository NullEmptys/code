package org.gof.core.connsrv.netty;

import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.Channels;

public class ServerPipelineFactory implements ChannelPipelineFactory {  

	public ChannelPipeline getPipeline() {
		ChannelPipeline p = Channels.pipeline();
		p.addLast("decoder", new Decoder());
		p.addLast("encoder", new Encoder());
		
		p.addLast("handler", new ServerHandler());

		return p;
	}
}