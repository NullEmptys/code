package org.gof.core.connsrv;

import java.net.InetSocketAddress;

import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelStateEvent;

/**
 * FLASH授权请求处理类
 */
public class FlashPolicyHandler {
	//授权请求
//	private static final String POLICY_REQUEST = "<policy-file-request/>";
	//授权内容
	private static final String POLICY_RESPONSE = "<?xml version=\"1.0\"?><cross-domain-policy><allow-access-from domain=\"*\" to-ports=\"*\" /></cross-domain-policy>\0";
	//授权监听端口
	private static final int POLICY_PORT = 843;
	
	/**
	 * 检查是否为授权请求
	 * @param channel
	 * @return
	 */
	public static boolean handle(ChannelStateEvent e) {
		Channel channel = e.getChannel();
		InetSocketAddress addrLocal = (InetSocketAddress)channel.getLocalAddress();
		
		//不是授权端口
		if(POLICY_PORT != addrLocal.getPort()) return false;
		//不是授权请求
//		if(!POLICY_REQUEST.equals(e.getMessage())) return false;
		
		//返回授权协议内容
		channel.write(POLICY_RESPONSE.getBytes());
		
		return true;
	}
}