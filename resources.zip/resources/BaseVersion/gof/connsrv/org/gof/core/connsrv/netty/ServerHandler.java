package org.gof.core.connsrv.netty;

import java.net.InetSocketAddress;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.gof.core.Port;
import org.gof.core.connsrv.Connection;
import org.gof.core.connsrv.FlashPolicyHandler;
import org.gof.core.connsrv.main.ConnStartup;
import org.gof.core.support.log.LogCore;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelStateEvent;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelUpstreamHandler;
import org.slf4j.Logger;

public class ServerHandler extends SimpleChannelUpstreamHandler {
	private final Logger log = LogCore.conn;
	
	//channel对应的connection对象
	public static final Map<Integer, Connection> channelIdToConnectin = new ConcurrentHashMap<>();

	@Override  
    public void messageReceived(ChannelHandlerContext ctx, MessageEvent e) {
		try {
			//属性
			int connId = e.getChannel().getId();
			Connection conn = channelIdToConnectin.get(connId);

			//日志
//			if(log.isDebugEnabled()) {
//				log.debug("接收到客户端消息：connId={}, status={}", connId, conn.getStatusString());
//			}

			//记录数据
			conn.putDate((byte[])e.getMessage());
		} catch (Exception et) {
			log.error(ExceptionUtils.getStackTrace(et));
		}
    }
	
	/**
	 * 建立新连接
	 */
	@Override  
    public void channelOpen(ChannelHandlerContext ctx, ChannelStateEvent e) {
		Channel channel = e.getChannel();

		//日志
		if(log.isDebugEnabled()) {
			InetSocketAddress addrLocal = (InetSocketAddress)channel.getLocalAddress();
			log.debug("新建一个连接：connId={}, port={}, addr={}", ctx.getChannel().getId(), addrLocal.getPort(), channel.getRemoteAddress());
		}
		
		Port port = ConnStartup.CONN_NODE.getRandomPort();
		Connection conn = new Connection(channel, port);
		conn.startup();
		
		//Flash授权验证请求
		if(FlashPolicyHandler.handle(e)) return;
		
		channelIdToConnectin.put(channel.getId(), conn);
    }
	
	@Override  
    public void channelClosed(ChannelHandlerContext ctx, ChannelStateEvent e) {  
		//属性
		int connId = e.getChannel().getId();
		Connection conn = channelIdToConnectin.get(connId);
		
		//日志
		if(log.isDebugEnabled()) {
			log.debug("连接关闭：connId={}, status={}", connId, conn == null ? "" : conn.getStatusString());
		}
		
		//关闭玩家连接
		//Flash的843连接不会记录映射关系 这种情况下无需清理
		if(conn != null) {
			conn.closeDelay();
			channelIdToConnectin.remove(connId);
		}
    }
	
	/**
	 * 有异常发生
	 */
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e) {
		//输出错误日志
		log.error("连接发生异常：connId={}, stackTrack={}", e.getChannel().getId(), ExceptionUtils.getStackTrace(e.getCause()));
	}
}
