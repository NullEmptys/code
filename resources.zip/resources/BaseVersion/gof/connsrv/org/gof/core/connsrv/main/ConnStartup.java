package org.gof.core.connsrv.main;

import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.concurrent.Executors;

import org.gof.core.DistrMethodCache;
import org.gof.core.Node;
import org.gof.core.connsrv.ConnPort;
import org.gof.core.connsrv.ConnService;
import org.gof.core.connsrv.netty.ServerPipelineFactory;
import org.gof.core.support.Distr;
import org.gof.core.support.log.LogCore;
import org.jboss.netty.bootstrap.ServerBootstrap;
import org.jboss.netty.channel.socket.nio.NioServerSocketChannelFactory;

public class ConnStartup {
	public static Node CONN_NODE;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if(args.length == 0) {
			args = new String[] {"0", "tcp://127.0.0.1:9100"};
		}
		
		System.setProperty("logFileName", "conn" + args[0]);
		
		DistrMethodCache.init();
		
		if(args.length < 2) {
			System.out.println(Arrays.toString(args));
			System.out.println("useage: servId nodeAddr");
			return ;
		}
		
		String serverId = args[0];
		String node_name = Distr.NODE_CONNECT_PREFIX + serverId;
		String node_addr = args[1];
		
		
		//启动netty监听
		ServerBootstrap bootstrap = new ServerBootstrap(new NioServerSocketChannelFactory(
															Executors.newCachedThreadPool(),
															Executors.newCachedThreadPool()));
		bootstrap.setPipelineFactory(new ServerPipelineFactory());
		bootstrap.setOption("child.tcpNoDelay", true);
		bootstrap.setOption("child.keepAlive", true);
		bootstrap.bind(new InetSocketAddress(8888));
		
		//创建Node
		Node node = new Node(node_name, node_addr);
		CONN_NODE = node;

//		node.addRemoteNode(Config.NODE_NAME_WORLD0, Config.NODE_ADDR_WORLD0);

		ConnPort port = new ConnPort(serverId);
		port.startup(node);
		
		//开启一个默认服务
		ConnService connService = new ConnService(port);
		connService.startup();
		port.addService(connService);
		
		node.startup();
		
		//启动日志信息
		LogCore.core.info("================================================");
		LogCore.core.info(node_name + " started.");
		LogCore.core.info("Listen:" + node_addr);
		LogCore.core.info("ServerId:" + serverId);
		LogCore.core.info("================================================");
		
		//系统关闭时进行清理
		Runtime.getRuntime().addShutdownHook(new Thread() { 
			public void run() { 
				
			} 
		});
	}

}
