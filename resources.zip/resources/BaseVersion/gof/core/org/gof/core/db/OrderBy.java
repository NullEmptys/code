package org.gof.core.db;

public enum OrderBy {
	ASC,
	DESC
}
