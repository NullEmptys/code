package org.gof.core.dbsrv;

import org.gof.core.Port;
import org.gof.core.CallPoint;
import org.gof.core.support.Distr;
import org.gof.core.support.Param;
import org.gof.core.support.log.LogCore;
import org.gof.core.gen.proxy.ProxyBase;
import org.gof.core.gen.proxy.GenProxyFile;
import org.gof.core.Chunk;
import org.gof.core.Record;
import java.util.List;

@GenProxyFile
public class DBServiceProxy extends ProxyBase {
	private static final String SERV_ID = "dbCommon";
	
	private CallPoint remote;
	private Port localPort;
	
	/**
	 * 私有构造函数
	 * 防止实例被私自创建 必须通过newInstance函数
	 */
	private DBServiceProxy() {}
	
	/**
	 * 获取实例
	 * 大多数情况下可用此函数获取
	 * @param localPort
	 * @return
	 */
	public static DBServiceProxy newInstance() {
		String portId = Distr.getPortId(SERV_ID);
		if(portId == null) {
			LogCore.remote.error("通过servId未能找到查找上级Port: servId={}", SERV_ID);
			return null;
		}
		
		String nodeId = Distr.getNodeId(portId);
		if(nodeId == null) {
			LogCore.remote.error("通过portId未能找到查找上级Node: portId={}", portId);
			return null;
		}
		
		return createInstance(nodeId, portId, SERV_ID);
	}
	
	
	/**
	 * 创建实例
	 * @param localPort
	 * @param node
	 * @param port
	 * @param id
	 * @return
	 */
	private static DBServiceProxy createInstance(String node, String port, Object id) {
		DBServiceProxy inst = new DBServiceProxy();
		inst.localPort = Port.getCurrent();
		inst.remote = new CallPoint(node, port, id);
		
		return inst;
	}
	
	/**
	 * 监听返回值
	 * @param obj
	 * @param methodName
	 * @param context
	 */
	public void listenResult(Object obj, String methodName, Object...context) {
		listenResult(obj, methodName, new Param(context));
	}
	
	/**
	 * 监听返回值
	 * @param obj
	 * @param methodName
	 * @param context
	 */
	public void listenResult(Object obj, String methodName, Param context) {
		localPort.listenResult(obj, methodName, context);
	}
	
	/**
	 * 等待返回值
	 */
	public Param waitForResult() {
		return localPort.waitForResult();
	}
	
	public void countBy(String tableName, Object... params) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:countBy(String, Object[])", new Object[]{ tableName, params });
	}
	
	public void countByQuery(String tableName, String whereAndOther, Object... params) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:countByQuery(String, String, Object[])", new Object[]{ tableName, whereAndOther, params });
	}
	
	public void delete(String tableName, long id) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:delete(String, long)", new Object[]{ tableName, id });
	}
	
	public void execute(boolean needResult, boolean flush, String sql, Object... params) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:execute(boolean, boolean, String, Object[])", new Object[]{ needResult, flush, sql, params });
	}
	
	public void findAll(String tableName) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:findAll(String)", new Object[]{ tableName });
	}
	
	public void findBy(String tableName, Object... params) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:findBy(String, Object[])", new Object[]{ tableName, params });
	}
	
	public void findBy(int firstResult, int maxResults, String tableName, Object... params) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:findBy(int, int, String, Object[])", new Object[]{ firstResult, maxResults, tableName, params });
	}
	
	public void findByQuery(String tableName, List columns, String whereAndOther, Object... params) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:findByQuery(String, List, String, Object[])", new Object[]{ tableName, columns, whereAndOther, params });
	}
	
	public void findByQuery(String tableName, String whereAndOther, Object... params) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:findByQuery(String, String, Object[])", new Object[]{ tableName, whereAndOther, params });
	}
	
	public void findFieldSet() {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:findFieldSet()", new Object[]{  });
	}
	
	public void flush(String tableName) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:flush(String)", new Object[]{ tableName });
	}
	
	public void flush() {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:flush()", new Object[]{  });
	}
	
	public void get(String tableName, long id) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:get(String, long)", new Object[]{ tableName, id });
	}
	
	public void getBy(String tableName, Object... params) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:getBy(String, Object[])", new Object[]{ tableName, params });
	}
	
	public void getByQuery(String tableName, List columns, String whereAndOther, Object... params) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:getByQuery(String, List, String, Object[])", new Object[]{ tableName, columns, whereAndOther, params });
	}
	
	public void getByQuery(String tableName, String whereAndOther, Object... params) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:getByQuery(String, String, Object[])", new Object[]{ tableName, whereAndOther, params });
	}
	
	public void insert(Record record) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:insert(Record)", new Object[]{ record });
	}
	
	public void update(String tableName, long id, Chunk patch, boolean sync) {
		localPort.call(remote, "org.gof.core.dbsrv.DBService:update(String, long, Chunk, boolean)", new Object[]{ tableName, id, patch, sync });
	}
}
