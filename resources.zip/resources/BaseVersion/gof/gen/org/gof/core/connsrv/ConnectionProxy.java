package org.gof.core.connsrv;

import org.gof.core.Port;
import org.gof.core.CallPoint;
import org.gof.core.support.Distr;
import org.gof.core.support.Param;
import org.gof.core.support.log.LogCore;
import org.gof.core.gen.proxy.ProxyBase;
import org.gof.core.gen.proxy.GenProxyFile;
import org.gof.core.Chunk;
import org.gof.core.support.ConnectionStatus;

@GenProxyFile
public class ConnectionProxy extends ProxyBase {
	
	private CallPoint remote;
	private Port localPort;
	
	/**
	 * 私有构造函数
	 * 防止实例被私自创建 必须通过newInstance函数
	 */
	private ConnectionProxy() {}
	
	
	/**
	 * 获取实例
	 * @return
	 */
	public static ConnectionProxy newInstance(CallPoint targetPoint) {
		return createInstance(targetPoint.nodeId, targetPoint.portId, targetPoint.servId);
	}
	
	/**
	 * 获取实例
	 * @return
	 */
	public static ConnectionProxy newInstance(String node, String port, Object id) {
		return createInstance(node, port, id);
	}
	
	/**
	 * 创建实例
	 * @param localPort
	 * @param node
	 * @param port
	 * @param id
	 * @return
	 */
	private static ConnectionProxy createInstance(String node, String port, Object id) {
		ConnectionProxy inst = new ConnectionProxy();
		inst.localPort = Port.getCurrent();
		inst.remote = new CallPoint(node, port, id);
		
		return inst;
	}
	
	/**
	 * 监听返回值
	 * @param obj
	 * @param methodName
	 * @param context
	 */
	public void listenResult(Object obj, String methodName, Object...context) {
		listenResult(obj, methodName, new Param(context));
	}
	
	/**
	 * 监听返回值
	 * @param obj
	 * @param methodName
	 * @param context
	 */
	public void listenResult(Object obj, String methodName, Param context) {
		localPort.listenResult(obj, methodName, context);
	}
	
	/**
	 * 等待返回值
	 */
	public Param waitForResult() {
		return localPort.waitForResult();
	}
	
	public void close() {
		localPort.call(remote, "org.gof.core.connsrv.Connection:close()", new Object[]{  });
	}
	
	public void sendMsg(int msgId, Chunk msgbuf) {
		localPort.call(remote, "org.gof.core.connsrv.Connection:sendMsg(int, Chunk)", new Object[]{ msgId, msgbuf });
	}
	
	public void setStatus(int status) {
		localPort.call(remote, "org.gof.core.connsrv.Connection:setStatus(int)", new Object[]{ status });
	}
	
	public void updateStatus(ConnectionStatus status) {
		localPort.call(remote, "org.gof.core.connsrv.Connection:updateStatus(ConnectionStatus)", new Object[]{ status });
	}
	
	public void updateStatus(String node, String port, long stage) {
		localPort.call(remote, "org.gof.core.connsrv.Connection:updateStatus(String, String, long)", new Object[]{ node, port, stage });
	}
}
