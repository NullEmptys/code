package org.gof.core.dbsrv;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class DBServiceCallback {
	public static final String _result_excute = "_result_excute";
	public static final String _result_syncRecordUpdate = "_result_syncRecordUpdate";
}
