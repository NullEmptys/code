package org.gof.core.dbsrv;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.gof.core.CallReturn;
import org.gof.core.Chunk;
import org.gof.core.Port;
import org.gof.core.PortPulseQueue;
import org.gof.core.Record;
import org.gof.core.Service;
import org.gof.core.db.CachedRecords;
import org.gof.core.db.CachedTables;
import org.gof.core.db.DBConnection;
import org.gof.core.db.DBConsts;
import org.gof.core.db.FieldSet;
import org.gof.core.db.FlushingRecords;
import org.gof.core.db.FlushingTable;
import org.gof.core.db.OrderBy;
import org.gof.core.dbsrv.DBLargeServiceProxy;
import org.gof.core.dbsrv.DBServiceCallback;
import org.gof.core.gen.callback.DistrCallback;
import org.gof.core.gen.proxy.DistrClass;
import org.gof.core.gen.proxy.DistrMethod;
import org.gof.core.support.Config;
import org.gof.core.support.Distr;
import org.gof.core.support.Param;
import org.gof.core.support.SysException;
import org.gof.core.support.TickTimer;
import org.gof.core.support.Time;
import org.gof.core.support.Utils;
import org.gof.core.support.log.LogCore;
import org.slf4j.Logger;

/**
 * 用来处理较块的数据库操作 比如单表查询
 * 新增(Insert)操作由于对实时性要求较高 一般仍由本类来处理
 * 
 * !对于操作消耗较大的的操作，如更新(Update)由DBLargeService来处理
 * !getBy系列函数，执行前会造成同表写缓存的立即刷新，请慎用，尽量在业务层解决。
 * !查询缓存已暂时屏蔽
 */
@DistrClass(
	servId = Distr.SERV_DB_COMMON,
	importClass = {Chunk.class, Record.class, List.class}
)
public class DBService extends Service {
	private static final String SQL_KEY_COUNT = "count(1)";			//数量查询KEY
	private static final String SQL_KEY_ALL = "*";						//全部参数KEY
	
	private final DBConnection dbConn;									//数据库连接
	private final CachedTables cachedRead = new CachedTables();		//数据读取缓存
	private final CachedTables cachedWrite = new CachedTables();		//数据写入缓存
	private final FlushingTable flushing = new FlushingTable();		//写入缓存刷新中的临时缓存
	
	//缓冲同步间隔
	private final TickTimer flushTimer = new TickTimer(Config.DB_CACHED_SYNC_SEC * Time.SEC);
	private boolean flushNowOnce = false;		//立即开始一次缓存刷新
	
	//异步刷新版本号
	private long flushingVersion = 0;
	
	//日志
	private final Logger log = LogCore.db;
	
	public DBService(DBPort port) {
		super(port);
		
		dbConn = new DBConnection(Config.DB_URL, Config.DB_USER, Config.DB_PWD);
		
		this.initFieldSet();
	}
	
	/**
	 * 通过升级包更新数据
	 * 当有缓存时，修改当前缓存，稍后持久化（sync=true时除外，会立即持久化）。
	 * 当无缓存时，立即生效持久化到数据库。
	 * @param tableName
	 * @param id
	 * @param patch
	 * @param sync
	 */
	@DistrMethod
	public void update(String tableName, long id, Chunk patch, boolean sync) {
		//日志
		if(log.isDebugEnabled()) {
			log.debug("接收到更新包:{}({})", tableName, id);
		}
		
		/* 写缓存 */
		CachedRecords write = cachedWrite.getOrCreate(tableName);
		Record w = write.get(id);
		//初始化
		if(w == null) {
			w = Record.newInstance(tableName);
			w.setStatus(DBConsts.RECORD_STATUS_MODIFIED);
			w.set("id", id);
			
			write.put(id, w);
		}
		
		//使修改生效
		w.patchUpdate(patch);
		
		//立即持久化至数据库
		if(sync || Config.DB_CACHED_SYNC_SEC == 0) {
			syncRecord(w);
		}
		
		/* 读缓存 */
		CachedRecords read = cachedRead.getOrCreate(tableName);
		Record r = read.get(id);

		//有缓存 修改当前读缓存
		if(r != null) {
			//使修改生效
			r.patchUpdate(patch);
		}
	}
	
	/**
	 * 新增一条数据
	 * @param tableName
	 * @param chunk
	 * @param cache
	 * @throws SQLException
	 * @throws IOException 
	 */
	@DistrMethod
	public void insert(Record record) throws SQLException, IOException {
		//立即持久化
		syncRecord(record);
	}
	
	/**
	 * 删除
	 * @param tableName
	 * @param id
	 */
	@DistrMethod
	public void delete(String tableName, long id) {
		//模拟一个record 进行删除
		Record record = Record.newInstance(tableName);
		record.setStatus(DBConsts.RECORD_STATUS_DELETED);
		record.set("id", id);
		
		//删除数据
		syncRecord(record);
		
		//删除读缓存
		cachedRead.removeRecord(tableName, id);
		//删除写缓存
		cachedWrite.removeRecord(tableName, id);
	}
	
	@DistrMethod
	public void findFieldSet() {
		port.returns(FieldSet.CACHE);
	}
	
	/**
	 * 获取符合条件的数据数量
	 * @param tableName
	 * @param params
	 */
	@DistrMethod
	public void countBy(String tableName, Object... params) {
		utilCount(tableName, params);
	}
	
	/**
	 * 获取查询的单体数据
	 * 如果有多条符合则返回第一条
	 * 当查询出的结果在缓存中已存在时，返回缓存中的数据。
	 * 当需要缓存结果时，如果缓存已存在，则不更新缓存。
	 * @param tableName
	 * @param params
	 */
	@DistrMethod
	public void countByQuery(String tableName, String whereAndOther, Object... params) {
		utilSqlCount(tableName, whereAndOther, params);
	}
	
	/**
	 * 根据主键获取数据
	 * @param tableName		表名
	 * @param id			主键
	 */
	@DistrMethod
	public void get(String tableName, long id) {
		CachedRecords cached = cachedRead.getOrCreate(tableName);
		Record data = cached.get(id);
		
		//命中缓存 直接返回
		if(data != null) {
			port.returns(data);
			return;
		}
		
		//如果缓存中不存在 再去数据库中取
		utilGet(tableName, "id", id);
	}
	
	/**
	 * 获取符合条件的单体数据
	 * 如果有多条符合则返回第一条
	 * @param tableName
	 * @param params
	 */
	@DistrMethod
	public void getBy(String tableName, Object...params) {
		//如果仅仅是根据ID查询 那么优化下
		if(params.length == 2 && "id".equals(params[0]) && !(params[1] instanceof List)) {
			get(tableName, (long) params[1]);
		} else {
			utilGet(tableName, params);
		}
	}
	
	/**
	 * 获取查询的单体数据
	 * 如果有多条符合则返回第一条
	 * 当查询出的结果在缓存中已存在时，返回缓存中的数据。
	 * 当需要缓存结果时，如果缓存已存在，则不更新缓存。
	 * @param tableName
	 * @param params
	 */
	@DistrMethod
	public void getByQuery(String tableName, String whereAndOther, Object... params) {
		getByQuery(tableName, Utils.ofList("*"), whereAndOther, params);
	}
	
	/**
	 * 获取查询的单体数据
	 * 如果有多条符合则返回第一条
	 * 当查询出的结果在缓存中已存在时，返回缓存中的数据。
	 * 当需要缓存结果时，如果缓存已存在，则不更新缓存。
	 * @param tableName
	 * @param params
	 */
	@DistrMethod
	public void getByQuery(String tableName, List<String> columns, String whereAndOther, Object... params) {
		utilSqlBase(true, tableName, columns, whereAndOther, params);
	}
	
	/**
	 * 获取全部数据集合
	 * 支持排序
	 * @param tableName
	 * @param params
	 */
	@DistrMethod
	public void findAll(String tableName) {
		findBy(tableName);
	}
	
	/**
	 * 获取符合条件的数据集合
	 * 支持排序
	 * @param tableName
	 * @param params
	 */
	@DistrMethod
	public void findBy(String tableName, Object... params) {
		findBy(0, Integer.MAX_VALUE, tableName, params);
	}
	
	/**
	 * 获取符合条件的数据集合
	 * 支持分页，支持排序
	 * @param tableName
	 * @param firstResult
	 * @param maxResults
	 * @param params
	 */
	@DistrMethod
	public void findBy(int firstResult, int maxResults, String tableName, Object... params) {
		utilFind(firstResult, maxResults, tableName, params);
	}
	
	/**
	 * 获取查询条件的数据集合
	 * 当查询出的结果在缓存中已存在时，返回缓存中的数据。
	 * 当需要缓存结果时，如果缓存已存在，则不更新缓存。
	 * @param tableName
	 * @param params
	 */
	@DistrMethod
	public void findByQuery(String tableName, String whereAndOther, Object... params) {
		findByQuery(tableName, Utils.ofList("*"), whereAndOther, params);
	}
	
	/**
	 * 获取查询条件的数据集合
	 * 当查询出的结果在缓存中已存在时，返回缓存中的数据。
	 * 当需要缓存结果时，如果缓存已存在，则不更新缓存。
	 * @param tableName
	 * @param params
	 */
	@DistrMethod
	public void findByQuery(String tableName, List<String> columns, String whereAndOther, Object... params) {
		utilSqlBase(false, tableName, columns, whereAndOther, params);
	}
	
	/**
	 * 执行SQL语句，支持?占位符
	 * 一般用来执行update或insert语句
	 * 
	 * @param sql
	 * @param params
	 */
	private void executeSync(String sql, Object... params) {
		try(PreparedStatement ps = dbConn.prepareStatement(sql)) {
			for(int i = 0; i < params.length; i++) {
				ps.setObject(i + 1, params[i]);
			}
			
			//执行
			ps.executeUpdate();
		} catch (Exception e) {
			throw new SysException(e);
		}
	}
	
	/**
	 * 会委托DBLargeService执行SQL语句，支持?占位符
	 * 除非特殊情况下，否则不建议调用本函数
	 * 由于无法判断此操作的影响返回，flush=true时会刷新全部写缓存
	 * 如果调用者可以判断影响返回，可以设置flush=false，通过预先调用flush(tableName)的方式来降低影响
	 * @param needResult 调用方是否需要收到执行完毕的消息
	 * @param flush 是否需要刷新全部缓存
	 * @param sql
	 * @param params
	 */
	@DistrMethod
	public void execute(boolean needResult, boolean flush, String sql, Object... params) {
		//刷新缓存
		if(flush) {
			LogCore.db.info("调用了execute函数，触发写缓存刷新操作。");
			flush();
		}
		
		//委托执行请求
		DBLargeServiceProxy prx = DBLargeServiceProxy.newInstance();
		prx.executeUpdate(needResult, sql, params);
		
		//监控返回值
		if(needResult) {
			long rid = port.createReturnAsync();
			prx.listenResult(this, DBServiceCallback._result_excute, "rid", rid);
		}
	}
	
	@DistrCallback
	public void _result_excute(Param results, Param context) {
		long rid = context.get("rid");
		Object result = results.get();
		
		port.returnsAsync(rid, result);
	}
	
	/**
	 * 刷新缓存至数据库
	 */
	@DistrMethod
	public void flush() {
		//缓存间隔时间为0时 就不用定时同步了
		//因为更新时已经做了判断 会立即持久化至数据库
		if(Config.DB_CACHED_SYNC_SEC == 0) {
			return;
		}
		
		//遍历数据 找到需要刷新的缓存
		int count = 0;
		for(String tableName : cachedWrite.getTableNames()) {
			int c = flush(tableName);
			//增加刷新数据量
			count += c;
		}
		
		//记录日志
		//关闭时自动调用flushNowOnce时会报错 所以忽略这种情况
		if(log.isInfoEnabled() && !flushNowOnce && count > 0) {
			log.info("进行缓存同步，同步数据量={}。", count);
		}
	}
	
	/**
	 * 刷新单张表的缓存至数据库
	 * @param tableName
	 */
	@DistrMethod
	public int flush(String tableName) {
		CachedRecords cached = cachedWrite.getOrCreate(tableName);
		
		//刷新数据量
		int count = 0;
		for(Record record : cached.values()) {
			//不是脏数据 忽略
			if(!record.isDirty()) continue;
			
			port.addQueue(new PortPulseQueue(record) {
				public void execute(Port port) {
					Record r = param.get();
					
					//同步
					DBService simplDB = port.getService(Distr.SERV_DB_COMMON);
					simplDB.syncRecord(r);
				}
			});
			
			//记录修改数量
			++count;
		}
		
		return count;
	}
	
	/**
	 * 查询返回符合结果数量的基础函数
	 * @param tableName
	 * @param params
	 * @return
	 */
	private void utilCount(String tableName, Object... params) {
		List<Object> settings = Utils.ofList(params);
		
		//查询参数
		Map<String, Object> paramsFilter = new LinkedHashMap<>();		//过滤条件
		
		//处理成对参数
		int len = settings.size();
		for(int i = 0; i < len; i += 2) {
			String key = (String)settings.get(i);
			Object val = settings.get(i + 1);
			
			//参数 排序规则忽略
			if(val instanceof OrderBy) {
				//忽略
			} else {	//参数 过滤条件
				paramsFilter.put(key, val);
			}
		}

		//最终查询SQL
		String sql = Utils.createStr("select {} from {} {}", SQL_KEY_COUNT, tableName, utilBaseGenSqlWhere(paramsFilter));
		
		//刷新本表的缓存
		flush(tableName);
		
		//创建异步返回
		CallReturn callReturn = port.getCall().createCallReturn();
		
		//委托查询
		DBLargeServiceProxy prx = DBLargeServiceProxy.newInstance();
		prx.countAndReturn(callReturn, sql, paramsFilter.values().toArray());
	}
	
	/**
	 * SQL结果数量查询基础函数
	 * @param sql
	 * @param whereAndOther
	 * @param params
	 * @return
	 */
	private void utilSqlCount(String tableName, String whereAndOther, Object...params) {
		List<Object> settings = Utils.ofList(params);
		
		//拼接最终SQL
		String sql = Utils.createStr("select {} from {} {}", SQL_KEY_COUNT, tableName, whereAndOther);

		//刷新本表的缓存
		flush(tableName);
		
		//创建异步返回
		CallReturn callReturn = port.getCall().createCallReturn();
		
		//委托查询
		DBLargeServiceProxy prx = DBLargeServiceProxy.newInstance();
		prx.countAndReturn(callReturn, sql, settings.toArray());
	}
	
	/**
	 * 查询返回数据集合的基础函数
	 * @param tableName
	 * @param firstResult
	 * @param maxResults
	 * @param params
	 * @return
	 */
	private void utilFind(int firstResult, int maxResults, String tableName, Object... params) {
		utilBase(false, firstResult, maxResults, tableName, params);
	}
	
	/**
	 * 查询返回单体数据的基础函数
	 * @param tableName
	 * @param servId
	 * @return
	 */
	private void utilGet(String tableName, Object... params) {
		utilBase(true, 0, 1, tableName, params);
	}
	
	/**
	 * 查询信息基础函数
	 * 当查询出的结果在缓存中已存在时，返回缓存中的数据。
	 * 当需要缓存结果时，如果缓存已存在，则不更新缓存。
	 * @param flush 是否需要先刷新缓存
	 * @param single 是否返回单一结果
	 * @param tableName
	 * @param firstResult
	 * @param maxResults
	 * @param params
	 * @return
	 */
	private void utilBase(boolean single, int firstResult, int maxResults, String tableName, Object... params) {
		List<Object> settings = Utils.ofList(params);
		
		//查询参数
		Map<String, Object> paramsFilter = new LinkedHashMap<>();		//过滤条件
		Map<String, OrderBy> paramsOrder = new LinkedHashMap<>();		//排序规则
//		boolean paramCache = false;									//缓存数据
//		
//		//处理独立参数
//		for(Iterator<Object> iter = settings.iterator(); iter.hasNext();) {
//			Object p = iter.next();
//			//参数 开启缓存
//			if(p instanceof Cache) {
//				paramCache = (p == Cache.TRUE);
//				iter.remove();
//			}
//		}
		
		//处理成对参数
		int len = settings.size();
		for(int i = 0; i < len; i += 2) {
			String key = (String)settings.get(i);
			Object val = settings.get(i + 1);
			
			//参数 排序规则
			if(val instanceof OrderBy) {
				paramsOrder.put(key, (OrderBy) val);
			} else {	//参数 过滤条件
				paramsFilter.put(key, val);
			}
		}
		
		//根据参数拼装出参数
		String sql = utilBaseGenSqlFrom(tableName) 
				   + utilBaseGenSqlWhere(paramsFilter)
				   + utilBaseGenSqlOrderBy(paramsOrder)
				   + utilBaseGenSqlLimit(firstResult, maxResults);
		
		//刷新本表的缓存
		flush(tableName);
		
		//创建异步返回
		CallReturn callReturn = port.getCall().createCallReturn();
		
		//委托查询
		DBLargeServiceProxy prx = DBLargeServiceProxy.newInstance();
		prx.findAndReturn(callReturn, single, true, sql, paramsFilter.values().toArray());
	}
	
	/**
	 * 多表查询或返回部分值时 无法缓存结果
	 * @param sql
	 * @param params
	 * @return
	 */
	private void utilSqlBase(boolean single, String tableName, List<String> columns, String whereAndOther, Object...params) {
		List<Object> settings = Utils.ofList(params);
		
		//查询参数
//		boolean paramCache = false;									//缓存数据
//		
//		//处理独立参数
//		for(Iterator<Object> iter = settings.iterator(); iter.hasNext();) {
//			Object p = iter.next();
//			//参数 开启缓存
//			if(p instanceof Cache) {
//				paramCache = (p == Cache.TRUE);
//				iter.remove();
//			}
//		}
		
		/* 字段修饰 */		
		//是否为全表查询
		boolean isFullQuery = false;
		if(columns.size() == 1 && SQL_KEY_ALL.equals(columns.get(0))) {
			isFullQuery = true;
		}
		
		//拼接属性SQL
		StringBuilder columnStr = new StringBuilder();
		
		//特殊字段 单独处理
		if(isFullQuery) {
			String c = columns.get(0);
			columnStr.append(c);
			
		//常规字段
		} else {
			for(int i = 0; i < columns.size(); i++) {
				String c = columns.get(i);
				
				//多个参数分割符
				if(i > 0) {
					columnStr.append(",");
				}

				//具体参数
				columnStr.append("`").append(c).append("`");
			}
		}
		
		//拼接最终SQL
		String sql = Utils.createStr("select {} from {} {}", columnStr.toString(), tableName, whereAndOther);
		
		//刷新本表的缓存
		flush(tableName);
		
		//创建异步返回
		CallReturn callReturn = port.getCall().createCallReturn();
		
		//委托查询
		DBLargeServiceProxy prx = DBLargeServiceProxy.newInstance();
		prx.findAndReturn(callReturn, single, isFullQuery, sql, settings.toArray());
	}
	
	/**
	 * 查询信息基础函数工具函数
	 * 用来生成from语句
	 * @param tableName
	 * @return
	 */
	private String utilBaseGenSqlFrom(String tableName) {
		return new StringBuilder("SELECT * FROM ")
							.append("`")
							.append(tableName)
							.append("`")
							.append(" t")
							.toString();
	}
	
	/**
	 * 查询信息基础函数工具函数
	 * 用来生成where语句
	 * @param tableName
	 * @return
	 */
	private String utilBaseGenSqlWhere(Map<String, Object> paramsFilter) {
		//SQL语句
		StringBuilder sqlWhere = new StringBuilder();
		//无参数 立即返回
		if(paramsFilter.isEmpty()) return sqlWhere.toString();
		
		//将参数拼装为?占位符的形式
		for(Entry<String, Object> e : paramsFilter.entrySet()) {
			String key = e.getKey();
			Object val = e.getValue();
			
			//需要增加and分割
			if(sqlWhere.length() > 0) sqlWhere.append(" AND ");
			
			//属性名
			sqlWhere.append("`").append(key).append("`");
			
			//属性值 如果是List则判定为in语句
			if(val instanceof List) {
				List<?> vals = (List<?>) val;
				//拼装in
				sqlWhere.append(" in ").append("(");
				for(int i = 0; i < vals.size(); i++) {
					if(i > 0) sqlWhere.append(", ");
					sqlWhere.append("?");
				}
				sqlWhere.append(")");
			} else {		//默认为相等
				sqlWhere.append(" = ").append("?");
			}
		}
		
		//在头部插入where语句
		sqlWhere.insert(0, " WHERE ");
		
		return sqlWhere.toString();
	}
	
	/**
	 * 查询信息基础函数工具函数
	 * 用来生成orderBy语句
	 * @param tableName
	 * @return
	 */
	private String utilBaseGenSqlOrderBy(Map<String, OrderBy> params) {
		//SQL语句
		StringBuilder orderWhere = new StringBuilder();
		//无参数 立即返回
		if(params.isEmpty()) return orderWhere.toString();
		
		//将参数拼装
		for(Entry<String, OrderBy> e : params.entrySet()) {
			//需要增加and分割
			if(orderWhere.length() > 0) orderWhere.append(", ");
			
			orderWhere.append("`").append(e.getKey()).append("`").append(" ").append(e.getValue().name());
		}
		
		//在头部插入where语句
		orderWhere.insert(0, " ORDER BY ");
		
		return orderWhere.toString();
	}
	
	/**
	 * 查询信息基础函数工具函数
	 * 用来生成limit语句
	 * @param tableName
	 * @return
	 */
	private String utilBaseGenSqlLimit(int firstResult, int maxResults) {
		//SQL语句
		StringBuilder limitWhere = new StringBuilder();
		
		//默认值 无需limit语句
		if(firstResult == 0 && maxResults == Integer.MAX_VALUE) {
			return limitWhere.toString();
		}
		
		//拼装SQL
		limitWhere.append(" limit ").append(firstResult).append(", ").append(maxResults);
		
		return limitWhere.toString();
	}
	
	/**
	 * 同步
	 * @param record
	 */
	private void syncRecord(Record record) {
		//没有改动过
		if(!record.isDirty()) {
			return;
		}

		//根据状态进行不同处理
		switch(record.getStatus()) {
			//新增
			case DBConsts.RECORD_STATUS_NEW: {
				_syncRecordInsert(record);
				break;
			}
			//修改
			case DBConsts.RECORD_STATUS_MODIFIED: {
				_syncRecordUpdate(record);
				break;
			}
			//删除
			case DBConsts.RECORD_STATUS_DELETED: {
				_syncRecordDelete(record);
				break;
			}
		}
	}
	
	/**
	 * 将record新增数据持久化到数据库
	 * @param record
	 */
	private void _syncRecordInsert(Record record) {
		//状态错误
		if(!record.isNew()) return;
		
		//执行SQL语句
		String sql = "INSERT INTO {}({}) VALUES({})";
		
		//填充语句部分<sqlInto: [属性列], sqlValues, [占位符], params: [参数]>
		Map<String, Object> setSqlMap = syncRecordInsertValuesGen(record);
		String sqlInto = (String) setSqlMap.get("sqlInto");
		String sqlValues = (String) setSqlMap.get("sqlValues");
		Object[] params = (Object[]) setSqlMap.get("params");
		
		//最终SQL
		sql = Utils.createStr(sql, record.getTableName(), sqlInto, sqlValues);
		
		//执行
		executeSync(sql, params);
		
		//重置状态
		record.resetStatus();
	}
	
	/**
	 * 将record被删除数据持久化到数据库
	 * @param record
	 */
	private void _syncRecordDelete(Record record) {
		//状态错误
		if(!record.isDeleted()) return;
		
		//执行SQL语句
		String sql = Utils.createStr("DELETE FROM {} WHERE id=?", record.getTableName());
		
		//执行
		executeSync(sql, record.get("id"));
	}
	
	/**
	 * 将record更新数据持久化到数据库
	 * @param record
	 */
	private void _syncRecordUpdate(Record record) {
		//状态错误
		if(!record.isModified()) return;
		
		//主键
		long id = record.get("id");
		
		//1.1 拼写SQL语句
		String sql = "UPDATE {} SET {} WHERE id = {}";
		
		//1.2 SET语句部分
		Map<String, Object> sqlSetMap = syncRecordUpdateSetGen(record);
		String sqlSet = (String) sqlSetMap.get("sql");
		Object[] params = (Object[]) sqlSetMap.get("params");
		
		//1.3 最终SQL
		sql = Utils.createStr(sql, record.getTableName(), sqlSet, id);
		
		//执行
		long version = ++flushingVersion;
		DBLargeServiceProxy prx = DBLargeServiceProxy.newInstance();
		prx.executeUpdate(true, sql, params);
		prx.listenResult(this, DBServiceCallback._result_syncRecordUpdate, "version", version, "talbeName", record.getTableName(), "id", id);
		
		/* 将缓存数据移入刷新中的临时缓存 */
		//清除写缓存
		CachedRecords write = cachedWrite.getOrCreate(record.getTableName());
		if(write != null) {
			write.remove(id);
		}
		
		//移入刷新临时缓存
		FlushingRecords flush = flushing.getOrCreate(record.getTableName());
		flush.put(id, version, record);
	}
	
	@DistrCallback
	public void _result_syncRecordUpdate(Param results, Param context) {
		long version = context.get("version");
		String tableName = context.get("tableName");
		long id = context.get("id");
		
		//删除刷新临时缓存
		FlushingRecords flush = flushing.getOrCreate(tableName);
		flush.remove(id, version);
	}
	
	/**
	 * 将record新增数据持久化到数据库 占位语句生成
	 * @param record
	 * @return <sqlInto: [属性列], sqlValues, [占位符], params: [参数]>
	 */
	private Map<String, Object> syncRecordInsertValuesGen(Record record) {
		StringBuilder sqlInto = new StringBuilder();
		StringBuilder sqlValues = new StringBuilder();
		List<Object> paramList = new ArrayList<>();
		
		//信息定义
		FieldSet fieldSet = record.getFieldSet();
		
		//拼写SQL
		for(String name : fieldSet.getFieldNames()) {
			//连接多个时 需要加入分隔符
			if(sqlInto.length() > 0) {
				sqlInto.append(", ");
				sqlValues.append(", ");
			}
			
			//占位符
			sqlInto.append("`").append(name).append("`");
			sqlValues.append("?");
			
			//实际值
			paramList.add(record.get(name));
		}
		
		//参数拼装备数组 便于之后的操作
		Object[] params = new Object[paramList.size()];
		paramList.toArray(params);
		
		return Utils.ofMap("sqlInto", sqlInto.toString(), "sqlValues", sqlValues.toString(), "params", params);
	}
	
	/**
	 * 将record更新数据持久化到数据库 set语句生成
	 * @param record
	 * @return {sql: sql语句, params: [参数1, 参数2]}
	 */
	private Map<String, Object> syncRecordUpdateSetGen(Record record) {
		StringBuilder sql = new StringBuilder();
		List<Object> paramList = new ArrayList<>();
		
		//拼写SQL
		for(String name : record.getFieldModified()) {
			//分隔符
			if(sql.length() > 0) sql.append(", ");
			//占位符
			sql.append("`").append(name).append("`= ?");
			//实际值
			paramList.add(record.get(name));
		}
		
		//参数拼装备数组 便于之后的操作
		Object[] params = new Object[paramList.size()];
		paramList.toArray(params);
		
		return Utils.ofMap("sql", sql.toString(), "params", params);
	}
	
	/**
	 * 初始化FieldSet
	 */
	private void initFieldSet() {
		try {
			ResultSet rs = dbConn.createStatement().executeQuery("select TABLE_NAME from information_schema.tables where table_schema = '" + Config.DB_SCHEMA + "'");
			
			List<String> tableNames = new ArrayList<>();
			while(rs.next()) {
				String tableName = rs.getString("TABLE_NAME");
				tableNames.add(tableName);
			}
			
			for(String n : tableNames) {
				this.initTable(n);
			}
			
		} catch (Exception e) {
			throw new SysException(e);
		}
	}
	
	/**
	 * 初始化FieldSet
	 * @param tableName
	 * @throws SQLException
	 */
	private void initTable(String tableName) throws SQLException {
		//缓存FieldSet
		ResultSet rs = dbConn.createStatement().executeQuery("SELECT * FROM " + tableName + " WHERE 0 = 1");
		
		FieldSet fs = new FieldSet(rs.getMetaData());
		FieldSet.put(tableName, fs);
	}
	
	/**
	 * 立即开始一次缓存刷新
	 */
	public void flushNow() {
		flushNowOnce = true;
	}

	@Override
	public Object getId() {
		return Distr.SERV_DB_COMMON;
	}
	
	@Override
	public void pulseOverride() {
		//定时刷新缓存数据至数据库
		if(flushTimer.isPeriod(Port.getTime()) || flushNowOnce) {
			flush();
			
			//还原刷新标示
			if(flushNowOnce) flushNowOnce = false;
		}
	}
}
