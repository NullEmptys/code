package org.gof.demo.worldsrv.support;

import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.support.enumKey.PropKey;

/**
 * 属性计算，只供PropKey中枚举的字段使用
 */
public class PropCalc extends PropCalcBase<PropKey, Integer> {
	public PropCalc() {
		
	}
	
	public PropCalc(String json) {
		super(json);
	}
	
	@Override
	protected PropKey toKey(String key) {
		return PropKey.valueOf(key);
	}
	
	@Override
	protected Integer toValue(Object value) {
		return Utils.intValue(value.toString());
	}
}
