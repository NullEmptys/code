package org.gof.demo.worldsrv.entity;

import org.gof.core.gen.entity.Entity;
import org.gof.core.gen.entity.Column;

/**
 * 玩家属性加成类
 * 计算各个功能对玩家属性加成时，会自动遍历这个类的各个属性列进行累加。
 * 必须使用PropCalcBase的子类才生成下列属性的值
 * 长度统一为512 默认值是{}
 */
@Entity(entityName="HumanPropPlus", tableName="zs_human_propplus")
public enum EntityHumanPropPlus {
	@Column(type=String.class, comment="等级", length = 512, defaults = "{}")
	level,
	
	@Column(type = String.class, comment="测试", length = 512, defaults = "{}")
	debug,
	;
}