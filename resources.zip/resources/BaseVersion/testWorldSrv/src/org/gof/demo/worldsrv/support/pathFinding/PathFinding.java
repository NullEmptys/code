package org.gof.demo.worldsrv.support.pathFinding;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.gof.core.support.SysException;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.config.ConfStage;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.Vector2;

/**
 * 寻路核心类
 *
 */
public class PathFinding {
	// nav文件所在目录及其后缀
	private static String xmlDir = PathFinding.class.getResource("/").getPath() + "META-INF/stageConfig/config/";
	private static String navDir = PathFinding.class.getResource("/").getPath() + "META-INF/stageConfig/mesh/";
	private static String navSuffix = ".nav";
	private static String xmlSuffix = ".xml";
	
	/**
	 * 加载寻路用到的C++动态库recast.dll
	 * 初始化加载所有数据
	 */
	static {
		//TODO 别忘了关 注释了下面1行
//		System.loadLibrary("recast");
		//checkFilesExist();
		init();
	}
	
	/**
	 * 检查地图的xml和nav是否都存在
	 */
	private static void checkFilesExist() {
		Collection<ConfStage> confList = ConfStage.findAll();
		List<ConfStage> xmlLost = new ArrayList<>();
		List<ConfStage> navLost = new ArrayList<>();
		for(ConfStage conf : confList) {
			int sn = conf.sn;
			//判断xml文件和nav文件是否都存在，如果不存在则直接抛出异常
			File xmlFile = new File(xmlDir + sn + xmlSuffix);
			File navFile = new File(navDir + sn + navSuffix);
			if(!xmlFile.exists()) {
				xmlLost.add(conf);
			}
			if(!navFile.exists()) {
				navLost.add(conf);
			}
		}
		
		if(!xmlLost.isEmpty()) {
			System.out.println("+++++xmlLost+++++以下地图缺失xml文件+++++xmlLost+++++");
			for(ConfStage conf : xmlLost) {
				System.out.println(conf.name + " " + conf.sn);
			}
		}
		if(!navLost.isEmpty()) {
			System.out.println("+++++navLost+++++以下地图缺失nav文件+++++navLost+++++");
			for(ConfStage conf : navLost) {
				System.out.println(conf.name + " " + conf.sn);
			}
		}
		if(!xmlLost.isEmpty() || !navLost.isEmpty()) {
			throw new SysException(Utils.createStr("有地图的xml或者nav文件缺失，无法启动！！！！！"));
		}
	}
	
	/**
	 * 遍历nav导航网格数据所在文件夹，初始化加载所有地图导航数据
	 */
	private static void init() {
		// 遍历nav文件所在目录
		File dir = new File(navDir);
		if(!dir.isDirectory())	return;
		
		File[] files = dir.listFiles();
		for(File f : files) {
			// 过滤不是nav文件
			String fileName = f.getName();
			if(!fileName.endsWith(navSuffix)) continue;
			
			int stageSn = Utils.intValue(fileName.replace(navSuffix, ""));
			
			loadNavData(stageSn, f.getAbsolutePath());
		}
	}
	
	/**
	 * 初始化并加载nav数据
	 * @param navPath
	 */
	private static native void loadNavData(int stageSn, String navPath);
	
	/**
	 * 根据起点终点坐标找到路径
	 * @param startPos
	 * @param endPos
	 * @return
	 */
	public static List<Vector2> findPaths(int stageSn, Vector2 startPos, Vector2 endPos) {
		return findPaths(stageSn, startPos, endPos, PathFindingFlagKey.init);
	}
	
	/**
	 * 根据起点，终点，掩码寻路，返回Vector2路径列表
	 * @param startPos
	 * @param endPos
	 * @param flag
	 * @return
	 */
	public static List<Vector2> findPaths(int stageSn, Vector2 startPos, Vector2 endPos, int flag) {
		// 转换坐标为float[]
//		float[] start = startPos.toFloat3();
//		float[] end = endPos.toFloat3();
//		
//		// 寻路结果
//		float[] paths = findPath(stageSn, start, end, flag);
//		int len = paths.length;
//		
//		// 转成需要的Vector2
//		List<Vector2> result = new ArrayList<>();
//		for(int i=0; i<len; i+=3) {
//			Vector2 point = new Vector2();
//			point.x = paths[i];
//			point.y = paths[i+2];
//			
//			result.add(point);
//		}
//		
//		return result;
		//TODO 先去DLL 直接返回
		List<Vector2> result = new ArrayList<>();
		result.add(startPos);
		result.add(endPos);
		return result;
	}
	
	/**
	 * 根据起点，终点，掩码寻路
	 * @param startPos
	 * @param endPos
	 * @param flag
	 * @return
	 */
	private static native float[] findPath(int stageSn, float[] startPos, float[] endPos, int flag);
	
	/**
	 * 判断坐标是否在阻挡区域内
	 * @param pos
	 * @return
	 * 	@author Lufeng
	 * @date 2013-11-1
	 */
	public static boolean isPosInBlock(int stageSn, Vector2 pos){
		//TODO 不使用DLL 先关闭
		return false;
//		return isPosInBlock(stageSn, new float[]{(float)pos.x, 0, (float)pos.y});
	}
	
	/**
	 * 判断坐标是否在阻挡区域内
	 * @param pos
	 * @return
	 */
	private static native boolean isPosInBlock(int stageSn, float[] pos);
	
	/**
	 * 检测起点到终点是否有阻挡，有则返回阻挡坐标，无则返回终点坐标
	 * @param startPos
	 * @param endPos
	 * @return
	 */
	public static Vector2 raycast(int stageSn, Vector2 startPos, Vector2 endPos) {
		return raycast(stageSn, startPos, endPos, PathFindingFlagKey.init);
	}
	
	/**
	 * 检测起点到终点是否有阻挡，有则返回阻挡坐标，无则返回终点坐标
	 * @param startPos
	 * @param endPos
	 * @param flag
	 * @return
	 */
	public static Vector2 raycast(int stageSn, Vector2 startPos, Vector2 endPos, int flag) {
		 //转换坐标为float[]
//		float[] start = startPos.toFloat3();
//		float[] end = endPos.toFloat3();
//		
//		// 检测结果
//		float[] paths = raycast(stageSn, start, end, flag);
//		
//		// 转成需要的Vector2
//		Vector2 result = new Vector2(paths[0], paths[2]);
//		
//		return result;
		
		//TODO 先去DLL 直接返回
		return endPos;
	}
	
	/**
	 * 检测起点到终点是否有阻挡，有则返回阻挡坐标，无则返回终点坐标
	 * @param startPos
	 * @param endPos
	 * @param flag
	 * @return
	 */
	private static native float[] raycast(int stageSn, float[] startPos, float[] endPos, int flag);
	
	/**
	 * 判断两个点是否能到达，判断标准为recase找到的终点与给定终点距离小于0.1
	 * @param stageSn
	 * @param startPos
	 * @param endPos
	 * @param flag
	 * @return
	 */
	public static boolean canReach(int stageSn, Vector2 startPos, Vector2 endPos, int flag) {
		//TODO 关闭了别忘了开
//		List<Vector2> paths = findPaths(stageSn, startPos, endPos, flag);
//		if(paths.isEmpty()) return false;
//		Vector2 pathEnd = paths.get(paths.size() - 1);
//		if(pathEnd.distance(endPos) <= 0.1) return true;
//		
//		return false;
		return true;
	}
}
