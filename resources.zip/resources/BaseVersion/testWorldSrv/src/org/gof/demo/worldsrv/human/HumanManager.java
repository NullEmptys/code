package org.gof.demo.worldsrv.human;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.gof.core.Port;
import org.gof.core.Record;
import org.gof.core.dbsrv.DBServiceProxy;
import org.gof.core.gen.callback.DistrCallback;
import org.gof.core.support.ManagerBase;
import org.gof.core.support.Param;
import org.gof.core.support.SysException;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.config.ConfGrow;
import org.gof.demo.worldsrv.config.ConfPropConversion;
import org.gof.demo.worldsrv.config.ConfStage;
import org.gof.demo.worldsrv.entity.EntityHumanPropPlus;
import org.gof.demo.worldsrv.entity.Human;
import org.gof.demo.worldsrv.entity.HumanPropPlus;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.DHuman;
import org.gof.demo.worldsrv.msg.Msg.DProp;
import org.gof.demo.worldsrv.stage.StageGlobalServiceProxy;
import org.gof.demo.worldsrv.stage.StageObject;
import org.gof.demo.worldsrv.stage.StagePort;
import org.gof.demo.worldsrv.support.LoadHumanDataUtils;
import org.gof.demo.worldsrv.support.PropCalc;
import org.gof.demo.worldsrv.support.PropCalcCommon;
import org.gof.demo.worldsrv.support.Vector2;
import org.gof.demo.worldsrv.support.enumKey.PropKey;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;
import org.gof.demo.worldsrv.support.observer.Listener;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;


public class HumanManager extends ManagerBase {
	
	//玩家初始主地图
	public static int stageInitSn = 10000;
	
	public static final int ONLINE_CHANGE_INTERVAL_SEC = 10;	//在线时间心跳间隔
	
	/**
	 * 获取实例
	 * @return
	 */
	public static HumanManager getInstance() {
		return getInstance(HumanManager.class);
	}
	
	/**
	 * 创建玩家
	 * @param account
	 * @param name
	 * @param profession
	 * @param sex
	 * @return
	 */
	public Human create(long id, int serverId, String account, String name, int profession, int sex) {
		
		//从配置中获得地图
		ConfStage conf = ConfStage.get(stageInitSn);
		//TODO 坐标回头扔配置
		List<?> temp = Utils.ofList(stageInitSn, stageInitSn, 100, 100, conf.type);
		List<?> stageInfo = Utils.ofList(temp);
		//初始化玩家信息
		Human human = new Human();
		human.setId(id);
		human.setServerId(serverId);
		human.setAccount(account);
		human.setName(name);
		human.setProfession(profession);
		human.setSex(sex);
		human.setLevel(1);
		
		human.setSpeed(1);

		
		//cur与max要相等 并且不能为零
		human.setHpCur(1);
		human.setHpMax(1);
		human.setMpCur(1);
		human.setMpMax(1);
		
		//设置地图信息
		human.setStageHistory(JSON.toJSONString(stageInfo));
		
		//持久化
		human.persist();
		
		/* 玩家属性加成 */
		//等级属性加成
		PropCalc levelPropPlus = getLevelProp(human.getProfession(), 1);
		
		HumanPropPlus pp = new HumanPropPlus();
		pp.setId(human.getId());
		pp.setLevel(levelPropPlus.toJSONStr());
		pp.persist();
		

		
		return human;
	}
	
	/**
	 * 获取指定职业 指定等级下的玩家属性
	 * @param profession
	 * @param level
	 * @return
	 */
	public PropCalc getLevelProp(int profession, int level) {
		//配置信息
		List<ConfGrow> confs = ConfGrow.findBy("profession", profession);
		
		//重新计算基础属性
		PropCalc prop = new PropCalc();
		for(ConfGrow conf : confs) {
			prop.plus(PropKey.valueOf(conf.prop), level * conf.factor + conf.base);
		}
		
		return prop;
	}
	
	/**
	 * 玩家登录游戏后 加载玩家的数据
	 */
	public void loadData(HumanObject humanObj) {
		//获取当前请求编号
		long pid = Port.getCurrent().createReturnAsync();
		humanObj.loadingPID = pid;
		
		//先将human主数据加载好
		DBServiceProxy prx = DBServiceProxy.newInstance();
		prx.get(Human.tableName, humanObj.id);
		prx.listenResult(this, HumanManagerCallback._result_loadHumanDataMain, "humanObj", humanObj);
	}
	
	@DistrCallback
	public void _result_loadHumanDataMain(Param results, Param context) {
		//玩家
		HumanObject humanObj = context.get("humanObj");
		HumanDataPersistance data = humanObj.dataPers;
		
		//处理返回数据
		data.human = new Human((Record)results.get());
		
		//发布事件 让其他各个模块开始加载数据
		Event.fire(EventKey.HUMAN_DATA_LOAD_BEGIN, humanObj);
	}
	
	/**
	 * 玩家数据加载完毕后 登录游戏
	 * @param humanObj
	 */
	private void login(HumanObject humanObj) {
		//注册到地图
		StageObject stageObj = humanObj.stageObj;
		
		//获取玩家在该地图的历史坐标
		Vector2 vector = humanObj.getStagePos(stageObj.id);
		
		//没找到历史坐标或者是死亡状态，打回出生点
		if((vector.x == -1 && vector.y == -1) || humanObj.isDie()) {
			// 常规地图位置
			if(humanObj.posNow.x == -1 && humanObj.posNow.y == -1) {
				//TODO 坐标回头扔配置
				Vector2 posNow = new Vector2(100, 100);
				humanObj.posNow = posNow;
			}
		} else {
			//历史路径
			humanObj.posNow = vector;
		}
		
		//将玩家注册进地图 暂不显示
		humanObj.stageRegister(stageObj);
				
		/* 初始化玩家信息 */
		Human human = humanObj.dataPers.human;
		
		//计算人物属性
		propCalc(humanObj);
		
		humanObj.name = human.getName();
		
		//刷新进游戏，如果人物死亡，设为满血复活
		if(humanObj.isDie()) {
			human.setHpCur(human.getHpMax());
		}
		
		/* 发送玩家登录时间及修改玩家登录时间 */
		//当前时间
		long timeNow = Port.getTime();
		//上次最后登录时间
		long timeLast = human.getTimeLogin();
		
		//设置登陆状态
		if(Utils.isSameDay(timeLast, timeNow)) {
			humanObj.loginStageState = 1;
		} else {
			humanObj.loginStageState = 2;
		}
		
		//更新玩家登录时间
		human.setTimeLogin(timeNow);
		Event.fire(EventKey.HUMAN_LOGIN, "humanObj", humanObj, "timeLoginLast", timeLast);
		
		//添加玩家全局信息
		StagePort stagePort = stageObj.getPort();
		HumanGlobalInfo hs = new HumanGlobalInfo();
		hs.id = humanObj.id;
		hs.account = human.getAccount();
		hs.name = human.getName();
		hs.nodeId = stagePort.getNodeId();
		hs.portId = stagePort.getId();
		hs.stageId = stageObj.id;
		hs.stageName = stageObj.name;
		hs.level = human.getLevel();
		hs.sex = human.getSex();
		hs.profession = human.getProfession();
		hs.connPoint = humanObj.connPoint;
		
		HumanGlobalServiceProxy prxShs = HumanGlobalServiceProxy.newInstance();
		prxShs.register(hs);
		
		
		StageGlobalServiceProxy proxy = StageGlobalServiceProxy.newInstance();
		//玩家地图人数+1
		proxy.stageHumanNumAdd(humanObj.stageObj.id);
		
	}
	
	
	
	@Listener(EventKey.HUMAN_LOGIN)
	public void readyToSendInitataToClient(Param param) {
		HumanObject humanObj = param.get("humanObj");
		
		//发送初始化消息给客户端
		sendInitDataToClient(humanObj);
	}
	
	/**
	 * 玩家登录游戏后 加载玩家的数据
	 * 对于简单的符合规则的数据 可以统一再这里加载
	 * @param humanObj
	 */
	@Listener(EventKey.HUMAN_DATA_LOAD_BEGIN)
	public void loadHumanDataInstance(Param param) {
		HumanObject humanObj = param.get();
		
		long humanId = humanObj.id;
		
		//属性加成
		LoadHumanDataUtils.load(humanObj, "humanPropPlus", HumanPropPlus.class, "id", humanId);
		//TODO 直接开始
//		Event.fire(EventKey.HUMAN_DATA_LOAD_FINISH_ONE, humanObj);
	}
	
	/**
	 * 玩家登录游戏后 加载玩家的数据
	 * 开始了一条新的数据加载
	 * @param humanObj
	 */
	@Listener(EventKey.HUMAN_DATA_LOAD_BEGIN_ONE)
	public void loadDataBeginOne(Param param) {
		HumanObject humanObj = param.get();
		humanObj.loadingNum++;
	}
	
	/**
	 * 玩家登录游戏后 加载玩家的数据
	 * 完成了一条新的数据加载
	 * @param humanObj
	 */
	@Listener(EventKey.HUMAN_DATA_LOAD_FINISH_ONE)
	public void loadDataFinishOne(Param param) {
		HumanObject humanObj = param.get();
		humanObj.loadingNum--;
		
		//玩家数据全部加载完毕 可以正式进行登录了
		if(humanObj.loadingNum <= 0) {
			//玩家数据加载完毕后 登录游戏
			login(humanObj);
			
			//返回
			Port port = Port.getCurrent();
			port.returnsAsync(humanObj.loadingPID, "node", port.getNode().getId(), "port", port.getId());
		}
	}

	@Listener(EventKey.HUMAN_LOGOUT)
	public void onLogout(Param param) {
		HumanObject humanObj = param.get("humanObj");
		Human human = humanObj.dataPers.human;
		
		//同步玩家位置
		JSONArray ja = JSON.parseArray(human.getStageHistory());
		JSONArray jaTemp = JSON.parseArray(ja.getString(0));
		jaTemp.set(2, humanObj.posNow.x);
		jaTemp.set(3, humanObj.posNow.y);
		ja.set(0, jaTemp);
		human.setStageHistory(JSON.toJSONString(ja));
		
		//更新退出时间
		human.setTimeLogout(Port.getTime());
		
		//移除地图
		humanObj.stageLeave();
		
		StageGlobalServiceProxy proxy = StageGlobalServiceProxy.newInstance();
		//地图玩家数-1
		proxy.stageHumanNumReduce(humanObj.stageObj.id);
	}
	
	/**
	 * 玩家完成加载登录到地图中时进行操作
	 * @param params
	 */
	@Listener(EventKey.HUMAN_STAGE_ENTER)
	public void onHumanStageEnter(Param params) {
		HumanObject humanObj = params.get("humanObj");
		
		//设置状态 代表客户端已经准备好了
		humanObj.isClientStageReady = true;
	}
	
	
	/**
	 * 发送登录初始化信息至客户端
	 */
	private void sendInitDataToClient(HumanObject humanObj) {
		//玩家基础信息
		Human human = humanObj.dataPers.human;
		StageObject stageObj = humanObj.stageObj;
		long curr = Port.getTime();
		
		//玩家基本属性
		DProp.Builder dProp = DProp.newBuilder();
		for(PropKey propKey : PropKey.values()) {
			Object v = Utils.fieldRead(human, propKey.name());
			if(propKey == PropKey.speed) continue;
			Utils.fieldWrite(dProp, propKey.name(), v);
		}
		dProp.setSpeed(human.getSpeed());
		
		//基本信息
		DHuman.Builder dHuman = DHuman.newBuilder();
		dHuman.setProp(dProp);
		dHuman.setId(humanObj.id);
		dHuman.setName(human.getName());
		dHuman.setLevel(human.getLevel());
		dHuman.setSex(human.getSex());
		dHuman.setHpCur(human.getHpCur());
		dHuman.setMpCur(human.getMpCur());
		dHuman.setProfession(human.getProfession());

		//地图信息
		Msg.DInitDataStage.Builder dStage = Msg.DInitDataStage.newBuilder();
		dStage.setPosNow(new Vector2(humanObj.posNow.x, humanObj.posNow.y).toMsg());
		dStage.setId(stageObj.id);
		dStage.setSn(stageObj.sn);
		
		//最终消息
		Msg.SCInitData.Builder msg = Msg.SCInitData.newBuilder();
		msg.setHuman(dHuman);
		msg.setStage(dStage);
		
		humanObj.sendMsg(msg);
	}
	
	public void recordStage(HumanObject humanObj, long stageId, int stageSn, String stageType, Vector2 vectorOld) {
		Human human = humanObj.dataPers.human;
		
		List<?> temp = Utils.ofList(stageSn, stageId, vectorOld.x, vectorOld.y, stageType);
		List<?> stageInfo = Utils.ofList(temp);
		
		human.setStageHistory(JSON.toJSONString(stageInfo));
	}
	
	/**
	 * 计算用户各项属性
	 * @param unitObject
	 */
	public void propCalc(HumanObject humanObj) {
		Human human = humanObj.dataPers.human;
		HumanPropPlus pp = humanObj.dataPers.humanPropPlus;
		
		//各模块加成属性
		PropCalcCommon propPlus = getPropPlus(pp);
		
		//计算一级属性
		human.setCon(propPlus.getInt(PropKey.con));
		human.setStr(propPlus.getInt(PropKey.str));
		human.setDex(propPlus.getInt(PropKey.dex));
		human.setInte(propPlus.getInt(PropKey.inte));
		
		
		//记录属性计算前的血/魔
		int hpMaxOld = human.getHpMax();
		int mpMaxOld = human.getMpMax();
		
		//计算人物二级属性
		int atk = propSecCalc(human, PropKey.atk) + propPlus.getInt(PropKey.atk);							//攻击=（力量*力量攻击系数 + 各模块加成）* （1 + 加成系数）
		int def = propSecCalc(human, PropKey.def) + propPlus.getInt(PropKey.def);							//防御=（敏捷*敏捷防御系数 + 各模块加成）* （1 + 加成系数）
		int hpMax = propSecCalc(human, PropKey.hpMax) + propPlus.getInt(PropKey.hpMax);			//生命=（体力*体力生命系数 + 各模块加成）* （1 + 加成系数）
		int mpMax = propSecCalc(human, PropKey.mpMax) + propPlus.getInt(PropKey.mpMax);		//法力=（体力*体力法力系数 + 各模块加成）* （1 + 加成系数）
		
		int hit = propSecCalc(human, PropKey.hit) + propPlus.getInt(PropKey.hit);							//命中=（敏捷*敏捷命中系数 + 各模块加成）
		int dodge = propSecCalc(human, PropKey.dodge) + propPlus.getInt(PropKey.dodge);			//闪避=（智力*智力闪避系数 + 各模块加成）
		int crit = propSecCalc(human, PropKey.crit) + propPlus.getInt(PropKey.crit);							//暴击=（智力*智力暴击系数 + 各模块加成）
		
		//设置上新的二级属性
		human.setAtk(atk);				
		human.setDef(def);				
		human.setHpMax(hpMax);					
		human.setMpMax(mpMax);					
		human.setHit(hit);				
		human.setDodge(dodge);			
		human.setCrit(crit);				
		
		
		int combat = getCombat(human);
		
//		if(combat > human.getCombat()){
//			Event.fire(EventKey.HUMAN_COMBAT_CHANGE, "human", human, "combat", combat);
//		}
		
		//计算战斗力
		human.setCombat(combat);
		
		//计算最终的 血/魔
		double hpNew = human.getHpCur() * (1.0 * human.getHpMax() / hpMaxOld);
		double mpNew = human.getMpCur() * (1.0 * human.getMpMax() / mpMaxOld);
		
		human.setHpCur((int)hpNew);
		human.setMpCur((int)mpNew);
	}
	
	/**
	 * 计算人物二级属性
	 * @param human
	 * @param propKey  二级属性  仅仅适用于二级属性，非抗性
	 */
	private int propSecCalc(Human human, PropKey propKey) {
		//计算人物二级属性
		for(ConfPropConversion p : ConfPropConversion.findAll()) {
			if(!propKey.name().equals(p.type)) continue;

			Map<String, Double> calcRadio = new HashMap<>();
			if(StringUtils.isNotBlank(p.conversionType1)) {
				calcRadio.put(p.conversionType1, p.conversionRatio1);
			}
			if(StringUtils.isNotBlank(p.conversionType2)) {
				calcRadio.put(p.conversionType2, p.conversionRatio2);
			}
			if(StringUtils.isNotBlank(p.conversionType3)) {
				calcRadio.put(p.conversionType3, p.conversionRatio3);
			}
			if(StringUtils.isNotBlank(p.conversionType4)) {
				calcRadio.put(p.conversionType4, p.conversionRatio4);
			}
			
			double value = 0;
			try {
				for(String prop : calcRadio.keySet()) {
					int propValue = Utils.fieldRead(human, prop);
					value += propValue * calcRadio.get(prop);
				}
			} catch (Exception e) {
				throw new SysException(e);
			}
			
			return (int)value;
		}
		
		return 0;
	}
	
	
	private int getCombat(Human human) {
		return human.getLevel();
	}
	/**
	 * 获取各个模块对玩家的属性加成
	 * @param humanExt
	 * @return
	 */
	public PropCalcCommon getPropPlus(HumanPropPlus humanPropPlus) {
		PropCalcCommon data = new PropCalcCommon();
		
		//遍历加成属性来累加数据
		for(EntityHumanPropPlus k : EntityHumanPropPlus.values()) {
			String pp = Utils.fieldRead(humanPropPlus, k.name());
			data.plus(pp);
		}
		
		return data;
	}
	
}