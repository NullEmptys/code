package org.gof.demo.worldsrv.stage;

import java.util.ArrayList;
import java.util.List;

import org.gof.core.support.Utils;
import org.gof.core.support.observer.MsgReceiver;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.character.WorldObject;
import org.gof.demo.worldsrv.config.ConfStage;
import org.gof.demo.worldsrv.human.HumanManager;
import org.gof.demo.worldsrv.msg.Msg.CSStageEnter;
import org.gof.demo.worldsrv.msg.Msg.CSStageMove;
import org.gof.demo.worldsrv.msg.Msg.CSStageMove2;
import org.gof.demo.worldsrv.msg.Msg.CSStageMoveStop;
import org.gof.demo.worldsrv.msg.Msg.CSStageSwitch;
import org.gof.demo.worldsrv.msg.Msg.SCStageEnterResult;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.Vector2;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;
import org.gof.seam.msg.MsgParam;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class StageMsgHandler {
	private StageManager stageManager = StageManager.getInstance();
	private HumanManager humanManager = HumanManager.getInstance();

	/**
	 * 玩家准备好 进入地图
	 * @param param
	 */
	@MsgReceiver(CSStageEnter.class)
	public void onCSStageEnter(MsgParam param) {
		HumanObject humanObj = param.getHumanObject();
		StageObject stageObj = humanObj.stageObj;

		//通知本人 本区域的地图单元信息
		SCStageEnterResult.Builder msgER = SCStageEnterResult.newBuilder();
		for(WorldObject o : stageManager.getWorldObjsInArea(humanObj.stageObj, humanObj.posNow)) {
			if(!o.isInWorld()) continue;
			if(o.equals(humanObj)) continue;

			msgER.addObj(o.createMsg());
		}
		humanObj.sendMsg(msgER);
		
		//死亡的时候不发stageEnter
		if(!humanObj.isDie()) {
			humanObj.stageShow();
		}
		
		//玩家登录到地图中的事件（切换地图是不会触发）
		if(humanObj.loginStageState == 1) {
			Event.fire(EventKey.HUMAN_LOGIN_FINISH, "humanObj", humanObj);
			humanObj.loginStageState = 0;
		} else if(humanObj.loginStageState == 2) {
			Event.fire(EventKey.HUMAN_LOGIN_FINISH_FIRST_TODAY, "humanObj", humanObj);
			Event.fire(EventKey.HUMAN_LOGIN_FINISH, "humanObj", humanObj);
			humanObj.loginStageState = 0;
		}
		
		//发送进入地图事件
		Event.fireEx(EventKey.HUMAN_STAGE_ENTER, stageObj.sn, "humanObj", humanObj);
	}
	
	/**
	 * 切换地图
	 * @param param
	 */
	@MsgReceiver(CSStageSwitch.class)
	public void onCSStageSwitch(MsgParam param) {
		HumanObject humanObj = param.getHumanObject();
		CSStageSwitch msg = param.getMsg();
		int mapSn = Utils.intValue(msg.getAreaSwitchKey());
		StageObject stageObj = humanObj.stageObj;
		
		ConfStage conf = ConfStage.get(mapSn);
		if(conf == null) {
			Log.stageCommon.info("切换地图错误！");
			return;
		}
		//取出目标点
		//TODO 坐标回头扔配置
		Vector2 posAppear = new Vector2(100, 100);
		
		//如果是本地图内传
		if(stageObj.sn == mapSn) {
			stageManager.pullTo(humanObj, posAppear);
		} else {
			stageManager.switchTo(humanObj, mapSn, posAppear);
		}
	}
	
	/**
	 * 玩家移动
	 * @param param
	 */
	@MsgReceiver(CSStageMove.class)
	public void onCSStageMove(MsgParam param) {
		HumanObject humanObj = param.getHumanObject();
		CSStageMove msg = param.getMsg();
		
		//处理玩家的移动
		humanObj.move(new Vector2(msg.getPosBegin()), Vector2.parseFrom(msg.getPosEndList()));
	}
	
	/**
	 * 手机地图玩家移动
	 * @param param
	 */
	@MsgReceiver(CSStageMove2.class)
	public void onCSStageMove2(MsgParam param) {
		HumanObject humanObj = param.getHumanObject();
		CSStageMove2 msg = param.getMsg();
		
		float x1 = msg.getPosBegin().getX();
		float y1 = msg.getPosBegin().getY();
		float x2 = msg.getDirection().getX();		//当前位置走向方向上的某一个点的横坐标
		float y2 = msg.getDirection().getY();		
		
		double distanceTemp = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
		double cosA = (x2 - x1)/distanceTemp;
		double sinA = (y2 - y1)/distanceTemp;
		
		Log.temp.debug("遥感移动");
		double xEnd = x1 + 10000 * cosA;
		double yEnd = y1 + 10000 * sinA;
		
		//处理玩家的移动
		humanObj.move(new Vector2(msg.getPosBegin()), Utils.ofList(new Vector2(xEnd, yEnd)));
	}
	
	/**
	 * 玩家移动停止
	 * @param param
	 * @return
	 */
	@MsgReceiver(CSStageMoveStop.class)
	public void onCSStageMoveStop(MsgParam param) {
		HumanObject humanObj = param.getHumanObject();
		CSStageMoveStop msg = param.getMsg();
		Vector2 posEnd = new Vector2(msg.getPosEnd());
		
		if(!(posEnd.x == 0 && posEnd.y == 0)) {
			humanObj.posNow = posEnd;
		}
		
		//TODO　验证坐标偏差
		humanObj.posNow = posEnd;
		
		//停止
		humanObj.stop();
	}
}