package org.gof.demo.worldsrv.stage;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.gof.core.CallPoint;
import org.gof.core.Chunk;
import org.gof.core.Port;
import org.gof.core.Service;
import org.gof.core.connsrv.ConnectionProxy;
import org.gof.core.gen.callback.DistrCallback;
import org.gof.core.gen.proxy.DistrClass;
import org.gof.core.gen.proxy.DistrMethod;
import org.gof.core.support.Param;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.character.HumanObjectServiceProxy;
import org.gof.demo.worldsrv.config.ConfStage;
import org.gof.demo.worldsrv.entity.Human;
import org.gof.demo.worldsrv.human.HumanGlobalServiceProxy;
import org.gof.demo.worldsrv.human.HumanManager;
import org.gof.demo.worldsrv.msg.Msg.SCStageSwitch;
import org.gof.demo.worldsrv.msg.MsgIds;
import org.gof.demo.worldsrv.support.D;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.Vector2;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;

import com.google.protobuf.Message;

@DistrClass(
		servId = D.SERV_STAGE_GLOBAL,
		importClass = {HumanObject.class, List.class, Message.class, Vector2.class}
)
public class StageGlobalService extends Service {
	
	private HumanManager humanManager = HumanManager.getInstance();
	private StageManager stageManager = StageManager.getInstance();
	
	//地图信息集合
	private final Map<Long, StageGlobalInfo> infos = new HashMap<Long,StageGlobalInfo>();
	
	public StageGlobalService(Port port) {
		super(port);
	}
	
	@Override
	public Object getId() {
		return D.SERV_STAGE_GLOBAL;
	}
	
	/**
	 * 注册地图信息
	 * @param stageId
	 * @param stageSn
	 */
	@DistrMethod
	public void infoRegister(long stageId, int stageSn, String stageName) {
		//创建信息对象并缓存
		StageGlobalInfo info= new StageGlobalInfo(stageId, stageSn, stageName, port.getCallFromNodeId(), port.getCallFromPortId());
		infos.put(stageId, info);
		
		//记录创建日志
		if(Log.stageCommon.isInfoEnabled()) {
			Log.stageCommon.info("创建地图：stageId={}, stageSn={}", stageId, stageSn);
		}
		
		Event.fireEx(EventKey.STAGE_REGISTER, stageSn, 
				"stageSn", stageSn, 
				"nodeId", port.getCallFromNodeId(), 
				"portId", port.getCallFromPortId(), 
				"stageId", stageId);
	}
	
	/**
	 * 注销地图信息
	 * @param stageId
	 */
	@DistrMethod
	public void infoCancel(long stageId) {
		StageGlobalInfo information = infos.remove(stageId);
		
		if(information == null) {
			Log.stageCommon.warn("销毁地图时发现地图已不存在：stageId={}", stageId);
			return;
		}
		
		Event.fireEx(EventKey.STAGE_CANCEL, information.sn, 
				"stageSn", information.sn, 
				"nodeId", port.getCallFromNodeId(), 
				"portId", port.getCallFromPortId(), 
				"stageId", stageId);
	}
	
	@DistrMethod
	public void login(long humanId, CallPoint connPoint, List<List<?>> lastStageIds) {
		Long pid = port.createReturnAsync();
		
		StageGlobalInfo information = null;
		information = this.infos.get(lastStageIds.get(0).get(0));
		
		StageObjectServiceProxy prx = StageObjectServiceProxy.newInstance(information.nodeId, information.portId, information.id);
		prx.login(humanId, connPoint, information.id, new Vector2(-1f, -1f));		//TODO 暂时先来个随机坐标
		prx.listenResult(this, StageGlobalServiceCallback._result_login, "pid", pid);
	}
	
	@DistrCallback
	public void _result_login(boolean timeout, Param results, Param context) {
		Long pid = context.get("pid");
		if(timeout) {
			port.returnsAsync(pid, "code", -2000);
			return;
		}
		port.returnsAsync(pid, results.toArray());
	}
	
	/**
	 * 地图玩家数量增加
	 * @param stageId
	 */
	@DistrMethod
	public void stageHumanNumAdd(long stageId) {
		stageHumanNumChange(stageId, true);
	}
	
	/**
	 * 地图玩家数量减少
	 * @param stageId
	 */
	@DistrMethod
	public void stageHumanNumReduce(long stageId) {
		stageHumanNumChange(stageId, false);
	}
	
	
	/**
	 * 地图玩家数量变动
	 * @param stageId
	 * @param add
	 */
	private void stageHumanNumChange(long stageId, boolean add) {
		StageGlobalInfo info = this.infos.get(stageId);
		
		if(info == null) return ;
		
		//地图人数变动
		if(add) {
			info.humanNum = Math.max(0, info.humanNum + 1);
		} else {
			info.humanNum -= Math.max(0, info.humanNum - 1);
		}
	}

	@DistrMethod
	public void switchToStage(HumanObject humanObj, long stageTargetId, Vector2 posAppear) {
		Human human = humanObj.dataPers.human;
		
		//根据配置重设出生点
		StageGlobalInfo temp = this.infos.get(stageTargetId);
		
		//常规地图位置
		ConfStage conf = ConfStage.get(temp.sn);

		//玩家上一张地图坐标
		Vector2 posOld = new Vector2(humanObj.posNow.x, humanObj.posNow.y);
		
		//玩家新地图的坐标
		humanObj.posNow = posAppear;
		
		/* 离开原地图 */
		//从原地图清离,原地图玩家数-1
		StageGlobalInfo infoSource = this.infos.get(humanObj.getStageNowId());	
		HumanObjectServiceProxy prxSource = HumanObjectServiceProxy.newInstance(infoSource.nodeId, infoSource.portId, humanObj.id);
		prxSource.leave();
		stageHumanNumReduce(humanObj.getStageNowId());

		/* 业务逻辑部分 */
		//更新玩家地图路径信息
		humanManager.recordStage(humanObj, stageTargetId, temp.sn, conf.type, posOld);
		
		/* 进入新地图 */
		StageGlobalInfo infoTarget = this.infos.get(stageTargetId);
		
		//更新玩家全局信息
		HumanGlobalServiceProxy prxHumanStatus = HumanGlobalServiceProxy.newInstance();
		prxHumanStatus.stageIdModify(human.getId(), infoTarget.id, infoTarget.name, infoTarget.nodeId, infoTarget.portId);
		
		//注册玩家至新地图，新地图玩家数+1(业务逻辑只能写在此处前，防止玩家数据提前串行化，到时修改失效)
		StageObjectServiceProxy prxTarget = StageObjectServiceProxy.newInstance(infoTarget.nodeId, infoTarget.portId, infoTarget.id);
		prxTarget.register(humanObj);
		prxTarget.listenResult(this, StageGlobalServiceCallback._result_switchToStage, "infoTarget", infoTarget, "humanObj", humanObj);
		stageHumanNumChange(stageTargetId, true);
	}
	
	@DistrCallback
	public void _result_switchToStage(boolean timeout, Param results, Param context) {
		StageGlobalInfo infoTarget = context.get("infoTarget");
		HumanObject humanObj = context.get("humanObj");
		Vector2 posNow = results.get("posNow");
		
		/* 消息处理 */
		//返回地图切换消息
		SCStageSwitch.Builder msgSwitch = SCStageSwitch.newBuilder();
		msgSwitch.setStageId(infoTarget.id);
		msgSwitch.setStageSn(infoTarget.sn);
		msgSwitch.setPos(posNow.toMsg());
		SCStageSwitch msg = msgSwitch.build();
		
		//玩家连接
		CallPoint connPoint = humanObj.connPoint;
		ConnectionProxy prx = ConnectionProxy.newInstance(connPoint.nodeId, connPoint.portId, connPoint.servId);
		prx.sendMsg(MsgIds.getIdByClass(msg.getClass()), new Chunk(msg));
		
		//更新连接服务器的玩家信息
		prx.updateStatus(infoTarget.nodeId, infoTarget.portId, infoTarget.id);
	}
	
}
