package org.gof.demo.worldsrv.support;

/**
 * 系统环境
 */
public class S {

}