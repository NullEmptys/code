package org.gof.demo.worldsrv.stage;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.gof.core.Port;
import org.gof.core.Service;
import org.gof.core.gen.proxy.DistrClass;
import org.gof.core.gen.proxy.DistrMethod;
import org.gof.core.support.Distr;
import org.gof.core.support.PackageClass;
import org.gof.core.support.SysException;
import org.gof.core.support.Time;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.support.D;

@DistrClass(
)
public class StageService extends Service {
	private StageManager stageManager = StageManager.getInstance();
	
	
	public StageService(StagePort port) {
		super(port);
	}
	
	@Override
	public Object getId() {
		return D.SERV_STAGE_DEFAULT;
	}

	
}
