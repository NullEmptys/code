package org.gof.demo.worldsrv.character;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.gof.demo.worldsrv.entity.Unit;
import org.gof.demo.worldsrv.msg.Msg.DStageMonster;
import org.gof.demo.worldsrv.msg.Msg.DStageObject;
import org.gof.demo.worldsrv.msg.Msg.EWorldObjectType;
import org.gof.demo.worldsrv.stage.StageObject;


/**
 * 怪物
 */
public class MonsterObject extends UnitObject {
	
	public MonsterObject(StageObject stageObj) {
		super(stageObj);
	}
	
	@Override
	public Unit getUnit() {
		return null;
	}
	
	@Override
	public DStageObject.Builder createMsg() {
		//monster特有信息
		DStageMonster.Builder dMonster = DStageMonster.newBuilder();
		
		
		//共同信息
		DStageObject.Builder dObj = DStageObject.newBuilder();
		dObj.setObjId(id);
		dObj.setType(EWorldObjectType.MONSTER);
		dObj.setPos(posNow.toMsg());
		dObj.setName(name);
		dObj.setMonster(dMonster);
		
		return dObj;
	}
	
}
