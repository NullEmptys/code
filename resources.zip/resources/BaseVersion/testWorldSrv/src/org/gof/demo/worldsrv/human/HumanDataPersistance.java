package org.gof.demo.worldsrv.human;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.gof.core.InputStream;
import org.gof.core.OutputStream;
import org.gof.core.interfaces.ISerilizable;
import org.gof.demo.worldsrv.entity.Human;
import org.gof.demo.worldsrv.entity.HumanPropPlus;

/**
 * 玩家持久化数据
 */
public class HumanDataPersistance implements ISerilizable {
	public Human human;									//基本信息
	
	public HumanPropPlus humanPropPlus;					//玩家属性加成
	/**
	 * 构造函数
	 */
	public HumanDataPersistance() {
	}
	
	@Override
	public void writeTo(OutputStream out) throws IOException {
		out.write(human);
		out.write(humanPropPlus);
	}
	
	@Override
	public void readFrom(InputStream in) throws IOException {
		human = in.read();
		humanPropPlus = in.read();
	}
}
