package org.gof.demo.worldsrv.support.enumKey;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 
 * @author ExceedSun
 *
 */
public enum PropKey {
	str("力量"),
	dex("敏捷"),
	con("体力"),
	inte("智力"),
	
	atk("攻击"),
	def("防御"),
	hit("命中"),
	dodge("闪避"),
	crit("暴击"),
	
	speed("速度"),
	

	
	hpMax("最大生命"),
	mpMax("最大法力"),
	;
	
	private PropKey(String content) {
		this.content = content;
	}

	private String content;
	private static Set<String> keys = new HashSet<>();
	
	static {
		for(PropKey key : values()) {
			keys.add(key.name());
		}
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	/**
	 * 是否包含给定的Key
	 * @param key
	 * @return
	 */
	public static boolean contains(String key) {
		return keys.contains(key);
	}
	
	/**
	 * 获取枚举关键字List
	 * @return
	 */
	public static List<String> toList() {
		List<String> result = new ArrayList<>();
		for (PropKey k : PropKey.values()) {
			result.add(k.name());
		}
		return result;
	}
}
