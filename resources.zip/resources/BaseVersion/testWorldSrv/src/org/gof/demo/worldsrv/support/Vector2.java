package org.gof.demo.worldsrv.support;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import org.gof.core.InputStream;
import org.gof.core.OutputStream;
import org.gof.core.interfaces.ISerilizable;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.DVector2;

/**
 * 坐标
 */
public class Vector2 implements ISerilizable {
	public double x;			//横坐标
	public double y;			//纵坐标
	
	public Vector2() { }
	
	/**
	 * 构造函数
	 * @param x
	 * @param y
	 */
	public Vector2(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * 将消息位置信息转化本坐标
	 * @param vector2
	 */
	public Vector2(DVector2 vector2) {
		this(vector2.getX(), vector2.getY());
	}
	
	/**
	 * 将消息位置信息转化本坐标
	 * @param vs
	 * @return
	 */
	public static List<Vector2> parseFrom(List<DVector2> vs) {
		List<Vector2> result = new ArrayList<>();
		for(DVector2 v : vs) {
			result.add(new Vector2(v));
		}
		
		return result;
	}
	
	/**
	 * 将消息位置信息转化本坐标
	 * @param vs
	 * @return
	 */
	public static List<DVector2> toMsgs(List<Vector2> vs) {
		List<DVector2> result = new ArrayList<>();
		for(Vector2 v : vs) {
			result.add(v.toMsg());
		}
		
		return result;
	}
	
	/**
	 * 转化为消息类型
	 * @return
	 */
	public DVector2 toMsg() {
		Msg.DVector2.Builder msg = Msg.DVector2.newBuilder();
		msg.setX((float)x);	
		msg.setY((float)y);
		
		return msg.build();
	}
	
	/**
	 * 转换为三维float型数组
	 */
	public float[] toFloat3() {
		return new float[]{(float)x, 0, (float)y};
	}
	
	/**
	 * 设置坐标值
	 * @param vector
	 */
	public void set(Vector2 vector) {
		this.x = vector.x;
		this.y = vector.y;
	}
	
	/**
	 * 获取易读的坐标字符串
	 * @return
	 */
	public String getPosStr() {
		return new StringBuilder("(").append(x).append(",").append(y).append(")").toString();
	}
	
	/**
	 * 两点之间的距离
	 * @param pos
	 * @return
	 * 2013-5-10
	 */
	public double distance(Vector2 pos) {
		double t1x = this.x;
		double t1y = this.y;
		double t2x = pos.x;
		double t2y = pos.y;
		
		return Math.sqrt(Math.pow((t1x -t2x), 2) + Math.pow((t1y - t2y) , 2));
	}
	
	@Override
	public void writeTo(OutputStream out) throws IOException {
		out.write(x);
		out.write(y);
	}
	
	@Override
	public void readFrom(InputStream in) throws IOException {
		x = in.read();
		y = in.read();
	}
	
	@Override
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		
		if(!(other instanceof Vector2)) {
			return false;
		}
		
		Vector2 castOther = (Vector2) other;
		return new EqualsBuilder().append(this.x, castOther.x).append(this.y, castOther.y).isEquals();
	}
	
	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(x).append(y).toHashCode();
	}

	@Override
	public String toString() {
		return new StringBuilder().append("[").append(x).append(",").append(y).append("]").toString();
	}
}
