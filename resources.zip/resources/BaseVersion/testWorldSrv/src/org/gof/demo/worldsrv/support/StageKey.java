package org.gof.demo.worldsrv.support;

/**
 * 记录场景的sn对应关系
 */
public class StageKey {
	//晶石
	public static final int j晶石活动场景 = 60001;
	
	//个人竞技
	public static final int g个人竞技擂台 = 70001;
	
	//多人竞技
	public static final int d多人竞技擂台 = 70001;
		
	// 离线竞技
	public static final int l离线竞技 = 70001;
	
	//世界boss
	public static final int s世界BOSS场景 = 50001;
	
	//兵团驻地
	public static final int b兵团驻地场景 = 50100;

	//兵团战
	public static final int b兵团战场景 = 70001;
}
