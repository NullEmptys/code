package org.gof.demo.worldsrv.support.observer;

public enum EventKey {
	GAME_STARTUP_BEFORE,				//游戏启动前
	GAME_STARTUP_FINISH,				//游戏启动完毕
	
	STAGE_REGISTER,						//地图被注册
	STAGE_CANCEL,						//地图被注销
	
	HUMAN_UPGRADE_EACH,					//用户升级，每级都抛出
	HUMAN_UPGRADE,						//用户升级，每次升级抛出一次，传递开始和结束等级
	HUMAN_BE_KILLED,					//用户死亡
	HUMAN_ONLINETIME_CHANGE,			//用户在线时间改变
	HUMAN_UNION_POINT_ADD,				//兵团贡献增加
	
	HUMAN_CREATE,						//创建角色
	HUMAN_LOGIN,						//玩家登录
	HUMAN_LOGIN_FINISH,					//玩家登录结束，可以开始接收消息。
	HUMAN_LOGIN_FINISH_FIRST_TODAY,		//玩家今日首次登录结束，可以开始接收消息。
	HUMAN_LOGOUT,						//玩家登出游戏
	
	HUMAN_RESET_ZERO,					//玩家进行零时所需清理
	HUMAN_RESET_FIVE,					//玩家进行五时所需清理
	
	HUMAN_STAGE_ENTER,					//玩家进入地图（切换地图时会触发）
	
	HUMAN_PROP_CHANGE,					//玩家属性变化
	HUMAN_PROP_ADD,						//玩家属性增加
	HUMAN_PROP_REDUCE,					//玩家属性减少
	
	HUMAN_DATA_MAIN_LOAD_BEGIN,		//用户玩家主要数据加载开始
	HUMAN_DATA_LOAD_BEGIN,				//用户玩家数据加载开始
	HUMAN_DATA_LOAD_BEGIN_ONE,			//用户玩家数据加载开始一个
	HUMAN_DATA_LOAD_FINISH_ONE,			//用户玩家数据加载完成一个
	
	UNIT_MOVE_START,					//可移动单元每次开始移动
	UNIT_HPLOSS,						//战斗单元受到伤害
	UNIT_ATTACK,						//战斗单元攻击
	UNIT_ACT,							//地图单元有动作，移动，攻击，施法等
	UNIT_BE_ATTACKED,					//战斗单元受攻击
	UNIT_BE_KILLED,						//战斗单元死亡
	
	MONSTER_MOVE_START,					//怪物每次开始移动
	MONSTER_HPLOSS,						//怪物受到伤害
	MONSTER_HPLOSS_BY_NO_HUMAN,			//怪物受到伤害,攻击者为null
	MONSTER_ATTACK,						//怪物攻击
	MONSTER_BE_KILLED,					//怪物被击杀
	MONSTER_BE_ATTACKED,				//怪物被攻击
	MONSTER_ACT,						//怪物有动作，移动，攻击，施法等
	MONSTER_EAT,						//怪物吞噬了其他怪
	MONSTER_BORN,						//怪物出生
	MONSTER_SKILL_CAST,					//怪物施放技能
	
	HUMAN_MOVE_START_BEFORE,			//玩家每次开始移动 之前抛出
	HUMAN_MOVE_START,					//玩家每次开始移动
	HUMAN_HPLOSS,						//玩家受到伤害
	HUMAN_ATTACK,						//玩家攻击
	HUMAN_ACTS_BEFORE,					//玩家有动作，移动，攻击，施法等 之前抛出
	HUMAN_ACT,							//玩家有动作，移动，攻击，施法等
	HUMAN_BE_ATTACKED,					//玩家受攻击
	HUMAN_MOVE_FINISH,					// 玩家停止移动
	HUMAN_REVIVE,						//玩家复活
	
	ITEM_CHANGE,
	ITEM_INIT,						//物品创建
	ITEM_EQUIP_STRTH,				//物品强化
	ITEM_EQUIP_REFINE,				//物品洗练
	ITEM_USE,						//物品使用
	ITEM_BE_USED_SUCCESS,			//物品使用成功
	
	QUEST_MONSTER_BE_KILLED,		//怪物被击杀,任务专用
	QUEST_AUTO,
	QUEST_FINISH,					//任务完成
	
	MONEY_COIN_ADD_MAIN,			//铜币增加
	MONEY_COIN_ADD,					//铜币增加
	MONEY_COIN_REDUCE,				//铜币消耗
	MONEY_COIN_GIFT_ADD,			//绑定铜币增加
	MONEY_COIN_GIFT_REDUCE,			//绑定铜币消耗
	MONEY_COIN_ALL_ADD,				//铜币增加，包括绑定和不绑定的
	MONEY_COIN_ALL_REDUCE,			//铜币消耗，包括绑定和不绑定的
	MONEY_COIN_ALL_CHANGE,			//铜币消耗，包括绑定和不绑定的
	
	MONEY_GOLD_ADD,					//元宝增加
	MONEY_GOLD_REDUCE,				//元宝消耗
	MONEY_GOLD_GIFT_ADD,			//绑定元宝增加
	MONEY_GOLD_GIFT_REDUCE,			//绑定元宝消耗
	MONEY_GOLD_ALL_ADD,				//元宝增加，包括绑定和不绑定的
	MONEY_GOLD_ALL_REDUCE,			//元宝消耗，包括绑定和不绑定的
	MONEY_GOLD_ALL_CHANGE,			//元宝消耗，包括绑定和不绑定的
	
	POCKET_LINE_HANDLE,				//按模块发送待办事件
	POCKET_LINE_HANDLE_ONE,			//用户待办事件,逐条发送
	POCKET_LINE_HANDLE_END,			//待办事件处理结束 
	
	THINKING_MAGIC_PRATICE,			//心法修炼次数
	
	SKILL_PASSIVE_CHECK,			//被动技能检查
	SKILL_UPGRADE,					//技能升级
	
	PICK_BE_PICKED,					//采集采集物
	TRIGGER_BE_TRIGGERED,			//机关触发
	
	INSTANCE_PASS,					//副本通关
	
	UNION_JOIN,						//加入兵团
	UNION_QUIT,						//退出兵团
	UNION_CREATE,					//创建兵团
	UNION_UPGRADE,					//兵团升级
	UNION_POWER_CHANGE,				//兵团实例变化，当兵团创建、升级、加经验时发送

	PARTNER_CREATE,					//魂将创建
	
	HUMAN_COMBAT_CHANGE,				//玩家战斗力变化
	PEGASUS_COMBAT_CHANGE,				//坐骑战斗力变化
	PARTNER_COMBAT_CHANGE,				//魂将战斗力变化
	
	COMPETE_OFFLINE_RANK_CHANGE,		// 离线竞技排行变化
	
	USUAL_PROMPT_TASK_INIT,			//待做事项初始化
	USUAL_PROMPT_TASK_CHANGE,		//待做事项改变
	
	/* 成就系统相关 */
	RELATION_FLOWER_RECEIVE, 				// 收到鲜花数
	RELATION_FLOWER_GIVE, 					// 送出鲜花数
	RELATION_FRIEND_ADD,						// 添加好友
	COMPETE_ENTER,									//个人竞技进入场景
	WORLDBOOS_BE_KILLED,						// 世界boss被击杀
	;
}