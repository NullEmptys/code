package org.gof.demo.worldsrv.character;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.gof.core.CallPoint;
import org.gof.core.Chunk;
import org.gof.core.InputStream;
import org.gof.core.OutputStream;
import org.gof.core.Port;
import org.gof.core.connsrv.ConnServiceProxy;
import org.gof.core.connsrv.ConnectionProxy;
import org.gof.core.gen.callback.DistrCallback;
import org.gof.core.gen.proxy.DistrClass;
import org.gof.core.interfaces.ISerilizable;
import org.gof.core.support.Distr;
import org.gof.core.support.Param;
import org.gof.core.support.Sys;
import org.gof.core.support.TickTimer;
import org.gof.core.support.Time;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.entity.Human;
import org.gof.demo.worldsrv.entity.Unit;
import org.gof.demo.worldsrv.human.HumanDataPersistance;
import org.gof.demo.worldsrv.human.HumanGlobalServiceProxy;
import org.gof.demo.worldsrv.human.HumanManager;
import org.gof.demo.worldsrv.msg.Msg.DStageHuman;
import org.gof.demo.worldsrv.msg.Msg.DStageObject;
import org.gof.demo.worldsrv.msg.Msg.EWorldObjectType;
import org.gof.demo.worldsrv.msg.MsgIds;
import org.gof.demo.worldsrv.msg.Msg.DVector2;
import org.gof.demo.worldsrv.stage.StageObject;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.PropCalcCommon;
import org.gof.demo.worldsrv.support.Vector2;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.protobuf.Message;
import com.google.protobuf.Message.Builder;

/**
 * 角色
 */
@DistrClass
public class HumanObject extends UnitObject {
	private HumanManager humanManager = HumanManager.getInstance();

	public CallPoint connPoint = new CallPoint();						//连接点信息

	//人物持久化信息
	public HumanDataPersistance dataPers = new HumanDataPersistance();
	
	public int loadingNum = 0;					//正在加载玩家数据时的计数器 当等于0时代表加载完毕
	public long loadingPID = 0;					//正在加载玩家数据时的请求ID

	public boolean isClientStageReady;			//客户端地图状态已准备完毕
	public boolean isStageSwitching = false;	//正在切换地图中
	
	//玩家登陆状态判断 临时属性 0=无状态 1=登陆中 2=今日首次登陆中
	public int loginStageState;	
		
	/**
	 * 构造函数
	 */
	public HumanObject() {
		super(null);
	}
	
	@Override
	public void writeTo(OutputStream out) throws IOException {
		super.writeTo(out);
		
		out.write(dataPers);
		out.write(connPoint);
		
	}

	@Override
	public void readFrom(InputStream in) throws IOException {
		super.readFrom(in);
		
		dataPers = in.read();
		connPoint = in.read();
	}
	
	@Override
	public Unit getUnit() {
		return dataPers.human;
	}
	
	@Override
	public void pulse() {
		//客户端是否已完成玩家的加载并登陆到地图前 不做任何操作
//		if(!isClientStageReady) {
//			return;
//		}
//		Log.temp.info("我是一个可爱的小蛇：{}", name);
		
		//先执行通用操作
		super.pulse();
	}
	
	
	/**
	 * 获取玩家信息，玩家进入地图时能够被其他玩家看到的基础信息
	 */
	@Override
	public DStageObject.Builder createMsg() {
		Human human = dataPers.human;
		
		//移动中的目标路径
//		List<DVector2> runPath = running.getRunPathMsg();
		
		//玩家信息单元
		DStageHuman.Builder h = DStageHuman.newBuilder();
//		h.addAllPosEnd(runPath);
		h.setLevel(human.getLevel());
		h.setHpCur(human.getHpCur());
		h.setHpMax(human.getHpMax());
		h.setMpCur(human.getMpCur());
		h.setMpMax(human.getMpMax());
		h.setSex(human.getSex());
		h.setProfession(human.getProfession());
		h.setPvpMode(human.getPvpMode());
		h.setInFighting(human.isInFighting());


		
		DStageObject.Builder objInfo = DStageObject.newBuilder();
		objInfo.setObjId(id);
		objInfo.setType(EWorldObjectType.HUMAN);
		objInfo.setName(name);
		objInfo.setModelSn(modelSn);
		objInfo.setPos(posNow.toMsg());
		objInfo.setHuman(h);
		
		return objInfo;
	}
	
	
	
	/**
	 * 发送消息至玩家
	 * @param builder
	 */
	public void sendMsg(Builder builder) {
		if(builder == null) return ;
		
		sendMsg(builder.build());
	}
	
	/**
	 * 发送消息至玩家
	 * @param builder
	 */
	public void sendMsg(Message msg) {
		if(msg == null) return ;
		
		//玩家连接信息
		ConnectionProxy prx = ConnectionProxy.newInstance(connPoint.nodeId, connPoint.portId, connPoint.servId);
		prx.sendMsg(MsgIds.getIdByClass(msg.getClass()), new Chunk(msg));
	}
	
	
	/**
	 * 将玩家注册到地图中 暂不显示
	 * @param stageObj
	 */
	public void stageRegister(StageObject stageObj) {
		//断线重连等情况下，会出现注册玩家前，可能会残留之前的数据
		//这里调用数据的原坐标，能避免坐标差距，造成客户端人物位置改变。
		HumanObject humanObjOld = stageObj.getHumanObj(id);
		if(humanObjOld != null) {
			posNow = humanObjOld.posNow;
		}
		
		//调用父类实现
		super.stageRegister(stageObj);
	}
	
	/**
	 * 玩家下线时进行清理
	 * @param humanObj
	 */
	public void connCloseClear() {
		//发布退出事件
		Event.fireEx(EventKey.HUMAN_LOGOUT, stageObj.sn, "humanObj", this);

		//清理
		HumanGlobalServiceProxy hgsprx = HumanGlobalServiceProxy.newInstance();
		hgsprx.cancel(id);
	}
	
	/**
	 * 获取玩家当前stageId
	 * @param human
	 * @return
	 */
	public long getStageNowId() {
		return getStageLastIds().get(0);
	}
	
	/**
	 * 返回玩家之前经历的地图路径的id集合，历史靠近的地图在list的index较小的位置
	 * @param human
	 * @return
	 */
	public List<Long> getStageLastIds() {
		List<Long> res = new ArrayList<>();
		JSONArray ja = JSON.parseArray(dataPers.human.getStageHistory());
		
		for(Object obj : ja) {
			JSONArray jaTemp = JSON.parseArray(obj.toString());
			res.add(jaTemp.getLongValue(0));
		}
		
		return res;
	}
	
	/**
	 * 获取玩家在地图历史中某张地图的坐标
	 * @param humanObj
	 * @param stageId
	 * @return
	 */
	public Vector2 getStagePos(long stageId) {
		Vector2 vector = new Vector2(-1, -1);
		Human human = dataPers.human;
		
		JSONArray ja = JSON.parseArray(human.getStageHistory());
		for(Object obj : ja) {
			JSONArray jaTemp = JSON.parseArray(obj.toString());
			if(stageId == jaTemp.getLongValue(0)) {
				vector.x = jaTemp.getIntValue(2);
				vector.y = jaTemp.getIntValue(3);
			}
		}
		
		return vector;
	}
	
	/**
	 * 设置当前地图历史路径的x，y坐标
	 * @param x
	 * @param y
	 */
	public void setStagePos(int x, int y) {
		Human human = dataPers.human;
		
		JSONArray ja = JSON.parseArray(human.getStageHistory());
		JSONArray jaTemp = JSON.parseArray(ja.getString(0));
		jaTemp.set(2, x);
		jaTemp.set(3, y);
		
		ja.set(0, jaTemp);
		
		human.setStageHistory(ja.toJSONString());
	}
}
