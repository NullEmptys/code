package org.gof.demo.worldsrv.character;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.gof.core.Port;
import org.gof.demo.worldsrv.entity.Unit;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.SCStageMoveStop;
import org.gof.demo.worldsrv.stage.StageCell;
import org.gof.demo.worldsrv.stage.StageObject;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.Running;
import org.gof.demo.worldsrv.support.Vector2;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;


/**
 * 角色基类
 * 包含移动、战斗等
 */
public abstract class UnitObject extends WorldObject {
	
	public Running running = new Running(this);	 //玩家移动信息
	
	public boolean canMove = true;																		//是否可移动
	public boolean canCastSkill = true;																	//是否可以施放技能
	public boolean canAttack = true;																	//能否普通攻击
		
	public abstract Unit getUnit();
	
	public UnitObject(StageObject stageObj) {
		super(stageObj);
	
	
	}
	
	public boolean isDie() {
		return getUnit().getHpCur() <= 0;
	}
	
	
	public boolean isHumanObj() {
		return this instanceof HumanObject;
	}
	
	public boolean isMonsterObj() {
		return this instanceof MonsterObject;
	}
	
	@Override
	public void pulse() {
		long curr = Port.getTime();
		//单元移动了
		pulseMove(curr);
		
	}
	
	/**
	 * 地图单元移动
	 * @param posFrom
	 * @param posTo
	 */
	public void move(Vector2 posFrom, List<Vector2> posTo) {
		if(!isInWorld()) return;
		if(!canMove) return;
		
		//移动过于频繁，忽略这次消息
		if(!running.isTimeExpired()) {
			return;
		}
		//修正起点
		if(isHumanObj()) {
			posFrom.set(running.correctPosFrom(posFrom));
		}
		
		//修正所有点，如果连续两个点相同，则移出后一个
		Vector2 pos = new Vector2();
		pos.set(posFrom);
		Iterator<Vector2> it = posTo.iterator();
		while(it.hasNext()) {
			Vector2 posNext = it.next();
			if(pos.equals(posNext)) {
				it.remove();
				continue;
			}
			pos.set(posNext);
		}
		
		//目标点为空
		if(posTo.isEmpty()) return;
		
		if(this.isHumanObj()) {
			Event.fire(EventKey.HUMAN_MOVE_START_BEFORE, "humanObj", this);
			Event.fire(EventKey.HUMAN_ACTS_BEFORE, "humanObj", this);
		}
		
		//移动
		running._move(posFrom, posTo, getUnit().getSpeed());
		
		/*if(this.isHumanObj()) {
			Log.temp.error("地图单元({})开始移动，起始位置{}，接下来的目标为{}。", this.name, posFrom.getPosStr(), running.getRunPathMsg());
		}*/
		
		//发送消息给前端
		Msg.SCStageMove.Builder move = Msg.SCStageMove.newBuilder();
		move.setObjId(id);
		move.setPosBegin(posFrom.toMsg());
		move.addAllPosEnd(running.getRunPathMsg());			
		stageManager.sendMsgToArea(move, stageObj, posNow);
		
		//抛出开始移动的事件
		Event.fire(EventKey.UNIT_MOVE_START, "unitObj", this);
		Event.fire(EventKey.UNIT_ACT, "unitObj", this);
		if(this.isHumanObj()) {
			Event.fire(EventKey.HUMAN_MOVE_START, "humanObj", this);
			Event.fire(EventKey.HUMAN_ACT, "humanObj", this);
		} else {
			Event.fire(EventKey.MONSTER_MOVE_START, "monsterObj", this);
			Event.fire(EventKey.MONSTER_ACT, "monsterObj", this);
		}
		
		//记录日志
		if(this.isHumanObj()) {
			HumanObject human = (HumanObject)this;
			if(Log.stageMove.isInfoEnabled()) {
				Log.stageMove.info("角色({})开始移动，起始位置{}，接下来的目标为{}。", human.dataPers.human.getName(), posFrom.getPosStr(), running.getRunPathMsg());
			}
		} else {
			if(Log.stageMove.isInfoEnabled()) {
				Log.stageMove.info("地图单元({})开始移动，起始位置{}，接下来的目标为{}。", this.name, posFrom.getPosStr(), running.getRunPathMsg());
			}
		}
		
	}
	
	/**
	 * 地图单元移动
	 * @param timeCurr 当前时间
	 */
	public void pulseMove(long timeCurr) {
		if(!isInWorld()) return;
		if(!running.isRunning()) return;
		//单元移动了
		StageCell cellBegin = stageCell;
		running._pulse();
		StageCell cellEnd = stageObj.getCell(posNow);
		stageCell = cellEnd;
		// 判断玩家有没有跨地图格了
		if(cellBegin != null && !cellEnd.equals(cellBegin)) { // 跨地图格了
			stageManager.cellChanged(cellBegin, cellEnd, this);
		}
	}
	
	/**
	 * 强制单元停止
	 * 
	 */
	public void stop() {
		if(!running.isRunning()) return;
		
		//停止移动
		running._stop();
		
		//发送消息
		SCStageMoveStop.Builder msgStop = SCStageMoveStop.newBuilder();
		msgStop.setObjId(id);
		msgStop.setPosEnd(posNow.toMsg());
		stageManager.sendMsgToArea(msgStop, stageObj, posNow);
	}
}