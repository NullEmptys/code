package org.gof.demo.worldsrv.stage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.gof.core.Node;
import org.gof.core.Port;
import org.gof.core.scheduler.ScheduleTask;
import org.gof.core.support.Distr;
import org.gof.core.support.ManagerBase;
import org.gof.core.support.Param;
import org.gof.core.support.SysException;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.character.WorldObject;
import org.gof.demo.worldsrv.config.ConfStage;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.SCStageEnterResult;
import org.gof.demo.worldsrv.msg.Msg.SCStageObjectAppear;
import org.gof.demo.worldsrv.msg.Msg.SCStageObjectDisappear;
import org.gof.demo.worldsrv.support.D;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.Vector2;
import org.gof.demo.worldsrv.support.observer.EventKey;
import org.gof.demo.worldsrv.support.observer.Listener;

import com.google.protobuf.Message;
import com.google.protobuf.Message.Builder;


public class StageManager extends ManagerBase {
	
	/**
	 * 游戏启动时 创建主地图
	 * @param params
	 * @throws Exception 
	 */
	@Listener(EventKey.GAME_STARTUP_BEFORE)
	public void onGameStartupBefore(Param params) throws Exception {
		Node node = params.get("node");
		
		//初始化地图
		for(int i = 0; i < D.PORT_STAGE_STARTUP_NUM; ++i) {
			//拼PortId
			String portId = D.PORT_STAGE_PREFIX + i;
			
			//验证启动Node
			String nodeId = Distr.getNodeId(portId);
			if(!node.getId().equals(nodeId)) {
				continue;
			}
			
			//创建地图Port
			StagePort portStage = new StagePort(portId);
			portStage.startup(node);
			
			//默认服务
			StageService stageServ = new StageService(portStage);
			stageServ.startup();
			portStage.addService(stageServ);
			
			//测试2个基本场景
//			if(i == 0) {
//				portStage.createCommonSafe(1000);
//				portStage.createCommonSafe(1001);
//			}
			
			//加载下属主地图
			List<ConfStage> stages = ConfStage.findBy(ConfStage.K.portId, portId, ConfStage.K.type, "common");
			for(ConfStage s : stages) {
				portStage.createCommonSafe(s.sn);
			}
		}
	}
	
	/**
	 * 获取实例
	 * @return
	 */
	public static StageManager getInstance() {
		return getInstance(StageManager.class);
	}
	
	/**
	 * 创建普通地图
	 * @param stageSn
	 */
	public StageObject createCommon(int stageSn) {
		StagePort port = (StagePort)Port.getCurrent();

		StageObject stage = new StageObject(port, stageSn, stageSn);
		stage.startup();
		
		return stage;
	}
	
	/**
	 * 发送消息至玩家
	 */
	public void sendMsgToHumans(Builder builder, Collection<HumanObject> humans) {
		for(HumanObject human : humans) {
			human.sendMsg(builder);
		}
	}
	
	/**
	 * 发送消息至地图中的全部玩家
	 */
	public void sendMsgToStage(Builder builder, StageObject stageObj) {
		sendMsgToHumans(builder, stageObj.getHumanObjs().values());
	}

	/**
	 * 发送消息至九宫格中的全部玩家
	 */
	public void sendMsgToArea(Builder builder, StageObject stageObj, Vector2 pos) {
		sendMsgToHumans(builder, getHumanObjsInArea(stageObj, pos));
	}
	
	/**
	 * 获取某张地图中以某个地图格为中心的九宫格
	 * @param stageObjId
	 * @param cellId
	 * @return
	 */
	public List<StageCell> getCellsInArea(StageObject stageObj, StageCell cell) {
		List<StageCell> result = new ArrayList<>();
		
		int i = cell.i;
		int j = cell.j;
		
		int [] is = {i - 1, i, i + 1};
		int [] js = {j - 1, j, j + 1};
		for(int y : js) {
			for(int x : is) {
				StageCell temp = stageObj.getCell(x, y);
				if(temp == null) continue;
				result.add(temp);
			}
		}
		return result;
	}
	
	public List<HumanObject> getHumanObjsInArea(StageObject stageObj, Vector2 pos) {
		//获取九宫格
		StageCell cell = stageObj.getCell(pos);
		List<StageCell> cells = getCellsInArea(stageObj, cell);
		
		//在九宫格中获取玩家
		List<HumanObject> result = new ArrayList<>();
		for(StageCell c : cells) {
			for(HumanObject ho : c.getHumans().values()) {
				result.add(ho);
			}
		}
		
		return result;
	}
	
	/**
	 * 地图单元跨地图格，不只是人，还可能是怪物等
	 * @param cellBegin
	 * @param cellEnd
	 * @param objId
	 */
	public void cellChanged(StageCell cellBegin, StageCell cellEnd, WorldObject obj) {
		//不是同一张地图内
		if(!cellBegin.isInSameStage(cellEnd)) {
			throw new SysException("严重错误！地图单元跨不同地图的地图格");
		}
		//没跨格
		if(cellBegin.equals(cellEnd)) return;
		
		StageObject stageObj = obj.stageObj;
		if(Log.stageMove.isDebugEnabled()) {
			Log.stageMove.debug("地图单元跨地图格子了，objId={}，cellBegin={}，cellEnd={}", obj.id, cellBegin.i + "," + cellBegin.j, cellEnd.i + "," + cellEnd.j);
		}
		//把obj从旧的区域移走，加入到新的区域
		cellBegin.delWorldObject(obj);
		cellEnd.addWorldObject(obj);
		
		//通知旧的区域有地图单位离开
		List<StageCell> cellsLeave = getCellsChangedLeave(stageObj, cellBegin, cellEnd);
		SCStageObjectDisappear.Builder msgObjDisappear = obj.createMsgDisappear();
		for(StageCell cell : cellsLeave) {
			for(HumanObject humanObj : cell.getHumanObjects().values()) {
				if(humanObj.id == obj.id) continue;
				//发送消息
				humanObj.sendMsg(msgObjDisappear);
				if(Log.stageMove.isInfoEnabled()) {
					Log.stageMove.info("移动单元{}从{}的视野中消失", obj.id, humanObj.name);
				}
			}
		}
		
		//通知新的区域有物体进入
		SCStageObjectAppear.Builder msgObjAppear = obj.createMsgAppear();
		
		List<StageCell> cellsNew = this.getCellChangedEnter(stageObj, cellBegin, cellEnd);
		for(StageCell cell : cellsNew) {
			for(HumanObject humanObj : cell.getHumanObjects().values()) {
				if(humanObj.id == obj.id) continue;
				//发送消息
				humanObj.sendMsg(msgObjAppear);
				if(Log.stageMove.isInfoEnabled()) {
					Log.stageMove.info("移动单元{}名字为{}出现在{}的视野中", obj.id, humanObj.name);
				}
			}
		}
		
		//给玩家发送周围信息
		if(obj instanceof HumanObject) {
			HumanObject humanObj = (HumanObject)obj;
			//离开格子中的东西
			for(StageCell cell : cellsLeave) {
				for(WorldObject o : cell.getWorldObjects().values()) {
					humanObj.sendMsg(o.createMsgDisappear());
				}
			}
			//新增格子中的东西
			for(StageCell cell : cellsNew) {
				for(WorldObject wo : cell.getWorldObjects().values()) {
					if(wo.id == obj.id) continue;
					if(!wo.isInWorld()) continue;
					humanObj.sendMsg(wo.createMsgAppear());
				}
			}
		}
	}
	
	/**
	 * 获取进入新区域后，新九宫格对比旧九宫格的增加区域。
	 * @param stageObjId
	 * @param cellBegin
	 * @param cellEnd
	 * @return
	 */
	private List<StageCell> getCellChangedEnter(StageObject stageObj, StageCell cellBegin, StageCell cellEnd) {
		//新旧区域
		List<StageCell> begin = getCellsInArea(stageObj, cellBegin);
		List<StageCell> end = getCellsInArea(stageObj, cellEnd);

		//取出新增部分
		List<StageCell> result = new ArrayList<>();
		for(StageCell c : end) {
			if(begin.contains(c))
				continue;

			result.add(c);
		}

		return result;
	}
	
	/**
	 * 获取进入新区域后，新九宫格对比旧九宫格减少的区域。
	 * @param stageObjId
	 * @param cellBegin
	 * @param cellEnd
	 * @return
	 */
	private List<StageCell> getCellsChangedLeave(StageObject stageObj, StageCell cellBegin, StageCell cellEnd) {
		//新旧区域
		List<StageCell> begin = getCellsInArea(stageObj, cellBegin);
		List<StageCell> end = getCellsInArea(stageObj, cellEnd);
		
		//取出减少部分
		List<StageCell> result = new ArrayList<>();
		for(StageCell c : begin) {
			if(end.contains(c)) continue;
			
			result.add(c);
		}
		
		return result;
	}
	
	
	/**
	  * 通过坐标来获取区九宫格域内所有单元
	 * @param stageObj
	 * @param pos
	 * @return
	 */
	public List<WorldObject> getWorldObjsInArea(StageObject stageObj, Vector2 pos) {
		//获取九宫格
		StageCell cell = stageObj.getCell(pos);
		List<StageCell> cells = this.getCellsInArea(stageObj, cell);
		
		//在九宫格中获取地图单元
		List<WorldObject> result = new ArrayList<>();
		for(StageCell c : cells) {
			for(WorldObject wo : c.getWorldObjects().values()) {
				result.add(wo);
			}
		}
		
		return result;
	}
	
	
	/**
	 * 将玩家拉到当前地图上的某个位置
	 * @param humanObj
	 * @param vector
	 */
	public void pullTo(HumanObject humanObj, Vector2 vector) {
		//原地点发送消失消息
		humanObj.stageHide();
		
		humanObj.posNow = vector;
		
		//通知前端刷新到当前点
		Msg.SCStagePullTo.Builder msgPull = Msg.SCStagePullTo.newBuilder();
		msgPull.setPos(humanObj.posNow.toMsg());
		humanObj.sendMsg(msgPull.build());
		
		SCStageEnterResult.Builder msgER = SCStageEnterResult.newBuilder();
		for(WorldObject o : getWorldObjsInArea(humanObj.stageObj, humanObj.posNow)) {
			if(!o.isInWorld()) continue;
			if(o.equals(humanObj)) continue;

			msgER.addObj(o.createMsg());
		}
		humanObj.sendMsg(msgER);
		
		//从现在的地点出现
		humanObj.stageShow();
	}
	
	/**
	 * 切换地图,尽量用此处方法，这里会加延迟切换并且改变玩家状态
	 * @param humanObj
	 * @param stageTargetId
	 * @param posAppear						//切换地图后的出现位置，为null的话出现在默认位置
	 */
	public void switchTo(final HumanObject humanObj, final long stageTargetId, final Vector2 posAppear) {
		
		Port port = Port.getCurrent();
		
		//切换地图加200ms延迟，并且改变用户状态设置为切换地图中
		port.getService(D.SERV_STAGE_DEFAULT).scheduleOnce(new ScheduleTask() {
			@Override
			public void execute() {
				//切换地图
				StageGlobalServiceProxy prx = StageGlobalServiceProxy.newInstance();
				prx.switchToStage(humanObj, stageTargetId, posAppear);
				
				//设置玩家状态为正在切换地图中
				humanObj.isStageSwitching = true;
			}
		}, 200);
		
	}
	
	
}
