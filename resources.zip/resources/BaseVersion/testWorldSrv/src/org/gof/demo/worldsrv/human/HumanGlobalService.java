package org.gof.demo.worldsrv.human;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.gof.core.connsrv.ConnectionProxy;
import org.gof.core.gen.proxy.DistrClass;
import org.gof.core.gen.proxy.DistrMethod;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.common.GamePort;
import org.gof.demo.worldsrv.common.GameServiceBase;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.SCHumanKick;
import org.gof.demo.worldsrv.support.D;
import org.gof.demo.worldsrv.support.I18n;
import org.gof.demo.worldsrv.support.Log;

import com.google.protobuf.Message;

@DistrClass(
	servId = D.SERV_HUMAN_GLOBAL,
	importClass = {HumanGlobalInfo.class ,  List.class, Message.class} 
)
public class HumanGlobalService extends GameServiceBase {
	private HumanGlobalManager manager = HumanGlobalManager.getInstance();
	
	//玩家状态信息
	private Map<Long, HumanGlobalInfo> datas = new HashMap<>();
	
	public HumanGlobalService(GamePort port) {
		super(port);
	}
	
	@Override
	protected void init() {
		
	}
	
	/**
	 * 注册玩家全局信息
	 * @param status
	 */
	@DistrMethod
	public void register(HumanGlobalInfo status) {
		datas.put(status.id, status);
	}
	
	
	
	/**
	 * 玩家是否已登录
	 * @param account
	 */
	@DistrMethod
	public void isLogined(String account) {
		boolean logined = false;
		long humanId = 0;
		for(HumanGlobalInfo h : datas.values()) {
			if(StringUtils.equals(account, h.account)) {
				logined = true;
				humanId = h.id;
				break;
			}
		}
		
		port.returns("logined", logined, "humanId", humanId);
	}
	
	/**
	 * 踢出玩家
	 * @param id
	 * @param reason
	 */
	@DistrMethod
	public void kick(long id, String reason) {
		kickHuman(id, reason);
	}
	
	
	/**
	 * 踢人下线
	 * @param connPoint
	 * @param msg
	 */
	private void kickHuman(long humanId, String reason) {
		//发送消息 通知玩家被踢
		SCHumanKick.Builder msg = SCHumanKick.newBuilder();
		msg.setReason(reason);
		sendMsg(humanId, msg.build());
		
		//玩家连接信息
		HumanGlobalInfo info = datas.get(humanId);
		
		//断开连接
		ConnectionProxy prx = ConnectionProxy.newInstance(info.connPoint);
		prx.close();
	}
	
	/**
	 * 发送消息至玩家
	 * @param builder
	 */
	@DistrMethod
	public void sendMsg(long humanId, Message msg) {
		//玩家连接信息
		HumanGlobalInfo info = datas.get(humanId);
		
		if(info == null) return ;
		manager.sendMsg(info.connPoint, msg);
	}
	
	/**
	 * 发送消息至全服玩家，有要排除的则设置excludeIds
	 * @param excludeIds
	 * @param msg
	 */
	@DistrMethod
	public void sendMsgToAll(List<Long> excludeIds, Message msg) {
		// 给所有玩家发送消息
		for(HumanGlobalInfo info : datas.values()) {
			// 排除不需要发送的玩家id
			if(excludeIds.contains(info.id)) continue;
			manager.sendMsg(info.connPoint, msg);
		}
	}
	
	/**
	 * 清楚玩家全局信息
	 * @param status
	 */
	@DistrMethod
	public void cancel(long humanId) {
		datas.remove(humanId);
	}
	
	@DistrMethod
	public void stageIdModify(long humanId, long stageIdNew, String stageName, String nodeId, String portId) {
		HumanGlobalInfo info = datas.get(humanId);
		
		//特殊处理
		if(info == null) {
			Log.human.error("修改玩家全局地图信息时出错，玩家数据不存在："
							+ "humanId={}, stageIdNew={}, stageName={}, nodeId={}, portId={}",
							humanId, stageIdNew, stageName, nodeId, portId);
			return;
		}
		
		//更新地图ID
		info.stageId = stageIdNew;
		info.stageName = stageName;
		info.nodeId = nodeId;
		info.portId = portId;
	}
}