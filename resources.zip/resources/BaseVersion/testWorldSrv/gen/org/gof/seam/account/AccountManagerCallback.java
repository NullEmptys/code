package org.gof.seam.account;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class AccountManagerCallback {
	public static final String _result_characterLogin = "_result_characterLogin";
	public static final String _result_characterLogin2 = "_result_characterLogin2";
	public static final String _result_login = "_result_login";
	public static final String _result_login2 = "_result_login2";
	public static final String _result_queryCharacters = "_result_queryCharacters";
}
