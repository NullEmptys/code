package org.gof.demo.worldsrv.msg;

import java.util.HashMap;
import java.util.Map;

import com.google.protobuf.Message;
import org.gof.core.support.SysException;

public class MsgIds {
	public static final int CSLogin = 11;
	public static final int SCLoginResult = 12;
	public static final int CSAccountReconnect = 21;
	public static final int SCAccountReconnectResult = 22;
	public static final int CSQueryCharacters = 1003;
	public static final int SCQueryCharactersResult = 1004;
	public static final int CSCharacterCreate = 1005;
	public static final int SCCharacterCreateResult = 1006;
	public static final int CSCharacterDelete = 1007;
	public static final int SCCharacterDeleteResult = 1008;
	public static final int CSCharacterLogin = 1009;
	public static final int SCCharacterLoginResult = 1010;
	public static final int SCInitData = 1101;
	public static final int SCHumanKick = 1200;
	public static final int CSStageEnter = 1201;
	public static final int SCStageEnterResult = 1202;
	public static final int CSStageSwitch = 1203;
	public static final int SCStageSwitch = 1204;
	public static final int CSStageMove = 1211;
	public static final int SCStageMove = 1212;
	public static final int SCStageSetPos = 1213;
	public static final int CSStageMoveStop = 1214;
	public static final int SCStageMoveStop = 1215;
	public static final int SCStageObjectAppear = 1216;
	public static final int SCStageObjectDisappear = 1217;
	public static final int SCStageMoveTeleport = 1220;
	public static final int CSStageMove2 = 1222;
	public static final int SCStagePullTo = 1226;
	
	//消息CLASS与消息ID的对应关系<消息class, 消息ID>
	private static final Map<Class<? extends Message>, Integer> classToId = new HashMap<>();
	//消息ID与消息CLASS的对应关系<消息ID, 消息class>
	private static final Map<Integer, Class<? extends Message>> idToClass = new HashMap<>();
	
	static {
		//初始化消息CLASS与消息ID的对应关系
		initClassToId();
		//初始化消息ID与消息CLASS的对应关系
		initIdToClass();
	}
	
	/**
	 * 获取消息ID
	 * @param clazz
	 * @return
	 */
	public static int getIdByClass(Class<? extends Message> clazz) {
		return classToId.get(clazz);
	}
	
	/**
	 * 获取消息CLASS
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getClassById(int msgId) {
		return (T) idToClass.get(msgId);
	}
	
	/**
	 * 获取消息名称
	 * @param clazz
	 * @return
	 */
	public static String getNameById(int msgId) {
		try {
			return idToClass.get(msgId).getSimpleName();
		} catch (Exception e) {
			throw new SysException(e, "获取消息名称是发生错误：msgId={0}", msgId);
		}
	}
	
	/**
	 * 初始化消息CLASS与消息ID的对应关系
	 */
	private static void initClassToId() {
		classToId.put(Msg.CSLogin.class, CSLogin);
		classToId.put(Msg.SCLoginResult.class, SCLoginResult);
		classToId.put(Msg.CSAccountReconnect.class, CSAccountReconnect);
		classToId.put(Msg.SCAccountReconnectResult.class, SCAccountReconnectResult);
		classToId.put(Msg.CSQueryCharacters.class, CSQueryCharacters);
		classToId.put(Msg.SCQueryCharactersResult.class, SCQueryCharactersResult);
		classToId.put(Msg.CSCharacterCreate.class, CSCharacterCreate);
		classToId.put(Msg.SCCharacterCreateResult.class, SCCharacterCreateResult);
		classToId.put(Msg.CSCharacterDelete.class, CSCharacterDelete);
		classToId.put(Msg.SCCharacterDeleteResult.class, SCCharacterDeleteResult);
		classToId.put(Msg.CSCharacterLogin.class, CSCharacterLogin);
		classToId.put(Msg.SCCharacterLoginResult.class, SCCharacterLoginResult);
		classToId.put(Msg.SCInitData.class, SCInitData);
		classToId.put(Msg.SCHumanKick.class, SCHumanKick);
		classToId.put(Msg.CSStageEnter.class, CSStageEnter);
		classToId.put(Msg.SCStageEnterResult.class, SCStageEnterResult);
		classToId.put(Msg.CSStageSwitch.class, CSStageSwitch);
		classToId.put(Msg.SCStageSwitch.class, SCStageSwitch);
		classToId.put(Msg.CSStageMove.class, CSStageMove);
		classToId.put(Msg.SCStageMove.class, SCStageMove);
		classToId.put(Msg.SCStageSetPos.class, SCStageSetPos);
		classToId.put(Msg.CSStageMoveStop.class, CSStageMoveStop);
		classToId.put(Msg.SCStageMoveStop.class, SCStageMoveStop);
		classToId.put(Msg.SCStageObjectAppear.class, SCStageObjectAppear);
		classToId.put(Msg.SCStageObjectDisappear.class, SCStageObjectDisappear);
		classToId.put(Msg.SCStageMoveTeleport.class, SCStageMoveTeleport);
		classToId.put(Msg.CSStageMove2.class, CSStageMove2);
		classToId.put(Msg.SCStagePullTo.class, SCStagePullTo);
	}
	
	/**
	 * 初始化消息ID与消息CLASS的对应关系
	 */
	private static void initIdToClass() {
		idToClass.put(CSLogin, Msg.CSLogin.class);
		idToClass.put(SCLoginResult, Msg.SCLoginResult.class);
		idToClass.put(CSAccountReconnect, Msg.CSAccountReconnect.class);
		idToClass.put(SCAccountReconnectResult, Msg.SCAccountReconnectResult.class);
		idToClass.put(CSQueryCharacters, Msg.CSQueryCharacters.class);
		idToClass.put(SCQueryCharactersResult, Msg.SCQueryCharactersResult.class);
		idToClass.put(CSCharacterCreate, Msg.CSCharacterCreate.class);
		idToClass.put(SCCharacterCreateResult, Msg.SCCharacterCreateResult.class);
		idToClass.put(CSCharacterDelete, Msg.CSCharacterDelete.class);
		idToClass.put(SCCharacterDeleteResult, Msg.SCCharacterDeleteResult.class);
		idToClass.put(CSCharacterLogin, Msg.CSCharacterLogin.class);
		idToClass.put(SCCharacterLoginResult, Msg.SCCharacterLoginResult.class);
		idToClass.put(SCInitData, Msg.SCInitData.class);
		idToClass.put(SCHumanKick, Msg.SCHumanKick.class);
		idToClass.put(CSStageEnter, Msg.CSStageEnter.class);
		idToClass.put(SCStageEnterResult, Msg.SCStageEnterResult.class);
		idToClass.put(CSStageSwitch, Msg.CSStageSwitch.class);
		idToClass.put(SCStageSwitch, Msg.SCStageSwitch.class);
		idToClass.put(CSStageMove, Msg.CSStageMove.class);
		idToClass.put(SCStageMove, Msg.SCStageMove.class);
		idToClass.put(SCStageSetPos, Msg.SCStageSetPos.class);
		idToClass.put(CSStageMoveStop, Msg.CSStageMoveStop.class);
		idToClass.put(SCStageMoveStop, Msg.SCStageMoveStop.class);
		idToClass.put(SCStageObjectAppear, Msg.SCStageObjectAppear.class);
		idToClass.put(SCStageObjectDisappear, Msg.SCStageObjectDisappear.class);
		idToClass.put(SCStageMoveTeleport, Msg.SCStageMoveTeleport.class);
		idToClass.put(CSStageMove2, Msg.CSStageMove2.class);
		idToClass.put(SCStagePullTo, Msg.SCStagePullTo.class);
	}
}

