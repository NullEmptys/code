package org.gof.demo.worldsrv.human;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class HumanManagerCallback {
	public static final String _result_loadHumanDataMain = "_result_loadHumanDataMain";
}
