package org.gof.demo.worldsrv.common;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class HumanCreateApplyServiceCallback {
	public static final String _result_apply = "_result_apply";
}
