package org.gof.seam.msg;

import org.gof.core.support.MsgHandler;
import org.gof.core.support.Param;
import org.gof.core.support.observer.MsgSender;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.msg.MsgIds;

import com.google.protobuf.GeneratedMessage;

public class HumanExtendMsgHandler extends MsgHandler {
	private HumanExtendMsgHandler() {}
	
	@Override
	protected void fire(GeneratedMessage msg, Param param) {
		//如果用户正在切换地图中，则不接受任何请求
		HumanObject humanObj = param.get("humanObj");
		if(humanObj.isStageSwitching) {
			return ;
		}
		
		MsgParam mp = new MsgParam(msg);
		mp.setHumanObject(humanObj);
		
		//输出当前人物动作 刨除移动
//		if(!(msg instanceof CSStageMove) && !(msg instanceof CSStageMoveStop)) {
//			Log.temp.info(humanObj.name + " " +msg.getClass());
//		}
		
		MsgSender.fire(mp);
	}
	
	@Override
	protected Class<?> getClassById(int msgId) {
		return MsgIds.getClassById(msgId);
	}
}