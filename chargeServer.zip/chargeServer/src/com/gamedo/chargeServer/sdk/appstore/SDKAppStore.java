package com.gamedo.chargeServer.sdk.appstore;

import java.util.Map;
import com.gamedo.chargeServer.constants.Log;
import com.gamedo.chargeServer.util.JSONUtil;

/**
 * appstore
 * 
 * @author IPOC-HUANGPING
 *
 */
public class SDKAppStore {

	private static final SDKAppStore sdkAppStore = new SDKAppStore();

//	private static Logger logger = LoggerFactory.getLogger(SDKAppStore.class);

	public static SDKAppStore getInstance() {
		return sdkAppStore;
	}

	@SuppressWarnings("unchecked")
	public static Map<String, Object> check(String receipt) {
		// 跟苹果验证获取返回结果------------------
		String verifyUrl = IOSVerify.getEnvironment(receipt);
		Log.charge.info("验证地址" + verifyUrl);
		String verifyResult = IOSVerify.buyAppVerify(receipt, verifyUrl);
		if (verifyResult == null) {
			return null;
		}
		Log.charge.info("验证后的结果" + verifyResult);
		Map<String, Object> res = JSONUtil.fromJson(verifyResult, Map.class);

		// 解码orderinfo------------------
		try {
			// String orderInfos = RSAUtil.decrypt(rsaKey, orderinfo, "utf-8");
			// res.put("info", JSONUtil.fromJson(orderInfos, Map.class));
		} catch (Exception e) {
			Log.charge.warn(e.getMessage());
			return null;
		}

		// 返回结果------------------
		return res;
	}
}
