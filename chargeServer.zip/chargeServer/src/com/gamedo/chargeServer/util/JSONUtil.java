package com.gamedo.chargeServer.util;

import java.io.IOException;

import org.codehaus.jackson.map.ObjectMapper;
import org.hibernate.mapping.Map;

import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;


public class JSONUtil {
	private static JSONSerializer serializer = new JSONSerializer();
	private static ObjectMapper objectMapper = new ObjectMapper();
	static {
		serializer.exclude("*.class");
	}

	private JSONUtil() {
	}


	public static String toJson(Object obj) {
		return serializer.deepSerialize(obj);
	}

	public static <T> T fromJson(String json, Class<T> clazz) {
		JSONDeserializer<T> deser = new JSONDeserializer<T>();
		return deser.deserialize(json, clazz);
	}

	public static <T> T fromJsonList(String json, Class<?> clazz) {
		JSONDeserializer<T> deser = new JSONDeserializer<T>();
		return (T) deser.use("values", clazz).deserialize(json);
	}

	/**
	 * ʹ�ö������json�����л���
	 * 
	 * @param json
	 *            json��
	 * @param pojoClass
	 *            ������
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static Object decodeJson(String json, Class pojoClass)
			throws Exception {
		try {
			return objectMapper.readValue(json, pojoClass);
		} catch (Exception e) {
			throw e;
		}
	}
	
	public static Map decodeMap(String json) {
		ObjectMapper mapper = new ObjectMapper();
        try
        {
            return mapper.readValue(json, Map.class);
        } catch (IOException e)
        {
            e.printStackTrace();
        }
		return null;
	}
	
	/**
	 * ���������л���
	 * 
	 * @param o
	 *            ʵ�����
	 * @return ���л���json
	 * @throws Exception
	 */
	public static String encodeJson(Object o) throws Exception {
		try {
			return objectMapper.writeValueAsString(o);
		} catch (Exception e) {
			throw e;
		}
	}
}
