package com.gamedo.chargeServer.scheduled;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component 
public class TimesServiceImpl implements ITimesService {

	@Scheduled(cron = "0/1 * * ? * *") // ÿ��ִ��һ��
	public void job() {
		System.out.println("ִ�ж�ʱ����");
	}

}
