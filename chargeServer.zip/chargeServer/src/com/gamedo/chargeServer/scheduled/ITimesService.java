package com.gamedo.chargeServer.scheduled;

public interface ITimesService {
	public void job();
}
