package com.gamedo.chargeServer.controller.appstore;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.chargeServer.constants.AppSdkState;
import com.gamedo.chargeServer.constants.ChargeState;
import com.gamedo.chargeServer.constants.Log;
import com.gamedo.chargeServer.constants.OrderType;
import com.gamedo.chargeServer.controller.BaseController;
import com.gamedo.chargeServer.domain.ChargeOrder;
import com.gamedo.chargeServer.message.CommonResponseMessage;
import com.gamedo.chargeServer.message.Packet;
import com.gamedo.chargeServer.message.appstore.AppStoreVerifyRequestMessage;
import com.gamedo.chargeServer.message.appstore.AppStoreVerifyResponseMessage;
import com.gamedo.chargeServer.sdk.appstore.IOSVerify;
import com.gamedo.chargeServer.sdk.appstore.SDKAppStore;
import com.gamedo.chargeServer.service.ChargeHandleService;
import com.gamedo.chargeServer.util.BASE64Util;
import com.gamedo.chargeServer.util.CommonResponse;
import com.gamedo.chargeServer.util.HttpRequester;
import com.gamedo.chargeServer.util.HttpRespons;
import com.gamedo.chargeServer.util.JSONUtil;

/**
 * appstore������֤
 * 
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = "/iosReceiptServerChchk")
public class PayResultVerifyController extends BaseController {

	@Autowired
	private ChargeHandleService chargeHandleService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void doService(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(request, response);
		AppStoreVerifyRequestMessage verifyRequest = (AppStoreVerifyRequestMessage) packet
				.getRequestMessage(AppStoreVerifyRequestMessage.class);

		AppStoreVerifyResponseMessage verifyResponse = new AppStoreVerifyResponseMessage();
		String receipt = verifyRequest.getReceipt();
		int playerId = verifyRequest.getPlayerID();
		int goodsId = verifyRequest.getRechargeItemID();
		float payMoney = verifyRequest.getPayMoney();
		Log.charge.debug(
				"receipt = " + receipt + "playerId = " + playerId + "goodsId = " + goodsId + "payMoney = " + payMoney);
		if (receipt == null) {
			verifyResponse.setCode(CommonResponseMessage.FALSE);
			verifyResponse.setIndicate(0);
			packet.send(verifyResponse);
		}
		receipt = BASE64Util.getFromBASE64(receipt);
		Log.charge.info("receipt = " + receipt);
		@SuppressWarnings("static-access")
		Map<String, Object> resMap = SDKAppStore.getInstance().check(receipt);
		if (resMap == null) {
			verifyResponse.setCode(CommonResponseMessage.FALSE);
			verifyResponse.setIndicate(AppSdkState.FAIL.getId());
			Log.charge.error("����У��ʧ��resMapΪ��");
			packet.send(verifyResponse);
			return;
		}
		Log.charge.info("status = " + resMap.get("status"));
		if (resMap.get("status").equals(AppSdkState.SUCCESS.getId())) {
			@SuppressWarnings("unchecked")
			Map<String, Object> objMap = (Map<String, Object>) resMap.get("receipt");
			ChargeOrder chargeOrder = chargeHandleService.getPayOrder(objMap.get("transaction_id").toString());
			if (chargeOrder == null) {
				chargeOrder = this.generageChargeOrder(objMap, goodsId, playerId);
				chargeOrder.setPayPrice(payMoney);
				String verifyUrl = IOSVerify.getEnvironment(receipt);
				if (verifyUrl != null && verifyUrl.equals("Sandbox")) {
					chargeOrder.setSummary("appstore���Ե�ַ����");
				}
				chargeHandleService.generateOrder(chargeOrder);
			}
			Log.charge.debug("��ֵ�����Ķ�����Ϣ" + chargeOrder.toString());
			if (chargeOrder.getOrderState() != ChargeState.SUCCESS.getState()) {
				chargeOrder.setNotifyTime(new Date());
				Map<String, String> data = new HashMap<String, String>();
				data.put("OrderNum", chargeOrder.getOrderNumber());
				data.put("playerID", "" + playerId);
				data.put("goodsId", "" + goodsId);

				HttpRequester httpRequest = new HttpRequester();
				HttpRespons httpRespons = null;
				try {
					String url = ChargeHandleService.Url;
					httpRespons = httpRequest.sendPost(url, data);
					String content = httpRespons.getContent();
					CommonResponse rsp = (CommonResponse) JSONUtil.decodeJson(content, CommonResponse.class);
					if (rsp.getCode() == 0) {
						chargeOrder.setReceiveNotifyTime(new Date());
						chargeOrder.setOrderState(ChargeState.SUCCESS.getState());
						chargeHandleService.finishSuccess(chargeOrder);
						Log.charge.info("��ֵ�ɹ�" + chargeOrder.toString());
					} else {
						chargeOrder.setOrderState(ChargeState.FAIL.getState());
						chargeHandleService.finishSuccess(chargeOrder);
						Log.charge.error("֪ͨ��Ϸ���쳣-----" + chargeOrder.toString());
					}
					verifyResponse.setCode(CommonResponseMessage.TRUE);
					verifyResponse.setIndicate(AppSdkState.SUCCESS.getId());
					packet.send(verifyResponse);
					return;
				} catch (Exception e) {
					e.printStackTrace();
					Log.charge.error("֪ͨ��Ϸ���쳣-----" + chargeOrder.toString());
				}
			} else {
				Log.charge.info("�����Ѿ����------" + chargeOrder.toString());
				verifyResponse.setCode(CommonResponseMessage.FALSE);
				verifyResponse.setIndicate(AppSdkState.FAIL.getId());
				packet.send(verifyResponse);
				return;
			}
		}
		Log.charge.error("����У��ʧ��");
		verifyResponse.setCode(CommonResponseMessage.FALSE);
		verifyResponse.setDesc(resMap.get("status").toString());
		verifyResponse.setIndicate(AppSdkState.FAIL.getId());
		packet.send(verifyResponse);
		return;
	}

	private ChargeOrder generageChargeOrder(Map<String, Object> resMap, int itemId, int playerId) {
		ChargeOrder chargeOrder = new ChargeOrder();
		chargeOrder.setOrderNumber(resMap.get("transaction_id").toString());
		chargeOrder.setChannelId("appstore");
		chargeOrder.setGoodsId(itemId);
		chargeOrder.setCreateTime(new Date());
		chargeOrder.setPayBackTime(new Date());
		chargeOrder.setOrderState(ChargeState.CREATE.getState());
		chargeOrder.setOrderType(String.valueOf(OrderType.NORMAL.getId()));
		chargeOrder.setPlayerId(playerId);
		return chargeOrder;
	}

}
