package com.gamedo.chargeServer.controller.appstore;

public class AppStorePayController {

}
