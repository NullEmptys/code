package com.gamedo.chargeServer.dao;

import org.hibernate.SessionFactory;

public class DefaultSessionFactory {

	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public static void setSessionFactory(SessionFactory sessionFactory) {
		DefaultSessionFactory.sessionFactory = sessionFactory;
	}

}
