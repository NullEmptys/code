package com.gamedo.chargeServer.dao.charge;

import org.springframework.stereotype.Component;

import com.gamedo.chargeServer.dao.GenericHibernateDAO;
import com.gamedo.chargeServer.domain.ChargeOrder;

/**
 * ��ֵ������¼
 * @author IPOC-HUANGPING
 *
 */
@Component
public class ChargeRecordDao extends GenericHibernateDAO<ChargeOrder,Integer>{
	
	/**
	 * ���ݶ����Ż�ȡ������¼
	 * @param orderNumber
	 * @return
	 */
	public ChargeOrder getChargeRecordByOrderNumber(String orderNumber){
		return (ChargeOrder) uniqueResult("from ChargeOrder c where c.orderNumber = ?0", orderNumber);
	}
	
}
