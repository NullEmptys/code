package com.gamedo.chargeServer.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * ��ֵ����ģ��
 * 
 * @author IPOC-HUANGPING
 *
 */
public class ChargeOrder implements Serializable {

	/** ���л�id */
	private static final long serialVersionUID = 1L;

	private int id;

	/** ��ɫid */
	private int playerId;
	/** ����id */
	private String channelId;
	/** �������� */
	private String subChannelId;
	/** ������ */
	private String orderNumber;
	/** �����û�����Ʒ��Ϣ */
	private int goodsId;
	/** ���ѽ�� */
	private float payPrice;
	/** ����״̬ */
	private int orderState;
	/** ֧����ʽ */
	private String payway;
	/** ��ע */
	private String summary;
	/**��������*/
	private String orderType;
	/** ��������ʱ�� */
	private Date createTime;
	/** ��ֵ���յ�֧���ص���ʱ�� */
	private Date payBackTime;
	/** ��ֵ��֪ͨ��Ϸ��ʱ�� */
	private Date notifyTime;
	/** ��Ϸ���յ���ֵ��֪ͨʱ�� */
	private Date receiveNotifyTime;
	/** ��Ϸ�������ɹ�ʱ�� */
	private Date finishTime;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getSubChannelId() {
		return subChannelId;
	}

	public void setSubChannelId(String subChannelId) {
		this.subChannelId = subChannelId;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public int getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(int goodsId) {
		this.goodsId = goodsId;
	}

	public float getPayPrice() {
		return payPrice;
	}

	public void setPayPrice(float payPrice) {
		this.payPrice = payPrice;
	}

	public int getOrderState() {
		return orderState;
	}

	public void setOrderState(int orderState) {
		this.orderState = orderState;
	}

	public String getPayway() {
		return payway;
	}

	public void setPayway(String payway) {
		this.payway = payway;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getPayBackTime() {
		return payBackTime;
	}

	public void setPayBackTime(Date payBackTime) {
		this.payBackTime = payBackTime;
	}

	public Date getNotifyTime() {
		return notifyTime;
	}

	public void setNotifyTime(Date notifyTime) {
		this.notifyTime = notifyTime;
	}

	public Date getReceiveNotifyTime() {
		return receiveNotifyTime;
	}

	public void setReceiveNotifyTime(Date receiveNotifyTime) {
		this.receiveNotifyTime = receiveNotifyTime;
	}

	public Date getFinishTime() {
		return finishTime;
	}

	public void setFinishTime(Date finishTime) {
		this.finishTime = finishTime;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	@Override
	public String toString() {
		return "ChargeOrder [id=" + id + ", playerId=" + playerId + ", channelId=" + channelId + ", subChannelId="
				+ subChannelId + ", orderNumber=" + orderNumber + ", goodsId=" + goodsId + ", payPrice=" + payPrice
				+ ", orderState=" + orderState + ", payway=" + payway + ", summary=" + summary + ", createTime="
				+ createTime + ", payBackTime=" + payBackTime + ", notifyTime=" + notifyTime + ", receiveNotifyTime="
				+ receiveNotifyTime + ", finishTime=" + finishTime + ", orderType=" + orderType + "]";
	}

}