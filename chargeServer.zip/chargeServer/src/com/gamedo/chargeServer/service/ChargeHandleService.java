package com.gamedo.chargeServer.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gamedo.chargeServer.dao.charge.ChargeRecordDao;
import com.gamedo.chargeServer.domain.ChargeOrder;

/**
 * ������ֵ��¼
 * @author IPOC-HUANGPING
 *
 */
@Service
public class ChargeHandleService implements ChargeHandle{

	@Autowired
	private ChargeRecordDao chargeRecordDao;
//	public static final String Url = "http://fz.xdsyh.gamedo.com.cn/gameServer/app/appstoreCharge";
	public static final String Url = "http://cz.xdsyh.gamedo.com.cn:8082/gameServer/app/appstoreCharge";
	
	@Override
	public void generateOrder(ChargeOrder chargeOrder) {
		chargeRecordDao.newEntity(chargeOrder);
	}

	@Override
	public ChargeOrder getPayOrder(String orderNumber) {
		return chargeRecordDao.getChargeRecordByOrderNumber(orderNumber);
	}

	@Override
	public void chargeSuccess(ChargeOrder chargeOrder) {
		chargeRecordDao.updateEntity(chargeOrder);
	}

	@Override
	public void finishSuccess(ChargeOrder chargeOrder) {
		chargeOrder.setFinishTime(new Date());
		chargeRecordDao.updateEntity(chargeOrder);
	}

	
}
