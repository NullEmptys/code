package com.gamedo.chargeServer.message;

/**
 * 
 * @author libm
 *
 */
public class CommonResponseMessage {
	
	public static final String TRUE = "0";
	
	public static final String FALSE = "1";
	
	public static final String TOKEN_ERROR = "2";

	private String code = FALSE;
	
	private String desc;
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
