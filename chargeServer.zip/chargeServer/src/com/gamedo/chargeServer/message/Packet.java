package com.gamedo.chargeServer.message;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.gamedo.chargeServer.constants.Log;
import com.gamedo.chargeServer.util.JSONUtil;

public class Packet {

	private HttpServletRequest request;

	private HttpServletResponse response;

	/* �ͻ��������������Ϣ���� */
	private Object requestMessage;
	/* ���������ؿͻ�����Ϣ���� */
	private Object responseMessage;

	public Packet(HttpServletRequest request, HttpServletResponse response) {
		this.request = request;
		this.response = response;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public Object getRequestMessage(Class object) {
		String content = "";
		java.io.BufferedReader reader = null;
		try {
			reader = request.getReader();// ����ַ���
			StringBuffer sb = new StringBuffer();
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\r\n");
			}
			content = sb.toString();
			int beginIndex = content.indexOf("{");
			int endIndex = content.lastIndexOf("}");
			content = content.substring(beginIndex, endIndex + 1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
				reader = null;
			} catch (Exception e) {
			}
		}

		try {
			Log.charge.debug("content = " + content);
			requestMessage = JSONUtil.decodeJson(content, object);
			Log.charge.debug("receiveMessage = " + content);
			return requestMessage;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public Map<String,Object> getRequestMessageMap(Class object) {
		String content = "";
		java.io.BufferedReader reader = null;
		try {
			reader = request.getReader();// ����ַ���
			StringBuffer sb = new StringBuffer();
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\r\n");
			}
			content = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
				reader = null;
			} catch (Exception e) {
			}
		}

		try {
			return JSONUtil.fromJson(content,Map.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Object getRequestMessage() {
		return requestMessage;
	}

	public void setRequestMessage(Map<String, Object> requestMessage) {
		this.requestMessage = requestMessage;
	}

	public Object getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(Object responseMessage) {
		this.responseMessage = responseMessage;
	}

	public void send(Object responseMessage) {
		try {
			String message = JSONUtil.encodeJson(responseMessage);
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.getOutputStream().write(message.getBytes("utf-8"));
			Log.charge.debug("sendClientMessage=" + message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getIpAddr() {
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}

}
