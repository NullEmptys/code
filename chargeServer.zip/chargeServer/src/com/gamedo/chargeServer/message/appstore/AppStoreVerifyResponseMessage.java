package com.gamedo.chargeServer.message.appstore;

import com.gamedo.chargeServer.message.CommonResponseMessage;

public class AppStoreVerifyResponseMessage extends CommonResponseMessage{
	private int indicate;

	public int getIndicate() {
		return indicate;
	}

	public void setIndicate(int indicate) {
		this.indicate = indicate;
	}
	
	
}
