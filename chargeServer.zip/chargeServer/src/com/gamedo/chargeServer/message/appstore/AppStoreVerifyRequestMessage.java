package com.gamedo.chargeServer.message.appstore;

import com.gamedo.chargeServer.message.CommonRequestMessage;

public class AppStoreVerifyRequestMessage extends CommonRequestMessage{
	private String receipt;
	private int rechargeItemID;//�ͻ�������
	private float payMoney;//֧�����

	public int getRechargeItemID() {
		return rechargeItemID;
	}

	public void setRechargeItemID(int rechargeItemID) {
		this.rechargeItemID = rechargeItemID;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public float getPayMoney() {
		return payMoney;
	}

	public void setPayMoney(float payMoney) {
		this.payMoney = payMoney;
	}
}
