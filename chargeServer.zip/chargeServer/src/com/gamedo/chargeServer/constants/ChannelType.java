package com.gamedo.chargeServer.constants;

/**
 * ������Ϣ
 * @author IPOC-HUANGPING
 *
 */
public enum ChannelType {

	SELF("0","��Ӫ����");
	
	String channelId;
	String name;
	
	private ChannelType(String channelId,String name) {
		this.channelId = channelId;
		this.name = name;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public static ChannelType getChannelType(String channelId) {
		for(ChannelType type : ChannelType.values()) {
			if(type.getChannelId().equals(channelId)) {
				return type;
			}
		}
		return null;
	}
	
}

