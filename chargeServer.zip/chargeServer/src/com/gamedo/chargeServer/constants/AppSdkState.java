package com.gamedo.chargeServer.constants;

public enum AppSdkState {
	SUCCESS(0, "appstore sdk ����У��ɹ�"),
	FAIL(1, "appstore sdk����У��ʧ��");

	private int id;
	private String description;

	private AppSdkState(int id, String description) {
		this.id = id;
		this.description = description;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
