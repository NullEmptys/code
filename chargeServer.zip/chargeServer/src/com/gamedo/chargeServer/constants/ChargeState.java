package com.gamedo.chargeServer.constants;

/**
 * ��ֵ״̬
 * @author IPOC-HUANGPING
 *
 */
public enum ChargeState {

	CREATE(0,"��������"),
	CHARGE_NOTIFY(1,"֪ͨ��Ϸ��"),
	SUCCESS(2,"������ҳ�ֵ�ɹ�"),
	FAIL(3,"������ҳ�ֵʧ��");
	
	int state;
	String desc;
	
	private ChargeState(int state,String desc) {
		this.state = state;
		this.desc = desc;
	}
	
	public static ChargeState getByState(int state) {
		for(ChargeState chargeState : ChargeState.values()) {
			if(chargeState.getState() == state) {
				return chargeState;
			}
		}
		return null;
	}
	
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
}

