package com.gamedo.chargeServer.constants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Log {
	public static Logger charge = LoggerFactory.getLogger("CHARGE");
}
