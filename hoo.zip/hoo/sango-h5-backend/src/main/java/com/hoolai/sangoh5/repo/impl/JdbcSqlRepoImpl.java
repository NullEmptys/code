package com.hoolai.sangoh5.repo.impl;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.hoolai.sango.util.DateUtil;
import com.hoolai.sangoh5.bo.payment.PayLog;
import com.hoolai.sangoh5.bo.union.Union;
import com.hoolai.sangoh5.bo.user.PayOrder;
import com.hoolai.sangoh5.bo.user.RegisterUser;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.repo.JdbcSqlRepo;

@Repository("jdbcSqlRepo")
public class JdbcSqlRepoImpl implements JdbcSqlRepo {

    private static final Log logger = LogFactory.getLog(JdbcSqlRepoImpl.class);

    public static final String PAY_ORDER_TABLE = "_pay_orders_wanba";//"_pay_orders";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Long> queryByOrderIdAndPlatformName(String tableName, String orderId, String platformName) {
        return jdbcTemplate.queryForList("select user_id from " + tableName + " where platform_order_id = ? and platform_name = ?;", new Object[] { orderId, platformName },
                Long.class);
    }

    @Override
    public void addPayLog(String tableName, PayLog payLog) {
        jdbcTemplate.update(
                "insert into " + tableName
                        + " (user_id,game_order_id,platform_order_id,amount,src_amount,success_time,product_id,notify_time,platform_name) values (?,?,?,?,?,?,?,?,?);",
                new PreparedStatementSetter() {

                    @Override
                    public void setValues(PreparedStatement ps) throws SQLException {
                        ps.setLong(1, payLog.getUserId());
                        ps.setString(2, payLog.getGameOrderId());
                        ps.setString(3, payLog.getPlatformOrderId());
                        ps.setInt(4, payLog.getAmount());
                        ps.setInt(5, payLog.getSrcAmount());
                        ps.setDate(6, new Date(payLog.getSuccessTime().getTime()));
                        ps.setString(7, payLog.getProductId());
                        ps.setDate(8, new Date(payLog.getNotifyTime().getTime()));
                        ps.setString(9, payLog.getPlatformName());
                    }
                });

    }

    @Override
    public PayOrder findOrderByBillno(String billno) {
        String date = DateUtil.currentYearMonth();
        try {
            PayOrder order = jdbcTemplate.queryForObject("select * from " + date + PAY_ORDER_TABLE + " where billno=?", new Object[] { billno }, new PayOrderRowMapper());
            return order;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<PayOrder> findOrderByUserId(int userId) {
        String date = DateUtil.currentYearMonth();
        try {
            List<PayOrder> orders = jdbcTemplate.query("select * from " + date + PAY_ORDER_TABLE + " where userid=?", new Object[] { userId }, new PayOrderRowMapper());
            return orders;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<PayOrder> findOrdersByDate(int datetime) {
        String date = DateUtil.currentYearMonth();
        try {
            List<PayOrder> orders = jdbcTemplate.query("select * from " + date + PAY_ORDER_TABLE + " where date=?", new Object[] { datetime }, new PayOrderRowMapper());
            return orders;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<PayOrder> findOrdersByOpenId(String openid) {
        String date = DateUtil.currentYearMonth();
        try {
            List<PayOrder> orders = jdbcTemplate.query("select * from " + date + PAY_ORDER_TABLE + " where openid=?", new Object[] { openid }, new PayOrderRowMapper());
            return orders;
        } catch (Exception e) {
            return null;
        }
    }

    public static class PayOrderRowMapper implements RowMapper<PayOrder> {

        @Override
        public PayOrder mapRow(ResultSet rs, int rowNum) throws SQLException {
            PayOrder order = PayOrder.dbPayOrder();
            order.setId(rs.getInt("id"));
            order.setDate(rs.getInt("date"));
            order.setTime(rs.getTimestamp("time"));
            order.setOpenid(rs.getString("openid"));
            order.setUserid(rs.getLong("userid"));
            order.setVip(rs.getBoolean("is_vip"));
            order.setAmount(rs.getInt("amount"));
            order.setSrcAmount(rs.getInt("src_amount"));
            order.setItemId(rs.getString("item_id"));
            order.setItemNum(rs.getInt("item_num"));
            order.setBillno(rs.getString("billno"));
            order.setGameId(rs.getInt("game_id"));
            order.setServerId(rs.getInt("server_id"));
            // add some other attribute here
            return order;
        }
    }

    @Override
    public boolean insertOrder(final PayOrder payOrder) {
        String date = DateUtil.currentYearMonth();
        PayOrderPreparedStatementSetter setter = new PayOrderPreparedStatementSetter(payOrder, date);
        return jdbcTemplate.update(setter.sql(), setter) == 1;
    }

    private static class PayOrderPreparedStatementSetter implements PreparedStatementSetter {

        private final PayOrder payOrder;

        private final String date;

        public PayOrderPreparedStatementSetter(PayOrder payOrder, String date) {
            super();
            this.payOrder = payOrder;
            this.date = date;
        }

        public String sql() {
            return "insert into " + date + PAY_ORDER_TABLE + "(date, time, openid, userid, is_vip, amount, src_amount, " + "item_id, item_num, billno, game_id, server_id) "
                    + "values(?,?,?,?,?,?,?,?,?,?,?,?)";
        }

        @Override
        public void setValues(PreparedStatement ps) throws SQLException {
            ps.setInt(1, payOrder.getDate());
            ps.setTimestamp(2, payOrder.getTime());
            ps.setString(3, payOrder.getOpenid());
            ps.setLong(4, payOrder.getUserid());
            ps.setBoolean(5, payOrder.isVip());
            ps.setInt(6, payOrder.getAmount());
            ps.setInt(7, payOrder.getSrcAmount());
            ps.setString(8, payOrder.getItemId());
            ps.setInt(9, payOrder.getItemNum());
            ps.setString(10, payOrder.getBillno());
            ps.setInt(11, payOrder.getGameId());
            ps.setInt(12, payOrder.getServerId());
            // add some other attribute here
        }
    }

    @Override
    public void initUnion() {
        try {
            jdbcTemplate.execute("CREATE TABLE `lianmeng` (" + "`lm_name` varchar(255) NOT NULL," + "`lm_id` bigint(20) NOT NULL," + "`lm_state` int(10) NOT NULL,"
                    + "PRIMARY KEY (`lm_id`,`lm_name`)" + ") ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        } catch (Exception e) {
            System.out.println(" ------- table union is error!!!!");
            e.printStackTrace();
        }
    }

    @Override
    public void modifyUnion(final Union union) {

        jdbcTemplate.update("update lianmeng set lm_name = ? where lm_id = ? and lm_state = ? ;", new PreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1, union.getUnionName());
                ps.setLong(2, union.getUnionId());
                ps.setInt(3, union.getState());
            }
        });
    }

    @Override
    public void addUnion(final Union union) {
        jdbcTemplate.update("insert into lianmeng (lm_name,lm_id,lm_state) values (?,?,?);", new PreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1, union.getUnionName());
                ps.setLong(2, union.getUnionId());
                ps.setInt(3, union.getState());
            }
        });
    }

    @Override
    public List<Long> queryForLikeName(int sangoState, String likeName) {
        return jdbcTemplate.queryForList("select lm_id from lianmeng where lm_state = ? and lm_name like ?;", new Object[] { sangoState, "%" + likeName + "%" }, Long.class);
    }

    @Override
    public void removeUnion(final Union union) {
        jdbcTemplate.update("delete from lianmeng where lm_name = ? and lm_id = ? and lm_state = ?;", new PreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1, union.getUnionName());
                ps.setLong(2, union.getUnionId());
                ps.setInt(3, union.getState());
            }
        });
    }

    @Override
    public boolean unionNameIsExist(String unionName) {
        List<Long> list = jdbcTemplate.queryForList("select lm_id from lianmeng where lm_name = ?;", new Object[] { unionName }, Long.class);
        return list == null ? false : list.size() > 0;
    }

    @Override
    public void addUser(User user) {
        jdbcTemplate.update("insert into users (userId, userName) values (?,?);", new PreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setLong(1, user.getId());
                ps.setString(2, user.getName());
            }
        });
    }

    @Override
    public void modifyUserName(User user) {
        jdbcTemplate.update("update users set userName = ? where userId = ?;", new PreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1, user.getName());
                ps.setLong(2, user.getId());
            }
        });
    }

    @Override
    public int queryUserCount4LikeName(String likeName) {
        return jdbcTemplate.query("select count(userId) as count from users where userName like ?;", new PreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1, "%" + likeName.trim() + "%");
            }
        }, new ResultSetExtractor<Integer>() {

            @Override
            public Integer extractData(ResultSet rs) throws SQLException, DataAccessException {
                rs.next();
                return rs.getInt(1);
            }
        });
    }

    @Override
    public List<Long> queryUserList4LikeName(int from, int num, String likeName) {
        return jdbcTemplate.queryForList("select userId from users where userName like ? limit ?,?;", new Object[] { "%" + likeName.trim() + "%", from, num }, Long.class);
    }

    @Override
    public boolean isExistUserName(String userName) {
        int a = (Integer) jdbcTemplate.queryForObject("select count(*) as count from user where name = ?", new Object[] { userName }, new RowMapper<Object>() {

            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                Integer count = rs.getInt("count");
                return count;
            }
        });
        if (a > 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean regUser(final RegisterUser registerUser) {
        try {
            jdbcTemplate.update("insert into user " + "(platformId, name, password, id_card, real_name) " + "values(?, ?, ?, ?, ?)", new PreparedStatementSetter() {

                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, registerUser.getPlatformId());
                    ps.setString(2, registerUser.getName());
                    ps.setString(3, registerUser.getPassword());
                    ps.setString(4, registerUser.getIdCard());
                    ps.setString(5, registerUser.getRealName());
                }
            });
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public RegisterUser findRegisterUserByName(String userName) {
        try {
            return (RegisterUser) jdbcTemplate.queryForObject("select * from user where name=?", new Object[] { userName }, new RowMapper<Object>() {

                @Override
                public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                    RegisterUser registerUser = new RegisterUser();
                    registerUser.setId(rs.getLong("id"));
                    registerUser.setName(rs.getString("name"));
                    registerUser.setIdCard(rs.getString("id_card"));
                    registerUser.setPassword(rs.getString("password"));
                    registerUser.setPlatformId(rs.getString("platformId"));
                    registerUser.setRealName(rs.getString("real_name"));
                    return registerUser;
                }
            });
        } catch (Exception e) {
            //e.printStackTrace();
            return null;
        }
    }

    @Override
    public RegisterUser findRegisterUserByPlatformId(String platformId) {
        try {
            return jdbcTemplate.queryForObject("select * from user where platformId=?", new Object[] { platformId }, new RowMapper<RegisterUser>() {

                @Override
                public RegisterUser mapRow(ResultSet rs, int rowNum) throws SQLException {
                    RegisterUser registerUser = new RegisterUser();
                    registerUser.setId(rs.getLong("id"));
                    registerUser.setName(rs.getString("name"));
                    registerUser.setIdCard(rs.getString("id_card"));
                    registerUser.setPassword(rs.getString("password"));
                    registerUser.setPlatformId(rs.getString("platformId"));
                    registerUser.setRealName(rs.getString("real_name"));
                    return registerUser;
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void updateRegisterUser(final RegisterUser registerUser) {
        try {
            jdbcTemplate.update("update user set platformId=?, password=? where id=?", new PreparedStatementSetter() {

                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, registerUser.getPlatformId());
                    ps.setString(2, registerUser.getPassword());
                    ps.setLong(3, registerUser.getId());
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
