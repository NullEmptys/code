package com.hoolai.sangoh5.bo.battle.enhance.buff;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.DefencePassiveSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class DefensiveShieldBuff extends Buff {

    private DefencePassiveSkill skill;

    public DefensiveShieldBuff(int targetUsedSkillXmlId, FightUnitName executeName, boolean is4front, int currentLevel, DefencePassiveSkill skill) {
        super(targetUsedSkillXmlId, skill.getName(), executeName, currentLevel);
        this.isForFront = is4front;
        this.skill = skill;
    }

    @Override
    public void apply(FightUnit target) {
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        alive.removeCounterAttackSkills(skill);
        alive.addBattleLog(alive.name() + "" + skill.getXmlId() + "[" + skillName + "]防御技能结束");
    }

    @Override
    protected DefensiveShieldBuff clone() {
        DefensiveShieldBuff buff = (DefensiveShieldBuff) super.clone(new DefensiveShieldBuff(this.targetUsedSkillXmlId, executeName, isForFront, currentLevel, skill));
        return buff;
    }

}
