package com.hoolai.sangoh5.bo.battle.skill;


public enum ForceDirection {

	NONE,// 表示只对现匹配的target有效
	X,// 横向几个格子内的敌方都有效
	Y,// 竖向几个格子内的敌方都有效
	XY // 横竖几个格子内的敌方都有效
	;
	
	public static ForceDirection convert(String direction){
		if("0".equals(direction)){
			return ForceDirection.NONE;
		}else{
			return ForceDirection.valueOf(direction.toUpperCase());
		}
	}
}
