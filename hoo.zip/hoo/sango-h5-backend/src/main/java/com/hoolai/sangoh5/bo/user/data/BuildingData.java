package com.hoolai.sangoh5.bo.user.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;
@Component
public class BuildingData extends JsonData<BuildingProperty>{

	@PostConstruct
	public void init() {
		try {
    		initData("com/hoolai/sangoh5/base.json", BuildingProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void checkProperty(BuildingProperty property) {
		// TODO Auto-generated method stub
		
	}


}
