package com.hoolai.sangoh5.bo.militaryRank.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class MilitaryRankProperty extends JsonProperty {

    /**
     * 军衔名称
     */
    private String name;

    /**
     * 提升需要军功
     */
    private int exploit;

    /**
     * 当前军衔等级可以解锁的士兵
     */
    private int[] openSoldier;

    /**
     * 士兵训练时间减少比例 单位是%
     */
    private int trainSoldierTimeDec;

    /**
     * 训练士兵数量增值
     */
    private int trainSoldierNumAdd;

    /**
     * 士兵训练所需金币减少比例
     */
    private int trainSoldierGoldDec;

    /**
     * PVP功勋加成比例
     */
    private int honorNumAdd;

    /**
     * PVP战斗次数增加
     */
    private int pvpFightNumAdd;

    /**
     * 粮草上限增加
     */
    private int foodLimitAdd;

    /**
     * PVE每关攻打次数增加
     */
    private int pveTimesAdd;

    /**
     * 排位战购买次数增加
     */
    private int qualifyBuyTimesAdd;

    /**
     * 悬赏购买次数增加
     */
    private int bountyBuyTimeAdd;

    /**
     * 招募解锁新将领
     */
    private int[] recruitOfficer;

    /**
     * 每次招降扣除忠诚度数量增加
     */
    private int deductLoyaltyAdd;

    /**
     * 联盟捐献积分增加
     */
    private int[] donateIntegrateAdd;

    /**
     * 悬赏次数增加
     */
    private int bountyNumAdd;

    /**
     * 免费令牌招募次数增加
     */
    private int normalRecNumAdd;

    /**
     * 拥有奴隶增加
     */
    private int slaveNumAdd;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getExploit() {
        return exploit;
    }

    public void setExploit(int exploit) {
        this.exploit = exploit;
    }

    public int getNormalRecNumAdd() {
        return normalRecNumAdd;
    }

    public void setNormalRecNumAdd(int normalRecNumAdd) {
        this.normalRecNumAdd = normalRecNumAdd;
    }

    public int getBountyNumAdd() {
        return bountyNumAdd;
    }

    public void setBountyNumAdd(int bountyNumAdd) {
        this.bountyNumAdd = bountyNumAdd;
    }

    public int[] getOpenSoldier() {
        return openSoldier;
    }

    public void setOpenSoldier(int[] openSoldier) {
        this.openSoldier = openSoldier;
    }

    public int getTrainSoldierTimeDec() {
        return trainSoldierTimeDec;
    }

    public void setTrainSoldierTimeDec(int trainSoldierTimeDec) {
        this.trainSoldierTimeDec = trainSoldierTimeDec;
    }

    public int getTrainSoldierNumAdd() {
        return trainSoldierNumAdd;
    }

    public void setTrainSoldierNumAdd(int trainSoldierNumAdd) {
        this.trainSoldierNumAdd = trainSoldierNumAdd;
    }

    public int getTrainSoldierGoldDec() {
        return trainSoldierGoldDec;
    }

    public void setTrainSoldierGoldDec(int trainSoldierGoldDec) {
        this.trainSoldierGoldDec = trainSoldierGoldDec;
    }

    public int getHonorNumAdd() {
        return honorNumAdd;
    }

    public void setHonorNumAdd(int honorNumAdd) {
        this.honorNumAdd = honorNumAdd;
    }

    public int getPvpFightNumAdd() {
        return pvpFightNumAdd;
    }

    public void setPvpFightNumAdd(int pvpFightNumAdd) {
        this.pvpFightNumAdd = pvpFightNumAdd;
    }

    public int getFoodLimitAdd() {
        return foodLimitAdd;
    }

    public void setFoodLimitAdd(int foodLimitAdd) {
        this.foodLimitAdd = foodLimitAdd;
    }

    public int getPveTimesAdd() {
        return pveTimesAdd;
    }

    public void setPveTimesAdd(int pveTimesAdd) {
        this.pveTimesAdd = pveTimesAdd;
    }

    public int getQualifyBuyTimesAdd() {
        return qualifyBuyTimesAdd;
    }

    public void setQualifyBuyTimesAdd(int qualifyBuyTimesAdd) {
        this.qualifyBuyTimesAdd = qualifyBuyTimesAdd;
    }

    public int getBountyBuyTimeAdd() {
        return bountyBuyTimeAdd;
    }

    public void setBountyBuyTimeAdd(int bountyBuyTimeAdd) {
        this.bountyBuyTimeAdd = bountyBuyTimeAdd;
    }

    public int[] getRecruitOfficer() {
        return recruitOfficer;
    }

    public void setRecruitOfficer(int[] recruitOfficer) {
        this.recruitOfficer = recruitOfficer;
    }

    public int getDeductLoyaltyAdd() {
        return deductLoyaltyAdd;
    }

    public void setDeductLoyaltyAdd(int deductLoyaltyAdd) {
        this.deductLoyaltyAdd = deductLoyaltyAdd;
    }

    public int[] getDonateIntegrateAdd() {
        return donateIntegrateAdd;
    }

    public void setDonateIntegrateAdd(int[] donateIntegrateAdd) {
        this.donateIntegrateAdd = donateIntegrateAdd;
    }

    public int getSlaveNumAdd() {
        return slaveNumAdd;
    }

    public void setSlaveNumAdd(int slaveNumAdd) {
        this.slaveNumAdd = slaveNumAdd;
    }

}
