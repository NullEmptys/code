package com.hoolai.sangoh5.bo.battle.skill.soldier.defence.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.DefencePassiveSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 绝对防御第一次伤害
 * 
 * @author liqing
 *
 */
public class AbsoluteDefense extends DefencePassiveSkill {

    private boolean isDoDefence;

    @Override
    public void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {
        if (effect == null || effect.getDeltaHp() < 1 || actor.isDead() || target.isDead()) {
            return;
        }
        if (!isDoDefence) {
            isDoDefence = true;
            int del = effect.getDeltaHp();
            effect.setDeltaHp(0);
            target.removeBuff(buff);
            target.addBuff(new Buff(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name()));
            target.addBattleLog(target.name() + "触发绝对防御，防御伤害=" + del);
        }
    }

    @Override
    public Skill clone() {
        return super.clone(new AbsoluteDefense());
    }

}
