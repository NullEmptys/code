package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class MingYunYiJi extends BaseOfficerPhysicsSkill {

    @Override
    public Skill clone() {
        return super.clone(new MingYunYiJi());
    }

    private float[] perArr = null;

    private final float INTEVAL = 10f;

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        FightUnit target = actor.getDefender();
        if (target != null) {
            target.addEffect(new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withDeltaHp(calLostPoint(actor, target))
                    .withTargetName(target.name()).withHurtPercentage(percentage * 100));
            targets.add(target);
        }

        return targets;
    }

    private int calLostPoint(FightUnit actor, FightUnit target) {
        if (perArr == null) {
            int two = Math.round(twoPercentage * 100f);
            int one = Math.round(percentage * 100f);

            int len = Math.round((two - one) / INTEVAL) + 1;
            perArr = new float[len];
            for (int i = 0; i < len; i++) {
                perArr[i] = Float.valueOf(one + i * INTEVAL) / 100f;
            }
        }
        this.percentage = perArr[pg.getRandomNumber(0, perArr.length - 1)];
        return calculateLostPoint4Skill(actor, target);
    }
}
