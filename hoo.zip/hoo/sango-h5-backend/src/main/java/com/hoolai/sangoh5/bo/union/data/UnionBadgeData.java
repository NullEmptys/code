package com.hoolai.sangoh5.bo.union.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.union.UnionBadgeProperty;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class UnionBadgeData extends JsonData<UnionBadgeProperty> {

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/unionBadge.json", UnionBadgeProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void checkProperty(UnionBadgeProperty property) {
        // TODO Auto-generated method stub

    }

}
