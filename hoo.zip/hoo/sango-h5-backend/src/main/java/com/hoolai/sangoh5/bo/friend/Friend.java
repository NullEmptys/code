package com.hoolai.sangoh5.bo.friend;

public class Friend implements Comparable<Friend> {

    public static final int FRINED_PLATFORM_TYPE = 0;

    private long userId;

    private String name;

    private String image;

    private int level;

    private int militaryRank;//军衔等级

    private String militaryName;

    private boolean isFriend;

    public Friend(long userId, String name, String image, int level, int militaryRank, String militaryName) {
        this.userId = userId;
        this.name = name;
        this.image = image;
        this.level = level;
        this.militaryRank = militaryRank;
        this.militaryName = militaryName;
    }

    public long getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getImage() {
        return image;
    }

    public int getLevel() {
        return level;
    }

    public int getMilitaryRank() {
        return militaryRank;
    }

    public String getMilitaryName() {
        return militaryName;
    }

    public boolean isFriend() {
        return isFriend;
    }

    public void isMyFriend() {
        this.isFriend = true;
    }

    @Override
    public int compareTo(Friend f2) {
        // 先排等级、后排军衔
        if (this.getLevel() > f2.getLevel()) {
            return 1;
        } else if (this.getLevel() == f2.getLevel()) {
            if (this.getMilitaryRank() > f2.getMilitaryRank()) {
                return 1;
            } else if (this.getMilitaryRank() == f2.getMilitaryRank()) {
                return 0;
            } else {
                return -1;
            }
        } else {
            return -1;
        }
    }

}
