package com.hoolai.sangoh5.bo.battle.skill.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.battle.BattleObjFoctory;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.ForceDirection;
import com.hoolai.sangoh5.bo.battle.skill.ForceType;
import com.hoolai.sangoh5.bo.battle.skill.ForceUnitType;
import com.hoolai.sangoh5.bo.battle.skill.Occasion;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.SkillType;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.util.ProbabilityGenerator;
import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.IntHashMap;

@Component
public class BattleEnhanceData extends JsonData<SkillProperty> {

    private static final IntHashMap<Skill> skillsMap = new IntHashMap<Skill>();

    @Autowired
    private ProbabilityGenerator pg;

    @Autowired
    private BattleObjFoctory battleObjFoctory;

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/battleEffect.json", SkillProperty.class);
            initSkill();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initSkill() {
        for (SkillProperty property : propertyMap.values()) {
            int skillXmlId = property.getId();
            int skillId = property.getSkillId();
            SkillType skillType = SkillType.valueOf(property.getType().toUpperCase());
            Skill skill = skillType.newInstance(skillId);

            if (skill == null) {
                throw new IllegalArgumentException("没有的技能就别配到xml里面xmlId:" + skillXmlId + ",skillId:" + skillId);
            }

            skill.setXmlId(skillXmlId);
            skill.setSkillId(skillId);
            skill.setLevel(property.getLevel());
            skill.setOccasion(Occasion.valueOf(property.getOccasion().toUpperCase()));
            skill.setForceType(ForceType.valueOf(property.getForce().toUpperCase()));
            skill.setAttributeType(AttributeType.valueOf(property.getAttribute().toUpperCase()));
            skill.setForceUnitType(ForceUnitType.valueOf(property.getUnit().toUpperCase()));
            skill.setPercentage(property.getPercentage() / 100f);
            skill.setValue(property.getValue());
            skill.setSkillType(skillType);
            skill.setChance(property.getChance());
            skill.setName(property.getName());
            skill.setRound((int) (property.getRound() / FightUnit.ROUND_SPEND));
            //        skill.setForceCore(ForceCore.convert(property.getCore()));
            skill.setRange(property.getRange());
            skill.setForceDirection(ForceDirection.convert(property.getDirection()));
            skill.setRepeatCount((int) (property.getRepeat() / FightUnit.ROUND_SPEND));
            skill.setName(property.getName());
            skill.setTwoImpactId(property.getTwoImpactId());
            skill.setSubType(property.getSubType());

            skill.setRestraintFinder(battleObjFoctory.newRestraintFinder());
            skill.setPg(pg);
            skill.setAttackUnitType(ForceUnitType.valueOf(property.getCaster().toUpperCase()));

            skillsMap.put(skillXmlId, skill);
        }
    }

    @Override
    protected void checkProperty(SkillProperty property) {
        // TODO Auto-generated method stub

    }

    /**
     * 查找技能，可进行修改，因为其实是查找后再返回clone的一份
     * 
     * @param xmlId
     * @return
     */
    public Skill findSkill(int xmlId) {
        Skill skill = skillsMap.get(xmlId);
        if (skill == null) {
            return null;
        }
        Skill clone = skill.clone();
        clone.setRestraintFinder(battleObjFoctory.newRestraintFinder());
        clone.setProbabilityGenerator(pg);
        return clone;
    }

}
