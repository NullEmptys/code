package com.hoolai.sangoh5.bo.battle.enhance.buff;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.BuffProto;
import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 在战火区域内持续掉血
 * 
 * @author Administrator
 *
 */
public class RangeSustainedBuff extends Buff {

    private FightUnit actor;

    private int buffInterval;

    private int delHpTemp;//暂存伤害值

    /*
     * 触发技能后的下一回生效
     */
    @Override
    public void apply(FightUnit target) {
        this.result();
        this.deltaHp = delHpTemp;
        if (buffInterval == 0) {
            if (logger.isDebugEnabled()) {
                logger.debug("buffInterval:" + buffInterval + ",xmlId=" + targetUsedSkillXmlId);
            }
            return;
        }

        if (!actor.isDead() && (executeCount % buffInterval == 0)) {
            super.apply(target);
            //            target.addBattleLog(actorName + "执行" + targetUsedSkillXmlId + "持续掉血：" + deltaHp + ",目前回合数：" + repeatCount + ",当前血量：" + target.getHp() + ",是否死亡：" + isTargetDie);
            //            isForFront = true;
            if (executeCount != 0) {
                needRepeatPlay();
            }
        } else {
            deltaHp = 0;
            isForFront = false;
        }
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * 此方法必要的时候需要在子类重写，否则会调用alive.unsilence()清除沉默产生负作用
     * 
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
    }

    public RangeSustainedBuff(BuffProto message) {
        super(message);
    }

    public RangeSustainedBuff(FightUnit actor, FightUnitName executeName, Skill skill, int currentLevel, int deltaHp) {
        super(skill.getXmlId(), skill.getName(), executeName, currentLevel);
        this.actor = actor;
        this.isKeep = true;
        this.buffInterval = skill.getRound();
        delHpTemp = deltaHp;
    }

    public Buff withBuffInterval(int buffInterval) {
        this.buffInterval = buffInterval;
        return this;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public int getDelHpTemp() {
        return delHpTemp;
    }

}
