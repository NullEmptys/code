package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class RankFightLimitationKey {

    private static final String prefix= "rfl";
	
    public static String getBarrackKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("id").toString();
    }
}
