package com.hoolai.sangoh5.bo.mission;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.Lists;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.MissionProtocolBuffer.DailyMissionActiveProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class DailyMissionActive implements ProtobufSerializable<DailyMissionActiveProto> {

    @JsonIgnore
    private long userId;

    private int dailyActiveValue;

    private List<Integer> dailyMissionRewardRec;

    @JsonIgnore
    private long dailyRefresh;

    public DailyMissionActive(long userId) {
        this.userId = userId;
    }

    public DailyMissionActive(byte[] bytes) {
        parseFrom(bytes);
    }

    public void addActiveVal(int val){
    	dailyActiveValue += val;
    }
    
    @Override
    public DailyMissionActiveProto copyTo() {
        DailyMissionActiveProto.Builder builder = DailyMissionActiveProto.newBuilder();
        builder.setUserId(userId);
        builder.setDailyActiveValue(dailyActiveValue);
        if (dailyMissionRewardRec != null && dailyMissionRewardRec.size() > 0) {
            for (Integer boxId : dailyMissionRewardRec) {
                builder.addDailyMissionRewardRec(boxId);
            }
        }
        builder.setDailyRefresh(dailyRefresh);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            DailyMissionActiveProto message = DailyMissionActiveProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }

    }

    @Override
    public void copyFrom(DailyMissionActiveProto message) {
        this.userId = message.getUserId();
        this.dailyActiveValue = message.getDailyActiveValue();
        int count = message.getDailyMissionRewardRecCount();
        this.dailyMissionRewardRec = Lists.newArrayListWithExpectedSize(count);
        for (int i = 0; i < count; i++) {
            dailyMissionRewardRec.add(message.getDailyMissionRewardRec(i));
        }
        this.dailyRefresh = message.getDailyRefresh();
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int getDailyActiveValue() {
        return dailyActiveValue;
    }

    public void setDailyActiveValue(int dailyActiveValue) {
        this.dailyActiveValue = dailyActiveValue;
    }

    public List<Integer> getDailyMissionRewardRec() {
        return dailyMissionRewardRec;
    }

    public void setDailyMissionRewardRec(List<Integer> dailyMissionRewardRec) {
        this.dailyMissionRewardRec = dailyMissionRewardRec;
    }

    public long getDailyRefresh() {
        return dailyRefresh;
    }

    public void setDailyRefresh(long dailyRefresh) {
        this.dailyRefresh = dailyRefresh;
    }

}
