package com.hoolai.sangoh5.bo.battle.fight;

import java.util.Iterator;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class AfterRound {

    private List<ActionResult> actionResultList;

    private TargetCollection tc;

    public AfterRound(List<ActionResult> actionResultList, TargetCollection tc) {
        this.actionResultList = actionResultList;
        this.tc = tc;
    }

    public void finalSpeHurtEnhance() {
        for (ActionResult actionResult : actionResultList) {
            targetEnhanceAfterExcuteBuffs(tc.getAlive(actionResult.getActorName()));
        }
        reflesh();
    }

    private void targetEnhanceAfterExcuteBuffs(FightUnit attOfficerUnit) {
        if (attOfficerUnit != null) {
            attOfficerUnit.targetEnhanceAfterExcuteBuffs(actionResultList, tc);
        }
    }

    public void reflesh() {
        Iterator<ActionResult> iterator = actionResultList.iterator();
        while (iterator.hasNext()) {
            ActionResult actionResult = iterator.next();
            if (!actionResult.isHaveDynamics()) {
                iterator.remove();
            }
        }
    }

}
