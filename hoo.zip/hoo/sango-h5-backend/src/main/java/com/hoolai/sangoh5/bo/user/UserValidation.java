package com.hoolai.sangoh5.bo.user;

import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.service.AntiPluginDomainService;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * validate user
 * 
 * accountState, cookie, white list. etc
 * 
 * @author luzj
 * 
 */
public class UserValidation {

    private final long userId;

    public UserValidation(long userId) {
        this.userId = userId;
    }

    /**
     * 检查帐号状态
     */
    public void validateAccountState(String token) {
        AccountState accountState = userRepo.getAccountState(userId);

        accountState.validateIdentifyingCode(token);

        antiPluginDomainService.refreshFreezeState(userId, accountState);

        validateFrozen(accountState);
        validateBlackList(accountState);
    }

    private void validateBlackList(AccountState accountState) {
        if (accountState != null && accountState.getIsBlackList()) {
            throw new com.hoolai.exception.BusinessException(ErrorCode.IS_BLACK_LIST.code, "User[" + userId + "] is in black list.");
        }
    }

    private void validateFrozen(AccountState accountState) {
        if (accountState != null && accountState.isFrozenAccount()) {
            throw new com.hoolai.exception.BusinessException(ErrorCode.USER_IS_FROZEN.code, "User[" + userId + "] is frozen.");
        }
    }

    /**
     * 检查是否在黑名单里，用于屏蔽黑名单内用户被其他人看到
     */
    public void validateBlackList() {
        AccountState accountState = userRepo.getAccountState(userId);
        validateBlackList(accountState);
    }

    /**
     * 检查Cookie, 白名单等状态是否合法
     * 
     * @param userIdStr
     * @return
     */
    public void validate(String token) {
        validateAccountState(token);
    }

    private UserRepo userRepo;

    private AntiPluginDomainService antiPluginDomainService;

    public void setUserRepo(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public void setAntiPluginDomainService(AntiPluginDomainService antiPluginDomainService) {
        this.antiPluginDomainService = antiPluginDomainService;
    }

}
