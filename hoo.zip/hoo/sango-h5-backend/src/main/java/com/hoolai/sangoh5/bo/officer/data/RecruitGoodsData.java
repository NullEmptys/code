package com.hoolai.sangoh5.bo.officer.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Component;

import com.hoolai.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.IntHashMap;

@Component
public class RecruitGoodsData extends JsonData<RecruitGoodsProperty> {
	
	@PostConstruct
	public void init() {
//		try {
//			initData("com/hoolai/sangoh5/recruitGoods.json", RecruitGoodsProperty.class);
//			initLevelMap();
//			initLevelMap4Officer();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		
	}

	private static final HashMap<String, int[]> NOMAL_LEVEL_RECRUIT_BAG_MAP = new HashMap<String, int[]>();
	private static final HashMap<String, int[]> YB_LEVEL_RECRUIT_BAG_MAP = new HashMap<String, int[]>();
	private static final HashMap<String, int[]> BOX_LEVEL_BAG_MAP = new HashMap<String, int[]>();
	
	private static final HashMap<String, int[]> NOMAL_LEVEL_RECRUIT_SKILL_MAP = new HashMap<String, int[]>();
	private static final HashMap<String, int[]> YB_LEVEL_RECRUIT_SKILL_MAP = new HashMap<String, int[]>();
	private static final HashMap<String, int[]> BOX_LEVEL_SKILL_MAP = new HashMap<String, int[]>();
	
	private static final IntHashMap<List<RecruitGoodsProperty>> OFFICER_CAN_RECRUIT_MAP = new IntHashMap<List<RecruitGoodsProperty>>();
	private static final int defaultOfficerKey = 1;
	
	private void initLevelMap() {
		HashMap<String, ArrayList<Integer>> nomalLvItemsMap = new HashMap<String, ArrayList<Integer>>();
		HashMap<String, ArrayList<Integer>> ybLvItemsMap = new HashMap<String, ArrayList<Integer>>();
		HashMap<String, ArrayList<Integer>> nomalLvSkillsMap = new HashMap<String, ArrayList<Integer>>();
		HashMap<String, ArrayList<Integer>> ybLvkillsMap = new HashMap<String, ArrayList<Integer>>();
		HashMap<String, ArrayList<Integer>> boxSkills = new HashMap<String, ArrayList<Integer>>();
		HashMap<String, ArrayList<Integer>> boxItems = new HashMap<String, ArrayList<Integer>>();
		
		for(RecruitGoodsProperty property:propertyMap.values()){
			if(property.getOnRecruit() == 0){
				continue;
			}
			
			int normalLv = property.getNormalLv();
			int diamondLv = property.getDiamondLv();
			int boxLv = property.getBoxLv();
			int qut = property.getQuantity();
			String type = property.getType();
			
			if("skills".equals(type)){
				classification(nomalLvSkillsMap, property, normalLv, qut);
				classification(ybLvkillsMap, property, diamondLv, qut);
				classificationBox(boxSkills, property, boxLv);
			}else if("item".equals(type)){
				classification(nomalLvItemsMap, property, normalLv, qut);
				classification(ybLvItemsMap, property, diamondLv, qut);
				classificationBox(boxItems, property, boxLv);
			}
		}
		
		classification4Map(NOMAL_LEVEL_RECRUIT_BAG_MAP,nomalLvItemsMap);
		classification4Map(YB_LEVEL_RECRUIT_BAG_MAP,ybLvItemsMap);
		classification4Map(NOMAL_LEVEL_RECRUIT_SKILL_MAP,nomalLvSkillsMap);
		classification4Map(YB_LEVEL_RECRUIT_SKILL_MAP,ybLvkillsMap);
		classification4Map(BOX_LEVEL_SKILL_MAP,boxSkills);
		classification4Map(BOX_LEVEL_BAG_MAP,boxItems);
		
		checkMap();
	}
	
	private void classificationBox(HashMap<String, ArrayList<Integer>> tempMap,
			RecruitGoodsProperty property, int boxLv) {
		if(boxLv == 0){
			for(int i=1;i<=6;i++){
				putBoxValue(tempMap, property, i);
			}
		}else{
			putBoxValue(tempMap, property, boxLv);
		}
	}

	private void putBoxValue(HashMap<String, ArrayList<Integer>> tempMap,
			RecruitGoodsProperty property, int boxLv) {
		ArrayList<Integer> list = tempMap.get(String.valueOf(boxLv));
		if(list == null){
			list = new ArrayList<Integer>();
		}
		list.add(property.getId());
		tempMap.put(String.valueOf(boxLv), list);
	}

	private void checkMap() {
		StringBuffer sb = new StringBuffer();
		for(int i=1;i<=6;i++){//用户的6个等级
			for(int j=1;j<=5;j++){//物品的5个品质
				String key = i+"_"+j;
				int[] a = NOMAL_LEVEL_RECRUIT_BAG_MAP.get(key);
				int[] b = YB_LEVEL_RECRUIT_BAG_MAP.get(key);
				int[] c = NOMAL_LEVEL_RECRUIT_SKILL_MAP.get(key);
				int[] d = YB_LEVEL_RECRUIT_SKILL_MAP.get(key);
//				System.out.println("namal_item:"+key+"="+Arrays.toString(a));
//				System.out.println("namal_skill:"+key+"="+Arrays.toString(c));
//				System.out.println("yb_item:"+key+"="+Arrays.toString(b));
//				System.out.println("yb_skill:"+key+"="+Arrays.toString(d));
				
				if(a == null || a.length < 8){
					sb.append("令牌可招募的item数量不够:key="+key+",size="+(a == null ? 0 : a.length));
					sb.append("\n");
				}
				if(b == null || b.length < 8){
					sb.append("钻石可招募的item数量不够:key="+key+",size="+(b == null ? 0 : b.length));
					sb.append("\n");
				}
				if(c == null || c.length < 3){
					sb.append("令牌可招募的技能数量不够:key="+key+",size="+(c == null ? 0 : c.length));
					sb.append("\n");
				}
				if(d == null || d.length < 3){
					sb.append("钻石可招募的技能数量不够:key="+key+",size="+(d == null ? 0 : d.length));
					sb.append("\n");
				}
			}
		}
		if(sb.toString().length() > 0){
			throw new BusinessException(ErrorCode.STATUS_ERROR, sb.toString());
		}
	}

	private void classification4Map(HashMap<String, int[]> nomalLevelRecruitBagMap,
			HashMap<String, ArrayList<Integer>> tempMap) {
		Set<String> keySet = tempMap.keySet();
		for(String key:keySet){
			ArrayList<Integer> list = tempMap.get(key);
			nomalLevelRecruitBagMap.put(key, toArray(list));
		}
	}

	private void classification(HashMap<String, ArrayList<Integer>> tempMap,
			RecruitGoodsProperty property, int normalLv, int qut) {
		if(normalLv == 0){
			for(int i=1;i<=6;i++){//用户6个等级
				qutClass(tempMap, property, qut, i);
			}
		}else{
			qutClass(tempMap, property, qut, normalLv);
		}
	}

	private void qutClass(HashMap<String, ArrayList<Integer>> tempMap,
			RecruitGoodsProperty property, int qut, int normalLv) {
		if(qut == 0){
			for(int j=1;j<=5;j++){
				putValue(tempMap, property, normalLv, j);
			}
		}else{
			putValue(tempMap, property, normalLv, qut);
		}
	}

	private void putValue(HashMap<String, ArrayList<Integer>> tempMap,
			RecruitGoodsProperty property, int level, int qut) {
		ArrayList<Integer> list = tempMap.get(level+"_"+qut);
		if(list == null){
			list = new ArrayList<Integer>();
		}
		list.add(property.getId());
		tempMap.put(level+"_"+qut, list);
	}

	private int[] getIdsByType(String itemType,String goodsType,String key){
		int ids0[] = null;
		if("nomal".equals(itemType) && "skills".equals(goodsType)){
			ids0 = NOMAL_LEVEL_RECRUIT_SKILL_MAP.get(key);
		}else if("nomal".equals(itemType) && "item".equals(goodsType)){
			ids0 = NOMAL_LEVEL_RECRUIT_BAG_MAP.get(key);
		}else if("yb".equals(itemType) && "skills".equals(goodsType)){
			ids0 = YB_LEVEL_RECRUIT_SKILL_MAP.get(key);
		}else if("yb".equals(itemType) && "item".equals(goodsType)){
			ids0 = YB_LEVEL_RECRUIT_BAG_MAP.get(key);
		}
		if(ids0 == null){
			throw new BusinessException(ErrorCode.STATUS_ERROR, "itemType="+itemType+",goodsType="+goodsType
					+",key="+key+";没有配置数据");
		}
		return ids0;
	}
	
	
	private int[] removeAll(int[] a,int[] b){
		List<Integer> alist = toList(a);
		List<Integer> blist = toList(b);
		alist.removeAll(blist);
		return toArray(alist);
	}
	
	/**
	 * 随机道具(招募专用)
	 * @param itemType 使用道具的类型（nomal/yb）
	 * @param goodsType 商品类型(skills/(item/equips))
	 * @param rank 类型的等级
	 * @param qut 商品的品质
	 * @param num 随机数量
	 * @return
	 */
	public int[] randomGoods(String itemType,String goodsType,int recruitItemLevel, int[] quts,int num) {
		
		int[] randomIds = new int[num];
		int index= 0;
		
		for(int qut:quts){
			String key = recruitItemLevel +"_"+qut;
			int ids0[] = getIdsByType(itemType, goodsType, key);
			
			int[] noRepeatIds = removeAll(ids0, randomIds);
			if(ArrayUtils.isEmpty(noRepeatIds)){
				randomIds[index++] = ids0[pg.getRandomNumber(ids0.length-1)];
			}else{
				randomIds[index++] = noRepeatIds[pg.getRandomNumber(noRepeatIds.length-1)];
			}
		}
		return randomIds;
	}
	
	/**
	 * 随机物品（宝箱专用）
	 * @param goodsType 商品类型(skills/(item/equips))
	 * @param boxLv
	 * @return
	 */
	public int randomBoxItem(String goodsType,int boxLv){
		int ids[] = null;
		if("skills".equals(goodsType)){
			ids = BOX_LEVEL_SKILL_MAP.get(String.valueOf(boxLv));
		}else if(!"skills".equals(goodsType)){
			ids = BOX_LEVEL_BAG_MAP.get(String.valueOf(boxLv));
		}
		return ids[pg.getRandomNumber(0,ids.length-1)];
	}
	
	
	public static void main(String[] args) {
		System.out.println(pg.getRandomNumber(0, 0));
	}

	@Override
	protected void checkProperty(RecruitGoodsProperty property) {
		int id = property.getId();
		if(id <1 || id > 10000){
//			throw new BusinessException(ErrorCode.SYSTEM_ERROR.code, "goods 表中的Id必须在1--10000之间");
		}
	}
	
	private void initLevelMap4Officer() {
		List<RecruitGoodsProperty> l1 = new ArrayList<RecruitGoodsProperty>();
		for(RecruitGoodsProperty property:propertyMap.values()){
			if(property.getType().equals("officer") && property.getOnRecruit() == 1){
				l1.add(property);
			}
		}
		
		if(l1.size() < 1){
			throw new BusinessException(ErrorCode.STATUS_ERROR, "可招募的将领数量不够:l1="+l1.size());
		}
		
		OFFICER_CAN_RECRUIT_MAP.put(defaultOfficerKey, l1);
	}
	
	private int[] findCanRecrutOfficerIds(int militaryRank){
		List<Integer> idList = new ArrayList<Integer>();
		for (RecruitGoodsProperty property : OFFICER_CAN_RECRUIT_MAP.get(defaultOfficerKey)) {
			if(property.getMilitaryRank() <= militaryRank){
				idList.add(property.getId());
			}
		}
		return toArray(idList);
	}
	
	public int randomOfficer(int militaryRank){
		int ids[] = findCanRecrutOfficerIds(militaryRank);
		int id = ids[pg.getRandomNumber(0,ids.length-1)];
//		System.out.println("level:"+level+",id="+id+",ids="+ArrayUtils.toString(ids, ""));
		return id;
	}
	
	public int[] randomOfficerNoReapt(int num, int militaryRank){
		int[] exceptIds = new int[]{};
		int ids[] = findCanRecrutOfficerIds(militaryRank);
		
		for(int i=0;i<num;i++){
			int[] canRecruitIds = removeAll(ids, exceptIds);
			int id = ids[pg.getRandomNumber(0,canRecruitIds.length-1)];
			exceptIds = ArrayUtils.add(exceptIds, id);
		}
		return exceptIds;
	}
	
	public int[] randomOfficerNoReapt(int[] exceptIds,int num, int militaryRank){
		int ids[] = findCanRecrutOfficerIds(militaryRank);
		
		for(int i=0;i<num;i++){
			int[] canRecruitIds = removeAll(ids, exceptIds);
			int id = ids[pg.getRandomNumber(0,canRecruitIds.length-1)];
			exceptIds = ArrayUtils.add(exceptIds, id);
		}
		return exceptIds;
	}

	public boolean isAllExist(int[] newIds, int militaryRank) {
		int[] ids = removeAll(findCanRecrutOfficerIds(militaryRank), newIds);
		return ArrayUtils.isEmpty(ids);
	}

}
