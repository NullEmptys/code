package com.hoolai.sangoh5.event;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 17:28
 * @version : 1.0
 */
public enum EventType {

    /**
     * pvp 占领
     */
    Pvpoccupy,

    /**
     * 悬赏解救
     */
    Rescue,

    /**
     * pvp 被占领
     */
    Pvpoccupied,
    ;

}
