package com.hoolai.sangoh5.bo.battle.skill.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ChangeDefenseBuff;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class MoYingJianJia extends AttributeEnhanceSkill {

    /*
     * 触发技能后的下一回生效,需要先执行
     */

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {

        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            Buff sbuff = new ChangeDefenseBuff(xmlId, name, target.name(), actor, forceType, Action.DEFAULT_ACTION_LEVEL, percentage).withKeepBuff().withActorName(actor.name())
                    .withTargetName(target.name()).withRepeatCount(repeatCount);
            sbuff.apply(target);
            target.addBuff(sbuff);
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]让" + target.name() + "减少防御力比率" + +percentage + ",持续回合数=" + repeatCount);
        }
    }

    @Override
    public Skill clone() {
        return super.clone(new MoYingJianJia());
    }

}
