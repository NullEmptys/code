package com.hoolai.sangoh5.bo.activity;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.OperationalActivityProto;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.OperationalActivityProto.Builder;
import com.hoolai.sangoh5.bo.activity.data.ActivityBaseProperty;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 11:06
 * @version : 1.0
 */
public class OperationalActivity implements ProtobufSerializable<OperationalActivityProto> {

    /** 活动id **/
    private int id;

    /** 活动开始时间 **/
    private long startTime;

    /** 结束时间 **/
    private long endTime;

    /** 活动中进行的项 **/
    private List<Integer> ids;

    public OperationalActivity(ActivityBaseProperty property) {
        this.id = property.getId();
        this.startTime = com.hoolai.sango.util.TimeUtil.currentTimeMillis();
        this.endTime = property.getTime() == 0 ? property.getTime() : this.startTime + TimeUnit.HOURS.toMillis(property.getTime());
    }

    public OperationalActivity(ActivityBaseProperty property, List<Integer> ids) {
        this(property);
        this.ids = ids;
    }

    public OperationalActivity(OperationalActivityProto activity) {
        this.copyFrom(activity);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public List<Integer> getIds() {
        return ids;
    }

    public void setIds(List<Integer> ids) {
        this.ids = ids;
    }

    @Override
    public OperationalActivityProto copyTo() {
        Builder newBuilder = OperationalActivityProto.newBuilder();
        newBuilder.setId(id);
        newBuilder.setStartTime(startTime);
        newBuilder.setEndTime(endTime);
        if (CollectionUtils.isNotEmpty(ids)) {
            newBuilder.addAllIds(ids);
        }
        return newBuilder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            OperationalActivityProto message = OperationalActivityProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(OperationalActivityProto message) {
        this.id = message.getId();
        this.startTime = message.getStartTime();
        this.endTime = message.getEndTime();
        this.ids = message.getIdsList();
    }

    public boolean finished() {
        return this.endTime == 0 ? false : TimeUtil.currentTimeMillis() >= endTime;
    }

    public boolean isStarted() {
        return this.startTime <= TimeUtil.currentTimeMillis();
    }

    public long getRemainTime() {
        return this.endTime == 0 ? 0 : TimeUtil.currentTimeMillis() < endTime ? endTime - TimeUtil.currentTimeMillis() : 0;
    }

    public String getStarttime() {
        if (startTime <= 0) {
            return StringUtils.EMPTY;
        }
        return DateUtil.convertToDate2(startTime);
    }

    public String getEndtime() {
        if (endTime <= 0) {
            return StringUtils.EMPTY;
        }
        return DateUtil.convertToDate2(endTime);
    }

    public void updateTime(String startTime, String endTime) {
        this.startTime = DateUtil.covertToDate3(startTime);
        this.endTime = DateUtil.covertToDate3(endTime);
    }
}
