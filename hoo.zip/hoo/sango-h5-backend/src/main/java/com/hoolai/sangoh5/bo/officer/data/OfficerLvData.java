package com.hoolai.sangoh5.bo.officer.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class OfficerLvData extends JsonData<OfficerLvProperty> {

	@PostConstruct
	public void init() {
		try {
			initData("com/hoolai/sangoh5/officerLv.json", OfficerLvProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	protected void checkProperty(OfficerLvProperty property) {
		// TODO Auto-generated method stub
		
	}

}
