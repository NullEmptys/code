package com.hoolai.sangoh5.bo.rescue;

/**
 * 常量池(暂时使用)
 * 
 * @author hp
 *
 */
public class Constants {

    public static final int choiceNum = 3;// 筛选条数

    public static final int matchLevelLimit = 5;// 匹配等级上限下限值

    public static final int userMinLevel = 1;// 玩家最低等级

    public static final int userMaxLevel = 100;// 玩家最高等级

    public static final int shopViewNum = 8;// 竞技场、排位赛列表显示数目

    public static final int unionShopNum = 10;// 联盟商店显示数量

    public static final int oneFlushTime = 12;// 商店刷新时间

    public static final int twoFlushTime = 18;// 商店刷新时间

    public static final int CanSal = 1;// 可以出售

    public static final int notSal = 2;// 不能出售

    public static final String shopReflushTime = " 12:00:00";

    public static final String shopReflushTwoTime = " 18:00:00";

    public static final int maxBuyNum = 20;// 揭榜挑战次数购买上限

    public static final String daily_mission_reflushTime = " 3:00:00";

    public static final int missionFlushTime = 3;

    public static final int sweepNum = 5;// 最多扫荡次数

    public static final int pveRankNum = 1000;// 国土排行显示条数

    public static final int formationDefaultStarLevel = 1;

    public static final int buyLimit = 3;//购买次数上限
}
