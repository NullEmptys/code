//package com.hoolai.sangoh5.bo.battle.skill.passive;
//
//import java.util.List;
//
//import com.hoolai.sangoh5.bo.battle.enhance.effect.EnhanceEffect;
//import com.hoolai.sangoh5.bo.battle.enhance.effect.HurtEnhanceEffect;
//import com.hoolai.sangoh5.bo.battle.enhance.effect.SkillHurtEnhanceEffect;
//import com.hoolai.sangoh5.bo.battle.skill.Skill;
//import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
//import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
//
///**
// * 对造成的伤害增加或减少,目前都是被动技能
// *
// */
//public class PassiveEnhanceHurtSkill extends AttributeEnhanceSkill {
//
//    @Override
//    public void apply(FightUnit actor, TargetCollection tc) {
//        float per = percentage;
//        
//        EnhanceEffect enhanceEffect = null;
//        switch(attributeType){
//    	case HURT:
//    		enhanceEffect = new HurtEnhanceEffect(this.xmlId,per);
//    		break;
//    	case SKILLHURT:
//    		enhanceEffect = new SkillHurtEnhanceEffect(this.xmlId,per);
//    		break;
//        }
//        
//        List<FightUnit> aliveMap = aliveTargetUnitList(tc,actor);
//		for (FightUnit target : aliveMap) {
//			target.addEnhanceEffect(enhanceEffect);
//		}
//    }
//    
//
//    @Override
//    public Skill clone() {
//        return super.clone(new PassiveEnhanceHurtSkill());
//    }
//    
//}
