package com.hoolai.sangoh5.bo.battle.enhance.buff;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class QingXinShuBuff extends Buff {

    public QingXinShuBuff(int targetUsedSkillXmlId, String skillName, FightUnitName executeName, int currentLevel) {
        super(targetUsedSkillXmlId, skillName, executeName, currentLevel);
        isForFront = true;
    }

    @Override
    public void apply(FightUnit target) {
        //    	apply(target);
        //		isForFront = true;
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        alive.unShieldControl();
        alive.addBattleLog(targetUsedSkillXmlId + "[" + skillName + "]" + alive.name() + "屏蔽所有控制状态效果结束");
    }

    @Override
    protected QingXinShuBuff clone() {
        QingXinShuBuff buff = (QingXinShuBuff) super.clone(new QingXinShuBuff(this.targetUsedSkillXmlId, skillName, executeName, currentLevel));
        return buff;
    }

}
