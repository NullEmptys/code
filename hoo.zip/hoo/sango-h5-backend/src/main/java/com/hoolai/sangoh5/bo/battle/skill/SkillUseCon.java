package com.hoolai.sangoh5.bo.battle.skill;

import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public enum SkillUseCon {

	wen_guan(1),wu_guan(2),all(3);
	
	private final int type;
	private SkillUseCon(int type){
		this.type = type;
	}
	
	public int value(){
		return type;
	}
	
	public static SkillUseCon valueOf(int type){
		for(SkillUseCon skillUseCon:values()){
			if(skillUseCon.value() == type){
				return skillUseCon;
			}
		}
		throw new BusinessException(ErrorCode.JSON_TABLE_ERROR);
	}
}
