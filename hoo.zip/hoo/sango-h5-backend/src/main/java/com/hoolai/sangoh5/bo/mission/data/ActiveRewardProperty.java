package com.hoolai.sangoh5.bo.mission.data;

import java.util.List;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class ActiveRewardProperty extends JsonProperty {

    /** 活跃度 */
    private int activeNeed;

    /** 任务的奖励 */
    private List<Integer> rewardIds;

    /** 奖励类型 */
    private List<String> rewardTypes;

    /** 奖励数量 */
    private List<Integer> rewardNums;

    public int getActiveNeed() {
        return activeNeed;
    }

    public void setActiveNeed(int activeNeed) {
        this.activeNeed = activeNeed;
    }

    public List<Integer> getRewardIds() {
        return rewardIds;
    }

    public void setRewardIds(List<Integer> rewardIds) {
        this.rewardIds = rewardIds;
    }

    public List<String> getRewardTypes() {
        return rewardTypes;
    }

    public void setRewardTypes(List<String> rewardTypes) {
        this.rewardTypes = rewardTypes;
    }

    public List<Integer> getRewardNums() {
        return rewardNums;
    }

    public void setRewardNums(List<Integer> rewardNums) {
        this.rewardNums = rewardNums;
    }

}
