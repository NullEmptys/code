package com.hoolai.sangoh5.bo.pvp.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-13 11:03
 * @version : 1.0
 */
@Component
public class RegionConBoxData extends ConBoxData<RegionConProperty> {

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/regionConBox.json", RegionConProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(RegionConProperty property) {
        if (property.getRewardIds().length != property.getRewardNums().length || property.getRewardIds().length != property.getRewardTypes().length) {
            throw new RuntimeException("regionConBoxData id = " + property.getId() + " 的奖励id，rewardsId, rewardsNums, rewardTypes 数组长度不一致");
        }
        if (property.getPersonalConValve().length != 2) {
            throw new RuntimeException("regionConBoxData id = " + property.getId() + " 的奖励id，PersonalConValve length error");
        }
    }
}
