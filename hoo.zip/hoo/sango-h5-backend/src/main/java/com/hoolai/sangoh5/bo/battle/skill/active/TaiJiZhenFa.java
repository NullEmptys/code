package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ChangeAttackBuff;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 太极阵法
 * 
 * 释放一个阵法，阵法区域内，敌方单位攻击下降5%，我方单位攻击提升5%，持续12秒
 * 
 * @author Administrator
 *
 */
public class TaiJiZhenFa extends IndependentSkill {

    @Override
    public Skill clone() {
        return super.clone(new TaiJiZhenFa());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            keepHurt(actor, currentLevel, target);
            targets.add(target);
        }
        return targets;
    }

    /**
     * 持续伤害
     * 
     * @param actor
     * @param currentLevel
     * @param target
     */
    private void keepHurt(FightUnit actor, int currentLevel, FightUnit target) {
        Buff buff = target.findBuff(this.xmlId);
        if (buff == null) {
            Buff sbuff = new ChangeAttackBuff(xmlId, name, target.name(), actor, forceType, Action.DEFAULT_ACTION_LEVEL, percentage).withKeepBuff().withActorName(actor.name())
                    .withTargetName(target.name()).withRepeatCount(repeatCount);
            sbuff.apply(target);
            target.addBuff(sbuff);
        } else {
            buff.setRepeatCount(repeatCount);
        }

        if (FightUnit.isSameTeam(actor, target)) {
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]让" + target.name() + "增加攻击力比率" + +percentage + ",持续回合数=" + repeatCount);
        } else {
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]让" + target.name() + "减少攻击力比率" + +percentage + ",持续回合数=" + repeatCount);
        }

    }

}
