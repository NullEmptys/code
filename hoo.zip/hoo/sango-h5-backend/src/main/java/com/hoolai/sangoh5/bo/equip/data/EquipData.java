package com.hoolai.sangoh5.bo.equip.data;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.equip.Equip;
import com.hoolai.sangoh5.bo.equip.Equip.ItemPosition;
import com.hoolai.sangoh5.bo.equip.Equips;
import com.hoolai.sangoh5.bo.equip.data.EquipProperty.EquipType;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonData;


@Component
public class EquipData extends JsonData<EquipProperty>{
	
   private final int[] defaultEquipIds = { -1, -2, -3, -4 };
   
//   public static int max_weapon_level;
//   public static int max_armor_level;
//   public static int max_helmet_level;
//   public static int max_horse_level;

	@PostConstruct
    public void init(){
    	try {
    		initData("com/hoolai/sangoh5/equips.json", EquipProperty.class);
//    		initLevel();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
	
//	 private void initLevel() {
//		for(EquipProperty property:propertyMap.values()){
//			EquipType type = EquipType.convertEquipType(property.getType());
//			switch(type){
//			case WEAPON:
//				max_weapon_level = Math.max(property.getId(), max_weapon_level);
//				break;
//			case ARMOR:
//				max_armor_level = Math.max(property.getId(), max_armor_level);
//				break;
//			case HELMET:
//				max_helmet_level = Math.max(property.getId(), max_helmet_level);
//				break;
//			case HORSE:
//				max_horse_level = Math.max(property.getId(), max_horse_level);
//				break;
//			}
//		}
//	}

	public boolean isDefaultByEquipId(int equipId) {
	        for (int defaultEquipId : defaultEquipIds) {
	            if (defaultEquipId == equipId) {
	                return true;
	            }
	        }
	        return false;
	    }
	 
	 public Equip findDefaultEquip(int equipId) {
//	        int equipXmlId;
//	        switch (equipId) {
//	        case -1:
//	            equipXmlId = defaultEquipXmlIds[0];
//	            break;
//	        case -2:
//	            equipXmlId = defaultEquipXmlIds[1];
//	            break;
//	        case -3:
//	            equipXmlId = defaultEquipXmlIds[2];
//	            break;
//	        case -4:
//	            equipXmlId = defaultEquipXmlIds[3];
//	            break;
//	        default:
//	            throw new ImproperOperationException("who permit you can here");
//	        }
	        return createDefaultEquip(equipId, equipId);
	    }

	    private Equip createDefaultEquip(int equipId, int equipXmlId) {
	        Equip equip = new Equip(equipXmlId, ItemPosition.in_officer.ordinal());
	        equip.setId(equipId);
	        return equip;
	    }

		public int[] findMaxOfficerEquip(Officer officer,Equips allEquips) {
			int helmet = -3,armor = -2,weapon = -1, horse = -4;
			int[] equips = {-1,-2,-3,-4};
			int officerLevel = officer.getLevel();
			List<Equip> equipList = allEquips.equipList();
			for(Equip equip:equipList){
				EquipProperty property = this.getProperty(equip.getXmlId());
				EquipType equipType = EquipType.convertEquipType(property.getType());
				switch(equipType){
				case WEAPON:
					if(property.getNeedOfficerLv() <= officerLevel && property.getId() > weapon){
						equips[0] = equip.getId();
					}
					break;
				case ARMOR:
					if(property.getNeedOfficerLv() <= officerLevel && property.getId() > armor){
						equips[1] = equip.getId();
					}
					break;
				case HELMET:
					if(property.getNeedOfficerLv() <= officerLevel && property.getId() > helmet){
						equips[2] = equip.getId();
					}
					break;
				case HORSE:
					if(property.getNeedOfficerLv() <= officerLevel && property.getId() > horse){
						equips[3] = equip.getId();
					}
					break;
				}
			}
			return equips;
		}

		public int[] findDefaultEquips() {
			return defaultEquipIds;
		}

		public int findDefaultEquipId(EquipType equipType) {
			switch (equipType) {
			case WEAPON:
				return -1;
			case ARMOR:
				return -2;
			case HELMET:
				return -3;
			case HORSE:
				return -4;
			default:
				throw new BusinessException(ErrorCode.ERROR_PARAM_VALUE);
			}
		}

//		public boolean isMaxLevel(int xmlId) {
//			EquipProperty equipProperty = getProperty(xmlId);
//			EquipType type = EquipType.convertEquipType(equipProperty.getType());
//			switch(type){
//			case WEAPON:
//				return xmlId == max_weapon_level;
//			case ARMOR:
//				return xmlId == max_armor_level;
//			case HELMET:
//				return xmlId == max_helmet_level;
//			case HORSE:
//				return xmlId == max_horse_level;
//			}
//			return false;
//		}

		@Override
		protected void checkProperty(EquipProperty property) {
			int id = property.getId();
			if(id < 10000 || id > 20000){
				throw new com.hoolai.exception.BusinessException(ErrorCode.ERROR_XMLID_IN_JSON.code, "equip表中的Id应在 10001 -- 20000 之间");
			}
		}
		
		
}
