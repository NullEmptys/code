package com.hoolai.sangoh5.bo.union.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.union.UnionTitleProperty;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class UnionTitleData extends JsonData<UnionTitleProperty> {

	public static final int MAX = 5;
	
	@PostConstruct
	public void init() {
		try {
			initData("com/hoolai/sangoh5/unionTitle.json", UnionTitleProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	protected void checkProperty(UnionTitleProperty property) {
		// TODO Auto-generated method stub
		
	}

}
