package com.hoolai.sangoh5.bo.technology;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.ScienceProtocolBuffer.SoldierTechnologyProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class SoldierTechnology implements ProtobufSerializable<SoldierTechnologyProto> {

    private int id;

    private long learnEndTime;

    private boolean isFinish;

    private int scienceId;

    transient long leftLearnTime;

    public SoldierTechnology(int id, int scienceId, long learnEndTime) {
        this.id = id;
        this.scienceId = scienceId;
        this.learnEndTime = learnEndTime;
    }

    public SoldierTechnology(SoldierTechnologyProto message) {
        copyFrom(message);
        reflesh();
    }

    @Override
    public SoldierTechnology clone() {
        SoldierTechnology technology = new SoldierTechnology(id, scienceId, learnEndTime);
        return technology;
    }

    private void reflesh() {
        if (!isFinish) {
            long now = TimeUtil.currentTimeMillis();
            isFinish = now >= learnEndTime;
            leftLearnTime = isFinish ? 0 : (learnEndTime - now) / 1000l;
        }
    }

    public void accelerate(long time) {
        this.learnEndTime -= time;
        reflesh();
    }

    public int getId() {
        return id;
    }

    public int getScienceId() {
        return scienceId;
    }

    public long getLeftLearnTime() {
        return leftLearnTime;
    }

    public boolean isFinish() {
        reflesh();
        return isFinish;
    }

    @Override
    public SoldierTechnologyProto copyTo() {
        SoldierTechnologyProto.Builder builder = SoldierTechnologyProto.newBuilder();
        builder.setId(id);
        builder.setLearnEndTime(learnEndTime);
        builder.setIsFinish(isFinish());
        builder.setScienceId(scienceId);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            SoldierTechnologyProto message = SoldierTechnologyProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(SoldierTechnologyProto message) {
        this.id = message.getId();
        this.learnEndTime = message.getLearnEndTime();
        this.isFinish = message.getIsFinish();
        this.scienceId = message.getScienceId();
    }
}
