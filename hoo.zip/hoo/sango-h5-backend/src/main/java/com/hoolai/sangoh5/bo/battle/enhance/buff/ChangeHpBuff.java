package com.hoolai.sangoh5.bo.battle.enhance.buff;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 加血Buff
 */
public class ChangeHpBuff extends Buff {

    private Skill skill;

    @Override
    public void apply(FightUnit target) {
        this.result();
        if (target.isDead() || skill.getRound() == 0) {//加一次的基本上在外面就需要加上
            return;
        }
        if (executeCount % skill.getRound() == 0) {
            target.changeHp(deltaHp);
            target.addBattleLog(actorName + "执行" + targetUsedSkillXmlId + "[" + skillName + "],加血" + deltaHp + ",hp=" + target.getHp());
            if (executeCount != 0) {
                needRepeatPlay();
            }
        }
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
    }

    @Override
    protected ChangeHpBuff clone() {
        ChangeHpBuff buff = (ChangeHpBuff) super.clone(new ChangeHpBuff(this.targetUsedSkillXmlId, this.skillName, executeName, currentLevel, attributeType, skill, isForFront));
        return buff;
    }

    public ChangeHpBuff(int targetUsedSkillXmlId, String skillName, FightUnitName executeName, int currentLevel, AttributeType attributeType, Skill skill, boolean isForFornt) {
        super(targetUsedSkillXmlId, skillName, executeName, currentLevel, attributeType);
        this.skill = skill;
        this.isForFront = isForFornt;
    }
}
