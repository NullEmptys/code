package com.hoolai.sangoh5.bo.officer.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.IntHashMap;

@Component
public class RecruitHeroData extends JsonData<RecruitHeroProperty> {

	private static final IntHashMap<List<RecruitHeroProperty>> RECRUIT_HERO_DATA = new IntHashMap<List<RecruitHeroProperty>>();

	@PostConstruct
	public void init() {
		try {
			initData("com/hoolai/sangoh5/recruitHero.json", RecruitHeroProperty.class);
			initRecruitHeroData();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	protected void checkProperty(RecruitHeroProperty property) {
		// TODO Auto-generated method stub

	}

	private void initRecruitHeroData() {
		IntHashMap<RecruitHeroProperty> heroRecruit = getPropertyMap();
		for (RecruitHeroProperty heroProperty : heroRecruit.values()) {
			if (RECRUIT_HERO_DATA.containsKey(heroProperty.getType())) {
				RECRUIT_HERO_DATA.get(heroProperty.getType()).add(heroProperty);
			} else {
				List<RecruitHeroProperty> recruitPropertyList = new ArrayList<RecruitHeroProperty>();
				recruitPropertyList.add(heroProperty);
				RECRUIT_HERO_DATA.put(heroProperty.getType(), recruitPropertyList);
			}
		}
	}

	public static IntHashMap<List<RecruitHeroProperty>> getRecruitHeroPropertyData() {
		return RECRUIT_HERO_DATA;
	}

}
