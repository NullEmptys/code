package com.hoolai.sangoh5.bo.client;

public class ChatClientFactory {

    //    public static ChatClientRepo createChatClient(String address, int port,ChatProcessorDispatcher) {
    //        ChatClientRepoImpl clientRepoImpl = new ChatClientRepoImpl(address, port);
    //        return clientRepoImpl;
    //    }

    //    public static ChatClientRepo createChatClient(String url) {
    //        ChatClientRepoImpl clientRepoImpl = new ChatClientRepoImpl(url);
    //        return clientRepoImpl;
    //    }
}
