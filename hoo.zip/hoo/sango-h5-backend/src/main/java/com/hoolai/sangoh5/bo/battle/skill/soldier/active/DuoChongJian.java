package com.hoolai.sangoh5.bo.battle.skill.soldier.active;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class DuoChongJian extends BaseSoldierPhysicsSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveUnits = aliveTargetUnitList(tc, actor);

        if (aliveUnits.size() <= 3) {
            for (FightUnit target : aliveUnits) {
                exe(actor, tc, currentLevel, targets, target);
            }
        } else {
            Collections.shuffle(aliveUnits, new Random(TimeUtil.currentTimeMillis()));
            for (int i = 0; i < 3; i++) {
                FightUnit target = aliveUnits.get(i);
                exe(actor, tc, currentLevel, targets, target);
            }
        }

        return targets;
    }

    private void exe(FightUnit actor, TargetCollection tc, int currentLevel, List<FightUnit> targets, FightUnit target) {
        Effect effect = new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name())
                .withDeltaHp(calculateLostPoint4AttackSkill(actor, target));
        target.addEffect(effect);
        targetDefence(actor, target, effect, null, tc, targets, currentLevel);
        targets.add(target);
    }

    @Override
    public Skill clone() {
        return super.clone(new DuoChongJian());
    }

}
