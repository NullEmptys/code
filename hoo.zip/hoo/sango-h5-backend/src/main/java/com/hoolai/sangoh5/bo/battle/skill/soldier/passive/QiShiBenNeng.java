package com.hoolai.sangoh5.bo.battle.skill.soldier.passive;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.passive.AttributeEnhanceSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 免疫击退和控制技能
 */
public class QiShiBenNeng extends AttributeEnhanceSkill {

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {
        actor.shieldControl();
        actor.addBuff(new Buff(xmlId, name, actor.name(), Effect.DEFAULT_BUFF_LEVEL).withActorName(actor.name()).withTargetName(actor.name()));
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]");
    }

    @Override
    public Skill clone() {
        return super.clone(new QiShiBenNeng());
    }
}
