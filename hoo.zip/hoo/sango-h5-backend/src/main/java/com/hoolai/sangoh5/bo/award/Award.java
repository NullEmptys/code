package com.hoolai.sangoh5.bo.award;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.AwardProto;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.AwardTypeProto;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Award implements ProtobufSerializable<AwardProto> {

    public static final String AWARD_KEY = "awards";

    public static final int gold = -1;//参见currency.json表， 下面同此

    public static final int userExp = -2;

    public static final int moonstone = -3;

    public static final int militaryExploits = -4;

    public static final int friendship = -7;

    public static final int reputation = -8;

    public static final int diamond = -9;

    public static final int lanTianYu = -10;

    public static final int provisionValue = -11;

    public static final int leftEar = -12;

    public static final int meteorite = -13;

    protected int xmlId;

    protected int num;

    protected AwardType awardType;

    public Award(int xmlId, int num, AwardType type) {
        this.xmlId = xmlId;
        this.num = num;
        this.awardType = type;
    }

    public Award(AwardProto proto) {
        copyFrom(proto);
    }

    public Award cloneAward() {
        return new Award(this.getXmlId(), this.getNum(), awardType);
    }

    public enum AwardType {
        GOLD("gold", AwardTypeProto.GOLD), 
        USEREXP("userExp", AwardTypeProto.USEREXP), 
        DIAMOND("diamond", AwardTypeProto.DIAMOND), 
        ITEM("item", AwardTypeProto.ITEM),
        //        EQUIP("equip", AwardTypeProto.EQUIP),
        OFFICER("officer", AwardTypeProto.OFFICER), 
        MOONSTONE("moonstone", AwardTypeProto.MOONSTONE), 
        MATERIAL("material", AwardTypeProto.MATERIAL), 
        MILITAREXPLOITS("MilitaryExploits", AwardTypeProto.MILITAREXPLOITS), 
        FRIENDSHIP("friendship", AwardTypeProto.FRIENDSHIP), 
        REPUTATION("reputation",AwardTypeProto.REPUTATION), 
        LANTIANYU("lanTianYu", AwardTypeProto.LANTIANYU), 
        SKILL("skill", AwardTypeProto.SKILL), 
        PROVISION("provision",AwardTypeProto.PROVISION), 
        SOLDIER("soldier", AwardTypeProto.SOLDIER), 
        LEFTEAR("leftEar", AwardTypeProto.LEFTEAR),
        METEORITE("meteorite",AwardTypeProto.METEORITE);

        private String awartType;

        private AwardTypeProto awardTypeProto;

        private AwardType(String awartType, AwardTypeProto awardTypeProto) {
            this.awartType = awartType;
            this.awardTypeProto = awardTypeProto;
        }

        public static AwardType converToAwardType(String type) {
            for (AwardType at : AwardType.values()) {
                if (at.getAwartType().equals(type)) {
                    return at;
                }
            }
            throw new com.hoolai.sango.core.exception.BusinessException(ErrorCode.ERROR_AWARD_TYPE.code, ErrorCode.ERROR_AWARD_TYPE.msg + "---errortype is " + type);
        }

        public static AwardType converToAwardType(AwardTypeProto awardTypeProto) {
            for (AwardType at : AwardType.values()) {
                if (at.getAwardTypeProto().equals(awardTypeProto)) {
                    return at;
                }
            }
            throw new com.hoolai.sango.core.exception.BusinessException(ErrorCode.ERROR_AWARD_TYPE.code, ErrorCode.ERROR_AWARD_TYPE.msg + "---errortype is " + awardTypeProto);
        }

        public String getAwartType() {
            return awartType;
        }

        public void setAwartType(String awartType) {
            //			this.awartType = awartType;
        }

        public AwardTypeProto getAwardTypeProto() {
            return awardTypeProto;
        }

        public void setAwardTypeProto(AwardTypeProto awardTypeProto) {
            //			this.awardTypeProto = awardTypeProto;
        }

    }

    public AwardType getAwardType() {
        return awardType;
    }

    public void setAwardType(AwardType type) {
        this.awardType = type;
    }

    public int getXmlId() {
        return xmlId;
    }

    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public void incrNum(int num) {
        this.num += num;
    }

    @Override
    public AwardProto copyTo() {
        AwardProto.Builder builder = AwardProto.newBuilder();
        builder.setXmlId(xmlId);
        builder.setNum(num);
        builder.setAwardType(this.awardType.getAwardTypeProto());
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            copyFrom(AwardProto.parseFrom(bytes));
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void copyFrom(AwardProto message) {
        this.xmlId = message.getXmlId();
        this.num = message.getNum();
        this.awardType = AwardType.converToAwardType(message.getAwardType());
    }

}
