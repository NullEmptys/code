package com.hoolai.sangoh5.bo.activity.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class FamilyProperty extends JsonProperty {

    private int gtade;

    private String[] type;

    private int[] reward;

    private int[] num;

    private int officerId;

    private int officerStar;

    public int getGtade() {
        return gtade;
    }

    public void setGtade(int gtade) {
        this.gtade = gtade;
    }

    public String[] getType() {
        return type;
    }

    public void setType(String[] type) {
        this.type = type;
    }

    public int[] getReward() {
        return reward;
    }

    public void setReward(int[] reward) {
        this.reward = reward;
    }

    public int[] getNum() {
        return num;
    }

    public void setNum(int[] num) {
        this.num = num;
    }

    public int getOfficerId() {
        return officerId;
    }

    public void setOfficerId(int officerId) {
        this.officerId = officerId;
    }

    public int getOfficerStar() {
        return officerStar;
    }

    public void setOfficerStar(int officerStar) {
        this.officerStar = officerStar;
    }

}
