package com.hoolai.sangoh5.bo.pvp;

import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.ContributeProto;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.ContributesProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-05 19:51
 * @version : 1.0
 */
public class Contributes implements ProtobufSerializable<ContributesProto> {

    /** 每天贡献值 **/
    private Map<Integer, Contribute> contributeMap;

    /** 是否领取阵营奖励 **/
    private boolean camp;

    /** 领取阵营奖励时间 **/
    private int drawCampDateValue;

    /** 上周奖励是否领取 **/
    private boolean lastWeek;

    public Contributes() {
    }

    public Contributes(ContributesProto contributes) {
        this.copyFrom(contributes);
    }

    public Contributes(byte[] obj) {
        this.parseFrom(obj);
    }

    public Contributes(long id) {
        this.contributeMap = Maps.newHashMapWithExpectedSize(8);
        this.drawCampDateValue = DateUtil.getTodayIntValue();
        this.lastWeek = true;
        this.camp = true;
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ContributesProto message = ContributesProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(ContributesProto message) {
        this.contributeMap = Maps.newHashMapWithExpectedSize(8);
        int contributeCount = message.getContributeCount();
        for (int i = 0; i < contributeCount; i++) {
            ContributeProto contributeMessage = message.getContribute(i);
            Contribute contribute = new Contribute(contributeMessage);
            this.contributeMap.put(contribute.getDay(), contribute);
        }
        this.camp = message.getCamp();
        this.drawCampDateValue = message.getDrawCampDateValue();
        this.lastWeek = message.getLastWeek();
    }

    @Override
    public ContributesProto copyTo() {
        ContributesProto.Builder builder = ContributesProto.newBuilder();
        if (!org.springframework.util.CollectionUtils.isEmpty(contributeMap)) {
            Collection<Contribute> values = contributeMap.values();
            for (Contribute contribute : values) {
                builder.addContribute(contribute.copyTo());
            }
        }
        builder.setCamp(camp);
        builder.setDrawCampDateValue(drawCampDateValue);
        builder.setLastWeek(lastWeek);
        return builder.build();
    }

    public int getCurrentDay() {
        long now = TimeUtil.currentTimeMillis();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(now);

        int hour = calendar.get(Calendar.HOUR_OF_DAY);

        int dayValue = DateUtil.getTodayIntValue();
        if (hour >= 21) {
            return dayValue + 1;
        } else {
            return dayValue;
        }
    }

    private Contribute getContribute(int day) {
        Contribute contribute = contributeMap.get(day);
        if (contribute == null) {
            contribute = new Contribute(day);
            contributeMap.put(day, contribute);
        }
        return contribute;
    }

    public void addAttackNum() {
        int day = getCurrentDay();
        Contribute contribute = getContribute(day);
        contribute.addAttackNum();
    }

    public void addDefenceNum() {
        int day = getCurrentDay();
        Contribute contribute = getContribute(day);
        contribute.addDefenceNum();
    }

    public void addRescueNum() {
        int day = getCurrentDay();
        Contribute contribute = getContribute(day);
        contribute.addRescueNum();
    }

    public void checkAndReceiveUnionGift() {
        int day = getCurrentDay() - 1;
        Contribute contribute = getContribute(day);
        if (contribute.drawedUnionGift()) {
            throw new BusinessException(ErrorCode.HAD_RECEIVE_REWARD);
        }
        contribute.drawUnionGift();
    }

    public int checkAndFindContribute() {
        int day = getCurrentDay() - 1;
        Contribute contribute = getContribute(day);
        if (contribute.drawedStateGift()) {
            throw new BusinessException(ErrorCode.HAD_RECEIVE_REWARD);
        }
        contribute.drawStateGift();
        return contribute.getContribute();
    }

    public void checkAndReceiveCampGift() {
        if (camp) {
            throw new BusinessException(ErrorCode.HAD_RECEIVE_REWARD);
        }
        this.camp = true;
        this.drawCampDateValue = getMonday();
    }

    private int getMonday() {
        long now = TimeUtil.currentTimeMillis();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(now);
        int weekDay = calendar.get(Calendar.DAY_OF_WEEK) - 1;
        if (weekDay == 0) {
            weekDay = 7;
        }
        return DateUtil.getTodayIntValue() - weekDay + 1;
    }

    public Contribute getLastContribute() {
        int day = getCurrentDay() - 1;
        return contributeMap.get(day);
    }

    public boolean drawedGampGift() {
        return this.camp;
    }

    public Map<String, Integer> findContributes() {
        long now = TimeUtil.currentTimeMillis();

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(now);

        int weekDay = calendar.get(Calendar.DAY_OF_WEEK) - 1;
        weekDay = weekDay == 0 ? 7 : weekDay;

        int hour = calendar.get(Calendar.HOUR_OF_DAY);

        int dayValue = DateUtil.getTodayIntValue();
        int today = hour >= 21 ? dayValue + 1 : dayValue;
        weekDay = hour >= 21 ? weekDay + 1 : weekDay;

        int attackNum = 0;
        int defenceNum = 0;
        int rescueNum = 0;
        do {
            Contribute contribute = contributeMap.get(today--);
            if (contribute != null) {
                attackNum += contribute.getAttackNum();
                defenceNum += contribute.getDefenceNum();
                rescueNum += contribute.getRescueNum();
            }
        } while (--weekDay >= 1);

        Map<String, Integer> map = Maps.newHashMapWithExpectedSize(3);
        map.put("attackNum", attackNum);
        map.put("defenceNum", defenceNum);
        map.put("rescueNum", rescueNum);
        return map;
    }

    public int getContribute() {
        Contribute contribute = getLastContribute();
        return contribute == null ? 0 : contribute.getContribute();
    }

    public void refresh() {
        int sevenDay = DateUtil.getTodayIntValue() - 7;
        Iterator<Integer> iterator = contributeMap.keySet().iterator();
        while (iterator.hasNext()) {
            if (iterator.next() < sevenDay) {
                iterator.remove();
            }
        }
    }

    private void refreshCamp() {
        long now = TimeUtil.currentTimeMillis();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(now);

        if (DateUtil.getTodayIntValue() - drawCampDateValue < 7) {
            return;
        }
        this.lastWeek = this.camp;
        this.camp = false;
        this.drawCampDateValue = DateUtil.getTodayIntValue();
    }

    public void refreshPvpUser() {
        this.refresh();
        this.refreshCamp();
    }

    public int findExpiredRewards() {
        long now = TimeUtil.currentTimeMillis();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(now);

        int hour = calendar.get(Calendar.HOUR_OF_DAY);

        int dayValue = DateUtil.getTodayIntValue();
        return hour >= 21 ? dayValue - 1 : dayValue - 2;
    }

    public boolean regionReward(int regIndex) {
        Contribute contribute = contributeMap.get(regIndex);
        return contribute == null ? false : contribute.drawedStateGift();
    }

    public void drawedStateReward(int lastIndex) {
        Contribute contribute = contributeMap.get(lastIndex);
        if (contribute == null) {
            contribute = new Contribute(lastIndex);
            contributeMap.put(lastIndex, contribute);
        }
        contribute.drawStateGift();
    }

    public boolean unionReward(int unionIndex) {
        Contribute contribute = contributeMap.get(unionIndex);
        return contribute == null ? true : contribute.drawedUnionGift();
    }

    public void drawedUnionReward(int lastIndex) {
        Contribute contribute = contributeMap.get(lastIndex);
        if (contribute == null) {
            contribute = new Contribute(lastIndex);
            contributeMap.put(lastIndex, contribute);
        }
        contribute.drawUnionGift();
    }

    public int findContribute(int index) {
        Contribute contribute = contributeMap.get(index);
        return contribute == null ? 0 : contribute.getContribute();
    }

    public boolean lastWeekCampRankGift() {
        return !this.lastWeek;
    }

    public void drawLastWeekCampGift() {
        this.lastWeek = true;
    }

    public List<Contribute> findContributeList() {
        return Lists.newArrayList(contributeMap.values());
    }

    public void changeContribute(String day, String attackNum, String defenceNum, String rescueNum) {
        Contribute contribute = contributeMap.get(Integer.valueOf(day));
        if (contribute != null) {
            contribute.changeNum(attackNum, defenceNum, rescueNum);
            return;
        }
        contribute = new Contribute(Integer.valueOf(day));
        contribute.changeNum(attackNum, defenceNum, rescueNum);
        contributeMap.put(contribute.getDay(), contribute);
    }

}
