package com.hoolai.sangoh5.repo.impl;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.sangoh5.bo.mission.DailyMissionActive;
import com.hoolai.sangoh5.bo.mission.Mission;
import com.hoolai.sangoh5.bo.mission.MissionList;
import com.hoolai.sangoh5.bo.mission.MissionStatus;
import com.hoolai.sangoh5.bo.mission.data.MissionType;
import com.hoolai.sangoh5.repo.MissionRepo;
import com.hoolai.sangoh5.repo.impl.key.MissionKey;

/**
 * 任务
 * 
 * @author hp
 *
 */
@Repository("missionRepo")
public class MissionRepoImpl implements MissionRepo {

    @Autowired
    @Qualifier("missionClient")
    private ExtendedMemcachedClient client;

    @Override
    public MissionList queryUserMissionList(long userId) {
        String key = MissionKey.getMissionKey(userId);
        Object o = client.get(key);
        if (o == null) {
            return new MissionList();
        } else {
            return new MissionList((byte[]) o);
        }
    }

    @Override
    public void saveAllMission(long userId, MissionList missionList) {
        String key = MissionKey.getMissionKey(userId);
        client.set(key, missionList.toByteArray());
    }

    @Override
    public int queryisFinishedMission(long userId, int category) {
        List<Mission> missions = this.queryUserMissionList(userId).getUserMissions();
        Iterator<Mission> it = missions.iterator();
        int finishMissionCount = 0;
        while (it.hasNext()) {
            Mission mission = it.next();
            if (mission.getCategoryId() == category && mission.getStatus() == MissionStatus.STATUS_FINISHED.getId()) {
                finishMissionCount++;
            }
        }
        return finishMissionCount;
    }

    @Override
    public Mission queryMainMission(long userId) {
        MissionList missionList = this.queryUserMissionList(userId);
        if (missionList.getUserMissions().size() != 0) {
            List<Mission> missions = missionList.getUserMissions();
            Iterator<Mission> it = missions.iterator();
            while (it.hasNext()) {
                Mission mission = it.next();
                if (mission.getCategoryId() == MissionType.CATEGORY_MAIN_MISSION.getType() && mission.getStatus() <= MissionStatus.STATUS_FINISHED.getId()) {
                    return mission;
                }
            }
        }
        return null;
    }

    @Override
    public DailyMissionActive queryDailyMissionActive(long userId) {
        String key = MissionKey.getActiveKey(userId);
        Object o = client.get(key);
        if (o == null) {
            return new DailyMissionActive(userId);
        } else {
            return new DailyMissionActive((byte[]) o);
        }
    }

    @Override
    public void saveDailyMissionActive(long userId, DailyMissionActive missionActive) {
        String key = MissionKey.getActiveKey(userId);
        client.set(key, missionActive.toByteArray());
    }

}
