package com.hoolai.sangoh5.bo.battle.unit;

import com.hoolai.sangoh5.bo.battle.fight.SoliderSequence;


/**
 * 战斗单位名称
 * 
 */
public enum FightUnitName {

    att_officer {
		@Override
		public FightUnitType info() {
			return new FightUnitType("att_officer",UnitType.officer,FightType.attack,7);
		}

    },
    def_officer {
		@Override
		public FightUnitType info() {
			return new FightUnitType("def_officer",UnitType.officer,FightType.defense,7);
		}
    },
    def_1 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("def_1",UnitType.soldier,FightType.defense,1);
		}
    },
    def_2 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("def_2",UnitType.soldier,FightType.defense,2);
		}
    },
    def_3 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("def_3",UnitType.soldier,FightType.defense,3);
		}
    },
    def_4 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("def_4",UnitType.soldier,FightType.defense,4);
		}
    },
    def_5 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("def_5",UnitType.soldier,FightType.defense,5);
		}
    },
    def_6 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("def_6",UnitType.soldier,FightType.defense,6);
		}
    },
    att_1 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("att_1",UnitType.soldier,FightType.attack,1);
		}
    },
    att_2 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("att_2",UnitType.soldier,FightType.attack,2);
		}
    },
    att_3 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("att_3",UnitType.soldier,FightType.attack,3);
		}
    },
    att_4 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("att_4",UnitType.soldier,FightType.attack,4);
		}
    },
    att_5 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("att_5",UnitType.soldier,FightType.attack,5);
		}
    },
    att_6 {
		@Override
		public FightUnitType info() {
			return new FightUnitType("att_6",UnitType.soldier,FightType.attack,6);
		}
    }
    ;
    
    public abstract FightUnitType info();
    
    
    public enum UnitType{
    	officer,soldier;
    }
    
    public enum FightType{
    	attack,defense
    }
    
    public class FightUnitType{
    	private boolean isOfficer;
    	private boolean isSoldier;
    	private String unitName;
    	private boolean isAttacker;
    	private int pos;
    	private SoliderSequence soliderSequence;
    	
    	public FightUnitType(String unitName,UnitType unitType,FightType fightType,int pos){
    		this.isAttacker = fightType == FightType.attack;
    		this.isOfficer = unitType == UnitType.officer;
    		this.isSoldier = unitType == UnitType.soldier;
    		this.unitName = unitName;
    		this.pos = pos;
    	}
    	
		public boolean isOfficer() {
			return isOfficer;
		}
		public boolean isSoldier() {
			return isSoldier;
		}
		public String getUnitName() {
			return unitName;
		}
		public boolean isAttacker() {
			return isAttacker;
		}

		public int getPos() {
			return pos;
		}
    	
    }

	public static FightUnitName officerUnitName(boolean isAttacker) {
		 return isAttacker ? att_officer : def_officer;
	}

	public static FightUnitName unitName(boolean isAttacker, int pos) {
		if(isAttacker){
			switch(pos){
			case 1:
				return att_1;
			case 2:
				return att_2;
			case 3:
				return att_3;
			case 4:
				return att_4;
			case 5:
				return att_5;
			case 6:
				return att_6;
			case 7:
				return att_officer;
				default:
					return null;
			}
		}else{
			switch(pos){
			case 1:
				return def_1;
			case 2:
				return def_2;
			case 3:
				return def_3;
			case 4:
				return def_4;
			case 5:
				return def_5;
			case 6:
				return def_6;
			case 7:
				return def_officer;
				default:
					return null;
			}
		}
	}
}
