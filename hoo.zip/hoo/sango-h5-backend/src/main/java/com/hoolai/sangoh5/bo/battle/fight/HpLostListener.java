package com.hoolai.sangoh5.bo.battle.fight;

import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;

public interface HpLostListener {

    void onHpLost(FightUnitName name, int lostPoint);
    
    //生命值回复
    void onHpRevival(FightUnitName name, int revivalPoint);
    
    public int getCurrLostPoint();
    
    public float lostPercentage();
    
    /**
     * 默认的监听器
     */
    HpLostListener NONE = new HpLostListener() {
        @Override
        public void onHpLost(FightUnitName name, int lostPoint) {
            //do nothing
        }

        @Override
        public void onHpRevival(FightUnitName name, int revivalPoint) {
            //do nothing
        }

		@Override
		public int getCurrLostPoint() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public float lostPercentage() {
			// TODO Auto-generated method stub
			return 0;
		}
    };
    
}
