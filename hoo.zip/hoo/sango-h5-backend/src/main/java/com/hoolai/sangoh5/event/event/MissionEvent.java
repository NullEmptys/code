package com.hoolai.sangoh5.event.event;

import com.hoolai.sangoh5.bo.mission.data.MissionProperty;
import com.hoolai.sangoh5.event.Event;
import com.hoolai.sangoh5.event.EventType;

public class MissionEvent {

	private MissionProperty missionProperty;
	
	private int missionDetail;
	
	private long userId;
	
	public MissionEvent(MissionProperty missionProperty, int missionDetail, long userId){
		this.missionDetail = missionDetail;
		this.missionProperty = missionProperty;
		this.userId = userId;
	}

	public MissionProperty getMissionProperty() {
		return missionProperty;
	}

	public void setMissionProperty(MissionProperty eventType) {
		this.missionProperty = eventType;
	}

	public int getMissionDetail() {
		return missionDetail;
	}

	public void setMissionDetail(int missionDetail) {
		this.missionDetail = missionDetail;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
	
}
