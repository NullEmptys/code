package com.hoolai.sangoh5.bo.battle.skill.defence.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 防御技能
 *
 */
public abstract class DefencePassiveSkill extends Skill {

    public static final DefencePassiveSkill NONE = new DefencePassiveSkill() {

        @Override
        public Skill clone() {
            return this;
        }

        @Override
        public void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {
            //DO NOTHING
        }
    };

    /**
     * 发动防御技能
     * 
     * @param actor 攻击者
     * @param target 防御者
     * @param effect 攻击者攻击Effect
     * @param tc 战斗单元集合，用来查找相关战斗单元
     * @param targets 在Match中作用apply的目标收集列表
     * @param currentLevel TODO
     */
    public abstract void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel);
}
