package com.hoolai.sangoh5.bo.union;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.UnionProtocolBuffer.ApplyUnionInfoProto;

public class ApplyUnionInfo implements ProtobufSerializable<ApplyUnionInfoProto>, Comparable<ApplyUnionInfo>{

	private long applyerId;//申请者userID
	private long applyTime;//申请的时间
	
	public ApplyUnionInfo() {
		super();
	}
	public ApplyUnionInfo(long applyUnionId, long applyTime) {
		super();
		this.applyerId = applyUnionId;
		this.applyTime = applyTime;
	}
	public ApplyUnionInfo(ApplyUnionInfoProto message) {
		super();
		copyFrom(message);
	}

	@Override
	public ApplyUnionInfoProto copyTo() {
		ApplyUnionInfoProto.Builder builder = ApplyUnionInfoProto.newBuilder();
		builder.setApplyerId(applyerId);
		builder.setApplyTime(applyTime);
		return builder.build();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			copyFrom(ApplyUnionInfoProto.parseFrom(bytes));
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void copyFrom(ApplyUnionInfoProto message) {
		this.applyerId = message.getApplyerId();
		this.applyTime = message.getApplyTime();
	}
	
	public static void main(String[] args) {
		long now = TimeUtil.currentTimeMillis();
		List<ApplyUnionInfo> asList = Arrays.asList(new ApplyUnionInfo(0, now + now/10), new ApplyUnionInfo(1, now + 2 * now/10), new ApplyUnionInfo(2, now - now/10));
		Collections.sort(asList);
		for(ApplyUnionInfo aUnionInfo : asList){
			System.out.println(aUnionInfo.applyerId);
		}
	}
	@Override
	public int compareTo(ApplyUnionInfo o) {
		if(o.applyTime == applyTime)
			return 0;
		if(o.applyTime > applyTime )
			return 1;
		return -1;
	}
	public long getApplyerId() {
		return applyerId;
	}
	public void setApplyerId(long applyerId) {
		this.applyerId = applyerId;
	}
	public long getApplyTime() {
		return applyTime;
	}
	public void setApplyTime(long applyTime) {
		this.applyTime = applyTime;
	}
	
	public boolean isEnough72Hours() {
		return TimeUtil.currentTimeMillis() - this.applyTime >= TimeUnit.HOURS.toMillis(72);
	}
	@Override
	public String toString() {
		return "ApplyUnionInfo [applyerId=" + applyerId + ", applyTime="
				+ applyTime + "]";
	}
}
