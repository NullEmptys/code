package com.hoolai.sangoh5.bo.activity;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.CdkeysProto;
import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Cdkeys implements ProtobufSerializable<CdkeysProto> {

    private List<Cdkey> cdkeys;

    public Cdkeys(byte[] bytes) {
        parseFrom(bytes);
    }

    public Cdkeys() {
        this.cdkeys = Lists.newArrayList();
    }

    public List<Cdkey> getCdkeys() {
        return cdkeys;
    }

    @Override
    public CdkeysProto copyTo() {
        CdkeysProto.Builder builder = CdkeysProto.newBuilder();
        if (CollectionUtils.isNotEmpty(cdkeys)) {
            for (Cdkey cdkey : cdkeys) {
                builder.addCdkey(cdkey.copyTo());
            }
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            CdkeysProto message = CdkeysProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(CdkeysProto message) {
        int count = message.getCdkeyCount();
        this.cdkeys = Lists.newArrayListWithExpectedSize(count);
        for (int i = 0; i < count; i++) {
            Cdkey cdkey = new Cdkey(message.getCdkey(i));
            cdkeys.add(cdkey);
        }
    }

    public Cdkey findCdkeyByCode(String cdkeyCode) {
        for (Cdkey cdkey : cdkeys) {
            if (cdkey.getKeys().contains(cdkeyCode)) {
                return cdkey;
            }
        }
        return null;
    }

    public Cdkey findCdkey(int id) {
        for (Cdkey cdkey : cdkeys) {
            if (cdkey.getId() == id) {
                return cdkey;
            }
        }
        return null;
    }

    public Set<String> findAllCdkey() {
        Set<String> allKeys = Sets.newHashSet();
        for (Cdkey cdkey : cdkeys) {
            allKeys.addAll(cdkey.getKeys());
        }
        return allKeys;
    }

    public String randomKey() {
        Set<String> oldKeys = findAllCdkey();
        for (int i = 0; i < 10; i++) {
            String key = RandomStringUtils.randomAlphanumeric(10);
            if (!oldKeys.contains(key)) {
                return key;
            }
        }
        throw new RuntimeException("not found cdkey ");
    }

    public void newCdkey(int cdkeyId, String name, int times, List<Award> awardList) {
        String key = randomKey();
        Cdkey cdkey = new Cdkey(cdkeyId, name, Sets.newHashSet(key), times, awardList);
        this.cdkeys.add(cdkey);
    }

    public void checkKey(Cdkey cdkey, String key) {
        if (StringUtils.isEmpty(key)) {
            throw new RuntimeException("key is empty");
        }
        if (cdkey.getKeys().contains(key)) {
            return;
        }
        Set<String> oldKeys = findAllCdkey();
        if (oldKeys.contains(key)) {
            throw new RuntimeException("key has exist");
        }
    }

    public void deleteCdkey(int cdkeyId) {
        Iterator<Cdkey> iterator = cdkeys.iterator();
        while (iterator.hasNext()) {
            Cdkey next = iterator.next();
            if (next.getId() == cdkeyId) {
                iterator.remove();
            }
        }
    }

}
