package com.hoolai.sangoh5.bo.award;

public class OfficerAward extends Award {
	
	private int starLevel = 1;
	
	private int level = 1;

	public OfficerAward(int xmlId, int num,  int starLevel, int level) {
		super(xmlId, num, AwardType.OFFICER);
		this.starLevel = starLevel;
		this.level = level;
	}

	public int getStarLevel() {
		return starLevel;
	}

	public void setStarLevel(int starLevel) {
		this.starLevel = starLevel;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}
	

	

	
}
