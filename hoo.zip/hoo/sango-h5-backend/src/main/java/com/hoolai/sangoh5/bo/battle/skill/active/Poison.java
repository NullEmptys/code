package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ChangeDefenseBuff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.RangeSustainedBuff;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 毒
 * 
 * 持续性掉血，并持续减少防御力
 * 
 * @author Administrator
 *
 */
public class Poison extends IndependentSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {

        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> alives = aliveTargetUnitList(tc, actor);
        for (FightUnit target : alives) {
            List<Buff> buffs = target.findBuffs(this.xmlId);
            if (buffs.size() < 1) {
                target.addBuff(new RangeSustainedBuff(actor, target.name(), this, currentLevel, Math.round(value)).withActorName(actor.name()).withTargetName(target.name())
                        .withKeepBuff().withRepeatCount(repeatCount));

                Buff sbuff = new ChangeDefenseBuff(xmlId, name, target.name(), actor, forceType, Action.DEFAULT_ACTION_LEVEL, twoPercentage).withKeepBuff()
                        .withActorName(actor.name()).withTargetName(target.name()).withRepeatCount(twoRepeatCount);
                sbuff.apply(target);
                target.addBuff(sbuff);
            } else {
                for (Buff buff : buffs) {
                    buff.setRepeatCount(repeatCount);
                }
            }
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]使" + target.name() + "毒发，造成持续性伤害=" + Math.round(value) + ",持续回合数=" + repeatCount + ",防御力下降率"
                    + twoPercentage + "持续回合数=" + twoRepeatCount);
            targets.add(target);
        }
        return targets;
    }

    @Override
    public Skill clone() {
        return super.clone(new Poison());
    }

}
