package com.hoolai.sangoh5.bo.mission.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-26 11:00
 * @version : 1.0
 */
@Component
public class NoviceData extends JsonData<NoviceProperty> {

    @PostConstruct
    @Override
    public void init() {
        try {
            initData("com/hoolai/sangoh5/novice.json", NoviceProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(NoviceProperty property) {
        // TODO Auto-generated method stub

    }

}
