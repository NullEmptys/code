package com.hoolai.sangoh5.repo;

import com.hoolai.sangoh5.bo.barrack.Barrack;

public interface BarrackRepo {

	boolean saveBarrack(Barrack barrack);
	
	Barrack findBarrack(long userId);
}
