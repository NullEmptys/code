package com.hoolai.sangoh5.bo.battle.skill.trigger;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.skill.Occasion;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.SkillType;
import com.hoolai.sangoh5.bo.battle.skill.active.BaseOfficerPhysicsSkill;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;

public class OfficerSkillTrigger extends SkillTrigger {

    private int indepSkillSize;

    private int coolingInterval;

    private FightUnit actor;

    public OfficerSkillTrigger(FightUnit actor, BaseOfficerPhysicsSkill physicsSkill, List<Skill> skills) {
        this.pg = physicsSkill.getPg();
        this.officerAttackSkill = physicsSkill;
        this.skills = skills;
        this.actor = actor;
        init();

        this.indepSkillSize = beforeActionIndeSkills.size();
        this.coolingInterval = coolingInterval();
    }

    @Override
    protected void init() {
        for (Skill skill : this.skills) {
            if (skill.getUser() != 0) {//将领是0
                continue;
            }
            SkillType skillType = skill.getSkillType();
            switch (skillType) {
                case ACTIVE:
                    independentSkills.add(skill);
                    if (skill.getOccasion() == Occasion.AFTER_ACTION) {
                        afterActionIndeSkills.add(skill);
                    } else if (skill.getOccasion() == Occasion.BEFORE_ACTION) {
                        beforeActionIndeSkills.add(skill);
                    }
                    break;
                case DEFENCE:
                    defenceSkills.add(skill);
                    break;
                default:
                    break;
            }
        }
    }

    private int coolingInterval() {
        if (indepSkillSize <= 4) {
            return 4;
        }
        return 5;
    }

    @Override
    public IndependentSkill triggerAttackSkill() {
        if (independentSkills.size() < 1) {
            return officerAttackSkill;
        }

        int index = independentSkillIndex++ % coolingInterval;
        //        System.out.println(indepSkillSize + ":执行顺序=" + index);

        if (index < indepSkillSize) {
            Skill skill = beforeActionIndeSkills.get(index);
            //            System.out.println(indepSkillSize + ":选取技能=" + skill.getName());
            boolean isLuck = pg.getRandomWithPercentage(skill.getChance());
            if (isLuck) {
                //                System.out.println(indepSkillSize + ":选取技能=" + skill.getName() + "触发成功");
                actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发成功");
                return (IndependentSkill) skill;
            } else {
                actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发失败");
            }
        }

        return officerAttackSkill;
    }

    @Override
    public DefenceSkill triggerDefenceSkill() {
        if (defenceSkills.size() < 1) {
            return DefenceSkill.NONE;
        }

        int index = defenceSkillIndex % defenceSkills.size();
        defenceSkillIndex++;

        Skill skill = defenceSkills.get(index);
        if (pg.getRandomWithPercentage(skill.getChance())) {
            actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发成功");
            return (DefenceSkill) skill;
        } else {
            actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发失败");
        }

        return DefenceSkill.NONE;
    }

    /**
     * after_action的技能，按概率
     * 
     * @return
     */
    @Override
    public IndependentSkill triggerActionSkill() {
        int index = actionSkillIndex % afterActionIndeSkills.size();
        actionSkillIndex++;

        Skill skill = afterActionIndeSkills.get(index);
        boolean isLuck = pg.getRandomWithPercentage(skill.getChance());
        if (isLuck) {
            actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发成功");
            return (IndependentSkill) skill;
        } else {
            actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发失败");
        }

        return IndependentSkill.NONE;
    }

    @Override
    public void changeAllSkillChance(float chance) {
        chance = chance / 100f;
        for (int index = 0; index < independentSkills.size(); index++) {
            Skill skill = independentSkills.get(index);
            skill.changeChance(skill.getChance() * chance);
        }

        for (int index = 0; index < defenceSkills.size(); index++) {
            Skill skill = defenceSkills.get(index);
            skill.changeChance(skill.getChance() * chance);
        }
    }

    @Override
    public boolean changeSkillChance(int xmlId, float chance) {

        List<Skill> allSkills = new ArrayList<Skill>();
        allSkills.addAll(independentSkills);
        allSkills.addAll(defenceSkills);

        int index = 0;
        for (; index < allSkills.size(); index++) {
            if (allSkills.get(index).getXmlId() == xmlId) {
                break;
            }
        }

        if (index == allSkills.size()) {
            return false;
        }
        Skill skill = allSkills.get(index);
        skill.changeChance(chance);
        return true;
    }

    /**
     * 将领被貂蝉的闭月斩封技能，不能封主动天赋技能 <br/>
     * 故主动天赋技能接下来或许触发概率会比原来没被封前大
     */
    @Override
    public void silence() {
        Iterator<Skill> it = skills.iterator();
        while (it.hasNext()) {
            Skill skill = it.next();
            it.remove();
            silenceSkills.add(skill);
        }
        init();
    }

    // 封闭某些技能，使得其不会触发
    private final List<Skill> silenceSkills = new ArrayList<Skill>();

    @Override
    public void unsilence() {
        if (silenceSkills.isEmpty()) {
            return;
        }

        independentSkills.addAll(silenceSkills);
        silenceSkills.clear();
        //    	init();

        for (Float changeChance : changeChanceList) {
            changeAllSkillChance(changeChance);
        }
    }

    private final List<Float> changeChanceList = new ArrayList<Float>();

    /**
     * 记录下改变概率的值，便于上面unsilence恢复的时候回复正确的概率
     */
    @Override
    public void recordChangeChance(float chance) {
        changeChanceList.add(chance);
    }

}
