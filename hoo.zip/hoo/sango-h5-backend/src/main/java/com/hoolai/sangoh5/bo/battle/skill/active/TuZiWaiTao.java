package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.RangeSustainedBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 竭心之术
 * 
 * @author Administrator
 *
 */
public class TuZiWaiTao extends IndependentSkill {

    @Override
    public Skill clone() {
        return super.clone(new TuZiWaiTao());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            Buff buff = target.findBuff(this.xmlId);
            int delHp = 0;
            if (buff == null) {
                delHp = calLostPoint(target.getOriginalHp());
                target.addBuff(new RangeSustainedBuff(actor, target.name(), this, currentLevel, delHp).withActorName(actor.name()).withTargetName(target.name()).withKeepBuff()
                        .withRepeatCount(repeatCount));
            } else {
                delHp = buff.getDeltaHp();
                buff.setRepeatCount(repeatCount);
            }
            targets.add(target);

            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]对" + target.name() + "造成持续性伤害=" + delHp + ",持续回合数=" + repeatCount + ",持续回合数=" + repeatCount);
        }

        return targets;
    }

    private int calLostPoint(float originalHp) {
        return Math.round(originalHp * percentage);
    }

}
