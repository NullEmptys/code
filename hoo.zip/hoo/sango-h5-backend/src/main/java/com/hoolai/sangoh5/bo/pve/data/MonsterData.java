package com.hoolai.sangoh5.bo.pve.data;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.equip.Equip;
import com.hoolai.sangoh5.bo.equip.Equip.ItemPosition;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.soldier.Soldier;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.soldier.data.SoldierProperty;
import com.hoolai.sangoh5.bo.tacticalManagement.Formation;
import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.IntHashMap;
import com.hoolai.util.JSONUtils;

@Component
public class MonsterData extends JsonData<MonsterProperty> {

    //排位战上位后，原先的位置由Npc占位
    protected IntHashMap<MonsterProperty> rankPropertyMap = new IntHashMap<MonsterProperty>();

    //pve关卡怪物
    protected IntHashMap<MonsterProperty> pvePropertyMap = new IntHashMap<MonsterProperty>();

    // 竞技场未匹配到痛等级用户的时候，默认NPC上
    protected IntHashMap<MonsterProperty> areaPropertyMap = new IntHashMap<MonsterProperty>();

    // pvp，生成NPC解救
    protected IntHashMap<MonsterProperty> pvpPropertyMap = new IntHashMap<MonsterProperty>();

    @Autowired
    private BoFactory boFactory;

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/monster.json", MonsterProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void initData(String path, Class<MonsterProperty> clazz) throws IOException {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        InputStream input = loader.getResourceAsStream(path);
        if (input == null) {
            throw new IllegalArgumentException("找不到配置文件" + path);
        }

        String jsonStr = IOUtils.toString(input);
        List<MonsterProperty> properties = JSONUtils.fromJSONToList(jsonStr, clazz);
        for (MonsterProperty property : properties) {
            int id = property.getId();
            Assert.isTrue(!propertyMap.containsKey(id), path + " 存在相同的id=" + id);
            checkProperty(property);
            propertyMap.put(id, property);
            //          logger.info("Json Loaded "+property);

            if (property.getType() == 1) {
                pvePropertyMap.put(id, property);
            } else if (property.getType() == 2) {
                rankPropertyMap.put(id, property);
            } else if (property.getType() == 3) {
                pvpPropertyMap.put(id, property);
            } else if (property.getType() == 4) {
                areaPropertyMap.put(id, property);
            }

            initForEach(property);
        }
    }

    public Officer createMonster(int monsterId) {

        Officer officer = new Officer();

        // 基本信息
        MonsterProperty property = this.getProperty(monsterId);
        officer.setXmlId(property.getOfficerId());
        officer.setId(-1);
        officer.setAttack(property.getAttack());
        officer.setAttackSpeed(property.getAs());
        officer.setDefence(property.getDefence());
        officer.setHp(property.getHp());
        officer.setMoveSpeed(property.getMs());
        officer.setLevel(property.getOfficerLv());
        officer.setName(property.getName());
        officer.setStation(-1);
        officer.setStarLevel(property.getStarLv());

        // 装备
        Integer[] defaultEquipXmlIds = { property.getWeapon(), property.getArmor(), property.getHelmet(), property.getHorse() };
        List<Equip> equipList = new ArrayList<Equip>();
        for (int xmlId : defaultEquipXmlIds) {
            equipList.add(new Equip(xmlId, ItemPosition.in_officer.ordinal()));
        }
        officer.setEquipList(equipList);

        // 技能
        officer.setSkills(property.getSkill());

        // 带兵
        int[] soldiers = property.getSoldierType();
        List<SoldierType> soldierTypes = new ArrayList<SoldierType>();
        int[] soldierAmount = property.getSoldierAmount();
        for (int i = 0; i < soldiers.length; i++) {
            SoldierProperty soldierProperty = boFactory.getSoldierData().getProperty(soldiers[i]);
            SoldierType soldierType = SoldierType.valueOf(soldierProperty.getSoldierType());
            soldierTypes.add(soldierType);

            Soldier soldier = new Soldier(soldierType);
            soldier.setAttackSpeed(soldierProperty.getAttackSpeed());
            soldier.setBaseNum(soldierAmount[i]);
            soldier.setMoveSpeed(soldierProperty.getMoveSpeed());
            soldier.setBaseAttack(soldierProperty.getBaseAttack()[0]);
            soldier.setBaseDefence(soldierProperty.getBaseDefence()[0]);
            soldier.setNum(soldierAmount[i]);
            soldier.setXmlId(soldiers[i]);
            soldier.setSkills(new int[] { soldierProperty.getBornSkill() });

            officer.getSoldiers().add(soldier);
        }

        //初始化阵法
        Formation formation = new Formation(boFactory.getTacticalData(), property.getDefaultTactical(), soldierTypes);
        List<Formation> formations = new ArrayList<Formation>();
        formations.add(formation);
        officer.setCurrFormation(formation);
        officer.setFormations(formations);

        boFactory.inject(officer);
        officer.fillEquip();
        officer.fillSkillEnhance();
        officer.fillFormations();
        officer.fillAllOfficerEnhance();
        return officer;
    }

    @Override
    protected void checkProperty(MonsterProperty property) {
        // TODO Auto-generated method stub

    }

    public Officer createRankMonster() {
        int[] ids = idArr(rankPropertyMap);
        return createMonster(ids[pg.getRandomNumber(ids.length - 1)]);
    }

    public Officer createArenaMonster() {
        int[] ids = idArr(areaPropertyMap);
        return createMonster(ids[pg.getRandomNumber(ids.length - 1)]);
    }

    public Officer generPvpMonster() {
        int[] ids = idArr(pvpPropertyMap);
        return createMonster(ids[pg.getRandomNumber(ids.length - 1)]);
    }

    public int generPvpMonsterXmlId() {
        int[] ids = idArr(pvpPropertyMap);
        return createMonster(ids[pg.getRandomNumber(ids.length - 1)]).getXmlId();
    }

    private int[] idArr(IntHashMap<MonsterProperty> propertyMap) {
        int[] ids = new int[propertyMap.values().size()];
        int i = 0;
        for (MonsterProperty property : propertyMap.values()) {
            ids[i++] = property.getId();
        }
        return ids;
    }

}
