package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class AddDesktopKey {
	
	private static final String prefix= "addDesk";
	
	public static String getAddDesktopKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("id").toString();
    }

}
