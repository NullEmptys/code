package com.hoolai.sangoh5.bo.mission.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-26 10:59
 * @version : 1.0
 */
public class NoviceProperty extends JsonProperty {

    /** 步骤名称 **/
    private String name;

    /** 类型 **/
    private int move;

    /** 位置 **/
    private int type;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMove() {
        return move;
    }

    public void setMove(int move) {
        this.move = move;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

}
