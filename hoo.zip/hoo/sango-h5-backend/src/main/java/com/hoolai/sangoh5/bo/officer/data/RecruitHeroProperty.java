package com.hoolai.sangoh5.bo.officer.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * 招募英雄配置表
 * 
 * @author hp
 *
 */
public class RecruitHeroProperty extends JsonProperty {
	private int type; // 所属类型
	private int goodsId; // 招募到的将领id
	private int goodsStar;// 招募到将领的星级

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(int goodsId) {
		this.goodsId = goodsId;
	}

	public int getGoodsStar() {
		return goodsStar;
	}

	public void setGoodsStar(int goodsStar) {
		this.goodsStar = goodsStar;
	}

}
