package com.hoolai.sangoh5.bo.payment.data;

import java.io.IOException;
import java.util.Arrays;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class RechargeHallData extends JsonData<RechargeHallProperty>{

	@Override
	@PostConstruct
	public void init() {
		try {
    		initData("com/hoolai/sangoh5/rechargeHall.json", RechargeHallProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void checkProperty(RechargeHallProperty property) {
		// TODO Auto-generated method stub
		
	}

	public int getMaxId() {
		int ids[] = idArr();
		Arrays.sort(ids);
		return ids[ids.length-1];
	}

	public int[] getFirstPayIds() {
		int ids[] = idArr();
		Arrays.sort(ids);
		return ids;
	}

}
