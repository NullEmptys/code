package com.hoolai.sangoh5.bo.payment.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class MoonWeekCardData extends JsonData<MoonWeekProperty>{

	@Override
	@PostConstruct
	public void init() {
		try {
    		initData("com/hoolai/sangoh5/moonWeek.json", MoonWeekProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void checkProperty(MoonWeekProperty property) {
		// TODO Auto-generated method stub
		
	}

	public MoonWeekProperty getMoonCardProperty(int type) {
		for(MoonWeekProperty property:this.propertyMap.values()){
			if(property.getType() == type){
				return property;
			}
		}
		return null;
	}

}
