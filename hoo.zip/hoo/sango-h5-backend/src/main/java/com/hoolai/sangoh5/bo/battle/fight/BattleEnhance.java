package com.hoolai.sangoh5.bo.battle.fight;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.ForceUnitType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.soldier.SoldierType;

public class BattleEnhance {

    /**
     * 目前有农田、矿洞、将领驻守加成
     * 需要让前端显示
     */
    private List<Skill> enhanceSkills = new ArrayList<Skill>();

    /**
     * 目前有阵型加成,士兵科技
     * 不需要前端显示
     */
    private List<Skill> otherEnhanceSkills = new ArrayList<Skill>();

    public void addSkill(Skill skill) {
        this.enhanceSkills.add(skill);
    }

    public void addOtherSkills(List<Skill> skills) {
        otherEnhanceSkills.addAll(skills);
    }

    public List<Skill> getOtherEnhanceSkills() {
        return otherEnhanceSkills;
    }

    public List<Skill> getEnhanceSkill() {
        return enhanceSkills;
    }

    public int[] getDisplayEnhanceSkillsArr() {
        int arr[] = new int[enhanceSkills.size()];
        int i = 0;
        for (Skill skill : enhanceSkills) {
            arr[i] = skill.getXmlId();
            i++;
        }
        return arr;
    }

    public int[] getOtherEnhanceSkillsArr() {
        List<Skill> temp = new ArrayList<Skill>();
        for (Skill skill : otherEnhanceSkills) {
            if (AttributeType.isBaseProperty(skill.getAttributeType())) {
                temp.add(skill);
            }
        }

        int arr[] = new int[temp.size()];
        int i = 0;
        for (Skill skill : temp) {
            arr[i] = skill.getXmlId();
            i++;
        }
        return arr;
    }

    public List<Skill> getOfficerEnhanceSkill() {
        List<Skill> skills = new ArrayList<Skill>();
        for (Skill skill : enhanceSkills) {
            if (skill.getAttackUnitType() == ForceUnitType.OFFICER) {
                skills.add(skill);
            }
        }
        return skills;
    }

    public List<Skill> getOfficerOtherEnhanceSkills() {
        List<Skill> skills = new ArrayList<Skill>();
        for (Skill skill : otherEnhanceSkills) {
            if (skill.getAttackUnitType() == ForceUnitType.OFFICER) {
                skills.add(skill);
            }
        }
        return skills;
    }

    public List<Skill> getSoldierEnhanceSkill(SoldierType soldierType) {
        List<Skill> skills = new ArrayList<Skill>();

        for (Skill skill : enhanceSkills) {
            if (skill.getAttackUnitType() == ForceUnitType.SOLDIERS || skill.getAttackUnitType() == ForceUnitType.SOLDIER
                    || skill.getAttackUnitType().name().equalsIgnoreCase(soldierType.name()) || skill.getAttackUnitType().name().equalsIgnoreCase(soldierType.attackType().name())) {
                skills.add(skill);
            }
        }
        return skills;
    }

    public List<Skill> getSoldierOtherEnhanceSkills(SoldierType soldierType) {
        List<Skill> skills = new ArrayList<Skill>();
        for (Skill skill : otherEnhanceSkills) {
            if (skill.getAttackUnitType() == ForceUnitType.SOLDIERS || skill.getAttackUnitType() == ForceUnitType.SOLDIER
                    || skill.getAttackUnitType().name().equalsIgnoreCase(soldierType.name()) || skill.getAttackUnitType().name().equalsIgnoreCase(soldierType.attackType().name())) {
                skills.add(skill);
            }
        }
        return skills;
    }
}
