package com.hoolai.sangoh5.bo.officer;

import java.util.Comparator;

public class OfficerCompare implements Comparator<Object> {

	@Override
	public int compare(Object o1, Object o2) {
		Officer officer1 = (Officer) o1;
		Officer officer2 = (Officer) o2;
		int val = 0;
		int v = officer2.getLevel() - officer1.getLevel();
		if (v != 0) {
			val = v > 0 ? 3 : -1;
		} else {
			v = officer2.getStarLevel() - officer1.getStarLevel();
			if (v != 0) {
				val = v > 0 ? 2 : -2;
			}
		}
		return val;
	}

}
