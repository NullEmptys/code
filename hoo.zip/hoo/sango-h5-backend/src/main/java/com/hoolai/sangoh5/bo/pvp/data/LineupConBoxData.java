package com.hoolai.sangoh5.bo.pvp.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-13 11:23
 * @version : 1.0
 */
@Component
public class LineupConBoxData extends ConBoxData<LineupConBoxProperty> {

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/lineupConBox.json", LineupConBoxProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(LineupConBoxProperty property) {
        if (property.getRewardIds().length != property.getRewardNums().length || property.getRewardIds().length != property.getRewardTypes().length) {
            throw new RuntimeException("lineupConBox id = " + property.getId() + " 的奖励id，rewardsId, rewardsNums, rewardTypes 数组长度不一致");
        }
    }

}
