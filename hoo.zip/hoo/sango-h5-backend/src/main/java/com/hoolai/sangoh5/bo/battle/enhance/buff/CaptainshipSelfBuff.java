package com.hoolai.sangoh5.bo.battle.enhance.buff;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.fight.ActionResult;
import com.hoolai.sangoh5.bo.battle.fight.HpLostListener;
import com.hoolai.sangoh5.bo.battle.skill.passive.YueCuoYueYong;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 战火覆盖范围内改变防御力
 */
public class CaptainshipSelfBuff extends Buff {

    private FightUnit skillOwner;

    private final YueCuoYueYong skill;

    @Override
    public void targetEnhanceAfterExcuteBuffs(List<ActionResult> actionResultList, TargetCollection tc) {
        this.result();

        HpLostListener actorHpLostListener = skillOwner.getHpLostListener();

        float index = actorHpLostListener.lostPercentage();
        int oldIndex = skill.getAddAttackIndex();
        int add = (int) (index / (skill.getTwoPercentage() * 100f));

        if (add - oldIndex > 0) {
            skillOwner.addBattleLog(skillOwner.name() + "越挫越勇,目前我方死亡率" + index);

            float d = skillOwner.baseAttackPoint() * skill.getPercentage() * (add - oldIndex);
            skillOwner.changeAttackPoint(d);
            skill.setAddAttackIndex(add);

            skillOwner.addBattleLog(skillOwner.name() + "使用越挫越勇," + skillOwner.name() + "增加攻击力力" + d + ",attackPoint=" + skillOwner.attackPoint());

            ActionResult actionResult = findActionResult(skill.getXmlId(), skillOwner, actionResultList);
            actionResult.getBuffList().add(
                    new Buff(skill.getXmlId(), skill.getName(), skillOwner.name(), Buff.DEFAULT_BUFF_LEVEL).withActorName(skillOwner.name()).withTargetName(skillOwner.name()));
        }
    }

    @Override
    public void apply(FightUnit target) {
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * 此方法必要的时候需要在子类重写，否则会调用alive.unsilence()清除沉默产生负作用
     * 
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        //alive.removeBuff(this);
    }

    @Override
    protected CaptainshipSelfBuff clone() {
        CaptainshipSelfBuff buff = (CaptainshipSelfBuff) super.clone(new CaptainshipSelfBuff(this.targetUsedSkillXmlId, executeName, skillOwner, skill, currentLevel, isForFront));
        buff.skillOwner = skillOwner;
        return buff;
    }

    public CaptainshipSelfBuff(int xmlId, FightUnitName name, FightUnit actor, YueCuoYueYong skill, int currentLevel, boolean isFornt) {
        super(xmlId, skill.getName(), name, currentLevel);
        this.skillOwner = actor;
        this.skill = skill;
        this.isForFront = isFornt;
    }

}
