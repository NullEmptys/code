package com.hoolai.sangoh5.bo.officerunion;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.OfficerUnionProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class OfficerUnion implements ProtobufSerializable<OfficerUnionProto>{
	
	private int unionId;

	private List<OfficerUnionStar> officerUnionStars = new ArrayList<OfficerUnionStar>();
	
	public OfficerUnion(){}
	
	public OfficerUnion(int unionId){
		this.unionId = unionId;
	}

	public OfficerUnion(OfficerUnionProto message) {
		copyFrom(message);
	}
	
	public int getMinStarLv(){
		int minStarLv = 100;
		for(OfficerUnionStar officerUnionStar:officerUnionStars){
			minStarLv = Math.min(officerUnionStar.getMaxStarLv(), minStarLv);
		}
		
		return minStarLv;
	}

	@Override
	public OfficerUnionProto copyTo() {
		OfficerUnionProto.Builder builder = OfficerUnionProto.newBuilder();
		builder.setUnionId(unionId);
		
		for(OfficerUnionStar officerUnionStar:officerUnionStars){
			builder.addOfficerUnionStars(officerUnionStar.copyTo());
		}
		return builder.build();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			OfficerUnionProto message = OfficerUnionProto.parseFrom(bytes);
			copyFrom(message);
		} catch (InvalidProtocolBufferException e) {
			throw new BusinessException(ErrorCode.CAN_NOT_MEM);
		}
	}

	@Override
	public void copyFrom(OfficerUnionProto message) {
		this.unionId = message.getUnionId();
		
		int count = message.getOfficerUnionStarsCount();
		for(int i=0;i<count;i++){
			this.officerUnionStars.add(new OfficerUnionStar(message.getOfficerUnionStars(i)));
		}
	}

	public int getUnionId() {
		return unionId;
	}

	public void setUnionId(int unionId) {
		this.unionId = unionId;
	}

	public List<OfficerUnionStar> getOfficerUnionStars() {
		return officerUnionStars;
	}

	public void setOfficerUnionStars(List<OfficerUnionStar> officerUnionStars) {
		this.officerUnionStars = officerUnionStars;
	}
	
	public OfficerUnionStar findOfficerUnionStar(int xmlId){
		for(OfficerUnionStar officerUnionStar:officerUnionStars){
			if(officerUnionStar.getOfficerXmlId() == xmlId){
				return officerUnionStar;
			}
		}
		return null;
	}
	
	public void addOfficerUnionStar(OfficerUnionStar officerUnionStar){
		if(findOfficerUnionStar(officerUnionStar.getOfficerXmlId()) == null){
			this.officerUnionStars.add(officerUnionStar);
		}
	}

	public boolean updateStarLv(int xmlId, int starLevel) {
		OfficerUnionStar officerUnionStar = findOfficerUnionStar(xmlId);
		if(officerUnionStar!=null){
			return officerUnionStar.updateStarLv(starLevel);
		}
		return false;
	}

	public boolean collect(int xmlId, int starLv) {
		OfficerUnionStar officerUnionStar = findOfficerUnionStar(xmlId);
		return officerUnionStar.collect(xmlId,starLv);
	}
	
}
