package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ChangeDefenseBuff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.MoDunBuff;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 对所有友军单位释放魔免护盾，无视所有技能效果和技能伤害。持续5秒
 * 
 * @author Administrator
 *
 */
public class MoDun extends IndependentSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            shieldSkillHurt(actor, target, currentLevel, targets);
            changeDefenseBuff(actor, target, currentLevel, targets);
        }

        return targets;
    }

    private void shieldSkillHurt(FightUnit actor, FightUnit target, int currentLevel, List<FightUnit> targets) {
        Buff buff = findMoDunBuff(target);
        if (buff == null) {
            target.addBuff(new MoDunBuff(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name()).withKeepBuff()
                    .withRepeatCount(repeatCount));
            targets.add(target);
        } else {
            buff.setRepeatCount(repeatCount);
        }
        target.shieldSkillHurt();

        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]让" + target.name() + "屏蔽技能伤害,持续回合数=" + repeatCount);
    }

    private void changeDefenseBuff(FightUnit actor, FightUnit target, int currentLevel, List<FightUnit> targets) {
        Buff buff = findChangeDefenseBuff(target);
        if (buff == null) {
            Buff sbuff = new ChangeDefenseBuff(xmlId, name, target.name(), actor, forceType, Action.DEFAULT_ACTION_LEVEL, twoPercentage).withKeepBuff().withActorName(actor.name())
                    .withTargetName(target.name()).withRepeatCount(twoRepeatCount);
            sbuff.apply(target);
            target.addBuff(sbuff);
        } else {
            buff.setRepeatCount(twoRepeatCount);
        }

    }

    private Buff findMoDunBuff(FightUnit target) {
        Iterator<Buff> iterator = target.getBuffList().iterator();
        while (iterator.hasNext()) {
            Buff buff = iterator.next();
            if (buff instanceof MoDunBuff && buff.getTargetUsedSkillXmlId() == xmlId) {
                return buff;
            }
        }
        return null;
    }

    private Buff findChangeDefenseBuff(FightUnit target) {
        Iterator<Buff> iterator = target.getBuffList().iterator();
        while (iterator.hasNext()) {
            Buff buff = iterator.next();
            if (buff instanceof ChangeDefenseBuff && buff.getTargetUsedSkillXmlId() == xmlId) {
                return buff;
            }
        }
        return null;
    }

    @Override
    public Skill clone() {
        return super.clone(new MoDun());
    }

}
