package com.hoolai.sangoh5.bo.arena;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ArenaProtocolBuffer.ArenaOfficerProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class ArenaOfficer implements ProtobufSerializable<ArenaOfficerProto>, Comparable<ArenaOfficer> {

    private int officerXmlId;

    private int winNum;

    private int loseNum;

    private int score = 1000;

    transient private long userId;

    transient private boolean isAddWin;

    transient private String userName;

    transient private String userImage;

    transient private String unionName;

    transient private int userLevel;

    public ArenaOfficer(byte[] bytes) {
        parseFrom(bytes);
    }

    public ArenaOfficer(int officerXmlId) {
        this.officerXmlId = officerXmlId;
    }

    public ArenaOfficer(long userId, int xmlId) {
        this.userId = userId;
        this.officerXmlId = xmlId;
    }

    public ArenaOfficer(long userId, ArenaOfficerProto message) {
        this.userId = userId;
        copyFrom(message);
    }

    public int getOfficerXmlId() {
        return officerXmlId;
    }

    public void setOfficerXmlId(int officerXmlId) {
        this.officerXmlId = officerXmlId;
    }

    public int getWinNum() {
        return winNum;
    }

    public void setWinNum(int winNum) {
        this.winNum = winNum;
    }

    public int getLoseNum() {
        return loseNum;
    }

    public void setLoseNum(int loseNum) {
        this.loseNum = loseNum;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getFightNum() {
        return winNum + loseNum;
    }

    public void addScore(int officerScore) {
        this.score += officerScore;
    }

    public void decScore(int officerDecScore) {
        this.score -= officerDecScore;
    }

    public float findWinRate() {
        return Float.valueOf(winNum) / Float.valueOf(getFightNum());
    }

    public float findServerWinRate() {
        if (this.getFightNum() < 1000) {
            return 0.5f;
        }
        return findWinRate();
    }

    public boolean isAddWin() {
        return isAddWin;
    }

    public void addWinNum() {
        isAddWin = true;
        this.winNum++;
    }

    public void addLoseNum() {
        isAddWin = false;
        this.loseNum++;
    }

    public long getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

    public String getUnionName() {
        return unionName;
    }

    public void setUnionName(String unionName) {
        this.unionName = unionName;
    }

    public int getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(int userLevel) {
        this.userLevel = userLevel;
    }

    @Override
    public ArenaOfficerProto copyTo() {
        ArenaOfficerProto.Builder builder = ArenaOfficerProto.newBuilder();
        builder.setLoseNum(loseNum);
        builder.setOfficerXmlId(officerXmlId);
        builder.setScore(score);
        builder.setWinNum(winNum);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ArenaOfficerProto message = ArenaOfficerProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(ArenaOfficerProto message) {
        this.winNum = message.getWinNum();
        this.loseNum = message.getLoseNum();
        this.score = message.getScore();
        this.officerXmlId = message.getOfficerXmlId();
    }

    @Override
    public int compareTo(ArenaOfficer arenaOfficer) {
        long diff = arenaOfficer.getScore() - getScore(); //降序，从大到小
        if (diff == 0) {
            return sgn(getUserId() - arenaOfficer.getUserId()); //升序，从小到大
        }
        return sgn(diff);
    }

    private int sgn(long diff) {
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        } else {
            return 0;
        }
    }

}
