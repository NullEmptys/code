package com.hoolai.sangoh5.bo.farmland.data;

import java.io.IOException;
import java.util.Iterator;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class FarAndMinUnlockPosData extends JsonData<FarAndMinUnlockPosProperty> {

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/slave.json", FarAndMinUnlockPosProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void checkProperty(FarAndMinUnlockPosProperty property) {
        // TODO Auto-generated method stub

    }

    public int getPropertySizeBuyType(int userLevel, int famOrMinLevel, int type) {
        int unlockPosSize = 0;
        Iterator<FarAndMinUnlockPosProperty> tempPropertyIt = this.getPropertyMap().values().iterator();
        while (tempPropertyIt.hasNext()) {
            FarAndMinUnlockPosProperty tempProperty = tempPropertyIt.next();
            if (tempProperty.getLandType() == type) {
                if (tempProperty.getOpenCondition().getCharacterLv() != 0 && tempProperty.getOpenCondition().getCharacterLv() <= userLevel) {
                    unlockPosSize++;
                } else if (tempProperty.getOpenCondition().getLandLv() != 0 && tempProperty.getOpenCondition().getLandLv() <= famOrMinLevel) {
                    unlockPosSize++;
                }
            }
        }
        return unlockPosSize;
    }
}
