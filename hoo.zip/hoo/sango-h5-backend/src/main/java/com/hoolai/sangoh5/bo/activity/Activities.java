package com.hoolai.sangoh5.bo.activity;

import java.util.Collection;
import java.util.Map;

import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.ActivitiesProto;
import com.hoolai.sangoh5.bo.activity.data.ActivityBaseProperty;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Activities implements ProtobufSerializable<ActivitiesProto> {

    private Map<Integer, Activity> activityMap;

    transient private long userId;

    public Activities(long userId, byte[] bytes) {
        this.userId = userId;
        parseFrom(bytes);
    }

    public Activities(long userId) {
        this.userId = userId;
        this.activityMap = Maps.newHashMapWithExpectedSize(10);
    }

    @Override
    public ActivitiesProto copyTo() {
        ActivitiesProto.Builder builder = ActivitiesProto.newBuilder();
        Collection<Activity> values = this.activityMap.values();
        for (Activity activity : values) {
            builder.addActivity(activity.copyTo());
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ActivitiesProto message = ActivitiesProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(ActivitiesProto message) {
        int activityCount = message.getActivityCount();
        this.activityMap = Maps.newHashMapWithExpectedSize(activityCount);
        for (int i = 0; i < activityCount; i++) {
            Activity activity = new Activity(message.getActivity(i));
            this.activityMap.put(activity.getActivityId(), activity);
        }
    }

    public long getUserId() {
        return userId;
    }

    public void addActivity(Activity activity) {
        this.activityMap.put(activity.getActivityId(), activity);
    }

    public Activity findActivityById(int activityId) {
        return activityMap.get(activityId);
    }

    public Activity findActivityByProperty(ActivityBaseProperty property) {
        Activity activity = this.findActivityById(property.getId());
        if (activity != null) {
            return activity;
        }
        activity = new Activity(property);
        addActivity(activity);
        return activity;
    }

    public Map<Integer, Activity> getActivityMap() {
        return activityMap;
    }

}
