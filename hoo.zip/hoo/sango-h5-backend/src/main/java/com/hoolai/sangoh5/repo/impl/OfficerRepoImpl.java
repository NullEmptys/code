package com.hoolai.sangoh5.repo.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.OfficerProto;
import com.hoolai.sangoh5.bo.mission.data.MissionProperty;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.officerunion.OfficerUnion;
import com.hoolai.sangoh5.bo.officerunion.OfficerUnions;
import com.hoolai.sangoh5.event.event.MissionEvent;
import com.hoolai.sangoh5.repo.OfficerRepo;
import com.hoolai.sangoh5.repo.OfficerUnionRepo;
import com.hoolai.sangoh5.repo.impl.key.OfficerKey;
import com.hoolai.sangoh5.service.MissionExecService;
import com.hoolai.sangoh5.service.TrackDomainService;
import com.hoolai.sangoh5.service.mission.MissionEngine;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

@Component("officerRepo")
public class OfficerRepoImpl implements OfficerRepo {

    @Autowired
    @Qualifier("itemClient")
    private ExtendedMemcachedClient client;

    @Autowired
    private BoFactory boFactory;

    @Autowired
    private OfficerUnionRepo officerUnionRepo;

    @Autowired
    private MissionExecService missionExecService;

    @Autowired
    private MissionEngine missionEngine;

    @Autowired
    private TrackDomainService trackDomainService;

    @Override
    public Officer findOfficer(long userId, int oid) {
        String officerKey = OfficerKey.getUserOfficersKey(userId);
        byte[] data = (byte[]) client.smember2(officerKey, oid);
        if (data == null) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }

        return boFactory.createOfficer(userId, data);
    }

    @Override
    public Officer findSimpleOfficer(long userId, int oid) {
        String officerKey = OfficerKey.getUserOfficersKey(userId);
        byte[] data = (byte[]) client.smember2(officerKey, oid);
        if (data == null) {
            return null;
        }

        return boFactory.createOfficer(userId, data);
    }

    @Override
    public Officer findMinOfficer(long userId, int oid) {
        String officerKey = OfficerKey.getUserOfficersKey(userId);
        byte[] data = (byte[]) client.smember2(officerKey, oid);
        if (data == null) {
            return null;
        }
        return new Officer(userId, data);
    }

    @Override
    public List<Officer> findOfficerList(long userId) {
        String key = OfficerKey.getUserOfficersKey(userId);
        Map<Long, byte[]> members = client.smembers2(key);

        return boFactory.createOfficers(userId, members);
    }

    @Override
    public List<Officer> findMiniOfficerList(long userId) {
        String key = OfficerKey.getUserOfficersKey(userId);
        Map<Long, byte[]> members = client.smembers2(key);
        List<Officer> officerList = Lists.newArrayListWithExpectedSize(members.size());

        Collection<byte[]> values = members.values();
        for (byte[] officer : values) {
            try {
                officerList.add(new Officer(OfficerProto.parseFrom(officer)));
            } catch (InvalidProtocolBufferException e) {
                e.printStackTrace();
            }
        }
        return officerList;
    }

    @Override
    public Map<Pair<Long, Integer>, Officer> getUserOfficers(Set<Pair<Long, Integer>> officerUserIds) {
        int len = officerUserIds.size();
        Map<String, Pair<Long, Integer>> keyMap = Maps.newHashMapWithExpectedSize(len);
        for (Pair<Long, Integer> userId : officerUserIds) {
            String key = OfficerKey.getUserOfficersKey(userId.getLeft()) + "_" + "mb" + "_" + userId.getRight();
            keyMap.put(key, userId);
        }
        Map<String, Object> officerUsers = client.mget(keyMap.keySet());
        if (officerUsers == null) {
            return Collections.emptyMap();
        }
        Map<Pair<Long, Integer>, Officer> users = Maps.newHashMapWithExpectedSize(officerUsers.size());
        Set<String> keys = officerUsers.keySet();
        for (String key : keys) {
            Pair<Long, Integer> pair = keyMap.get(key);
            Object obj = officerUsers.get(key);
            Officer officer = new Officer(pair.getLeft(), (byte[]) obj);

            users.put(pair, officer);
        }
        return users;
    }

    @Override
    public boolean saveNewOfficer(Officer officer) {
        String key = OfficerKey.getUserOfficersKey(officer.getUserId());
        if (client.sismember(key, officer.getId())) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
        int officerId = this.getOfficerId(officer.getUserId());
        officer.setId(officerId);

        boolean isSucc = client.sadd3(key, officer.toByteArray(), String.valueOf(officer.getId()));
        if (isSucc && officer.getStation() != Officer.station_captive && officer.whetherHaveOfficerUnion()) {
            succOfficerUnion(officer);
        }
        if (isSucc) {
            missionEngine.onEvent(new MissionEvent(MissionProperty.PROPERTY_将领_数量_MISSION, 0, officer.getUserId()));
            missionEngine.onEvent(new MissionEvent(MissionProperty.PROPERTY_达成_组合_MISSION, 0, officer.getUserId()));
        }
        return isSucc;
    }

    private int getOfficerId(long userId) {
        String officerIdKey = OfficerKey.getUniqueOfficerIdKey(userId);
        int officerId = (int) client.justIncr(officerIdKey);
        if (officerId < 0 && (officerId = repairNullKey(userId, officerIdKey)) < 0) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
        return officerId;
    }

    @Override
    public boolean updateOfficer(Officer officer) {
        if (officer == null) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
        String key = OfficerKey.getUserOfficersKey(officer.getUserId());

        if (client.smember2(key, officer.getId()) == null) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
        return client.sreplace2(key, officer.toByteArray(), officer.getId());
    }

    private int repairNullKey(long userId, String officerIdKey) {
        if (client.get(officerIdKey) != null) {
            return -1;
        }
        String key = OfficerKey.getUserOfficersKey(userId);
        Map<Long, byte[]> members = client.smembers2(key);
        int maxOfficerId = 0;
        for (Entry<Long, byte[]> member : members.entrySet()) {
            if (member.getKey().intValue() > maxOfficerId) {
                maxOfficerId = member.getKey().intValue();
            }
        }
        client.set(officerIdKey, String.valueOf(maxOfficerId + 1));
        return maxOfficerId + 1;
    }

    @Override
    public int findOfficerCount(long userId) {
        String key = OfficerKey.getUserOfficersKey(userId);
        return (int) client.scard2(key);
    }

    @Override
    public boolean removeOfficer(long userId, int officerId) {

        if (findOfficerCount(userId) <= 1) {
            throw new BusinessException(ErrorCode.CAN_NOT_ACCELERATE);
        }

        String userOfficerIdsKey = OfficerKey.getUserOfficersKey(userId);
        return client.srem2(userOfficerIdsKey, String.valueOf(officerId));
    }

    @Override
    public void succOfficerUnion(Officer officer) {
        OfficerUnions officerUnions = officerUnionRepo.findOfficerUnions(officer.getUserId());
        OfficerUnion officerUnion = officerUnions.findOfficerUnion(officer.findCombinationId());
        int starLevel = officerUnion.getMinStarLv();
        if (officerUnions.collect(officerUnion, officer.getXmlId(), officer.getStarLevel())) {
            officerUnionRepo.saveOfficerUnions(officerUnions);
            int currentStarLevel = officerUnion.getMinStarLv();
            if (starLevel != currentStarLevel) {
                trackDomainService.trackOfficerUnion(officer.getUserId(), officer.findCombinationId(), currentStarLevel);
            }
        }
    }

}
