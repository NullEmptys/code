package com.hoolai.sangoh5.bo.battle.skill.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ShenDunBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 每10秒为所有单位增加一个护盾，抵挡1000点伤害后消失
 * 
 * @author Administrator
 *
 */
public class ShenDun extends AttributeEnhanceSkill {

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {

        List<FightUnit> fightUnits = aliveTargetUnitList(tc, actor);
        Buff shenDunBuff = new ShenDunBuff(xmlId, actor.name(), Effect.DEFAULT_BUFF_LEVEL, fightUnits, this, actor).withActorName(actor.name()).withTargetName(actor.name())
                .withKeepBuff().withRepeatCount(repeatCount);
        shenDunBuff.apply(actor);//因为 先执行确保战斗一开始就有效果

        actor.addBuff(shenDunBuff);
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]");
    }

    @Override
    public Skill clone() {
        return super.clone(new YouLieZhuanHuan());
    }
}
