package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 以自身或者目标为中心点的范围内 所有敌人受到一定伤害
 * 
 * @author Administrator
 *
 */
public class ZouSiLeiDian extends BaseOfficerPhysicsSkill {

    @Override
    public Skill clone() {
        return super.clone(new ZouSiLeiDian());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();
        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            Effect effect = new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withDeltaHp(calculateLostPoint4Skill(actor, target))
                    .withTargetName(target.name());
            target.addEffect(effect);
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "造成伤害=" + effect.getDeltaHp());
            targets.add(target);
            targetDefence(actor, target, effect, null, tc, targets, currentLevel);
        }
        return targets;
    }
}
