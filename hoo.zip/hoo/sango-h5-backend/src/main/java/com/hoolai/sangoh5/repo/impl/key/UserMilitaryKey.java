package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class UserMilitaryKey {

    public static final String prefix = "military";

    public static String getUserMilitaryKey(long userId) {
        return new StringBuilder().append(userId).append(Constant.separator).append(prefix).toString();
    }

}
