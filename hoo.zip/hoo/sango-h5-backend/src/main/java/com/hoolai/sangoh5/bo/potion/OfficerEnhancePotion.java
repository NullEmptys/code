package com.hoolai.sangoh5.bo.potion;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.OfficerEnhancePotionProto;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.ForceType;
import com.hoolai.sangoh5.bo.battle.skill.ForceUnitType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.data.BattleEnhanceData;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillProperty;
import com.hoolai.sangoh5.bo.item.data.ItemData;
import com.hoolai.sangoh5.bo.item.data.ItemProperty;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class OfficerEnhancePotion implements ProtobufSerializable<OfficerEnhancePotionProto> {

    private long userId;

    private List<Potion> potions = new ArrayList<Potion>();

    transient private ItemData itemData;

    transient private BattleEnhanceData battleEnhanceData;

    transient private boolean isChange;

    public OfficerEnhancePotion(long userId) {
        this.userId = userId;
    }

    public OfficerEnhancePotion(long userId, byte[] bytes) {
        this(userId);
        parseFrom(bytes);
        init();
    }

    public void init() {
        Iterator<Potion> iterator = potions.iterator();
        while (iterator.hasNext()) {
            Potion potion = iterator.next();
            if (TimeUtil.currentTimeMillis() > potion.getLoseEfficacyTime()) {
                iterator.remove();
                isChange = true;
                continue;
            }
        }
    }

    public boolean isChange() {
        return isChange;
    }

    public long getUserId() {
        return userId;
    }

    /**
     * 只要有作用对象相同、效果相同的药水，覆盖效果
     * 
     * @param xmlId
     */
    public void addPotions(int xmlId) {
        ItemProperty itemProperty = itemData.getProperty(xmlId);

        int skillXmlId = itemProperty.getValue();
        int times = itemProperty.getValueOfDonate();

        Skill skill = battleEnhanceData.findSkill(skillXmlId);

        Iterator<Potion> iterator = potions.iterator();
        while (iterator.hasNext()) {
            Potion potion = iterator.next();
            ItemProperty exItemProperty = itemData.getProperty(potion.getXmlId());
            Skill exSkill = battleEnhanceData.findSkill(exItemProperty.getValue());

            switch (skill.getAttackUnitType()) {
                case SOLDIER:
                case SOLDIERS:
                case OFFICER_SOLDIERS:
                    if (isContainsUnit(skill.getForceType(), exSkill.getForceType()) && isContainsEffect(skill.getAttributeType(), exSkill.getAttributeType())) {
                        iterator.remove();
                    }
                    break;
                default:
                    if (skill.getAttackUnitType() == exSkill.getAttackUnitType() && isContainsUnit(skill.getForceType(), exSkill.getForceType())
                            && isContainsEffect(skill.getAttributeType(), exSkill.getAttributeType())) {
                        iterator.remove();
                    }
            }
        }

        potions.add(new Potion(xmlId, times));
    }

    private boolean isContainsEffect(AttributeType attributeType, AttributeType exAttributeType) {
        return attributeType.name().contains(exAttributeType.name());
    }

    private boolean isContainsUnit(ForceType forceType, ForceType exForceType) {
        if (forceType == ForceType.ALL) {
            return true;
        }
        return forceType.name().contains(exForceType.name());
    }

    public List<Integer> getSkillIds() {
        Iterator<Potion> iterator = potions.iterator();

        List<Integer> skills = new ArrayList<Integer>();
        while (iterator.hasNext()) {
            Potion potion = iterator.next();
            if (TimeUtil.currentTimeMillis() > potion.getLoseEfficacyTime()) {
                iterator.remove();
                continue;
            }
            skills.add(itemData.getProperty(potion.getXmlId()).getValue());
        }

        return skills;
    }

    public void setItemData(ItemData itemData) {
        this.itemData = itemData;
    }

    public void setBattleEnhanceData(BattleEnhanceData battleEnhanceData) {
        this.battleEnhanceData = battleEnhanceData;
    }

    @Override
    public OfficerEnhancePotionProto copyTo() {
        OfficerEnhancePotionProto.Builder builder = OfficerEnhancePotionProto.newBuilder();
        builder.setUserId(userId);

        for (Potion potion : potions) {
            builder.addPotions(potion.copyTo());
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            OfficerEnhancePotionProto message = OfficerEnhancePotionProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(OfficerEnhancePotionProto message) {
        this.userId = message.getUserId();

        int count = message.getPotionsCount();
        this.potions = new ArrayList<Potion>();
        for (int i = 0; i < count; i++) {
            this.potions.add(new Potion(message.getPotions(i)));
        }
    }

    public List<SkillProperty> findOfficerPotion() {
        List<Integer> skills = getSkillIds();
        List<SkillProperty> skillPropertys = new ArrayList<SkillProperty>();

        Iterator<Integer> iterator = skills.iterator();
        while (iterator.hasNext()) {
            int skillXmlId = iterator.next();

            SkillProperty property = battleEnhanceData.getProperty(skillXmlId);
            ForceUnitType caster = ForceUnitType.valueOf(property.getCaster().toUpperCase());
            ForceType force = ForceType.valueOf(property.getForce().toUpperCase());
            AttributeType attribyte = AttributeType.valueOf(property.getAttribute().toUpperCase());
            if (force != ForceType.ENEMY && (caster == ForceUnitType.OFFICER || caster == ForceUnitType.OFFICER_SOLDIERS) && AttributeType.isBaseProperty(attribyte)) {
                skillPropertys.add(property);
            }
        }

        return skillPropertys;
    }

}
