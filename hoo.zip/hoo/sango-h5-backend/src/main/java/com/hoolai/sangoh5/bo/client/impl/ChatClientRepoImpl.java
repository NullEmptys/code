package com.hoolai.sangoh5.bo.client.impl;

import java.net.InetSocketAddress;

import com.hoolai.sangoh5.bo.client.ChatClientRepo;
import com.hoolai.sangoh5.io.transport.client.socket.NettyClient;
import com.hoolai.sangoh5.io.transport.processor.ProcessorDispatcher;
import com.hoolai.sangoh5.io.transport.session.Session;
import com.hoolai.sangoh5.model.MsgType;
import com.hoolai.sangoh5.proto.ChatProto.ChatMsgProto;

public class ChatClientRepoImpl implements ChatClientRepo {

    private final ChatMsgProto pongMessage = ChatMsgProto.newBuilder().setMainType(MsgType.Pong.mainType).setSubType(MsgType.Pong.subType).build();

    private final NettyClient nettyClient;

    public ChatClientRepoImpl(String address, int port) {
        this.nettyClient = new NettyClient(new ProcessorDispatcher<ChatMsgProto>() {

            @Override
            public void dispatcher(Session session, ChatMsgProto message) {
                final MsgType msgType = MsgType.valueOf(message.getMainType(), message.getSubType());

                if (msgType == MsgType.Ping) {
                    nettyClient.sendMsg(pongMessage);
                }
            }
        });
        nettyClient.connect(new InetSocketAddress(address, port));
    }

    @Override
    public void sendMsg(ChatMsgProto chatMsg) {
        try {
            if (nettyClient.isActive()) {
                nettyClient.sendMsg(chatMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
