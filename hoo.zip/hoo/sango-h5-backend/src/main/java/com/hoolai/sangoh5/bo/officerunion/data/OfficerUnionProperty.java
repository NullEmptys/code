package com.hoolai.sangoh5.bo.officerunion.data;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.util.json.JsonProperty;

public class OfficerUnionProperty extends JsonProperty {

    private int[] officerID;

    private String description;

    private String[] oneStarProperty;

    private int[] oneStarValue;

    private int[] oneStarValueG;

    private String[] twoStarProperty;

    private int[] twoStarValue;

    private int[] twoStarValueG;

    private String[] threeStarProperty;

    private int[] threeStarValue;

    private int[] threeStarValueG;

    private String[] fourStarProperty;

    private int[] fourStarValue;

    private int[] fourStarValueG;

    private String[] fiveStarProperty;

    private int[] fiveStarValue;

    private int[] fiveStarValueG;

    public int[] getOfficerID() {
        return officerID;
    }

    public void setOfficerID(int[] officerID) {
        this.officerID = officerID;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String[] getOneStarProperty() {
        return oneStarProperty;
    }

    public void setOneStarProperty(String[] oneStarProperty) {
        this.oneStarProperty = oneStarProperty;
    }

    public int[] getOneStarValue() {
        return oneStarValue;
    }

    public void setOneStarValue(int[] oneStarValue) {
        this.oneStarValue = oneStarValue;
    }

    public String[] getTwoStarProperty() {
        return twoStarProperty;
    }

    public void setTwoStarProperty(String[] twoStarProperty) {
        this.twoStarProperty = twoStarProperty;
    }

    public int[] getTwoStarValue() {
        return twoStarValue;
    }

    public void setTwoStarValue(int[] twoStarValue) {
        this.twoStarValue = twoStarValue;
    }

    public int[] getTwoStarValueG() {
        return twoStarValueG;
    }

    public void setTwoStarValueG(int[] twoStarValueG) {
        this.twoStarValueG = twoStarValueG;
    }

    public String[] getThreeStarProperty() {
        return threeStarProperty;
    }

    public void setThreeStarProperty(String[] threeStarProperty) {
        this.threeStarProperty = threeStarProperty;
    }

    public int[] getThreeStarValue() {
        return threeStarValue;
    }

    public void setThreeStarValue(int[] threeStarValue) {
        this.threeStarValue = threeStarValue;
    }

    public int[] getThreeStarValueG() {
        return threeStarValueG;
    }

    public void setThreeStarValueG(int[] threeStarValueG) {
        this.threeStarValueG = threeStarValueG;
    }

    public String[] getFourStarProperty() {
        return fourStarProperty;
    }

    public void setFourStarProperty(String[] fourStarProperty) {
        this.fourStarProperty = fourStarProperty;
    }

    public int[] getFourStarValue() {
        return fourStarValue;
    }

    public void setFourStarValue(int[] fourStarValue) {
        this.fourStarValue = fourStarValue;
    }

    public int[] getFourStarValueG() {
        return fourStarValueG;
    }

    public void setFourStarValueG(int[] fourStarValueG) {
        this.fourStarValueG = fourStarValueG;
    }

    public String[] getFiveStarProperty() {
        return fiveStarProperty;
    }

    public void setFiveStarProperty(String[] fiveStarProperty) {
        this.fiveStarProperty = fiveStarProperty;
    }

    public int[] getFiveStarValue() {
        return fiveStarValue;
    }

    public void setFiveStarValue(int[] fiveStarValue) {
        this.fiveStarValue = fiveStarValue;
    }

    public int[] getFiveStarValueG() {
        return fiveStarValueG;
    }

    public void setFiveStarValueG(int[] fiveStarValueG) {
        this.fiveStarValueG = fiveStarValueG;
    }

    public int[] getOneStarValueG() {
        return oneStarValueG;
    }

    public void setOneStarValueG(int[] oneStarValueG) {
        this.oneStarValueG = oneStarValueG;
    }

    public class EnhanceProperty {

        private AttributeType attributeType;

        private int value;

        private int per;

        public EnhanceProperty(AttributeType attributeType, int value, int per) {
            this.attributeType = attributeType;
            this.value = value;
            this.per = per;
        }

        public AttributeType getAttributeType() {
            return attributeType;
        }

        public int getValue() {
            return value;
        }

        public int getPer() {
            return per;
        }
    }

    public List<EnhanceProperty> findEnhances(int starLv) {
        String[] types;
        int[] values;
        int[] pers;
        List<EnhanceProperty> enhanceProperties = new ArrayList<OfficerUnionProperty.EnhanceProperty>();

        switch (starLv) {
            case 1:
                types = oneStarProperty;
                values = oneStarValue;
                pers = oneStarValueG;
                break;
            case 2:
                types = twoStarProperty;
                values = twoStarValue;
                pers = twoStarValueG;
                break;
            case 3:
                types = threeStarProperty;
                values = threeStarValue;
                pers = threeStarValueG;
                break;
            case 4:
                types = fourStarProperty;
                values = fourStarValue;
                pers = fourStarValueG;
                break;
            case 5:
                types = fiveStarProperty;
                values = fiveStarValue;
                pers = fiveStarValueG;
                break;
            default:
                return enhanceProperties;
        }

        for (int i = 0; i < types.length; i++) {
            AttributeType attributeType = AttributeType.convertType(types[i]);
            EnhanceProperty property = new EnhanceProperty(attributeType, values[i], pers[i]);
            enhanceProperties.add(property);
        }
        return enhanceProperties;
    }
}
