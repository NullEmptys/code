package com.hoolai.sangoh5.bo.battle.fight;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.BattleLogProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class BattleLog implements ProtobufSerializable<BattleLogProto> {

    private List<String> logs = new ArrayList<String>();

    public BattleLog() {
        logs.add("------------------战斗开始-------------------");
    }

    public BattleLog(byte[] bytes) {
        parseFrom(bytes);
    }

    public void add(String log) {
        this.logs.add(log);
    }

    public void println() {
        for (String log : logs) {
            System.out.println(log);
        }
        System.out.println("------------------战斗结束-------------------");
    }

    public List<String> getLogs() {
        return logs;
    }

    public void setLogs(List<String> logs) {
        this.logs = logs;
    }

    @Override
    public BattleLogProto copyTo() {
        BattleLogProto.Builder builder = BattleLogProto.newBuilder();
        for (String log : logs) {
            builder.addLogs(log);
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            BattleLogProto message = BattleLogProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(BattleLogProto message) {
        int count = message.getLogsCount();
        for (int i = 0; i < count; i++) {
            this.logs.add(message.getLogs(i));
        }
    }
}
