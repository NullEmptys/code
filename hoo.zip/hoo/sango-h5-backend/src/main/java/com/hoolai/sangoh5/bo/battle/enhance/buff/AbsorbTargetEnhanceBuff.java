package com.hoolai.sangoh5.bo.battle.enhance.buff;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.BuffProto;
import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 每次击中时，吸取对方攻击力,防御力，可叠加
 * 
 * @author Administrator
 *
 */
public class AbsorbTargetEnhanceBuff extends Buff {

    FightUnit owner;

    Skill skill;

    public AbsorbTargetEnhanceBuff(int targetUsedSkillXmlId, int currentLevel, FightUnit owner, Skill skill) {
        super(targetUsedSkillXmlId, skill.getName(), owner.name(), currentLevel);
        this.owner = owner;
        this.skill = skill;
        this.isForFront = false;
    }

    @Override
    public List<FightUnit> targetEnhance(FightUnit actor, FightUnit target, TargetCollection tc) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        if (actor.name().equals(owner.name())) {
            boolean isHaveHurt = false;
            for (Effect effect : target.getEffectList()) {
                if (effect.getDeltaHp() > 0) {
                    isHaveHurt = true;
                    break;
                }
            }

            if (isHaveHurt) {
                if (logger.isDebugEnabled()) {
                    logger.debug(actorName + "偷取成功！");
                }
                actor.changeAttackPoint(skill.getValue());
                target.changeAttackPoint(-skill.getTwoValue());
                target.changeDefencePoint(-skill.getTwoValue());
                targets.add(target);
                needRepeatPlay();
                actor.addBattleLog(actor.name() + "偷取成功,增加攻击力" + skill.getValue() + ",attackPoint=" + actor.attackPoint());
                actor.addBattleLog(actor.name() + "偷取成功," + target.name() + "减少攻击力" + skill.getValue() + ",attackPoint=" + target.attackPoint() + "减少防御力" + skill.getValue()
                        + ",defencePoint=" + target.defencePoint());
            }

            return targets;
        }

        return new ArrayList<FightUnit>();
    }

    @Override
    public void apply(FightUnit target) {
        this.result();
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * 此方法必要的时候需要在子类重写，否则会调用alive.unsilence()清除沉默产生负作用
     * 
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
    }

    public AbsorbTargetEnhanceBuff(BuffProto message) {
        super(message);
    }

}
