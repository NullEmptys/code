package com.hoolai.sangoh5.bo.militaryRank.data;

import com.hoolai.sangoh5.bo.UserProtocolBuffer.MilitaryEffectTypeProto;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public enum MilitaryEffectType {

    OPENSOLDIER(0, MilitaryEffectTypeProto.OPENSOLDIER), //"士兵解锁"
    TRAINSOLDIERTIME(1, MilitaryEffectTypeProto.TRAINSOLDIERTIME), //"士兵训练时间减少比例"
    TRAINSOLDIERNUM(2, MilitaryEffectTypeProto.TRAINSOLDIERNUM), //"训练士兵数量增值"
    TRAINSOLDIERGOLD(3, MilitaryEffectTypeProto.TRAINSOLDIERGOLD), // "士兵训练所需金币减少比例"
    HONORNUMADD(4, MilitaryEffectTypeProto.HONORNUMADD), //"PVP功勋加成比例"
    PVPFIGHTNUMADD(5, MilitaryEffectTypeProto.PVPFIGHTNUMADD), //"PVP战斗次数增加"
    FOODLIMITADD(7, MilitaryEffectTypeProto.FOODLIMITADD), //"粮草上限增加"
    PVETIMESADD(8, MilitaryEffectTypeProto.PVETIMESADD), //"PVE每关攻打次数增加"
    QUALIFYBUYTIMESADD(9, MilitaryEffectTypeProto.QUALIFYBUYTIMESADD), //"排位战购买次数增加"
    BOUNTYBUYTIMEADD(10, MilitaryEffectTypeProto.BOUNTYBUYTIMEADD), //"悬赏购买次数增加"
    RECRUITOFFICER(11, MilitaryEffectTypeProto.RECRUITOFFICER), //"招募解锁新将领"
    DEDUCTLOYALTYADD(12, MilitaryEffectTypeProto.DEDUCTLOYALTYADD), //"每次招降扣除忠诚度数量增加"
    DONATEINTEGRATEADD(13, MilitaryEffectTypeProto.DONATEINTEGRATEADD), //"联盟捐献积分增加"
    BOUNTYNUMADD(15, MilitaryEffectTypeProto.BOUNTYNUMADD), //"bountyNumAdd"
    NORMALRECNUMADD(16, MilitaryEffectTypeProto.NORMALRECNUMADD), //"免费令牌招募次数增加"
    SLAVENUMADD(17, MilitaryEffectTypeProto.SLAVENUMADD);//"拥有奴隶增加"

    private MilitaryEffectTypeProto militaryEffectType;

    private int id;

    private MilitaryEffectType(int id, MilitaryEffectTypeProto militaryEffectType) {
        this.id = id;
        this.militaryEffectType = militaryEffectType;

    }

    public static MilitaryEffectType getValue(int id) {
        for (MilitaryEffectType militaryEffectType : MilitaryEffectType.values()) {
            if (militaryEffectType.getId() == id) {
                return militaryEffectType;
            }
        }
        return null;
    }

    public static MilitaryEffectType converToMilitaryEffectType(MilitaryEffectTypeProto militaryEffectType) {
        for (MilitaryEffectType at : MilitaryEffectType.values()) {
            if (at.getMilitaryEffectType().equals(militaryEffectType)) {
                return at;
            }
        }
        throw new com.hoolai.sango.core.exception.BusinessException(ErrorCode.ERROR_AWARD_TYPE.code, ErrorCode.ERROR_AWARD_TYPE.msg + "---errortype is " + militaryEffectType);
    }

    public int getId() {
        return id;
    }

    public MilitaryEffectTypeProto getMilitaryEffectType() {
        return militaryEffectType;
    }

}
