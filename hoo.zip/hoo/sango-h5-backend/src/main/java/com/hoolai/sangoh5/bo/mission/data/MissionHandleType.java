package com.hoolai.sangoh5.bo.mission.data;

/**
 * 任务Detail操作
 * @author hp
 *
 */
public enum MissionHandleType {
	
	SYMBOL_NULL(0, "不做处理"), 
	SYMBOL_ADD(1, "累加"), 
	SYMBOL_REPLACE(2, "替换"),
	SYMBOL_MAX_REPLACE(3, "最大值替换");

	private int type;
	private String desc;

	private MissionHandleType(int type, String desc) {
		this.type = type;
		this.desc = desc;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public static MissionHandleType getValue(int type){
		for(MissionHandleType handleType :MissionHandleType.values()){
			if(handleType.getType() == type){
				return handleType;
			}
		}
		return null;
	}
}
