package com.hoolai.sangoh5.bo.activity.data;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-12 16:48
 * @version : 1.0
 */
public class RewardLvProperty extends JsonProperty {

    /** 等级 **/
    private int lv;

    /** 奖励类型 **/
    private String[] type;

    /** 奖励id **/
    private int[] reward;

    /** 数量 **/
    private int[] num;

    @JsonIgnore
    private RewardLvProperty preReward;

    public int getLv() {
        return lv;
    }

    public void setLv(int lv) {
        this.lv = lv;
    }

    public String[] getType() {
        return type;
    }

    public void setType(String[] type) {
        this.type = type;
    }

    public int[] getReward() {
        return reward;
    }

    public void setReward(int[] reward) {
        this.reward = reward;
    }

    public int[] getNum() {
        return num;
    }

    public void setNum(int[] num) {
        this.num = num;
    }

}
