package com.hoolai.sangoh5.bo.battle.enhance.buff;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.fight.ActionResult;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 战火覆盖范围内改变防御力
 */
public class YouLieZhuanHuanBuff extends Buff {

    private FightUnit skillOwner;

    private Skill skill;

    private List<FightUnit> foreUnits;

    private Map<FightUnitName, YouLieZhuanHuanStatus> foreUnitStatusMap;

    class YouLieZhuanHuanStatus {

        private boolean isAddAttack;

        private boolean isAddDefence;

        public boolean isAddAttack() {
            return isAddAttack;
        }

        public boolean isAddDefence() {
            return isAddDefence;
        }

        public void setAddAttack(boolean isAddAttack) {
            this.isAddAttack = isAddAttack;
        }

        public void setAddDefence(boolean isAddDefence) {
            this.isAddDefence = isAddDefence;
        }

    }

    /*
     * 触发技能后的下一回生效
     */
    @Override
    public void targetEnhanceAfterExcuteBuffs(List<ActionResult> actionResults, TargetCollection targetCollection) {
        this.result();

        for (FightUnit fightUnit : foreUnits) {
            if (fightUnit.isDead()) {
                continue;
            }
            FightUnit target = fightUnit.getDefender();
            if (target == null || target.isDead()) {
                continue;
            }
            ChangeAttackOrDefence(fightUnit, target, actionResults);
        }
    }

    private void ChangeAttackOrDefence(FightUnit actor, FightUnit target, List<ActionResult> actionResults) {
        boolean canChangeAttack = actor.getHp() >= target.getHp();
        boolean canChangeDefence = actor.getHp() < target.getHp();
        YouLieZhuanHuanStatus status = foreUnitStatusMap.get(actor.name());

        if (canChangeAttack && !status.isAddAttack()) {
            status.setAddAttack(true);
            float att = actor.baseAttackPoint() * skill.getTwoPercentage();
            actor.changeAttackPoint(att);

            String defenceStr = "";
            if (status.isAddDefence()) {
                float def = actor.baseDefencePoint() * skill.getPercentage();
                status.setAddDefence(false);
                actor.changeDefencePoint(-def);
                defenceStr = ",减去防御力：" + def;
            }
            isForFront = true;
            actor.addBattleLog(targetUsedSkillXmlId + "[" + skillName + "]" + "我方血量多余对方血量，增加攻击力：       " + actor.name() + "当前血量[" + actor.getHp() + "]," + target.name() + "当前血量["
                    + target.getHp() + "],增加攻击力:" + att + defenceStr);
        } else if (canChangeDefence && !status.isAddDefence()) {
            float def = actor.baseDefencePoint() * skill.getPercentage();
            status.setAddDefence(true);
            actor.changeDefencePoint(def);

            String defenceStr = "";
            if (status.isAddAttack()) {
                float att = actor.baseAttackPoint() * skill.getTwoPercentage();
                status.setAddAttack(false);
                actor.changeAttackPoint(-att);
                defenceStr = ",减去攻击力力：" + att;
            }
            isForFront = true;
            actor.addBattleLog(targetUsedSkillXmlId + "[" + skillName + "]" + "我方血量少于对方血量，加防御力:       " + actor.name() + "当前血量[" + actor.getHp() + "]," + target.name() + "当前血量["
                    + target.getHp() + "],增加防御力:" + def + defenceStr);
        }

        if (isForFront) {
            ActionResult actionResult = findActionResult(skill.getXmlId(), actor, actionResults);
            actionResult.getBuffList().add(
                    new Buff(skill.getXmlId(), skill.getName(), actor.name(), Buff.DEFAULT_BUFF_LEVEL).withActorName(actor.name()).withTargetName(actor.name()));
            isForFront = false;
        }
    }

    @Override
    public void apply(FightUnit target) {
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * 此方法必要的时候需要在子类重写，否则会调用alive.unsilence()清除沉默产生负作用
     * 
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        //alive.removeBuff(this);
    }

    @Override
    protected YouLieZhuanHuanBuff clone() {
        YouLieZhuanHuanBuff buff = (YouLieZhuanHuanBuff) super.clone(new YouLieZhuanHuanBuff(this.targetUsedSkillXmlId, executeName, skillOwner, skill, currentLevel, foreUnits));
        buff.skillOwner = skillOwner;
        return buff;
    }

    public YouLieZhuanHuanBuff(int xmlId, FightUnitName executeName, FightUnit actor, Skill skill, int currentLevel, List<FightUnit> foreUnits) {
        super(xmlId, skill.getName(), executeName, currentLevel);
        this.skillOwner = actor;
        this.skill = skill;
        this.foreUnits = foreUnits;
        this.isForFront = false;

        foreUnitStatusMap = new HashMap<FightUnitName, YouLieZhuanHuanBuff.YouLieZhuanHuanStatus>();
        for (FightUnit fightUnit : foreUnits) {
            foreUnitStatusMap.put(fightUnit.name(), new YouLieZhuanHuanStatus());
        }
    }

}
