package com.hoolai.sangoh5.bo.mission.data;

/**
 * 任务属性定义枚举
 * 
 * @author hp
 *
 */
public enum MissionProperty{

    PROPERTY_副本_战斗_MISSION(1,"攻打副本"),
    PROPERTY_令牌_招募_MISSION(2,"令牌招募"),
    PROPERTY_钻石_招募_MISSION(3,"钻石招募"),
    PROPERTY_强化_任意装备_MISSION(4,"强化任意装备"),
    PROPERTY_训练_士兵_MISSION(5,"训练士兵"),
    PROPERTY_升级_任意将领_MISSION(6,"任意将领升级"),
    PROPERTY_PVP_获得_俘虏_MISSION(7,"PVP中获得俘虏"),
    PROPERTY_工作_奴隶个数_MISSION(8,"农田矿洞中奴隶在工作"),
    PROPERTY_参加_排行榜_MISSION(9,"参加排行榜"),
    PROPERTY_参加_悬赏_MISSION(10,"参加悬赏"),
    PROPERTY_挑战_竞技场_MISSION(11,"挑战终极竞技场"),
    PROPERTY_玩家_等级_MISSION(12,"玩家等级达到"),
    PROPERTY_副本_总星数_MISSION(13,"副本总星级达到"),
    PROPERTY_排行榜_最高名次_MISSION(14,"排行榜最高名次到"),
    PROPERTY_达成_组合_MISSION(15,"达成组合"),
    PROPERTY_至少_将领_等级_MISSION(16,"至少n个将领达到n级"),
    PROPERTY_N将领_N升星_MISSION(17,"n个将领达到n星"),
    PROPERTY_悬赏_累计解救_玩家_MISSION(18,"悬赏中累计解救n个玩家"),
    PROPERTY_将领_数量_MISSION(19,"将领数量达到n个"),
    PROPERTY_拥有_T将领_MISSION(20,"n件装备进阶至n"),
    PROPERTY_解锁_士兵_任意_MISSION(21,"解锁任意n种士兵"),
    PROPERTY_解锁_新兵种(22,"解锁新兵种"),
    PROPERTY_将领_学完_士兵_MISSION(23,"n个将领学完所有士兵"),
    PROPERTY_加入_联盟_MISSION(24,"加入联盟"),
    PROPERTY_累计_获得_俘虏_MISSION(25,"PVP中累计获得俘虏"),
    PROPERTY_联盟_捐献_MISSION(36,"在联盟中捐献1次"),
    PROPERTY_军情_复仇_MISSION(111,"军情通知中累计复仇次数"),
    PROPERTY_招降_成功_MISSION(113,"累计成功招降个数"),
    PROPERTY_农田_收获_MISSION(114,"农田中累计收获粮草次数"),
    PROPERTY_农田_品质_MISSION(115,"农田品质达到多少星"),
    PROPERTY_矿洞_收获_MISSION(116,"矿洞中累计收获金币次数"),
    PROPERTY_矿洞_品质_MISSION(117,"农田品质达到多少星"),
    PROPERTY_排位殿_每日三次_MISSION(118,"每日三次"),
    PROPERTY_徽章_升级_MISSION(119,"联盟徽章升至多少级"),
    PROPERTY_个人_官职_MISSION(120,"个人官职达到某级别"),
    PROPERTY_获得_个人徽章_MISSION(121,"联盟中获得多少个徽章"),
    PROPERTY_通关_关卡_MISSION(1010,"通关关卡"),
    PROPERTY_学习_技能_MISSION(1000,"学习技能"),
    PROPERTY_开启_吴国弓兵_MISSION(1001,"兵营中开启吴国弓兵"),
    PROPERTY_将领_升星_MISSION(1002,"将领升星"),
    PROPERTY_城墙_驻将_MISSION(1003,"城墙驻守将领"),
    PROPERTY_经验丹_升级_MISSION(1004,"使用经验丹给将领升级1次"),
    PROPERTY_参加_PVP_MISSION(1005,"参加pvp一次"),
    PROPERTY_农田_奴隶_MISSION(1006,"进入农田使用抓捕的奴隶"),
    PROPERTY_购买_钥匙_MISSION(1007,"商店购买钥匙"),
    PROPERTY_开宝箱_MISSION(1008,"开宝箱"),
    PROPERTY_招降_将领_MISSION(1009,"进入俘虏营招降将领"),
    
    PROPERTY_PVE_更换_将领_MISSION(40,"更换PVE中上阵将领"),
    PROPERTY_更换_士兵_MISSION(41,"为新将领更换强大的士兵"),
    PROPERTY_PVP_本州_面积_MISSION(42,"PVP中本州面积增加"),
    PROPERTY_PVE_国土_面积_MISSION(43,"国土面积达到n平方公里"),
    PROPERTY_拥有_好友_MISSION(44,"拥有1个好友"),
    PROPERTY_拥有_技能_MISSION(45,"军衔中拥有1个1级技能"),
    PROPERTY_装备_升阶_MISSION(46,"拥有N个TM的将领"),
    PROPERTY_登陆_游戏_MISSION(47,"登陆游戏"),
    PROPERTY_抓捕N奴隶_MISSION(48,"抓捕2个奴隶"),
    PROPERTY_分享_MISSION(49,"分享1次"),
    PROPERTY_邀请_MISSION(50,"邀请好友N个"),
    PROPERTY_购买金币_MISSION(51,"购买一次金币"),
    PROPERTY_在月商店购买_MISSION(52,"在月商店购买"),
    PROPERTY_在排商店兑换_MISSION(53,"在排商店兑换"),
    PROPERTY_领取周卡_MISSION(55,"领取周卡奖励"),
    PROPERTY_领取月卡_MISSION(54,"领取月卡奖励");
    
    private int propertyId;

    private String desc;
    
    private MissionProperty(int propertyId, String desc) {
        this.propertyId = propertyId;
        this.desc = desc;
    }

    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public static MissionProperty getValue(int propertyId) {
        for (MissionProperty missionProperty : MissionProperty.values()) {
            if (missionProperty.getPropertyId() == propertyId) {
                return missionProperty;
            }
        }
        return null;
    }

    public static boolean isContainProperty(int propertyId) {
        boolean isContain = false;
        MissionProperty missionProperty = getValue(propertyId);
        if (missionProperty == null) {
            return false;
        }
        switch (missionProperty) {
            case PROPERTY_将领_数量_MISSION:
            case PROPERTY_达成_组合_MISSION:
            case PROPERTY_PVP_获得_俘虏_MISSION:
            case PROPERTY_玩家_等级_MISSION:
                isContain = true;
                break;
            default:
                isContain = false;
        }
        return isContain;
    }
    
}