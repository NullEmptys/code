package com.hoolai.sangoh5.bo.mission.data;

/**
 * 任务分类
 * 
 * @author hp
 *
 */
public enum MissionType {

    CATEGORY_DAILY_MISSION(1, "日常任务"), CATEGORY_ACHIEVEMENT_MISSION(2, "成就任务"), CATEGORY_MAIN_MISSION(3, "主线任务");

    private int type;

    private String description;

    private MissionType(int type, String description) {
        this.type = type;
        this.description = description;
    }

    public static MissionType getValue(int type) {
        for (MissionType missionType : MissionType.values()) {
            if (missionType.getType() == type) {
                return missionType;
            }
        }
        return null;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public static String getType(int type) {
        switch (type) {
            case 1:
                return "daily";
            case 2:
                return "achievement";
            case 3:
                return "main";
            default:
                break;
        }
        throw new RuntimeException("not found type " + type);
    }

}
