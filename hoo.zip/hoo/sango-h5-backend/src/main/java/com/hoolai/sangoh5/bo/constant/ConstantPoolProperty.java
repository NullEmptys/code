package com.hoolai.sangoh5.bo.constant;

import com.hoolai.sangoh5.util.json.JsonProperty;
/**
 * 常量池
 * @author hp
 *
 */
public class ConstantPoolProperty extends JsonProperty{
	
	private int value;

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	
}
