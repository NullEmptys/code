package com.hoolai.sangoh5.bo.arena;

import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.repo.ArenaRepo;

public class ScoreProcessor {

    private final ArenaUser attackArenaUser;

    private final ArenaUser defenceArenaUser;

    private ArenaRepo arenaRepo;

    private ArenaOfficers arenaOfficers;

    private ArenaOfficer arenaOfficer;

    private ArenaOfficer serverArenaOfficer;

    private ArenaOfficers defenceArenaOfficers;

    private ArenaOfficer defenceArenaOfficer;

    private ArenaOfficer defenceServerArenaOfficer;

    public static final int LIMIT_RANK_OFFICER = 10;

    public ScoreProcessor(ArenaUser arenaUser, ArenaUser defenceArenaUser) {
        this.attackArenaUser = arenaUser;
        this.defenceArenaUser = defenceArenaUser;
    }

    public void setArenaRepo(ArenaRepo arenaRepo) {
        this.arenaRepo = arenaRepo;
    }

    public void init(Officer attackOfficer, Officer defenceOfficer) {
        arenaOfficers = arenaRepo.findArenaOfficers(attackArenaUser.getUserId());
        arenaOfficer = arenaOfficers.findArenaOfficer(attackOfficer.getXmlId());
        serverArenaOfficer = arenaRepo.findServerArenaOfficer(attackOfficer.getXmlId());

        if (defenceArenaUser.getUserId() > 0) {
            defenceArenaOfficers = arenaRepo.findArenaOfficers(defenceArenaUser.getUserId());
            defenceArenaOfficer = defenceArenaOfficers.findArenaOfficer(defenceOfficer.getXmlId());
            defenceServerArenaOfficer = arenaRepo.findServerArenaOfficer(defenceOfficer.getXmlId());
        }
    }

    public void save() {
        arenaRepo.saveArenaOfficers(arenaOfficers);
        arenaRepo.saveServerArenaOfficer(serverArenaOfficer);

        if (defenceArenaUser.getUserId() > 0) {
            arenaRepo.saveArenaUser(defenceArenaUser);
            arenaRepo.saveArenaOfficers(defenceArenaOfficers);
            arenaRepo.saveServerArenaOfficer(defenceServerArenaOfficer);
        }
    }

    public void cal(boolean isBattleWin) {
        if (isBattleWin) {
            win(attackArenaUser, defenceArenaUser, serverArenaOfficer, arenaOfficer, arenaOfficers);
            lose(defenceArenaUser, attackArenaUser, defenceServerArenaOfficer, defenceArenaOfficer, defenceArenaOfficers);
        } else {
            lose(attackArenaUser, defenceArenaUser, serverArenaOfficer, arenaOfficer, arenaOfficers);
            win(defenceArenaUser, attackArenaUser, defenceServerArenaOfficer, defenceArenaOfficer, defenceArenaOfficers);
        }
    }

    public void win(ArenaUser arenaUser, ArenaUser targetArenaUser, ArenaOfficer serverArenaOfficer, ArenaOfficer arenaOfficer, ArenaOfficers arenaOfficers) {
        if (arenaUser.getUserId() <= 0) {
            return;
        }

        /******************************* 计算将领积分 ************************************/
        int D = 100;
        double F = Math.min(Math.max(1 - Double.valueOf(arenaUser.getCurrentScore()) / Double.valueOf(targetArenaUser.getCurrentScore()), -0.5d), 0.5d);
        double G = -0.25d * Math.min(Math.max(serverArenaOfficer.findServerWinRate(), 0.3d), 0.7d) + 1.25d;
        double H = 1 + Math.min(Math.max(Double.valueOf(arenaOfficer.getScore()) / Double.valueOf(arenaUser.getCurrentScore()), -0.4d), 0.4d);
        double E = 0;
        if (arenaOfficer.getWinNum() < 3) {
            if (arenaOfficer.getFightNum() == 0) {
                E = 0;
            } else {
                E = 3d / Double.valueOf(arenaOfficer.getFightNum()) * 100d;
            }
        }
        double officerScoreDouble = D * (1 + F + G) * H + E;
        int officerScore = (int) (officerScoreDouble);
        arenaOfficer.addScore(officerScore);
        serverArenaOfficer.addWinNum();
        arenaOfficer.addWinNum();

        upDateRankOfficer(arenaOfficer);

        /******************************* 计算君主积分 ************************************/
        double A = arenaOfficers.top10OfficerAvgScore();
        double B = Math.min((Double.valueOf(arenaUser.getTodayFightNum()) / 5d), 2d) + 2d;
        double C = officerScoreDouble / 10d;
        int userScore = (int) (A + B + C);
        arenaUser.setCurrentScore(userScore);
    }

    public void lose(ArenaUser arenaUser, ArenaUser targetArenaUser, ArenaOfficer serverArenaOfficer, ArenaOfficer arenaOfficer, ArenaOfficers arenaOfficers) {
        if (arenaUser.getUserId() <= 0) {
            return;
        }
        /******************************* 计算将领积分 ************************************/
        int D = 100;
        double I = Math.min(Math.max(Double.valueOf(arenaUser.getCurrentScore()) / Double.valueOf(targetArenaUser.getCurrentScore()) - 1d, -0.5d), 0.5d);
        double J = 0.25 * Math.min(Math.max(serverArenaOfficer.findServerWinRate(), 0.3d), 0.7d) - 1.25d;
        double H = 1 + Math.min(Math.max(Double.valueOf(arenaOfficer.getScore()) / Double.valueOf(arenaUser.getCurrentScore()), -0.4d), 0.4d);

        int officerDecScore = (int) (D * (1 + I + J) * H);
        arenaOfficer.decScore(-officerDecScore);
        serverArenaOfficer.addLoseNum();
        arenaOfficer.addLoseNum();

        upDateRankOfficer(arenaOfficer);

        /******************************* 计算君主积分 ************************************/
        double K = arenaOfficers.top10OfficerAvgScore();
        int userScore = (int) (K);
        arenaUser.setCurrentScore(userScore);
    }

    private void upDateRankOfficer(ArenaOfficer arenaOfficer) {
        if (arenaOfficer.getUserId() <= 0) {
            return;
        }
        arenaRepo.zaddRankArenaOfficer(arenaOfficer.getUserId(), arenaOfficer.getOfficerXmlId(), arenaOfficer.getScore());
        int count = arenaRepo.getRankArenaOfficersCount(arenaOfficer.getOfficerXmlId());
        if (count > LIMIT_RANK_OFFICER) {
            arenaRepo.zremByRankArenaOfficer(arenaOfficer.getOfficerXmlId(), 0, count - LIMIT_RANK_OFFICER - 1);
        }
    }
}
