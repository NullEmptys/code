package com.hoolai.sangoh5.bo.award;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.compass.core.util.CollectionUtils;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.barrack.Barrack;
import com.hoolai.sangoh5.bo.item.ItemBag;
import com.hoolai.sangoh5.bo.item.ItemBags;
import com.hoolai.sangoh5.bo.item.data.ItemData;
import com.hoolai.sangoh5.bo.mission.data.MissionProperty;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.pvp.data.ConBoxReward;
import com.hoolai.sangoh5.bo.pvp.data.LineupConBoxData;
import com.hoolai.sangoh5.bo.pvp.data.RegionConBoxData;
import com.hoolai.sangoh5.bo.pvp.data.UnionConBoxData;
import com.hoolai.sangoh5.bo.slave.Slave;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.soldier.data.SoldierProperty;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.bo.user.User.CurrencyType;
import com.hoolai.sangoh5.event.event.MissionEvent;
import com.hoolai.sangoh5.repo.ItemRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.service.TrackDomainService;
import com.hoolai.sangoh5.service.UpgradeEngine;

/**
 * 用bofactory.createAwardProcessor 去创建,因为需要注入bean
 */
public class AwardProcessor {

    protected transient long userId;

    /** 道具奖励 */
    protected transient List<Award> itemBagList = new ArrayList<Award>();

    //    /** 装备奖励 */
    //    protected transient List<EquipAward> equipList = new ArrayList<EquipAward>();

    /** 将领奖励 */
    protected transient List<OfficerAward> officerList = new ArrayList<OfficerAward>();

    /** 解锁的士兵id */
    private final List<Integer> soldierList = new ArrayList<Integer>();

    /** 黄金奖励 */
    private transient int gold;

    /** 钻石奖励 */
    private transient int diamond;

    /** 用户经验奖励 */
    private transient int userExp;

    /** 功勋奖励 */
    private int moonstone;

    /** 蓝田玉 */
    private int lanTianYu;

    /** 奴隶 */
    private Slave slave;

    /** 俘虏 */
    private Officer officer;

    /** 军功 */
    private int militaryExploits;

    /** 友情点 */
    private int friendship;

    /** 奖励id **/
    private int rewardId;

    /** 声望 **/
    private int reputation;

    private int provision;

    private int leftEar;

    private int farmlandSnatch;

    private int mineSnatch;

    private int meteorite;

    private transient BoFactory boFactory;

    private transient ItemRepo itemRepo;

    private transient UserRepo userRepo;

    private transient ItemBags itemBags;

    private transient User user;

    private transient List<ItemBag> itemBag4Front = new ArrayList<ItemBag>();

    /** 将领奖励 */
    protected transient List<Officer> officers4Front = new ArrayList<Officer>();

    private transient UnionConBoxData unionCoinBoxData;

    private transient LineupConBoxData lineupConBoxData;

    private transient RegionConBoxData regionConBoxData;

    private transient AwardChannel awardChannel;

    private transient TrackDomainService trackDomainService;

    private UpgradeEngine upgradeEngine;

    /**
     * 不要用这个创建 ，用bofactory.createAwardProcessor 去创建,因为需要注入bean
     */
    public AwardProcessor(AwardChannel awardChannel) {
        this.awardChannel = awardChannel;
    }

    public void setUnionCoinBoxData(UnionConBoxData unionCoinBoxData) {
        this.unionCoinBoxData = unionCoinBoxData;
    }

    public void setLineupConBoxData(LineupConBoxData lineupConBoxData) {
        this.lineupConBoxData = lineupConBoxData;
    }

    public void setRegionConBoxData(RegionConBoxData regionConBoxData) {
        this.regionConBoxData = regionConBoxData;
    }

    public void setTrackDomainService(TrackDomainService trackDomainService) {
        this.trackDomainService = trackDomainService;
    }

    public void setUpgradeEngine(UpgradeEngine upgradeEngine) {
        this.upgradeEngine = upgradeEngine;
    }

    /**
     * 根据类型 计算奖励
     * 
     * @param awards
     */
    public void transforAward(List<Award> awards) {
        for (Award award : awards) {
            switch (award.getAwardType()) {
                case GOLD:
                    this.gold += award.getNum();
                    break;
                case DIAMOND:
                    this.diamond += award.getNum();
                    break;
                case MATERIAL:
                case SKILL:
                case ITEM:
                    distinctAwards(award, itemBagList);
                    break;
                //			case EQUIP:
                //				processorNomalEquip(award);
                //				break;
                case OFFICER:
                    processorNomalOfficer(award);
                    break;
                case USEREXP:
                    this.userExp += award.getNum();
                    break;
                case MOONSTONE:
                    this.moonstone += award.getNum();
                    break;
                case LANTIANYU:
                    this.lanTianYu += award.getNum();
                    break;
                case MILITAREXPLOITS:
                    this.militaryExploits += award.getNum();
                    break;
                case FRIENDSHIP:
                    this.friendship += award.getNum();
                    break;
                case REPUTATION:
                    this.reputation += award.getNum();
                    break;
                case PROVISION:
                    this.provision += award.getNum();
                    break;
                case SOLDIER:
                    this.soldierList.add(award.getXmlId());
                    break;
                case LEFTEAR:
                    this.leftEar += award.getNum();
                    break;
                case METEORITE:
                    this.meteorite += award.getNum();
                default:
                    break;
            }
        }
    }

    /**
     * 保存奖励
     */
    public void awardPesistent() {
        saveItemBags();
        //        saveEquips();
        saveOfficer();
        saveUser();
        saveSoldier();
    }

    private void saveSoldier() {
        if (awardChannel == AwardChannel.PveFight) {
            return;
        }
        if (CollectionUtils.isEmpty(soldierList)) {
            return;
        }
        Barrack barrack = boFactory.getBarrackRepo().findBarrack(user.getId());
        boolean change = false;
        for (int soldierId : soldierList) {
            SoldierProperty property = boFactory.getSoldierData().getProperty(soldierId);
            SoldierType type = SoldierType.valueOf(property.getSoldierType());

            List<Integer> currSoldierIds = barrack.currOpenSoldierIds(type);
            if (currSoldierIds.contains(soldierId)) {
                continue;
            }
            barrack.openSoldier(type, soldierId);
            change = true;
        }
        if (change) {
            boFactory.getBarrackRepo().saveBarrack(barrack);
            boFactory.getMissionEngine().onEvent(new MissionEvent(MissionProperty.PROPERTY_解锁_新兵种, soldierList.size(), userId));
        }
    }

    /**
     * 保存奖励
     */
    public void awardPesistent(ItemBags itemBags) {
        this.itemBags = itemBags;
        awardPesistent();
    }

    /**
     * 保存奖励
     */
    public void awardPesistent(User user) {
        this.user = user;
        awardPesistent();
    }

    /**
     * 保存奖励
     */
    public void awardPesistent(User user, ItemBags itemBags) {
        this.user = user;
        this.itemBags = itemBags;
        awardPesistent();
    }

    /**
     * 把奖励列表发给前端展示
     * 
     * @return
     */
    public Map<String, Object> awardResult() {
        Map<String, Object> result = new HashMap<String, Object>();
        if (itemBag4Front != null && itemBag4Front.size() > 0) {
            result.put("classifyItemBagList", ItemData.classifyItemBagList(boFactory, itemBag4Front));
        }

        result.put("officerList", officers4Front);
        result.put("gold", gold);
        result.put("diamond", diamond);
        result.put("userExp", userExp);
        result.put("moonstone", moonstone);
        result.put("lanTianYu", lanTianYu);
        result.put("slave", slave);
        result.put("militaryExploits", militaryExploits);
        result.put("friendship", friendship);
        result.put("rewardId", rewardId);
        result.put("reputation", reputation);
        result.put("captive", officer);
        result.put("provision", provision);
        result.put("soldierList", soldierList);
        result.put("leftEar", leftEar);
        result.put("farmlandSnatch", getFarmlandSnatch());
        result.put("mineSnatch", getMineSnatch());
        result.put("meteorite", meteorite);
        return result;
    }

    private void distinctAwards(Award newAward, List<Award> existAwardList) {
        boolean isHad = false;
        for (Award awardTemp : existAwardList) {
            if (awardTemp.getXmlId() == newAward.getXmlId()) {
                awardTemp.incrNum(newAward.getNum());
                isHad = true;
                break;
            }
        }
        if (!isHad) {
            existAwardList.add(newAward.cloneAward());
        }
    }

    private void saveItemBags() {
        if (itemBagList == null || itemBagList.size() < 1) {
            return;
        }
        if (itemBags == null) {
            itemBags = itemRepo.findItemBags(userId);
        }
        for (Award Award : itemBagList) {
            itemBags.addOrIncrItemBag(Award.getXmlId(), Award.getNum());
            itemBag4Front.add(new ItemBag(Award.getXmlId(), Award.getNum()));
        }
        itemRepo.saveItemBags(itemBags);

        if (user == null) {
            user = userRepo.findUser(userId);
        }

        trackDomainService.trackInflowItem(user, awardChannel, itemBagList);
    }

    public void saveRepItemBags(List<Award> awards) {
        itemBag4Front.clear();
        for (Award Award : awards) {
            itemBag4Front.add(new ItemBag(Award.getXmlId(), Award.getNum()));
        }
    }

    /**
     * 2017-05-10 李鑫
     * 系统内将领奖励一定要用OfficerAward
     * json配表的将领奖励，num表示星级！！！！！
     * 如果奖励多个相同星级的奖励，数组中多配一条数据，而不是用num的来控制
     * 
     * @param award
     */
    private void processorNomalOfficer(Award award) {
        if (award instanceof OfficerAward) {
            for (int i = 0; i < award.getNum(); i++) {
                officerList.add((OfficerAward) award);
            }
        } else {
            officerList.add(new OfficerAward(award.getXmlId(), 1, award.getNum(), 1));
        }
    }

    private void saveOfficer() {
        if (CollectionUtils.isEmpty(officerList)) {
            return;
        }
        this.officers4Front.addAll(boFactory.createOfficer(userId, officerList));
    }

    private void saveUser() {
        boolean isSave = false;
        user = (user == null ? userRepo.findUser(userId) : user);
        if (gold > 0) {
            user.addGold(gold);
            isSave |= true;
            trackEconomy(CurrencyType.GOLD, gold, user.getGold());
        }
        if (diamond > 0) {
            user.addDiamond(diamond);
            isSave |= true;
            trackEconomy(CurrencyType.DIAMOND, diamond, user.getDiamond());
        }
        if (userExp > 0) {
            user.addAndRefreshLv(userExp);
            isSave |= true;
        }
        if (moonstone > 0) {
            user.addMoonstone(moonstone);
            isSave |= true;
            trackEconomy(CurrencyType.MOONSTONE, moonstone, user.getMoonstone());
        }
        if (militaryExploits > 0) {
            user.refreshMilitaryRank(militaryExploits);
            isSave |= true;
            trackEconomy(CurrencyType.MILITARYEXPLOITS, militaryExploits, user.getMilitaryExploits());
        }
        if (friendship > 0) {
            user.addFriendShip(this.friendship);
            isSave |= true;
            trackEconomy(CurrencyType.FRIENDSHIP, friendship, user.getFriendship());
        }
        if (lanTianYu > 0) {
            user.addLanTianYu(this.lanTianYu);
            isSave |= true;
            trackEconomy(CurrencyType.LANTIANYU, lanTianYu, user.getLanTianYu());
        }
        if (leftEar > 0) {
            user.addLeftEar(this.leftEar);
            isSave |= true;
            trackEconomy(CurrencyType.LEFTEAR, leftEar, user.getLeftEar());
        }
        if (meteorite > 0) {
            user.addMeteorite(this.meteorite);
            isSave |= true;
            trackEconomy(CurrencyType.METEORITE, meteorite, user.getMeteorite());
        }
        if (isSave) {
            userRepo.saveUser(user);
            upgradeEngine.upgrade(user);
        }
    }

    private void trackEconomy(CurrencyType currencyType, int changeValue, int currentValue) {
        trackDomainService.trackEarningEconomy(user, awardChannel, currencyType, changeValue);
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public void setItemRepo(ItemRepo itemRepo) {
        this.itemRepo = itemRepo;
    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }

    public void setUserRepo(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public Slave getSlave() {
        return slave;
    }

    public void setSlave(Slave slave) {
        this.slave = slave;
    }

    public Officer getOfficer() {
        return officer;
    }

    public void setOfficer(Officer officer) {
        this.officer = officer;
    }

    public User getUser() {
        return user;
    }

    public void setDiamond(int diamond) {
        this.diamond = diamond;
    }

    public void setLanTianYu(int lanTianYu) {
        this.lanTianYu = lanTianYu;
    }

    public int getMilitaryExploits() {
        return militaryExploits;
    }

    public int getReputation() {
        return reputation;
    }

    public void setMilitaryExploits(int militaryExploits) {
        this.militaryExploits = militaryExploits;
    }

    public void giveUnionRewards(int contribute) {
        ConBoxReward reward = unionCoinBoxData.getBoxRewardByContribute(contribute);
        if (reward == null) {
            return;
        }
        this.rewardId = reward.getId();
        List<Award> rewardList = unionCoinBoxData.findRewardByContribute(reward);
        transforAward(rewardList);
    }

    public void giveRegionRewards(int contribute) {
        ConBoxReward reward = regionConBoxData.getBoxRewardByContribute(contribute);
        if (reward == null) {
            return;
        }
        this.rewardId = reward.getId();
        List<Award> rewardList = regionConBoxData.findRewardByContribute(reward);
        transforAward(rewardList);
    }

    public void giveCampRewards(int rank) {
        ConBoxReward reward = lineupConBoxData.getBoxRewardByContribute(rank);
        if (reward == null) {
            return;
        }
        this.rewardId = reward.getId();
        List<Award> rewardList = lineupConBoxData.findRewardByContribute(reward);
        transforAward(rewardList);
    }

    public int getFarmlandSnatch() {
        return farmlandSnatch;
    }

    public void setFarmlandSnatch(int farmlandSnatch) {
        this.farmlandSnatch = farmlandSnatch;
    }

    public int getMineSnatch() {
        return mineSnatch;
    }

    public void setMineSnatch(int mineSnatch) {
        this.mineSnatch = mineSnatch;

    }

    public int getMeteorite() {
        return meteorite;
    }

    public void setMeteorite(int meteorite) {
        this.meteorite = meteorite;
    }

}
