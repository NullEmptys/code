package com.hoolai.sangoh5.bo.union;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.StringUtil;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.UnionProtocolBuffer.UnionUserProto;
import com.hoolai.sangoh5.bo.union.data.UnionTitleData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class UnionUser implements ProtobufSerializable<UnionUserProto> {

    public static final int LAST_QUIT_TIME_LIMIT = 24;

    private long userId;//玩家id

    private String userName;//玩家用户名

    private int sangoState;

    private List<Long> applyUnionId = new ArrayList<Long>();//申请加入的联盟的ids

    private int todayApplyNum;//今天申请联盟的次数

    private long lastQuitTime;//最后一次退出联盟的时间

    private int position = 1;

    private long unionId;//所在联盟的id

    private String unionName;//所在联盟的名字

    private int integral;//玩家的积分

    private int attackNum;//本周占领成功的次数

    private int defenceNum;//本周成功防御敌方玩家进攻的次数

    private int rescueNum;//本周成功解救盟友的次数

    private int rankNum;//在悬赏功能中，成功击杀目标的数量

    private int huntingNum;//本周数据在所属州的排名，积分算法待定

    private int[] medals;//我的徽章

    private int unionCoin;//联盟币

    private String userImage;

    private boolean isMyFriend = false;

    private int level;

    private UnionTitleData unionTitleData;

    ////////////////////////////////////////////////////////////
    public UnionUser() {

    }

    public UnionUser(long userId) {
        this.userId = userId;
    }

    public UnionUser(long userId, String userName, int sangoState, String image) {
        this.userId = userId;
        this.userName = userName;
        this.sangoState = sangoState;
        this.userImage = image;
    }

    public UnionUser(byte[] bytes) {
        parseFrom(bytes);
    }

    ////////////////////////////////////////////////////////////
    @Override
    public UnionUserProto copyTo() {
        UnionUserProto.Builder builder = UnionUserProto.newBuilder();
        if (!StringUtil.isBlank(userName)) {
            builder.setUserName(userName);
        }
        if (applyUnionId != null) {
            for (Long uid : applyUnionId) {
                builder.addApplyUnionId(uid);
            }
        }
        builder.setTodayApplyNum(todayApplyNum);
        builder.setLastQuitTime(lastQuitTime);
        builder.setPosition(position);
        builder.setUnionId(unionId);
        if (!StringUtil.isBlank(unionName)) {
            builder.setUnionName(unionName);
        }
        builder.setAttackNum(attackNum);
        builder.setDefenceNum(defenceNum);
        builder.setRescueNum(rescueNum);
        builder.setRankNum(rankNum);
        builder.setHuntingNum(huntingNum);
        if (medals != null) {
            for (Integer id : medals) {
                builder.addMedals(id);
            }
        }
        builder.setIntegral(integral);
        builder.setSangoState(sangoState);
        builder.setUserId(userId);
        builder.setUnionCoin(unionCoin);
        builder.setUserImage(userImage == null ? "" : userImage);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            copyFrom(UnionUserProto.parseFrom(bytes));
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void copyFrom(UnionUserProto message) {
        this.userName = message.getUserName();
        for (Long uid : message.getApplyUnionIdList()) {
            this.applyUnionId.add(uid);
        }
        this.todayApplyNum = message.getTodayApplyNum();
        this.lastQuitTime = message.getLastQuitTime();
        this.position = message.getPosition();
        this.unionId = message.getUnionId();
        this.unionName = message.getUnionName();
        this.attackNum = message.getAttackNum();
        this.defenceNum = message.getDefenceNum();
        this.rescueNum = message.getRescueNum();
        this.rankNum = message.getRankNum();
        this.huntingNum = message.getHuntingNum();
        int index = 0;
        for (Integer id : message.getMedalsList()) {
            this.medals[index++] = id;
        }
        this.integral = message.getIntegral();
        this.sangoState = message.getSangoState();
        this.userId = message.getUserId();
        this.unionCoin = message.getUnionCoin();
        this.userImage = message.getUserImage();
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<Long> getApplyUnionId() {
        return applyUnionId;
    }

    public void setApplyUnionId(List<Long> applyUnionId) {
        this.applyUnionId = applyUnionId;
    }

    public int getTodayApplyNum() {
        return todayApplyNum;
    }

    public void setTodayApplyNum(int todayApplyNum) {
        this.todayApplyNum = todayApplyNum;
    }

    public long getLastQuitTime() {
        return lastQuitTime;
    }

    public void setLastQuitTime(long lastQuitTime) {
        this.lastQuitTime = lastQuitTime;
    }

    public int getAttackNum() {
        return attackNum;
    }

    public void setAttackNum(int attackNum) {
        this.attackNum = attackNum;
    }

    public int getDefenceNum() {
        return defenceNum;
    }

    public void setDefenceNum(int defenceNum) {
        this.defenceNum = defenceNum;
    }

    public int getRescueNum() {
        return rescueNum;
    }

    public void setRescueNum(int rescueNum) {
        this.rescueNum = rescueNum;
    }

    public int getRankNum() {
        return rankNum;
    }

    public void setRankNum(int rankNum) {
        this.rankNum = rankNum;
    }

    public int getHuntingNum() {
        return huntingNum;
    }

    public void setHuntingNum(int huntingNum) {
        this.huntingNum = huntingNum;
    }

    public long getUnionId() {
        return unionId;
    }

    public void setUnionId(long unionId) {
        this.unionId = unionId;
    }

    public String getUnionName() {
        return unionName;
    }

    public void setUnionName(String unionName) {
        this.unionName = unionName;
    }

    public int[] getMedals() {
        return medals;
    }

    public void setMedals(int[] medals) {
        this.medals = medals;
    }

    public int getSangoState() {
        return sangoState;
    }

    public void setSangoState(int sangoState) {
        this.sangoState = sangoState;
    }

    public int getIntegral() {
        return integral;
    }

    public void setIntegral(int integral) {
        this.integral = integral;
    }

    public int getUnionCoin() {
        return unionCoin;
    }

    public void setUnionCoin(int unionCoin) {
        this.unionCoin = unionCoin;
    }

    //	public enum UnionOfficials{
    //		NONE,//没有用 已经废弃
    //		PING_MIN,//平民
    //		XIAN_LING,//县令
    //		TAI_SHOU,//太守
    //		CI_SHI,//刺史
    //		ZHOU_MU,//州牧
    //		;
    //		public static UnionOfficials translate2UnionOfficials(int a){
    //			for (UnionOfficials uo : UnionOfficials.values()) {
    //				if(uo.ordinal() == a){
    //					return uo;
    //				}
    //			}
    //			throw new BusinessException(ErrorCode.SYSTEM_ERROR);
    //		}
    //	}

    public void joinUnion(long unionId, String unionName) {
        this.unionName = unionName;
        this.unionId = unionId;
        this.position = 1;
        this.integral = 0;
        clearApplyUnionIds();
    }

    public void creatUnion(long unionId, String unionName) {
        this.unionName = unionName;
        this.unionId = unionId;
        this.position = 1;
        this.integral = 0;
    }

    public void clearApplyUnionIds() {
        this.applyUnionId = new ArrayList<Long>();
    }

    public void applyUnion(long unionId) {
        this.applyUnionId.add(unionId);
        this.todayApplyNum++;
    }

    public void quiteUnion() {
        this.unionName = null;
        this.unionId = 0;
        this.lastQuitTime = TimeUtil.currentTimeMillis();
        this.position = 1;
        this.integral = 0;
    }

    public boolean isEnough24Hours() {
        return TimeUtil.currentTimeMillis() - this.lastQuitTime >= TimeUnit.HOURS.toMillis(LAST_QUIT_TIME_LIMIT);
    }

    public boolean hasUnion() {
        return this.unionId > 0;
    }

    public void removeApplyUnid(long unionId) {
        this.applyUnionId.remove((Long) unionId);
    }

    public void addIntegralAndPosition(int num) {
        this.integral += num;
        if (position >= unionTitleData.MAX) {
            integral = Math.min(integral, unionTitleData.getProperty(unionTitleData.MAX).getTitlePoint());
            return;
        }

        UnionTitleProperty property = unionTitleData.getProperty(position);
        while (integral > property.getTitlePoint() && position < unionTitleData.MAX) {
            integral -= property.getTitlePoint();
            position++;
            property = unionTitleData.getProperty(position);
        }
    }

    public boolean hasApplyThisUnion(long unionId) {
        return this.applyUnionId.contains(unionId);
    }

    public void resetNewDayData() {
        this.todayApplyNum = 0;
    }

    public boolean isMyFriend() {
        return isMyFriend;
    }

    public void setMyFriend(boolean isMyFriend) {
        this.isMyFriend = isMyFriend;
    }

    public void fillIsFriend() {
        this.isMyFriend = true;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public void checkAndDecUnionCoin(int unionCoin) {
        if (unionCoin < 0 || unionCoin > this.unionCoin) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_UNION_COIN);
        }
        this.unionCoin -= unionCoin;
    }

    public void addUnionCoin(int unionCoin) {
        this.unionCoin += unionCoin;
    }

    public int getLevel() {
        return level;
    }

    public void fillLevel(int level) {
        this.level = level;
    }

    public void setUnionTitleData(UnionTitleData unionTitleData) {
        this.unionTitleData = unionTitleData;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

}
