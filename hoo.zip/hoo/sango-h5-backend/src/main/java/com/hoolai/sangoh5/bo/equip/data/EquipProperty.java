package com.hoolai.sangoh5.bo.equip.data;

import com.hoolai.sangoh5.bo.item.ItemBag;
import com.hoolai.sangoh5.util.json.JsonProperty;

public class EquipProperty extends JsonProperty {

    private String name;

    private int stage;

    private int suit;

    private String type;

    private String attribute;

    private float[] percentage;

    private int[] value;

    private String solderAttribute;

    private int[] solderType;

    private float[] solderPercentage;

    private int[] solderValue;

    private int needOfficerLv;

    //	private String image;
    private int improveOfficerLv;

    private int needGold;

    private int[] needItemType;

    private int[] needItemAmount;

    public enum EquipType {
        /**
         * 武器
         */
        WEAPON("weapon"),
        /**
         * 盔甲
         */
        ARMOR("armor"),
        /**
         * 头盔
         */
        HELMET("helmet"),
        /**
         * 马匹
         */
        HORSE("horse");

        private final String type;

        private EquipType(String type) {
            this.type = type;
        }

        public String typeName() {
            return this.type;
        }

        public static EquipType convertEquipType(String type) {
            for (EquipType equipType : values()) {
                if (equipType.typeName().equals(type)) {
                    return equipType;
                }
            }
            return null;
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStage() {
        return stage;
    }

    public void setStage(int stage) {
        this.stage = stage;
    }

    public int getSuit() {
        return suit;
    }

    public void setSuit(int suit) {
        this.suit = suit;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public float[] getPercentage() {
        return percentage;
    }

    public void setPercentage(float[] percentage) {
        this.percentage = percentage;
    }

    public int[] getValue() {
        return value;
    }

    public void setValue(int[] value) {
        this.value = value;
    }

    public int getNeedOfficerLv() {
        return needOfficerLv;
    }

    public void setNeedOfficerLv(int needOfficerLv) {
        this.needOfficerLv = needOfficerLv;
    }

    //	public String getImage() {
    //		return image;
    //	}
    //	public void setImage(String image) {
    //		this.image = image;
    //	}
    public int getNeedGold() {
        return needGold;
    }

    public void setNeedGold(int needGold) {
        this.needGold = needGold;
    }

    public int[] getNeedItemType() {
        return needItemType;
    }

    public void setNeedItemType(int[] needItemType) {
        this.needItemType = needItemType;
    }

    public int[] getNeedItemAmount() {
        return needItemAmount;
    }

    public void setNeedItemAmount(int[] needItemAmount) {
        this.needItemAmount = needItemAmount;
    }

    public int getImproveOfficerLv() {
        return improveOfficerLv;
    }

    public void setImproveOfficerLv(int improveOfficerLv) {
        this.improveOfficerLv = improveOfficerLv;
    }

    public String getSolderAttribute() {
        return solderAttribute;
    }

    public void setSolderAttribute(String solderAttribute) {
        this.solderAttribute = solderAttribute;
    }

    public int[] getSolderType() {
        return solderType;
    }

    public void setSolderType(int[] solderType) {
        this.solderType = solderType;
    }

    public float[] getSolderPercentage() {
        return solderPercentage;
    }

    public void setSolderPercentage(float[] solderPercentage) {
        this.solderPercentage = solderPercentage;
    }

    public int[] getSolderValue() {
        return solderValue;
    }

    public void setSolderValue(int[] solderValue) {
        this.solderValue = solderValue;
    }

    public ItemBag[] needItemBag() {
        ItemBag[] itemBags = new ItemBag[needItemType.length];
        for (int i = 0; i < needItemType.length; i++) {
            itemBags[i] = new ItemBag(needItemType[i], needItemAmount[i]);
        }
        return itemBags;

    }
}
