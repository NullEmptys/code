package com.hoolai.sangoh5.bo.rescue;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Utils {

    // 默认显示日期的格式
    public static final String DATAFORMAT_STR = "yyyy-MM-dd";

    // 默认显示日期时间的格式
    public static final String DATATIMEF_STR = "yyyy-MM-dd HH:mm:ss";

    public static DateFormat dateFormat = null;

    public static DateFormat dateTimeFormat = null;
    static {
        dateFormat = new SimpleDateFormat(DATAFORMAT_STR);
        dateTimeFormat = new SimpleDateFormat(DATATIMEF_STR);
    }

    /**
     * 格式化时间戳
     * 
     * @param value
     * @param pattern
     * @return
     */
    public static String formatTime(long timestamp, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern);

        return format.format(new Date(timestamp));
    }

    /**
     * 是否是同一天
     * 
     * @param ta
     * @param tb
     * @return
     */
    public static boolean isSameDay(long ta, long tb) {
        return Utils.formatTime(ta, "yyyyMMdd").equals(Utils.formatTime(tb, "yyyyMMdd"));
    }

    /**
     * 根据占领时间获取占领的天数
     * 
     * @param occupyTime
     * @return
     */
    public static int getOccupyDays(long occupyTime) {
        int days = (int) (occupyTime / (24 * 60 * 60 * 1000));
        int mod = (int) (occupyTime % (24 * 60 * 60 * 1000));
        if (mod >= (12 * 60 * 60 * 1000) && mod < (24 * 60 * 60 * 1000)) {
            days++;
        }
        return days;
    }

    /**
     * 随机指定范围内N个不重复的数 最简单最基本的方法
     * 
     * @param min
     *        指定范围最小值
     * @param max
     *        指定范围最大值
     * @param n
     *        随机数个数
     */
    public static int[] randomCommon(int min, int max, int n) {
        if (n > (max - min + 1) || max < min) {
            return null;
        }
        int[] result = new int[n];
        int count = 0;
        while (count < n) {
            int num = (int) (Math.random() * (max - min)) + min;
            boolean flag = true;
            for (int j = 0; j < n; j++) {
                if (num == result[j]) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                result[count] = num;
                count++;
            }
        }
        return result;
    }

    /**
     * int[] to list<Integer>
     * 
     * @param array
     * @return
     */
    public static List<Integer> toList(int[] array) {
        List<Integer> asList = new ArrayList<Integer>();
        if (array == null) {
            return null;
        }
        for (int arr : array) {
            asList.add(arr);
        }
        return asList;
    }

    /**
     * 获取给定时间小时数
     * 
     * @param time
     *        给定时间
     * @return
     */
    public static int getTimeOfHour(long time) {
        Calendar ca = Calendar.getInstance();
        ca.setTimeInMillis(time);

        return ca.get(Calendar.HOUR_OF_DAY);
    }

    /**
     * 两个时间戳相差的天数
     * 
     * @param a
     * @param b
     * @return
     */
    public static int getDaysBetween(long ta, long tb) {
        Calendar a = Calendar.getInstance();
        a.setTimeInMillis(ta);
        Calendar b = Calendar.getInstance();
        b.setTimeInMillis(tb);

        if (a.after(b)) {
            Calendar swap = a;
            a = b;
            b = swap;
        }

        int days = b.get(Calendar.DAY_OF_YEAR) - a.get(Calendar.DAY_OF_YEAR);
        int y2 = b.get(Calendar.YEAR);
        if (a.get(Calendar.YEAR) != y2) {
            a = (Calendar) a.clone();
            do {
                days += a.getActualMaximum(Calendar.DAY_OF_YEAR);
                a.add(Calendar.YEAR, 1);
            } while (a.get(Calendar.YEAR) != y2);
        }
        return days;
    }

    /**
     * 获取给定时间当前凌晨的时间对象
     * 
     * @param time
     *        取当天凌晨的话传入 System.currentTimeMillis() 即可
     * @return
     */
    public static long getTimeBeginOfToday(long time) {
        Calendar ca = Calendar.getInstance();
        ca.setTimeInMillis(time);
        ca.set(Calendar.HOUR_OF_DAY, 0);
        ca.set(Calendar.MINUTE, 0);
        ca.set(Calendar.SECOND, 0);
        ca.set(Calendar.MILLISECOND, 0);

        return ca.getTimeInMillis();
    }

    /**
     * 指定时间的毫秒数( 获取当天YYYY-mm-DD 12:00:00的时间)
     * 
     * @return
     */
    public static long getNowDayTime(String setTime) {

        String backOrForwardDay = dateFormat.format(new Date().getTime());
        backOrForwardDay += setTime;
        Date bfd = null;
        try {
            bfd = dateTimeFormat.parse(backOrForwardDay);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return bfd.getTime();
    }

    /**
     * 是否是今天
     * 
     * @param a
     * @return
     */
    public static boolean isToday(String a) {
        if (a == null) return false;
        Calendar c = Calendar.getInstance();
        Date today = c.getTime();
        SimpleDateFormat format = new SimpleDateFormat(DATATIMEF_STR);

        return format.format(today).equals(format.format(a));

    }

    public static long getLongTime(String date) {
        Date time = null;
        try {
            time = dateTimeFormat.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return time.getTime();
    }

    /**
     * 通过今天某一整点获取时间戳
     * 
     * @param hour
     * @return
     */
    public static long getTimeLine(int hour) {
        if (hour >= 0 && hour <= 24) {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(com.hoolai.sango.util.TimeUtil.currentTimeMillis());
            c.set(Calendar.HOUR_OF_DAY, hour);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            return c.getTimeInMillis();
        } else {
            return 0;
        }
    }

    public static long getReferenceTime(long lastproduceDay, int lastproduceHour) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(TimeUnit.DAYS.toMillis(lastproduceDay));
        calendar.set(Calendar.HOUR_OF_DAY, lastproduceHour);
        return calendar.getTimeInMillis();
    }

    public static void main(String[] args) {
        System.out.println(TimeUnit.MILLISECONDS.toHours(System.currentTimeMillis()));
    }

}
