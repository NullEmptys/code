package com.hoolai.sangoh5.bo.battle.unit;

import com.hoolai.util.IntHashMap;

/**
 * 战斗单元的行为，也可认为是状态，有记忆性的，在整个战斗中都有效
 *
 */
public class Behavior {

    /**
     * 静默，不能移动，不能攻击
     */
    private boolean isSlince;

    /**
     * 技能沉默，不能使用技能
     */
    private boolean isChenMo;

    /**
     * 物理攻击沉默，只能触发技能，如果没有技能或者未触发技能，攻击停顿
     * 正在移动的单元不能移动
     */
    private boolean isPhyChenMo;

    /**
     * 屏蔽技能效果和伤害
     */
    private boolean isShieldSkillHurt;

    /**
     * 屏蔽普攻伤害
     */
    private boolean isShieldBaseHurt;

    /**
     * 屏蔽所有控制状态
     */
    private boolean isShieldControl;

    private IntHashMap<Integer> skillTriggerNumMap = new IntHashMap<Integer>();// 记录可重复触发的又要持续回合的技能，避免效果被覆盖

    public int getSkillTriggerNum(int skillXmlId) {
        Integer skill = skillTriggerNumMap.get(skillXmlId);
        return skill == null ? 0 : skill.intValue();
    }

    public void addSkillTriggerNum(int skillXmlId, int num) {
        Integer skill = skillTriggerNumMap.get(skillXmlId);
        if (skill == null || skill.intValue() == 0) {
            skillTriggerNumMap.put(skillXmlId, num);
        } else {
            skillTriggerNumMap.put(skillXmlId, skill.intValue() + num);
        }
    }

    public boolean isSlince() {
        return isSlince && !isShieldControl;
    }

    public void setSlince(boolean isSlince) {
        this.isSlince = isSlince;
    }

    public boolean isChenMo() {
        return isChenMo && !isShieldControl;
    }

    public void setChenMo(boolean isChenMo) {
        this.isChenMo = isChenMo;
    }

    public IntHashMap<Integer> getSkillTriggerNumMap() {
        return skillTriggerNumMap;
    }

    public void setSkillTriggerNumMap(IntHashMap<Integer> skillTriggerNumMap) {
        this.skillTriggerNumMap = skillTriggerNumMap;
    }

    public boolean isPhyChenMo() {
        return isPhyChenMo && !isShieldControl;
    }

    public void setPhyChenMo(boolean isPhyChenMo) {
        this.isPhyChenMo = isPhyChenMo;
    }

    public boolean isShieldSkillHurt() {
        return isShieldSkillHurt;
    }

    public void setShieldSkillHurt(boolean isShieldSkillHurt) {
        this.isShieldSkillHurt = isShieldSkillHurt;
    }

    public boolean isShieldControl() {
        return isShieldControl;
    }

    public boolean isShieldBaseHurt() {
        return isShieldBaseHurt;
    }

    public void setShieldBaseHurt(boolean isShieldBaseHurt) {
        this.isShieldBaseHurt = isShieldBaseHurt;
    }

    public void setShieldControl(boolean isShieldControl) {
        this.isShieldControl = isShieldControl;
        if (isShieldControl) {
            clearControlStatus();
        }
    }

    public void clearControlStatus() {
        isSlince = false;
        isChenMo = false;
        isPhyChenMo = false;
    }

}
