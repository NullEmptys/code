package com.hoolai.sangoh5.bo.activity.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.IntHashMap;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-12 16:51
 * @version : 1.0
 */
@Component
public class RewardLvData extends JsonData<RewardLvProperty> {

    protected IntHashMap<RewardLvProperty> levelMap = new IntHashMap<RewardLvProperty>();

    @PostConstruct
    @Override
    public void init() {
        try {
            initData("com/hoolai/sangoh5/rewardLv.json", RewardLvProperty.class);
            initLevel();
        } catch (IOException e) {
            logger.error(e);
        }
    }

    private void initLevel() {
        Collection<RewardLvProperty> values = propertyMap.values();
        for (RewardLvProperty property : values) {
            levelMap.put(property.getLv(), property);
        }
    }

    @Override
    protected void checkProperty(RewardLvProperty property) {

    }

    public RewardLvProperty findReward(int level) {
        return levelMap.get(level);

    }

    public List<Award> getRewardLevel(int level) {
        RewardLvProperty property = propertyMap.get(level);
        List<Award> items = new ArrayList<Award>();

        String type[] = property.getType();
        int reAward[] = property.getReward();
        int num[] = property.getNum();

        for (int i = 0; i < type.length; i++) {
            items.add(new Award(reAward[i], num[i], AwardType.converToAwardType(type[i])));
        }
        return items;
    }

    public int getSize() {
        return propertyMap.size();
    }

}
