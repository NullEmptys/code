package com.hoolai.sangoh5.bo.battle.skill.defence.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ChangeHpBuff;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 将对方的伤害转化成治疗
 * 
 * @author liqing
 *
 */
public class HurtTreatment extends DefenceSkill {

    @Override
    public void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {
        if (effect == null || effect.getDeltaHp() < 1 || actor.isDead() || target.isDead()) {
            return;
        }
        int delHp = effect.getDeltaHp();
        int treatmentHp = (int) (delHp * this.percentage);

        //回血的要立马执行，因为如果先执行的effect，死了回血也不能复生
        target.changeHp(-treatmentHp);

        target.addBuff(new ChangeHpBuff(xmlId, name, target.name(), currentLevel, AttributeType.HP, this, true).withActorName(actor.name()).withTargetName(target.name())
                .withDeltaHp(-treatmentHp));

        target.addBattleLog(target.name() + "使用" + this.xmlId + "[" + this.name + "]从" + actor.name() + "的打出的伤害中回血，伤害=" + delHp + ",回血=" + treatmentHp + ",当前血量=" + target.getHp());
    }

    @Override
    public Skill clone() {
        return super.clone(new HurtTreatment());
    }

}
