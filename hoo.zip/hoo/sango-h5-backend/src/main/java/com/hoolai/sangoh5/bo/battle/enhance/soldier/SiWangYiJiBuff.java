package com.hoolai.sangoh5.bo.battle.enhance.soldier;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.fight.ActionResult;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.soldier.active.BaseSoldierPhysicsSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.SoldierUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.bo.soldier.RestraintFinder;
import com.hoolai.sangoh5.util.ProbabilityGenerator;

/**
 *
 */
public class SiWangYiJiBuff extends Buff {

    private boolean isDo;

    private Skill skill;

    private FightUnit skillOwner;

    private ProbabilityGenerator pg;

    @Override
    public void targetEnhanceAfterExcuteBuffs(List<ActionResult> actionResultList, TargetCollection tc) {
        float delRate = skillOwner.getHp() / skillOwner.getOriginalHp();
        if (!isDo && delRate <= (skill.getValue() / 100)) {
            FightUnit target = skillOwner.getDefender();
            if (target == null) {
                skillOwner.addBattleLog(skillOwner.name() + "触发死亡一击，但未找到攻击目标");
                isDo = true;
                return;
            }

            RestraintFinder finder = ((SoldierUnit) skillOwner).getSoldierAttackSkill().getRestraintFinder();
            BaseSoldierPhysicsSkill physicsSkill = new BaseSoldierPhysicsSkill(finder, pg);
            physicsSkill.setPercentage(skill.getPercentage());

            int delHp = physicsSkill.calculateLostPoint4AttackSkill(skillOwner, target);
            target.changeHp(delHp);

            Buff buff = new Buff(skill.getXmlId(), skill.getName(), target.name(), Effect.DEFAULT_BUFF_LEVEL).withActorName(actorName).withTargetName(target.name())
                    .withDeltaHp(delHp);

            ActionResult actionResult = findActionResult(skill.getXmlId(), target, actionResultList);
            actionResult.getBuffList().add(buff);
            isDo = true;
            skillOwner.addBattleLog(skillOwner.name() + "触发死亡一击，" + target.name() + "受到" + delHp + "点伤害");
        }
    }

    /*
     * 触发技能后的下一回生效
     */
    @Override
    public void apply(FightUnit target) {
        this.result();
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
    }

    @Override
    protected SiWangYiJiBuff clone() {
        SiWangYiJiBuff buff = (SiWangYiJiBuff) super.clone(new SiWangYiJiBuff(this.targetUsedSkillXmlId, executeName, isForFront, currentLevel, skill, skillOwner));
        return buff;
    }

    public SiWangYiJiBuff(int targetUsedSkillXmlId, FightUnitName executeName, boolean is4front, int currentLevel, Skill skill, FightUnit skillOwner) {
        super(targetUsedSkillXmlId, skill.getName(), executeName, currentLevel);
        this.isForFront = is4front;
        this.skill = skill;
        this.skillOwner = skillOwner;
    }

}
