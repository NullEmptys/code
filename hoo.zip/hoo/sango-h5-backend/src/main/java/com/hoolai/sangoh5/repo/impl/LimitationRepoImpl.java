package com.hoolai.sangoh5.repo.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.sangoh5.bo.Limitation;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryEffectType;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryRankProperty;
import com.hoolai.sangoh5.bo.officer.OfficerLimitation;
import com.hoolai.sangoh5.repo.LimitationRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.repo.impl.key.LimitationKey;
import com.hoolai.sangoh5.service.BusinessDomainService;
import com.hoolai.util.TimeUtil;
import com.schooner.MemCached.MemcachedItem;

@Repository("limitationRepo")
public class LimitationRepoImpl implements LimitationRepo {

    @Autowired
    @Qualifier("userClient")
    private ExtendedMemcachedClient client;

    @Autowired
    private ConstantsPoolData constantsPool;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private BusinessDomainService businessDomainService;

    @Override
    public boolean addOperationTime(long userId, long value) {
        return client.add(LimitationKey.getOperationTimeKey(userId), value);
    }

    public MemcachedItem findOperationTime(long userId) {
        return client.gets(LimitationKey.getOperationTimeKey(userId));
    }

    public boolean removeOperationTime(long userId) {
        return client.delete(LimitationKey.getOperationTimeKey(userId));
    }

    public void saveOpenrationTime(long userId, long value) {
        client.set(LimitationKey.getOperationTimeKey(userId), value);
    }

    @Override
    public OfficerLimitation findOfficerLimitation(long userId) {
        String key = LimitationKey.getOfficerLimitationKey(userId);
        Object obj = client.get(key);

        userRepo.findUser(userId);

        MilitaryRankProperty property = businessDomainService.getMilitaryEffectValue(userId, MilitaryEffectType.NORMALRECNUMADD);
        int addTokenRecrNum = 0;
        if (property != null) {
            addTokenRecrNum = property.getNormalRecNumAdd();
        }
        OfficerLimitation fficerLimitation = null;
        if (obj == null) {
            fficerLimitation = new OfficerLimitation(userId, addTokenRecrNum + constantsPool.getProperty(33).getValue());
        } else {
            byte[] data = (byte[]) obj;
            fficerLimitation = new OfficerLimitation(userId, data, addTokenRecrNum + constantsPool.getProperty(33).getValue());
        }
        return fficerLimitation;
    }

    @Override
    public boolean saveOfficerLimitation(OfficerLimitation officerLimitation) {
        return client.set(LimitationKey.getOfficerLimitationKey(officerLimitation.getUserId()), officerLimitation.toByteArray());
    }

    @Override
    public Limitation findLimitation(long userId, Limitation.Type limitationType) {
        String key = LimitationKey.getDayLimitationKey(userId, limitationType);
        Object o = client.get(key);
        String limiationValue = o == null ? (0 + "|" + 0) : (String) o;
        Limitation limitation = new Limitation(limiationValue, limitationType);
        limitation.checkAndReset();
        return limitation;
    }

    @Override
    public void saveLimitation(long userId, Limitation limitation) {
        String key = LimitationKey.getDayLimitationKey(userId, limitation.getLimitationType());
        client.set(key, limitation.value());
    }

    @Override
    public boolean getRecruitRedPoint(long userId) {
        OfficerLimitation officerLimitation = this.findOfficerLimitation(userId);
        long leftTokenRecrTime = Math.max(officerLimitation.getNextTokenRecrTime() - TimeUtil.currentTimeMillis(), 0) / 1000;
        long leftYbRecrTime = Math.max(officerLimitation.getNextYbRecrOffTime() - TimeUtil.currentTimeMillis(), 0) / 1000;
        if (leftTokenRecrTime <= 0 && officerLimitation.getTokenRecrLeftNum() > 0) {
            return true;
        }
        if (leftYbRecrTime <= 0) {
            return true;
        }
        return false;
    }

}
