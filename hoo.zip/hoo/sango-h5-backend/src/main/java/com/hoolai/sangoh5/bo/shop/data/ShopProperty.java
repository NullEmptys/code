package com.hoolai.sangoh5.bo.shop.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * 排位赛、竞技场、联盟 商店配置表
 * 
 * @author hp
 *
 */
public class ShopProperty extends JsonProperty {
	
	private String name;// 商品名称
	private String type;// 物品类型
	private int costAmount;// 消耗的货币数量
	private int num;// 出售的数量
	private int unlockLv;//道具可出售的等级限制
	private int sellType;//售卖类型
	private int probability;//出现概率

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getCostAmount() {
		return costAmount;
	}

	public void setCostAmount(int costAmount) {
		this.costAmount = costAmount;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getUnlockLv() {
		return unlockLv;
	}

	public void setUnlockLv(int unlockLv) {
		this.unlockLv = unlockLv;
	}

	public int getSellType() {
		return sellType;
	}

	public void setSellType(int sellType) {
		this.sellType = sellType;
	}

	public int getProbability() {
		return probability;
	}

	public void setProbability(int probability) {
		this.probability = probability;
	}
	

}
