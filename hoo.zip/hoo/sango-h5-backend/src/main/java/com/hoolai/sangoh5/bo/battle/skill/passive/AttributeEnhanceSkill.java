package com.hoolai.sangoh5.bo.battle.skill.passive;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.ForceType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.SkillType;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.SoldierUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.soldier.SoldierType.AttackType;

/**
 * 对指定FightUnit的指定属性进行加成的技能，被动技能
 *
 */
public class AttributeEnhanceSkill extends Skill {

    public void apply(FightUnit actor, TargetCollection tc) {

        boolean isAttacker = actor.isAttacker();
        switch (this.forceType) {
            case FRIEND:
                break;
            case ENEMY:
                isAttacker = !isAttacker;
                break;
        }

        switch (this.forceUnitType) {
            case OFFICER:
                applyAttribute(actor, tc.getAlive(FightUnitName.officerUnitName(isAttacker)));
                break;
            case SOLDIERS:
                apply4AllSoliders(actor, isAttacker, tc);
                break;
            case RANDOM_ONE:
                apply4RandomSoldier(actor, isAttacker, tc);
                break;
            case FOOTMAN:
                apply4OneSoldier(actor, isAttacker, tc, SoldierType.footman);
                break;
            case RIDER:
                apply4OneSoldier(actor, isAttacker, tc, SoldierType.rider);
                break;
            case ARCHER:
                apply4OneSoldier(actor, isAttacker, tc, SoldierType.archer);
                break;
            case SPEARMAN:
                apply4OneSoldier(actor, isAttacker, tc, SoldierType.spearman);
                break;
            case VEHICLEMAN:
                apply4OneSoldier(actor, isAttacker, tc, SoldierType.vehicleman);
                break;
            case CROSSBOWMAN:
                apply4OneSoldier(actor, isAttacker, tc, SoldierType.crossbowman);
                break;
            case OFFICER_SOLDIERS:
                applyAttribute(actor, tc.getAlive(FightUnitName.officerUnitName(isAttacker)));
                apply4AllSoliders(actor, isAttacker, tc);
                break;
            case LONG_RANGE:
                apply4LongRangeSoldier(actor, isAttacker, tc);
                break;
            case CLOSE_COMBAT:
                apply4CloseCombatSoldier(actor, isAttacker, tc);
                break;
        }
    }

    private void apply4CloseCombatSoldier(FightUnit actor, boolean isAttacker, TargetCollection tc) {
        for (Entry<FightUnitName, FightUnit> entry : tc.getUnitMap().entrySet()) {
            FightUnitName key = entry.getKey();
            if (key.info().isAttacker() == isAttacker && key.info().isSoldier()) {
                SoldierUnit fightUnit = (SoldierUnit) entry.getValue();
                if (fightUnit.getSoldierFightType() == AttackType.CLOSE_COMBAT) {
                    applyAttribute(actor, fightUnit);
                }
            }
        }
    }

    private void apply4LongRangeSoldier(FightUnit actor, boolean isAttacker, TargetCollection tc) {
        for (Entry<FightUnitName, FightUnit> entry : tc.getUnitMap().entrySet()) {
            FightUnitName key = entry.getKey();
            if (key.info().isAttacker() == isAttacker && key.info().isSoldier()) {
                SoldierUnit fightUnit = (SoldierUnit) entry.getValue();
                if (fightUnit.getSoldierFightType() == AttackType.LONG_RANGE) {
                    applyAttribute(actor, fightUnit);
                }
            }
        }
    }

    private void apply4OneSoldier(FightUnit actor, boolean isAttacker, TargetCollection tc, SoldierType soldierType) {
        for (Entry<FightUnitName, FightUnit> entry : tc.getUnitMap().entrySet()) {
            FightUnitName key = entry.getKey();
            if (key.info().isAttacker() == isAttacker && key.info().isSoldier()) {
                SoldierUnit fightUnit = (SoldierUnit) entry.getValue();
                if (fightUnit.getSoldierType() == soldierType) {
                    applyAttribute(actor, fightUnit);
                }
            }
        }
    }

    private void apply4RandomSoldier(FightUnit actor, boolean isAttacker, TargetCollection tc) {
        List<FightUnit> fightUnits = new ArrayList<FightUnit>(4);
        for (Entry<FightUnitName, FightUnit> entry : tc.getUnitMap().entrySet()) {
            FightUnitName key = entry.getKey();
            if (key.info().isAttacker() == isAttacker && key.info().isSoldier()) {
                fightUnits.add(entry.getValue());
            }
        }

        if (fightUnits.isEmpty()) return;

        applyAttribute(actor, fightUnits.get(pg.getRandomNumber(fightUnits.size() - 1)));
    }

    private void apply4AllSoliders(FightUnit actor, boolean isAttacker, TargetCollection tc) {
        for (Entry<FightUnitName, FightUnit> entry : tc.getUnitMap().entrySet()) {
            FightUnitName key = entry.getKey();
            if (key.info().isAttacker() == isAttacker && key.info().isSoldier()) {
                applyAttribute(actor, entry.getValue());
            }
        }
    }

    protected void applyAttribute(FightUnit actor, FightUnit fightUnit) {
        if (fightUnit == null) return;//如果没有这个战斗单位

        if ((this.skillType.equals(SkillType.DEFENDER_PASSIVE) && fightUnit.isAttacker()) || (this.skillType.equals(SkillType.ATTACKER_PASSIVE) && !fightUnit.isAttacker())) {
            return;
        }

        boolean self = this.forceType.equals(ForceType.FRIEND);
        float realPercentage = self ? this.percentage : -this.percentage;
        float realValue = self ? this.value : -this.value;
        //        if (logger.isDebugEnabled()) {
        //        logger.debug("isAttacker: "+fightUnit.isAttacker()+" , fightUnitName: "+fightUnit.name()
        //        		+" , skill id: "+ this.skillId +" , skillXmlId id:" + this.xmlId 
        //        		+" , attack:"+fightUnit.baseAttackPoint()+"  ,realPercentage="+realPercentage
        //        		+" ,realValue:"+realValue+"  ,changeAttackPoint: "+(fightUnit.baseAttackPoint() * realPercentage + realValue));
        //    }
        switch (this.attributeType) {
            case ATTACK:
                //                if (logger.isDebugEnabled()) {
                //        	logger.debug(fightUnit.name()+"skill id:"+this.skillId+",attack:"+fightUnit.baseAttackPoint()+",realPercentage="+realPercentage+",realValue:"+realValue+",changeAttackPoint:"+fightUnit.baseAttackPoint() * realPercentage + realValue);
                //                }
                float enhance = fightUnit.baseAttackPoint() * realPercentage + realValue;
                //            float originalAttack = fightUnit.attackPoint();
                fightUnit.changeAttackPoint(enhance);
                //                if (logger.isDebugEnabled()) {
                //            logger.debug("技能:"+this.name+"对"+fightUnit.name()+"加成,原始攻击力:"+originalAttack+",加成百分比="+realPercentage+",加成值:"+realValue+",最终加成攻击:"+enhance+",加成后的攻击力:"+fightUnit.attackPoint());
                //        }
                actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Action.DEFAULT_ACTION_LEVEL, attributeType).withActorName(actor.name())
                        .withTargetName(fightUnit.name()).withDeltaHp((int) (enhance)));
                actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + fightUnit.name() + "增加攻击力=" + enhance + ",加成比率=" + realPercentage + ",加成值="
                        + realValue);
                break;
            case DEFENCE:
                float enhanceD = fightUnit.baseDefencePoint() * realPercentage + realValue;
                //  float originalDefence = fightUnit.defencePoint();
                //                if (logger.isDebugEnabled()) {
                //        	logger.debug("skill id:"+this.skillId+",defence:"+fightUnit.baseDefencePoint()+",realPercentage="+realPercentage+",realValue:"+realValue+",changeDefencePoint:"+fightUnit.baseDefencePoint() * realPercentage + realValue);
                //        }
                fightUnit.changeDefencePoint(enhanceD);
                //                if (logger.isDebugEnabled()) {
                //            logger.debug("技能:"+this.name+"对"+fightUnit.name()+"加成,原始防御力:"+originalDefence+",加成百分比="+realPercentage+",加成值:"+realValue+",最终加成防御:"+enhanceD+",加成后的防御力:"+fightUnit.defencePoint());
                //        }
                actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Action.DEFAULT_ACTION_LEVEL, attributeType).withActorName(actor.name())
                        .withTargetName(fightUnit.name()).withDeltaHp((int) (enhanceD)));
                actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + fightUnit.name() + "增加防御力=" + enhanceD + ",加成比率=" + realPercentage + ",加成值="
                        + realValue);
                break;
            case HP:
                int enhanceH = Math.round(fightUnit.baseHp() * realPercentage + realValue);
                fightUnit.changeOriginalHp(enhanceH);
                //                if (logger.isDebugEnabled()) {
                //logger.debug("技能:"+this.name+"对"+fightUnit.name()+"加成,原始血量:"+fightUnit.getOriginalHp()+",加成百分比="+realPercentage+",加成值:"+realValue+",最终加成血量:"+enhanceH+",加成后的血量:"+fightUnit.getHp());
                //        }
                actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Action.DEFAULT_ACTION_LEVEL, attributeType).withActorName(actor.name())
                        .withTargetName(fightUnit.name()).withDeltaHp((enhanceH)));

                actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + fightUnit.name() + "增加初始血量=" + enhanceH + ",加成比率=" + realPercentage + ",加成值="
                        + realValue);
                break;
            case DELTA_HP: //和上面HP削减将领原始血量不同，此技能时直接削减将领现有的血量（包括装备和其他属性加成后的血量）
                int deltaHp = Math.round(fightUnit.getHp() * realPercentage + realValue);
                fightUnit.changeOriginalHp(deltaHp);
                actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Action.DEFAULT_ACTION_LEVEL, attributeType).withActorName(actor.name())
                        .withTargetName(fightUnit.name()).withDeltaHp((deltaHp)));
                //                if (logger.isDebugEnabled()) {
                //logger.debug("技能:"+this.name+"对"+fightUnit.name()+"加成,原始血量:"+fightUnit.getOriginalHp()+",加成百分比="+realPercentage+",加成值:"+realValue+",最终加成血量:"+deltaHp+",加成后的血量:"+fightUnit.getHp());
                //        }
                break;
            case ATTACK_DEFENCE://攻防同时加
                //        	originalAttack = fightUnit.attackPoint();
                //        	originalDefence = fightUnit.defencePoint();
                enhance = fightUnit.baseAttackPoint() * realPercentage + realValue;
                enhanceD = fightUnit.baseDefencePoint() * realPercentage + realValue;

                fightUnit.changeAttackPoint(enhance);
                fightUnit.changeDefencePoint(enhanceD);
                //                if (logger.isDebugEnabled()) {
                //            logger.debug("技能:"+this.name+"对"+fightUnit.name()+"加成,原始攻击力:"+originalAttack+",加成百分比="+realPercentage+",加成值:"+realValue+",最终加成攻击:"+enhance+",加成后的攻击力:"+fightUnit.attackPoint());
                //            logger.debug("技能:"+this.name+"对"+fightUnit.name()+"加成,原始防御力:"+originalDefence+",加成百分比="+realPercentage+",加成值:"+realValue+",最终加成防御:"+enhanceD+",加成后的防御力:"+fightUnit.defencePoint());
                //        }
                actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Action.DEFAULT_ACTION_LEVEL, AttributeType.ATTACK).withActorName(actor.name())
                        .withTargetName(fightUnit.name()).withDeltaHp((int) (enhance)));
                actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Action.DEFAULT_ACTION_LEVEL, AttributeType.DEFENCE).withActorName(actor.name())
                        .withTargetName(fightUnit.name()).withDeltaHp((int) (enhanceD)));
                actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + fightUnit.name() + "增加攻击力=" + enhance + ",增加防御力=" + enhanceD + ",加成比率="
                        + realPercentage + ",加成值=" + realValue);
                break;
            case ATTACK_DEFENCE_HP://攻防血同时加
                enhance = fightUnit.baseAttackPoint() * realPercentage + realValue;
                //originalAttack = fightUnit.attackPoint();

                enhanceD = fightUnit.baseDefencePoint() * realPercentage + realValue;
                //originalDefence = fightUnit.defencePoint();

                enhanceH = Math.round(fightUnit.baseHp() * realPercentage + realValue);

                fightUnit.changeAttackPoint(enhance);
                fightUnit.changeDefencePoint(enhanceD);
                fightUnit.changeOriginalHp(enhanceH);

                actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Action.DEFAULT_ACTION_LEVEL, AttributeType.ATTACK).withActorName(actor.name())
                        .withTargetName(fightUnit.name()).withDeltaHp((int) (enhance)));
                actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Action.DEFAULT_ACTION_LEVEL, AttributeType.DEFENCE).withActorName(actor.name())
                        .withTargetName(fightUnit.name()).withDeltaHp((int) (enhanceD)));
                actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Action.DEFAULT_ACTION_LEVEL, AttributeType.HP).withActorName(actor.name())
                        .withTargetName(fightUnit.name()).withDeltaHp((enhanceH)));

                actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + fightUnit.name() + "增加攻击力=" + enhance + ",增加防御力=" + enhanceD + ",增加原始血量=" + enhanceH
                        + ",加成比率=" + realPercentage + ",加成值=" + realValue);

                //                if (logger.isDebugEnabled()) {
                //logger.debug("技能:"+this.name+"对"+fightUnit.name()+"加成,原始攻击力:"+originalAttack+",加成百分比="+realPercentage+",加成值:"+realValue+",最终加成攻击:"+enhance+",加成后的攻击力:"+fightUnit.attackPoint());
                //logger.debug("技能:"+this.name+"对"+fightUnit.name()+"加成,原始防御力:"+originalDefence+",加成百分比="+realPercentage+",加成值:"+realValue+",最终加成防御:"+enhanceD+",加成后的防御力:"+fightUnit.defencePoint());
                //logger.debug("技能:"+this.name+"对"+fightUnit.name()+"加成,原始血量:"+fightUnit.baseHp()+",加成百分比="+realPercentage+",加成值:"+realValue+",最终加成血量:"+enhanceH+",加成后的血量:"+fightUnit.getHp());
                //        }
                break;
            case TRIGGER:
                fightUnit.changeAllSkillChance(realPercentage * 100);
                break;
            case TOTAL_DEFENCE:
                float total_enhanceD = fightUnit.defencePoint() * realPercentage + realValue;
                //float total_originalDefence = fightUnit.defencePoint();
                //                if (logger.isDebugEnabled()) {
                //logger.debug("skill id:"+this.skillId+",defence:"+total_originalDefence+",realPercentage="+realPercentage+",realValue:"+realValue+",changeDefencePoint:"+total_originalDefence * realPercentage + realValue);
                //        }
                fightUnit.changeDefencePoint(total_enhanceD /*+ fightUnit.huangLongJiaoDefence()*/);
                //                if (logger.isDebugEnabled()) {
                //logger.debug("技能:"+this.name+"对"+fightUnit.name()+"加成,原始防御力:"+total_originalDefence+",加成百分比="+realPercentage+",加成值:"+realValue+",最终加成防御:"+total_enhanceD+",加成后的防御力:"+fightUnit.defencePoint());
                //        }
                break;
            default:
                break;
        }

    }

    @Override
    public Skill clone() {
        return super.clone(new AttributeEnhanceSkill());
    }

}
