package com.hoolai.sangoh5.bo.battle.skill.soldier.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class LianShe extends BaseSoldierPhysicsSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        this.actor = actor;
        target = actor.getDefender();
        if (null == target) {
            return null;
        }

        int lostHp = calculateLostPoint4AttackSkill(actor, target);

        List<FightUnit> targets = new ArrayList<FightUnit>();
        for (int i = 0; i < value; i++) {
            Effect effect = new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name()).withDeltaHp(lostHp);
            targetDefence(actor, target, effect, null, tc, targets, currentLevel);
            target.addEffect(effect);
        }
        targets.add(target);
        return targets;
    }

    @Override
    public Skill clone() {
        return super.clone(new LianShe());
    }

}
