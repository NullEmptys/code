package com.hoolai.sangoh5.bo.battle.fight;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;

public interface BuffCollection {
 
    void addBuff(Buff buff);
    
    void addBuffs(List<Buff> buffs);
    
}
