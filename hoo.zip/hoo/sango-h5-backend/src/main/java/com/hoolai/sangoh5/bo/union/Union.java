package com.hoolai.sangoh5.bo.union;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.ArrayUtils;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.StringUtil;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.UnionProtocolBuffer.ApplyUnionInfoProto;
import com.hoolai.sangoh5.bo.UnionProtocolBuffer.UnionProto;
import com.hoolai.sangoh5.bo.item.Item;
import com.hoolai.sangoh5.bo.union.data.UnionBadgeData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Union implements ProtobufSerializable<UnionProto> {

    /**
     * 联盟总人数
     */
    public static final int UNION_TOTAL_NUMS = 50;

    /**
     * 3天内联盟人数不足 XX 人，联盟将解散
     */
    public static final int UNION_DISSOLUTION_DAY = 3;

    public static final int UNION_DISSOLUTION_NUMS = 20;

    public static final int[] DONATE_XMLIDS = { Item.ITEM_JUAN_XIAN_1, Item.ITEM_JUAN_XIAN_2, Item.ITEM_JUAN_XIAN_3, Item.ITEM_JUAN_XIAN_4 };

    private long unionId;//联盟id

    private String unionName;//联盟名

    private int level;//等级

    private int icon;//图标

    private String notes;//公告

    private long creatTime;//创建时间

    private int state;//联盟所属的州

    /**
     * 人数不足要求的时候 以这个时间来判断是否够3天 如果够就解散联盟
     */
    private long dissolutionTime;//3天内联盟人数不足20人，联盟将解散

    private long unionOwnerId;//盟主id

    private String unionOwnerName;//盟主名

    private List<Long> unionMembers = new ArrayList<Long>();//成员的userIds

    private List<ApplyUnionInfo> applyUnionInfo = new ArrayList<ApplyUnionInfo>();//申请者的信息

    private int[] donateItems = new int[DONATE_XMLIDS.length];//捐献的道具数量
    //	private int integral;

    private List<UnionUser> unionUsers;//联盟成员的具体信息

    private long levelUpTime;//联盟升级的时间 单位为分钟

    private transient long unionRank;

    ////////////////////////////////////////////////////construct/////////////////////////////////////////////
    public Union(long unionId) {
        super();
        this.unionId = unionId;
    }

    public Union(byte[] bytes) {
        parseFrom(bytes);
    }

    public Union(long unionId, String unionName, int state) {
        this(unionId);
        this.unionName = unionName;
        this.state = state;
    }

    ////////////////////////////////////////////////////ptotobuff  serialize/////////////////////////////////////////////
    @Override
    public UnionProto copyTo() {
        UnionProto.Builder builder = UnionProto.newBuilder();
        builder.setUnionId(unionId);
        builder.setUnionName(unionName);
        builder.setLevel(level);
        builder.setIcon(icon);
        if (!StringUtil.isBlank(notes)) builder.setNotes(notes);
        builder.setCreateTime(creatTime);
        builder.setDissolutionTime(dissolutionTime);
        builder.setUnionOwnerId(unionOwnerId);
        builder.setUnionOwnerName(unionOwnerName);
        for (Long id : unionMembers) {
            builder.addUnionMembers(id);
        }
        for (ApplyUnionInfo aui : applyUnionInfo) {
            builder.addApplyUnionInfo(aui.copyTo());
        }
        for (int num : donateItems) {
            builder.addDonateItems(num);
        }
        builder.setSangoState(state);
        builder.setLevelUpTime(levelUpTime);
        //        builder.setContributes(contributes.copyTo());
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            copyFrom(UnionProto.parseFrom(bytes));
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void copyFrom(UnionProto message) {
        this.unionId = message.getUnionId();
        this.unionName = message.getUnionName();
        this.level = message.getLevel();
        this.icon = message.getIcon();
        this.notes = message.getNotes();
        this.creatTime = message.getCreateTime();
        this.dissolutionTime = message.getDissolutionTime();
        this.unionOwnerId = message.getUnionOwnerId();
        this.unionOwnerName = message.getUnionOwnerName();
        for (Long id : message.getUnionMembersList()) {
            this.unionMembers.add(id);
        }
        for (ApplyUnionInfoProto aui : message.getApplyUnionInfoList()) {
            this.applyUnionInfo.add(new ApplyUnionInfo(aui));
        }
        for (int i = 0; i < message.getDonateItemsList().size(); i++) {
            this.donateItems[i] = message.getDonateItemsList().get(i);
        }
        this.state = message.getSangoState();
        this.levelUpTime = message.getLevelUpTime();
        //        this.contributes = new Contributes(message.getContributes());
    }

    /////////////////////////////////////////////////////get set method/////////////////////////////////////////////
    public long getUnionId() {
        return unionId;
    }

    public void setUnionId(long unionId) {
        this.unionId = unionId;
    }

    public String getUnionName() {
        return unionName;
    }

    public void setUnionName(String unionName) {
        this.unionName = unionName;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public long getCreatTime() {
        return creatTime;
    }

    public void setCreatTime(long creatTime) {
        this.creatTime = creatTime;
    }

    public long getDissolutionTime() {
        return dissolutionTime;
    }

    public void setDissolutionTime(long dissolutionTime) {
        this.dissolutionTime = dissolutionTime;
    }

    public List<Long> getUnionMembers() {
        return unionMembers;
    }

    public void setUnionMembers(List<Long> normalMemvers) {
        this.unionMembers = normalMemvers;
    }

    public List<ApplyUnionInfo> getApplyUnionInfo() {
        return applyUnionInfo;
    }

    public void setApplyUnionInfo(List<ApplyUnionInfo> applyUnionInfo) {
        this.applyUnionInfo = applyUnionInfo;
    }

    public long getUnionOwnerId() {
        return unionOwnerId;
    }

    public void setUnionOwnerId(long unionOwnerId) {
        this.unionOwnerId = unionOwnerId;
    }

    public int[] getDonateItems() {
        return donateItems;
    }

    public void setDonateItems(int[] donateItems) {
        this.donateItems = donateItems;
    }

    public List<UnionUser> getUnionUsers() {
        return unionUsers;
    }

    public void setUnionUsers(List<UnionUser> unionUsers) {
        this.unionUsers = unionUsers;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getUnionOwnerName() {
        return unionOwnerName;
    }

    public void setUnionOwnerName(String unionOwnerName) {
        this.unionOwnerName = unionOwnerName;
    }

    //	public int getIntegral() {
    //		return integral;
    //	}
    //
    //	public void setIntegral(int integral) {
    //		this.integral = integral;
    //	}
    ////////////////////////////////////////////////////////////////////////////////////////////

    public Union creatUnion(String unionName, int icon, long unionOwnerId, String unionOwnerName, int state) {
        this.unionName = unionName;
        this.icon = icon;
        this.creatTime = TimeUtil.currentTimeMillis();
        this.dissolutionTime = TimeUtil.currentTimeMillis();
        this.unionOwnerId = unionOwnerId;
        this.unionOwnerName = unionOwnerName;
        this.level = 0;
        this.state = state;
        this.levelUpTime = TimeUnit.MILLISECONDS.toMinutes(TimeUtil.currentTimeMillis());
        return this;
    }

    public int findMemberCounts() {
        return this.unionMembers.size() + 1;
    }

    public List<Long> findMemberIds() {
        List<Long> members = new ArrayList<Long>();
        members.add(unionOwnerId);
        members.addAll(unionMembers);
        return members;
    }

    public boolean isFull() {
        return unionMembers.size() + 1 >= UNION_TOTAL_NUMS;
    }

    public void addApplyIds(long userId) {
        ApplyUnionInfo unionInfo = new ApplyUnionInfo(userId, TimeUtil.currentTimeMillis());
        this.applyUnionInfo.add(unionInfo);
    }

    public void checkIsCreater(long userId) {
        if (this.unionOwnerId != userId) {
            throw new BusinessException(ErrorCode.YOU_NOT_UNION_OWNER);
        }
    }

    public void addUnionMembers(long userId) {
        this.unionMembers.add(userId);
        if (unionMembers.size() + 1 < UNION_DISSOLUTION_NUMS) {
            this.dissolutionTime = TimeUtil.currentTimeMillis();
        }
    }

    public void clearApplyerInfo() {
        this.applyUnionInfo = new ArrayList<ApplyUnionInfo>();
    }

    public void removeUnionMember(long userId) {
        this.unionMembers.remove(userId);
        if (unionMembers.size() + 1 < UNION_DISSOLUTION_NUMS) {
            this.dissolutionTime = TimeUtil.currentTimeMillis();
        }
    }

    //	public void addIntegral(int num){
    //		this.integral += num;
    //	}

    public boolean isCreater(long userId) {
        return this.unionOwnerId == userId;
    }

    /**
     * 是否符合 3天内联盟人数不足 XX 人，联盟将解散 的要求
     * 
     * @return
     */
    public boolean isAutoDeleteUnion() {
        return unionMembers.size() + 1 < UNION_DISSOLUTION_NUMS && TimeUtil.currentTimeMillis() - this.creatTime >= TimeUnit.DAYS.toMillis(UNION_DISSOLUTION_DAY);
    }

    /**
     * 添加捐献道具的数量
     */
    public boolean addDonateNum(int xmlId, int num) {
        int index = ArrayUtils.indexOf(DONATE_XMLIDS, xmlId);
        if (index >= 0) {
            donateItems[index] += num;
            return true;
        }
        return false;
    }

    /**
     * 是否是捐献道具
     */
    public static boolean isDonateItem(int xmlId) {
        return ArrayUtils.indexOf(DONATE_XMLIDS, xmlId) >= 0;
    }

    public void fillUnionUsers(List<UnionUser> unionUsers) {
        this.unionUsers = unionUsers;
    }

    public void checkAndLevelUp(UnionBadgeData unionBadgeData) {
        if (level >= unionBadgeData.getPropertyMap().size() - 1) {
            throw new BusinessException(ErrorCode.UNION_HAD_MAX_LEVEL);
        }
        UnionBadgeProperty unionBadgeProperty = unionBadgeData.getProperty(level + 1);
        List<Integer> unionNeedId = unionBadgeProperty.getNeedID();
        List<Integer> unionNeedNum = unionBadgeProperty.getNeedNumber();
        for (int i = 0; i < unionNeedId.size(); i++) {
            int index = ArrayUtils.indexOf(DONATE_XMLIDS, unionNeedId.get(i));
            if (donateItems[index] < unionNeedNum.get(i)) {
                throw new BusinessException(ErrorCode.NOT_ENOUGH_ITEM);
            }
            donateItems[index] -= unionNeedNum.get(i);
        }
        level++;
        this.levelUpTime = TimeUnit.MILLISECONDS.toMinutes(TimeUtil.currentTimeMillis());
    }

    public long getLevelUpTime() {
        return levelUpTime;
    }

    public void setLevelUpTime(long levelUpTime) {
        this.levelUpTime = levelUpTime;
    }

    public int getIndex() {
        long now = TimeUtil.currentTimeMillis();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(now);

        int day = calendar.get(Calendar.DAY_OF_WEEK);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        if (hour >= 21) {
            return day;
        } else {
            return day - 1;
        }
    }

    public long getUnionRank() {
        return unionRank;
    }

    public void setUnionRank(long unionRank) {
        this.unionRank = unionRank;
    }

    //    public Map<String, Integer> findContributes() {
    //        return contributes.findContributes();
    //    }

    //    public Contributes findContributes() {
    //        return contributes;
    //    }
    //
    //    public int getContribute() {
    //        Contribute contribute = contributes.getLastContribute();
    //        return contribute == null ? 0 : contribute.getContribute();
    //    }
}
