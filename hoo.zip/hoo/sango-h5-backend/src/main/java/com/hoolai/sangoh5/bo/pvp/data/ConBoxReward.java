package com.hoolai.sangoh5.bo.pvp.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-13 11:08
 * @version : 1.0
 */
public abstract class ConBoxReward extends JsonProperty {

    /** 奖励id **/
    private int id;

    /** 奖励类型 **/
    private String[] rewardTypes;

    /** 奖励id **/
    private int[] rewardIds;

    /** 奖励数量 **/
    private int[] rewardNums;

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    public String[] getRewardTypes() {
        return rewardTypes;
    }

    public void setRewardTypes(String[] rewardTypes) {
        this.rewardTypes = rewardTypes;
    }

    public int[] getRewardIds() {
        return rewardIds;
    }

    public void setRewardIds(int[] rewardIds) {
        this.rewardIds = rewardIds;
    }

    public int[] getRewardNums() {
        return rewardNums;
    }

    public void setRewardNums(int[] rewardNums) {
        this.rewardNums = rewardNums;
    }

    public boolean contains(int contribute) {
        return false;
    }

}
