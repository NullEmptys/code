package com.hoolai.sangoh5.event.event;

import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.event.Event;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 17:34
 * @version : 1.0
 */
public abstract class UserEvent implements Event {

    protected final User owner;

    /**
     * @param owner
     */
    public UserEvent(User owner) {
        super();
        this.owner = owner;
    }

    public User getOwner() {
        return owner;
    }

}
