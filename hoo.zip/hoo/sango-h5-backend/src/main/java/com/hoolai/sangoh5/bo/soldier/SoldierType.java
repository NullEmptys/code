package com.hoolai.sangoh5.bo.soldier;



public enum SoldierType {

	/**
	 * 弓箭兵  远攻
	 */
	archer (1,"archer") {
		@Override
		public AttackType attackType() {
			return AttackType.LONG_RANGE;
		}
	},
	  /**
     * 弩兵  远攻
     */
    crossbowman (2,"crossbowman") {
		@Override
		public AttackType attackType() {
			return AttackType.LONG_RANGE;
		}
    },
    /**
     * 车兵  远攻
     */
    vehicleman (3,"vehicleman") {
		@Override
		public AttackType attackType() {
			return AttackType.LONG_RANGE;
		}
    },
    /**
     * 骑兵  近战
     */
    rider (4,"rider") {
		@Override
		public AttackType attackType() {
			return AttackType.CLOSE_COMBAT;
		}
    },
    /**
     * 步兵  近战
     */
    footman (5,"footman") { 
		@Override
		public AttackType attackType() {
			return AttackType.CLOSE_COMBAT;
		}
    },
    /**
     * 矛兵  近战
     */
    spearman (6,"spearman") {
		@Override
		public AttackType attackType() {
			return AttackType.CLOSE_COMBAT;
		}
    }
    ;

    public abstract AttackType attackType();
    
    private final int value;
    private final String name;
    
    private SoldierType(int value,String name) {
        this.value = value;
        this.name = name;
    }
    
    public int value() {
        return this.value;
    }
    
    public String trackName(){
    	return this.name;
    }
    
    public static SoldierType valueOf(int value) {
        switch (value) {
        case 1:
            return archer;
        case 2:
            return crossbowman;
        case 3:
        	return vehicleman;
        case 4:
            return rider;
        case 5:
        	return footman;
        case 6:
        	return spearman;
        default:
            throw new IllegalArgumentException("there is no SoldierType enum element`s value is " + value);
        }
    }
    
    public enum AttackType{
    	CLOSE_COMBAT(1),//近战
    	LONG_RANGE(2),//远攻
    	TRIGGER(3);//触发
    	
    	private final int type;
    	private AttackType(int type){
    		this.type = type;
    	}
    	
    	public int typeInt(){
    		return this.type;
    	}
    	
    	public static AttackType convertToType(int typeInt){
    		for(AttackType type:values()){
    			if(type.typeInt()==typeInt){
    				return type;
    			}
    		}
    		return null;
    	}
    }
}
