package com.hoolai.sangoh5.bo.battle.skill;

public enum AttributeType {

    //攻击
    ATTACK("attack"),
    //防御
    DEFENCE("defence"),
    //血量
    HP("hp"),
    //带兵数
    CAPTAINSHIP("captainship"),
    //所有伤害
    HURT("hurt"),
    //经验值
    EXP("exp"),
    //攻防
    ATTACK_DEFENCE("attack_defence"),
    //防御与血量
    HP_DEFENCE("hp_defence"),
    //血量与带兵
    HP_CAPTAINSHIP("hp_captainship"),
    //死亡率
    DIE("die"),
    //无
    NONE("none"),
    //触发概率
    TRIGGER("trigger"),
    // 现有血量
    DELTA_HP("delta_hp"),
    // 加成后的总防御力
    TOTAL_DEFENCE("total_defence"),
    //攻防血
    ATTACK_DEFENCE_HP("attack_defence_hp"),
    //装备的攻防血
    EQUIP_ATTACK_DEFENCE_HP("equip_attack_defence_hp"),
    //士兵技能伤害
    SOLDIER_SKILL_HURT("soldier_skill_hurt"),
    //眩晕
    STUN("stun"),
    //移速
    MS("ms"),
    //攻速
    AS("as"),
    //无视技能伤害
    IMMUNOHURT("immunoHurt"),
    //无视普攻伤害
    IMMUNOBASEHURT("immunoBaseHurt"),
    //技能伤害
    SKILLHURT("skillHurt"),
    //普通伤害
    BASEHURT("baseHurt"),
    //治疗
    TREAT("treat"),
    //冷冻
    FROZEN("frozen"), CHEMO("chenmo"),
    // 无视控制眩晕冷冻等等状态
    IMMUNOCONTROL("immunoControl");

    private final String type;

    private AttributeType(String type) {
        this.type = type;
    }

    public static AttributeType convertType(String type) {
        for (AttributeType attributeType : values()) {
            if (attributeType.type.equals(type)) {
                return attributeType;
            }
        }
        return null;
    }

    public static boolean isBaseProperty(AttributeType attribyte) {
        return attribyte == AttributeType.ATTACK || attribyte == AttributeType.ATTACK_DEFENCE || attribyte == AttributeType.ATTACK_DEFENCE_HP || attribyte == AttributeType.DEFENCE
                || attribyte == AttributeType.HP || attribyte == AttributeType.HP_CAPTAINSHIP || attribyte == AttributeType.HP_DEFENCE;
    }
}
