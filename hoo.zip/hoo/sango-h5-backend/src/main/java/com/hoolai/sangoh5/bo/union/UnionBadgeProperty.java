package com.hoolai.sangoh5.bo.union;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class UnionBadgeProperty extends JsonProperty {

    private int level;

    private List<Integer> needID;

    private List<Integer> needNumber;

    private int value1;

    private int value2;

    private int value3;

    private int getGold;

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public List<Integer> getNeedID() {
        return needID;
    }

    public void setNeedID(List<Integer> needID) {
        this.needID = needID;
    }

    public List<Integer> getNeedNumber() {
        return needNumber;
    }

    public void setNeedNumber(List<Integer> needNumber) {
        this.needNumber = needNumber;
    }

    public int getValue1() {
        return value1;
    }

    public void setValue1(int value1) {
        this.value1 = value1;
    }

    public int getValue2() {
        return value2;
    }

    public void setValue2(int value2) {
        this.value2 = value2;
    }

    public int getValue3() {
        return value3;
    }

    public void setValue3(int value3) {
        this.value3 = value3;
    }

    public int getGetGold() {
        return getGold;
    }

    public void setGetGold(int getGold) {
        this.getGold = getGold;
    }

    public List<Integer> getEnhanceSkillS() {
        List<Integer> skills = new ArrayList<Integer>();
        skills.add(value1);
        skills.add(value2);
        skills.add(value3);
        return skills;
    }

}
