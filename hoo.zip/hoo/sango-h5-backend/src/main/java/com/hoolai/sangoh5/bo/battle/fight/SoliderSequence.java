package com.hoolai.sangoh5.bo.battle.fight;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;

import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.soldier.SoldierType.AttackType;
import com.hoolai.sangoh5.bo.tacticalManagement.Formation;
import com.hoolai.sangoh5.bo.tacticalManagement.FormationPos;
import com.hoolai.sangoh5.util.Constant;

/**
 * 
 * 士兵出手顺序队列
 * 
 */
public class SoliderSequence {

    public static final int OFFICER_POS = 7;

    public static final int[] ALL_POS = { 1, 2, 3, 4, 5, 6, 7 };

    private final int[] attackSequencePos;

    private final int[] oneRow;

    private final int[] twoRow;

    private final int[] threeRow;

    private int currentIndex = 0;

    public SoliderSequence(Formation attackFormation, Formation defenceFormation) {
        int[] attackerSequencePos = attackSqueue(attackFormation);
        int[] defenceSequencePos = attackSqueue(defenceFormation);

        int[] sequeue = new int[14];
        int j = 0;
        // 按照攻击、防御、攻击、防御...的顺序依次决定攻击的顺序
        for (int i = 0; i < 7; i++) {
            sequeue[j++] = attackerSequencePos[i];
            sequeue[j++] = defenceSequencePos[i];
        }

        attackSequencePos = sequeue;

        oneRow = null;
        twoRow = null;
        threeRow = null;
    }

    public SoliderSequence(int pos, Formation targetFormation) {
        attackSequencePos = null;

        oneRow = targetFormation.takeFightRow(1);
        twoRow = targetFormation.takeFightRow(2);
        threeRow = targetFormation.takeFightRow(3);
    }

    private int[] attackSqueue(Formation attackFormation) {
        List<FormationPos> formationPoses = attackFormation.getCorps();
        int[] jin = new int[0];
        int[] yuan = new int[0];
        int officer = 0;
        for (FormationPos formationPos : formationPoses) {
            if (formationPos.isOfficer()) {
                officer = formationPos.getPosInt();
            } else {
                if (formationPos.getSoldierType().attackType() == AttackType.CLOSE_COMBAT) {
                    jin = ArrayUtils.add(jin, formationPos.getPosInt());
                } else {
                    yuan = ArrayUtils.add(yuan, formationPos.getPosInt());
                }
            }
        }

        Arrays.sort(jin);
        Arrays.sort(yuan);

        int[] boths = ArrayUtils.addAll(jin, yuan);
        int[] both = ArrayUtils.add(boths, officer);

        return both;
    }

    /**
     * 是否是整场战斗的攻击方
     * 因为是按照攻击、防御、攻击、防御...的顺序依次决定攻击的顺序
     * 
     * @return
     */
    private boolean isAttacker() {
        return currentIndex % 2 == 0;
    }

    /**
     * 是否还有主动攻击的单元
     * 
     * @return
     */
    public boolean hasAttackNext() {
        return currentIndex < attackSequencePos.length;
    }

    /**
     * 主动攻击的单元
     * 
     * @return
     */
    public FightUnitName attackNext() {
        //不可能超出限制,如果超出限制则!hasNext();
        return FightUnitName.unitName(isAttacker(), attackSequencePos[currentIndex++]);
    }

    /**
     * 是否还有可选择的攻击目标
     * 
     * @return
     */
    public boolean hasTargetNext() {
        return currentIndex < OFFICER_POS;
    }

    public int[] targetNext(int row) {
        switch (row) {
            case 1:
                return oneRow;
            case 2:
                return twoRow;
            case 3:
                return threeRow;
        }
        return null;
    }

    public void reset() {
        currentIndex = 0;
    }

    public int getCurrentIndex() {
        return currentIndex;
    }

    public int randomTargetNext(int[] except) {
        Integer[] alivePos = getAlivePos(except);
        return alivePos[Constant.pg.getRandomNumber(alivePos.length - 1)];
    }

    private Integer[] getAlivePos(int[] except) {
        LinkedList<Integer> list = new LinkedList<Integer>();
        for (int pos : ALL_POS) {
            if (!list.contains(pos)) {
                list.add(pos);
            }
        }
        for (int pos : except) {
            if (list.contains(pos)) {
                list.remove(pos);
            }
        }
        Integer[] result = {};
        return list.toArray(result);
    }

}
