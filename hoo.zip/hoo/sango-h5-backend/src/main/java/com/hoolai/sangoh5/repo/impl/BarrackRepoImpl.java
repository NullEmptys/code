package com.hoolai.sangoh5.repo.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.hoolai.exception.DataAccessException;
import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.barrack.Barrack;
import com.hoolai.sangoh5.repo.BarrackRepo;
import com.hoolai.sangoh5.repo.impl.key.BarrackKey;

@Repository("barrackRepo")
public class BarrackRepoImpl implements BarrackRepo {

    @Autowired
    @Qualifier("itemClient")
    private ExtendedMemcachedClient client;

    @Autowired
    private BoFactory boFactory;

    @Override
    public boolean saveBarrack(Barrack barrack) {
        return client.set(BarrackKey.getBarrackKey(barrack.getUserId()), barrack.toByteArray());
    }

    @Override
    public Barrack findBarrack(long userId) {
        String barrackKey = BarrackKey.getBarrackKey(userId);
        byte[] bytes = (byte[]) client.get(barrackKey);
        if (bytes == null) {
            throw new DataAccessException("Barrack is null", "Barrack");
        }
        Barrack barrack = new Barrack(userId, bytes);
        boFactory.inject(barrack);
        return barrack.reflushBarrack();
    }

}
