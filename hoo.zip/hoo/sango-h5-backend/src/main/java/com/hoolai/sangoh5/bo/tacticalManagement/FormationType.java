package com.hoolai.sangoh5.bo.tacticalManagement;

public enum FormationType {

}
