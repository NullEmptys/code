package com.hoolai.sangoh5.bo.user.data;

import java.io.IOException;
import java.util.Iterator;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class NoviceRewardData extends JsonData<NoviceRewardProperty> {

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/qiangZhiDiaoLuo.json", NoviceRewardProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(NoviceRewardProperty property) {
        // TODO Auto-generated method stub

    }

    public NoviceRewardProperty getNoviceRewardByType(int type, int pveBarrId) {
        Iterator<NoviceRewardProperty> it = this.getPropertyMap().values().iterator();
        while (it.hasNext()) {
            NoviceRewardProperty nrp = it.next();
            if (nrp.getWhetherDrop() == type && nrp.getCorresponding() == pveBarrId) {
                return nrp;
            }
        }
        return null;
    }

}
