package com.hoolai.sangoh5.bo.pve.data;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Component;

import com.hoolai.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class ChapterData extends JsonData<ChapterProperty> {

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/chapter.json", ChapterProperty.class);
            check();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void check() {
        for (ChapterProperty property : propertyMap.values()) {
            int[] stages = property.getStageId();
            Set<Integer> set = new HashSet<Integer>();
            int temp = 0;
            for (int stage : stages) {
                if (stage < temp) {
                    throw new BusinessException(ErrorCode.STATUS_ERROR, "chapter=" + property.getId() + ",stage=" + ArrayUtils.toString(stages) + "不是递增关卡");
                }
                set.add(stage);
                temp = stage;
            }
            if (set.size() < stages.length) {
                throw new BusinessException(ErrorCode.STATUS_ERROR, "chapter=" + property.getId() + ",stage=" + ArrayUtils.toString(stages) + "有重复关卡");
            }
        }
    }

    @Override
    protected void checkProperty(ChapterProperty property) {
        // TODO Auto-generated method stub

    }

}
