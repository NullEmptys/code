//package com.hoolai.sangoh5.bo.award;
//
//public class EquipAward extends Award {
//
//	protected int equipId;
//	
//	
//	public EquipAward(int xmlId, int num) {
//		super(xmlId, num);
//	}
//	
//	public EquipAward(int xmlId, int num ,AwardType type) {
//		super(xmlId, num);
//		this.awardType = type;
//	}
//	
//	
//
//	public int getEquipId() {
//		return equipId;
//	}
//
//	public void setEquipId(int equipId) {
//		this.equipId = equipId;
//	}
//
//	
//
//}
