package com.hoolai.sangoh5.bo.pve;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.HeroBarrierProto;
import com.hoolai.sangoh5.bo.pve.data.PveData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class HeroBarrier implements ProtobufSerializable<HeroBarrierProto> {

    //	public static final int DAY_LIMIT = 10;

    private int dayLimit;

    private int maxStarNum;

    private int boxState;// 0未获得、1获得未领取、2已领取

    private int attackNum;

    private int barrierId;

    private int sweepNum;//扫荡次数

    private int buySweepNum;//购买的扫荡次数

    private int first3StarDieSolNum;// 第一次达到3星死亡的士兵数量，用于扫荡扣兵用

    transient private long userId;

    public HeroBarrier() {
    }

    public HeroBarrier(int barrierId, PveData pveData) {
        this.barrierId = barrierId;
        if (pveData != null && pveData.getProperty(barrierId) != null) {
            this.dayLimit = pveData.getProperty(barrierId).getTimes();
        }
    }

    public HeroBarrier(HeroBarrierProto message, long userId, PveData pveData) {
        copyFrom(message);
        this.userId = userId;
        if (pveData != null && pveData.getProperty(barrierId) != null) {
            this.dayLimit = pveData.getProperty(barrierId).getTimes();
        }
    }

    public void setUpMaxStarNum(int maxStarNum, int soldierNum) {
        if (maxStarNum == 3) {
            first3StarDieSolNum = Math.max(1, first3StarDieSolNum == 0 ? soldierNum : Math.min(this.first3StarDieSolNum, soldierNum));
        }
        this.maxStarNum = Math.max(this.maxStarNum, maxStarNum);
    }

    public int getAttackNum() {
        return attackNum;
    }

    public void setAttackNum(int attackNum) {
        this.attackNum = attackNum;
    }

    public int getBarrierId() {
        return barrierId;
    }

    public void setBarrierId(int barrierId) {
        this.barrierId = barrierId;
    }

    public int getMaxStarNum() {
        return maxStarNum;
    }

    public void setMaxStarNum(int maxStarNum) {
        this.maxStarNum = maxStarNum;
    }

    public int getFirst3StarDieSolNum() {
        return first3StarDieSolNum;
    }

    public int getBoxState() {
        return boxState;
    }

    public void setBoxState(int boxState) {
        this.boxState = boxState;
    }

    public int getSweepNum() {
        return sweepNum;
    }

    public void setSweepNum(int sweepNum) {
        this.sweepNum = sweepNum;
    }

    public int getBuySweepNum() {
        return buySweepNum;
    }

    public void setBuySweepNum(int buySweepNum) {
        this.buySweepNum = buySweepNum;
    }

    @Override
    public HeroBarrierProto copyTo() {
        HeroBarrierProto.Builder builder = HeroBarrierProto.newBuilder();
        builder.setAttackNum(attackNum);
        builder.setBarrierId(barrierId);
        builder.setMaxStarNum(maxStarNum);
        builder.setBoxState(boxState);
        builder.setSweepNum(sweepNum);
        builder.setBuySweepNum(buySweepNum);
        builder.setFirst3StarDieSolNum(first3StarDieSolNum);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            HeroBarrierProto message = HeroBarrierProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(HeroBarrierProto message) {
        this.attackNum = message.getAttackNum();
        this.barrierId = message.getBarrierId();
        this.maxStarNum = message.getMaxStarNum();
        this.boxState = message.getBoxState();
        this.sweepNum = message.getSweepNum();
        this.buySweepNum = message.getBuySweepNum();
        this.first3StarDieSolNum = message.getFirst3StarDieSolNum();
    }

    public void checkNum(int extraAddNum) {
        if (this.attackNum >= dayLimit + extraAddNum) {
            throw new BusinessException(ErrorCode.TODAY_REACH_MAX);
        }
    }

    public void checkNum(int extraAddNum, int sweepNum) {
        if (this.attackNum + sweepNum > dayLimit + extraAddNum) {
            throw new BusinessException(ErrorCode.TODAY_REACH_MAX);
        }
    }

    public void addAttackNum() {
        this.attackNum += 1;
    }

    public void clearAttackNum() {
        attackNum = 0;
        sweepNum = 0;
        buySweepNum = 0;
    }

    public int getDayLimit() {
        return dayLimit;
    }

}
