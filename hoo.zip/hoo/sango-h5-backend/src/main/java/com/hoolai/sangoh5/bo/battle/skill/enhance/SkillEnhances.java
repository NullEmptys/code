package com.hoolai.sangoh5.bo.battle.skill.enhance;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * FightUnit的士兵科技集合封装类，目前仅士兵单元用到，将领单元也有，但是没用到
 *
 */
public class SkillEnhances {

    protected static final Logger log = Logger.getLogger(SkillEnhances.class);

    /** 每种士兵单元的士兵科技map */
    private Map<String, SkillEnhance> skillEnhances = new ConcurrentHashMap<String, SkillEnhance>();

    /**
     * 执行攻击技能，如果是士兵单元的话，除了执行skill外，还遍历去执行enhances下的士兵技能
     * 
     * @param skill
     * @param actor
     * @param tc
     * @param currentLevel TODO
     * @return
     */
    public List<FightUnit> execute(IndependentSkill skill, FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = skill.execute(actor, tc, currentLevel);
        //        if(targets!= null && targets.size() > 0 && skillEnhances != null && skillEnhances.size() > 0){
        //        	for (String key : skillEnhances.keySet()) {
        //                   targets.addAll(skillEnhances.get(key).execute(skillEnhances, skill, actor, tc));
        //               }
        //        }
        return targets;
    }

    public void remove(String name) {
        skillEnhances.remove(name);
    }

    public SkillEnhance getEnhance(String name) {
        return skillEnhances.get(name);
    }

    /**
     * 仅仅能加入一次的SkillEnhance
     * 
     * @param name
     * @param enhance
     * @return
     */
    public SkillEnhances putEnhance(String name, SkillEnhance enhance) {
        if (null == skillEnhances.get(name)) {
            skillEnhances.put(name, enhance);
            return this;
        }
        return this;
    }

    public void defence(DefenceSkill defenceSkill, FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets) {
        defenceSkill.defence(actor, target, effect, buff, tc, targets, Action.DEFAULT_ACTION_LEVEL);//默认防御
    }

}
