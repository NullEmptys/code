package com.hoolai.sangoh5.bo.battle.skill.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.battle.BattleObjFoctory;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.ForceDirection;
import com.hoolai.sangoh5.bo.battle.skill.ForceType;
import com.hoolai.sangoh5.bo.battle.skill.ForceUnitType;
import com.hoolai.sangoh5.bo.battle.skill.Occasion;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.SkillType;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.DefencePassiveSkill;
import com.hoolai.sangoh5.bo.battle.skill.passive.AttributeEnhanceSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.util.ProbabilityGenerator;
import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.IntHashMap;

@Component
public class SkillData extends JsonData<SkillProperty> {

    //	private static final IntHashMap<int[]> levelMap = new IntHashMap<int[]>();
    private static final IntHashMap<Skill> skillsMap = new IntHashMap<Skill>();

    private static final IntHashMap<Skill> officerSkillMap = new IntHashMap<Skill>();

    private static final IntHashMap<Skill> soldierSkillMap = new IntHashMap<Skill>();

    private static final IntHashMap<List<SkillProperty>> qualtitySkillMap = new IntHashMap<List<SkillProperty>>();

    @Autowired
    private ProbabilityGenerator pg;

    @Autowired
    private BattleObjFoctory battleObjFoctory;

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/skills.json", SkillProperty.class);
            initData("com/hoolai/sangoh5/soldierSkills.json", SkillProperty.class);
            initLevelMap();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initSkills(SkillProperty property) {
        int skillXmlId = property.getId();
        int skillId = property.getSkillId();
        SkillType skillType = SkillType.valueOf(property.getType().toUpperCase());
        Skill skill = skillType.newInstance(skillId);

        if (skill == null) {
            throw new IllegalArgumentException("没有的技能就别配到xml里面xmlId:" + skillXmlId + ",skillId:" + skillId);
        }

        skill.setXmlId(skillXmlId);
        skill.setSkillId(skillId);
        skill.setLevel(property.getLevel());
        skill.setOccasion(Occasion.valueOf(property.getOccasion().toUpperCase()));
        skill.setForceType(ForceType.valueOf(property.getForce().toUpperCase()));
        skill.setAttributeType(AttributeType.valueOf(property.getAttribute().toUpperCase()));
        skill.setForceUnitType(ForceUnitType.valueOf(property.getUnit().toUpperCase()));
        skill.setPercentage(property.getPercentage() / 100f);
        skill.setValue(property.getValue());
        skill.setSkillType(skillType);
        skill.setChance(property.getChance());
        skill.setName(property.getName());
        skill.setRound((int) (property.getRound() / FightUnit.ROUND_SPEND));
        //        skill.setForceCore(ForceCore.convert(property.getCore()));
        skill.setRange(property.getRange());
        skill.setForceDirection(ForceDirection.convert(property.getDirection()));
        skill.setRepeatCount((int) (property.getRepeat() / FightUnit.ROUND_SPEND));
        skill.setName(property.getName());
        skill.setTwoImpactId(property.getTwoImpactId());
        skill.setSubType(property.getSubType());

        skill.setRestraintFinder(battleObjFoctory.newRestraintFinder());
        skill.setPg(pg);
        skill.setAttackUnitType(ForceUnitType.valueOf(property.getCaster().toUpperCase()));

        if ("officer".equals(property.getCaster())) {
            if (qualtitySkillMap.containsKey(property.getBorderColor())) {
                qualtitySkillMap.get(property.getBorderColor()).add(property);
            } else {
                List<SkillProperty> skillPropertyList = new ArrayList<>();
                skillPropertyList.add(property);
                qualtitySkillMap.put(property.getBorderColor(), skillPropertyList);
            }
            skill.setTwoAttribute(AttributeType.valueOf(property.getTwoAttribute().toUpperCase()));
            skill.setTwoPercentage(property.getTwoPercentage() / 100f);
            skill.setTwoRepeatCount((int) (property.getTwoRepeat() / FightUnit.ROUND_SPEND));
            skill.setTwoValue(property.getTwoValue());

            officerSkillMap.put(skillXmlId, skill);
        } else if ("soldier".equals(property.getCaster())) {
            skill.setUser(1);
            soldierSkillMap.put(skillXmlId, skill);
        }

        skillsMap.put(skillXmlId, skill);
    }

    private void initLevelMap() {
        for (SkillProperty property : propertyMap.values()) {
            initSkills(property);
        }
    }

    /**
     * 查找技能，可进行修改，因为其实是查找后再返回clone的一份
     * 
     * @param xmlId
     * @return
     */
    public Skill findSkill(int xmlId) {
        Skill skill = skillsMap.get(xmlId);
        if (skill == null) {
            return null;
        }
        Skill clone = skill.clone();
        clone.setRestraintFinder(battleObjFoctory.newRestraintFinder());
        clone.setProbabilityGenerator(pg);
        return clone;
    }

    public List<AttributeEnhanceSkill> findPassiveSkills(int[] xmlIds, List<Skill> battleEnhaceSkills, List<Skill> otherEnhaceSkills) {
        List<AttributeEnhanceSkill> skills = new ArrayList<AttributeEnhanceSkill>();
        for (Integer xmlId : xmlIds) {
            Skill skill = findSkill(xmlId);
            if (skill instanceof AttributeEnhanceSkill) {
                skills.add((AttributeEnhanceSkill) skill);
            }
        }

        if (battleEnhaceSkills != null && battleEnhaceSkills.size() > 0) {
            for (Skill skill : battleEnhaceSkills) {
                if (skill instanceof AttributeEnhanceSkill) {
                    skills.add((AttributeEnhanceSkill) skill);
                }
            }
        }
        if (otherEnhaceSkills != null && otherEnhaceSkills.size() > 0) {
            for (Skill skill : otherEnhaceSkills) {
                if (skill instanceof AttributeEnhanceSkill) {
                    skills.add((AttributeEnhanceSkill) skill);
                }
            }
        }
        return skills;
    }

    public List<Skill> findActiveSkills(int[] xmlIds, List<Skill> battleEnhaceSkills, List<Skill> otherEnhaceSkills) {
        List<Skill> skills = new ArrayList<Skill>(xmlIds.length);
        for (Integer xmlId : xmlIds) {
            Skill skill = findSkill(xmlId);
            if (skill instanceof IndependentSkill || skill instanceof DefenceSkill) {
                skills.add(skill);
            }
        }
        if (battleEnhaceSkills != null && battleEnhaceSkills.size() > 0) {
            for (Skill skill : battleEnhaceSkills) {
                if (skill instanceof IndependentSkill || skill instanceof DefenceSkill) {
                    skills.add(skill);
                }
            }
        }
        if (otherEnhaceSkills != null && otherEnhaceSkills.size() > 0) {
            for (Skill skill : otherEnhaceSkills) {
                if (skill instanceof IndependentSkill || skill instanceof DefenceSkill) {
                    skills.add(skill);
                }
            }
        }
        return skills;
    }

    public List<DefencePassiveSkill> findCounterAttackSkills(int[] xmlIds, List<Skill> battleEnhaceSkills, List<Skill> otherEnhaceSkills) {
        List<DefencePassiveSkill> skills = new ArrayList<DefencePassiveSkill>(xmlIds.length);
        for (Integer xmlId : xmlIds) {
            Skill skill = findSkill(xmlId);
            if (skill instanceof DefencePassiveSkill) {
                skills.add((DefencePassiveSkill) skill);
            }
        }
        if (battleEnhaceSkills != null && battleEnhaceSkills.size() > 0) {
            for (Skill skill : battleEnhaceSkills) {
                if (skill instanceof DefencePassiveSkill) {
                    skills.add((DefencePassiveSkill) skill);
                }
            }
        }
        if (otherEnhaceSkills != null && otherEnhaceSkills.size() > 0) {
            for (Skill skill : otherEnhaceSkills) {
                if (skill instanceof DefencePassiveSkill) {
                    skills.add((DefencePassiveSkill) skill);
                }
            }
        }
        return skills;
    }

    @Override
    protected void checkProperty(SkillProperty property) {

    }

    public static IntHashMap<Skill> getOfficerskillmap() {
        return officerSkillMap;
    }

    public static IntHashMap<Skill> getSoldierskillmap() {
        return soldierSkillMap;
    }

    public static List<SkillProperty> getQualtityskillmap(int quantity) {
        return qualtitySkillMap.get(quantity);
    }

    public int[] getOfficeSkill() {
        int[] ids = new int[officerSkillMap.values().size()];
        int i = 0;
        for (Skill skill : officerSkillMap.values()) {
            ids[i++] = skill.getSkillId();
        }
        return ids;
    }
}
