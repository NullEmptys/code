package com.hoolai.sangoh5.bo.user;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.util.Constant;

public abstract class LoginProcessor {

    public abstract User login();

    public static LoginProcessor getProcessor(String requestInfoStr, BoFactory boFactory) {
        switch (Constant.PLATFORM_NAME) {
            case "gamegold":
                return new GameGoldUserLoginProcessor(requestInfoStr, boFactory);
            case "wanba_ts":
                return boFactory.createWanBaUserLoginProcessor(requestInfoStr);
            case "wechat":
                return new WechatLoginProcessor(requestInfoStr, boFactory);
            default:
                return boFactory.createUserLoginProcessor(requestInfoStr);
        }
    }
}
