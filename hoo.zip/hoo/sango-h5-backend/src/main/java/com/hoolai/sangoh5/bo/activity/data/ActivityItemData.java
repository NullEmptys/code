package com.hoolai.sangoh5.bo.activity.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-16 10:54
 * @version : 1.0
 */
@Component
public class ActivityItemData extends JsonData<ActivityItemProperty> {

    @PostConstruct
    @Override
    public void init() {
        try {
            initData("com/hoolai/sangoh5/activityItem.json", ActivityItemProperty.class);
        } catch (IOException e) {
            logger.error(e);
        }
    }

    @Override
    protected void checkProperty(ActivityItemProperty property) {
        property.checkAndInit();
    }

}
