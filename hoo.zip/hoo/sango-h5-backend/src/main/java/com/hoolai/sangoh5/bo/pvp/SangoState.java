package com.hoolai.sangoh5.bo.pvp;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;

import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.SangoStateProto;
import com.hoolai.sangoh5.util.Utils;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.schooner.MemCached.MemcachedItem;

/**
 * 州县
 * 记录州县被其他州县占领数量
 * 
 * @author LiQing
 *
 */
public class SangoState implements ProtobufSerializable<SangoStateProto>, Comparable<SangoState> {

    /** 州ID */
    private int stateId;

    /** 州原始国土面积 */
    private int landArea;

    /** 与此州同一势力的州 */
    private int[] firendState;

    /** 上周排名 */
    private int lastWeekRank;

    /** 国土侵占计数 侵占A，就A+1 被A侵占，就A-1 */
    private Map<Integer, Integer> stateOccupyNumMap = new HashMap<Integer, Integer>();

    transient private int updateState;

    transient private int updateArea;

    transient MemcachedItem item;

    public SangoState() {
    }

    public SangoState(int stateId) {
        this.stateId = stateId;
    }

    public SangoState(int stateId, int landArea, int[] firendState) {
        this.firendState = firendState;
        this.stateId = stateId;
        this.landArea = landArea;
    }

    public SangoState(MemcachedItem item) {
        this.item = item;
        parseFrom((byte[]) item.getValue());
    }

    public float getLandAreaPer() {
        //        Math.round(((Float.valueOf(getCurrLandArea()) * 100f) / Float.valueOf(landArea))) / 100f;
        return Utils.calculationLandArea(getCurrLandArea(), landArea);
    }

    public int getCurrLandArea() {
        int num = 0;
        for (int i = 1; i <= 9; i++) {
            if (!ArrayUtils.contains(firendState, i)) {
                Integer inte = stateOccupyNumMap.get(i);
                num += inte == null ? 0 : inte.intValue();
            }
        }
        return num;
    }

    public int findLandArea() {
        return landArea + getCurrLandArea();
    }

    public void reflesh(int landArea, int[] firendState) {
        this.landArea = landArea;
        this.firendState = firendState;
    }

    public void update(int stateId, int area) {
        Integer inte = stateOccupyNumMap.get(stateId);
        if (inte == null) {
            inte = 0;
        }

        stateOccupyNumMap.put(stateId, inte.intValue() + area);

        updateArea = area;
        updateState = stateId;
    }

    public int getStateId() {
        return stateId;
    }

    public int getLandArea() {
        return landArea;
    }

    public int[] getFirendState() {
        return firendState;
    }

    public Map<Integer, Integer> getStateOccupyNumMap() {
        return stateOccupyNumMap;
    }

    public MemcachedItem getItem() {
        return item;
    }

    public int getLastWeekRank() {
        return lastWeekRank;
    }

    public void setLastWeekRank(int lastWeekRank) {
        this.lastWeekRank = lastWeekRank;
    }

    @Override
    public SangoStateProto copyTo() {
        SangoStateProto.Builder builder = SangoStateProto.newBuilder();
        builder.setStateId(stateId);
        builder.setLandArea(landArea);
        builder.setLastWeekRank(lastWeekRank);

        for (int state : firendState) {
            builder.addFirendState(state);
        }

        Set<Integer> keyset = stateOccupyNumMap.keySet();
        for (int key : keyset) {
            builder.addStateOccupyNumKey(key);
            builder.addStateOccupyNumValue(stateOccupyNumMap.get(key));
        }

        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            SangoStateProto message = SangoStateProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(SangoStateProto message) {
        this.stateId = message.getStateId();
        this.landArea = message.getLandArea();
        this.lastWeekRank = message.getLastWeekRank();

        int count = message.getFirendStateCount();
        this.firendState = new int[count];
        for (int i = 0; i < count; i++) {
            firendState[i] = message.getFirendState(i);
        }

        count = message.getStateOccupyNumKeyCount();
        this.stateOccupyNumMap = Maps.newHashMapWithExpectedSize(count);
        for (int i = 0; i < count; i++) {
            stateOccupyNumMap.put(message.getStateOccupyNumKey(i), message.getStateOccupyNumValue(i));
        }
    }

    public void resolveConflict(SangoState current) {
        Integer inte = current.getStateOccupyNumMap().get(updateState);
        if (inte == null) {
            inte = 0;
        }
        current.getStateOccupyNumMap().put(updateState, inte + updateArea);
    }

    @Override
    public int compareTo(SangoState compareSangoState) {
        if (compareSangoState.getCurrLandArea() > this.getCurrLandArea()) {
            return 1;
        }
        return 0;
    }

}
