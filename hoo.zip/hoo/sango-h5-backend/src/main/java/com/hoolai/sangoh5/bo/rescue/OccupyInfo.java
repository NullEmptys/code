package com.hoolai.sangoh5.bo.rescue;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.PvpOccupyProto;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 占领(其他玩家城池)的玩家信息(占领者信息)
 * 
 * @author Administrator
 *
 */
public class OccupyInfo implements ProtobufSerializable<PvpOccupyProto> {

    private int officerId;// 占领者将领id

    private long userId;// 被占领者id

    private long occupyId;// 占领者id

    private long occupyStartTime;// 占领时间

    private int rank;

    public OccupyInfo() {

    }

    public OccupyInfo(PvpOccupyProto message) {
        copyFrom(message);
    }

    public OccupyInfo(int officerId, long userId, long occupyId, long occupyStartTime, int rank) {
        super();
        this.officerId = officerId;
        this.userId = userId;
        this.occupyId = occupyId;
        this.occupyStartTime = occupyStartTime;
        this.rank = rank;

    }

    public OccupyInfo(byte[] bytes) {
        this.parseFrom(bytes);
    }

    public int getOfficerId() {
        return officerId;
    }

    public void setOfficerId(int officerId) {
        this.officerId = officerId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getOccupyId() {
        return occupyId;
    }

    public void setOccupyId(long occupyId) {
        this.occupyId = occupyId;
    }

    public long getOccupyStartTime() {
        return occupyStartTime;
    }

    public void setOccupyStartTime(long occupyStartTime) {
        this.occupyStartTime = occupyStartTime;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    @Override
    public PvpOccupyProto copyTo() {
        PvpOccupyProto.Builder builder = PvpOccupyProto.newBuilder();
        builder.setOfficerId(this.officerId);
        builder.setUserId(this.userId);
        builder.setOccupyId(this.occupyId);
        builder.setOccupyStartTime(this.occupyStartTime);
        builder.setRank(this.rank);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            PvpOccupyProto message = PvpOccupyProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }

    }

    @Override
    public void copyFrom(PvpOccupyProto message) {
        this.officerId = message.getOfficerId();
        this.userId = message.getUserId();
        this.occupyId = message.getOccupyId();
        this.occupyStartTime = message.getOccupyStartTime();
        this.rank = message.getRank();
    }

    public OccupyObj transform(User user, Officer officer) {
        OccupyObj obj = new OccupyObj();
        obj.setOccupyId(occupyId);
        if (occupyId > 0) {
            if (user != null) {
                obj.setUserName(user.getName());
                obj.setLevel(user.getRank());
            }
            obj.setOfferId(officer.getXmlId());
            // 方便测试不够1天按1天算，暂时去掉时间限制
            obj.setOccupyTime(Utils.getOccupyDays(TimeUtil.currentTimeMillis() - occupyStartTime) == 0 ? 1 : Utils.getOccupyDays(TimeUtil.currentTimeMillis() - occupyStartTime));
            obj.setBeRescueUserId(userId);
        }
        return obj;
    }

}
