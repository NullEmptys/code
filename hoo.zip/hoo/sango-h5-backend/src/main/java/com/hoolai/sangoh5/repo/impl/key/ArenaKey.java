package com.hoolai.sangoh5.repo.impl.key;

import java.util.concurrent.TimeUnit;

import com.hoolai.sangoh5.util.Constant;

public class ArenaKey {
	
	private static final String prefix= "are";

	public static final long LOCK_USER_EXPTIME = TimeUnit.MINUTES.toMillis(1);
	public static final int SCORE_INTERVAL = 50;
	
    public static String getServerArenaOfficerKey(int xmlId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(xmlId).append(Constant.separator).append("osid").toString();
    }

	public static String getDeterentRankingTotalNumKey() {
		return new StringBuilder().append(prefix).append(Constant.separator).append("dertn").toString();
	}

	public static String getRankingListIdsKey(long currentNum) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(currentNum).append(Constant.separator).append("rlids").toString();
	}

	public static String getLockArenaUserKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("arlkuid").toString();
	}

	public static String getArenaScoreUserKey(int page) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(page).append(Constant.separator).append("asu").toString();
	}

	public static String getLockArenaSortRankingKey(long hour) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(hour).append(Constant.separator).append("arlksr").toString();
	}

	public static String getArenaUserKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("aruid").toString();
	}

	public static String getArenaOfficersKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("aroids").toString();
	}

	public static String getRankArenaOfficersKey(int xmlId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(xmlId).append(Constant.separator).append("raok").toString();
	}

}
