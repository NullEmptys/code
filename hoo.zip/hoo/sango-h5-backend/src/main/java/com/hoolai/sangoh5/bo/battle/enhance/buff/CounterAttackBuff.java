package com.hoolai.sangoh5.bo.battle.enhance.buff;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.DefencePassiveSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 
 */
public class CounterAttackBuff extends Buff {

    private DefencePassiveSkill skill;

    @Override
    public void apply(FightUnit target) {
        this.result();
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        alive.removeCounterAttackSkills(skill);
        alive.addBattleLog(alive.name() + "" + skill.getXmlId() + "[" + this.skillName + "]反击技能结束");
    }

    @Override
    protected CounterAttackBuff clone() {
        CounterAttackBuff buff = (CounterAttackBuff) super.clone(new CounterAttackBuff(targetUsedSkillXmlId, executeName, skill, currentLevel));
        return buff;
    }

    public CounterAttackBuff(int targetUsedSkillXmlId, FightUnitName executeName, DefencePassiveSkill skill, int currentLevel) {
        super(targetUsedSkillXmlId, skill.getName(), executeName, currentLevel);
        this.skill = skill;
    }

}
