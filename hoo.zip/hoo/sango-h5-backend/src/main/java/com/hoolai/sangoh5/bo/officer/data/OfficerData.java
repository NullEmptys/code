package com.hoolai.sangoh5.bo.officer.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;


@Component
public class OfficerData extends JsonData<OfficerProperty>{

//	private static final IntHashMap<int[]> LEVEL_ALL_MAP = new IntHashMap<int[]>();
//	private static final IntHashMap<int[]> LEVEL_CAN_RECRUIT_MAP = new IntHashMap<int[]>();
	
	@PostConstruct
    public void init(){
    	try {
    		initData("com/hoolai/sangoh5/officer.json", OfficerProperty.class);
//    		initLevelMap();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
	
/*	private void initLevelMap() {
		List<Integer> l1 = new ArrayList<Integer>();
		List<Integer> l2 = new ArrayList<Integer>();
		List<Integer> l3 = new ArrayList<Integer>();
		List<Integer> l4 = new ArrayList<Integer>();
		List<Integer> l5 = new ArrayList<Integer>();
		
		List<Integer> lr1 = new ArrayList<Integer>();
		List<Integer> lr2 = new ArrayList<Integer>();
		List<Integer> lr3 = new ArrayList<Integer>();
		List<Integer> lr4 = new ArrayList<Integer>();
		List<Integer> lr5 = new ArrayList<Integer>();
		for(OfficerProperty property:propertyMap.values()){
			switch (property.getGeneralRank()) {
			case 1:
				l1.add(property.getId());
				if(property.getOnRecruit() == 1){
					lr1.add(property.getId());
				}
				break;
			case 2:
				l2.add(property.getId());
				if(property.getOnRecruit() == 1){
					lr2.add(property.getId());
				}
				break;
			case 3:
				l3.add(property.getId());
				if(property.getOnRecruit() == 1){
					lr3.add(property.getId());
				}
				break;
			case 4:
				l4.add(property.getId());
				if(property.getOnRecruit() == 1){
					lr4.add(property.getId());
				}
				break;
			case 5:
				l5.add(property.getId());
				if(property.getOnRecruit() == 1){
					lr5.add(property.getId());
				}
				break;
			default:
				throw new BusinessException(ErrorCode.STATUS_ERROR, "no this officer level");
			}
		}
		
		LEVEL_ALL_MAP.put(1, toArray(l1));
		LEVEL_ALL_MAP.put(2, toArray(l2));
		LEVEL_ALL_MAP.put(3, toArray(l3));
		LEVEL_ALL_MAP.put(4, toArray(l4));
		LEVEL_ALL_MAP.put(5, toArray(l5));
		
//		if(!Constant.isLocalPlatform()){
		if(lr1.size() < 5 || lr2.size() < 5 || lr3.size() < 5 || lr4.size() < 5 || lr5.size() < 5 ){
//			throw new BusinessException(ErrorCode.STATUS_ERROR, "可招募的将领数量不够:lv1="+lr1.size()+",lv2="+lr2.size()
//					+",lv3="+lr3.size()+",lv4="+lr4.size()+",lv5="+lr5.size());
		}
//		}
		
		LEVEL_CAN_RECRUIT_MAP.put(1, toArray(lr1));
		LEVEL_CAN_RECRUIT_MAP.put(2, toArray(lr2));
		LEVEL_CAN_RECRUIT_MAP.put(3, toArray(lr3));
		LEVEL_CAN_RECRUIT_MAP.put(4, toArray(lr4));
		LEVEL_CAN_RECRUIT_MAP.put(5, toArray(lr5));
	}
	
	public int randomOfficer(int level){
		int ids[] = LEVEL_CAN_RECRUIT_MAP.get(level);
		int id = ids[Constant.pg.getRandomNumber(0,ids.length-1)];
//		System.out.println("level:"+level+",id="+id+",ids="+ArrayUtils.toString(ids, ""));
		return id;
	}

	public int[] randomOfficer(int[] levels, int num,boolean isRepeat) {
		
		int[] randomIds = new int[num];
		int index = 0;
		
		for(int level:levels){
			int continueNum = 0;
			int[] ids = LEVEL_CAN_RECRUIT_MAP.get(level);
			int[] newIds = Arrays.copyOf(ids, ids.length);
			do{
				int id = newIds[Constant.pg.getRandomChoice(newIds)];
//				boolean isExist = isExist(randomIds,newIds,id);
				boolean isExist = ArrayUtils.indexOf(randomIds, id) >= 0;
				if(isExist){
					ArrayUtils.removeElement(newIds, id);
				}
				if(!isRepeat && isExist){
					continueNum ++;
				}else{
					randomIds[index++] = id;
					break;
				}
			}while(continueNum<100);
		}
		
//		System.out.println("num:"+num+",levels="+ArrayUtils.toString(levels, "")+",ids="+ArrayUtils.toString(randomIds, ""));
		return randomIds;
	}

	private boolean isExist(int[] a, int[] c, int b) {
		for(int i=0;i<a.length;i++){
			if(a[i] == b) {
				c = arrRemove(c,b);
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @param offLvs
	 * @param existIds 需要不重复的ID
	 * @param needCheckLevel
	 * @param num
	 * @param isRepeat
	 * @return
	 */
/*
	public int[] randomOfficer(int[] offLvs, int[] existIds, int needCheckLevel,int num,boolean isRepeat) {
		
		// 先将已经存在的去掉
		int[] temp = LEVEL_CAN_RECRUIT_MAP.get(needCheckLevel);
		int[] needCheckIds =  Arrays.copyOf(temp,temp.length);
		for(int i=0;i<existIds.length;i++){
			needCheckIds = arrRemove(needCheckIds, existIds[i]);
		}
		
		boolean isNeedCheck = needCheckIds.length == 0 ? false : true;
		int[] randomIds = new int[num];
		int index = 0;
		
		IntHashMap<int[]> tempMap = new IntHashMap<int[]>();//伪随机
		for(int level:offLvs){
			int continueNum = 0;//设置最大循环次数
			int[] newIds = null;
			
			if(level == needCheckLevel){
				if(tempMap.get(level) == null || tempMap.get(level).length < 1){
					if(needCheckIds.length<1){
						newIds = existIds;
					}else{
						newIds = needCheckIds;
					}
					
					tempMap.put(level, newIds);
				}else{
					newIds = tempMap.get(level);
				}
			}else{
				if(isRepeat){
					int[] ids = LEVEL_CAN_RECRUIT_MAP.get(level);
					newIds = Arrays.copyOf(ids, ids.length);
				}else{
					if(tempMap.get(level) == null || tempMap.get(level).length < 1){
						int[] ids = LEVEL_CAN_RECRUIT_MAP.get(level);
						newIds = Arrays.copyOf(ids, ids.length);
						tempMap.put(level, newIds);
					}else{
						newIds = tempMap.get(level);
					}
				}
			}
			
			do{
				int id = newIds[Constant.pg.getRandomNumber(0,newIds.length-1)];
				boolean isExist = false;
				if(isNeedCheck && level == needCheckLevel){
					needCheckIds = arrRemove(needCheckIds, id);
					isNeedCheck = needCheckIds.length != 0;
					if(!isNeedCheck){
						needCheckIds = Arrays.copyOf(existIds,existIds.length);
					}
					tempMap.put(level, needCheckIds);
				}
				isExist = isExist(randomIds,id);
				
				if(!isRepeat && isExist){
					newIds = arrRemove(newIds, id);
					tempMap.put(level, newIds);
					continueNum ++;
				}else{
					randomIds[index++] = id;
					break;
				}
			}while(continueNum<100);
		}
		
		return randomIds;
	}

	public boolean isAllExist(int[] newIds, int level) {
		int[] temp = LEVEL_CAN_RECRUIT_MAP.get(level);
		for(int id:temp){
			if(!isExist(newIds, id)){
				return false;
			}
		}
		return true;
	}*/
	
	public boolean isWenOfficer(int xmlId){
		OfficerProperty property = this.getProperty(xmlId);
		return property.getType() == 1;
	}
	
	public boolean isWuOfficer(int xmlId){
		OfficerProperty property = this.getProperty(xmlId);
		return property.getType() == 0;
	}

	@Override
	protected void initForEach(OfficerProperty property) {
		
	}

	@Override
	protected void checkProperty(OfficerProperty property) {
		// TODO Auto-generated method stub
		
	}
	
//	public static void main(String[] args) {
//		LEVEL_CAN_RECRUIT_MAP.put(2, new int[]{102,202,302,402,502});
//		LEVEL_CAN_RECRUIT_MAP.put(3, new int[]{101,201,301,401,501,601,701,801});
//		int[] os = randomOfficer(new int[]{3,2,3,2,2}, new int[]{102,202,302,502}, 2, 5, false);
//		for(int o:os){
//			System.out.println(o);
//		}
//		
//	}
	
	
}
