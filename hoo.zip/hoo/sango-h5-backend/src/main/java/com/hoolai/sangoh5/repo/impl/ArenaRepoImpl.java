package com.hoolai.sangoh5.repo.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.compass.core.util.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.hoolai.keyvalue.jredis.JRedis;
import com.hoolai.keyvalue.jredis.StorageKeyProtobuf;
import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.protobuf.BytesList;
import com.hoolai.sango.util.NativeCodec;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.arena.ArenaOfficer;
import com.hoolai.sangoh5.bo.arena.ArenaOfficers;
import com.hoolai.sangoh5.bo.arena.ArenaUser;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.repo.ArenaRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.repo.impl.key.ArenaKey;
import com.hoolai.sangoh5.repo.redis.RedisKeyFalg;
import com.hoolai.sangoh5.util.BitConverter;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.schooner.MemCached.MemcachedItem;

@Repository("arenaRepo")
public class ArenaRepoImpl implements ArenaRepo {

    @Autowired
    @Qualifier("itemClient")
    private ExtendedMemcachedClient client;

    @Autowired
    @Qualifier("jRedis")
    private JRedis jRedis;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private BoFactory bofactory;

    @Override
    public ArenaUser findArenaUser(long userId) {
        String key = ArenaKey.getArenaUserKey(userId);
        Object o = client.get(key);
        if (o == null) {
            return null;
        }
        return bofactory.createArenaUserr(userId, (byte[]) o);

    }

    @Override
    public void saveArenaUser(ArenaUser arenaUser) {
        String key = ArenaKey.getArenaUserKey(arenaUser.getUserId());
        client.set(key, arenaUser.toByteArray());
    }

    @Override
    public void addUserScoreToRedis(int userScore, long userId) {
        long timestamp = TimeUtil.currentTimeMillis() / 1000;
        long redisScore = ((userScore & 0xFFFFFFFFL) << 32) | (timestamp & 0xFFFFFFFFL);
        Long m = jRedis.zadd(getArenaUserRankKey(), redisScore, NativeCodec.toBytes(userId));
    }

    @Override
    public Long getRankByUserId(long userId) {
        Long rank = jRedis.zrevrank(getArenaUserRankKey(), NativeCodec.toBytes(userId));
        if (rank == null) {
            return 0l;
        }
        return rank;//数据库中排名从0开始
    }

    @Override
    public List<Long> getUsersByRank(int start, int stop) {
        List<Long> user = new ArrayList<Long>();
        Set<byte[]> zrevrange = jRedis.zrevrange(getArenaUserRankKey(), start, stop);
        for (byte[] bytes : zrevrange) {
            user.add(NativeCodec.toLong(bytes));
        }
        return user;
    }

    @Override
    public void casArenaUser(ArenaUser arenaUser) {
        String key = ArenaKey.getArenaUserKey(arenaUser.getUserId());
        MemcachedItem item = client.gets(key);
        if (item == null) {
            if (client.add(key, arenaUser.toByteArray())) {
                return;
            } else {
                item = client.gets(key);
            }
        }
        for (int i = 0; i < 5; i++) {
            ArenaUser current = new ArenaUser(arenaUser.getUserId(), (byte[]) item.getValue());
            current.setCurrentRank(arenaUser.getCurrentRank());
            if (client.cas(key, current.toByteArray(), item.getCasUnique())) {
                return;
            }
            item = client.gets(key);
        }
    }

    @Override
    public void saveArenaOfficers(ArenaOfficers arenaOfficers) {
        String key = ArenaKey.getArenaOfficersKey(arenaOfficers.getUserId());
        client.set(key, arenaOfficers.toByteArray());
    }

    @Override
    public ArenaOfficers findArenaOfficers(long userId) {
        String key = ArenaKey.getArenaOfficersKey(userId);
        Object o = client.get(key);
        if (o == null) {
            return new ArenaOfficers(userId);
        } else {
            return new ArenaOfficers(userId, (byte[]) o);
        }
    }

    /**
     * 往有序集和中添加officer
     */
    @Override
    public void zaddRankArenaOfficer(long userId, int xmlId, int score) {
        jRedis.zadd(getRankArenaOfficersKey(xmlId), score, NativeCodec.toBytes(userId));
    }

    /**
     * 移除某个排名区间的元素
     */
    @Override
    public boolean zremByRankArenaOfficer(int xmlId, int start, int stop) {
        return jRedis.zremrangeByRank(getRankArenaOfficersKey(xmlId), start, stop) > 0;
    }

    @Override
    public void deleteRankArenaOfficer(int xmlId) {
        String key = ArenaKey.getRankArenaOfficersKey(xmlId);
        client.delete(key);
    }

    @Deprecated
    @Override
    public BytesList getRankArenaOfficers(int xmlId) {
        String key = ArenaKey.getRankArenaOfficersKey(xmlId);
        byte[] datas = (byte[]) client.get(key);
        if (datas == null) {
            return null;
        }
        BytesList userIdList = new BytesList(datas);
        return userIdList;
    }

    /**
     * 查询某个排名区间的用户
     */
    @Override
    public long getRankArenaOfficersTopOne(int xmlId) {
        byte[] key = getRankArenaOfficersKey(xmlId);
        Set<byte[]> userIds = jRedis.zrevrange(key, 0, 0);
        if (CollectionUtils.isEmpty(userIds)) {
            return 0;
        }
        List<Long> ids = new ArrayList<Long>();
        for (byte[] idByte : userIds) {
            ids.add(NativeCodec.toLong(idByte));
        }
        return ids.get(0);
    }

    /**
     * 查询zset中用户总数
     */
    @Override
    public int getRankArenaOfficersCount(int xmlId) {
        byte[] key = getRankArenaOfficersKey(xmlId);
        Long count = jRedis.zcard(key);
        return (int) count.longValue();
    }

    @Override
    public boolean saveServerArenaOfficer(ArenaOfficer arenaOfficer) {
        String key = ArenaKey.getServerArenaOfficerKey(arenaOfficer.getOfficerXmlId());
        MemcachedItem item = client.gets(key);
        if (item == null) {
            if (client.add(key, arenaOfficer.toByteArray())) {
                return true;
            } else {
                item = client.gets(key);
            }
        }
        for (int i = 0; i < 5; i++) {
            ArenaOfficer current = new ArenaOfficer((byte[]) item.getValue());
            if (arenaOfficer.getWinNum() == 0 && arenaOfficer.getLoseNum() == 0) {
                break;
            }
            if (arenaOfficer.isAddWin()) {
                current.addWinNum();
                arenaOfficer.setWinNum(current.getWinNum());
            } else {
                current.addLoseNum();
                arenaOfficer.setLoseNum(current.getLoseNum());
            }

            if (client.cas(key, current.toByteArray(), item.getCasUnique())) {
                return true;
            }
            item = client.gets(key);
        }
        return false;
    }

    @Override
    public ArenaOfficer findServerArenaOfficer(int xmlId) {
        String key = ArenaKey.getServerArenaOfficerKey(xmlId);
        Object o = client.get(key);
        if (o == null) {
            return new ArenaOfficer(xmlId);
        }
        return new ArenaOfficer((byte[]) o);
    }

    @Override
    public long findSortListTotalPageNum() {
        String identityTotalNumKey = ArenaKey.getDeterentRankingTotalNumKey();
        Object totalNumStr = this.client.get(identityTotalNumKey);
        if (totalNumStr == null) {
            return 0;
        }
        long totalNum = Long.parseLong(totalNumStr.toString());
        return calRangeCurrentSortList(totalNum);
    }

    public List<Long> getSortList(long pageNum) {
        String identityRangeListKey = ArenaKey.getRankingListIdsKey(pageNum);
        byte[] datas = (byte[]) client.get(identityRangeListKey);
        if (datas == null) {
            return Collections.emptyList();
        }
        BytesList userIdList = new BytesList(datas);
        List<Long> userIds = new ArrayList<Long>();
        for (byte[] idByte : userIdList) {
            userIds.add(BitConverter.bytes2long(idByte, 0));
        }
        return userIds;
    }

    @Override
    public List<ArenaUser> findRankSortList(long pageNum) {
        List<Long> userIds = getSortList(pageNum);
        if (userIds.isEmpty()) {
            return Collections.emptyList();
        }

        Map<Long, User> userMap = userRepo.findUsers(userIds);

        List<ArenaUser> rankSortList = new ArrayList<ArenaUser>();
        int len = userIds.size();
        String[] keys = new String[len];
        for (int i = 0; i < len; i++) {
            long userId = userIds.get(i);
            keys[i] = ArenaKey.getArenaUserKey(userId);
        }

        String regEx = "[^0-9]";
        Pattern p = Pattern.compile(regEx);

        Map<String, Object> keyValueMap = client.mget(keys);
        for (String key : keyValueMap.keySet()) {
            Matcher m = p.matcher(key);
            String userIdStr = m.replaceAll("").trim();
            long userId = Long.valueOf(userIdStr.substring(0, userIdStr.length()));
            User user = userMap.get(userId);
            rankSortList.add(new ArenaUser(userId, user.getName(), (byte[]) keyValueMap.get(key)));
        }

        return rankSortList;
    }

    private User findUser(long userId, List<User> users) {
        for (User user : users) {
            if (user.getId() == userId) {
                return user;
            }
        }
        return null;
    }

    /**
     * 根据排行榜总页数来生成分页
     * 
     * @param totalNum
     * @return
     */
    private long calRangeCurrentSortList(long totalNum) {
        long ret = 0;
        ret = (totalNum / 2000) + 1;
        return ret;
    }

    @Override
    public boolean lockArenaSortRanking(long hour) {
        String key = ArenaKey.getLockArenaSortRankingKey(hour);
        return client.lock(key);
    }

    @Override
    public void unLockArenaSortRanking(long hour) {
        client.unlock(ArenaKey.getLockArenaSortRankingKey(hour));
    }

    @Override
    public boolean lockArenaUser(long userId) {
        String key = ArenaKey.getLockArenaUserKey(userId);
        boolean lock = client.lock(key, ArenaKey.LOCK_USER_EXPTIME);
        if (!lock) {
            throw new BusinessException(ErrorCode.ARENA_USER_OPERATED);
        }
        return lock;
    }

    @Override
    public void unLockArenaUser(long userId) {
        client.unlock(ArenaKey.getLockArenaUserKey(userId));
    }

    private byte[] getArenaUserRankKey() {
        return StorageKeyProtobuf.getByteArray(RedisKeyFalg.ARENA_USER_KEY, RedisKeyFalg.ARENA_USER_KEY, RedisKeyFalg.ARENA_USER_KEY);
    }

    private byte[] getRankArenaOfficersKey(int xmlId) {
        return StorageKeyProtobuf.getByteArray(RedisKeyFalg.RANK_OFFICER_KEY, xmlId, RedisKeyFalg.RANK_OFFICER_KEY);
    }

}
