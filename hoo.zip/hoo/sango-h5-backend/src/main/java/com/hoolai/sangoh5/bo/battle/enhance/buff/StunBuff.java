package com.hoolai.sangoh5.bo.battle.enhance.buff;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 *
 */
public class StunBuff extends Buff {

    @Override
    public void apply(FightUnit target) {
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        alive.unsilence();
        alive.addBattleLog(targetUsedSkillXmlId + "[" + skillName + "]" + alive.name() + "静默效果结束");
    }

    @Override
    protected StunBuff clone() {
        StunBuff buff = (StunBuff) super.clone(new StunBuff(this.targetUsedSkillXmlId, skillName, executeName, isForFront, currentLevel));
        return buff;
    }

    public StunBuff(int targetUsedSkillXmlId, String skillName, FightUnitName executeName, boolean is4front, int currentLevel) {
        super(targetUsedSkillXmlId, skillName, executeName, currentLevel);
        this.isForFront = is4front;
    }

}
