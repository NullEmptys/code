package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class FriendKey {

	private static final String prefix= "fri";

	public static String getUserFriendIdsKey(long userId, int platformType) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("friuf").toString();
	}

	public static String getUserFriendsMaxCountKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("friuc").toString();
	}

	public static String getGameFriendIdsKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("friug").toString();
	}

	public static String getApplyFriendsKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("friua").toString();
	}

	public static String getSendFriendsKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("frisf").toString();
	}
}
