package com.hoolai.sangoh5.bo.adddesktopstatus;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.AddDesktopStatusProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class AddDesktopStatus implements ProtobufSerializable<AddDesktopStatusProto>{

	private long userId;
	
	private int addDesktopStatus;//0为未过硬性引导，1为强弹，2为已添加未领奖，3为已领奖，4为已过强弹时间
	
	private long time;//过硬性引导时间
	
	/**
	 * 开始强弹
	 */
	public void beginBomb(){
		if(addDesktopStatus == 0){
			addDesktopStatus = 1;
		}
		if(time == 0){
			time = TimeUtil.currentTimeMillis();
		}
	}
	
	public AddDesktopStatus() {
    }

    public AddDesktopStatus(long userId) {
        this.userId = userId;
    }

    public AddDesktopStatus(long userId, byte[] bytes) {
        this(userId);
        parseFrom(bytes);
    }

	public int getAddDesktopStatus() {
		return addDesktopStatus;
	}

	public void setAddDesktopStatus(int addDesktopStatus) {
		this.addDesktopStatus = addDesktopStatus;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	@Override
	public AddDesktopStatusProto copyTo() {
		AddDesktopStatusProto.Builder builder = AddDesktopStatusProto.newBuilder();
        builder.setAddDesktopStatus(addDesktopStatus);
        builder.setTime(time);
        return builder.build();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			AddDesktopStatusProto message = AddDesktopStatusProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
	}

	@Override
	public void copyFrom(AddDesktopStatusProto message) {
		this.addDesktopStatus = message.getAddDesktopStatus();
        this.time = message.getTime();
	}

	private void checkCanReward() {
		if(addDesktopStatus == 3){
			throw new BusinessException(ErrorCode.EXCE_MISSION_IS_REWARDED);
		}
	}

	public void addReward() {
		checkCanReward();
		addDesktopStatus = 3;
	}
	
	public void addDesktop() {
		if(addDesktopStatus != 3){
			addDesktopStatus = 2;
		}
	}
}
