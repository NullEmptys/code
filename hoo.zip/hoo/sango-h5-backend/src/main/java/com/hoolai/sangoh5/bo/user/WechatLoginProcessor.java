package com.hoolai.sangoh5.bo.user;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.compass.core.util.Assert;

import com.hoolai.keyvalue.jredis.JRedis;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.repo.JdbcSqlRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.operation.TokenProducer;
import com.hoolai.util.JSONUtils;

public class WechatLoginProcessor extends LoginProcessor {

    private static final Log logger = LogFactory.getLog(GameGoldUserLoginProcessor.class);

    private final String requestInfoStr;

    private final UserRepo userRepo;

    private User user;

    private final BoFactory boFactory;

    private final JdbcSqlRepo jdbcSqlRepo;

    private long userId;

    private final JRedis jedis;

    public WechatLoginProcessor(String requestInfoStr, BoFactory boFactory) {
        this.requestInfoStr = requestInfoStr;
        this.boFactory = boFactory;
        this.userRepo = boFactory.getUserRepo();
        this.jdbcSqlRepo = boFactory.getJdbcSqlRepo();
        this.jedis = boFactory.getjRedis();
    }

    @Override
    public User login() {
        Map<String, Object> userInfo = JSONUtils.fromJSON(requestInfoStr, HashMap.class);

        checkRequestInfo(userInfo.get("openid").toString(), userInfo.get("token").toString());

        String openid = userInfo.get("openid").toString();
        boolean isNewUser = !userRepo.isUserExist(openid);
        if (isNewUser) {
            long userId = userRepo.getUniqueId();
            Assert.isTrue(userRepo.savePlatformId(userId, openid)); // 建立platformID 与  useId的双向索引)

            UserLoginProcessor userLoginProcessor = boFactory.createUserLoginProcessor(requestInfoStr);
            user = userLoginProcessor.initNewUser(userId, openid);
            //            user.setLastSynAt(DateUtil.getTodayIntValue());

            int sex = Integer.parseInt(userInfo.get("sex").toString()) == 1 ? 1 : 0;//平台默认1是男，2为女
            user.setSex(sex);
            try {
                //                String host = new URL(Constant.RESOURCE_URL).getHost();// 获取主机名 
                //                String image = "http://" + host + "/image/" + DateUtil.currentYearMonthDay() + "/" + user.getId();//获取图片生成之后的地址
                String image = userInfo.get("image").toString();//获取图片生成之后的地址
                user.setImage(image);
                user.setName(userInfo.get("name").toString());
                user.setSlaveShapeType(sex == 0 ? new Random().nextInt(2) : new Random().nextInt(3));
                userLoginProcessor.allotSangoState(user);
                jdbcSqlRepo.addUser(user);
                //                String srcImage = userInfo.get("image").toString();
                //                jedis.lpush(DownloadImageTask.getUserImageKey(), (user.getId() + "," + srcImage).getBytes("UTF-8"));
            } catch (Exception e) {
                logger.error(e);
            }
        } else {
            if (userRepo.isUserExist(openid)) {
                userId = userRepo.findUserId(openid);
                userRepo.checkAccountState(userId);
                user = userRepo.findUser(userId);
            }
        }
        return user;

    }

    private void checkRequestInfo(String openid, String token) {
        String checkToken = TokenProducer.produceGetUserInfoToken(openid);

        // 是否登陆有效，如果无效，提醒重新登录 内部将抛BussionException异常。
        if (!token.equals(checkToken)) {
            throw new BusinessException(ErrorCode.USER_IS_FROZEN);
        }
    }

}
