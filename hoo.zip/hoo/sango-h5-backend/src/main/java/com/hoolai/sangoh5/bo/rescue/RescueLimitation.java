package com.hoolai.sangoh5.bo.rescue;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.RescueLimitationProto;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class RescueLimitation implements ProtobufSerializable<RescueLimitationProto> {

    private long userId;

    /**
     * 已经揭榜的次数
     */
    private int hasRescueNum;

    /**
     * 购买的次数
     */
    private int buyRescueNum;

    private int extraRescueNum;

    /** 挑战次数 */
    //	private String challenageNum;
    /** 抵御防御的次数 */
    private int rescueFailCount;

    private transient ConstantsPoolData constantsPool;

    public RescueLimitation(long userId, int addRescueNum, ConstantsPoolData constantsPool) {
        super();
        this.userId = userId;
        this.extraRescueNum = addRescueNum;
        this.constantsPool = constantsPool;
        //		this.challenageNum = "";
    }

    public RescueLimitation(long userId, byte[] bytes, int addRescueNum, ConstantsPoolData constantsPool) {
        this(userId, addRescueNum, constantsPool);
        parseFrom(bytes);
    }

    /**
     * 重置新的一天的数据
     */
    public void resetNewDay() {
        this.buyRescueNum = 0;
        this.hasRescueNum = 0;
    }

    public int getHasRescueNum() {
        return hasRescueNum;
    }

    public void setHasRescueNum(int hasRescueNum) {
        this.hasRescueNum = hasRescueNum;
    }

    public int getExtraRescueNum() {
        return extraRescueNum;
    }

    public void setExtraRescueNum(int extraRescueNum) {
        this.extraRescueNum = extraRescueNum;
    }

    public int getBuyRescueNum() {
        return buyRescueNum;
    }

    public void setBuyRescueNum(int buyRescueNum) {
        this.buyRescueNum = buyRescueNum;
    }

    public int getLeftRescueNum() {
        return constantsPool.getProperty(2).getValue() + extraRescueNum + buyRescueNum - hasRescueNum;
    }

    public void setLeftRescueNum(int leftRescueNum) {
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    //	public String getChallenageNum() {
    //		return challenageNum;
    //	}
    //
    //	public void setChallenageNum(String challenageNum) {
    //		this.challenageNum = challenageNum;
    //	}

    public int getRescueFailCount() {
        return rescueFailCount;
    }

    public void setRescueFailCount(int rescueFailCount) {
        this.rescueFailCount = rescueFailCount;
    }

    public void addRescueFailCount() {
        this.rescueFailCount++;
    }
    
    @Override
    public RescueLimitationProto copyTo() {
        RescueLimitationProto.Builder builder = RescueLimitationProto.newBuilder();
        builder.setBuyRescueNum(buyRescueNum);
        builder.setHasRescueNum(hasRescueNum);
        builder.setUserId(userId);
        //		builder.setChallenageNum(challenageNum);
        builder.setRescueFailCount(rescueFailCount);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            copyFrom(RescueLimitationProto.parseFrom(bytes));
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void copyFrom(RescueLimitationProto message) {
        this.buyRescueNum = message.getBuyRescueNum();
        this.hasRescueNum = message.getHasRescueNum();
        this.userId = message.getUserId();
        //		this.challenageNum = message.getChallenageNum();
        this.rescueFailCount = message.getRescueFailCount();
    }

    public boolean isOverChallengeNum() {
        return hasRescueNum >= constantsPool.getProperty(2).getValue() + extraRescueNum + buyRescueNum;
    }

    public boolean isOverBuyNum(int extraNum) {
        return buyRescueNum >= Constants.maxBuyNum + extraNum;
    }

    public void addHasRescueNum() {
        this.hasRescueNum++;
    }
    
    public void checkAndAddHasRescueNum(){
    	if (isOverChallengeNum()) {
            throw new BusinessException(ErrorCode.ERROR_CHALLENAGE_COUNT);
        }
        addHasRescueNum();
    }

    public void addBuyRescueNum() {
        this.buyRescueNum++;
    }
}
