package com.hoolai.sangoh5.bo.shop;

import java.util.ArrayList;
import java.util.List;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ArenaProtocolBuffer.ShopIdList;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 排位赛、竞技场、联盟商店id
 * @author hp
 *
 */
public class ShopList implements ProtobufSerializable<ShopIdList> {

	private List<Integer> ids = new ArrayList<Integer>();

	public ShopList(){
		
	}
	
	public ShopList(byte[] bytes){
		parseFrom(bytes);
	}
	
	@Override
	public ShopIdList copyTo() {
		ShopIdList.Builder builder = ShopIdList.newBuilder();
		if (ids.size() > 0) {
			for (int id : ids) {
				builder.addId(id);
			}
		}
		return builder.build();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			ShopIdList message = ShopIdList.parseFrom(bytes);
			copyFrom(message);
		} catch (InvalidProtocolBufferException e) {
			throw new BusinessException(ErrorCode.CAN_NOT_MEM);
		}

	}

	@Override
	public void copyFrom(ShopIdList message) {
		int count = message.getIdCount();
		for (int i = 0; i < count; i++) {
			ids.add(message.getId(i));
		}
	}

	public List<Integer> getIds() {
		return ids;
	}

	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}
	
}
