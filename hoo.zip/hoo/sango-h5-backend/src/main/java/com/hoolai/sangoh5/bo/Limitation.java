package com.hoolai.sangoh5.bo;

import com.hoolai.sango.util.DateUtil;

public class Limitation {
	/**
	 * 位置一但确定就不要改了，因为是用 ordinary 作为key存取数据的，切记！！！<br>
	 * 位置一但确定就不要改了，因为是用 ordinary 作为key存取数据的，切记！！！<br>
	 * 位置一但确定就不要改了，因为是用 ordinary 作为key存取数据的，切记！！！<br>
	 * 位置一但确定就不要改了，因为是用 ordinary 作为key存取数据的，切记！！！<br>
	 * 位置一但确定就不要改了，因为是用 ordinary 作为key存取数据的，切记！！！<br>
	 */
	public static enum Type{
		SEND_WORD_MESSAGE_TIMES{

			@Override
			int topLimit() {
				return 10;
			}
			
		};
		
		abstract int topLimit();
		
		 /** 默认的错误信息(不需要错误码时errorCode()的默认返回值) */
		String errMessge(){
			return "";
		}
	}
	
	/** 该条记录的日期(日期为距1970年1月1日的天数) {@link DateUtil} */
    private int limitDay;

    /** 该条记录中已经使用过的limit数值 */
    private int limitNum;

    /** 限制类型 */
    transient private Type limitationType;

    /**
     * 根据数据库的value创建limitation对象 {limitDay|limitNum}
     *
     * @param data
     */
    public Limitation(String data, Type limitationType) {
        String[] columns = data.split("\\|");
        this.limitDay = Integer.parseInt(columns[0]);
        this.limitNum = Integer.parseInt(columns[1]);
        this.limitationType = limitationType;

        //checkAndReset();
    }
    
    /**
     * 存在数据库的value
     *
     * @return
     */
    public String value() {
        return new StringBuilder().append(limitDay).append("|").append(limitNum).toString();
    }
    
    public boolean checkAndReset() {
		int today = DateUtil.getTodayIntValue();
        if (this.limitDay < today) {
            this.limitDay = today;
            this.limitNum = 0;
            return true;
        }
        return false;
	}
    
    public int findLeftLimitNum() {
        if (this.limitDay < DateUtil.getTodayIntValue()) {
            return limitationType.topLimit();
        }
        return limitationType.topLimit() - this.limitNum;
    }
    
    /**
     * 判断今天是否超出限制
     *
     * @param limitationType
     * @return
     */
    public boolean isOverTodayLimit() {
        return this.limitNum >= limitationType.topLimit();
    }
    
    /**
     * 判断如果加addLimit个今天是否超出限制
     *
     * @param limitationType
     * @return
     */
    public boolean isOverTodayLimit(int addLimit) {
        return limitNum + addLimit > limitationType.topLimit();
    }
    
    public void addLimitNum(){
    	this.limitNum++;
    }
   
    public void addLimitNum(int num){
    	this.limitNum += num;
    }

	public int getLimitDay() {
		return limitDay;
	}

	public void setLimitDay(int limitDay) {
		this.limitDay = limitDay;
	}

	public int getLimitNum() {
		return limitNum;
	}

	public void setLimitNum(int limitNum) {
		this.limitNum = limitNum;
	}

	public Type getLimitationType() {
		return limitationType;
	}

	public void setLimitationType(Type limitationType) {
		this.limitationType = limitationType;
	}
    
}
