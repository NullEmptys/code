package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.Iterator;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.DefencePassiveSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public abstract class IndependentSkill extends Skill {

    public static final IndependentSkill NONE = new IndependentSkill() {

        @Override
        public Skill clone() {
            return this;
        }

        @Override
        public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
            //DO NOTHING
            return null;
        }
    };

    public IndependentSkill withChance(float chance) {
        this.setChance(chance);
        return this;
    }

    /**
     * 执行技能，确定目标，产生技能效果，并将技能效果绑定到每一个目标身上 应用各种加成 如果技能触发，返回被影响的target列表
     * 否则，返回null
     * 
     * @param actor
     * @param tc
     * @param currentLevel TODO
     * @return
     */
    public abstract List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel);

    /**
     * 被攻击方防御
     * 
     * @param actor
     * @param target
     * @param effect
     * @param tc
     * @param targets
     * @param currentLevel TODO
     * @return
     */
    protected DefenceSkill targetDefence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {

        List<DefencePassiveSkill> counterAttackSkills = target.getCounterAttackSkills();
        if (counterAttackSkills != null) {
            Iterator<DefencePassiveSkill> iterator = counterAttackSkills.iterator();
            while (iterator.hasNext()) {
                DefencePassiveSkill defencePassiveSkill = iterator.next();
                defencePassiveSkill.defence(actor, target, effect, buff, tc, targets, currentLevel);
            }
        }

        DefenceSkill defenceSkill = target.useDefenceSkill();
        defenceSkill.defence(actor, target, effect, buff, tc, targets, currentLevel);//默认防御
        return defenceSkill;
    }

    protected IndependentSkill nextTriggerSkill;

    public IndependentSkill getNextTriggerSkill() {
        return nextTriggerSkill;
    }

    public void setNextTriggerSkill(IndependentSkill nextTriggerSkill) {
        this.nextTriggerSkill = nextTriggerSkill;
    }

}
