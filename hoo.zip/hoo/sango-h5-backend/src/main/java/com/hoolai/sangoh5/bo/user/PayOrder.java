package com.hoolai.sangoh5.bo.user;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hoolai.sango.util.DateUtil;
import com.hoolai.sangoh5.util.Constant;
import com.hoolai.platform.service.tencent.TencentOrderV3;
import com.hoolai.util.StringUtil;
import com.hoolai.util.TimeUtil;

/**
 * <p>描述：玩吧积分支付订单</p>
 * @author whg
 * @date 2016-10-9 下午03:05:34
 */
public class PayOrder {
	
	private static final Logger logger = LoggerFactory.getLogger(PayOrder.class);

    private int id;

    private int date;
    private Timestamp time;

    private String openid;
    private long userid;

    /** 是否是玩吧达人 */
    private boolean isVip;
    
    /** 
     * 玩吧积分是玩吧通用货币，价格为1积分=0.1RMB；<br/>
     * 这里amount=cost（即单位为人民币的角）；<br/>
     *（打折以后的总价钱，即乘以数目后的）
     **/
    private int amount;
    
    /** 玩吧积分（打折前的价钱总价格，即乘以数目后的）*/
    private int srcAmount;

    private String itemId;
    private int itemNum;

    /** 交易流水账号 */
    private String billno;

    /** 对应BI的gameId，因为我们是单服单区不分多服多区 */
    private int gameId;
    
    /** 对应的多服多区的服Id，现在迫不得已需要放弃1服玩家开新的2服了 */
    private int serverId;
    
    public static PayOrder dbPayOrder(){
    	return new PayOrder();
    }
    
    private PayOrder(){
    	this.date = Integer.parseInt(DateUtil.currentYearMonthDay1());
    	this.time = new Timestamp(TimeUtil.currentTimeMillis());
    }
    
    public static PayOrder h5PayOrder(User user, boolean isVip, int amount, int srcAmount, String itemId, int itemNum, String billno) {
    	return new PayOrder(user.getPlatformId(), user.getId(), isVip, amount, amount, itemId, itemNum, billno);//取消打折商品
    }
    
	private PayOrder(String openid, long userid, boolean isVip, int amount, int srcAmount, String itemId, int itemNum, String billno){
    	this();
//    	String trackGameId = Constant.trackGameId(openid);
    	if(Constant.isLocalPlatform()){
    		this.openid = openid;
    	}else if(Constant.PLATFORM_NAME.equals("wanba_ts")){
    		this.openid = User.realPlatformId(openid);
    	}
    	this.userid = userid;
    	this.isVip = isVip;
    	this.amount = amount;
    	this.srcAmount = srcAmount;
    	this.itemId = itemId;
    	this.itemNum = itemNum;
    	this.billno = billno;
    	this.gameId = 1;//TODO
    	this.serverId = Constant.SERVER_ID;
    }
    
	@Override
	public String toString() {
		return "PayOrder [amount=" + amount + ", billno=" + billno + ", date=" + date + ", gameId=" + gameId + ", id=" + id + ", isVip=" + isVip
				+ ", itemId=" + itemId + ", itemNum=" + itemNum + ", openid=" + openid + ", srcAmount=" + srcAmount + ", time=" + time + ", userid="
				+ userid + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getDate() {
		return date;
	}

	public void setDate(int date) {
		this.date = date;
	}

	public Timestamp getTime() {
		return time;
	}

	public void setTime(Timestamp time) {
		this.time = time;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public boolean isVip() {
		return isVip;
	}

	public void setVip(boolean isVip) {
		this.isVip = isVip;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getSrcAmount() {
		return srcAmount;
	}

	public void setSrcAmount(int srcAmount) {
		this.srcAmount = srcAmount;
	}
	
	public int getIntItemId(){
		return Integer.parseInt(itemId);
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public int getItemNum() {
		return itemNum;
	}

	public void setItemNum(int itemNum) {
		this.itemNum = itemNum;
	}

	public String getBillno() {
		return billno;
	}

	public void setBillno(String billno) {
		this.billno = billno;
	}

	public int getGameId() {
		return gameId;
	}

	public void setGameId(int gameId) {
		this.gameId = gameId;
	}

	public int getServerId() {
		return serverId;
	}

	public void setServerId(int serverId) {
		this.serverId = serverId;
	}

}
