package com.hoolai.sangoh5.bo.battle.fight;

import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;


/**
 * 
 * 将领出手顺序队列
 * 
 */
public class OfficerSequence {
    
    private final FightUnitName[] sequence; 
    private final int[] sequencePos;

    /**
     * 这一回合可以出手的战斗单元，对应构造函数OfficerSequence()
     */
    private final static FightUnitName[] defaultSequence = new FightUnitName[] {FightUnitName.def_officer,FightUnitName.att_officer};
    
    /**
     * 初始化某个战斗单元可攻击的战斗单元以及顺序，对应构造函数OfficerSequence(FightUnitName)
     */
    private int currentIndex = 0;
    
    /**
     * 初始化可以出手的战斗单元
     */
    public OfficerSequence() {
        this(defaultSequence);
    }
    
    public OfficerSequence(FightUnitName[] sequence) {
        this.sequence = sequence;
        this.sequencePos = new int[]{1,2,3,4};
    }
    
    public boolean hasNext() {
        return currentIndex < sequence.length;
    }
    
    public int nextPos() {
        return sequencePos[currentIndex++];
    }
    
    public FightUnitName next() {
        return sequence[currentIndex++];
    }
    
    public void reset() {
        currentIndex = 0;
    }

	public int getCurrentIndex() {
		return currentIndex;
	}
	
	public FightUnitName getUnit(int index){
		return sequence[index];
	}

	public boolean hasNextPos() {
		return currentIndex < sequencePos.length;
	}
    
}
