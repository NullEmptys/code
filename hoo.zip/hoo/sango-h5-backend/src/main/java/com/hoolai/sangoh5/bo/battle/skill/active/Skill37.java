package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.buff.TargetEnhanceBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 薄葬在接下来的5秒内阻止所有将导致目标死亡的伤害
 * 
 * @author Administrator
 *
 */
public class Skill37 extends IndependentSkill {

    @Override
    public Skill clone() {
        return super.clone(new Skill37());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        actor.addBuff(new TargetEnhanceBuff(xmlId, name, currentLevel, this.percentage, actor).withActorName(actor.name()).withTargetName(actor.name())
                .withRepeatCount(repeatCount).withKeepBuff());
        targets.add(actor);

        return targets;
    }

}
