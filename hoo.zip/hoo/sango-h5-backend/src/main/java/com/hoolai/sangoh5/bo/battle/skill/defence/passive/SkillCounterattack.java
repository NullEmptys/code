package com.hoolai.sangoh5.bo.battle.skill.defence.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 针对技能反击类技能
 * 
 * @author liqing
 *
 */
public class SkillCounterattack extends DefencePassiveSkill {

    @Override
    public void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {
        if (effect == null || effect.getDeltaHp() < 1 || actor.isDead() || target.isDead() || effect.getTargetUsedSkillXmlId() == Effect.NONE_USED_SKILL_ID) {
            return;
        }
        if (pg.getRandomWithPercentage(chance)) {
            int delHp = effect.getDeltaHp();
            int counterHp = Math.round(actor.getOriginalHp() * percentage);

            effect.setDeltaHp(0);
            actor.addBuff(new Buff(this.xmlId, name, actor.name(), currentLevel).withActorName(actor.name()).withTargetName(actor.name()).withDeltaHp(counterHp));

            target.addBattleLog(target.name() + "使用" + this.xmlId + "[" + this.name + "]防御了" + actor.name() + "的伤害，old=" + delHp + ",new=" + effect.getDeltaHp() + ",且反击了一个伤害="
                    + counterHp);
        }
    }

    @Override
    public Skill clone() {
        return super.clone(new SkillCounterattack());
    }

}
