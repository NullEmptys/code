package com.hoolai.sangoh5.bo.user.data;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.RandomUtil;

@Component
public class NameData extends JsonData<NameProperty> {

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/name.json", NameProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(NameProperty property) {

    }

    public String getRandomName() {
        Iterator<NameProperty> it = this.getPropertyMap().values().iterator();
        Set<String> type1Names = Sets.newHashSet();
        Set<String> type2Names = Sets.newHashSet();
        while (it.hasNext()) {
            NameProperty name = it.next();
            if (name.getType() == 1) {
                type1Names.add(name.getName());
            } else {
                type2Names.add(name.getName());
            }
        }
        List<String> type1ListNames = Lists.newArrayList(type1Names);
        List<String> type2ListNames = Lists.newArrayList(type2Names);
        StringBuilder sb = new StringBuilder();
        sb.append(type1ListNames.get(RandomUtil.randomOpenNum(type1ListNames.size() - 1)));
        sb.append(type2ListNames.get(RandomUtil.randomOpenNum(type2ListNames.size() - 1)));
        return sb.toString();
    }

}
