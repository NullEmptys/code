package com.hoolai.sangoh5.bo.tacticalManagement;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.FormationProto;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName.FightType;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.tacticalManagement.data.TacticalData;
import com.hoolai.sangoh5.bo.tacticalManagement.data.TacticalProperty;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Formation implements ProtobufSerializable<FormationProto> {

    private int id;

    private int starLevel = 1;

    private int fightNum;//使用该阵型战斗次数

    private List<FormationPos> corps = new ArrayList<FormationPos>();

    transient private TacticalData tacticalData;

    transient private boolean isLevelUp;

    public Formation(Formation clone) {
        this.id = clone.id;
        this.starLevel = clone.getStarLevel();
        this.fightNum = clone.getFightNum();
        this.tacticalData = clone.tacticalData;
        this.corps = clone.copyCorps();
    }

    public Formation(TacticalData tacticalData, int defaultTactical, int[] soldierTypes, int[] oneXy, int[] twoXy) {
        this.tacticalData = tacticalData;

        TacticalProperty tacticalProperty = tacticalData.getProperty(defaultTactical);
        this.id = tacticalProperty.getId();

        // 初始兵种1的站位
        for (int xy : oneXy) {
            FormationPos formationPos = new FormationPos(xy, SoldierType.valueOf(soldierTypes[0]));
            corps.add(formationPos);
        }

        // 初始兵种2的站位
        for (int xy : twoXy) {
            FormationPos formationPos = new FormationPos(xy, SoldierType.valueOf(soldierTypes[1]));
            corps.add(formationPos);
        }

        // 将领的站位
        FormationPos formationPos = new FormationPos(FormationPos.OFFICER_POS_INT);
        corps.add(formationPos);

        this.init(tacticalData);
    }

    public Formation(FormationProto currFormation) {
        copyFrom(currFormation);
    }

    /**
     * 创建NPC
     * 
     * @param tacticalData
     * @param defaultTactical
     * @param soldierType
     */
    public Formation(TacticalData tacticalData, int defaultTactical, List<SoldierType> soldierType) {
        this.tacticalData = tacticalData;

        TacticalProperty tacticalProperty = tacticalData.getProperty(defaultTactical);
        this.id = tacticalProperty.getId();

        // 兵种站位
        for (int i = 1; i <= soldierType.size(); i++) {
            FormationPos formationPos = new FormationPos(i, soldierType.get(i - 1));
            corps.add(formationPos);
        }

        // 将领站位
        FormationPos formationPos = new FormationPos(FormationPos.OFFICER_POS_INT);
        corps.add(formationPos);
    }

    private List<FormationPos> copyCorps() {
        if (corps != null && corps.size() > 0) {
            List<FormationPos> newCorps = new ArrayList<FormationPos>();
            for (FormationPos formationPos : corps) {
                newCorps.add(formationPos.clone());
            }
            return newCorps;
        }
        return null;
    }

    public List<SoldierType> takeSoldierTypes() {
        List<SoldierType> soldierTypes = new ArrayList<SoldierType>();
        for (FormationPos formationPos : corps) {
            if (!formationPos.isOfficer()) {
                soldierTypes.add(formationPos.getSoldierType());
            }
        }
        return soldierTypes;
    }

    public int[] takeOfficerPos(boolean isAttacker) {
        TacticalProperty property = tacticalData.getProperty(id);
        if (isAttacker) {
            return property.getAttackOfficerXy();
        } else {
            return property.getDefenceOfficerXy();
        }
    }

    public int[] takeSoldierPos(int pos, FightType type) {
        TacticalProperty property = tacticalData.getProperty(id);
        switch (pos) {
            case 1:
                if (type == FightType.attack) {
                    return property.getAttackOneXy();
                } else {
                    return property.getDefenceOneXy();
                }
            case 2:
                if (type == FightType.attack) {
                    return property.getAttackTwoXy();
                } else {
                    return property.getDefenceTwoXy();
                }
            case 3:
                if (type == FightType.attack) {
                    return property.getAttackThreeXy();
                } else {
                    return property.getDefenceThreeXy();
                }
            case 4:
                if (type == FightType.attack) {
                    return property.getAttackFourXy();
                } else {
                    return property.getDefenceFourXy();
                }
            case 5:
                if (type == FightType.attack) {
                    return property.getAttackFiveXy();
                } else {
                    return property.getDefenceFiveXy();
                }
            case 6:
                if (type == FightType.attack) {
                    return property.getAttackSixXy();
                } else {
                    return property.getDefenceSixXy();
                }
            default:
                return null;
        }
    }

    public List<FormationPos> getCorps() {
        return corps;
    }

    public int getId() {
        return id;
    }

    public int takeSoldierRow(int pos) {
        TacticalProperty property = tacticalData.getProperty(id);
        return property.getRow(pos);
    }

    public int[] takeFightRow(int index) {
        TacticalProperty property = tacticalData.getProperty(id);
        switch (index) {
            case 1:
                return property.getOneRow();
            case 2:
                return property.getTwoRow();
            case 3:
                return property.getThreeRow();
        }
        return null;
    }

    public void changeFormationPos(int pos, int soldierTypeInt) {
        FormationPos formationPos = findFormationPos(pos);
        if (formationPos == null) {
            throw new BusinessException(ErrorCode.NO_HAVE_POS);
        }
        formationPos.setSoldierType(SoldierType.valueOf(soldierTypeInt));
    }

    public void exchangeFormationPos(int pos1, int pos2) {
        FormationPos formationPos1 = findFormationPos(pos1);
        FormationPos formationPos2 = findFormationPos(pos2);

        if (formationPos1 == null || formationPos2 == null) {
            throw new BusinessException(ErrorCode.NO_HAVE_POS);
        }

        SoldierType soldierType1 = formationPos1.getSoldierType();
        SoldierType soldierType2 = formationPos2.getSoldierType();

        formationPos1.setSoldierType(soldierType2);
        formationPos2.setSoldierType(soldierType1);
    }

    public FormationPos findFormationPos(int pos) {
        for (FormationPos formationPos : corps) {
            if (formationPos.getPosInt() == pos) {
                return formationPos;
            }
        }
        return null;
    }

    @Override
    public Formation clone() {
        Formation formation = new Formation(this);
        return formation;
    }

    public void setTacticalData(TacticalData tacticalData) {
        this.tacticalData = tacticalData;
    }

    public int getStarLevel() {
        return starLevel;
    }

    public void setStarLevel(int starLevel) {
        this.starLevel = starLevel;
    }

    public int getFightNum() {
        return fightNum;
    }

    public void setFightNum(int fightNum) {
        this.fightNum = fightNum;
    }

    @Override
    public FormationProto copyTo() {
        FormationProto.Builder builder = FormationProto.newBuilder();
        builder.setId(id);
        builder.setStarLevel(starLevel);
        builder.setFightNum(fightNum);

        for (FormationPos formationPos : corps) {
            builder.addCorps(formationPos.copyTo());
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            FormationProto message = FormationProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(FormationProto message) {
        this.id = message.getId();
        this.starLevel = message.getStarLevel();
        this.fightNum = message.getFightNum();

        int count = message.getCorpsCount();
        for (int i = 0; i < count; i++) {
            this.corps.add(new FormationPos(message.getCorps(i)));
        }
    }

    /**
     * 给傻逼前端显示用
     * 
     * @param tacticalData
     */
    public void init(TacticalData tacticalData) {
        this.tacticalData = tacticalData;
        for (FormationPos formationPos : corps) {
            if (formationPos.isOfficer()) {
                formationPos.setPos(this.takeOfficerPos(true));
            } else {
                formationPos.setPos(this.takeSoldierPos(formationPos.getPosInt(), FightType.attack));
            }
        }
    }

    public boolean isLevelUp() {
        return isLevelUp;
    }

    public void setLevelUp(boolean isLevelUp) {
        this.isLevelUp = isLevelUp;
    }

    public void addFightNum() {
        TacticalProperty tactical = tacticalData.getProperty(id);
        if (starLevel >= tactical.getPromoteNeedFigNum().length + 1) {
            return;
        }
        this.fightNum++;
        int[] needFigNum = tactical.getPromoteNeedFigNum();
        int nextTarget = needFigNum[starLevel - 1];
        if (fightNum >= nextTarget) {
            isLevelUp = true;
            starLevel++;
        }
    }
}
