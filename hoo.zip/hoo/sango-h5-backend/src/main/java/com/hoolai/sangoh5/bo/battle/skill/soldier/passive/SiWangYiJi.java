package com.hoolai.sangoh5.bo.battle.skill.soldier.passive;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.soldier.SiWangYiJiBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.passive.AttributeEnhanceSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.SoldierUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.bo.soldier.SoldierType;

/**
 * 免疫击退和控制技能
 */
public class SiWangYiJi extends AttributeEnhanceSkill {

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {
        if (((SoldierUnit) actor).getSoldierType() == SoldierType.spearman) {
            actor.addAfterActionBuff(new SiWangYiJiBuff(xmlId, actor.name(), false, Effect.MONITORING_BUFF_LEVEL, this, actor).withActorName(actor.name())
                    .withTargetName(actor.name()).withRepeatCount(MaxRepeatCount).withKeepBuff());
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]");
        }
    }

    @Override
    public Skill clone() {
        return super.clone(new SiWangYiJi());
    }
}
