package com.hoolai.sangoh5.bo.battle.skill;

import com.hoolai.sangoh5.bo.battle.skill.active.AnLeiNuZhan;
import com.hoolai.sangoh5.bo.battle.skill.active.BaoJi;
import com.hoolai.sangoh5.bo.battle.skill.active.BaoZou;
import com.hoolai.sangoh5.bo.battle.skill.active.ChenMoSkill;
import com.hoolai.sangoh5.bo.battle.skill.active.DefensiveShield;
import com.hoolai.sangoh5.bo.battle.skill.active.HanWuJi;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.skill.active.LeiDun;
import com.hoolai.sangoh5.bo.battle.skill.active.MingYunYiJi;
import com.hoolai.sangoh5.bo.battle.skill.active.MoDun;
import com.hoolai.sangoh5.bo.battle.skill.active.Poison;
import com.hoolai.sangoh5.bo.battle.skill.active.QingXinShu;
import com.hoolai.sangoh5.bo.battle.skill.active.RangeSustainedAttack;
import com.hoolai.sangoh5.bo.battle.skill.active.ShengMingLianJie;
import com.hoolai.sangoh5.bo.battle.skill.active.Stun;
import com.hoolai.sangoh5.bo.battle.skill.active.TaiJiZhenFa;
import com.hoolai.sangoh5.bo.battle.skill.active.TuZiWaiTao;
import com.hoolai.sangoh5.bo.battle.skill.active.ZouSiLeiDian;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.Counterattack;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.DefencePassiveSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.HurtTreatment;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.OfficerDuoShan;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.SkillCounterattack;
import com.hoolai.sangoh5.bo.battle.skill.passive.AttributeEnhanceSkill;
import com.hoolai.sangoh5.bo.battle.skill.passive.BingHun;
import com.hoolai.sangoh5.bo.battle.skill.passive.KuangBao;
import com.hoolai.sangoh5.bo.battle.skill.passive.KuangXueShouHua;
import com.hoolai.sangoh5.bo.battle.skill.passive.PassiveHurtEnhance;
import com.hoolai.sangoh5.bo.battle.skill.passive.ShanShuoTuXi;
import com.hoolai.sangoh5.bo.battle.skill.passive.ShenDun;
import com.hoolai.sangoh5.bo.battle.skill.passive.SkillSteal;
import com.hoolai.sangoh5.bo.battle.skill.passive.TouQu;
import com.hoolai.sangoh5.bo.battle.skill.passive.YouLieZhuanHuan;
import com.hoolai.sangoh5.bo.battle.skill.passive.YueCuoYueYong;
import com.hoolai.sangoh5.bo.battle.skill.soldier.active.BaoLie;
import com.hoolai.sangoh5.bo.battle.skill.soldier.active.DuoChongJian;
import com.hoolai.sangoh5.bo.battle.skill.soldier.active.FengXing;
import com.hoolai.sangoh5.bo.battle.skill.soldier.active.LianShe;
import com.hoolai.sangoh5.bo.battle.skill.soldier.active.WuShiHuJia;
import com.hoolai.sangoh5.bo.battle.skill.soldier.defence.DuoShan;
import com.hoolai.sangoh5.bo.battle.skill.soldier.defence.JianShang;
import com.hoolai.sangoh5.bo.battle.skill.soldier.defence.passive.AbsoluteDefense;
import com.hoolai.sangoh5.bo.battle.skill.soldier.passive.ChangeSelfHp;
import com.hoolai.sangoh5.bo.battle.skill.soldier.passive.ChongFeng;
import com.hoolai.sangoh5.bo.battle.skill.soldier.passive.QiShiBenNeng;
import com.hoolai.sangoh5.bo.battle.skill.soldier.passive.SiWangYiJi;

public enum SkillType {

    /** 主动技能,主动触发(大都有概率) */
    ACTIVE {

        @Override
        public Skill newInstance(int skillId) {
            switch (skillId) {
                case 6:
                    return new Poison();
                case 7:
                    return new RangeSustainedAttack();
                case 14:
                    return new ChenMoSkill();
                case 19:
                case 28:
                case 32:
                    return new AnLeiNuZhan();
                case 20:
                case 21:
                case 27:
                case 29:
                case 30:
                    return new HanWuJi();
                case 22:
                case 31:
                case 202:
                    return new Stun();
                case 23:
                case 24:
                case 25:
                case 26:
                case 33:
                case 34:
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                case 40:
                case 41:
                case 42:
                    return new ZouSiLeiDian();
                case 44:
                    return new ShengMingLianJie();
                case 45:
                    return new TaiJiZhenFa();
                case 47:
                    return new LeiDun();
                case 49:
                    return new MoDun();
                case 54:
                    return new BaoJi();
                case 100:
                    return new QingXinShu();
                case 101:
                    return new TuZiWaiTao();
                case 200:
                    return new BaoZou();
                case 201:
                case 10010:
                    return new DefensiveShield();
                case 304:
                    return new MingYunYiJi();
                case 10006:
                    return new WuShiHuJia();
                case 10001:
                    return new DuoChongJian();
                case 10002:
                    return new LianShe();
                case 10003:
                    return new BaoLie();
                case 10009:
                    return new FengXing();
                case 10011:
                    return new ChangeSelfHp();
                default:
                    return IndependentSkill.NONE;
            }
        }
    },

    /** 被动技能,一直有效 */
    PASSIVE {

        @Override
        public Skill newInstance(int skillId) {
            switch (skillId) {
                case 46:
                    return new ShenDun();
                case 48:
                    return new KuangBao();
                case 50:
                    return new BingHun();
                case 52:
                    return new TouQu();
                case 53:
                    return new YouLieZhuanHuan();
                case 300:
                    return new ShanShuoTuXi();
                case 302:
                    return new SkillSteal();
                case 303:
                    return new YueCuoYueYong();
                case 307:
                    return new KuangXueShouHua();
                case 1001:
                case 1002:
                case 55:
                case 1007:
                    return new PassiveHurtEnhance();
                case 10008:
                    return new QiShiBenNeng();
                case 10012:
                    return new ChongFeng();
                case 10014:
                    return new SiWangYiJi();
                default:
                    return new AttributeEnhanceSkill();
            }
        }
    },

    ATTACKER_PASSIVE {

        @Override
        public Skill newInstance(int skillId) {
            return null;
        }
    },

    /**
     * 必然触发的防御技能
     */
    DEFENDER_PASSIVE {

        @Override
        public Skill newInstance(int skillId) {
            switch (skillId) {
                case 43:
                    return new Counterattack();
                case 56:
                    return new SkillCounterattack();
                case 301:
                    return new OfficerDuoShan();
                case 10013:
                    return new AbsoluteDefense();
            }
            return DefencePassiveSkill.NONE;
        }
    },

    DEFENCE {

        @Override
        public Skill newInstance(int skillId) {
            switch (skillId) {
                case 51:
                    return new HurtTreatment();
                case 10004:
                    return new DuoShan();
                case 10005:
                    return new JianShang();
                default:
                    return DefenceSkill.NONE;
            }
        }
    },
    SKILL_ENHANCE {

        @Override
        public Skill newInstance(int skillId) {
            switch (skillId) {
                default:
                    return null;
            }
        }
    },
    OTHER {

        @Override
        public Skill newInstance(int skillId) {
            switch (skillId) {
                default:
                    return null;
            }
        }
    };

    public abstract Skill newInstance(int skillId);

}
