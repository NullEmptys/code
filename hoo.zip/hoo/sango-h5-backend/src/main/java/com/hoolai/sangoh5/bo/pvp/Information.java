package com.hoolai.sangoh5.bo.pvp;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.compass.core.util.CollectionUtils;

import com.google.common.collect.Lists;
import com.hoolai.sangoh5.util.Utils;

/**
 * 情报信息
 * 
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-17 17:54
 * @version : 1.0
 */
public class Information {

    /** 州id **/
    private int stateId;

    /** 国土面积 **/
    private int landArea;

    /** 国土面积百分比 **/
    private float landAreaPer;

    /** 阵营id **/
    private int campId;

    /** 阵营名称 **/
    private String name;

    public Information(Camp camp, SangoState sangoState) {
        this.stateId = sangoState.getStateId();
        this.landArea = sangoState.findLandArea();
        this.landAreaPer = sangoState.getLandAreaPer();
        this.campId = camp.getId();
        this.name = camp.getName();
    }

    public Information(int stateId, int occupiedArea, int landArea) {
        this.stateId = stateId;
        this.landArea = occupiedArea;
        this.landAreaPer = Utils.calculationLandArea(occupiedArea, landArea);
    }

    public int getStateId() {
        return stateId;
    }

    public void setStateId(int stateId) {
        this.stateId = stateId;
    }

    public int getLandArea() {
        return landArea;
    }

    public void setLandArea(int landArea) {
        this.landArea = landArea;
    }

    public float getLandAreaPer() {
        return landAreaPer;
    }

    public void setLandAreaPer(float landAreaPer) {
        this.landAreaPer = landAreaPer;
    }

    public int getCampId() {
        return campId;
    }

    public void setCampId(int campId) {
        this.campId = campId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static List<Information> buildInformationList(Camp camp, List<SangoState> sangoStates) {
        if (CollectionUtils.isEmpty(sangoStates)) {
            return Collections.emptyList();
        }
        List<Information> informationList = Lists.newArrayListWithExpectedSize(sangoStates.size());
        for (SangoState sangoState : sangoStates) {
            informationList.add(new Information(camp, sangoState));
        }
        return informationList;
    }

    public static List<Information> createStateInformations(SangoState sangoState) {
        if (sangoState == null) {
            return Collections.emptyList();
        }
        Map<Integer, Integer> stateOccupyNumMap = sangoState.getStateOccupyNumMap();
        Set<Integer> keySet = stateOccupyNumMap.keySet();
        List<Information> informationList = Lists.newArrayListWithExpectedSize(stateOccupyNumMap.size());
        for (int stateId : keySet) {
            int occupiedArea = stateOccupyNumMap.get(stateId);
            if (occupiedArea < 0) {
                informationList.add(new Information(stateId, Math.abs(occupiedArea), sangoState.getLandArea()));
            }
        }

        return informationList;
    }
}
