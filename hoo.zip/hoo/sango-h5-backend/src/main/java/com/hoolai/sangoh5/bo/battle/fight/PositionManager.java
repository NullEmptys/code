package com.hoolai.sangoh5.bo.battle.fight;

import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.PositionManagerProto;
import com.hoolai.sangoh5.bo.battle.fight.PositionCalculator.MoveDirection;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.OfficerUnit;
import com.hoolai.sangoh5.bo.battle.unit.SoldierUnit;
import com.hoolai.sangoh5.bo.soldier.SoldierType.AttackType;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class PositionManager implements ProtobufSerializable<PositionManagerProto> {

    private static final Log logger = LogFactory.getLog("battle");

    private AttackType fightType;

    private FightUnitName lockActtackrName;

    /**
     * 攻击位置，一个单元周围有8个攻击位置，依次为12345678：
     * [x-1,y],[x+1,y],[x-1,y+1],[x+1,y+1],[x-1,y-1],[x+1,y-1],[x,y+1],[x,y
     * -1]
     */
    private int attackPos;

    private FightUnit actor;

    /**
     * 将领或者士兵初始站位（xml配置）
     */
    private int[] position = { 0, 0 };//将领或者士兵初始站位（xml配置）

    /**
     * 锁定攻击目标时的站位
     */
    private int[] lockTargetInitPos = { 0, 0 };//锁定攻击目标时的站位

    /**
     * 即将要去的目标位置
     */
    private int[] targetPosition = null;//即将要去的目标位置

    /**
     * 将领或者士兵目前的坐标
     */
    private int[] currentPosition = { 0, 0 };//将领或者士兵目前的坐标

    private int moveNum;

    private MoveDirection leftOrRight;

    private MoveDirection upOrDown;

    private int lrMoveNum;

    private int udMoveNum;

    private int roundCounter;//已经走了几个格子

    private int alreadyMoveLrNum;

    private int alreadyMoveUdNum;

    public PositionManager(FightUnit actor) {
        this.actor = actor;
        if (actor instanceof OfficerUnit) {
            OfficerUnit officerUnit = (OfficerUnit) actor;
            fightType = officerUnit.getOfficer().isWuGuan() ? AttackType.CLOSE_COMBAT : AttackType.LONG_RANGE;
        } else {
            fightType = ((SoldierUnit) actor).getSoldierFightType();
        }
        if (logger.isDebugEnabled()) {
            logger.debug(actor.name() + ":" + fightType);
        }
    }

    public PositionManager(PositionManagerProto message) {
        copyFrom(message);
    }

    public boolean isReachTargetPos() {
        if (fightType == AttackType.LONG_RANGE) {
            return true;
        }
        if (targetPosition != null && currentPosition[0] == targetPosition[0] && currentPosition[1] == targetPosition[1]) {
            return true;
        }
        return false;
    }

    public void addCounter() {
        roundCounter++;
    }

    public void clear() {
        roundCounter = 0;
        this.alreadyMoveLrNum = 0;
        this.alreadyMoveUdNum = 0;
    }

    public int counter() {
        return roundCounter;
    }

    public void next() {
        if ((roundCounter % 2 == 0 && alreadyMoveLrNum < lrMoveNum) || (roundCounter % 2 != 0 && alreadyMoveLrNum < lrMoveNum && alreadyMoveUdNum >= udMoveNum)) {
            currentPosition[0] = leftOrRight == MoveDirection.LEFT ? currentPosition[0] - 1 : currentPosition[0] + 1;
            alreadyMoveLrNum++;
        } else if ((roundCounter % 2 != 0 && alreadyMoveUdNum < udMoveNum) || (roundCounter % 2 == 0 && alreadyMoveUdNum < udMoveNum && alreadyMoveLrNum >= lrMoveNum)) {
            currentPosition[1] = upOrDown == MoveDirection.UP ? currentPosition[1] - 1 : currentPosition[1] + 1;
            alreadyMoveUdNum++;
        }
    }

    /**
     * 下一步预计会走到哪一个格子，用来判断这一个回合或者下一回合是否在某个技能Buff的辐射范围之内
     * 提前预计可避免战斗单元执行的先后问题造成的误差
     * 
     * @return
     */
    public int[] expectNext() {
        int[] expectPos = Arrays.copyOf(currentPosition, currentPosition.length);
        if (this.isReachTargetPos()) {
            return expectPos;
        } else {
            if ((roundCounter % 2 == 0 && alreadyMoveLrNum < lrMoveNum) || (roundCounter % 2 != 0 && alreadyMoveLrNum < lrMoveNum && alreadyMoveUdNum >= udMoveNum)) {
                expectPos[0] = leftOrRight == MoveDirection.LEFT ? expectPos[0] - 1 : expectPos[0] + 1;
            } else if ((roundCounter % 2 != 0 && alreadyMoveUdNum < udMoveNum) || (roundCounter % 2 == 0 && alreadyMoveUdNum < udMoveNum && alreadyMoveLrNum >= lrMoveNum)) {
                expectPos[1] = upOrDown == MoveDirection.UP ? expectPos[1] - 1 : expectPos[1] + 1;
            }
            return expectPos;
        }
    }

    private int[] newArrayClone(int[] clone) {
        if (clone == null) {
            return null;
        }
        int[] c = new int[] { clone[0], clone[1] };
        return c;
    }

    @Override
    public PositionManager clone() {
        PositionManager positionManager = new PositionManager(actor);
        positionManager.setCurrentPosition(newArrayClone(currentPosition));
        positionManager.setLeftOrRight(leftOrRight);
        positionManager.setLockActtackrName(lockActtackrName);
        positionManager.setLockTargetInitPos(newArrayClone(lockTargetInitPos));
        positionManager.setLrMoveNum(lrMoveNum);
        positionManager.setMoveNum(moveNum);
        positionManager.setPosition(newArrayClone(position));
        positionManager.setTargetPosition(newArrayClone(targetPosition));
        positionManager.setUdMoveNum(udMoveNum);
        positionManager.setUpOrDown(upOrDown);
        return positionManager;
    }

    public FightUnitName getLockActtackrName() {
        return lockActtackrName;
    }

    public void setLockActtackrName(FightUnitName lockActtackrName) {
        this.lockActtackrName = lockActtackrName;
    }

    public int[] getPosition() {
        return position;
    }

    public void setPosition(int[] position) {
        this.position = position;
    }

    public int[] getLockTargetInitPos() {
        return lockTargetInitPos;
    }

    public void setLockTargetInitPos(int[] lockTargetInitPos) {
        System.arraycopy(lockTargetInitPos, 0, this.lockTargetInitPos, 0, lockTargetInitPos.length);
    }

    public int[] getTargetPosition() {
        if (targetPosition == null && fightType == AttackType.LONG_RANGE) {
            return position;
        }

        return targetPosition;
    }

    public void setTargetPosition(int[] targetPosition) {
        this.targetPosition = targetPosition;
    }

    public int getMoveNum() {
        return moveNum;
    }

    public void setMoveNum(int moveNum) {
        this.moveNum = moveNum;
    }

    public MoveDirection getLeftOrRight() {
        return leftOrRight;
    }

    public void setLeftOrRight(MoveDirection leftOrRight) {
        this.leftOrRight = leftOrRight;
    }

    public MoveDirection getUpOrDown() {
        return upOrDown;
    }

    public void setUpOrDown(MoveDirection upOrDown) {
        this.upOrDown = upOrDown;
    }

    public int getLrMoveNum() {
        return lrMoveNum;
    }

    public void setLrMoveNum(int lrMoveNum) {
        this.lrMoveNum = lrMoveNum;
    }

    public int getUdMoveNum() {
        return udMoveNum;
    }

    public void setUdMoveNum(int udMoveNum) {
        this.udMoveNum = udMoveNum;
    }

    public int[] getCurrentPosition() {
        return currentPosition;
    }

    public void setCurrentPosition(int[] currentPosition) {
        this.currentPosition = currentPosition;
    }

    public boolean isHaveAttackUnit() {
        return this.lockActtackrName != null;
    }

    @Override
    public String toString() {
        return "PositionManager [fightType=" + fightType + ", lockActtackrName=" + lockActtackrName + ", position=" + Arrays.toString(position) + ", lockTargetInitPos="
                + Arrays.toString(lockTargetInitPos) + ", targetPosition=" + Arrays.toString(targetPosition) + ", currentPosition=" + Arrays.toString(currentPosition)
                + ", moveNum=" + moveNum + ", leftOrRight=" + leftOrRight + ", upOrDown=" + upOrDown + ", lrMoveNum=" + lrMoveNum + ", udMoveNum=" + udMoveNum + ", roundCounter="
                + roundCounter + ", alreadyMoveLrNum=" + alreadyMoveLrNum + ", alreadyMoveUdNum=" + alreadyMoveUdNum + "]";
    }

    @Override
    public void copyFrom(PositionManagerProto message) {
        this.alreadyMoveLrNum = message.getAlreadyMoveLrNum();
        this.alreadyMoveUdNum = message.getAlreadyMoveUdNum();
        if (message.hasFightType()) {
            this.fightType = AttackType.valueOf(message.getFightType());
        }

        int count = message.getCurrentPositionCount();
        if (count > 0) {
            this.currentPosition = new int[count];
            for (int i = 0; i < count; i++) {
                currentPosition[i] = message.getCurrentPosition(i);
            }
        }

        if (message.hasLeftOrRight()) {
            this.leftOrRight = MoveDirection.valueOf(message.getLeftOrRight());
        }
        if (message.hasUpOrDown()) {
            this.upOrDown = MoveDirection.valueOf(message.getUpOrDown());
        }
        if (message.hasLockActtackrName()) {
            this.lockActtackrName = FightUnitName.valueOf(message.getLockActtackrName());
        }

        int count1 = message.getPositionCount();
        if (count1 > 0) {
            this.position = new int[count];
            for (int i = 0; i < count; i++) {
                position[i] = message.getPosition(i);
            }
        }

        this.roundCounter = message.getRoundCounter();
        this.lrMoveNum = message.getLrMoveNum();

        int count2 = message.getLockTargetInitPosCount();
        if (count2 > 0) {
            this.lockTargetInitPos = new int[count];
            for (int i = 0; i < count2; i++) {
                lockTargetInitPos[i] = message.getLockTargetInitPos(i);
            }
        }

        this.moveNum = message.getMoveNum();

        int count3 = message.getTargetPositionCount();
        if (count3 > 0) {
            this.targetPosition = new int[count];
            for (int i = 0; i < count3; i++) {
                targetPosition[i] = message.getTargetPosition(i);
            }
        }

        this.udMoveNum = message.getUdMoveNum();
    }

    @Override
    public PositionManagerProto copyTo() {
        PositionManagerProto.Builder builder = PositionManagerProto.newBuilder();
        builder.setAlreadyMoveLrNum(alreadyMoveLrNum);
        builder.setAlreadyMoveUdNum(alreadyMoveUdNum);
        builder.setFightType(fightType.name());
        builder.setLeftOrRight(leftOrRight.name());
        if (lockActtackrName != null) {
            builder.setLockActtackrName(lockActtackrName.name());
        }
        if (lockTargetInitPos != null && lockTargetInitPos.length > 0) {
            for (int w : lockTargetInitPos) {
                builder.addLockTargetInitPos(w);
            }
        }
        if (currentPosition != null && currentPosition.length > 0) {
            for (int w : currentPosition) {
                builder.addCurrentPosition(w);
            }
        }
        builder.setLrMoveNum(lrMoveNum);
        builder.setMoveNum(moveNum);
        builder.setRoundCounter(roundCounter);
        if (position != null && position.length > 0) {
            for (int w : position) {
                builder.addPosition(w);
            }
        }
        if (targetPosition != null && targetPosition.length > 0) {
            for (int w : targetPosition) {
                builder.addTargetPosition(w);
            }
        }
        builder.setUdMoveNum(udMoveNum);
        builder.setUpOrDown(upOrDown.name());
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] arg0) {
        try {
            PositionManagerProto message = PositionManagerProto.parseFrom(arg0);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    public int getAttackPos() {
        return attackPos;
    }

    public void setAttackPos(int attackPos) {
        this.attackPos = attackPos;
    }

}
