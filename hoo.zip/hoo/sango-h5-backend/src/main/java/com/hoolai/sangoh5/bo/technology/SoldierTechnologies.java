package com.hoolai.sangoh5.bo.technology;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.ScienceProtocolBuffer.SoldierTechnologiesProto;
import com.hoolai.sangoh5.bo.barrack.Barrack;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.data.BattleEnhanceData;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.technology.data.SoldierScienceData;
import com.hoolai.sangoh5.bo.technology.data.SoldierScienceProperty;
import com.hoolai.sangoh5.bo.technology.data.SoldierScienceProperty.ScienceType;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.bo.user.User.CurrencyType;
import com.hoolai.sangoh5.repo.BarrackRepo;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class SoldierTechnologies implements ProtobufSerializable<SoldierTechnologiesProto> {

    private long userId;

    private int currScienceId;

    private Map<Integer, SoldierTechnology> soldierMap = new HashMap<Integer, SoldierTechnology>();

    transient SoldierTechnology currSoldierTechnology;

    transient String technologyName;

    transient boolean isHaveChange;

    private SoldierScienceData scienceData;

    private BarrackRepo barrackRepo;

    public SoldierTechnologies(long userId) {
        this.userId = userId;
    }

    public SoldierTechnologies(long userId, byte[] bytes) {
        this.userId = userId;
        parseFrom(bytes);
    }

    public boolean reflesh() {
        if (currScienceId > 0) {
            currSoldierTechnology = soldierMap.get(currScienceId);
            if (currSoldierTechnology.isFinish()) {
                refleshSkills();
                technologyName = scienceData.getProperty(currSoldierTechnology.getId()).getName();
                currScienceId = 0;
                currSoldierTechnology = null;
                return true;
            }
        }
        return false;
    }

    private void refleshSkills() {
        SoldierScienceProperty property = scienceData.getProperty(currSoldierTechnology.getId());
        ScienceType scienceType = ScienceType.valueOf(property.getType().toUpperCase());
        if (scienceType != ScienceType.BATTLEEFFECT) {
            Barrack barrack = barrackRepo.findBarrack(userId);
            SoldierType soldierType = SoldierType.valueOf(property.getEffectId());
            switch (scienceType) {
                case LEVELUP:
                    barrack.levelUpSoldierSkills(soldierType, (int) property.getNum());
                    break;
                case ADD:
                    barrack.addSoldierSkills(soldierType, (int) property.getNum());
                    break;
                default:
                    break;
            }
            barrackRepo.saveBarrack(barrack);
        }
    }

    /**
     * 升级科技
     * 
     * @param id
     * @param user
     */
    public int learn(int id, User user) {
        SoldierScienceProperty property = checkCanLearn(id, user);

        long endTime = TimeUtil.currentTimeMillis() + property.getTime() * 1000l;
        this.currScienceId = property.getScienceId();

        SoldierTechnology soldierTechnology = new SoldierTechnology(id, currScienceId, endTime);
        learnScience(soldierTechnology);

        return property.getSciece();
    }

    private void learnScience(SoldierTechnology soldierTechnology) {
        this.soldierMap.put(soldierTechnology.getScienceId(), soldierTechnology);
        this.currSoldierTechnology = soldierTechnology;
    }

    /**
     * 加速科技
     * 
     * @param id
     * @param time 分
     */
    public void accelerate(int time) {
        checkCanAccelerate();
        long accelerateTime = time * 60l * 1000l;
        currSoldierTechnology.accelerate(accelerateTime);
        reflesh();
    }

    /**
     * 快速完成
     * 
     * @param scienceId
     * @param user
     */
    public int fastToFinish(User user) {
        checkCanAccelerate();
        SoldierScienceProperty property = scienceData.getProperty(currSoldierTechnology.getId());

        int lanTianYu = (int) (Math.ceil(Double.valueOf(currSoldierTechnology.getLeftLearnTime()) / 60d));
        user.checkAndDecCurrency(CurrencyType.LANTIANYU, lanTianYu);

        currSoldierTechnology.accelerate(property.getTime() * 1000l);
        reflesh();
        return lanTianYu;
    }

    private void checkCanAccelerate() {
        if (currScienceId < 0 || currSoldierTechnology == null) {
            throw new BusinessException(ErrorCode.SCIENCE_HAS_NOT_LEARN);
        }

        if (currSoldierTechnology.isFinish()) {
            throw new BusinessException(ErrorCode.SCIENCE_LEARN_FINISH);
        }
    }

    private SoldierScienceProperty checkCanLearn(int id, User user) {
        if (currSoldierTechnology != null) {
            throw new BusinessException(ErrorCode.ONLY_LEARN_ONE);
        }

        SoldierScienceProperty property = scienceData.getProperty(id);
        SoldierTechnology technology = soldierMap.get(property.getScienceId());
        if (technology != null) {
            SoldierScienceProperty exsitProperty = scienceData.getProperty(technology.getId());
            if (exsitProperty.getLevel() >= property.getLevel()) {
                throw new BusinessException(ErrorCode.SCIENCE_LEARN_FINISH);
            }
        }

        user.checkAndDecCurrency(CurrencyType.METEORITE, property.getSciece());
        checkFront(property, user);
        return property;
    }

    private boolean isHaveFront(int[] fronts) {
        if (fronts.length == 1 && fronts[0] == 0) {
            return false;
        }
        return true;
    }

    private boolean isUserFront(int frontId) {
        if (frontId < 10000) {
            return true;
        }
        return false;
    }

    private void checkFront(SoldierScienceProperty property, User user) {
        int[] fronts = property.fronts();
        if (isHaveFront(fronts)) {
            if (property.isAnd()) {
                checkAnd(user, fronts);
            } else {
                checkOr(user, fronts);
            }
        }
    }

    private void checkOr(User user, int[] fronts) {
        boolean isDo = false;
        boolean isJuUser = false;
        for (int i = 0; i < fronts.length; i++) {
            if (isUserFront(fronts[i])) {
                isDo |= (isJuUser = user.getRank() >= fronts[i]);
            } else {
                isDo |= isHaveTechnologyFront(fronts[i]);
            }
            if (isDo) break;
        }

        if (!isDo) {
            if (!isJuUser) {
                throw new BusinessException(ErrorCode.NOT_ENOUGH_LEVEL);
            } else {
                throw new BusinessException(ErrorCode.FRONT_SCIENCE_HAS_NOT_LEARN);
            }
        }
    }

    private void checkAnd(User user, int[] fronts) {
        for (int i = 0; i < fronts.length; i++) {
            if (isUserFront(fronts[i])) {
                user.checkLevel(fronts[i]);
            } else {
                if (!isHaveTechnologyFront(fronts[i])) {
                    throw new BusinessException(ErrorCode.FRONT_SCIENCE_HAS_NOT_LEARN);
                }
            }
        }
    }

    private boolean isHaveTechnologyFront(int frontId) {
        SoldierScienceProperty property = scienceData.getProperty(frontId);
        if (property == null) {
            throw new BusinessException(ErrorCode.NO_THIS_SCIENCE);
        }
        SoldierTechnology soldierTechnology = soldierMap.get(property.getScienceId());
        if (soldierTechnology == null) {
            return false;
        }

        SoldierScienceProperty nowProperty = scienceData.getProperty(soldierTechnology.getId());
        if (nowProperty.getLevel() < property.getLevel() || (nowProperty.getLevel() == property.getLevel() && !soldierTechnology.isFinish())) {
            return false;
        }
        return true;
    }

    //    private void checkTechnologyFront(int frontId) {
    //        SoldierScienceProperty property = scienceData.getProperty(frontId);
    //        if (property == null) {
    //            throw new BusinessException(ErrorCode.NO_THIS_SCIENCE);
    //        }
    //
    //        SoldierTechnology soldierTechnology = soldierMap.get(property.getScienceId());
    //        if (soldierTechnology == null) {
    //            throw new BusinessException(ErrorCode.FRONT_SCIENCE_HAS_NOT_LEARN);
    //        }
    //
    //        SoldierScienceProperty nowProperty = scienceData.getProperty(soldierTechnology.getId());
    //        if (nowProperty.getLevel() < property.getLevel() || (nowProperty.getLevel() == property.getLevel() && !soldierTechnology.isFinish())) {
    //            throw new BusinessException(ErrorCode.FRONT_SCIENCE_HAS_NOT_LEARN);
    //        }
    //    }

    public long getUserId() {
        return userId;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public boolean isHaveChange() {
        return isHaveChange;
    }

    public Collection<SoldierTechnology> getSoldierTechnologies() {
        return soldierMap.values();
    }

    public SoldierTechnology getCurrSoldierTechnology() {
        return currSoldierTechnology;
    }

    public void setScienceData(SoldierScienceData scienceData) {
        this.scienceData = scienceData;
    }

    public void setBarrackRepo(BarrackRepo barrackRepo) {
        this.barrackRepo = barrackRepo;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public Map<Integer, SoldierTechnology> getSoldierMap() {
        return soldierMap;
    }

    @Override
    public SoldierTechnologiesProto copyTo() {
        SoldierTechnologiesProto.Builder builder = SoldierTechnologiesProto.newBuilder();
        builder.setCurrScienceId(currScienceId);

        Iterator<SoldierTechnology> iterator = soldierMap.values().iterator();
        while (iterator.hasNext()) {
            builder.addSoldierTechnologies(iterator.next().copyTo());
        }

        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            SoldierTechnologiesProto message = SoldierTechnologiesProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(SoldierTechnologiesProto message) {
        this.currScienceId = message.getCurrScienceId();

        int count = message.getSoldierTechnologiesCount();
        for (int i = 0; i < count; i++) {
            SoldierTechnology technology = new SoldierTechnology(message.getSoldierTechnologies(i));
            soldierMap.put(technology.getScienceId(), technology);
        }
    }

    public List<Skill> findSkill(BattleEnhanceData battleEnhanceData) {
        List<Skill> skills = new ArrayList<Skill>();

        Iterator<SoldierTechnology> iterator = soldierMap.values().iterator();
        while (iterator.hasNext()) {
            SoldierTechnology technology = iterator.next();

            SoldierScienceProperty property = scienceData.getProperty(technology.getId());
            ScienceType scienceType = ScienceType.valueOf(property.getType().toUpperCase());

            if (scienceType == ScienceType.BATTLEEFFECT) {
                Skill skill = null;
                if (technology.isFinish()) {
                    skill = battleEnhanceData.findSkill(property.getEffectId());
                    skill.setPercentage(property.getNum() / 100f);
                } else if (property.getNextLv() > 0) {
                    SoldierScienceProperty preProperty = scienceData.getProperty(property.getNextLv());
                    skill = battleEnhanceData.findSkill(preProperty.getEffectId());
                    skill.setPercentage(preProperty.getNum() / 100f);
                }

                if (skill != null) {
                    skills.add(skill);
                }
            }
        }

        return skills;
    }

    public String getTechnologyName() {
        return technologyName;
    }

}
