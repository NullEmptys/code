package com.hoolai.sangoh5.bo.battle.skill.soldier.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.effect.EnhanceEffect;
import com.hoolai.sangoh5.bo.battle.enhance.effect.PassiveHurtEnhanceEffect;
import com.hoolai.sangoh5.bo.battle.enhance.soldier.ChongfengBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.passive.AttributeEnhanceSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 战斗开始释放冲锋技能，第一次攻击造成N%的伤害
 */
public class ChongFeng extends AttributeEnhanceSkill {

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {

        EnhanceEffect enhanceEffect = new PassiveHurtEnhanceEffect(actor, this, tc).withCanEnhanceTimes(1);
        List<FightUnit> targets = aliveTargetUnitList(tc, actor);
        for (FightUnit target : targets) {
            target.addEnhanceEffect(enhanceEffect);
        }

        actor.addAfterActionBuff(new ChongfengBuff(xmlId, actor.name(), actor, this, Effect.MONITORING_BUFF_LEVEL).withActorName(actor.name()).withTargetName(actor.name())
                .withRepeatCount(MaxRepeatCount).withKeepBuff());
        actor.setMoveSpeed(FightUnit.ROUND_SPEND);

        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]冲锋，并让自己第一次增加攻击伤害比率：" + percentage);
    }

    @Override
    public Skill clone() {
        return super.clone(new ChongFeng());
    }
}
