package com.hoolai.sangoh5.bo.militaryRank.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class MilitaryEffectLeveProperty extends JsonProperty {

    private int needEarNum;

    public int getNeedEarNum() {
        return needEarNum;
    }

    public void setNeedEarNum(int needEarNum) {
        this.needEarNum = needEarNum;
    }

}
