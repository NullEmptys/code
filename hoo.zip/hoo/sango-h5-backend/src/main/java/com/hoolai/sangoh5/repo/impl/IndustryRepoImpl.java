package com.hoolai.sangoh5.repo.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.captive.Captives;
import com.hoolai.sangoh5.bo.farmland.Farmland;
import com.hoolai.sangoh5.bo.item.data.SlaveNpcData;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryEffectType;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryRankProperty;
import com.hoolai.sangoh5.bo.mine.Mine;
import com.hoolai.sangoh5.bo.slave.Slave;
import com.hoolai.sangoh5.bo.slave.Slaves;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.repo.IndustryRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.repo.impl.key.IndustryKey;
import com.hoolai.sangoh5.repo.impl.key.PvpKey;
import com.hoolai.sangoh5.service.BusinessDomainService;
import com.hoolai.sangoh5.service.FarmlandOrMineService;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

@Component("industryRepo")
public class IndustryRepoImpl implements IndustryRepo {

    @Autowired
    @Qualifier("itemClient")
    private ExtendedMemcachedClient client;

    @Autowired
    private BoFactory boFactory;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private FarmlandOrMineService farmlandOrMineService;

    @Autowired
    private SlaveNpcData slaveNpcData;

    @Autowired
    private BusinessDomainService businessDomainService;

    public static volatile int query = 0;

    @Override
    public boolean saveFarmland(Farmland farmland) {
        String key = IndustryKey.getFarmlandKey(farmland.getUserId());
        return client.set(key, farmland.toByteArray());
    }

    @Override
    public Farmland findSimpleFarmland(long userId) {
        String key = IndustryKey.getFarmlandKey(userId);
        Object o = client.get(key);
        Farmland farmland = null;
        if (o == null) {
            farmland = new Farmland(userId);
            farmland.setWorkSlaves(new int[0]);
            return farmland;
        } else {
            farmland = new Farmland(userId, (byte[]) o);
            return farmland;
        }
    }

    @Override
    public Farmland findFarmland(long userId) {
        String key = IndustryKey.getFarmlandKey(userId);
        Object o = client.get(key);
        Farmland farmland = null;
        if (o == null) {
            farmland = new Farmland(userId);
            farmland.setWorkSlaves(new int[0]);
            this.saveFarmland(farmland);
        } else {
            farmland = new Farmland(userId, (byte[]) o);
            farmlandOrMineService.supplementInfo(userId, farmland, null);
        }
        return farmland;
    }

    @Override
    public Slaves findSlaves(long userId) {
        String key = IndustryKey.getSlavesKey(userId);
        Map<Long, byte[]> members = client.smembers2(key);

        return parseSlaves(userId, members);
    }

    private Slaves parseSlaves(long userId, Map<Long, byte[]> members) {
        List<Slave> slaves = new ArrayList<Slave>();
        for (Entry<Long, byte[]> member : members.entrySet()) {
            Slave slave = new Slave(userId, member.getValue());
            User user = userRepo.findUser(slave.getSlaveId());
            slave.initUser(user, slaveNpcData);
            slaves.add(slave);
        }
        Slaves slaves0 = boFactory.createSlaves(userId);
        slaves0.setSlaves(slaves);
        User user = userRepo.findUser(userId);
        MilitaryRankProperty property = businessDomainService.getMilitaryEffectValue(user.getId(), MilitaryEffectType.SLAVENUMADD);
        slaves0.fillExtraAddNum(property == null ? 0 : property.getSlaveNumAdd());
        return slaves0;
    }

    @Override
    public boolean saveSlave(Slave slave) {
        if (slave == null) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
        String key = IndustryKey.getSlavesKey(slave.getUserId());
        if (slave.getId() <= 0) {
            // 添加
            String slaveIdKey = IndustryKey.getUniqueSlaveIdKey(slave.getUserId());
            int slaveId = (int) client.justIncr(slaveIdKey);
            /** incr没有成功??? */
            if (slaveId < 0) {
                boolean setSlave = initSlaveUniqueKey(slave.getUserId());
                if (setSlave) {
                    slaveId = (int) client.justIncr(slaveIdKey);
                } else {
                    return true;
                }
                //                throw new BusinessException(ErrorCode.CAN_NOT_MEM);
            }
            slave.setId(slaveId);
            return client.sadd3(key, slave.toByteArray(), String.valueOf(slaveId));
        }
        return client.sreplace2(key, slave.toByteArray(), slave.getId());
    }

    @Override
    public boolean removeSlave(long userId, int slaveId) {
        String slavesKey = IndustryKey.getSlavesKey(userId);
        boolean isRemove = client.srem2(slavesKey, String.valueOf(slaveId));
        if (isRemove) {
            //        	if(findSlavesCount(userId) <= 0){
            //    			client.set(IndustryKey.getUniqueSlaveIdKey(userId), "0");
            //    		}
            Object o = client.get(slavesKey + "_ids");
            if (o == null) {
                client.delete(slavesKey + "_ids");
            }
        }
        return isRemove;
    }

    @Override
    public Slave findSlave(long userId, int slaveId) {
        String slavesKey = IndustryKey.getSlavesKey(userId);
        byte[] data = (byte[]) client.smember2(slavesKey, slaveId);
        if (data == null) {
            //            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
            return null;
        } else {
            Slave slave = new Slave(userId, data);
            User user = userRepo.findUser(slave.getSlaveId());
            slave.initUser(user, slaveNpcData);
            return slave;
        }
    }

    @Override
    public int findSlavesCount(long userId) {
        String slavesKey = IndustryKey.getSlavesKey(userId);
        return (int) client.scard2(slavesKey);
    }

    @Override
    public boolean initSlaveUniqueKey(long userId) {
        return client.set(IndustryKey.getUniqueSlaveIdKey(userId), "0");
    }

    @Override
    public Captives findCaptives(long userId) {
        String key = IndustryKey.getCaptivesKey(userId);
        Object o = client.get(key);
        Captives captives = null;
        User user = userRepo.findUser(userId);
        if (o == null) {
            captives = new Captives(user);
        } else {
            captives = new Captives(user, (byte[]) o);
        }
        boFactory.inject(captives);
        return captives;
    }

    @Override
    public boolean saveCaptives(Captives captives) {
        String key = IndustryKey.getCaptivesKey(captives.getUserId());
        return client.set(key, captives.toByteArray());
    }

    @Override
    public Mine findMine(long userId) {
        String key = IndustryKey.getMineKey(userId);
        Object o = client.get(key);
        Mine mine = null;
        if (o == null) {
            mine = new Mine(userId);
            mine.setFirstOpenTime(com.hoolai.sango.util.TimeUtil.currentTimeMillis());
            mine.setWorkSlaves(new int[0]);
            this.saveMine(mine);
        } else {
            mine = new Mine(userId, (byte[]) o);
            if (mine.getFirstOpenTime() == 0) {
                mine.setFirstOpenTime(com.hoolai.sango.util.TimeUtil.currentTimeMillis());
            }
            farmlandOrMineService.supplementInfo(userId, null, mine);
        }
        return mine;
    }

    @Override
    public boolean saveMine(Mine mine) {
        String key = IndustryKey.getMineKey(mine.getUserId());
        return client.set(key, mine.toByteArray());
    }

    @Override
    public Mine findSimpleMine(long userId) {
        String key = IndustryKey.getMineKey(userId);
        Object o = client.get(key);
        if (o == null) {
            Mine mine = new Mine(userId);
            mine.setWorkSlaves(new int[0]);
            return mine;
        } else {
            return new Mine(userId, (byte[]) o);
        }
    }

    @Override
    public boolean lockSlave(long userId, int slaveId) {
        String key = IndustryKey.getLockSlaveKey(userId, slaveId);
        boolean lock = client.lock(key, PvpKey.LOCK_CITY_EXPTIME);
        if (!lock) {
            return false;
        }
        return lock;
    }

    @Override
    public boolean unLockSlave(long userId, int slaveId) {
        String key = IndustryKey.getLockSlaveKey(userId, slaveId);
        client.unlock(key);
        return true;
    }

    @Override
    public int findSnatchCount(long userId, String source) {
        String key = IndustryKey.getSnatchKey(userId, source);
        Object obj = client.get(key);
        if (obj == null) {
            return 0;
        }
        return (int) obj;
    }

    @Override
    public boolean saveSnatchCount(long userId, String source, int snatchCount) {
        String key = IndustryKey.getSnatchKey(userId, source);
        return client.set(key, snatchCount);
    }

}
