package com.hoolai.sangoh5.bo.captive;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.sangoh5.bo.IndustryProtocolBuffer.CaptiveProto;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Captive implements ProtobufSerializable<CaptiveProto> {

    private int officerId;

    /**
     * 忠诚值
     */
    private int stubbornValue;

    private long stubbornDay;

    public Captive(int officerId, int stubbornValue) {
        this.officerId = officerId;
        this.stubbornValue = stubbornValue;
        this.stubbornDay = DateUtil.getTodayIntValue();
    }

    public Captive(CaptiveProto message) {
        copyFrom(message);
    }

    transient long userId;

    transient Officer officer;

    public int getOfficerId() {
        return officerId;
    }

    public void setOfficerId(int officerId) {
        this.officerId = officerId;
    }

    public int getStubbornValue() {
        return stubbornValue;
    }

    public void setStubbornValue(int stubbornValue) {
        this.stubbornValue = stubbornValue;
    }

    public Officer getOfficer() {
        return officer;
    }

    public void setOfficer(Officer officer) {
        this.officer = officer;
    }

    public long getUserId() {
        return userId;
    }

    @Override
    public CaptiveProto copyTo() {
        CaptiveProto.Builder builder = CaptiveProto.newBuilder();
        builder.setOfficerId(officerId);
        builder.setStubbornValue(stubbornValue);
        builder.setStubbornDay(stubbornDay);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            CaptiveProto message = CaptiveProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(CaptiveProto message) {
        this.officerId = message.getOfficerId();
        this.stubbornValue = message.getStubbornValue();
        this.stubbornDay = message.getStubbornDay();
    }

    public void deductStubborn(int extraNum) {
        this.stubbornValue -= extraNum;
        if (this.stubbornValue < 0) {
            this.stubbornValue = 0;
        }
    }

    /**
     * 杀鸡儆猴
     */
    public void scareMonkey(int value) {
        this.stubbornValue -= value;
    }

    public boolean isCanConquests() {
        if (stubbornValue <= 0) {
            return true;
        }
        return false;
    }

    public void reflesh() {
        long currDay = DateUtil.getTodayIntValue();
        if (stubbornDay <= 0) {
            this.stubbornDay = currDay;
        } else if (currDay > stubbornDay) {
            long temp = currDay - stubbornDay;
            this.stubbornValue -= temp;
            this.stubbornDay = currDay;
        }
    }

}
