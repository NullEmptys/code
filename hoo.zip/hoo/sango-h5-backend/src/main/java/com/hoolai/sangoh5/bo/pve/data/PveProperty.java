package com.hoolai.sangoh5.bo.pve.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class PveProperty extends JsonProperty{
	
	private String name;
	private int heroStage;
	private int stageBox;
	private String bossHead;
	private int cost;
	private int[] rewardId;
	private int[] rewardNum;
	private String[] rewardType;
	private int[] probability;
	private int monster;
	private int times;
	private String description;
	private int officerExp;
	private int gold;
	private int characterExp;
	private int sweepNum;
	private int singleLandArea;
	private int totalLandArea;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the heroStage
	 */
	public int getHeroStage() {
		return heroStage;
	}
	/**
	 * @param heroStage the heroStage to set
	 */
	public void setHeroStage(int heroStage) {
		this.heroStage = heroStage;
	}
	/**
	 * @return the stageBox
	 */
	public int getStageBox() {
		return stageBox;
	}
	/**
	 * @param stageBox the stageBox to set
	 */
	public void setStageBox(int stageBox) {
		this.stageBox = stageBox;
	}
	/**
	 * @return the bossHead
	 */
	public String getBossHead() {
		return bossHead;
	}
	/**
	 * @param bossHead the bossHead to set
	 */
	public void setBossHead(String bossHead) {
		this.bossHead = bossHead;
	}
	/**
	 * @return the cost
	 */
	public int getCost() {
		return cost;
	}
	/**
	 * @param cost the cost to set
	 */
	public void setCost(int cost) {
		this.cost = cost;
	}
	
	public int[] getRewardId() {
		return rewardId;
	}
	public void setRewardId(int[] rewardId) {
		this.rewardId = rewardId;
	}
	public int[] getRewardNum() {
		return rewardNum;
	}
	public void setRewardNum(int[] rewardNum) {
		this.rewardNum = rewardNum;
	}
	public String[] getRewardType() {
		return rewardType;
	}
	public void setRewardType(String[] rewardType) {
		this.rewardType = rewardType;
	}
	/**
	 * @return the probability
	 */
	public int[] getProbability() {
		return probability;
	}
	/**
	 * @param probability the probability to set
	 */
	public void setProbability(int[] probability) {
		this.probability = probability;
	}
	/**
	 * @return the monster
	 */
	public int getMonster() {
		return monster;
	}
	/**
	 * @param monster the monster to set
	 */
	public void setMonster(int monster) {
		this.monster = monster;
	}
	/**
	 * @return the times
	 */
	public int getTimes() {
		return times;
	}
	/**
	 * @param times the times to set
	 */
	public void setTimes(int times) {
		this.times = times;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * @return the officerExp
	 */
	public int getOfficerExp() {
		return officerExp;
	}
	/**
	 * @param officerExp the officerExp to set
	 */
	public void setOfficerExp(int officerExp) {
		this.officerExp = officerExp;
	}
	public boolean isHeroStage(){
		return this.heroStage == 1;
	}
	public int getGold() {
		return gold;
	}
	public void setGold(int gold) {
		this.gold = gold;
	}
	public int getCharacterExp() {
		return characterExp;
	}
	public void setCharacterExp(int characterExp) {
		this.characterExp = characterExp;
	}
	
	public int getSweepNum() {
		return sweepNum;
	}
	public void setSweepNum(int sweepNum) {
		this.sweepNum = sweepNum;
	}
	public int getSingleLandArea() {
		return singleLandArea;
	}
	public void setSingleLandArea(int singleLandArea) {
		this.singleLandArea = singleLandArea;
	}
	public int getTotalLandArea() {
		return totalLandArea;
	}
	public void setTotalLandArea(int totalLandArea) {
		this.totalLandArea = totalLandArea;
	}
}
