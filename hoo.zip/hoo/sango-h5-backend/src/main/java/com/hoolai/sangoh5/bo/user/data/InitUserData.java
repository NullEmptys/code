package com.hoolai.sangoh5.bo.user.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class InitUserData extends JsonData<InitUserProperty> {

    private static Map<AwardType, List<Award>> INIT_MAP = new HashMap<Award.AwardType, List<Award>>();

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/initUser.json", InitUserProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(InitUserProperty property) {
        if (property.getRewardId().length != property.getRewardNum().length && property.getRewardId().length != property.getRewardType().length) {
            throw new BusinessException(ErrorCode.JSON_TABLE_ERROR);
        }

        int[] rewardIds = property.getRewardId();
        String[] rewardtypes = property.getRewardType();
        int[] rewardNums = property.getRewardNum();

        for (int i = 0; i < rewardIds.length; i++) {
            AwardType awardType = AwardType.converToAwardType(rewardtypes[i]);
            List<Award> awards = INIT_MAP.get(awardType);
            if (awards == null) {
                awards = new ArrayList<Award>();
            }
            awards.add(new Award(rewardIds[i], rewardNums[i], awardType));
            INIT_MAP.put(awardType, awards);
        }

    }

    public Award getAward(AwardType awardType) {
        List<Award> awards = INIT_MAP.get(awardType);
        if (awards == null || awards.size() < 1) {
            return new Award(0, 0, awardType);
        }
        return awards.get(0);
    }

    public List<Award> getAwards(AwardType awardType) {
        return INIT_MAP.get(awardType);
    }

}
