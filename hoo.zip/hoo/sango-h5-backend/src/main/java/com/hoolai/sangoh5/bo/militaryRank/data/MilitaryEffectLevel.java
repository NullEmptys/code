package com.hoolai.sangoh5.bo.militaryRank.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.MilitaryEffectProto;

public class MilitaryEffectLevel implements ProtobufSerializable<MilitaryEffectProto> {

    private int level;

    transient private int type;

    @JsonIgnore
    private MilitaryEffectType militaryEffectType;

    public MilitaryEffectLevel(MilitaryEffectProto message) {
        copyFrom(message);
    }

    public MilitaryEffectLevel() {
    }

    public MilitaryEffectType getMilitaryEffectType() {
        return militaryEffectType;
    }

    public void setMilitaryEffectType(MilitaryEffectType militaryEffectType) {
        this.militaryEffectType = militaryEffectType;
        this.type = militaryEffectType.getId();
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public MilitaryEffectProto copyTo() {
        MilitaryEffectProto.Builder builder = MilitaryEffectProto.newBuilder();
        builder.setLevel(level);
        builder.setEffectType(this.militaryEffectType.getMilitaryEffectType());
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            copyFrom(MilitaryEffectProto.parseFrom(bytes));
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void copyFrom(MilitaryEffectProto message) {
        this.level = message.getLevel();
        this.militaryEffectType = MilitaryEffectType.converToMilitaryEffectType(message.getEffectType());
        this.type = this.militaryEffectType.getId();
    }

}
