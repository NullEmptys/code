package com.hoolai.sangoh5.bo.mission.data;

import java.util.List;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * 任务配置表
 * 
 * @author hp
 *
 */
public class MissionDefine extends JsonProperty {

    public static final int LEVEL_UNLIMIT = 0;// 无等级限制

    public static final int CANT_NOT_USER = 0;// 无前置任务或不继承

    public static final int INHERIT = 1;// 继承

    public static final int AUTO_REWARD = 1;// 自动领奖

    public static final int AUTO_FINISH = 1;//添加任务时检测任务状态

    /** 任务分类 */
    private int category;

    /** 任务属性 */
    private int property;

    /** 任务开启等级限制,0为无等级限制 */
    private int limitLevel;

    /** 任务达成条件参数策划需求 */
    private int condition;

    /** 达成目标参数 */
    private int target;

    /** 前置任务id 0 不适用此记录 */
    private int limitMissionId;

    /** 继承上一个统计值0不适用此字段1继承 */
    private int isInherit;

    /** 任务的奖励 */
    private List<Integer> rewardIds;

    private List<String> rewardTypes;

    private List<Integer> rewardNums;

    /** 是否自动领取奖励 */
    private int isAutoGetReward;

    /** 是否在开启时检测任务状态 */
    private int sign;

    /** 任务描述 **/
    private String description;
    
    private int activeVal;

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public int getProperty() {
        return property;
    }

    public void setProperty(int property) {
        this.property = property;
    }

    public int getLimitLevel() {
        return limitLevel;
    }

    public void setLimitLevel(int limitLevel) {
        this.limitLevel = limitLevel;
    }

    public int getCondition() {
        return condition;
    }

    public void setCondition(int condition) {
        this.condition = condition;
    }

    public int getTarget() {
        return target;
    }

    public void setTarget(int target) {
        this.target = target;
    }

    public int getLimitMissionId() {
        return limitMissionId;
    }

    public void setLimitMissionId(int limitMissionId) {
        this.limitMissionId = limitMissionId;
    }

    public int getIsInherit() {
        return isInherit;
    }

    public void setIsInherit(int isInherit) {
        this.isInherit = isInherit;
    }

    public List<Integer> getRewardIds() {
        return rewardIds;
    }

    public void setRewardIds(List<Integer> rewardIds) {
        this.rewardIds = rewardIds;
    }

    public List<String> getRewardTypes() {
        return rewardTypes;
    }

    public void setRewardTypes(List<String> rewardTypes) {
        this.rewardTypes = rewardTypes;
    }

    public List<Integer> getRewardNums() {
        return rewardNums;
    }

    public void setRewardNums(List<Integer> rewardNums) {
        this.rewardNums = rewardNums;
    }

    public int getIsAutoGetReward() {
        return isAutoGetReward;
    }

    public void setIsAutoGetReward(int isAutoGetReward) {
        this.isAutoGetReward = isAutoGetReward;
    }

    public int getSign() {
        return sign;
    }

    public void setSign(int sign) {
        this.sign = sign;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getActiveVal() {
		return activeVal;
	}

	public void setActiveVal(int activeVal) {
		this.activeVal = activeVal;
	}

	@Override
    public String toString() {
        return "MissionDefine [category=" + category + ", property=" + property + ", limitLevel=" + limitLevel + ", condition=" + condition + ", target=" + target
                + ", limitMissionId=" + limitMissionId + ", isInherit=" + isInherit + ", rewardIds=" + rewardIds + ", rewardTypes=" + rewardTypes + ", rewardNums=" + rewardNums
                + ", isAutoGetReward=" + isAutoGetReward + ", sign=" + sign + "]";
    }

}
