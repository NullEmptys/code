package com.hoolai.sangoh5.bo.activity;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 14:22
 * @version : 1.0
 */
public enum ActivityId {
    /**
     * 首充
     */
    FirstPay(1),

    /**
     * 连续登录
     */
    CumulativeLogin(2),

    /**
     * 月卡
     */
    MonthCard(3),

    /**
     * 周卡
     */
    WeekCard(4),

    /**
     * 等级礼包
     */
    LevelGift(5),

    /**
     * 神兵天将
     */
    SpecialSoldier(6),

    /**
     * 十连抽
     */
    Luckdraw(7),

    /**
     * 转盘
     */
    LuckyWheel(8),

    /**
     * 累计消费
     */
    CumulativePay(9),

    /**
     * 邀请
     */
    Invite(10),

    /**
     * 关注
     */
    Focuson(11),

    /**
     * pc 版充值活动
     */
    Recharge(12),

    /**
     * pc 登录活动
     */
    LoginGift(13),

    /**
     * 阖家欢
     */
    Family(14),

    /**
     * 图特摩斯
     */
    Thutmose(15),;

    private final int id;

    private ActivityId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public static ActivityId valueOf(int activityId) {
        switch (activityId) {
            case 1:
                return FirstPay;
            case 2:
                return CumulativeLogin;
            case 3:
                return MonthCard;
            case 4:
                return WeekCard;
            case 5:
                return LevelGift;
            case 6:
                return SpecialSoldier;
            case 7:
                return Luckdraw;
            case 8:
                return LuckyWheel;
            case 9:
                return CumulativePay;
            case 10:
                return Invite;
            case 11:
                return Focuson;
            case 12:
                return Recharge;
            case 13:
                return LoginGift;
            case 14:
                return Family;
            case 15:
                return Thutmose;
            default:
                break;
        }
        throw new RuntimeException("not found activityId " + activityId);
    }

    public static boolean needRefresh(int activityId) {
        return activityId == LuckyWheel.getId() || activityId == Luckdraw.getId() || activityId == Recharge.getId();
    }

}
