package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hoolai.sangoh5.bo.battle.enhance.buff.CounterAttackBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.Counterattack;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 给自己或者自己的士兵赋予一个反击的技能，持续一段时间后消失
 * 
 * @author Administrator
 *
 */
public class CounterattackActiveSkill extends IndependentSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();
        boolean isAttacker = actor.isAttacker();

        Counterattack counterattack = new Counterattack();
        counterattack.setXmlId(this.xmlId);
        counterattack.setPercentage(this.percentage);

        int index = pg.getRandomNumber(0, 1);

        if (index == 0 && !actor.isHaveDefencePassiveSkill(this.xmlId)) {
            actor.addCounterAttackSkills(counterattack);
            actor.addBuff(new CounterAttackBuff(xmlId, actor.name(), counterattack, currentLevel).withActorName(actor.name()).withTargetName(actor.name()).withKeepBuff()
                    .withRepeatCount(repeatCount));
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给自己增加一个反击类技能,持续回合数=" + repeatCount);
        } else {
            Map<FightUnitName, FightUnit> aliveMap = tc.aliveTargetSoldier(!isAttacker);// 获取自己方的士兵
            Set<FightUnitName> keySet = aliveMap.keySet();
            for (FightUnitName name : keySet) {
                FightUnit target = aliveMap.get(name);
                if (target.isHaveDefencePassiveSkill(this.xmlId)) {
                    continue;
                }
                target.addCounterAttackSkills(counterattack);
                target.addBuff(new CounterAttackBuff(xmlId, target.name(), counterattack, currentLevel).withActorName(actor.name()).withTargetName(target.name()).withKeepBuff()
                        .withRepeatCount(repeatCount));

                actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "增加一个反击类技能,持续回合数=" + repeatCount);
                targets.add(target);
                break;
            }
        }
        return targets;
    }

    @Override
    public Skill clone() {
        return super.clone(new CounterattackActiveSkill());
    }

}
