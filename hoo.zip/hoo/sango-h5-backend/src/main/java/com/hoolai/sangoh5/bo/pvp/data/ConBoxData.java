package com.hoolai.sangoh5.bo.pvp.data;

import java.util.Collections;
import java.util.List;

import com.google.common.collect.Lists;
import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.util.json.JsonData;

public abstract class ConBoxData<T extends ConBoxReward> extends JsonData<T> {

    public List<Award> findRewardByContribute(ConBoxReward property) {
        if (property == null) {
            return Collections.emptyList();
        }
        int rewardLength = property.getRewardTypes().length;
        List<Award> awardList = Lists.newArrayListWithExpectedSize(rewardLength);
        for (int i = 0; i < rewardLength; i++) {
            awardList.add(new Award(property.getRewardIds()[i], property.getRewardNums()[i], AwardType.converToAwardType(property.getRewardTypes()[i])));
        }
        return awardList;
    }

    public ConBoxReward getBoxRewardByContribute(int contribute) {
        if (contribute <= 0) {
            return null;
        }
        for (ConBoxReward property : propertyMap.values()) {
            if (property.contains(contribute)) {
                return property;
            }
        }
        return null;
    }

    public List<Award> getRewardByContribute(int contirbute) {
        ConBoxReward reward = getBoxRewardByContribute(contirbute);
        if (reward == null) {
            return Collections.emptyList();
        }
        return findRewardByContribute(reward);
    }

}
