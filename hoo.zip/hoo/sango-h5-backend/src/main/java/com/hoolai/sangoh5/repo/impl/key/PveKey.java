package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class PveKey {

    private static final String prefix = "pve";

    public static String getChaptersKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("cid").toString();
    }

    public static String getProvisionKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("pid").toString();
    }

    public static String getExchangeOfficerKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("officer").toString();
    }

    public static String getCartoonStartKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("cartoonStar").toString();
    }

    public static String getCartoonEndKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("cartoonEnd").toString();
    }

    public static String getUseItemKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("addProvision").toString();
    }

}
