package com.hoolai.sangoh5.bo.activity;

import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.CdkeyProto;
import com.hoolai.sangoh5.bo.award.Award;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-26 19:25
 * @version : 1.0
 */
public class Cdkey implements ProtobufSerializable<CdkeyProto> {

    /** 兑换id **/
    private int id;

    /** 礼包名称 **/
    private String name;

    /** keys 列表 **/
    private Set<String> keys;

    /** 可兑换次数 **/
    private int maxCount;

    /** 奖励列表 **/
    private List<Award> awardList;

    /** 当前兑换次数 **/
    private transient int times;

    public Cdkey(int id, String name, Set<String> keys, int times, List<Award> awardList) {
        this.id = id;
        this.name = name;
        this.keys = keys;
        maxCount = times;
        this.awardList = awardList;
    }

    public Cdkey(CdkeyProto message) {
        copyFrom(message);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Set<String> getKeys() {
        return keys;
    }

    public int getMaxCount() {
        return maxCount;
    }

    public List<Award> getAwardList() {
        return awardList;
    }

    public int getTimes() {
        return times;
    }

    public void setTimes(int times) {
        this.times = times;
    }

    @Override
    public CdkeyProto copyTo() {
        CdkeyProto.Builder builder = CdkeyProto.newBuilder();
        builder.setId(id);
        builder.setName(name);
        if (CollectionUtils.isNotEmpty(keys)) {
            for (String key : keys) {
                builder.addKeys(key);
            }
        }
        builder.setMaxCount(maxCount);
        if (CollectionUtils.isNotEmpty(awardList)) {
            for (Award aw : awardList) {
                builder.addAwards(aw.copyTo());
            }
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            copyFrom(CdkeyProto.parseFrom(bytes));
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void copyFrom(CdkeyProto message) {
        this.id = message.getId();
        this.name = message.getName();
        int count = message.getKeysCount();
        this.keys = Sets.newHashSetWithExpectedSize(count);
        for (int i = 0; i < count; i++) {
            keys.add(message.getKeys(i));
        }
        this.maxCount = message.getMaxCount();
        count = message.getAwardsCount();
        this.awardList = Lists.newArrayListWithExpectedSize(count);
        for (int i = 0; i < count; i++) {
            this.awardList.add(new Award(message.getAwards(i)));
        }
    }

    public String getAwards() {
        StringBuilder sb = new StringBuilder();
        for (Award award : awardList) {
            sb.append(award.getAwardType().getAwartType()).append(":").append(award.getXmlId()).append(":").append(award.getNum()).append(",");
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }

    public String getCdkey() {
        StringBuilder sb = new StringBuilder();
        for (String key : keys) {
            sb.append(key).append(",");
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }

    public void update(String key, List<Award> awardList) {
        this.keys = Sets.newHashSet(key);
        this.awardList = awardList;
    }
}
