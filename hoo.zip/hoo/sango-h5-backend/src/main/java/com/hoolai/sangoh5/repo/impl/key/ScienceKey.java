package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class ScienceKey {

    public static final String prefix = "science";

    public static String getSoldierTechnologiesKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("1").toString();
    }

}
