package com.hoolai.sangoh5.bo.pve.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class ChapterProperty extends JsonProperty {

    private String name;

    private int isUnlock;

    private int[] star;

    private int[] boxId;

    private String description;

    private int[] stageId;

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the star
     */
    public int[] getStar() {
        return star;
    }

    /**
     * @param star the star to set
     */
    public void setStar(int[] star) {
        this.star = star;
    }

    /**
     * @return the boxId
     */
    public int[] getBoxId() {
        return boxId;
    }

    /**
     * @param boxId the boxId to set
     */
    public void setBoxId(int[] boxId) {
        this.boxId = boxId;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the stageId
     */
    public int[] getStageId() {
        return stageId;
    }

    /**
     * @param stageId the stageId to set
     */
    public void setStageId(int[] stageId) {
        this.stageId = stageId;
    }

    /**
     * @return the isUnlock
     */
    public int getIsUnlock() {
        return isUnlock;
    }

    /**
     * @param isUnlock the isUnlock to set
     */
    public void setIsUnlock(int isUnlock) {
        this.isUnlock = isUnlock;
    }

}
