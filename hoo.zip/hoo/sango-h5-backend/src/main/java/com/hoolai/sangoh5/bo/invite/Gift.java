package com.hoolai.sangoh5.bo.invite;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.WanBaInviteProtocolBuffer.GiftProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Gift implements ProtobufSerializable<GiftProto>{

	private long userId;
	
	private boolean isGet;
	
	private int lastGetTime;
	
	public Gift() {
    }

    public Gift(long userId) {
        this.userId = userId;
    }

    public Gift(long userId, byte[] bytes) {
        this(userId);
        parseFrom(bytes);
    }

	@Override
	public GiftProto copyTo() {
		GiftProto.Builder builder = GiftProto.newBuilder();
        builder.setIsGet(isGet);
        builder.setLastGetTime(lastGetTime);
        return builder.build();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			GiftProto message = GiftProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
	}

	@Override
	public void copyFrom(GiftProto message) {
		this.isGet = message.getIsGet();
		this.lastGetTime = message.getLastGetTime();
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public boolean isGet() {
		return isGet;
	}

	public void setGet(boolean isGet) {
		this.isGet = isGet;
	}

	public int getLastGetTime() {
		return lastGetTime;
	}

	public void setLastGetTime(int lastGetTime) {
		this.lastGetTime = lastGetTime;
	}
	
	public void reset(int lastUpdateTime){
		isGet = false;
		lastGetTime = lastUpdateTime;
	}
}
