package com.hoolai.sangoh5.bo.shop.data;

import java.io.IOException;
import javax.annotation.PostConstruct;
import org.springframework.stereotype.Component;

@Component
public class RankFightShopData extends ShopData{

	@PostConstruct
	public void init() {
		try {
			initData("com/hoolai/sangoh5/rankGoods.json", ShopProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

