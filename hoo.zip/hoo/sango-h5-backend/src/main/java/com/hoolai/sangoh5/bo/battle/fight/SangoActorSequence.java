package com.hoolai.sangoh5.bo.battle.fight;

import java.util.EnumMap;

import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.tacticalManagement.Formation;

/**
 * 出手队列
 */
public class SangoActorSequence implements ActorSequence {

    /** 出手者（即战斗单元）map[战斗单元名称：战斗单元] **/
    private EnumMap<FightUnitName, FightUnit> actors = new EnumMap<FightUnitName, FightUnit>(FightUnitName.class);

    private boolean currentActorIsAttacker = false; //默认当前先手方为防守方

    private FightUnitName currentActorName; //当前回手出名战斗单位名称

    private SoliderSequence soliderSequence;

    public SangoActorSequence(Formation attackFormation, Formation defenceFormation) {
        this.soliderSequence = new SoliderSequence(attackFormation, defenceFormation);
    }

    @Override
    public FightUnit next() {
        return actors.get(currentActorName);
    }

    @Override
    public void put(FightUnit actor) {
        actors.put(actor.name(), actor);
    }

    @Override
    public void remove(FightUnit actor) {
        actors.remove(actor.name());
    }

    @Override
    public boolean isNextRoundTurn() {
        return isNextSoldierRoundTurn();
    }

    private boolean isNextSoldierRoundTurn() {
        while (soliderSequence.hasAttackNext()) {
            this.currentActorName = soliderSequence.attackNext();
            if (actors.get(currentActorName) == null) {
                this.currentActorName = null;
                continue;
            }
            return false;
        }

        return true;
    }

    @Override
    public void endCurrentRound() {
        this.currentActorIsAttacker = !this.currentActorIsAttacker;
        this.soliderSequence.reset();
    }

    @Override
    public boolean currentActorIsAttacker() {
        return currentActorIsAttacker;
    }

}
