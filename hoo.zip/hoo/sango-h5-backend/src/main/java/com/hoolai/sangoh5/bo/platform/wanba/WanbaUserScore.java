package com.hoolai.sangoh5.bo.platform.wanba;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.WanbaUserScoreProto;

public class WanbaUserScore implements ProtobufSerializable<WanbaUserScoreProto>{

	private boolean is_vip;
	private int vip_level;
	private int score;
	private long expiredtime;
	
	public WanbaUserScore(){
		
	}
	
	public WanbaUserScore(WanbaUserScoreProto proto) {
		copyFrom(proto);
	}
	
	public void decrScore(int cost) {
		score = Math.max(0, score - cost);
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			copyFrom(WanbaUserScoreProto.parseFrom(bytes));
		} catch (InvalidProtocolBufferException ex) {
			throw new IllegalArgumentException(ex);
		}
	}

	@Override
	public void copyFrom(WanbaUserScoreProto proto) {
		is_vip = proto.getIsVip();
		vip_level = proto.getVipLevel();
		score = proto.getScore();
		expiredtime = proto.getExpiredtime();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public WanbaUserScoreProto copyTo() {
		WanbaUserScoreProto.Builder builder = WanbaUserScoreProto.newBuilder();
		builder.setIsVip(is_vip);
		builder.setVipLevel(vip_level);
		builder.setScore(score);
		builder.setExpiredtime(expiredtime);
		return builder.build();
	}
	
	@Override
	public String toString() {
		return "TencentWanbaUserScore [expiredtime=" + expiredtime + ", is_vip=" + is_vip + ", score=" + score + ", vip_level=" + vip_level + "]";
	}
	
	public boolean getIs_vip() {
		return is_vip;
	}
	public void setIs_vip(boolean isVip) {
		is_vip = isVip;
	}
	public int getVip_level() {
		return vip_level;
	}
	public void setVip_level(int vipLevel) {
		vip_level = vipLevel;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public long getExpiredtime() {
		return expiredtime;
	}
	public void setExpiredtime(long expiredtime) {
		this.expiredtime = expiredtime;
	}
	
}
