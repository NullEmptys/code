package com.hoolai.sangoh5.event;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 17:30
 * @version : 1.0
 */
public interface EventDispatcher {

    public void subscribe(EventType eventType, EventSubscriber<?> eventSubscriber);

    public void publish(Event event);

    public void dispatch(Event event);

}
