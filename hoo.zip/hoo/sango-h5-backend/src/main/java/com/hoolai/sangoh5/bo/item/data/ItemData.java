package com.hoolai.sangoh5.bo.item.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillData;
import com.hoolai.sangoh5.bo.item.ItemBag;
import com.hoolai.sangoh5.util.json.JsonData;


@Component
public class ItemData extends JsonData<ItemProperty>{
    
    @PostConstruct
    public void init(){
        try {
            initData("com/hoolai/sangoh5/item.json", ItemProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(ItemProperty property) {
        // TODO Auto-generated method stub
        
    }
    
    /**
     * 分类返回所有的装备
     */
    public static Map<String, Object> classifyItemBagList(BoFactory boFactory,List<ItemBag> itemBagList){
        ItemData itemData = boFactory.getItemData();
        SkillData skillData = boFactory.getSkillData();
        MaterialData materialData = boFactory.getMaterialData();
        List<ItemBag> itemBags = new ArrayList<ItemBag>();
        List<ItemBag> skillBags = new ArrayList<ItemBag>();
        List<ItemBag> materialBags = new ArrayList<ItemBag>();
        List<ItemBag> pieceBags = new ArrayList<ItemBag>();
        for (ItemBag itemBag:itemBagList) {
            int xmlId = itemBag.getXmlId();
            if(itemData.getProperty(xmlId)!=null){
                itemBags.add(itemBag);
            }else if(skillData.getProperty(xmlId)!=null){
                skillBags.add(itemBag);
            }else if (materialData.getProperty(xmlId) != null) {
                materialBags.add(itemBag);
            }
        }
        Map<String,Object> resut = new HashMap<String, Object>();
        resut.put("itemBagList", itemBags);
        resut.put("skillBags", skillBags);
        resut.put("materialBags", materialBags);
        resut.put("pieceBags", pieceBags);
        return resut;
    }
}
