package com.hoolai.sangoh5.bo.rescue;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.tuple.Pair;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.pve.data.MonsterData;
import com.hoolai.sangoh5.bo.pvp.Camps;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.bo.user.data.NameData;
import com.hoolai.sangoh5.repo.OfficerRepo;
import com.hoolai.sangoh5.repo.PvpRepo;
import com.hoolai.sangoh5.repo.RescueRepo;
import com.hoolai.sangoh5.repo.UserRepo;

public class OccupyObjs {

    private static final int[] rang = new int[] { 0, -1, 1, -2, 2, -3, 3, -4, 4, -5 };

    private PvpRepo pvpRepo;

    private UserRepo userRepo;

    private RescueRepo rescueRepo;

    private OfficerRepo officerRepo;

    private MonsterData monsterData;

    private User user;

    private NameData nameData;

    public OccupyObjs() {
    }

    public void inject(PvpRepo pvpRepo, UserRepo userRepo, RescueRepo rescueRepo, OfficerRepo officerRepo, MonsterData monsterData, User currentUser, NameData nameData) {
        this.pvpRepo = pvpRepo;
        this.userRepo = userRepo;
        this.rescueRepo = rescueRepo;
        this.officerRepo = officerRepo;
        this.monsterData = monsterData;
        this.user = currentUser;
        this.nameData = nameData;
    }

    /**
     * 获取悬赏列表
     * 
     * @param currentUser
     * @return
     */
    public List<OccupyObj> findRescueList(User currentUser) {
        int rank = currentUser.getRank();
        long userId = currentUser.getId();

        List<OccupyObj> list = findOccupyInfos(rank, userId);
        if (CollectionUtils.isEmpty(list)) {
            list = Lists.newArrayListWithExpectedSize(Constants.choiceNum);
        }
        int tempSize = list.size();
        for (int i = 0; i < Constants.choiceNum - tempSize; i++) {
            int generPvpMonsterXmlId = monsterData.generPvpMonsterXmlId();
            OccupyObj occupyObj = new OccupyObj();
            occupyObj.setOccupyObjInfo(generPvpMonsterXmlId, nameData.getRandomName());
            list.add(occupyObj);
        }
        return list;
    }

    /**
     * 根据当前用户等级获取已经占城的列表信息
     * 
     * @return 若此等级满足条件用户大于3个，则返回，若不足3个继续循环
     */
    public List<OccupyObj> findOccupyInfos(int rank, long userId) {
        Set<Pair<Long, Long>> occupyIdsSet = Sets.newHashSetWithExpectedSize(8);

        Camps camps = pvpRepo.findCamps();

        List<Pair<Integer, Integer>> keyGroups = camps.findStateKeyGroups(user.getSangoState());

        for (int differ : rang) {
            int level = rank + differ;
            Set<Pair<Long, Long>> memberIds = rescueRepo.findOccupyUserIds(keyGroups, level);
            if (CollectionUtils.isEmpty(memberIds)) {
                continue;
            }
            occupyIdsSet.addAll(memberIds);
            if (occupyIdsSet.size() >= 3) {
                break;
            }
        }
        if (CollectionUtils.isEmpty(occupyIdsSet)) {
            return Collections.emptyList();
        }
        Set<OccupyInfo> occupyInfos = rescueRepo.findOccupyInfos(occupyIdsSet, user.getId());
        return changeOccupyObj(occupyInfos);
    }

    private List<OccupyObj> changeOccupyObj(Set<OccupyInfo> occupyInfos) {
        if (CollectionUtils.isEmpty(occupyInfos)) {
            return Collections.emptyList();
        }

        Set<Long> userIds = Sets.newHashSetWithExpectedSize(occupyInfos.size());
        Map<Pair<Long, Integer>, OccupyInfo> officerUserIds = Maps.newHashMapWithExpectedSize(occupyInfos.size());
        for (OccupyInfo occupyInfo : occupyInfos) {
            userIds.add(occupyInfo.getOccupyId());
            officerUserIds.put(Pair.of(occupyInfo.getOccupyId(), occupyInfo.getOfficerId()), occupyInfo);
            if (officerUserIds.size() >= Constants.choiceNum) {
                break;
            }
        }
        Set<Pair<Long, Integer>> keySet = officerUserIds.keySet();

        Map<Long, User> userMap = userRepo.getUsersByUserIds(userIds);
        Map<Pair<Long, Integer>, Officer> userOfficers = officerRepo.getUserOfficers(keySet);

        List<OccupyObj> tempList = Lists.newArrayListWithExpectedSize(userIds.size());
        for (Pair<Long, Integer> key : keySet) {
            OccupyInfo occupyInfo = officerUserIds.get(key);
            User user = userMap.get(key.getLeft());
            Officer officer = userOfficers.get(key);

            tempList.add(occupyInfo.transform(user, officer));
        }
        return tempList;
    }
}
