package com.hoolai.sangoh5.bo.rescue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.bo.award.AwardChannel;
import com.hoolai.sangoh5.bo.award.AwardProcessor;
import com.hoolai.sangoh5.bo.barrack.Barrack;
import com.hoolai.sangoh5.bo.battle.BattleObjFoctory;
import com.hoolai.sangoh5.bo.battle.fight.Battle;
import com.hoolai.sangoh5.bo.battle.fight.BattleResult;
import com.hoolai.sangoh5.bo.battle.fight.BattleType;
import com.hoolai.sangoh5.bo.city.MainCity;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.bo.item.Item;
import com.hoolai.sangoh5.bo.item.data.ItemData;
import com.hoolai.sangoh5.bo.item.data.ItemProperty;
import com.hoolai.sangoh5.bo.mission.data.ClientMission;
import com.hoolai.sangoh5.bo.mission.data.MissionProperty;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.pve.data.MonsterData;
import com.hoolai.sangoh5.bo.pvp.Camps;
import com.hoolai.sangoh5.bo.pvp.Contribute.PvpBattleType;
import com.hoolai.sangoh5.bo.pvp.PvpUser;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.event.EventDispatcher;
import com.hoolai.sangoh5.event.event.MissionEvent;
import com.hoolai.sangoh5.event.event.RescueEvent;
import com.hoolai.sangoh5.repo.BarrackRepo;
import com.hoolai.sangoh5.repo.OfficerRepo;
import com.hoolai.sangoh5.repo.PvpRepo;
import com.hoolai.sangoh5.repo.RescueRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.service.BattleDomainService;
import com.hoolai.sangoh5.service.mission.MissionEngine;
import com.hoolai.sangoh5.util.ProbabilityGenerator;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class RescueFightAction {

    private static final Log logger = LogFactory.getLog(RescueFightAction.class);

    private MonsterData monsterData;

    private OfficerRepo officerRepo;

    private BarrackRepo barrackRepo;

    private UserRepo userRepo;

    private BattleObjFoctory battleObjFoctory;

    private BoFactory boFactory;

    private Officer attackOfficer;

    private Officer defenceOfficer;

    private BattleResult battleResult;

    private AwardProcessor awardProcessor;

    private BattleDomainService battleDomainService;

    private RescueRepo rescueRepo;

    private MissionEngine missionEngine;

    private PvpRepo pvpRepo;

    private ItemData itemData;

    private ConstantsPoolData constantsPool;

    private ProbabilityGenerator pg;

    private final User attackUser;

    private User defUser;

    private User beRescueUser;

    private final long beRescueUserId;

    private final int officerId;

    private Barrack barrack;

    private MainCity mainCity;

    private List<ClientMission> changedMission = new ArrayList<ClientMission>();

    private final boolean isNpc;

    private EventDispatcher eventDispatcher;

    public RescueFightAction(User attackUser, long beRescueUserId, int officerId) {
        this.attackUser = attackUser;
        this.beRescueUserId = beRescueUserId;
        this.officerId = officerId;
        this.isNpc = beRescueUserId <= 0 ? true : false;
    }

    public void inject(BattleDomainService battleDomainService, MissionEngine missionEngine, RescueRepo rescueRepo, EventDispatcher eventDispatcher, BoFactory boFactory) {
        this.boFactory = boFactory;
        this.monsterData = boFactory.getMonsterData();
        this.barrackRepo = boFactory.getBarrackRepo();
        this.officerRepo = boFactory.getOfficerRepo();
        this.battleDomainService = battleDomainService;
        this.pvpRepo = boFactory.getPvpRepo();
        this.userRepo = boFactory.getUserRepo();
        this.missionEngine = missionEngine;
        this.rescueRepo = rescueRepo;
        this.itemData = boFactory.getItemData();
        this.pg = boFactory.getPg();
        this.constantsPool = boFactory.getConstantsPool();
        this.eventDispatcher = eventDispatcher;
        this.battleObjFoctory = boFactory.getBattleObjFoctory();
    }

    private void initFight() {
        long userId = attackUser.getId();

        barrack = barrackRepo.findBarrack(userId);
        attackOfficer = officerRepo.findOfficer(userId, officerId);// 攻击方
        attackOfficer.checkAndTroops(barrack);

        if (isNpc) {
            defUser = new User();
            defUser.toNpcUser(attackUser.getRank());
            defenceOfficer = monsterData.generPvpMonster();
        } else {
            mainCity = pvpRepo.findMainCity(beRescueUserId);
            defUser = userRepo.findUser(mainCity.getLordId());
            defenceOfficer = officerRepo.findOfficer(defUser.getId(), mainCity.getOfficerId());
            beRescueUser = userRepo.findUser(beRescueUserId);
        }

        if (attackUser == null || defUser == null || attackOfficer == null || defenceOfficer == null) {
            throw new BusinessException(ErrorCode.USER_IS_NULL);
        }
    }

    public void fight() {
        this.initFight();
        this.battle();
        this.afterFight();
    }

    private void battle() {
        try {
            Battle battle = battleObjFoctory.createBattle(BattleType.NORMAL, attackUser, defUser, attackOfficer, defenceOfficer);
            battleResult = battle.fight();
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException(ErrorCode.SYSTEM_ERROR);
        }
    }

    private void afterFight() {
        this.awardProcessor = getAwardsAfterFight();
    }

    private void addRandomItem(List<Award> awards, int rank) {
        int currentItemId = 0;
        for (int i = 0; i < Item.KEYGROUP.length; i++) {
            ItemProperty item = itemData.getProperty(Item.KEYGROUP[i]);
            if (rank >= item.getValue() && rank <= item.getValueOfDonate()) {
                currentItemId = Item.KEYGROUP[i];
                break;
            }
        }

        boolean isDrop = pg.getRandomWithPercentage(constantsPool.getProperty(currentItemId).getValue());
        if (isDrop) {
            awards.add(new Award(currentItemId, 1, AwardType.ITEM));
        }

        int size = 0;
        for (int i = 0; i < Item.DONATIONITEM.length; i++) {
            size += constantsPool.getProperty(Item.DONATIONITEM[i]).getValue();
        }
        int random = pg.getRandomNumber(size);
        int currentDonation = 0;
        int temp = 0;
        for (int i = 0; i < Item.DONATIONITEM.length; i++) {
            temp += constantsPool.getProperty(Item.DONATIONITEM[i]).getValue();
            if (temp >= random) {
                currentDonation = Item.DONATIONITEM[i];
                break;
            }
        }
        if (currentDonation != 0) {
            awards.add(new Award(currentDonation, 1, AwardType.ITEM));
        }
    }

    private PvpUser findPvpUser(long userId, int stateId, int militaryRank) {

        if (userId > 0) {
            PvpUser occupyedPvpUser = pvpRepo.findPvpUser(userId);

            if (occupyedPvpUser == null) {
                Camps camps = pvpRepo.findCamps();
                occupyedPvpUser = new PvpUser(userId, stateId);
                occupyedPvpUser.reflesh(camps);
                pvpRepo.savePvpUser(occupyedPvpUser);
            }

            return occupyedPvpUser;
        } else {
            return new PvpUser(userId, stateId, militaryRank);
        }
    }

    public Map<String, Object> drawRewards() {
        return awardProcessor.awardResult();
    }

    private AwardProcessor getAwardsAfterFight() {
        List<Award> awards = new ArrayList<Award>();
        AwardProcessor awardProcessorTemp = boFactory.createAwardProcessor(attackUser.getId(), AwardChannel.AreanFight);
        if (isNpc) {
            if (battleResult.isAttackerBattleWin()) {
                PvpUser pvpUser = findPvpUser(attackUser.getId(), attackUser.getSangoState(), attackUser.getMilitaryRank());
                battleDomainService.calPvpUserRescueContribute(pvpUser, null, true);
                battleDomainService.calUnionRescueContribute(attackUser, null, true);

                awards.add(battleDomainService.getMilitaryExploit(battleResult.getAttackArmyCurrLostPoint(), battleResult.getDefenceArmyCurrLostPoint(),
                        (int) (Math.round(attackUser.getRank() / 5.0) + 1)));

                addRandomItem(awards, attackUser.getRank());
                awards.add(battleDomainService.giveHonorAwards(attackUser.getId(), attackUser.getMilitaryRank()));
                awards.add(new Award(Award.leftEar, 8, AwardType.LEFTEAR));
            }
            barrack.addSoldier(battleResult.getAttackArmy().findSoldierNumber());
            attackOfficer.backBarrack();
            barrackRepo.saveBarrack(barrack);
            officerRepo.updateOfficer(attackOfficer);
            awardProcessorTemp.transforAward(awards);
            awardProcessorTemp.awardPesistent(battleResult.getAttackPerfectUser());
            battleResult.setAttackPerfectUser(battleResult.getAttackPerfectUser());
        } else {
            //FIXME 解决之后mainCity为空城
            long occupyTime = mainCity.getOccupyStartTime();
            long defferUserId = mainCity.getLordId();
            AwardProcessor battleAwardProcessor = battleDomainService.processAfterBattle(mainCity, beRescueUser, barrack, battleResult, PvpBattleType.rescue);
            RescueLimitation defferRescueRec = rescueRepo.findRescueLimitation(defferUserId);
            if (battleResult.isAttackerBattleWin()) {
                userRepo.changeCityStatus(beRescueUser, mainCity, MainCity.status_occupy);
                pvpRepo.saveMainCity(mainCity);
                int day = Utils.getOccupyDays(TimeUtil.currentTimeMillis() - occupyTime) == 0 ? 1 : Utils.getOccupyDays(TimeUtil.currentTimeMillis() - occupyTime);
                //                awards.add(new Award(Award.gold, Math.min(40 * day * defUser.getRank(), 50000), AwardType.GOLD));

                awards.add(new Award(Award.leftEar, Math.min(8 + (day - 1) * 2, 20), AwardType.LEFTEAR));
                battleAwardProcessor.transforAward(awards);
                awardProcessorTemp.transforAward(awards);
                awardProcessorTemp.awardPesistent(battleResult.getAttackPerfectUser());
                awardProcessorTemp = battleAwardProcessor;
                //                    // -------发送邮件抵御多少次攻击 尚闯说不要了
                //                    MessageInfos messageInfos = messageInfosRepo.findMessageInfos(defferUserId);
                //                    messageInfos.addMessageInfos(new MessageInfo(defferUserId, messageInfosRepo, null, MessageInfoType.Rescue,
                //                            Integer.toString(day) + ";" + Integer.toString(defferRescueRec.getRescueFailCount())));
                //                    messageInfosRepo.saveMessageInfos(messageInfos);
            } else {
                defferRescueRec.addRescueFailCount();
            }
            rescueRepo.saveRescueLimitation(defferRescueRec);
            eventDispatcher.dispatch(new RescueEvent(attackUser, battleResult.isAttackerBattleWin()));
        }
        if (battleResult.isAttackerBattleWin()) {
            missionEngine.onEvent(new MissionEvent(MissionProperty.PROPERTY_悬赏_累计解救_玩家_MISSION, 1, attackUser.getId()));
            missionEngine.onEvent(new MissionEvent(MissionProperty.PROPERTY_参加_悬赏_MISSION, 1, attackUser.getId()));
        }
        return awardProcessorTemp;
    }

    public int getHonorPoint() {
        return battleResult.isAttackerBattleWin() ? 200 : 50;
    }

    public void setMonsterData(MonsterData monsterData) {
        this.monsterData = monsterData;
    }

    public void setOfficerRepo(OfficerRepo officerRepo) {
        this.officerRepo = officerRepo;
    }

    public void setBarrackRepo(BarrackRepo barrackRepo) {
        this.barrackRepo = barrackRepo;
    }

    public void setUserRepo(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public void setBattleObjFoctory(BattleObjFoctory battleObjFoctory) {
        this.battleObjFoctory = battleObjFoctory;
    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }

    public Officer getAttackOfficer() {
        return attackOfficer;
    }

    public Officer getDefenceOfficer() {
        return defenceOfficer;
    }

    public BattleResult getBattleResult() {
        return battleResult;
    }

    public Barrack getBarrack() {
        return barrack;
    }

    public void setBarrack(Barrack barrack) {
        this.barrack = barrack;
    }

    public MainCity getMainCity() {
        return mainCity;
    }

    public void setMainCity(MainCity mainCity) {
        this.mainCity = mainCity;
    }

    @JsonIgnore
    public List<ClientMission> getChangedMission() {
        return changedMission;
    }

    public void setChangedMission(List<ClientMission> changedMission) {
        this.changedMission = changedMission;
    }

}
