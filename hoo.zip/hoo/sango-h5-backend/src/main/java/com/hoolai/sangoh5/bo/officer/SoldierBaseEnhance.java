package com.hoolai.sangoh5.bo.officer;

import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.equip.data.EquipProperty;
import com.hoolai.sangoh5.bo.officer.Officer.EnhanceType;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.tacticalManagement.data.TacticalProperty;

public class SoldierBaseEnhance {

    /** 步兵攻击属性加成 */
    private float footmanAttackEnhanceRate;

    /** 步兵防御属性加成 */
    private float footmanDefenceEnhanceRate;

    /** 弓箭兵攻击属性加成 */
    private float archerAttackEnhanceRate;

    /** 弓箭兵防御属性加成 */
    private float archerDefenceEnhanceRate;

    /** 骑兵攻击属性加成 */
    private float riderAttackEnhanceRate;

    /** 骑兵防御属性加成 */
    private float riderDefenceEnhanceRate;

    /** 矛兵攻击属性加成 */
    private float spearmanAttackEnhanceRate;

    /** 矛兵防御属性加成 */
    private float spearmanDefenceEnhanceRate;

    /** 弩兵攻击属性加成 */
    private float crossbowmanAttackEnhanceRate;

    /** 弩兵防御属性加成 */
    private float crossbowmanDefenceEnhanceRate;

    /** 车兵攻击属性加成 */
    private float vehiclemanAttackEnhanceRate;

    /** 车兵防御属性加成 */
    private float vehiclemanDefenceEnhanceRate;

    private EnhanceType enhanceType;

    public SoldierBaseEnhance(EnhanceType enhanceType) {
        this.enhanceType = enhanceType;
    }

    public void enhance(EquipProperty property) {
        String attribute = property.getSolderAttribute();
        AttributeType attributeType = AttributeType.convertType(attribute);
        int[] soldierTypeInt = property.getSolderType();
        SoldierType[] soldierTypes = new SoldierType[soldierTypeInt.length];
        for (int i = 0; i < soldierTypeInt.length; i++) {
            soldierTypes[i] = SoldierType.valueOf(soldierTypeInt[i]);
        }

        enhance0(attributeType, soldierTypes, property.getSolderPercentage(), property.getSolderValue());
    }

    private void enhance0(AttributeType attributeType, SoldierType[] soldierTypes, float[] solderPercentage, int[] solderValue) {
        switch (attributeType) {
            case ATTACK:
                attackEnhance(soldierTypes, solderPercentage[0]);
                break;
            case DEFENCE:
                defenceEnhance(soldierTypes, solderPercentage[0]);
                break;
            case ATTACK_DEFENCE:
                attackEnhance(soldierTypes, solderPercentage[0]);
                defenceEnhance(soldierTypes, solderPercentage[1]);
                break;
            default:
                break;
        }
    }

    private void attackEnhance(SoldierType[] soldierTypes, float solderPercentage) {
        for (SoldierType soldierType : soldierTypes) {
            switch (soldierType) {
                case archer:
                    this.archerAttackEnhanceRate += solderPercentage / 100f;
                    break;
                case crossbowman:
                    this.crossbowmanAttackEnhanceRate += solderPercentage / 100f;
                    break;
                case footman:
                    this.footmanAttackEnhanceRate += solderPercentage / 100f;
                    break;
                case rider:
                    this.riderAttackEnhanceRate += solderPercentage / 100f;
                    break;
                case spearman:
                    this.spearmanAttackEnhanceRate += solderPercentage / 100f;
                    break;
                case vehicleman:
                    this.vehiclemanAttackEnhanceRate += solderPercentage / 100f;
                    break;
            }
        }
    }

    private void defenceEnhance(SoldierType[] soldierTypes, float solderPercentage) {
        for (SoldierType soldierType : soldierTypes) {
            switch (soldierType) {
                case archer:
                    this.archerDefenceEnhanceRate += solderPercentage / 100f;
                    break;
                case crossbowman:
                    this.crossbowmanDefenceEnhanceRate += solderPercentage / 100f;
                    break;
                case footman:
                    this.footmanDefenceEnhanceRate += solderPercentage / 100f;
                    break;
                case rider:
                    this.riderDefenceEnhanceRate += solderPercentage / 100f;
                    break;
                case spearman:
                    this.spearmanDefenceEnhanceRate += solderPercentage / 100f;
                    break;
                case vehicleman:
                    this.vehiclemanDefenceEnhanceRate += solderPercentage / 100f;
                    break;
            }
        }
    }

    public float getFootmanAttackEnhanceRate() {
        return footmanAttackEnhanceRate;
    }

    public void setFootmanAttackEnhanceRate(float footmanAttackEnhanceRate) {
        this.footmanAttackEnhanceRate = footmanAttackEnhanceRate;
    }

    public float getFootmanDefenceEnhanceRate() {
        return footmanDefenceEnhanceRate;
    }

    public void setFootmanDefenceEnhanceRate(float footmanDefenceEnhanceRate) {
        this.footmanDefenceEnhanceRate = footmanDefenceEnhanceRate;
    }

    public float getArcherAttackEnhanceRate() {
        return archerAttackEnhanceRate;
    }

    public void setArcherAttackEnhanceRate(float archerAttackEnhanceRate) {
        this.archerAttackEnhanceRate = archerAttackEnhanceRate;
    }

    public float getArcherDefenceEnhanceRate() {
        return archerDefenceEnhanceRate;
    }

    public void setArcherDefenceEnhanceRate(float archerDefenceEnhanceRate) {
        this.archerDefenceEnhanceRate = archerDefenceEnhanceRate;
    }

    public float getRiderAttackEnhanceRate() {
        return riderAttackEnhanceRate;
    }

    public void setRiderAttackEnhanceRate(float riderAttackEnhanceRate) {
        this.riderAttackEnhanceRate = riderAttackEnhanceRate;
    }

    public float getRiderDefenceEnhanceRate() {
        return riderDefenceEnhanceRate;
    }

    public void setRiderDefenceEnhanceRate(float riderDefenceEnhanceRate) {
        this.riderDefenceEnhanceRate = riderDefenceEnhanceRate;
    }

    public float getSpearmanAttackEnhanceRate() {
        return spearmanAttackEnhanceRate;
    }

    public void setSpearmanAttackEnhanceRate(float spearmanAttackEnhanceRate) {
        this.spearmanAttackEnhanceRate = spearmanAttackEnhanceRate;
    }

    public float getSpearmanlDefenceEnhanceRate() {
        return spearmanDefenceEnhanceRate;
    }

    public void setSpearmanlDefenceEnhanceRate(float spearmanlDefenceEnhanceRate) {
        this.spearmanDefenceEnhanceRate = spearmanlDefenceEnhanceRate;
    }

    public float getCrossbowmanAttackEnhanceRate() {
        return crossbowmanAttackEnhanceRate;
    }

    public void setCrossbowmanAttackEnhanceRate(float crossbowmanAttackEnhanceRate) {
        this.crossbowmanAttackEnhanceRate = crossbowmanAttackEnhanceRate;
    }

    public float getCrossbowmanDefenceEnhanceRate() {
        return crossbowmanDefenceEnhanceRate;
    }

    public void setCrossbowmanDefenceEnhanceRate(float crossbowmanDefenceEnhanceRate) {
        this.crossbowmanDefenceEnhanceRate = crossbowmanDefenceEnhanceRate;
    }

    public float getVehiclemanAttackEnhanceRate() {
        return vehiclemanAttackEnhanceRate;
    }

    public void setVehiclemanAttackEnhanceRate(float vehiclemanAttackEnhanceRate) {
        this.vehiclemanAttackEnhanceRate = vehiclemanAttackEnhanceRate;
    }

    public float getVehiclemanDefenceEnhanceRate() {
        return vehiclemanDefenceEnhanceRate;
    }

    public void setVehiclemanDefenceEnhanceRate(float vehiclemanDefenceEnhanceRate) {
        this.vehiclemanDefenceEnhanceRate = vehiclemanDefenceEnhanceRate;
    }

    public EnhanceType getEnhanceType() {
        return enhanceType;
    }

    public SoldierBaseEnhance addEnhance(SoldierBaseEnhance... enhances) {
        for (SoldierBaseEnhance baseEnhance : enhances) {
            if (baseEnhance == null) {
                continue;
            }
            this.archerAttackEnhanceRate += baseEnhance.getArcherAttackEnhanceRate();
            this.archerDefenceEnhanceRate += baseEnhance.getArcherDefenceEnhanceRate();
            this.crossbowmanAttackEnhanceRate += baseEnhance.getCrossbowmanAttackEnhanceRate();
            this.crossbowmanDefenceEnhanceRate += baseEnhance.getCrossbowmanDefenceEnhanceRate();
            this.footmanAttackEnhanceRate += baseEnhance.getFootmanAttackEnhanceRate();
            this.footmanDefenceEnhanceRate += baseEnhance.getFootmanDefenceEnhanceRate();
            this.riderAttackEnhanceRate += baseEnhance.getRiderAttackEnhanceRate();
            this.riderDefenceEnhanceRate += baseEnhance.getRiderDefenceEnhanceRate();
            this.spearmanAttackEnhanceRate += baseEnhance.getSpearmanAttackEnhanceRate();
            this.spearmanDefenceEnhanceRate += baseEnhance.getSpearmanlDefenceEnhanceRate();
            this.vehiclemanAttackEnhanceRate += baseEnhance.getVehiclemanAttackEnhanceRate();
            this.vehiclemanDefenceEnhanceRate += baseEnhance.getVehiclemanDefenceEnhanceRate();
        }
        return this;
    }

    @Override
    public SoldierBaseEnhance clone() {
        SoldierBaseEnhance soldierBaseEnhance = new SoldierBaseEnhance(enhanceType);
        soldierBaseEnhance.archerAttackEnhanceRate = this.getArcherAttackEnhanceRate();
        soldierBaseEnhance.archerDefenceEnhanceRate = this.getArcherDefenceEnhanceRate();
        soldierBaseEnhance.crossbowmanAttackEnhanceRate = this.getCrossbowmanAttackEnhanceRate();
        soldierBaseEnhance.crossbowmanDefenceEnhanceRate = this.getCrossbowmanDefenceEnhanceRate();
        soldierBaseEnhance.footmanAttackEnhanceRate = this.getFootmanAttackEnhanceRate();
        soldierBaseEnhance.footmanDefenceEnhanceRate = this.getFootmanDefenceEnhanceRate();
        soldierBaseEnhance.riderAttackEnhanceRate = this.getRiderAttackEnhanceRate();
        soldierBaseEnhance.riderDefenceEnhanceRate = this.getRiderDefenceEnhanceRate();
        soldierBaseEnhance.spearmanAttackEnhanceRate = this.getSpearmanAttackEnhanceRate();
        soldierBaseEnhance.spearmanDefenceEnhanceRate = this.getSpearmanlDefenceEnhanceRate();
        soldierBaseEnhance.vehiclemanAttackEnhanceRate = this.getVehiclemanAttackEnhanceRate();
        soldierBaseEnhance.vehiclemanDefenceEnhanceRate = this.getVehiclemanDefenceEnhanceRate();
        return soldierBaseEnhance;
    }

    public int getAttackEnhanceValue(SoldierType soldierType) {
        return 0;
    }

    public float getAttackEnhanceRate(SoldierType soldierType) {
        switch (soldierType) {
            case archer:
                return archerAttackEnhanceRate;
            case crossbowman:
                return crossbowmanAttackEnhanceRate;
            case footman:
                return footmanAttackEnhanceRate;
            case rider:
                return riderAttackEnhanceRate;
            case spearman:
                return spearmanAttackEnhanceRate;
            case vehicleman:
                return vehiclemanAttackEnhanceRate;
        }
        return 0;
    }

    public int getDefenceEnhanceValue(SoldierType soldierType) {
        return 0;
    }

    public float getDefenceEnhanceRate(SoldierType soldierType) {
        switch (soldierType) {
            case archer:
                return archerDefenceEnhanceRate;
            case crossbowman:
                return crossbowmanDefenceEnhanceRate;
            case footman:
                return footmanDefenceEnhanceRate;
            case rider:
                return riderDefenceEnhanceRate;
            case spearman:
                return spearmanDefenceEnhanceRate;
            case vehicleman:
                return vehiclemanDefenceEnhanceRate;
        }
        return 0;
    }

    public void enhance(TacticalProperty property, int starLv) {
        String[] tacp = property.getTacProperty();

        int[] pers = property.getPer(starLv);
        //        int[] values = property.getValue(starLv);

        for (int i = 0; i < tacp.length; i++) {
            String type = tacp[i];
            switch (type) {
                case "remoteSolDef":
                    this.archerDefenceEnhanceRate += pers[i] / 100f;
                    this.crossbowmanDefenceEnhanceRate += pers[i] / 100f;
                    this.vehiclemanDefenceEnhanceRate += pers[i] / 100f;
                    break;
                case "meleeCreDef":
                    this.riderDefenceEnhanceRate += pers[i] / 100f;
                    this.footmanDefenceEnhanceRate += pers[i] / 100f;
                    this.spearmanDefenceEnhanceRate += pers[i] / 100f;
                    break;
            }
        }
    }
}
