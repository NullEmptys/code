package com.hoolai.sangoh5.bo.user;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.compass.core.util.Assert;

import com.hoolai.platform.PlatformType;
import com.hoolai.platform.RequestInfo;
import com.hoolai.platform.RequestInfoFactory;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.bo.barrack.Barrack;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillData;
import com.hoolai.sangoh5.bo.city.MainCity;
import com.hoolai.sangoh5.bo.item.ItemBags;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryRankData;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.officerunion.OfficerUnions;
import com.hoolai.sangoh5.bo.officerunion.data.OfficerUnionData;
import com.hoolai.sangoh5.bo.pve.Provision;
import com.hoolai.sangoh5.bo.pvp.data.RegionData;
import com.hoolai.sangoh5.bo.soldier.data.SoldierData;
import com.hoolai.sangoh5.bo.technology.SoldierTechnologies;
import com.hoolai.sangoh5.bo.user.data.InitUserData;
import com.hoolai.sangoh5.repo.BarrackRepo;
import com.hoolai.sangoh5.repo.IndustryRepo;
import com.hoolai.sangoh5.repo.ItemRepo;
import com.hoolai.sangoh5.repo.JdbcSqlRepo;
import com.hoolai.sangoh5.repo.OfficerUnionRepo;
import com.hoolai.sangoh5.repo.PveRepo;
import com.hoolai.sangoh5.repo.PvpRepo;
import com.hoolai.sangoh5.repo.SoldierScienceRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.repo.redis.PveAreaRankRepo;
import com.hoolai.sangoh5.service.activity.ActivityService;
import com.hoolai.sangoh5.service.remoting.TrackRemoteService;
import com.hoolai.sangoh5.util.ProbabilityGenerator;
import com.hoolai.util.RandomUtil;
import com.hoolai.util.net.HttpService;

public class UserLoginProcessor extends LoginProcessor {

    private static final Log logger = LogFactory.getLog(UserLoginProcessor.class);

    private static final HttpService httpService = new HttpService();

    private final String requestInfoStr;

    private UserRepo userRepo;

    private BarrackRepo barrackRepo;

    private ItemRepo itemRepo;

    private BoFactory boFactory;

    private ProbabilityGenerator pg;

    private RegionData regionData;

    private IndustryRepo industryRepo;

    private PvpRepo pvpRepo;

    private User user;

    private long userId;

    private String openid;

    private SkillData skillData;

    private SoldierData soldierData;

    private OfficerUnionData officerUnionData;

    private OfficerUnionRepo officerUnionRepo;

    private MilitaryRankData militaryRankData;

    private JdbcSqlRepo jdbcSqlRepo;

    private PveRepo pveRepo;

    private ActivityService activityService;

    private TrackRemoteService trackRemoteService;

    private PveAreaRankRepo pveAreaRankRepo;

    private InitUserData initUserData;

    private SoldierScienceRepo soldierScienceRepo;

    public UserLoginProcessor(String requestInfoStr) {
        this.requestInfoStr = requestInfoStr;
    }

    @Override
    public User login() {
        RequestInfo requestInfo = RequestInfoFactory.parseRequestInfo(PlatformType.LOCAL, requestInfoStr);
        openid = requestInfo.findPid();
        boolean isNewUser = !userRepo.isUserExist(openid);
        if (isNewUser) {
            userId = userRepo.getUniqueId();
            Assert.isTrue(userRepo.savePlatformId(userId, requestInfo.findPid())); // 建立platformID 与  useId的双向索引)
            user = initNewUser(userId, openid);
            //            user.setLastSynAt(DateUtil.getTodayIntValue());
            int sex = new Random().nextInt(2);
            user.setSex(sex);
            user.setSlaveShapeType(sex == 0 ? new Random().nextInt(2) : new Random().nextInt(3));
            allotSangoState(user);
            try {
                jdbcSqlRepo.addUser(user);
            } catch (Exception e) {
                logger.error(e);
            }
        } else {
            if (userRepo.isUserExist(openid)) {
                userId = userRepo.findUserId(openid);
                userRepo.checkAccountState(userId);
                user = userRepo.findUser(userId);
            }
        }
        return user;
    }

    public void allotSangoState(User user) {
        ;
        //        String url = Constant.USER_IP_REAQUEST_URL + NetUtil.findClientIPStr();
        //
        //        HttpClient client = new HttpClient();
        //        HttpMethod method = new GetMethod(url);
        //        int state = 0;
        //        try {
        //            client.executeMethod(method);
        //            String ipStr = method.getResponseBodyAsString();
        //            IpInfo ipInfo = JSONUtils.fromJSON(ipStr, IpInfo.class);
        //
        //            String province = URLDecoder.decode(ipInfo.getProvince(), "utf-8");
        //            state = regionData.getState(province);
        //        } catch (Exception e) {
        //            logger.error(e);
        //            state = regionData.getState("");
        //        } finally {
        user.setSangoState(RandomUtil.randomCloseNum(1, 9));
        //            method.releaseConnection();
        //        }
    }

    public User initNewUser(long userId, String openid) {
        User user = new User(userId, openid);
        user.setMilitaryRankData(militaryRankData);
        user.setSkillData(skillData);
        user.setPg(pg);
        user.init(openid, initUserData);

        // 第一级用户
        if (user.isNeedTrack()) {
            userRepo.addRankUser(user);
        }
        userRepo.addUser(user);

        //初始化一些key
        itemRepo.initUniqueEquipId(userId);
        industryRepo.initSlaveUniqueKey(userId);

        //初始化主城
        pvpRepo.lockCity(userId);
        try {
            MainCity mainCity = new MainCity(userId);
            pvpRepo.saveMainCity(mainCity);
        } finally {
            pvpRepo.unLockCity(userId);
        }

        // 初始化兵营
        Barrack barrack = new Barrack();
        barrack.setSoldierData(soldierData);
        barrack.setUserId(userId);
        barrack.setSoldierNum(initUserData.getAward(AwardType.SOLDIER).getNum());
        barrack.init();
        barrackRepo.saveBarrack(barrack);

        // 初始化将领
        List<Award> officerAwards = initUserData.getAwards(AwardType.OFFICER);
        if (officerAwards != null) {
            for (Award award : officerAwards) {
                for (int i = 0; i < award.getNum(); i++) {
                    boFactory.createOfficer(userId, award.getXmlId(), Officer.station_barrack);
                }
            }
        }

        // 初始化包裹
        List<Award> skillAwards = initUserData.getAwards(AwardType.SKILL);
        if (skillAwards != null) {
            ItemBags itemBags = itemRepo.findItemBags(userId);

            for (Award award : skillAwards) {
                itemBags.addOrIncrItemBag(award.getXmlId(), award.getNum());
            }
            itemRepo.saveItemBags(itemBags);
        }

        // 初始化将领组合
        OfficerUnions officerUnions = officerUnionData.createNewOfficerUnions(userId);
        officerUnionRepo.saveOfficerUnions(officerUnions);

        // 初始化粮草
        Provision provision = pveRepo.findProvision(userId);
        provision.addProvision(initUserData.getAward(AwardType.PROVISION).getNum());
        pveRepo.saveProvision(provision);

        // 初始化士兵科技
        SoldierTechnologies soldierTechnologies = new SoldierTechnologies(userId);
        soldierScienceRepo.newSoldierTechnologies(soldierTechnologies);

        //邀请
        activityService.onAfterCreateRole(user);

        trackRemoteService.trackRole(userId);
        if (user.isNeedTrack()) {
            pveAreaRankRepo.addOrUpdateUserLevelSortList(userId, user.getRank());
        }

        return user;
    }

    public void setUserRepo(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public void setBarrackRepo(BarrackRepo barrackRepo) {
        this.barrackRepo = barrackRepo;
    }

    public void setItemRepo(ItemRepo itemRepo) {
        this.itemRepo = itemRepo;
    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }

    public void setPg(ProbabilityGenerator pg) {
        this.pg = pg;
    }

    public void setIndustryRepo(IndustryRepo industryRepo) {
        this.industryRepo = industryRepo;
    }

    public void setRegionData(RegionData regionData) {
        this.regionData = regionData;
    }

    public void setPvpRepo(PvpRepo pvpRepo) {
        this.pvpRepo = pvpRepo;
    }

    public static void main(String[] args) {
        try {
            System.out.println(URLDecoder.decode("\u4e2d\u56fd", "utf-8"));
            System.out.println(URLDecoder.decode("\u5e7f\u4e1c", "utf-8"));
            System.out.println(URLDecoder.decode("\u5e7f\u5dde", "utf-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public void setSkillData(SkillData skillData) {
        this.skillData = skillData;
    }

    public void setOfficerUnionData(OfficerUnionData officerUnionData) {
        this.officerUnionData = officerUnionData;
    }

    public void setOfficerUnionRepo(OfficerUnionRepo officerUnionRepo) {
        this.officerUnionRepo = officerUnionRepo;
    }

    public void setMilitaryRankData(MilitaryRankData militaryRankData) {
        this.militaryRankData = militaryRankData;
    }

    public void setJdbcSqlRepo(JdbcSqlRepo jdbcSqlRepo) {
        this.jdbcSqlRepo = jdbcSqlRepo;
    }

    public PveRepo getPveRepo() {
        return pveRepo;
    }

    public void setPveRepo(PveRepo pveRepo) {
        this.pveRepo = pveRepo;
    }

    public void setSoldierData(SoldierData soldierData) {
        this.soldierData = soldierData;
    }

    public void setActivityService(ActivityService activityService) {
        this.activityService = activityService;
    }

    public void setTrackRemoteService(TrackRemoteService trackRemoteService) {
        this.trackRemoteService = trackRemoteService;
    }

    public void setPveAreaRankRepo(PveAreaRankRepo pveAreaRankRepo) {
        this.pveAreaRankRepo = pveAreaRankRepo;
    }

    public void setInitUserData(InitUserData initUserData) {
        this.initUserData = initUserData;
    }

    public void setSoldierScienceRepo(SoldierScienceRepo soldierScienceRepo) {
        this.soldierScienceRepo = soldierScienceRepo;
    }

}
