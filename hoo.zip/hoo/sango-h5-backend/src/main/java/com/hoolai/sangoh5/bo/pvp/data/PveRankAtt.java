package com.hoolai.sangoh5.bo.pvp.data;

/**
 * 任务属性定义枚举
 * 
 * @author hp
 *
 */
public enum PveRankAtt {

	PVE_RANK_CONTRY(1,"全国排行"),
	PVE_RANK_STATE(2,"本州排行"),
	PVE_RANK_FRIEND(3,"好友排行");
	
	private int propertyId;
	private String desc;

	private PveRankAtt(int propertyId, String desc) {
		this.propertyId = propertyId;
		this.desc = desc;
	}

	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public static PveRankAtt getValue(int propertyId) {
		for (PveRankAtt missionProperty : PveRankAtt.values()) {
			if (missionProperty.getPropertyId() == propertyId) {
				return missionProperty;
			}
		}
		return null;
	}

}
