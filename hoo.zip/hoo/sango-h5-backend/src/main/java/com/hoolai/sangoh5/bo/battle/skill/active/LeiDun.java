package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.RangeSustainedBuff;
import com.hoolai.sangoh5.bo.battle.fight.PositionCalculator;
import com.hoolai.sangoh5.bo.battle.skill.ForceType;
import com.hoolai.sangoh5.bo.battle.skill.ForceUnitType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.LeiDunDefence;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 为某个单位身上释放一个雷电护盾，每次吸收10%伤害，每秒对周围距离为3的敌方单位造成50点伤害，被攻击4次后消失
 * 
 * @author Administrator
 *         这个技能要做特例
 */
public class LeiDun extends IndependentSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveFightUnits = aliveTargetUnitList(tc, actor);
        if (aliveFightUnits == null || aliveFightUnits.isEmpty()) {
            return targets;
        }

        // 随机己方一个单位
        int index = pg.getRandomNumber(0, aliveFightUnits.size() - 1);
        FightUnit target = aliveFightUnits.get(index);
        LeiDunDefence leiDunDefence = (LeiDunDefence) target.findDefencePassiveSkill(xmlId);
        if (leiDunDefence == null) {
            leiDunDefence = new LeiDunDefence(xmlId, repeatCount / 10);
            leiDunDefence.setForceType(ForceType.ENEMY);
            leiDunDefence.setForceUnitType(ForceUnitType.OFFICER_SOLDIERS);
            target.addCounterAttackSkills(leiDunDefence);
        } else {
            leiDunDefence.reset(repeatCount / 10);
        }

        // 给所以敌方单位加上Buff
        int[] targetRange = new int[] { 3, 3, 3, 3 };
        Collection<FightUnit> targetFightUnits = tc.aliveValues();
        for (FightUnit fightUnit : targetFightUnits) {
            if (fightUnit.isAttacker() != actor.isAttacker()) {
                int[] referPos = target.getPositionManager().expectNext();
                int[] targetPos = fightUnit.getPositionManager().expectNext();
                if (PositionCalculator.isRange(referPos, targetPos, targetRange, null)) {
                    Buff buff = fightUnit.findBuff(xmlId, actor.name());
                    if (buff == null) {
                        fightUnit.addBuff(new RangeSustainedBuff(actor, fightUnit.name(), this, currentLevel, twoValue).withActorName(actor.name())
                                .withTargetName(fightUnit.name()).withKeepBuff().withRepeatCount(twoRepeatCount));
                    } else {
                        buff.setRepeatCount(twoRepeatCount);
                    }
                }
            }
        }
        return targets;
    }

    @Override
    public Skill clone() {
        return super.clone(new LeiDun());
    }

}
