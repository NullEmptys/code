package com.hoolai.sangoh5.bo.pvp.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 15:03
 * @version : 1.0
 */
public class PersonalMedalProperty extends JsonProperty {

    /** id **/
    private int id;

    /** 名称 **/
    private String name;

    /** 类型 **/
    private MedalTriggerType type;

    /** 条件 **/
    private int condition;

    /** 次数 **/
    private int target;

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public MedalTriggerType getType() {
        return type;
    }

    public void setType(int type) {
        this.type = MedalTriggerType.valueOf(type);
    }

    public int getCondition() {
        return condition;
    }

    public void setCondition(int condition) {
        this.condition = condition;
    }

    public int getTarget() {
        return target;
    }

    public void setTarget(int target) {
        this.target = target;
    }

    public boolean isFinish(int completeCount) {
        return this.target <= completeCount;
    }

}
