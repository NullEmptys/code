package com.hoolai.sangoh5.bo.battle.skill.soldier.defence;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.soldier.DuoShanBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class DuoShan extends DefenceSkill {

    @Override
    public void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {

        target.addBuff(new DuoShanBuff(xmlId, name, target.name(), currentLevel).withChance(chance).withActorName(actor.name()).withTargetName(target.name()).withKeepBuff()
                .withRepeatCount(repeatCount));
        target.addBattleLog(target.name() + "使用躲闪了" + actor.name() + "的" + effect.getTargetUsedSkillXmlId() + "的攻击伤害：" + effect.getDeltaHp() + (buff != null ? "以及buff效果" : ""));

        effect.setDeltaHp(0);
        target.changeSkillChance(xmlId, -chance);

        if (buff != null) {
            buff.clear(tc);
            target.removeBuff(buff);
        }
    }

    @Override
    public Skill clone() {
        return super.clone(new DuoShan());
    }
}
