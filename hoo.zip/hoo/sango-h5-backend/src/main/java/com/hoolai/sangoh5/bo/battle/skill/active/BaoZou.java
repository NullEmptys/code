package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.CountChangeAttackBuff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.CountChangeDefenseBuff;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.ForceType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 
 * 以自身为中心点，所有敌人受到一定伤害,并增加自身的攻防
 * 
 * @author Administrator
 *
 */
public class BaoZou extends BaseOfficerPhysicsSkill {

    @Override
    public Skill clone() {
        return super.clone(new BaoZou());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            Effect effect = rangeHurt(actor, target, currentLevel);
            targets.add(target);
            targetDefence(actor, target, effect, null, tc, targets, currentLevel);
        }

        keepHurt(actor, actor, currentLevel);
        return targets;
    }

    /**
     * 持续伤害
     * 
     * @param actor
     * @param currentLevel
     * @param target
     */
    private void keepHurt(FightUnit actor, FightUnit target, int currentLevel) {
        Buff buff = target.findBuff(this.xmlId);
        if (buff == null) {
            Buff sbuff = null;
            if (this.twoAttribute == AttributeType.ATTACK) {
                sbuff = new CountChangeAttackBuff(xmlId, name, target.name(), actor, ForceType.FRIEND, Action.DEFAULT_ACTION_LEVEL, twoPercentage).withKeepBuff()
                        .withActorName(actor.name()).withTargetName(target.name()).withRepeatCount(twoRepeatCount);
            } else if (this.twoAttribute == AttributeType.DEFENCE) {
                sbuff = new CountChangeDefenseBuff(xmlId, name, target.name(), actor, ForceType.FRIEND, Action.DEFAULT_ACTION_LEVEL, twoPercentage).withKeepBuff()
                        .withActorName(actor.name()).withTargetName(target.name()).withRepeatCount(twoRepeatCount);
            }
            sbuff.apply(target);
            target.addBuff(sbuff);
        } else {
            buff.setRepeatCount(twoRepeatCount);
            buff.apply(target);
        }
    }

    /**
     * 范围内伤害
     * 
     * @param actor
     * @param currentLevel
     * @param referPos
     * @param target
     */
    private Effect rangeHurt(FightUnit actor, FightUnit target, int currentLevel) {
        Effect effect = new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withDeltaHp(calculateLostPoint4Skill(actor, target))
                .withTargetName(target.name());
        target.addEffect(effect);
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "造成伤害=" + effect.getDeltaHp());
        return effect;
    }
}
