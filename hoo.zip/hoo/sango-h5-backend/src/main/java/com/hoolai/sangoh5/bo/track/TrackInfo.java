package com.hoolai.sangoh5.bo.track;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.TrackInfoProto;

public class TrackInfo implements ProtobufSerializable<TrackInfoProto> {

    private int lastLoginTimeDay;

    public TrackInfo() {

    }

    public TrackInfo(byte[] input) {
        parseFrom(input);
    }

    @Override
    public void copyFrom(TrackInfoProto proto) {
        lastLoginTimeDay = proto.getLastLoginTimeDay();
    }

    @Override
    public TrackInfoProto copyTo() {
        TrackInfoProto.Builder builder = TrackInfoProto.newBuilder();
        builder.setLastLoginTimeDay(this.lastLoginTimeDay);
        return builder.build();

    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            copyFrom(TrackInfoProto.parseFrom(bytes));
        } catch (InvalidProtocolBufferException ex) {
            throw new IllegalArgumentException(ex);
        }
    }

    public int getLastLoginTimeDay() {
        return lastLoginTimeDay;
    }

    public void setLastLoginTimeDay(int lastLoginTimeDay) {
        this.lastLoginTimeDay = lastLoginTimeDay;
    }

}
