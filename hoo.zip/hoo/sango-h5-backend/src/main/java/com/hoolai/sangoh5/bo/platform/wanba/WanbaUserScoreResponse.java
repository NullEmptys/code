package com.hoolai.sangoh5.bo.platform.wanba;

import java.util.Arrays;

public class WanbaUserScoreResponse extends WanbaResponse{

	private WanbaUserScore[] data;
	
	public WanbaUserScoreResponse(){
		
	}
	
	private WanbaUserScoreResponse(int code){
		this.code = code;
	}
	
	public static WanbaUserScoreResponse success() {
		return new WanbaUserScoreResponse(WanbaResponse.SUCCESS_CODE);
	}
	
	public static WanbaUserScoreResponse error() {
		return new WanbaUserScoreResponse(WanbaResponse.ERROR_CODE);
	}
	
	@Override
	public String toString() {
		return "TencentWanbaUserScoreResponse [data=" + Arrays.toString(data) + ", code=" + code + ", message=" + message + ", subcode=" + subcode
				+ "]";
	}
	
	public WanbaUserScore[] getData() {
		return data;
	}
	public void setData(WanbaUserScore[] data) {
		this.data = data;
	}
	
}
