package com.hoolai.sangoh5.bo.item.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class SlaveNpcData extends JsonData<SlaveNpcProperty> {

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/slaveNpc.json", SlaveNpcProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(SlaveNpcProperty property) {
        // TODO Auto-generated method stub

    }

}
