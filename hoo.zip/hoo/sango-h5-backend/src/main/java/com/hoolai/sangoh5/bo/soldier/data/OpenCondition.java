package com.hoolai.sangoh5.bo.soldier.data;

import com.hoolai.sango.core.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class OpenCondition {

    //	private int type;
    private int level;

    //	private int gold;
    private int lanTianYu;

    //	private int vipLevel;
    private int militaryRank;

    private int pve;

    //	public enum UnlockSoldierType{
    //		DEFAULT(1),
    //		LEVEL_GOLD(2),
    //		DIAMOND(3),
    //		VIP(4);
    //		
    //		private final int type;
    //		private UnlockSoldierType(int type){
    //			this.type = type;
    //		}
    //		
    //		public int type() {
    //	        return this.type;
    //	    }
    //		
    //		 public static UnlockSoldierType valueOf(int value) {
    //		        switch (value) {
    //		        case 1:
    //		            return DEFAULT;
    //		        case 2:
    //		            return LEVEL_GOLD;
    //		        case 3:
    //		        	return DIAMOND;
    //		        case 4:
    //		            return VIP;
    //		        default:
    //		            throw new IllegalArgumentException("there is no UnlockSoldierType enum element`s value is " + value);
    //		        }
    //		    }
    //	}

    //	public int getType() {
    //		return type;
    //	}
    //	public void setType(int type) {
    //		this.type = type;
    //	}
    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    //	public int getGold() {
    //		return gold;
    //	}
    //	public void setGold(int gold) {
    //		this.gold = gold;
    //	}
    //	public int getVipLevel() {
    //		return vipLevel;
    //	}
    //	public void setVipLevel(int vipLevel) {
    //		this.vipLevel = vipLevel;
    //	}

    public int getMilitaryRank() {
        return militaryRank;
    }

    public int getLanTianYu() {
        return lanTianYu;
    }

    public void setLanTianYu(int lanTianYu) {
        this.lanTianYu = lanTianYu;
    }

    public void setMilitaryRank(int militaryRank) {
        this.militaryRank = militaryRank;
    }

    public void checkLevel(int level) {
        if (this.level > level) {
            throw new BusinessException(ErrorCode.USER_LEVEL_NOT_ENOUGH.code, "君主等级达到" + this.level + "才能开启哦！");
        }
    }

    public void checkMilitaryRankRank(int rank) {
        if (this.militaryRank > rank) {
            throw new BusinessException(ErrorCode.MILITARY_RANK_NOT_ENOUGH.code, "君主军衔等级达到" + this.militaryRank + "才能开启哦！");
        }
    }

    public void checkLanTianYu(int lanTianYu) {
        if (this.lanTianYu > lanTianYu) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_YUANBAO.code, "蓝田玉不足");
        }
    }

    public void checkPve(int barrierId) {
        if (barrierId <= 0 || this.pve > barrierId) {
            throw new BusinessException(ErrorCode.MILITARY_RANK_NOT_ENOUGH.code, "pve关卡没达到哦！");
        }
    }

    public int getPve() {
        return pve;
    }

    public void setPve(int pve) {
        this.pve = pve;
    }

}
