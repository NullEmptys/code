package com.hoolai.sangoh5.bo.platform.wanba;

import java.util.Arrays;

public class WanbaBuyItemResponse extends WanbaResponse{

	private WanbaBuyItem[] data;
	
	public WanbaBuyItemResponse(){
		
	}
	
	private WanbaBuyItemResponse(int code){
		super(code);
	}
	
	public static WanbaBuyItemResponse success() {
		return code(WanbaResponse.SUCCESS_CODE);
	}

	public static WanbaBuyItemResponse error() {
		return code(WanbaResponse.ERROR_CODE);
	}
	
	public static WanbaBuyItemResponse code(int code) {
		return new WanbaBuyItemResponse(code);
	}
	
	public boolean notEnoughScore() {
		return code == 1004;
	}
	
	@Override
	public String toString() {
		return "TencentWanbaBuyItemResponse [data=" + Arrays.toString(data) + ", code=" + code + ", message=" + message + ", subcode=" + subcode
				+ "]";
	}
	
	public WanbaBuyItem[] getData() {
		return data;
	}
	public void setData(WanbaBuyItem[] data) {
		this.data = data;
	}
	
}
