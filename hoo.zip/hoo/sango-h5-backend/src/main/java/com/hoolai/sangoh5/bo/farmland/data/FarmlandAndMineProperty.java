package com.hoolai.sangoh5.bo.farmland.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class FarmlandAndMineProperty extends JsonProperty {

    private int landType;//类型

    private int landLv;//等级

    private int costDiamond;//消耗钻石

    private int improve;//收成加成值

    private int soildernum;//带兵加成 直接在officer中加成

    private int skillhurt;// 技能伤害加成

    private int attackhurt;// 基本伤害加成

    private int sciencenum;//掠夺陨铁值上限

    public enum FarmlandAndMineType {
        FARM_LAND(1), MINE(2);

        private final int type;

        private FarmlandAndMineType(int type) {
            this.type = type;
        }

        public int value() {
            return type;
        }
    }

    public int getLandType() {
        return landType;
    }

    public void setLandType(int landType) {
        this.landType = landType;
    }

    public int getLandLv() {
        return landLv;
    }

    public void setLandLv(int landLv) {
        this.landLv = landLv;
    }

    public int getCostDiamond() {
        return costDiamond;
    }

    public void setCostDiamond(int costDiamond) {
        this.costDiamond = costDiamond;
    }

    public int getImprove() {
        return improve;
    }

    public void setImprove(int improve) {
        this.improve = improve;
    }

    public int getSoildernum() {
        return soildernum;
    }

    public void setSoildernum(int soildernum) {
        this.soildernum = soildernum;
    }

    public int getSkillhurt() {
        return skillhurt;
    }

    public void setSkillhurt(int skillhurt) {
        this.skillhurt = skillhurt;
    }

    public int getAttackhurt() {
        return attackhurt;
    }

    public void setAttackhurt(int attackhurt) {
        this.attackhurt = attackhurt;
    }

    public int getSciencenum() {
        return sciencenum;
    }

    public void setSciencenum(int sciencenum) {
        this.sciencenum = sciencenum;
    }

}
