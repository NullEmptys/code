package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class IndustryKey {

    private static final String prefix = "ind";

    public static String getFarmlandKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("fid").toString();
    }

    public static String getMineKey(long userId) {
        return new StringBuilder().append(prefix).append("mine").append(Constant.separator).append(userId).append(Constant.separator).append("fid").toString();
    }

    public static String getSlavesKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("ss").toString();
    }

    public static String getUniqueSlaveIdKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("sid").toString();
    }

    public static String getCaptivesKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("caid").toString();
    }

    public static String getLockSlaveKey(long userId, int slaveId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append(slaveId).append("lock").toString();
    }

    public static String getSnatchKey(long userId, String source) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append(source).toString();
    }

}
