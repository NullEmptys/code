package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 给己方士兵恢复一定兵力
 * 
 * @author Administrator
 *
 */
@Deprecated
public class Treatment extends IndependentSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        boolean isAttacker = actor.isAttacker();
        List<FightUnit> targets = new ArrayList<FightUnit>();

        Map<FightUnitName, FightUnit> aliveMap = tc.aliveTargetSoldier(!isAttacker);// 获取自己方的士兵
        if (aliveMap == null || aliveMap.isEmpty()) {
            return targets;
        }
        Set<FightUnitName> keySet = aliveMap.keySet();
        Object[] fightUnitNames = keySet.toArray();

        FightUnit target = aliveMap.get(fightUnitNames[pg.getRandomNumber(fightUnitNames.length - 1)]);

        target.changeHp((int) (target.getHp() * percentage));
        targets.add(target);
        return targets;
    }

    @Override
    public Skill clone() {
        return super.clone(new Treatment());
    }

}
