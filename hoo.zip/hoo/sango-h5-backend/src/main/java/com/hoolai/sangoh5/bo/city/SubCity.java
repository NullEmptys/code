package com.hoolai.sangoh5.bo.city;

public class SubCity {

	private long occupiedAt; // 开始占领时间
	
	private long originalUserId; // 城池原本的君主
}
