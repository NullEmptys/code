package com.hoolai.sangoh5.bo.battle.skill.soldier.passive;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ChangeHpBuff;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 每秒增加生命值上限N%的生命值
 */
public class ChangeSelfHp extends IndependentSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {

        Buff buff = actor.findBuff(xmlId);
        if (buff == null) {
            actor.addBuff(new ChangeHpBuff(xmlId, name, actor.name(), Effect.MONITORING_BUFF_LEVEL, AttributeType.HP, this, false).withActorName(actor.name())
                    .withTargetName(actor.name()).withRepeatCount(repeatCount).withKeepBuff().withDeltaHp(-Math.round(actor.getOriginalHp() * percentage)));
        } else {
            buff.setRepeatCount(repeatCount);
        }

        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]" + ",每" + this.round + "秒增加" + Math.round(actor.getOriginalHp() * percentage) + "血");
        return new ArrayList<FightUnit>();
    }

    @Override
    public Skill clone() {
        return super.clone(new ChangeSelfHp());
    }
}
