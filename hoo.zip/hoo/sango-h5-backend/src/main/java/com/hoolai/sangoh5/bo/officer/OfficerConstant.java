package com.hoolai.sangoh5.bo.officer;

public class OfficerConstant {

	public static final int station_barrack = 1;
	
	public static final int station_garrison = 2;
	
}
