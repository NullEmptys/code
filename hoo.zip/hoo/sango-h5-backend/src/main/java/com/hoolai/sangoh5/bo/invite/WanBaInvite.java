package com.hoolai.sangoh5.bo.invite;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.WanBaInviteProtocolBuffer.WanBaInviteProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.schooner.MemCached.MemcachedItem;

public class WanBaInvite implements ProtobufSerializable<WanBaInviteProto>{

	private long userId;
	
	private int share;
	
	private int invite;
	
	private boolean isGetShareAwards;
	
	private boolean isGetInviteAwards;
	
	private MemcachedItem memcachedItem;
	
	public WanBaInvite() {
    }

    public WanBaInvite(long userId) {
        this.userId = userId;
    }

    public WanBaInvite(long userId, byte[] bytes) {
        this(userId);
        parseFrom(bytes);
    }

	public WanBaInvite(long userId, byte[] value, MemcachedItem item) {
		this(userId, value);
        this.memcachedItem = item;
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			WanBaInviteProto message = WanBaInviteProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
	}

	@Override
	public WanBaInviteProto copyTo() {
		WanBaInviteProto.Builder builder = WanBaInviteProto.newBuilder();
        builder.setShare(share);
        builder.setInvite(invite);
        builder.setIsGetInviteAwards(isGetInviteAwards);
        builder.setIsGetShareAwards(isGetShareAwards);
        return builder.build();
	}

	@Override
	public void copyFrom(WanBaInviteProto message) {
		this.share = message.getShare();
        this.invite = message.getInvite();
        this.isGetInviteAwards = message.getIsGetInviteAwards();
        this.isGetShareAwards = message.getIsGetShareAwards();
	}
	
	public int getShare() {
		return share;
	}

	public void setShare(int share) {
		this.share = share;
	}

	public int getInvite() {
		return invite;
	}

	public void setInvite(int invite) {
		this.invite = invite;
	}

	public boolean isGetShareAwards() {
		return isGetShareAwards;
	}

	public void setGetShareAwards(boolean isGetShareAwards) {
		this.isGetShareAwards = isGetShareAwards;
	}

	public boolean isGetInviteAwards() {
		return isGetInviteAwards;
	}

	public void setGetInviteAwards(boolean isGetInviteAwards) {
		this.isGetInviteAwards = isGetInviteAwards;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public void addShare() {
		share++;
	}

	public long casUnique() {
		return this.memcachedItem.casUnique;
	}

	public void addInvite() {
		invite++;
	}

	public void resetShare() {
		share = 0;
		isGetShareAwards = false;
	}
}
