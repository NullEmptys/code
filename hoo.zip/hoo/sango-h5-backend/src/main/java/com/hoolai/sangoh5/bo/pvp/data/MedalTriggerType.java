package com.hoolai.sangoh5.bo.pvp.data;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 15:08
 * @version : 1.0
 */
public enum MedalTriggerType {
    /**
     * 剩余士兵数量
     */
    SurplusSoldier(1),

    /**
     * 战斗力超越
     */
    OverstepFightPower(2),

    /**
     * 抵挡攻击
     */
    ResistAttack(3),

    /**
     * 连胜
     */
    WinningStreak(4);

    private final int type;

    private MedalTriggerType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public static MedalTriggerType valueOf(int type) {
        for (MedalTriggerType triggerType : values()) {
            if (triggerType.getType() == type) {
                return triggerType;
            }
        }
        throw new RuntimeException("not found trigger type " + type);
    }

}
