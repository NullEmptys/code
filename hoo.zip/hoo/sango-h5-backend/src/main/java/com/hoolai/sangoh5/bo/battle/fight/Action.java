package com.hoolai.sangoh5.bo.battle.fight;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class Action {

    public static int DEFAULT_ACTION_LEVEL = 1;

    private int currentLevel = DEFAULT_ACTION_LEVEL;

    private IndependentSkill skill;

    private FightUnit actor;

    private ActionType actionType;

    private Action next;

    List<FightUnit> targets = new ArrayList<FightUnit>();

    public Action(FightUnit actor, ActionType actionType, IndependentSkill skill) {
        this.actor = actor;
        this.skill = skill;
        this.actionType = actionType;
    }

    public void withNext(Action next) {
        this.next = next;
    }

    private boolean hasNext() {
        return this.next != null;
    }

    /**
     * action执行，即技能执行。形成技能效果，产生目标列表。 在每一个目标列表中应用技能效果。
     * 
     * @param targetCollection
     * @param match
     * @param level
     * @return
     */
    public Action execute(TargetCollection targetCollection, Match match, int level) {

        currentLevel = level;
        this.targets = skill.execute(actor, targetCollection, currentLevel);

        if (this.hasNext()) {
            this.next.execute(targetCollection, match, currentLevel++);
        }
        return this;
    }

    public ActionResult apply(Match match, TargetCollection targetCollection) {
        ActionResult actionResult = apply(targets, match, targetCollection);
        if (this.hasNext()) {
            actionResult.setNext(this.next.apply(match, targetCollection));
        }
        return actionResult;
    }

    private ActionResult apply(List<FightUnit> targets, Match match, TargetCollection targetCollection) {
        ActionResult actionResult = new ActionResult(skill.getXmlId(), actor.name(), actionType, currentLevel);

        List<Effect> effects = new ArrayList<Effect>();
        List<Buff> buffs = new ArrayList<Buff>();

        /**
         * 执行buff
         */
        if (targets == null || targets.isEmpty()) {
            actionResult = nullTargets(match, actionResult);

            actor.applyBuffs(actor, skill, currentLevel);

            match.addBuffs(actor.getNoRepeatBuffList(actor, currentLevel));//士兵,有时候就是加到自己身上

            buffs.addAll(actor.cloneRealTimeBuffList(actor.name()));

            actor.clearBuffs(this.actor, currentLevel);
            if (actionResult.getIsHaveNewTarget()) {
                actor.setIsHaveNewTarget(false);
            }
            actionResult.setBuffList(buffs);
            return actionResult;
        }

        clearRepeatTarget(targets, targetCollection);

        // 收集基础伤害
        collectHurt4Targets(targets, targetCollection);
        collectHurt4Actor();

        // 对伤害总和执行的操作
        finalHurtEnhance4Targets(targets, targetCollection);
        finalHurtEnhance4Actor(targets, targetCollection);

        // 执行普通的effects,buffs
        apply4Targets(targets);
        apply4Actor();

        //clear&copy&add,buff,effect,
        deal4Targets(targets, effects, buffs, match);
        deal4Actor(effects, buffs, match);

        actionResult.setEffectList(effects);
        actionResult.setBuffList(buffs);
        return actionResult;
    }

    private void collectHurt4Targets(List<FightUnit> targets, TargetCollection tc) {
        for (FightUnit target : targets) {
            target.enhanceEffect(currentLevel);
        }
    }

    private void collectHurt4Actor() {
        actor.enhanceEffect(currentLevel);
    }

    private ActionResult nullTargets(Match match, ActionResult actionResult) {
        switch (actionType) {
            case MOVE_IDLE:
            case MOVE:
                if (actionType == ActionType.MOVE) {
                    actor.getPositionManager().next();
                }
                if (actor.isHaveNewTarget()) {
                    actionResult.setIsHaveNewTarget(true);
                    actionResult.setPositionManager(actor.getPositionManager().clone());
                    //                    actor.setIsHaveNewTarget(false);// 放在buff后执行
                }
                break;
            case ATTACK:
                actionResult.setActionType(ActionType.ATTACK_IDLE);
                break;
            default:
                break;
        }
        return actionResult;
    }

    private void apply4Targets(List<FightUnit> targets) {
        if (targets == null || targets.isEmpty()) {
            return;
        }
        for (FightUnit target : targets) {
            target.applyEffects(actor, skill, currentLevel);
        }
    }

    private void apply4Actor() {
        actor.applyEffects(actor, skill, currentLevel);
        actor.applyBuffs(actor, skill, currentLevel);
    }

    private void deal4Actor(List<Effect> effects, List<Buff> buffs, BuffCollection buffCollection) {
        effects.addAll(actor.getAllEffectList(actor, currentLevel));
        buffCollection.addBuffs(actor.getNoRepeatBuffList(actor, currentLevel));//士兵,有时候就是加到自己身上
        buffs.addAll(actor.cloneRealTimeBuffList(actor.name()));
        actor.clearEffects(this.actor, currentLevel);
        actor.clearBuffs(this.actor, currentLevel);
    }

    private void deal4Targets(List<FightUnit> targets, List<Effect> effects, List<Buff> buffs, BuffCollection buffCollection) {
        for (FightUnit target : targets) {
            effects.addAll(target.getAllEffectList(actor, currentLevel));
            //            buffCollection.addBuffs(target.getNoRepeatBuffList(actor,currentLevel));
            //            buffs.addAll(target.cloneRealTimeBuffList(actor.name()));//由于有repeatedCount的关系buff放入actionResult里需要clone一份当前的
            target.clearEffects(actor, currentLevel);
            //            target.clearBuffs(actor,currentLevel);
        }
    }

    /**
     * 清除重复的单元
     * 
     * @param targets
     */
    private void clearRepeatTarget(List<FightUnit> targets, TargetCollection tc) {
        if (actor.isCanAttackAllTargets()) {
            targets.clear();

            Map<FightUnitName, FightUnit> aliveMap = tc.aliveTargetUnit(actor.isAttacker());
            Set<FightUnitName> keySet = aliveMap.keySet();
            for (FightUnitName name : keySet) {
                targets.add(aliveMap.get(name));
            }
        } else {
            Iterator<FightUnit> iterator = targets.iterator();
            List<FightUnit> addTargets = new ArrayList<FightUnit>();
            while (iterator.hasNext()) {
                FightUnit target = iterator.next();

                if (target.name().equals(actor.name())) {
                    iterator.remove();
                    continue;
                }

                boolean isHave = false;
                for (FightUnit addTarget : addTargets) {
                    if (target.name().equals(addTarget.name())) {
                        isHave = true;
                        break;
                    }
                }

                if (isHave) {
                    iterator.remove();
                } else {
                    addTargets.add(target);
                }
            }
        }
    }

    /**
     * 对最终伤害加成（需要对全局伤害做处理的技能）
     * 
     * @param targets
     * @param targetCollection
     */
    private void finalHurtEnhance4Targets(List<FightUnit> targets, TargetCollection targetCollection) {
        List<FightUnit> targetsTemp = new ArrayList<FightUnit>();
        for (FightUnit target : targets) {
            targetsTemp.addAll(target.targetEnhance(actor, target, targetCollection, currentLevel));
        }
        targets.addAll(targetsTemp);
        clearRepeatTarget(targets, targetCollection);
    }

    /**
     * 对最终伤害加成（需要对全局伤害做处理的技能）
     * 
     * @param targets
     * @param targetCollection
     */
    private void finalHurtEnhance4Actor(List<FightUnit> targets, TargetCollection targetCollection) {
        List<FightUnit> targetsTemp = new ArrayList<FightUnit>();
        for (FightUnit target : targets) {
            targetsTemp.addAll(actor.targetEnhance(actor, target, targetCollection, currentLevel));
        }
        targets.addAll(targetsTemp);
        clearRepeatTarget(targets, targetCollection);
    }
}
