package com.hoolai.sangoh5.repo.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.equip.Equips;
import com.hoolai.sangoh5.bo.item.ItemBags;
import com.hoolai.sangoh5.bo.payment.MoonWeekCard;
import com.hoolai.sangoh5.bo.payment.RechargeHall;
import com.hoolai.sangoh5.bo.potion.OfficerEnhancePotion;
import com.hoolai.sangoh5.repo.ItemRepo;
import com.hoolai.sangoh5.repo.impl.key.ItemKey;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

@Repository("itemRepo")
public class ItemRepoImpl implements ItemRepo {

    @Autowired
    @Qualifier("itemClient")
    private ExtendedMemcachedClient client;

    @Autowired
    private BoFactory boFactory;

    @Override
    public boolean saveItemBags(ItemBags itemBags) {
        return client.set(ItemKey.getItemBagsKey(itemBags.getUserId()), itemBags.toByteArray());
    }

    @Override
    public ItemBags findItemBags(long userId) {
        String itemBagsKey = ItemKey.getItemBagsKey(userId);
        byte[] bytes = (byte[]) client.get(itemBagsKey);
        if (bytes == null) {
            //            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
            //        	return null;
            ItemBags item = new ItemBags(userId);
            return item;
        }
        ItemBags itemBags = new ItemBags(userId, bytes);
        boFactory.inject(itemBags);
        return itemBags;
    }

    @Override
    public boolean saveEquips(Equips equips) {
        return client.set(ItemKey.getEquipsKey(equips.getUserId()), equips.toByteArray());
    }

    @Override
    public Equips findEquips(long userId) {
        String itemBagsKey = ItemKey.getEquipsKey(userId);
        byte[] bytes = (byte[]) client.get(itemBagsKey);
        Equips equips = null;
        if (bytes == null) {
            equips = new Equips(userId);
        } else {
            equips = new Equips(userId, bytes);
        }
        boFactory.inject(equips);
        return equips;
    }

    @Override
    public boolean initUniqueEquipId(long userId) {
        String equipIdKey = ItemKey.getUniqueEquipIdKey(userId);
        return client.set(equipIdKey, "0");
    }

    @Override
    public int getUniqueEquipId(long userId) {
        String equipIdKey = ItemKey.getUniqueEquipIdKey(userId);
        int equipId = (int) client.justIncr(equipIdKey);
        /** incr没有成功??? */
        if (equipId < 0) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
        return equipId;
    }

	@Override
	public OfficerEnhancePotion findOfficerEnhancePotion(long userId) {
		String key = ItemKey.getOfficerEnhancePotionKey(userId);
		Object o = client.get(key);
		if(o == null){
			return boFactory.createOfficerEnhancePotion(userId);
		}else{
			OfficerEnhancePotion officerEnhancePotion = new OfficerEnhancePotion(userId,(byte[])o);
			boFactory.inject(officerEnhancePotion);
			officerEnhancePotion.init();
			if(officerEnhancePotion.isChange()){
				saveOfficerEnhancePotion(officerEnhancePotion);
			}
			return officerEnhancePotion;
		}
	}

	@Override
	public void saveOfficerEnhancePotion(OfficerEnhancePotion officerEnhancePotion) {
		 client.set(ItemKey.getOfficerEnhancePotionKey(officerEnhancePotion.getUserId()), 
				 officerEnhancePotion.toByteArray());
	}

	@Override
	public RechargeHall findRechargeHall(long userId) {
		String key = ItemKey.getRechargeHallKey(userId);
		Object o = client.get(key);
		if(o == null){
			RechargeHall rechargeHall = new RechargeHall(userId);
			rechargeHall.setRechargeHallData(boFactory.getRechargeHallData());
			client.add(key, rechargeHall.toByteArray());
			return rechargeHall;
		}else{
			RechargeHall rechargeHall = new RechargeHall(userId,(byte[])o);
			rechargeHall.setRechargeHallData(boFactory.getRechargeHallData());
			return rechargeHall;
		}
	}

	@Override
	public void saveRechargeHall(RechargeHall rechargeHall) {
		client.set(ItemKey.getRechargeHallKey(rechargeHall.getUserId()), rechargeHall.toByteArray());
	}

	@Override
	public MoonWeekCard findMoonWeekCard(long userId) {
		String key = ItemKey.getMoonWeekCardKey(userId);
		Object o = client.get(key);
		if(o == null){
			MoonWeekCard moonWeekCard = new MoonWeekCard(userId);
			client.add(key, moonWeekCard.toByteArray());
			return moonWeekCard;
		}else{
			MoonWeekCard moonWeekCard = new MoonWeekCard(userId,(byte[])o);
			return moonWeekCard;
		}
	}

	@Override
	public void saveMoonWeekCard(MoonWeekCard moonWeekCard) {
		client.set(ItemKey.getMoonWeekCardKey(moonWeekCard.getUserId()), moonWeekCard.toByteArray());
	}

}
