package com.hoolai.sangoh5.bo.officer.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class RecruitGoodsProperty extends JsonProperty {
	private String name;
	private String type;
	private int quantity;
	/** 1代表可被招募，0代表不能被招募 */
	private int onRecruit;
	private int diamondLv;
	private int normalLv;
	private int boxLv;
	private int militaryRank;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getOnRecruit() {
		return onRecruit;
	}
	public void setOnRecruit(int onRecruit) {
		this.onRecruit = onRecruit;
	}
	public int getDiamondLv() {
		return diamondLv;
	}
	public void setDiamondLv(int diamondLv) {
		this.diamondLv = diamondLv;
	}
	public int getNormalLv() {
		return normalLv;
	}
	public void setNormalLv(int normalLv) {
		this.normalLv = normalLv;
	}
	public int getBoxLv() {
		return boxLv;
	}
	public void setBoxLv(int boxLv) {
		this.boxLv = boxLv;
	}
	public int getMilitaryRank() {
		return militaryRank;
	}
	public void setMilitaryRank(int militaryRank) {
		this.militaryRank = militaryRank;
	}
	
}
