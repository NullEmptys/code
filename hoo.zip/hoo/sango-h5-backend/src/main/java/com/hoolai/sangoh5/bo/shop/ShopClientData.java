package com.hoolai.sangoh5.bo.shop;

import java.util.List;

/**
 * 商城数据
 * 
 * @author hp
 *
 */
public class ShopClientData {
	private List<ShopListIdsAndNum> itemList;// 商城道具信息

	private int needCoinNum;// 需要的联盟币

	private long leftTime;// 剩余时间

	public List<ShopListIdsAndNum> getItemList() {
		return itemList;
	}

	public void setItemList(List<ShopListIdsAndNum> itemList) {
		this.itemList = itemList;
	}

	public int getNeedCoinNum() {
		return needCoinNum;
	}

	public void setNeedCoinNum(int needCoinNum) {
		this.needCoinNum = needCoinNum;
	}

	public long getLeftTime() {
		return leftTime;
	}

	public void setLeftTime(long leftTime) {
		this.leftTime = leftTime;
	}

}
