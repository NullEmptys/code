package com.hoolai.sangoh5.bo.battle.skill.passive;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.CaptainshipBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/*
 * 对方每死亡一个单位，则增加N%的攻击力。
 * 我方每死亡一个单位，则增加N%的防御力。
 */
public class BingHun extends AttributeEnhanceSkill {

    // 记录一下增加攻击力的序号，如果一个单元的buff，捕捉到可以加攻击力的条件，应该给所有单元加上攻击力
    // 因为有的单元在跑动中，可能不去执行afterbuff
    private int addAttackIndex;

    private int addDefenceIndex;

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {

        actor.addAfterActionBuff(new CaptainshipBuff(xmlId, actor.name(), actor, this, Effect.MONITORING_BUFF_LEVEL, false, aliveTargetUnitList(tc, actor)).withKeepBuff()
                .withRepeatCount(MaxRepeatCount).withActorName(actor.name()).withTargetName(actor.name()));

        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]");
    }

    @Override
    public Skill clone() {
        return super.clone(new BingHun());
    }

    public int getAddAttackIndex() {
        return addAttackIndex;
    }

    public void setAddAttackIndex(int addAttackIndex) {
        this.addAttackIndex = addAttackIndex;
    }

    public int getAddDefenceIndex() {
        return addDefenceIndex;
    }

    public void setAddDefenceIndex(int addDefenceIndex) {
        this.addDefenceIndex = addDefenceIndex;
    }

}
