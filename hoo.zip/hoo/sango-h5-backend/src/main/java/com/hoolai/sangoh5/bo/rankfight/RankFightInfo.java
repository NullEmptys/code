package com.hoolai.sangoh5.bo.rankfight;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.RankFightInfoProto;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class RankFightInfo implements ProtobufSerializable<RankFightInfoProto> {

    private long launchUserId;// 主动发起挑战的人launchUserId == userId说明是主动挑战，反之被挑战

    private long fightUserId; // 战斗对方的userId

    private int fightUserRank;// 战斗对方当时的user等级

    private long fightTime;// 战斗时间

    private boolean isWin;// 是否胜利

    private int rank; // 战斗后的排位

    private int battleId; // 战报ID

    private int fightStatus;// 0,上升 1 下降 2 没变化

    private String fightUserName;// 战斗对方的名字

    private String fightUserImage;// 战斗对方的头像

    private long userId;// 这条信息属于谁

    public enum RankFightStatus {
        up, down, none
    }

    public RankFightInfo(long ownerUserId, long launchUserId, long fightUserId, int fightUserRank, long fightTime, boolean isWin, int rank, int battleId,
            RankFightStatus fightStatus) {
        super();
        this.userId = ownerUserId;
        this.launchUserId = launchUserId;
        this.fightUserId = fightUserId;
        this.fightUserRank = fightUserRank;
        this.fightTime = fightTime;
        this.isWin = isWin;
        this.rank = rank;
        this.battleId = battleId;
        this.fightStatus = fightStatus.ordinal();
    }

    public RankFightInfo(byte[] bytes) {
        this.parseFrom(bytes);
    }

    public void refresh(User fightUser) {
        this.fightUserImage = fightUser.getImage();
        this.fightUserName = fightUser.getName();
    }

    public long getFightUserId() {
        return fightUserId;
    }

    public void setFightUserId(long fightUserId) {
        this.fightUserId = fightUserId;
    }

    public int getFightUserRank() {
        return fightUserRank;
    }

    public void setFightUserRank(int fightUserRank) {
        this.fightUserRank = fightUserRank;
    }

    public long getFightTime() {
        return fightTime;
    }

    public void setFightTime(long fightTime) {
        this.fightTime = fightTime;
    }

    public boolean isWin() {
        return isWin;
    }

    public void setWin(boolean isWin) {
        this.isWin = isWin;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getBattleId() {
        return battleId;
    }

    public void setBattleId(int battleId) {
        this.battleId = battleId;
    }

    public String getFightUserName() {
        return fightUserName;
    }

    public void setFightUserName(String fightUserName) {
        this.fightUserName = fightUserName;
    }

    public String getFightUserImage() {
        return fightUserImage;
    }

    public void setFightUserImage(String fightUserImage) {
        this.fightUserImage = fightUserImage;
    }

    public int getFightStatus() {
        return fightStatus;
    }

    public void setFightStatus(int fightStatus) {
        this.fightStatus = fightStatus;
    }

    public long getLaunchUserId() {
        return launchUserId;
    }

    public void setLaunchUserId(long launchUserId) {
        this.launchUserId = launchUserId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    @Override
    public RankFightInfoProto copyTo() {
        RankFightInfoProto.Builder builder = RankFightInfoProto.newBuilder();
        builder.setBattleId(battleId);
        builder.setFightTime(fightTime);
        builder.setFightUserId(fightUserId);
        builder.setLaunchUserId(launchUserId);
        builder.setFightUserRank(fightUserRank);
        builder.setRank(rank);
        builder.setIsWin(isWin);
        builder.setFightUserName(fightUserName);
        if (fightUserImage != null) {
            builder.setFightUserImage(fightUserImage);
        }
        builder.setUserId(userId);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            RankFightInfoProto message = RankFightInfoProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(RankFightInfoProto message) {
        this.battleId = message.getBattleId();
        this.fightTime = message.getFightTime();
        this.fightUserId = message.getFightUserId();
        this.fightUserRank = message.getFightUserRank();
        this.rank = message.getRank();
        this.isWin = message.getIsWin();
        this.userId = message.getUserId();
        this.launchUserId = message.getLaunchUserId();
        this.fightUserName = message.getFightUserName();
        this.fightUserImage = message.getFightUserImage();
    }

}
