package com.hoolai.sangoh5.bo.award;

import com.hoolai.sangoh5.bo.pvp.Contribute.PvpBattleType;

/**
 * 奖励途径
 * 
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-23 16:36
 * @version : 1.0
 */
public enum AwardChannel {
    /**
     * 首充
     */
    FirstPay("首充"),

    /**
     * 连续登录
     */
    CumulativeLogin("连续登录"),

    /**
     * 月卡
     */
    MonthCard("月卡"),

    /**
     * 周卡
     */
    WeekCard("周卡"),

    /**
     * 等级礼包
     */
    LevelGift("等级礼包"),

    /**
     * 神兵天将
     */
    SpecialSoldier("神兵天将"),

    /**
     * 十连抽
     */
    Luckdraw("十连抽"),

    /**
     * 转盘
     */
    LuckyWheel("转盘"),

    Invite("邀请"),

    Focuson("关注"),

    /**
     * 累计消费
     */
    CumulativePay("累计消费"),

    RechargePc("pc重置活动"),

    LoginGift("pc登录"),

    Family("阖家欢"),

    Thutmose("图特摩斯"),

    AreanFight("竞技场战斗掉落青铜钥匙"),

    OpenBox("开宝箱"),

    MaiAttachment("邮件附件"),

    MissionReward("任务奖励"),

    PveFight("pve战斗"),

    PveBox("pve宝箱"),

    PveStageBox("pve关卡宝箱"),

    PveSweep("pve扫荡"),

    PvpFight("pvp战斗"),

    PvpRescue("pvp解救"),

    Revenge("pvp复仇"),

    PvpResumed("pvp收复"),

    PvpUnionBox("pvp联盟宝箱"),

    PvpStageBox("pvp州宝箱"),

    PvpCampBox("pvp势力宝箱"),

    RankFight("排位战战斗"),

    RankFightDaily("排位战每日奖励"),

    Recruit("酒馆招募"),

    TenRecruit("10连抽酒馆招募"),

    JoinUnion("加入联盟"),

    RemoveSkill("删除技能"),

    ChangeSkill("更改技能"),

    SpeedSoldier("士兵训练加速"),

    CONQUESTS("招降"),

    UseItem("使用道具"),

    UseItemByFunction("功能中使用经验丹"),

    Strength("强化"),

    LearnSkill("学习技能"),

    LearnSoldier("学习士兵"),

    OfficerStar("将领升星"),

    AddProvender("加粮草"),

    UnionDonate("联盟捐献"),

    HarvestGold("收获粮草"),

    HarvestMeteorite("收获陨铁"),

    TraingSoldier("训练士兵"),

    FarmAndMineLevelUp("升级农田"),

    Buyitem("购买道具"),

    BuySweepTimes("购买扫荡次数"),

    BuyPvpFightTimes("购买pvp次数"),

    BuyRankFightTimes("购买排位战次数"),

    BuyRescueTimes("购买悬赏次数"),

    BuySpecailSoldier("神兵天将购买"),

    BuyItemFriendShip("友情商店购买"),

    CreateUnion("创建联盟"),

    Recharge("充值"),

    EquipAdvanced("装备进阶"),

    RankFightShop("排位战商店"),

    ArenaShop("竞技场商店"),

    UnionShop("联盟商店"),

    Cdkey("兑换礼包"),

    NewFunction("新功能开启奖励");

    private final String name;

    private AwardChannel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static AwardChannel getAwardChannel(PvpBattleType pvpBattleType) {
        switch (pvpBattleType) {
            case occupy:
                return PvpFight;
            case rescue:
                return PvpRescue;
            case resumed:
                return PvpResumed;
            case revenge:
                return Revenge;
            default:
                break;
        }
        throw new RuntimeException("not found pvp battle type " + pvpBattleType);
    }

}
