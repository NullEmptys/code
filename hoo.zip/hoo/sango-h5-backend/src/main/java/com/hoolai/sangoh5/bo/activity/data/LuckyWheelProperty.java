package com.hoolai.sangoh5.bo.activity.data;

import java.util.List;

import com.google.common.collect.Lists;
import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.util.Weightable;
import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 15:38
 * @version : 1.0
 */
public class LuckyWheelProperty extends JsonProperty implements Weightable {

    /** 活动id **/
    private int id;

    /** 类型 **/
    private int type;

    /** 奖励类型 **/
    private String[] rewardType;

    /** 奖励id **/
    private int[] rewardId;

    /** 奖励数量 **/
    private int[] rewardNum;

    /** 概率 **/
    private int probability;

    public LuckyWheelProperty() {
    }

    public LuckyWheelProperty(int id, String rewardType, int rewardId, int lantianyu, int probability) {
        this.id = id;
        this.rewardType = new String[] { rewardType };
        this.rewardId = new int[] { rewardId };
        this.rewardNum = new int[] { lantianyu };
        this.probability = probability;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String[] getRewardType() {
        return rewardType;
    }

    public void setRewardType(String[] rewardType) {
        this.rewardType = rewardType;
    }

    public int[] getRewardId() {
        return rewardId;
    }

    public void setRewardId(int[] rewardId) {
        this.rewardId = rewardId;
    }

    public int getProbability() {
        return probability;
    }

    public void setProbability(int probability) {
        this.probability = probability;
    }

    public int[] getRewardNum() {
        return rewardNum;
    }

    public void setRewardNum(int[] rewardNum) {
        this.rewardNum = rewardNum;
    }

    @Override
    public int getWeight() {
        return probability;
    }

    public List<Award> getAwardList() {
        List<Award> items = Lists.newArrayListWithExpectedSize(rewardType.length);
        for (int i = 0; i < rewardType.length; i++) {
            items.add(new Award(rewardId[i], rewardNum[i], AwardType.converToAwardType(rewardType[i])));
        }
        return items;
    }

}
