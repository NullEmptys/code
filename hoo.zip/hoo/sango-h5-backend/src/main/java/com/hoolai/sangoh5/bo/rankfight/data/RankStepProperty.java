package com.hoolai.sangoh5.bo.rankfight.data;

import java.util.List;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * 排位殿根据等级划分的区域
 * 
 * @author hp
 *
 */
public class RankStepProperty extends JsonProperty {

    /** 阶段名称 */
    private String name;

    /** 对应等级限制 闭区间 */
    private List<Integer> level;

    /** 对应宝箱奖励金币百分比 */
    private int goldPercent;

    /** 升级至对应区域奖励类型 */
    private List<String> stepRewardType;

    /** 升级至对应区域奖励id */
    private List<Integer> stepRewardId;

    /** 升级至对应区域奖励数量 */
    private List<Integer> stepRewardNum;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Integer> getLevel() {
        return level;
    }

    public void setLevel(List<Integer> level) {
        this.level = level;
    }

    public int getGoldPercent() {
        return goldPercent;
    }

    public void setGoldPercent(int goldPercent) {
        this.goldPercent = goldPercent;
    }

    public List<String> getStepRewardType() {
        return stepRewardType;
    }

    public void setStepRewardType(List<String> stepRewardType) {
        this.stepRewardType = stepRewardType;
    }

    public List<Integer> getStepRewardId() {
        return stepRewardId;
    }

    public void setStepRewardId(List<Integer> stepRewardId) {
        this.stepRewardId = stepRewardId;
    }

    public List<Integer> getStepRewardNum() {
        return stepRewardNum;
    }

    public void setStepRewardNum(List<Integer> stepRewardNum) {
        this.stepRewardNum = stepRewardNum;
    }

}
