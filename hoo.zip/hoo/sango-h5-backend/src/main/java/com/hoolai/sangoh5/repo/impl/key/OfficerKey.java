package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class OfficerKey {

    private static final String prefix= "off";
	
    public static String getUserOfficersKey(long userId) {
    	 return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
                 .append("os").toString();
    }
    
    public static String getUniqueOfficerIdKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
                .append("oid").toString();
    }
}
