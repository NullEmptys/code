package com.hoolai.sangoh5.bo.pve.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class MonsterProperty extends JsonProperty {

    private String name;

    private int officerId;

    private int hp;

    private float attack;

    private float defence;

    private float ms;

    private float as;

    private int type;

    private int[] soldierType;

    private int[] soldierAmount;

    private int[] skill;

    private int weapon;

    private int armor;

    private int helmet;

    private int horse;

    private int defaultTactical;

    private int starLv;

    private int officerLv;

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the officerId
     */
    public int getOfficerId() {
        return officerId;
    }

    /**
     * @param officerId the officerId to set
     */
    public void setOfficerId(int officerId) {
        this.officerId = officerId;
    }

    /**
     * @return the hp
     */
    public int getHp() {
        return hp;
    }

    /**
     * @param hp the hp to set
     */
    public void setHp(int hp) {
        this.hp = hp;
    }

    /**
     * @return the attack
     */
    public float getAttack() {
        return attack;
    }

    /**
     * @param attack the attack to set
     */
    public void setAttack(float attack) {
        this.attack = attack;
    }

    /**
     * @return the defence
     */
    public float getDefence() {
        return defence;
    }

    /**
     * @param defence the defence to set
     */
    public void setDefence(float defence) {
        this.defence = defence;
    }

    /**
     * @return the ms
     */
    public float getMs() {
        return ms;
    }

    /**
     * @param ms the ms to set
     */
    public void setMs(float ms) {
        this.ms = ms;
    }

    /**
     * @return the as
     */
    public float getAs() {
        return as;
    }

    /**
     * @param as the as to set
     */
    public void setAs(float as) {
        this.as = as;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    /**
     * @return the soldierType
     */
    public int[] getSoldierType() {
        return soldierType;
    }

    /**
     * @param soldierType the soldierType to set
     */
    public void setSoldierType(int[] soldierType) {
        this.soldierType = soldierType;
    }

    /**
     * @return the soldierAmount
     */
    public int[] getSoldierAmount() {
        return soldierAmount;
    }

    /**
     * @param soldierAmount the soldierAmount to set
     */
    public void setSoldierAmount(int[] soldierAmount) {
        this.soldierAmount = soldierAmount;
    }

    /**
     * @return the skill
     */
    public int[] getSkill() {
        return skill;
    }

    /**
     * @param skill the skill to set
     */
    public void setSkill(int[] skill) {
        this.skill = skill;
    }

    /**
     * @return the weapon
     */
    public int getWeapon() {
        return weapon;
    }

    /**
     * @param weapon the weapon to set
     */
    public void setWeapon(int weapon) {
        this.weapon = weapon;
    }

    /**
     * @return the armor
     */
    public int getArmor() {
        return armor;
    }

    /**
     * @param armor the armor to set
     */
    public void setArmor(int armor) {
        this.armor = armor;
    }

    /**
     * @return the helmet
     */
    public int getHelmet() {
        return helmet;
    }

    /**
     * @param helmet the helmet to set
     */
    public void setHelmet(int helmet) {
        this.helmet = helmet;
    }

    /**
     * @return the horse
     */
    public int getHorse() {
        return horse;
    }

    /**
     * @param horse the horse to set
     */
    public void setHorse(int horse) {
        this.horse = horse;
    }

    public int getDefaultTactical() {
        return defaultTactical;
    }

    public void setDefaultTactical(int defaultTactical) {
        this.defaultTactical = defaultTactical;
    }

    public int getStarLv() {
        return starLv;
    }

    public void setStarLv(int starLv) {
        this.starLv = starLv;
    }

    public int getOfficerLv() {
        return officerLv;
    }

    public void setOfficerLv(int officerLv) {
        this.officerLv = officerLv;
    }

}
