package com.hoolai.sangoh5.bo.battle.skill.soldier.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class BaoLie extends BaseSoldierPhysicsSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        this.actor = actor;
        target = actor.getDefender();
        if (null == target) {
            return null;
        }

        List<FightUnit> targets = new ArrayList<FightUnit>();
        Effect effect = new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name())
                .withDeltaHp(Math.round(calculateLostPoint() * (1 + percentage) + value));
        target.addEffect(effect);

        targets.add(target);
        targetDefence(actor, target, effect, null, tc, targets, currentLevel);
        return targets;
    }

    @Override
    public Skill clone() {
        return super.clone(new BaoLie());
    }

}
