package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.RangeSustainedBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 暗雷怒斩
 * 
 * 范围内固定伤害且持续性掉血
 * 
 * @author Administrator
 *
 */
public class AnLeiNuZhan extends BaseOfficerPhysicsSkill {

    @Override
    public Skill clone() {
        return super.clone(new AnLeiNuZhan());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            Effect effect = rangeHurt(actor, target, currentLevel);
            Buff buff = keepHurt(actor, target, currentLevel);
            targets.add(target);
            targetDefence(actor, target, effect, buff, tc, targets, currentLevel);
        }

        return targets;
    }

    /**
     * 持续伤害
     * 
     * @param actor
     * @param currentLevel
     * @param target
     */
    private Buff keepHurt(FightUnit actor, FightUnit target, int currentLevel) {
        Buff buff = target.findBuff(xmlId, actor.name());
        if (buff == null) {
            buff = new RangeSustainedBuff(actor, target.name(), this, currentLevel, Math.round(twoValue)).withActorName(actor.name()).withTargetName(target.name())
                    .withRepeatCount(twoRepeatCount);
            target.addBuff(buff);
        } else {
            buff.setRepeatCount(twoRepeatCount);
        }

        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "造成持续性伤害=" + Math.round(twoValue) + ",持续回合数=" + twoRepeatCount);
        return buff;
    }

    /**
     * 范围内伤害
     * 
     * @param actor
     * @param currentLevel
     * @param target
     */
    private Effect rangeHurt(FightUnit actor, FightUnit target, int currentLevel) {
        Effect effect = new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withDeltaHp(calculateLostPoint4Skill(actor, target))
                .withTargetName(target.name());
        target.addEffect(effect);

        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "造成伤害=" + effect.getDeltaHp());
        return effect;
    }
}
