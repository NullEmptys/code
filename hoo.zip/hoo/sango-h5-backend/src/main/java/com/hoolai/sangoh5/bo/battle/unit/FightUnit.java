package com.hoolai.sangoh5.bo.battle.unit;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.effect.EnhanceEffect;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.fight.ActionResult;
import com.hoolai.sangoh5.bo.battle.fight.ActionType;
import com.hoolai.sangoh5.bo.battle.fight.BattleEnhance;
import com.hoolai.sangoh5.bo.battle.fight.BattleLog;
import com.hoolai.sangoh5.bo.battle.fight.HpLostListener;
import com.hoolai.sangoh5.bo.battle.fight.LifecycleListener;
import com.hoolai.sangoh5.bo.battle.fight.Match;
import com.hoolai.sangoh5.bo.battle.fight.PositionManager;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillData;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.DefencePassiveSkill;
import com.hoolai.sangoh5.bo.battle.skill.enhance.SkillEnhances;
import com.hoolai.sangoh5.bo.battle.skill.passive.AttributeEnhanceSkill;
import com.hoolai.sangoh5.bo.battle.skill.trigger.SkillTrigger;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.util.ProbabilityGenerator;
import com.hoolai.sangoh5.util.ProbabilityGeneratorImpl;

public abstract class FightUnit {

    protected static final Log logger = LogFactory.getLog("battle");

    public final static float ROUND_SPEND = 0.05f;

    protected ProbabilityGenerator pg = ProbabilityGeneratorImpl.getInstance();

    protected Officer officer;

    protected int originalHp; // 初始血量

    protected int hp; // 实时血量

    protected boolean isAttacker;// 是否攻击者

    protected float attackPoint; // 实时攻击力

    protected float defencePoint; // 实时防御力

    protected float attackSpeed;//攻击速度

    protected float moveSpeed;//移动速度

    protected float baseAttackPoint;// 基本攻击力

    protected float baseDefencePoint;// 基本防御力

    protected float baseAttackSpeed;// 基本攻速

    protected float baseMoveSpeed;// 基本移速

    protected float baseHp;// 基本血量

    protected PositionManager positionManager;// 站位管理器

    protected ActionType actionType = ActionType.NONE; // 执行的动作类型

    protected SkillEnhances skillEnhances;

    protected boolean isHaveNewTarget;// 是否有新目标

    protected boolean isConvergedAttacking;// 是否夹击

    protected int initPos = 5;//单位的初始位置

    protected int[] initPosition = {};// 单位的初始坐标

    protected int initRow = 0;// 单位初始排位

    protected FightUnit defender;// 我在攻击谁

    protected FightUnit lastDefender;//上一次攻击的对象，被围攻者选择围攻者用

    protected List<FightUnit> attackers = new ArrayList<FightUnit>(); // 谁在攻击我

    protected List<FightUnit> companionAttacker = new ArrayList<FightUnit>(); // 我和谁并肩作战

    protected List<SameBoatUnit> sameBoatUnits = new ArrayList<SameBoatUnit>(); // 生命链接 一人受伤害，被链接的人一同掉血

    protected boolean isCanAttackAllTargets;//生命链接可攻击战场所有被链接的人

    protected Behavior behavior = new Behavior();// 战斗单元行为状态

    /** 主动技能 */
    protected List<Skill> activeSkills;

    /** 被动技能 */
    protected List<AttributeEnhanceSkill> passiveSkills;

    /** 反击技能/100%发生的防御技能 */
    protected List<DefencePassiveSkill> counterAttackSkills;

    /** 对技能进行加成的技能 */
    //    protected List<EnhanceSkill> enhanceSkills;

    /** 从敌方学习到的技能 */
    protected int[] stealSkills;

    /** 技能触发器 */
    protected SkillTrigger trigger;

    protected BattleEnhance battleEnhance;// 系统的各个功能模块对战斗的加成

    protected transient int attackRoundCounter;// 记录每个攻击、移动行为的计时器，完成这个行为后清零，进行下一个行为的计数

    protected transient int actionCounter;// 将领动作的计时器，目前并没有什么用

    // 战斗单元监听器，控制是否还可以继续战斗，死亡移除，复活增加
    protected transient LifecycleListener lifecycleListener = LifecycleListener.NONE;

    // 士兵总血量监听器
    protected transient HpLostListener hpLostListener = HpLostListener.NONE;

    /** 对技能效果造成影响的加成 */
    protected transient List<EnhanceEffect> enhanceEffectList = new ArrayList<EnhanceEffect>();

    // 技能和普攻伤害
    protected transient List<Effect> effectList = new ArrayList<Effect>();

    // 包括持续性有效的伤害、加成，或者某种效果的监听器
    protected transient List<Buff> buffList = new ArrayList<Buff>();

    // 一回合执行完所有的伤害以后，执行的效果
    protected transient List<Buff> afterActionBuffList = new ArrayList<Buff>();

    // 在战斗之前就起效和前端需要播放的buff
    protected transient List<Buff> beforeBattleBuff = new ArrayList<Buff>();

    // buff衍生的buff，无法直接放buffList中，在这暂存，事后需要重新归入buffList中
    protected transient List<Buff> afterBuffList = new ArrayList<Buff>();

    protected transient BattleLog battleLog;

    protected transient SkillData skillData;

    public FightUnit(boolean isAttacker, int hp) {
        this.isAttacker = isAttacker;
        this.originalHp = hp;
        this.hp = hp;

        skillEnhances = new SkillEnhances();
    }

    public abstract void changeHp(int deltaHp);

    public abstract boolean isDead();

    public abstract FightUnitName name();

    public abstract void init();

    protected abstract void initAttributes();

    public abstract void initSkills();

    public abstract float baseAttackPoint();

    public abstract float baseAttackSpeed();

    public abstract float baseMoveSpeed();

    public abstract DefenceSkill useDefenceSkill();

    /**
     * 静默，不能移动，不能攻击
     */
    public void silence() {
        this.behavior.setSlince(true);
    }

    public void unsilence() {
        this.behavior.setSlince(false);
    }

    /**
     * 技能沉默，不能使用技能
     */
    public void chenMo() {
        this.behavior.setChenMo(true);
    }

    public void unChenMo() {
        this.behavior.setChenMo(false);
    }

    /**
     * 物理攻击沉默，只能触发技能，如果没有技能或者未触发技能，攻击停顿
     * 正在移动的单元不能移动
     */
    public void phyChenMo() {
        this.behavior.setPhyChenMo(true);
    }

    public void unPhyChenMo() {
        this.behavior.setPhyChenMo(false);
    }

    /**
     * 屏蔽技能效果和伤害
     */
    public void shieldSkillHurt() {
        this.behavior.setShieldSkillHurt(true);
    }

    public void unShieldSkillHurt() {
        this.behavior.setShieldSkillHurt(false);
    }

    public void shieldBaseHurt() {
        this.behavior.setShieldBaseHurt(true);
    }

    public void unShieldBaseHurt() {
        this.behavior.setShieldBaseHurt(false);
    }

    public abstract Action action(int roundCounter);

    public void setIsHaveNewTarget(boolean isHaveNewTarget) {
        this.isHaveNewTarget = isHaveNewTarget;
    }

    public boolean isHaveNewTarget() {
        return isHaveNewTarget;
    }

    public void addEffect(Effect effect) {
        if (behavior.isShieldSkillHurt() && effect.isUsedSkill()) {
            battleLog.add(this.name() + "屏蔽" + effect.getTargetUsedSkillXmlId() + "技能伤害=" + effect.getDeltaHp());
            effect.setDeltaHp(0);
        }
        if (behavior.isShieldBaseHurt() && !effect.isUsedSkill()) {
            battleLog.add(this.name() + "屏蔽普攻伤害=" + effect.getDeltaHp());
            effect.setDeltaHp(0);
        }

        //TODO 测试用！！！！！！
        //        if (effect.getDeltaHp() > 0) {
        //            effect.setDeltaHp((int) Math.round(effect.getDeltaHp() * 0.1));
        //        }

        tongShang(effect);
        this.effectList.add(effect);
    }

    public void addTongShangEffect(Effect effect) {
        if (behavior.isShieldSkillHurt()) {
            return;
        }
        this.effectList.add(effect);
    }

    /**
     * 生命链接 一人受伤害，被链接的人一同掉血
     * 
     * @param effect
     */
    private void tongShang(Effect effect) {
        if (sameBoatUnits.size() > 0) {
            Iterator<SameBoatUnit> iterator = sameBoatUnits.iterator();
            while (iterator.hasNext()) {
                SameBoatUnit unit = iterator.next();
                if (unit != null) {
                    unit.addTongShangEffect(effect);
                }
            }
        }
    }

    public void addBuff(Buff buff) {
        if (behavior.isShieldSkillHurt()) {
            return;
        }
        this.buffList.add(buff);
    }

    public void addAfterBuff(Buff buff) {
        this.afterBuffList.add(buff);
    }

    //    public void removeBuff(int xmlId, FightUnitName actorName) {
    //        Iterator<Buff> iterator = buffList.iterator();
    //        while (iterator.hasNext()) {
    //            Buff buff = iterator.next();
    //            if (buff.getTargetUsedSkillXmlId() == xmlId && buff.getActorName().equals(actorName) && buff.getCurrentLevel() != Effect.MONITORING_BUFF_LEVEL) {
    //                iterator.remove();
    //            }
    //        }
    //    }

    public void removeBuff(Buff buff) {
        if (buff == null) return;
        buffList.remove(buff);
    }

    public void addAfterActionBuff(Buff buff) {
        this.afterActionBuffList.add(buff);
    }

    public boolean isAttacker() {
        return isAttacker;
    }

    public float attackPoint() {
        return this.attackPoint;
    }

    public float defencePoint() {
        return defencePoint;
    }

    public SkillEnhances getSkillEnhances() {
        return skillEnhances;
    }

    public void applyEffects(FightUnit actor, Skill skill, int actionLevel) {

        Iterator<Effect> effectIt = effectList.iterator();
        while (effectIt.hasNext()) {
            Effect effect = effectIt.next();
            if (effect.getCurrentLevel() <= actionLevel) {
                if (isDead()) {
                    effectIt.remove();
                } else if (effect.getActorName() == actor.name()) {
                    if (!this.isDead()) {
                        effect.apply(actor, this, skill);
                    }
                }
            }
        }
    }

    public void applyBuffs(FightUnit actor, IndependentSkill skill, int actionLevel) {
        for (Buff buff : buffList) {
            if (buff.getCurrentLevel() <= actionLevel && buff.getExecuteName() == actor.name()) {
                buff.apply(this);
            }
        }
        buffList.addAll(afterBuffList);
        afterBuffList.clear();
    }

    public Collection<? extends Effect> getAllEffectList(FightUnit actor, int actionLevel) {
        Iterator<Effect> effectIt = effectList.iterator();
        List<Effect> returnEffects = new ArrayList<Effect>();
        while (effectIt.hasNext()) {
            Effect effect = effectIt.next();
            if (effect.getCurrentLevel() <= actionLevel && effect.actorName() == actor.name()) {
                returnEffects.add(effect);
            }
        }
        return returnEffects;
    }

    public List<Buff> getNoRepeatBuffList(FightUnit actor, int actionLevel) {
        List<Buff> rbuffs = new ArrayList<Buff>();

        List<Buff> buffs = new ArrayList<Buff>();
        buffs.addAll(buffList);
        buffs.addAll(afterActionBuffList);
        for (Buff buff : buffs) {
            if (!buff.isCanRepeatPlay() && buff.getIsNew() && actor.name() == buff.getExecuteName() && buff.getCurrentLevel() <= actionLevel) {
                rbuffs.add(buff);
            }
        }
        return rbuffs;
    }

    public List<Buff> cloneRealTimeBuffList(FightUnitName name) {
        List<Buff> rbuffs = new ArrayList<Buff>();
        List<Buff> buffs = new ArrayList<Buff>();
        buffs.addAll(buffList);
        buffs.addAll(afterActionBuffList);
        for (Buff buff : buffs) {
            if (name == buff.getExecuteName() && buff.isForFront()) {
                Buff cloneBuff = buff.cloneRealTime();
                //                cloneBuff.setRepeatCount(1);
                rbuffs.add(cloneBuff);
            }
        }
        return rbuffs;
    }

    public void clearBuffs(FightUnit actor, int actionLevel) {
        Iterator<Buff> iterator = buffList.iterator();
        while (iterator.hasNext()) {
            Buff buff = iterator.next();
            if (!buff.isKeep() && actor.name() == buff.getExecuteName() && buff.getCurrentLevel() <= actionLevel) {
                iterator.remove();
            }
        }
    }

    public void clearEffects(FightUnit actor, int actionLevel) {
        Iterator<Effect> iterator = effectList.iterator();
        while (iterator.hasNext()) {
            Effect effect = iterator.next();
            if (effect.actorName() == actor.name() && effect.getCurrentLevel() <= actionLevel) {
                iterator.remove();
            }
        }
    }

    public ActionType getActionType() {
        return actionType;
    }

    public void setActionType(ActionType actionType) {
        this.actionType = actionType;
    }

    public float getAttackSpeed() {
        return attackSpeed;
    }

    public void setAttackSpeed(float attackSpeed) {
        this.attackSpeed = attackSpeed;
    }

    public float getMoveSpeed() {
        return moveSpeed;
    }

    public void setMoveSpeed(float moveSpeed) {
        this.moveSpeed = moveSpeed;
    }

    public PositionManager getPositionManager() {
        return positionManager;
    }

    public void setPositionManager(PositionManager positionManager) {
        this.positionManager = positionManager;
    }

    public void setLifecycleListener(Match match) {
        this.lifecycleListener = match;
    }

    public int getDefNum() {
        return hp;
    }

    public int getAttNum() {
        return hp;
    }

    public List<FightUnit> getAttackers() {
        return attackers;
    }

    public void addAttacker(FightUnit actor) {
        boolean isOwner = actor.name().equals(this.name());
        if (logger.isDebugEnabled()) {
            logger.debug(isOwner ? "把自己加进攻击者里面来了~！" : this.name() + "增加攻击者：" + actor.name());
        }

        if (!isOwner && !attackers.contains(actor)) {
            this.attackers.add(actor);
        }
        if (this.attackers.size() > 1) {
            if (logger.isDebugEnabled()) {
                logger.debug(this.name() + "的攻击者有：");
                StringBuilder sb = new StringBuilder();
                for (FightUnit aFightUnit : attackers) {
                    sb.append(aFightUnit.name()).append(",");
                }
                logger.debug(sb.toString());
            }

        }
    }

    public FightUnit getDefender() {
        return defender;
    }

    public void setDefender(FightUnit target) {
        this.defender = target;
        if (target != null) {
            this.lastDefender = target;
        }
    }

    public void addCompanionAttacker(FightUnit actor) {
        if (!hasCompanion(actor)) {
            this.companionAttacker.add(actor);
        }
    }

    private boolean hasCompanion(FightUnit actor) {
        Iterator<FightUnit> iterator = companionAttacker.iterator();
        while (iterator.hasNext()) {
            FightUnit unit = iterator.next();
            if (unit.name().equals(actor.name())) {
                return true;
            }
        }
        return false;
    }

    public boolean isOfficer() {
        return false;
    }

    public void removeAttacker(FightUnit fightUnit) {
        this.attackers.remove(fightUnit);
    }

    public void removeCompanionAttacker(FightUnit fightUnit) {
        Iterator<FightUnit> iterator = companionAttacker.iterator();
        while (iterator.hasNext()) {
            FightUnit unit = iterator.next();
            if (unit.name().equals(fightUnit.name())) {
                iterator.remove();
            }
        }
    }

    public int getInitPos() {
        return initPos;
    }

    public void setInitPos(int initPos) {
        this.initPos = initPos;
    }

    public int[] getInitPosition() {
        return initPosition;
    }

    public void setInitPosition(int[] initPosition) {
        this.initPosition = initPosition;
    }

    public abstract int getXmlId();

    public void changeAttackPoint(float deltaAttackPoint) {
        if (logger.isDebugEnabled()) {
            logger.debug(this.name() + "," + attackPoint + "攻击力增加：！！！！！！！！！！" + deltaAttackPoint);
        }
        this.attackPoint += deltaAttackPoint;
    }

    /**
     * 改变战斗单元的攻速
     * 
     * @param deltaAttackSpeed 正值提高攻速，负值降低攻速
     */
    public void changeAttackSpeed(float deltaAttackSpeed) {
        //        if (logger.isDebugEnabled()) {
        //	    	logger.debug(this.name() + ","+attackPoint + "攻速提高：！！！！！！！！！！" + deltaAttackSpeed);
        //    }
        this.attackSpeed -= deltaAttackSpeed;
    }

    public abstract float baseDefencePoint();

    public void changeDefencePoint(float deltaDefencePoint) {
        if (logger.isDebugEnabled()) {
            logger.debug(this.name() + "," + defencePoint + "防御力增加：！！！！！！！！！！" + deltaDefencePoint);
        }
        this.defencePoint += deltaDefencePoint;
    }

    public void setDefencePoint(float defencePoint) {
        //        if (logger.isDebugEnabled()) {
        //	    	logger.debug(this.name() + ","+defencePoint + "防御力更改为：！！！！！！！！！！" + defencePoint);
        //    }
        this.defencePoint = defencePoint;
    }

    public abstract float baseHp();

    public void changeOriginalHp(int deltaHp) {
        this.originalHp += deltaHp;
        this.hp += deltaHp;
    }

    public float getHp() {
        return hp;
    }

    public void changeAllSkillChance(float chance) {
        for (DefencePassiveSkill skill : this.counterAttackSkills) {
            skill.changeChance(chance);
        }
        trigger.changeAllSkillChance(chance);
    }

    public void changeSkillChance(int xmlId, float chance) {
        boolean isChange = false;
        for (DefencePassiveSkill skill : this.counterAttackSkills) {
            if (skill.getXmlId() == xmlId) {
                skill.changeChance(chance);
                isChange = true;
            }
        }
        if (!isChange) {
            trigger.changeSkillChance(xmlId, chance);
        }
    }

    public void setSkillData(SkillData skillData) {
        this.skillData = skillData;
    }

    public abstract void applyBeforeBattleSkill(TargetCollection tc);

    public void addEnhanceEffect(EnhanceEffect enhanceEffect) {
        this.enhanceEffectList.add(enhanceEffect);
    }

    public void removeEnhanceEffect(EnhanceEffect enhanceEffect) {
        enhanceEffectList.remove(enhanceEffect);
    }

    /**
     * buff不接受加成
     * 
     * @param actionLevel
     */
    public void enhanceEffect(int actionLevel) {
        for (EnhanceEffect enhanceEffect : this.enhanceEffectList) {
            for (Effect effect : effectList) {
                if (effect.getCurrentLevel() <= actionLevel) {
                    enhanceEffect.enhance(effect);
                }
            }
        }
    }

    public boolean isHaveDefencePassiveSkill(int skillXmlId) {
        Iterator<DefencePassiveSkill> iterator = counterAttackSkills.iterator();
        while (iterator.hasNext()) {
            DefencePassiveSkill defencePassiveSkill = iterator.next();
            if (defencePassiveSkill.getXmlId() == skillXmlId) {
                return true;
            }
        }
        return false;
    }

    public DefencePassiveSkill findDefencePassiveSkill(int skillXmlId) {
        Iterator<DefencePassiveSkill> iterator = counterAttackSkills.iterator();
        while (iterator.hasNext()) {
            DefencePassiveSkill defencePassiveSkill = iterator.next();
            if (defencePassiveSkill.getXmlId() == skillXmlId) {
                return defencePassiveSkill;
            }
        }
        return null;
    }

    /**
     * 一般将领技能用此方法够用，因为不会有相同的技能和相同的单元出现
     * 
     * @param xmlId
     * @return
     */
    public Buff findBuff(int xmlId) {
        Iterator<Buff> iterator = buffList.iterator();
        while (iterator.hasNext()) {
            Buff buff = iterator.next();
            if (buff.getTargetUsedSkillXmlId() == xmlId) {
                return buff;
            }
        }
        return null;
    }

    /**
     * 一个技能多个buff效果
     * 
     * @param xmlId
     * @return
     */
    public List<Buff> findBuffs(int xmlId) {
        List<Buff> buffs = new ArrayList<Buff>();
        Iterator<Buff> iterator = buffList.iterator();
        while (iterator.hasNext()) {
            Buff buff = iterator.next();
            if (buff.getTargetUsedSkillXmlId() == xmlId) {
                buffs.add(buff);
            }
        }
        return buffs;
    }

    /**
     * 多个攻击者使用同一个技能的效果攻击，效果叠加<br>
     * 一般给士兵使用
     * 
     * @param xmlId
     * @param actorName
     * @return
     */
    public Buff findBuff(int xmlId, FightUnitName actorName) {
        Iterator<Buff> iterator = buffList.iterator();
        while (iterator.hasNext()) {
            Buff buff = iterator.next();
            if (buff.getTargetUsedSkillXmlId() == xmlId && buff.actorName().equals(actorName)) {
                return buff;
            }
        }
        return null;
    }

    public List<Buff> getBeforeBattleBuff() {
        return beforeBattleBuff;
    }

    /**
     * 战斗之前被动加属性技能的buff
     * 
     * @param buff
     */
    public void addBeforeBattleBuff(Buff buff) {
        for (Buff bf : beforeBattleBuff) {
            if (bf.getTargetUsedSkillXmlId() == buff.getTargetUsedSkillXmlId() && bf.getTargetName().equals(buff.getTargetName())) {
                bf.addDeltaHp(buff.getDeltaHp());
                bf.withRepeatCount(buff.getRepeatCount());
                return;
            }
        }
        this.beforeBattleBuff.add(buff);
    }

    public List<FightUnit> targetEnhance(FightUnit actor, FightUnit target, TargetCollection targetCollection, int currentLevel) {
        List<FightUnit> newTargets = new ArrayList<FightUnit>();
        List<Buff> buffListTemp = new ArrayList<Buff>();
        buffListTemp.addAll(buffList);
        for (Buff buff : buffListTemp) {
            if (buff.getCurrentLevel() <= currentLevel) {
                newTargets.addAll(buff.targetEnhance(actor, target, targetCollection));
            }
        }
        return newTargets;
    }

    public List<FightUnit> targetEnhance(FightUnit actor, FightUnit target, TargetCollection targetCollection, Action action) {
        return Collections.emptyList();
    }

    public List<DefencePassiveSkill> getCounterAttackSkills() {
        return counterAttackSkills;
    }

    public void addCounterAttackSkills(DefencePassiveSkill skill) {
        this.counterAttackSkills.add(skill);
    }

    public void removeCounterAttackSkills(DefencePassiveSkill skill) {
        Iterator<DefencePassiveSkill> iterator = counterAttackSkills.iterator();
        while (iterator.hasNext()) {
            DefencePassiveSkill defencePassiveSkill = iterator.next();
            if (defencePassiveSkill.getXmlId() == skill.getXmlId()) {
                iterator.remove();
            }
        }
    }

    public List<Effect> getEffectList() {
        return effectList;
    }

    public int getOriginalHp() {
        return originalHp;
    }

    public int getInitRow() {
        return initRow;
    }

    public FightUnit getLastDefender() {
        return lastDefender;
    }

    public void setLastDefender(FightUnit lastDefender) {
        this.lastDefender = lastDefender;
    }

    public int getOfficerLevel() {
        return officer.getLevel();
    }

    public int getFormationId() {
        return officer.getCurrFormation().getId();
    }

    public boolean containsSameBoatUnit(SameBoatUnit sameBoatUnit) {
        for (SameBoatUnit unit : sameBoatUnits) {
            if (unit.equals(sameBoatUnit)) {
                return true;
            }
        }
        return false;
    }

    public void addSameBoatUnit(SameBoatUnit sameBoatUnit) {
        if (sameBoatUnits.contains(sameBoatUnit)) {
            return;
        }
        this.sameBoatUnits.add(sameBoatUnit);
    }

    public HpLostListener getHpLostListener() {
        return hpLostListener;
    }

    public void clearSameBoatUnit(int targetUsedSkillXmlId) {
        Iterator<SameBoatUnit> iterator = sameBoatUnits.iterator();
        while (iterator.hasNext()) {
            SameBoatUnit sameBoatUnit = iterator.next();
            if (sameBoatUnit.getSkillXmlId() == targetUsedSkillXmlId) {
                iterator.remove();
            }
        }
    }

    public int getOfficerStarLevel() {
        return officer.getStarLevel();
    }

    public void canAttackAllTargets() {
        isCanAttackAllTargets = true;
    }

    public boolean isCanAttackAllTargets() {
        return isCanAttackAllTargets;
    }

    public int[] getOfficerSkills() {
        return officer.getSkills();
    }

    /**
     * 添加偷学技能
     * 
     * @param skillId
     */
    public void addStealSkill(int skillId) {
        // 子类重写
    }

    public abstract void processStealSkillEffects(TargetCollection targetCollection);

    public void shieldControl() {
        this.behavior.setShieldControl(true);
    }

    public void unShieldControl() {
        this.behavior.setShieldControl(false);
    }

    public List<Buff> getBuffList() {
        return buffList;
    }

    public void targetEnhanceAfterExcuteBuffs(List<ActionResult> actionResultList, TargetCollection tc) {
        for (Buff buff : afterActionBuffList) {
            buff.targetEnhanceAfterExcuteBuffs(actionResultList, tc);
        }
    }

    public boolean isShieldControl() {
        return behavior.isShieldControl();
    }

    public void setBattleLog(BattleLog battleLog) {
        this.battleLog = battleLog;
    }

    /**
     * 以actor为主线
     * 
     * @param log
     */
    public void addBattleLog(String log) {
        this.battleLog.add(log);
    }

    public static boolean isSameTeam(FightUnit unit1, FightUnit unit2) {
        if (unit1.isAttacker() == unit2.isAttacker()) {
            return true;
        }
        return false;
    }

}
