//package com.hoolai.sangoh5.bo.battle.enhance.effect;
//
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//
//import com.hoolai.sangoh5.bo.battle.enhance.Buff;
//import com.hoolai.sangoh5.bo.battle.enhance.Effect;
//import com.hoolai.sangoh5.bo.battle.skill.Skill;
//import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
//
///**
// * 一些递进伤害的
// */
//public class Skill31HurtEnhanceEffect extends EnhanceEffect {
//
//    protected static final Log log = LogFactory.getLog("MoreHurtEnhanceEffect");
//
//    protected float hurtAddedRate;
//
//    protected String skillName;
//
//    protected int addDelHp;
//
//    protected int targetUsedSkillXmlId;
//
//    protected int repeatCount;
//
//    protected FightUnit skillOwner;
//
//    protected FightUnit target;
//
//    protected Skill skill;
//
//    protected Skill31HurtEnhanceEffect() {
//    }
//
//    public Skill31HurtEnhanceEffect(FightUnit actor, FightUnit target, Skill skill) {
//        this.hurtAddedRate = skill.getPercentage();
//        this.targetUsedSkillXmlId = skill.getXmlId();
//        this.skillName = skill.getName();
//        this.skillOwner = actor;
//        this.target = target;
//    }
//
//    public String getName() {
//        return skillName;
//    }
//
//    public void setHurtAddedRate(float hurtAddedRate) {
//        this.hurtAddedRate = hurtAddedRate;
//    }
//
//    public void setRepeatCount(int repeatCount) {
//        this.repeatCount = repeatCount;
//    }
//
//    @Override
//    public void enhance(Effect effect) {
//        enhance0(effect);
//    }
//
//    protected void enhance0(Effect effect) {
//        if (effect.actorName().equals(skillOwner.name()) && (repeatCount % ((int) (skillOwner.getAttackSpeed() * 10 * skill.getRound()))) == 0) {
//
//            target.changeAttackSpeed(-target.baseAttackSpeed() * 0.25f);
//
//            int oldDelHp = effect.getDeltaHp();
//            if (oldDelHp <= 0) {
//                return;
//            }
//            if (effect instanceof Buff) {
//                if (((Buff) effect).getIsNew() && effect.getDeltaHp() > 0) {
//                    addDelHp = (int) (effect.getDeltaHp() * hurtAddedRate);
//                    effect.addDeltaHp(addDelHp);
//                }
//            } else {
//                effect.setDeltaHp((int) (effect.getDeltaHp() * (1 + hurtAddedRate)));
//            }
//            //			if (logger.isDebugEnabled()) {
//            //			logger.debug("技能(" + targetUsedSkillXmlId + (skillName == null ? "基本攻击" : skillName)
//            //			+ ")效果： 加成前伤害," + oldDelHp + ", 加成后伤害："
//            //			+ effect.getDeltaHp() + ", actorName： "
//            //			+ effect.actorName() + ", targetName： "
//            //			+ effect.getTargetName() + ", TargetUsedSkillXmlId： "
//            //			+ effect.getTargetUsedSkillXmlId());
//            //		}
//        }
//    }
//
//    protected void enhance1(Effect effect) {
//    }
//
//    @Override
//    public int hashCode() {
//        final int prime = 31;
//        int result = 1;
//        result = prime * result + Float.floatToIntBits(hurtAddedRate);
//        return result;
//    }
//
//    @Override
//    public boolean equals(Object obj) {
//        if (this == obj) return true;
//        if (obj == null) return false;
//        if (getClass() != obj.getClass()) return false;
//        Skill31HurtEnhanceEffect other = (Skill31HurtEnhanceEffect) obj;
//        if (Float.floatToIntBits(hurtAddedRate) != Float.floatToIntBits(other.hurtAddedRate)) return false;
//        if (skillName != null && !skillName.equals(other.skillName)) return false;
//        return true;
//    }
//
//    @Override
//    public String toString() {
//        return skillName + ", " + hurtAddedRate + ", " + addDelHp;
//    }
//
//    public float getHurtAddedRate() {
//        return hurtAddedRate;
//    }
//
//}
