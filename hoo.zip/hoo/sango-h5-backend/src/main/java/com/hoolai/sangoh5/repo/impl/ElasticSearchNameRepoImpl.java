package com.hoolai.sangoh5.repo.impl;

import java.net.InetSocketAddress;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.elasticsearch.action.admin.indices.create.CreateIndexRequest;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequestBuilder;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.settings.Settings.Builder;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.transport.client.PreBuiltTransportClient;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hoolai.sangoh5.repo.NameRepo;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-06-26 20:24
 * @version : 1.0
 */
public class ElasticSearchNameRepoImpl implements NameRepo {

    private static final Log logger = LogFactory.getLog(ElasticSearchNameRepoImpl.class);

    private final String indexName;

    private static final String USER_indexName = "users";

    private static final String UNION_indexName = "unions";

    private final TransportClient client;

    public ElasticSearchNameRepoImpl(String address, String clusterName, String indexName) {
        Settings settings = Settings.builder().put("cluster.name", clusterName).build();

        client = new PreBuiltTransportClient(settings);
        String[] addressList = StringUtils.split(address, ',');
        for (String host : addressList) {
            String[] net = StringUtils.split(host, ':');
            if (net.length != 2) {
                throw new RuntimeException("host error " + host);
            }
            client.addTransportAddress(new InetSocketTransportAddress(new InetSocketAddress(net[0], Integer.valueOf(net[1]))));
        }
        this.indexName = indexName;
    }

    @Override
    public void init() {
        Builder builder = Settings.builder();
        builder.put("refresh_interval", "1s").put("number_of_shards", 3).put("number_of_replicas", 1);
        builder.put("analysis.analyzer.ik_max_word.type", "ik_max_word").put("analysis.analyzer.ik_max_word.use_smart", "false");
        builder.put("analysis.analyzer.ik_smart.type", "ik_max_word").put("analysis.analyzer.ik_smart.use_smart", "true");
        builder.put("analysis.analyzer.pinyin_analyzer.type", "custom").put("analysis.analyzer.pinyin_analyzer.tokenizer", "ik_max_word");
        builder.put("analysis.analyzer.pinyin_analyzer.filter", "my_pinyin,snowball,word_delimiter,stemmer");
        builder.put("analysis.filter.my_pinyin.type", "pinyin").put("analysis.filter.my_pinyin.first_letter", "none");
        builder.put("analysis.filter.my_pinyin.padding_char", "");

        Settings indexSettings = builder.build();
        CreateIndexRequest indexRequest = new CreateIndexRequest(indexName, indexSettings);
        client.admin().indices().create(indexRequest).actionGet();

        createUserIndex();

        createUnionIndex();
    }

    private void createUnionIndex() {
        Map<String, Object> mappingSource = Maps.newHashMap();

        Map<String, String> allMap = Maps.newHashMap();
        allMap.put("enabled", "false");//禁用 特殊区域
        mappingSource.put("_all", allMap);

        Map<String, String> sourceMap = Maps.newHashMap();
        sourceMap.put("enabled", "false");//禁用 特殊区域
        mappingSource.put("_source", sourceMap);

        Map<String, Object> fileds = Maps.newHashMap();

        Map<String, String> unionName = Maps.newHashMap();
        unionName.put("type", "string");
        unionName.put("store", "false");//yes 独立存储source之外 ，false不独立
        unionName.put("index", "analyzed");//1.分词 analyzed 2.不分词 可以精确搜索 not_analyzed  3.不分词，不能够被搜索到 no
        unionName.put("analyzer", "pinyin_analyzer");//设置索引时分词
        unionName.put("search_analyzer", "pinyin_analyzer");//查询时分词
        unionName.put("doc_values", "false");//
        unionName.put("include_in_all", "false");//是否添加到特殊区域 供搜索用
        //        userName.put("boost", "8");//是否添加到特殊区域 供搜索用
        fileds.put("unionName", unionName);

        Map<String, String> noAnalyzedName = Maps.newHashMap();
        noAnalyzedName.put("type", "string");
        noAnalyzedName.put("store", "false");//yes 独立存储source之外 ，false不独立
        noAnalyzedName.put("index", "not_analyzed");//1.分词 analyzed 2.不分词 可以精确搜索 not_analyzed  3.不分词，不能够被搜索到 no
        //        noAnalyzedName.put("analyzer", "pinyin_analyzer");//设置索引时分词
        //        noAnalyzedName.put("search_analyzer", "pinyin_analyzer");//查询时分词
        noAnalyzedName.put("doc_values", "false");//
        noAnalyzedName.put("include_in_all", "false");//是否添加到特殊区域 供搜索用
        //        userName.put("boost", "8");//是否添加到特殊区域 供搜索用
        fileds.put("noAnalyzedName", noAnalyzedName);

        Map<String, String> state = Maps.newHashMap();
        state.put("type", "integer");
        state.put("store", "false");//yes 独立存储source之外 ，false不独立
        state.put("index", "not_analyzed");//1.分词 analyzed 2.不分词 可以精确搜索 not_analyzed  3.不分词，不能够被搜索到 no
        //        noAnalyzedName.put("analyzer", "pinyin_analyzer");//设置索引时分词
        //        noAnalyzedName.put("search_analyzer", "pinyin_analyzer");//查询时分词
        state.put("doc_values", "false");//
        state.put("include_in_all", "false");//是否添加到特殊区域 供搜索用
        //        userName.put("boost", "8");//是否添加到特殊区域 供搜索用
        fileds.put("state", state);

        mappingSource.put("properties", fileds);

        client.admin().indices().preparePutMapping(indexName).setType(UNION_indexName).setSource(mappingSource).get();
    }

    private void createUserIndex() {
        Map<String, Object> mappingSource = Maps.newHashMap();

        Map<String, String> allMap = Maps.newHashMap();
        allMap.put("enabled", "false");//禁用 特殊区域
        mappingSource.put("_all", allMap);

        Map<String, String> sourceMap = Maps.newHashMap();
        sourceMap.put("enabled", "false");//禁用 特殊区域
        mappingSource.put("_source", sourceMap);

        Map<String, Object> fileds = Maps.newHashMap();
        Map<String, String> userName = Maps.newHashMap();
        userName.put("type", "string");
        userName.put("store", "false");//yes 独立存储source之外 ，false不独立
        userName.put("index", "analyzed");//1.分词 analyzed 2.不分词 可以精确搜索 not_analyzed  3.不分词，不能够被搜索到 no
        userName.put("analyzer", "pinyin_analyzer");//设置索引时分词
        userName.put("search_analyzer", "pinyin_analyzer");//查询时分词
        userName.put("doc_values", "false");//
        userName.put("include_in_all", "false");//是否添加到特殊区域 供搜索用
        //        userName.put("boost", "8");//是否添加到特殊区域 供搜索用
        fileds.put("userName", userName);

        mappingSource.put("properties", fileds);

        client.admin().indices().preparePutMapping(indexName).setType(USER_indexName).setSource(mappingSource).get();
    }

    @Override
    public void insertUser(long userId, String userName) {
        Map<String, Object> fields = Maps.newHashMapWithExpectedSize(1);
        fields.put("userName", userName);
        client.prepareIndex(indexName, USER_indexName).setSource(fields).setId(String.valueOf(userId)).execute();
    }

    @Override
    public void updateUser(long userId, String userName) {
        Map<String, Object> fields = Maps.newHashMapWithExpectedSize(1);
        fields.put("userName", userName);
        client.prepareUpdate(indexName, USER_indexName, String.valueOf(userId)).setDoc(fields).execute();
    }

    @Override
    public void deleteUser(long userId) {
        client.prepareDelete(indexName, USER_indexName, String.valueOf(userId)).execute();
    }

    @Override
    public List<Long> searchUser(String userName, int count) {
        QueryBuilder matchQuery = QueryBuilders.matchPhraseQuery("userName", userName);
        SearchResponse response = client.prepareSearch(indexName).setTypes(USER_indexName).setQuery(matchQuery).setSize(count).execute().actionGet();
        //获取查询结果集  
        SearchHits searchHits = response.getHits();
        List<Long> userIds = Lists.newArrayListWithExpectedSize((int) searchHits.getTotalHits());

        for (SearchHit hit : searchHits) {
            userIds.add(Long.valueOf(hit.getId()));
        }
        return userIds;
    }

    @Override
    public void insertUnion(long unionId, int state, String unionName) {
        Map<String, Object> fields = Maps.newHashMapWithExpectedSize(2);
        fields.put("unionName", unionName);
        fields.put("noAnalyzedName", unionName);
        fields.put("state", state);
        client.prepareIndex(indexName, UNION_indexName).setSource(fields).setId(String.valueOf(unionId)).execute();
    }

    @Override
    public void updateUnion(long unionId, int state, String unionName) {
        Map<String, Object> fields = Maps.newHashMapWithExpectedSize(2);
        fields.put("unionName", unionName);
        fields.put("noAnalyzedName", unionName);
        fields.put("state", state);
        client.prepareUpdate(indexName, UNION_indexName, String.valueOf(unionId)).setDoc(fields).execute();
    }

    @Override
    public void deleteUnion(long unionId) {
        client.prepareDelete(indexName, UNION_indexName, String.valueOf(unionId)).execute();
    }

    @Override
    public boolean exitUnionName(String unionName) {
        QueryBuilder matchQuery = QueryBuilders.termQuery("noAnalyzedName", unionName);
        SearchResponse response = client.prepareSearch(indexName).setTypes(UNION_indexName).setQuery(matchQuery).setSize(30).execute().actionGet();
        SearchHits searchHits = response.getHits();
        return searchHits.getTotalHits() > 0;
    }

    @Override
    public List<Long> searchUnion(int state, String unionName) {
        QueryBuilder matchQuery = QueryBuilders.boolQuery().must(QueryBuilders.termQuery("state", state)).must(QueryBuilders.matchPhraseQuery("unionName", unionName));
        SearchResponse response = client.prepareSearch(indexName).setTypes(UNION_indexName).setQuery(matchQuery).setSize(50).execute().actionGet();
        SearchHits searchHits = response.getHits();
        List<Long> unionIds = Lists.newArrayListWithExpectedSize((int) searchHits.getTotalHits());

        for (SearchHit hit : searchHits) {
            unionIds.add(Long.valueOf(hit.getId()));
        }
        return unionIds;
    }

    @Override
    public void clearIndex() {
        IndicesExistsResponse res = client.admin().indices().prepareExists(indexName).execute().actionGet();
        if (res.isExists()) {
            DeleteIndexRequestBuilder delIdx = client.admin().indices().prepareDelete(indexName);
            delIdx.execute().actionGet();
        }
    }

    public void destroy() throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("client is destory");
        }
        client.close();
    }

}
