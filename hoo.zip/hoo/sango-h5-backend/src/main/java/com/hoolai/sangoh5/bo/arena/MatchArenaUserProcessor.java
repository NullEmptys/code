package com.hoolai.sangoh5.bo.arena;

import java.util.List;

import org.compass.core.util.CollectionUtils;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.pve.data.MonsterData;
import com.hoolai.sangoh5.repo.ArenaRepo;

public class MatchArenaUserProcessor {

    private final ArenaUser arenaUser;

    private ArenaUser matchUser;

    private final long userId;

    private ArenaRepo arenaRepo;

    private BoFactory boFactory;

    public MatchArenaUserProcessor(ArenaUser arenaUser) {
        this.arenaUser = arenaUser;
        this.userId = arenaUser.getUserId();
    }

    public ArenaUser matchUser() {
        int currentRank = (int) arenaUser.getCurrentRank();

        for (int i = 1; i <= 5; i++) {
            matchUser = randomUser(currentRank - i * 10, currentRank + i * 10);
            if (matchUser != null) {
                break;
            }
        }

        if (matchUser == null) {
            matchUser = createNpc();
        }

        return matchUser;
    }

    private ArenaUser randomUser(int start, int stop) {
        List<Long> userIds = arenaRepo.getUsersByRank(start, stop);
        if (CollectionUtils.isEmpty(userIds)) {
            return null;
        }
        userIds.remove(Long.valueOf(userId));
        if (CollectionUtils.isEmpty(userIds)) {
            return null;
        }

        int index = userIds.size() == 1 ? 0 : boFactory.getPg().getRandomNumber(userIds.size() - 1);

        long matchUserId = userIds.get(index);

        //FIXME why choose arenaUser.getCurrentOfficerId() == -1
        return arenaRepo.findArenaUser(matchUserId);
    }

    //    private ArenaUser randomUser(int sorceTemp) {
    //        List<Long> userIds = arenaRepo.getUsersByRank(sorceTemp, 10, userId);
    //        if (userIds != null && userIds.size() > 0) {
    //            for (long matchUserId : userIds) {
    //                ArenaUser arenaUser = arenaRepo.findArenaUser(matchUserId);
    //                if (arenaUser.getCurrentOfficerId() == -1) {
    //                    continue;
    //                }
    //                if (!arenaRepo.lockArenaUser(arenaUser.getUserId())) {
    //                    continue;
    //                }
    //                return arenaUser;
    //            }
    //        }
    //        return null;
    //    }

    private ArenaUser createNpc() {
        ArenaUser arenaUser = this.arenaUser.cloneArenaUser();
        arenaUser.setUserId(-userId);
        arenaUser.setBofactory(boFactory);
        return arenaUser;
    }

    public Officer createNpcOfficer() {
        MonsterData monsterData = boFactory.getMonsterData();
        Officer monster = monsterData.createArenaMonster();
        return monster;
    }

    public Officer createNpcOfficer(Officer officer) {
        Officer officerNpc = officer.cloneOfficer();

        int officerLv = officerNpc.getLevel();
        officerNpc.setUserId(-userId);
        officerNpc.setLevel(officerLv);
        officerNpc.setAttack(officerNpc.getAttack() * 0.8f);
        officerNpc.setDefence(officerNpc.getDefence() * 0.8f);
        officerNpc.setHp(Math.round(officerNpc.getHp() * 1.2f));
        officerNpc.findAndFillCaptainship();
        return officerNpc;
    }

    public void setArenaRepo(ArenaRepo arenaRepo) {
        this.arenaRepo = arenaRepo;
    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }

}
