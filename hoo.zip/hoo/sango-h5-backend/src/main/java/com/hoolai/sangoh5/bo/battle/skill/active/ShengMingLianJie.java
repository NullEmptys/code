package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ShengMingLianJieBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.SameBoatUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 随机链接对方离我方将领最近的5个单位，当某个单位收到伤害时，其他单位也会受到10%的伤害
 * 
 * @author Administrator
 *
 */
public class ShengMingLianJie extends IndependentSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit mainTarget : aliveMap) {
            Buff buff = mainTarget.findBuff(xmlId);
            if (buff == null) {
                if (logger.isDebugEnabled()) {
                    logger.debug(mainTarget.name() + "被生命链接");
                }
                for (FightUnit target : aliveMap) {
                    if (mainTarget.name().equals(target.name())) {
                        continue;
                    }
                    mainTarget.addSameBoatUnit(new SameBoatUnit(actor, target, xmlId, name, currentLevel, percentage, Math.round(value)));
                }
                mainTarget.addBuff(new ShengMingLianJieBuff(xmlId, name, mainTarget.name(), currentLevel).withActorName(actor.name()).withTargetName(mainTarget.name())
                        .withKeepBuff().withRepeatCount(repeatCount));
                targets.add(mainTarget);
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug(mainTarget.name() + "被生命链接重置");
                }
                buff.setRepeatCount(repeatCount);
            }
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]使" + mainTarget.name() + "中生命链接，持续回合数=" + repeatCount);
        }

        Map<FightUnitName, FightUnit> actorAliveMap = tc.aliveTargetUnit(!actor.isAttacker());
        Set<FightUnitName> keySet = actorAliveMap.keySet();
        for (FightUnitName name : keySet) {
            FightUnit fightUnit = actorAliveMap.get(name);
            fightUnit.canAttackAllTargets();
        }

        return targets;
    }

    @Override
    public Skill clone() {
        return super.clone(new ShengMingLianJie());
    }

}
