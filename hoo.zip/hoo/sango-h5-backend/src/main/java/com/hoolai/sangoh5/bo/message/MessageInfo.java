package com.hoolai.sangoh5.bo.message;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.GeneratedMessage;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.AwardProto;
import com.hoolai.sangoh5.bo.MessageInfoProtocolBuffer.MessageInfoProto;
import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.repo.MessageInfosRepo;

public class MessageInfo implements ProtobufSerializable, Comparable<MessageInfo> {

    protected long id;

    protected List<Award> awards = new ArrayList<Award>();

    protected long createTime;

    protected boolean isRead;

    protected int type;

    protected String context;

    protected transient long userId;

    public enum MessageInfoType {
        Null, //空
        Union, //联盟解散通知
        Rescue, //悬赏
        Friend, //好友
        UnionBox, //联盟宝箱奖励
        SateBox, //州战宝箱奖励
        CampBox, //正营宝箱奖励
        unionEmblem, //联盟徽章奖励
        Focuson, //关注公众号
        RankFight,//排位殿奖励
    }

    //	public MessageInfo(int id, long createTime, boolean isRead, List<Award> awards,
    //			int type, long userId) {
    //		super();
    //		this.id = id;
    //		this.createTime = createTime;
    //		this.isRead = isRead;
    //		this.type = type;
    //		this.userId = userId;
    //		this.awards = awards;
    //	}

    public MessageInfo() {
    }

    public MessageInfo(long userId, MessageInfosRepo messageInfosRepo, List<Award> awards, MessageInfoType messageInfoTypepe, String message) {
        super();
        this.id = messageInfosRepo.generaterUniqueId(userId);
        this.createTime = TimeUtil.currentTimeMillis();
        this.userId = userId;
        this.isRead = false;
        this.type = messageInfoTypepe.ordinal();
        this.awards = awards == null ? new ArrayList<Award>() : awards;
        this.context = message;
    }

    public MessageInfo(MessageInfoProto mp) {
        copyFrom(mp);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(boolean isRead) {
        this.isRead = isRead;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public List<Award> getAwards() {
        return awards;
    }

    public void setAwards(List<Award> awards) {
        this.awards = awards;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    @Override
    public GeneratedMessage copyTo() {
        MessageInfoProto.Builder builder = MessageInfoProto.newBuilder();
        builder.setId(id);
        builder.setCreateTime(createTime);
        builder.setIsRead(isRead);
        if (awards != null) {
            for (Award aw : awards) {
                builder.addAwards(aw.copyTo());
            }
        }
        builder.setType(type);
        builder.setUserId(userId);
        builder.setContext(context == null ? "" : context);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            copyFrom(MessageInfoProto.parseFrom(bytes));
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void copyFrom(GeneratedMessage arg0) {
        MessageInfoProto message = (MessageInfoProto) arg0;
        this.id = message.getId();
        this.createTime = message.getCreateTime();
        if (message.getAwardsList() != null) {
            for (AwardProto awp : message.getAwardsList()) {
                this.awards.add(new Award(awp));
            }
        }
        this.isRead = message.getIsRead();
        this.type = message.getType();
        this.userId = message.getUserId();
        this.context = message.getContext();
    }

    @Override
    public int compareTo(MessageInfo o) {
        if (this.getCreateTime() > o.getCreateTime()) {
            return -1;
        } else if (this.getCreateTime() < o.getCreateTime()) {
            return 1;
        }
        return 0;
    }

    public void redMesInfo() {
        this.isRead = true;
    }

    //	public static void main(String[] args) {
    //		List<MessageInfo> list = new ArrayList<MessageInfo>();
    //		list.add(new MessageInfo(1, 11L, false, null, 0, 0L));
    //		list.add(new MessageInfo(2, 110202202202L, false, null, 0, 0L));
    //		list.add(new MessageInfo(3, 102222221L, false, null, 0, 0L));
    //		Collections.sort(list);
    //		for (MessageInfo messageInfo : list) {
    //			System.out.println(messageInfo.getId());
    //		}
    //	}

}
