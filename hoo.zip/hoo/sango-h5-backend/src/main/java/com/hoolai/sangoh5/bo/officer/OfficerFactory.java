package com.hoolai.sangoh5.bo.officer;

import java.util.List;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.award.OfficerAward;
import com.hoolai.sangoh5.bo.barrack.Barrack;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillProperty;
import com.hoolai.sangoh5.bo.equip.Equips;
import com.hoolai.sangoh5.bo.farmland.Farmland;
import com.hoolai.sangoh5.bo.mine.Mine;
import com.hoolai.sangoh5.bo.officer.data.OfficerData;
import com.hoolai.sangoh5.bo.officer.data.OfficerLvData;
import com.hoolai.sangoh5.bo.officerunion.OfficerUnions;
import com.hoolai.sangoh5.bo.potion.OfficerEnhancePotion;
import com.hoolai.sangoh5.bo.union.Union;
import com.hoolai.sangoh5.bo.union.UnionUser;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.repo.UserRepo;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-06-15 15:30
 * @version : 1.0
 */
public class OfficerFactory {

    private final long userId;

    private byte[] data;

    private Barrack barrack;

    private Equips allEquips;

    private Mine mine;

    private Farmland farmland;

    private OfficerUnions officerUnions;

    private Union union;

    private UnionUser unionUser;

    private boolean isMainCityDefence;

    private boolean isOfficerUnionOpen;

    private OfficerLvData officerLvData;

    private OfficerData officerData;

    private BoFactory boFactory;

    private OfficerEnhancePotion enhancePotion;

    private UserRepo userRepo;

    public OfficerFactory(long userId) {
        this.userId = userId;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public void setBarrack(Barrack barrack) {
        this.barrack = barrack;
    }

    public void setAllEquips(Equips allEquips) {
        this.allEquips = allEquips;
    }

    public void setMine(Mine mine) {
        this.mine = mine;
    }

    public void setFarmland(Farmland farmland) {
        this.farmland = farmland;
    }

    public void setOfficerUnions(OfficerUnions officerUnions) {
        this.officerUnions = officerUnions;
    }

    public void setUnion(Union union) {
        this.union = union;
    }

    public void setUnionUser(UnionUser unionUser) {
        this.unionUser = unionUser;
    }

    public void setMainCityDefence(boolean isMainCityDefence) {
        this.isMainCityDefence = isMainCityDefence;
    }

    public void setOfficerUnionOpen(boolean isOfficerUnionOpen) {
        this.isOfficerUnionOpen = isOfficerUnionOpen;
    }

    public void setOfficerLvData(OfficerLvData officerLvData) {
        this.officerLvData = officerLvData;
    }

    public void setOfficerData(OfficerData officerData) {
        this.officerData = officerData;
    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }

    public void setEnhancePotion(OfficerEnhancePotion enhancePotion) {
        this.enhancePotion = enhancePotion;
    }

    public void setUserRepo(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public Equips getAllEquips() {
        return allEquips;
    }

    public Officer createOfficer(OfficerAward officerAward) {
        Officer officer = new Officer(userId);
        officer.setBoFactory(boFactory);
        officer.initNewOfficer(officerAward.getXmlId());
        officer.setStarLevel(officerAward.getStarLevel());
        officer.setLevel(officerAward.getLevel());

        int[] equipIds = allEquips.addNewEquip(officer.getEquipList());
        officer.setEquips(equipIds);

        initOfficer(officer, false);
        officer.changeShowFightPower();
        return officer;
    }

    public Officer createOfficer(boolean searchCityUser) {
        Officer officer = new Officer(userId, data);
        officer.setBoFactory(boFactory);
        initOfficer(officer, searchCityUser);
        return officer;
    }

    private void initOfficer(Officer officer, boolean searchCityUser) {
        officer.setOfficerProperty(officerData.getProperty(officer.getXmlId()));
        officer.setOfficerLvData(officerLvData);
        // 先处理所有能加成的信息
        officer.fillEquip(allEquips);
        officer.fillSkillEnhance();
        officer.fillLandMineEnhance(mine, farmland);
        officer.fillFormations();
        if (officer.whetherHaveOfficerUnion() && isOfficerUnionOpen) {
            officer.fillOfficerUnions(officerUnions);
        }
        if (isMainCityDefence) {
            officer.fillOfficerDefenceEnhance();
        }
        officer.fillUnionEnhance(union, unionUser);

        List<SkillProperty> potionProperties = enhancePotion.findOfficerPotion();
        officer.fillPotion(potionProperties);

        officer.fillAllOfficerEnhance();
        officer.fillSoldier(barrack);

        if (searchCityUser) {
            officer.setCityUser(findCityUser(officer.getCityUserId()));
        }
    }

    private User findCityUser(long cityUserId) {
        if (cityUserId == 0) {
            return null;
        }
        if (cityUserId > 0) {
            return userRepo.findUser(cityUserId);
        }
        User cityUser = userRepo.findUser(-cityUserId);
        cityUser.clone();
        cityUser.setId(cityUserId);
        return cityUser;
    }
}
