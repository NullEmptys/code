//package com.hoolai.sangoh5.bo.battle.skill.active;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import com.hoolai.sangoh5.bo.battle.enhance.buff.MoreHurtEnhanceBuff;
//import com.hoolai.sangoh5.bo.battle.enhance.buff.ReduceTargetEnhanceBuff;
//import com.hoolai.sangoh5.bo.battle.enhance.buff.TargetEnhanceBuff;
//import com.hoolai.sangoh5.bo.battle.enhance.effect.MoreHurtEnhanceEffect;
//import com.hoolai.sangoh5.bo.battle.skill.Skill;
//import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
//import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
// //每次攻击降低单位1点护甲，持续10秒
//public class Skill33 extends IndependentSkill {
//
//	@Override
//	public Skill clone() {
//		return super.clone(new Skill33());
//	}
//
//	@Override
//	public List<FightUnit> execute(FightUnit actor, TargetCollection tc,int currentLevel) {
//		List<FightUnit> targets = new ArrayList<FightUnit>();
//		
//		actor.addBuff(new ReduceTargetEnhanceBuff(xmlId,actor,currentLevel).withActorName(actor.name())
//				.withTargetName(actor.name()).withRepeatCount(repeatCount).withKeepBuff());
//	    targets.add(actor);
//		
//		return targets;
//	}
//
//}
