package com.hoolai.sangoh5.bo.user.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class NoviceRewardProperty extends JsonProperty {

    public static final int drop = 1;

    public static final int notDrop = 2;

    private int whetherDrop;

    private int corresponding;

    private String[] rewardType;

    private int[] rewardId;

    private int[] rewardNum;

    public int getWhetherDrop() {
        return whetherDrop;
    }

    public void setWhetherDrop(int whetherDrop) {
        this.whetherDrop = whetherDrop;
    }

    public int getCorresponding() {
        return corresponding;
    }

    public void setCorresponding(int corresponding) {
        this.corresponding = corresponding;
    }

    public String[] getRewardType() {
        return rewardType;
    }

    public void setRewardType(String[] rewardType) {
        this.rewardType = rewardType;
    }

    public int[] getRewardId() {
        return rewardId;
    }

    public void setRewardId(int[] rewardId) {
        this.rewardId = rewardId;
    }

    public int[] getRewardNum() {
        return rewardNum;
    }

    public void setRewardNum(int[] rewardNum) {
        this.rewardNum = rewardNum;
    }

}
