package com.hoolai.sangoh5.bo.battle.fight;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.battle.BattleObjFoctory;
import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.unit.Army;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName.FightType;
import com.hoolai.sangoh5.bo.battle.unit.OfficerUnit;
import com.hoolai.sangoh5.bo.battle.unit.SoldierUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.soldier.FightSoldier;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.user.User;

public class Battle {

    private static final Log logger = LogFactory.getLog("battle");

    public static final int OFFICER_DEFENCE_ENHANCE_SKILL = 25021;

    private final User attackUser;

    private final User defenseUser;

    private final Officer attackOfficer;

    private final Officer defenseOfficer;

    private final BattleEnhance attackBattleEnhance;

    private final BattleEnhance defenseBattleEnhance;

    private TargetCollection targetCollection;

    private Match match;

    private ActorSequence actorSequence;

    private BattleType battleType = BattleType.NORMAL;

    private List<RoundResult> roundResultList = new ArrayList<RoundResult>();

    private final EnumMap<FightUnitName, FightUnit> fightUnitMap = new EnumMap<FightUnitName, FightUnit>(FightUnitName.class);

    /////////////////////////////////////
    private BoFactory boFactory;

    private BattleObjFoctory battleObjFoctory;

    private BattleLog battleLog = new BattleLog();

    public Battle(BattleType battleType, User attackUser, User defenseUser, Officer attackOfficer, Officer defenseOffcier, BattleEnhance attackBattleEnhance,
            BattleEnhance defenseBattleEnhance) {
        this.attackOfficer = attackOfficer;
        this.defenseOfficer = defenseOffcier;
        this.attackUser = attackUser;
        this.defenseUser = defenseUser;
        this.battleType = battleType;
        this.attackBattleEnhance = attackBattleEnhance;
        this.defenseBattleEnhance = defenseBattleEnhance;
    }

    public void init() {
        targetCollection = new TargetCollection(fightUnitMap);
        actorSequence = new SangoActorSequence(attackOfficer.getCurrFormation(), defenseOfficer.getCurrFormation());

        OfficerUnit attOfficerUnit = initOfficer(FightType.attack, attackOfficer, attackBattleEnhance);
        OfficerUnit defOfficerUnit = initOfficer(FightType.defense, defenseOfficer, defenseBattleEnhance);

        initSoldierUnits(FightType.attack, attackOfficer, attOfficerUnit.getArmy(), attackBattleEnhance);
        initSoldierUnits(FightType.defense, defenseOfficer, defOfficerUnit.getArmy(), defenseBattleEnhance);

        applyBeforeBattleSkillEffects();
        processStealSkillEffects();

        match = boFactory.createMatch(actorSequence, targetCollection, fightUnitMap, attackOfficer.getCurrFormation(), defenseOfficer.getCurrFormation());
    }

    private void processStealSkillEffects() {
        for (FightUnitName name : fightUnitMap.keySet()) {
            fightUnitMap.get(name).processStealSkillEffects(targetCollection);
        }
    }

    private List<SoldierUnit> initSoldierUnits(FightType type, Officer officer, Army army, BattleEnhance battleEnhance) {
        if (army.getFightSoldiers() == null || army.getFightSoldiers().isEmpty()) {
            return null;
        }
        List<SoldierUnit> soldierUnits = new ArrayList<SoldierUnit>(SoldierType.values().length);
        for (FightSoldier fightSoldier : army.getFightSoldiers()) {
            soldierUnits.add(initSoldierUnit(type, officer, fightSoldier, army, battleEnhance));
        }
        return soldierUnits;
    }

    private SoldierUnit initSoldierUnit(FightType type, Officer officer, FightSoldier fightSoldier, Army army, BattleEnhance battleEnhance) {
        if (fightSoldier.getOriginalNum() > 0) {
            SoldierUnit soldierUnit = battleObjFoctory.newSoldierUnit(type, officer, fightSoldier, army, battleEnhance, battleLog);
            addToCollections(soldierUnit);
            return soldierUnit;
        }
        return null;
    }

    private OfficerUnit initOfficer(FightType fightType, Officer officer, BattleEnhance battleEnhance) {
        Army army = boFactory.createArmy(officer);
        OfficerUnit officerUnit = battleObjFoctory.newOfficerUnit(fightType == FightType.attack, officer, army, battleEnhance, battleLog);
        addToCollections(officerUnit);
        return officerUnit;
    }

    private void addToCollections(FightUnit fightUnit) {
        targetCollection.addUnit(fightUnit);
        fightUnitMap.put(fightUnit.name(), fightUnit);
        actorSequence.put(fightUnit);
    }

    private void applyBeforeBattleSkillEffects() {
        for (FightUnitName name : fightUnitMap.keySet()) {
            fightUnitMap.get(name).applyBeforeBattleSkill(targetCollection);
        }
    }

    public BattleResult fight() {
        if (battleType == BattleType.ONLY_OFFICER_FIGHT) {
            return offierFight();
        }
        return normalFight();
    }

    private BattleResult normalFight() {
        boolean isAttackerPkWin = false;

        if (hasSoldiersFight()) {
            soldierFighting();
        } else {
            match.setIsAttackerBattleWin(isAttackerPkWin);
        }
        return result();
    }

    private void soldierFighting() {
        while (!match.isFinished()) {
            executeSoldierRound();
        }
    }

    private boolean hasSoldiersFight() {
        OfficerUnit atto = (OfficerUnit) fightUnitMap.get(FightUnitName.att_officer);
        OfficerUnit defo = (OfficerUnit) fightUnitMap.get(FightUnitName.def_officer);
        return atto.getArmy().findSoldierNumber() != 0 || defo.getArmy().findSoldierNumber() != 0;
    }

    private BattleResult offierFight() {
        return onlyOfficerFightResult();
    }

    private void executeSoldierRound() {
        //	    	match.currentActorIsAttacker();
        match.nextRound();
        RoundResult roundResult = match.endCurrentRound();
        apply(roundResult);
    }

    private void apply(RoundResult roundResult) {
        if (roundResult != null) {
            roundResultList.add(roundResult);
        }
    }

    private BattleResult onlyOfficerFightResult() {
        // applyAtferBattleSkillEffects();

        OfficerUnit attackOfficerUnit = (OfficerUnit) fightUnitMap.get(FightUnitName.att_officer);
        OfficerUnit defenceOfficerUnit = (OfficerUnit) fightUnitMap.get(FightUnitName.def_officer);

        //Army attackArmy = attackOfficerUnit.getArmy();
        //Army defenceArmy = defenceOfficerUnit.getArmy();
        boolean isAttackerBattleWin = match.isAttackerBattleWin();

        BattleResult battleResult = new BattleResult(attackOfficer, defenseOfficer);

        battleResult.setAttackPerfectUser(attackUser);
        battleResult.setDefencePerfectUser(defenseUser);
        battleResult.setRoundResultList(roundResultList);
        battleResult.setIsAttackerBattleWin(isAttackerBattleWin);
        //battleResult.setAttackArmy(attackArmy);
        // battleResult.setDefenceArmy(defenceArmy);
        //        battleResult.setBackGround(pg.getRandomNumber(1, 5));
        battleResult.setAttackUserLastHp(attackOfficerUnit.getLostHPPercentage());
        battleResult.setDefenceUserLastHp(defenceOfficerUnit.getLostHPPercentage());

        attackOfficer.setIsDead((!isAttackerBattleWin) && attackOfficerUnit.isDead());// 赢了就不死
        defenseOfficer.setIsDead(isAttackerBattleWin && defenceOfficerUnit.isDead());

        attackOfficer.findFormationAndModification(attackOfficer.getCurrFormation().getId());

        //        battleResult.getAttackOfficer().setIsDead(attackOfficer.isDead());
        //        battleResult.getDefenceOfficer().setIsDead(defenseOfficer.isDead());
        //        battleResult.getAttackOfficer().setLostPoint(attackOfficerUnit.totalLostPoint());
        //        battleResult.getDefenceOfficer().setLostPoint(defenceOfficerUnit.totalLostPoint());

        return battleResult;
    }

    private BattleResult result() {

        OfficerUnit attackOfficerUnit = (OfficerUnit) fightUnitMap.get(FightUnitName.att_officer);
        OfficerUnit defenceOfficerUnit = (OfficerUnit) fightUnitMap.get(FightUnitName.def_officer);

        Army attackArmy = attackOfficerUnit.getArmy();
        Army defenceArmy = defenceOfficerUnit.getArmy();
        boolean isAttackerBattleWin = match.isAttackerBattleWin();

        appendPassiveSkillEnhanceRound();

        if (logger.isDebugEnabled()) {
            logger.debug("防守方生存：" + targetCollection.aliveTargetSoldierCount(true) + ",死亡兵数" + defenceArmy.getCurrLostPoint());
            logger.debug("攻击方生存：" + targetCollection.aliveTargetSoldierCount(false) + ",死亡兵数" + attackArmy.getCurrLostPoint());
        }

        BattleResult battleResult = new BattleResult(attackOfficer, defenseOfficer);
        battleResult.setAttackPerfectUser(attackUser);
        battleResult.setDefencePerfectUser(defenseUser);
        battleResult.setRoundResultList(roundResultList);
        battleResult.setIsAttackerBattleWin(isAttackerBattleWin);
        battleResult.setAttackArmy(attackArmy);
        battleResult.setDefenceArmy(defenceArmy);
        //        battleResult.setBackGround(pg.getRandomNumber(1, 5));
        battleResult.setBattleType(battleType);
        battleResult.setAttEnhanceSkills(attackBattleEnhance.getDisplayEnhanceSkillsArr());
        battleResult.setDefEnhanceSkills(defenseBattleEnhance.getDisplayEnhanceSkillsArr());
        battleResult.setAttOtherEnhanceSkills(attackBattleEnhance.getOtherEnhanceSkillsArr());
        battleResult.setDefOtherEnhanceSkills(defenseBattleEnhance.getOtherEnhanceSkillsArr());

        if (battleResult.getAttackUser().getId() > 0) {
            attackOfficer.findFormationAndModification(attackOfficer.getCurrFormation().getId());
        }

        attackOfficer.setLostPoint(attackOfficerUnit.totalLostPoint());
        defenseOfficer.setLostPoint(defenceOfficerUnit.totalLostPoint());

        battleResult.setBattleLog(battleLog);
        //        battleLog.println();

        return battleResult;
    }

    private void appendPassiveSkillEnhanceRound() {
        List<RoundResult> newRoundResultList = new ArrayList<RoundResult>();

        List<ActionResult> actionResults = new ArrayList<ActionResult>();
        for (FightUnitName name : fightUnitMap.keySet()) {
            FightUnit fightUnit = fightUnitMap.get(name);
            List<Buff> buffList = fightUnit.getBeforeBattleBuff();
            if (buffList.size() > 0) {
                ActionResult actionResult = new ActionResult();
                actionResult.setActionType(ActionType.NONE);
                actionResult.setActorName(name);
                actionResult.setBuffList(buffList);
                actionResults.add(actionResult);
            }
        }

        RoundResult roundResult = new RoundResult();
        roundResult.setRoundNum(0);
        roundResult.setActionResultList(actionResults);

        newRoundResultList.add(roundResult);
        newRoundResultList.addAll(roundResultList);
        roundResultList = newRoundResultList;
    }

    //    private void applySoldierLost(Officer officer, Army army) {
    //        officer.fightedSoldierNum(army);
    //    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }

    public void setBattleObjFoctory(BattleObjFoctory battleObjFoctory) {
        this.battleObjFoctory = battleObjFoctory;
    }

}
