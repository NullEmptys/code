package com.hoolai.sangoh5.bo.platform.wanba;

import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.sangoh5.util.Constant;

public class WanbaYellowDiamond{
	
	public static final int ONE_MONTH = 12557;
	public static final int THREE_MONTH = 12558;
	public static final int TWELVE_MONTH = 12559;
	
	public static final int ACT_ID = 610;

	private int count;
	private int prizeid;
	private long time;
	
	public WanbaYellowDiamond(){
		
	}
	
	public WanbaYellowDiamond(int prizeid, long time, int count) {
		this.count = count;
		this.prizeid = prizeid;
		this.time = time;
	}

	public String key(){
		return prizeid+Constant.separator+time;
	}
	
	@JsonIgnore
	public String getTimeStr(){
		return DateUtil.f(TimeUnit.SECONDS.toMillis(time), DateUtil.DATE_FORMAT_SECONDS);
	}
	
	@JsonIgnore
	public String getName(){
		if(prizeid == ONE_MONTH){
			return "一个月黄钻";
		}else if(prizeid == THREE_MONTH){
			return "三个月黄钻";
		}else if(prizeid == TWELVE_MONTH){
			return "年费黄钻";
		}
		return "未识别的prizeid="+prizeid;
	}

	@Override
	public String toString() {
		return "TencentWanbaYellowDiamond [count=" + count + ", prizeid=" + prizeid + ", time=" + time + "]";
	}

	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getPrizeid() {
		return prizeid;
	}
	public void setPrizeid(int prizeid) {
		this.prizeid = prizeid;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}

}
