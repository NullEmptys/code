package com.hoolai.sangoh5.bo.city;

import java.util.concurrent.TimeUnit;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.MainCityProto;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class MainCity implements ProtobufSerializable<MainCityProto> {

    private static final long serialVersionUID = 7314418200316965871L;

    public static final int status_defence = 1;

    public static final int status_occupy = 2;

    public static final int status_deserted = 0;

    private int officerId;

    /** 只有自己驻防的时候才给值 其他情况为-1 */
    private long defendAt;

    private long lordId;

    private int hasGeneratedIncome;

    private long nextIncomeFullTime;

    /** 被占领的开始时间 */
    private long occupyStartTime;

    /** 状态等级分组id **/
    private int rankStateGroupId;

    transient private long ownerUserId;

    transient private User lord;

    transient private Officer officer;

    transient private long incomeFullLeftTime;// 前端用的参数(为避免前后端产生的时间不一致情况)

    transient private long hasDefendedTime;// 前端展示用

    public MainCity(long ownerUserId) {
        this.ownerUserId = ownerUserId;
        this.defendAt = -1;
    }

    public MainCity(long userId, byte[] bytes) {
        this(userId);
        parseFrom(bytes);
    }

    public boolean isOccupy() {
        if (officerId > 0 && lordId > 0 && lordId != ownerUserId) {
            return true;
        }
        return false;
    }

    public boolean isDefence() {
        if (defendAt > 0 && officerId > 0 && lordId > 0 && lordId == ownerUserId) {
            this.hasDefendedTime = TimeUnit.MILLISECONDS.toSeconds(TimeUtil.currentTimeMillis() - defendAt);
            return true;
        }
        return false;
    }

    /**
     * 是否空城
     * 
     * @return 是返回true，反之false
     */
    public boolean isDesertedCity() {
        return !isDefence() && !isOccupy();
    }

    public void fillOfficer(Officer officer) {
        this.officer = officer;
    }

    public void fillLordUser(User user) {
        this.lord = user;
    }

    public void defence(int officerId) {
        this.defendAt = TimeUtil.currentTimeMillis();
        this.lordId = ownerUserId;
        this.officerId = officerId;
        this.occupyStartTime = 0;
    }

    public void occupy(long lordId, int officerId) {
        this.defendAt = -1;
        this.lordId = lordId;
        this.officerId = officerId;
        this.occupyStartTime = TimeUtil.currentTimeMillis();
    }

    public void withdraw() {
        this.defendAt = -1;
        this.lordId = 0;
        this.officerId = 0;
        this.occupyStartTime = 0;
        this.officer = null;
    }

    public void rescue() {
        this.defendAt = -1;
        this.lordId = 0;
        this.officerId = 0;
        this.occupyStartTime = 0;
        this.officer = null;
    }

    public void giveUp() {
        this.defendAt = -1;
        this.lordId = 0;
        this.officerId = 0;
        this.occupyStartTime = 0;
        this.officer = null;
    }

    public int getOfficerId() {
        return officerId;
    }

    public void setOfficerId(int officerId) {
        this.officerId = officerId;
    }

    public long getLordId() {
        return lordId;
    }

    public void setLordId(long lordId) {
        this.lordId = lordId;
    }

    public long getOccupyStartTime() {
        return occupyStartTime;
    }

    public void setOccupyStartTime(long occupyStartTime) {
        this.occupyStartTime = occupyStartTime;
    }

    public long getOwnerUserId() {
        return ownerUserId;
    }

    public void setOwnerUserId(long ownerUserId) {
        this.ownerUserId = ownerUserId;
    }

    public User getLord() {
        return lord;
    }

    public void setLord(User lord) {
        this.lord = lord;
    }

    public Officer getOfficer() {
        return officer;
    }

    public void setOfficer(Officer officer) {
        this.officer = officer;
    }

    public long getHasDefendedTime() {
        return hasDefendedTime;
    }

    public void setHasDefendedTime(long hasDefendedTime) {
        this.hasDefendedTime = hasDefendedTime;
    }

    public int getRankStateGroupId() {
        return rankStateGroupId;
    }

    public void setRankStateGroupId(int rankStateGroupId) {
        this.rankStateGroupId = rankStateGroupId;
    }

    @Override
    public MainCityProto copyTo() {
        MainCityProto.Builder builder = MainCityProto.newBuilder();
        builder.setDefendAt(defendAt);
        builder.setHasGeneratedIncome(hasGeneratedIncome);
        builder.setLordId(lordId);
        builder.setNextIncomeFullTime(nextIncomeFullTime);
        builder.setOccupyStartTime(occupyStartTime);
        builder.setOfficerId(officerId);
        builder.setRankStateGroupId(rankStateGroupId);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            MainCityProto message = MainCityProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(MainCityProto message) {
        this.defendAt = message.getDefendAt();
        this.hasGeneratedIncome = message.getHasGeneratedIncome();
        this.lordId = message.getLordId();
        this.nextIncomeFullTime = message.getNextIncomeFullTime();
        this.occupyStartTime = message.getOccupyStartTime();
        this.officerId = message.getOfficerId();
        this.rankStateGroupId = message.getRankStateGroupId();
    }

    public int getMainCityStatus() {
        if (isDefence()) {
            return status_defence;
        } else if (isOccupy()) {
            return status_occupy;
        } else {
            return status_deserted;
        }
    }
}
