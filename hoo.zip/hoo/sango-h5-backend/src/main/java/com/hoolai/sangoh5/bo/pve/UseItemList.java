package com.hoolai.sangoh5.bo.pve;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.UseItemProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class UseItemList implements ProtobufSerializable<UseItemProto> {

    private List<UseItemAddProvision> addProvisionItemList = new ArrayList<UseItemAddProvision>();

    public UseItemList(byte[] bytes) {
        parseFrom(bytes);
    }

    public UseItemList() {
    }

    @Override
    public UseItemProto copyTo() {
        UseItemProto.Builder builder = UseItemProto.newBuilder();
        if (addProvisionItemList.size() > 0) {
            for (UseItemAddProvision addProvision : addProvisionItemList) {
                builder.addUserItem(addProvision.copyTo());
            }
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            UseItemProto message = UseItemProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }

    }

    @Override
    public void copyFrom(UseItemProto message) {
        int count = message.getUserItemCount();
        for (int i = 0; i < count; i++) {
            UseItemAddProvision addProvision = new UseItemAddProvision(message.getUserItem(i));
            addProvisionItemList.add(addProvision);
        }

    }

    public List<UseItemAddProvision> getAddProvisionItemList() {
        return addProvisionItemList;
    }

    public void setAddProvisionItemList(List<UseItemAddProvision> addProvisionItemList) {
        this.addProvisionItemList = addProvisionItemList;
    }

}
