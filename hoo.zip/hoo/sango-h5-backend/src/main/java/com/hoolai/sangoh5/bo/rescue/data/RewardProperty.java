package com.hoolai.sangoh5.bo.rescue.data;

import java.util.List;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class RewardProperty extends JsonProperty {
	private String dayTime;
	private String itemType;
	private List<Integer> itemIds;
	private List<Integer> itemNums;

	public String getDayTime() {
		return dayTime;
	}

	public void setDayTime(String dayTime) {
		this.dayTime = dayTime;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public List<Integer> getItemIds() {
		return itemIds;
	}

	public void setItemIds(List<Integer> itemIds) {
		this.itemIds = itemIds;
	}

	public List<Integer> getItemNums() {
		return itemNums;
	}

	public void setItemNums(List<Integer> itemNums) {
		this.itemNums = itemNums;
	}

}
