package com.hoolai.sangoh5.bo.user;

import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Sets;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.AnnounceProto;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Announce implements ProtobufSerializable<AnnounceProto> {

    public static final int ANNOUNCE_INIT_VERSION = 1;

    private int version;// 公告版本

    private String message;// 公告内容

    private String whiteList;// 白名单

    private int appVersion; // 可用来控制前端版本，统一管理前端文件版本号

    private boolean isPublicOpen = true;// 是否对外开放，false表示正在维护或者内测中，只有白名单能够进入

    public Announce(byte[] bytes) {
        parseFrom(bytes);
    }

    public Announce() {
        version = ANNOUNCE_INIT_VERSION;
        message = "";
        whiteList = "";
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            copyFrom(AnnounceProto.parseFrom(bytes));
        } catch (InvalidProtocolBufferException ex) {
            throw new IllegalArgumentException(ex);
        }
    }

    @Override
    public void copyFrom(AnnounceProto proto) {
        version = proto.getVersion();
        message = proto.getMessage();
        whiteList = proto.getWhiteList();
        if (proto.hasAppVersion()) {
            appVersion = proto.getAppVersion();
        }
        this.isPublicOpen = proto.getIsPublicOpen();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public AnnounceProto copyTo() {
        AnnounceProto.Builder builder = AnnounceProto.newBuilder();
        builder.setVersion(version);
        builder.setMessage(message);
        builder.setWhiteList(whiteList);
        builder.setAppVersion(appVersion);
        builder.setIsPublicOpen(isPublicOpen);
        return builder.build();
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getWhiteList() {
        return whiteList;
    }

    public void setWhiteList(String whiteList) {
        this.whiteList = whiteList;
    }

    public boolean isWhiteList(String platformId) {
        Set<String> list = Sets.newHashSet(StringUtils.split(whiteList, ","));
        return list.contains(platformId);
    }

    public int getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(int appVersion) {
        this.appVersion = appVersion;
    }

    public boolean isPublicOpen() {
        return isPublicOpen;
    }

    public void setPublicOpen(boolean isPublicOpen) {
        this.isPublicOpen = isPublicOpen;
    }

    public boolean forbidPublicOpen(String platformId) {
        if (isPublicOpen) {
            return false;
        }
        return !isWhiteList(platformId);
    }

    public void verifyPublicOpen(String platformId) {
        if (forbidPublicOpen(platformId)) {
            throw new com.hoolai.exception.BusinessException(ErrorCode.LOGIN_IS_EXPIRED.code, ErrorCode.LOGIN_IS_EXPIRED.msg);
        }
    }

}
