package com.hoolai.sangoh5.bo.arena;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.compass.core.util.CollectionUtils;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.bo.award.AwardChannel;
import com.hoolai.sangoh5.bo.award.AwardProcessor;
import com.hoolai.sangoh5.bo.barrack.Barrack;
import com.hoolai.sangoh5.bo.battle.BattleObjFoctory;
import com.hoolai.sangoh5.bo.battle.fight.Battle;
import com.hoolai.sangoh5.bo.battle.fight.BattleResult;
import com.hoolai.sangoh5.bo.battle.fight.BattleType;
import com.hoolai.sangoh5.bo.item.Item;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.pve.data.MonsterData;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.repo.ArenaRepo;
import com.hoolai.sangoh5.repo.BarrackRepo;
import com.hoolai.sangoh5.repo.OfficerRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.util.ProbabilityGenerator;

public class ArenaFightAction {

    private static final Log logger = LogFactory.getLog(ArenaFightAction.class);

    private final ArenaUser attackArenaUser;

    private final ArenaUser defenceArenaUser;

    private ArenaRepo arenaRepo;

    private MonsterData monsterData;

    private OfficerRepo officerRepo;

    private BarrackRepo barrackRepo;

    private UserRepo userRepo;

    private BattleObjFoctory battleObjFoctory;

    private ProbabilityGenerator probabilityGenerator;

    private BoFactory boFactory;

    private final ScoreProcessor scoreProcessor;

    private Officer attackOfficer;

    private Officer defenceOfficer;

    private BattleResult battleResult;

    private List<Award> awards;

    public ArenaFightAction(ArenaUser arenaUser, ArenaUser defenceArenaUser) {
        this.attackArenaUser = arenaUser;
        this.defenceArenaUser = defenceArenaUser;
        this.scoreProcessor = new ScoreProcessor(arenaUser, defenceArenaUser);
    }

    public void setMonsterData(MonsterData monsterData) {
        this.monsterData = monsterData;
    }

    public void setOfficerRepo(OfficerRepo officerRepo) {
        this.officerRepo = officerRepo;
    }

    public void setBarrackRepo(BarrackRepo barrackRepo) {
        this.barrackRepo = barrackRepo;
    }

    public void setArenaRepo(ArenaRepo arenaRepo) {
        this.arenaRepo = arenaRepo;
    }

    public void setUserRepo(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public void setBattleObjFoctory(BattleObjFoctory battleObjFoctory) {
        this.battleObjFoctory = battleObjFoctory;
    }

    public void setProbabilityGenerator(ProbabilityGenerator probabilityGenerator) {
        this.probabilityGenerator = probabilityGenerator;
    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }

    public Officer getAttackOfficer() {
        return attackOfficer;
    }

    public Officer getDefenceOfficer() {
        return defenceOfficer;
    }

    private void initFight() {
        attackOfficer = createAttackOfficer(attackArenaUser);
        defenceOfficer = createDefenceOffcer(defenceArenaUser);

        scoreProcessor.setArenaRepo(arenaRepo);
        scoreProcessor.init(attackOfficer, defenceOfficer);
    }

    public void fight() {
        this.initFight();
        this.battle();
        this.afterFight();
    }

    private void battle() {
        User attackUser = userRepo.findUser(attackArenaUser.getUserId());
        User defenceUser = null;
        if (defenceArenaUser.getUserId() > 0) {
            defenceUser = userRepo.findUser(defenceArenaUser.getUserId());
        } else {
            defenceUser = new User(defenceArenaUser.getUserId());
        }
        Battle battle = battleObjFoctory.createBattle(BattleType.NORMAL, attackUser, defenceUser, attackOfficer, defenceOfficer);
        this.battleResult = battle.fight();
    }

    private void afterFight() {
        scoreProcessor.cal(battleResult.isAttackerBattleWin());
        scoreProcessor.save();

        attackArenaUser.addHonorPoint(getHonorPoint());
        attackArenaUser.addNum(battleResult.isAttackerBattleWin());

        arenaRepo.saveArenaUser(attackArenaUser);
        arenaRepo.addUserScoreToRedis(attackArenaUser.getCurrentScore(), attackArenaUser.getUserId());

        if (defenceArenaUser.getUserId() > 0) {
            arenaRepo.addUserScoreToRedis(defenceArenaUser.getCurrentScore(), defenceArenaUser.getUserId());
        }

        this.awards = getAwardsAfterFight();
    }

    public Map<String, Object> drawRewards() {
        if (CollectionUtils.isEmpty(awards)) {
            return Collections.emptyMap();
        }
        AwardProcessor awardProcessor = boFactory.createAwardProcessor(attackArenaUser.getUserId(), AwardChannel.AreanFight);
        awardProcessor.transforAward(awards);
        awardProcessor.awardPesistent();

        return awardProcessor.awardResult();
    }

    private List<Award> getAwardsAfterFight() {
        if (!battleResult.isAttackerBattleWin()) {
            return Collections.emptyList();
        }
        boolean isDrop = probabilityGenerator.getRandomWithPercentage(20f);
        if (!isDrop) {
            return Collections.emptyList();
        }
        List<Award> awards = new ArrayList<Award>();
        awards.add(new Award(Item.ITEM_QING_TONG_YAO_SHI, 1, AwardType.ITEM));

        return awards;
    }

    public int getHonorPoint() {
        return battleResult.isAttackerBattleWin() ? 200 : 50;
    }

    public List<Award> getAwards() {
        return awards;
    }

    public BattleResult getBattleResult() {
        return battleResult;
    }

    private Officer createAttackOfficer(ArenaUser arenaUser) {
        Officer attackOfficer = findAndRepairOfficer(arenaUser).cloneOfficer();

        Barrack barrack = barrackRepo.findBarrack(attackOfficer.getUserId());
        attackOfficer.troops(barrack);
        return attackOfficer;
    }

    private Officer findAndRepairOfficer(ArenaUser arenaUser) {
        Officer defenceOfficer = null;
        try {
            return officerRepo.findOfficer(arenaUser.getUserId(), arenaUser.getCurrentOfficerId()).cloneOfficer();
        } catch (Exception e) {
            logger.debug(arenaUser.getUserId() + "提取竞技场将领失败，将领ID：" + arenaUser.getCurrentOfficerId());
        }
        List<Officer> officerList = officerRepo.findOfficerList(arenaUser.getUserId());
        int fightValue = 0;
        for (Officer officerTemp : officerList) {
            if (officerTemp.getFightPower() > fightValue) {
                fightValue = officerTemp.getFightPower();
                defenceOfficer = officerTemp;
            }
        }
        //        arenaUser.setCurrentOfficerId(defenceOfficer.getId());
        //        arenaRepo.saveArenaUser(arenaUser);
        return defenceOfficer;
    }

    private Officer createDefenceOffcer(ArenaUser defenceArenaUser) {
        if (defenceArenaUser.getUserId() < 0) {
            return monsterData.createArenaMonster();
        }
        Officer defenceOfficerClone = findAndRepairOfficer(defenceArenaUser).cloneOfficer();
        Barrack barrack = barrackRepo.findBarrack(defenceOfficerClone.getUserId());
        defenceOfficerClone.troops(barrack);

        return defenceOfficerClone;
    }
}
