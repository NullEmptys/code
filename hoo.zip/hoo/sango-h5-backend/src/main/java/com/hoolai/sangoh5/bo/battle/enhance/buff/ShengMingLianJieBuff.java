package com.hoolai.sangoh5.bo.battle.enhance.buff;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class ShengMingLianJieBuff extends Buff {

    public ShengMingLianJieBuff(int targetUsedSkillXmlId, String skillName, FightUnitName executeName, int currentLevel) {
        super(targetUsedSkillXmlId, skillName, executeName, currentLevel);
    }

    @Override
    public void apply(FightUnit target) {
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        alive.clearSameBoatUnit(targetUsedSkillXmlId);
        alive.addBattleLog(targetUsedSkillXmlId + "[" + skillName + "]" + alive.name() + "生命链接效果结束");
    }

    @Override
    protected ShengMingLianJieBuff clone() {
        ShengMingLianJieBuff buff = (ShengMingLianJieBuff) super.clone(new ShengMingLianJieBuff(this.targetUsedSkillXmlId, skillName, executeName, currentLevel));
        return buff;
    }

}
