package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.buff.RangeSustainedBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 向一个敌方目标遭雷击。雷电在4秒内打击目标3次。如果其他敌人过于接近该目标，也同样会遭雷击。
 * @author Administrator
 *
 */
public class Skill12 extends IndependentSkill{

	@Override
	public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
		List<FightUnit> targets = new ArrayList<FightUnit>();
		
		FightUnit target = actor.getDefender();
		if(target != null){
			target.addBuff(new RangeSustainedBuff(actor, target.name(), this, currentLevel,Math.round(value))
			.withBuffInterval(this.repeatCount % 3)
			.withActorName(actor.name()).withTargetName(target.name()));
			targets.add(target);
		}
		
		// 挨着很近的地方单位
		List<FightUnit> aliveMap = aliveTargetUnitList(tc,actor);
		for (FightUnit other : aliveMap) {
			if(target != null && target.name().equals(other.name())){
				continue;
			}
			other.addBuff(new RangeSustainedBuff(actor, target.name(), this, currentLevel,Math.round(value))
			.withBuffInterval(this.repeatCount % 3)
			.withActorName(actor.name()).withTargetName(target.name()));
			targets.add(other);
		}
		
		return targets;
	}

	@Override
	public Skill clone() {
		return super.clone(new Skill12());
	}

}
