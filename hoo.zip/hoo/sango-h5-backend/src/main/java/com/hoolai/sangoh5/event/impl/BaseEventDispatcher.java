package com.hoolai.sangoh5.event.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.google.common.base.Supplier;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimaps;
import com.hoolai.sangoh5.event.Event;
import com.hoolai.sangoh5.event.EventDispatcher;
import com.hoolai.sangoh5.event.EventSubscriber;
import com.hoolai.sangoh5.event.EventType;
import com.hoolai.sangoh5.event.annotation.Subscriber;

/**
 * TODO 支持异步分发
 * <p>
 * 事件 发布/订阅 模式的三种实现
 * <ul>
 * <li>传统实现，一个事件一个接口</li>
 * <li>公共订阅接口</li>
 * <li>类似guava's eventbus的处理方式</li>
 * </ul>
 * </p>
 * 
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 17:32
 * @version : 1.0
 */
@Component("eventDispatcher")
public class BaseEventDispatcher implements EventDispatcher {

    private static final Log logger = LogFactory.getLog(BaseEventDispatcher.class);

    private final ListMultimap<EventType, EventSubscriber<?>> subscribersByType = Multimaps.newListMultimap(Maps.<EventType, Collection<EventSubscriber<?>>> newHashMap(),
            new Supplier<List<EventSubscriber<?>>>() {

                @Override
                public List<EventSubscriber<?>> get() {
                    return Lists.newArrayList();
                }
            });

    @Override
    public void subscribe(EventType eventType, EventSubscriber<?> eventSubscriber) {
        //TODO sort subscribers
        subscribersByType.put(eventType, eventSubscriber);

        List<EventSubscriber<?>> list = subscribersByType.get(eventType);

        Collections.sort(list, new Comparator<EventSubscriber<?>>() {

            @Override
            public int compare(EventSubscriber<?> o1, EventSubscriber<?> o2) {
                if (o1 == null || o2 == null) {
                    return 0;
                }
                Subscriber s1 = o1.getClass().getAnnotation(Subscriber.class);
                Subscriber s2 = o2.getClass().getAnnotation(Subscriber.class);
                return Integer.compare(s1.priority(), s2.priority());
            }
        });
    }

    @Override
    public void dispatch(Event event) {
        publish(event);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public void publish(Event event) {
        if (logger.isDebugEnabled()) {
            logger.debug("publish event: " + event);
        }

        List<EventSubscriber<?>> subscribers = getSubscribersForEventType(event.getType());

        for (int i = 0; i < subscribers.size(); i++) {
            EventSubscriber subscriber = subscribers.get(i);
            dispatch(event, subscriber);
        }
    }

    protected <T extends Event> void dispatch(T event, EventSubscriber<T> subscriber) {
        try {
            subscriber.onEvent(event);
        } catch (Exception e) {
            logger.error(String.format("dispatch event error, %s.onEvent: %s", subscriber.getClass().getName(), event), e);
        }
    }

    private List<EventSubscriber<?>> getSubscribersForEventType(EventType eventType) {
        return subscribersByType.get(eventType);
    }

}
