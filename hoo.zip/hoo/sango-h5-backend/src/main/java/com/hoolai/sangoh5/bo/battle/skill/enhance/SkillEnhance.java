package com.hoolai.sangoh5.bo.battle.skill.enhance;

import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillData;

public class SkillEnhance {

    /** 攻击属性加成 */
    private float attackEnhanceRate;

    /** 防御属性加成 */
    private float defenceEnhanceRate;

    /** HP属性的加成 */
    private float hpEnhanceRate;

    /** 装备防御的加成 */
    private float equipDefenceEnhanceRate;

    /** 装备攻击的加成 */
    private float equipAttackEnhanceRate;

    /** 装备HP的加成 */
    private float equipHpEnhanceRate;

    /** 武将带兵上限的加成 */
    private float captainShipEnhanceRate;
    
    /** 武将带兵上限的固定值加成 */
    private float captainShipEnhanceValue;

    /** 武将训练时间加成 */
    private float traingTimeEnhanceRate;

    /** 体力回愎速度加成 */
    private float recoverEnergyEnhanceRate;

    /** 步兵攻击属性加成 */
    private float footmanAttackEnhanceRate;

    /** 步兵防御属性加成 */
    private float footmanDefenceEnhanceRate;
    
    /** 弓箭兵攻击属性加成 */
    private float archerAttackEnhanceRate;
    
    /** 弓箭兵防御属性加成 */
    private float archerDefenceEnhanceRate;
    
    /** 骑兵攻击属性加成 */
    private float riderAttackEnhanceRate;
    
    /** 骑兵防御属性加成 */
    private float riderDefenceEnhanceRate;
    
    /** 特种兵攻击属性加成 */
    private float specialAttackEnhanceRate;
    
    /** 特种兵防御属性加成 */
    private float specialDefenceEnhanceRate;
    
    private SkillData skillData;
    
    /**
     * 需要展示的skillEnhance 攻,防,装备攻防,HP,带兵上限,训练时间,加上星级特效的加成，阵法给装备的加成
     * 
     * @param skillXmlIds
     */
    public void fillBaseAndStarSkillEnhance(Integer[] skillXmlIds, Integer[] starSkillXmlIds,
            Integer[] expirationSkillXmlIds,Integer[] unionWarEnhanceSkills,Integer[] chariotEnhanceSkills, 
            Integer[] offLineUnionBattleEnhanceSkills,Integer[] titleSkillXmlIds, Integer[] soldierMatrixSkills) {
        fillBaseSkillEnhance(skillXmlIds);
    }

	/**
     * 需要展示的skillEnhance 攻,防,装备攻防,HP,带兵上限,训练时间
     * 
     * @param skillXmlIds
     */
    public void fillBaseSkillEnhance(Integer[] skillXmlIds) {
        if (skillXmlIds == null) {
            return;
        }

        for (Integer skillXmlId : skillXmlIds) {
        	fillSkillEnhance(skillXmlId);
        }
    }
    
	/**
     * 清除skillEnhance 攻,防,装备攻防,HP,带兵上限,训练时间
     * 
     * @param skillXmlIds
     */
    public void clearBaseSkillEnhance(int[] skillXmlIds) {
        if (skillXmlIds == null) {
            return;
        }

        for (int skillXmlId : skillXmlIds) {
        	clearSkillEnhance(skillXmlId);
        }
    }
    
    
    public void fillBaseSkillEnhance(int[] skillXmlIds) {
        if (skillXmlIds == null) {
            return;
        }

        for (int skillXmlId : skillXmlIds) {
        	fillSkillEnhance(skillXmlId);
        }
    }

    public void clearSkillEnhance(int skillXmlId) {
        Skill skill = skillData.findSkill(skillXmlId);
        if (skill == null) {
            return;
        }
        switch (skill.getSkillId()) {
        case 1:
            this.attackEnhanceRate = Math.max(0, this.attackEnhanceRate - skill.getPercentage());
            break;
        case 2:
        	 this.defenceEnhanceRate = Math.max(0, this.defenceEnhanceRate - skill.getPercentage());
            break;
        case 3:
        	this.hpEnhanceRate = Math.max(0, this.hpEnhanceRate - skill.getPercentage());
            break;
        case 13:
            this.equipAttackEnhanceRate = Math.max(0, this.equipAttackEnhanceRate - skill.getPercentage());
            break;
        case 14:
            this.equipDefenceEnhanceRate = Math.max(0, this.equipDefenceEnhanceRate - skill.getPercentage());
            break;
        case 15:
            this.traingTimeEnhanceRate = Math.max(0, this.traingTimeEnhanceRate - skill.getPercentage());
            break;
        case 29:
        case 612:
        	 this.captainShipEnhanceRate = Math.max(0, this.captainShipEnhanceRate - skill.getPercentage());
             break;
        case 30:
            this.recoverEnergyEnhanceRate = Math.max(0, this.recoverEnergyEnhanceRate - skill.getPercentage());
            break;
        case 41:
            this.equipHpEnhanceRate = Math.max(0, this.equipHpEnhanceRate - skill.getPercentage());
            break;
        case 17:
            this.archerAttackEnhanceRate = Math.max(0, this.archerAttackEnhanceRate - skill.getPercentage());
            break;
        case 18:
            this.archerDefenceEnhanceRate = Math.max(0, this.archerDefenceEnhanceRate - skill.getPercentage());
            break;
        case 19:
            this.footmanAttackEnhanceRate = Math.max(0, this.footmanAttackEnhanceRate - skill.getPercentage());
            break;
        case 20:
            this.footmanDefenceEnhanceRate = Math.max(0, this.footmanDefenceEnhanceRate - skill.getPercentage());
            break;
        case 21:
            this.riderAttackEnhanceRate = Math.max(0, this.riderAttackEnhanceRate - skill.getPercentage());
            break;
        case 22:
            this.riderDefenceEnhanceRate = Math.max(0, this.riderDefenceEnhanceRate - skill.getPercentage());
            break;
        case 23:
            this.specialAttackEnhanceRate = Math.max(0, this.specialAttackEnhanceRate - skill.getPercentage());
            break;
        case 24:
            this.specialDefenceEnhanceRate = Math.max(0, this.specialDefenceEnhanceRate - skill.getPercentage());
            break;
        case 75:
            this.attackEnhanceRate = Math.max(0, this.attackEnhanceRate - skill.getPercentage());
            this.defenceEnhanceRate = Math.max(0, this.defenceEnhanceRate - skill.getPercentage());
            this.hpEnhanceRate = Math.max(0, this.hpEnhanceRate - skill.getPercentage());
            break;
        case 76:
            this.attackEnhanceRate = Math.max(0, this.attackEnhanceRate - skill.getPercentage());
            this.defenceEnhanceRate = Math.max(0, this.defenceEnhanceRate - skill.getPercentage());
            break;
        case 101:
        	this.equipAttackEnhanceRate = Math.max(0, this.equipAttackEnhanceRate - skill.getPercentage());
        	this.equipDefenceEnhanceRate = Math.max(0, this.equipDefenceEnhanceRate - skill.getPercentage());
        	this.equipHpEnhanceRate = Math.max(0, this.equipHpEnhanceRate - skill.getPercentage());
        	break;
        case 103:
        	this.equipAttackEnhanceRate = Math.max(0, this.equipAttackEnhanceRate - skill.getPercentage());
        	this.equipDefenceEnhanceRate = Math.max(0, this.equipDefenceEnhanceRate - skill.getPercentage());
        	break;
        case 613:
       	 	this.captainShipEnhanceValue = Math.max(0, this.captainShipEnhanceValue - skill.getPercentage());
       	 	break;
        }
    }
    
    
    public void fillSkillEnhance(int skillXmlId) {
        Skill skill = skillData.findSkill(skillXmlId);
        if (skill == null) {
            return;
        }
        switch (skill.getSkillId()) {
        case 1:
            this.attackEnhanceRate += skill.getPercentage();
            break;
        case 2:
            this.defenceEnhanceRate += skill.getPercentage();
            break;
        case 3:
            this.hpEnhanceRate += skill.getPercentage();
            break;
        case 13:
            this.equipAttackEnhanceRate += skill.getPercentage();
            break;
        case 14:
            this.equipDefenceEnhanceRate += skill.getPercentage();
            break;
        case 15:
            this.traingTimeEnhanceRate += skill.getPercentage();
            break;
        case 29:
        case 612:
        	 this.captainShipEnhanceRate += skill.getPercentage();
             break;
        case 30:
            this.recoverEnergyEnhanceRate += skill.getPercentage();
            break;
        case 41:
            this.equipHpEnhanceRate += skill.getPercentage();
            break;
        case 17:
            this.archerAttackEnhanceRate += skill.getPercentage();
            break;
        case 18:
            this.archerDefenceEnhanceRate += skill.getPercentage();
            break;
        case 19:
            this.footmanAttackEnhanceRate += skill.getPercentage();
            break;
        case 20:
            this.footmanDefenceEnhanceRate += skill.getPercentage();
            break;
        case 21:
            this.riderAttackEnhanceRate += skill.getPercentage();
            break;
        case 22:
            this.riderDefenceEnhanceRate += skill.getPercentage();
            break;
        case 23:
            this.specialAttackEnhanceRate += skill.getPercentage();
            break;
        case 24:
            this.specialDefenceEnhanceRate += skill.getPercentage();
            break;
        case 75:
            this.attackEnhanceRate += skill.getPercentage();
            this.defenceEnhanceRate += skill.getPercentage();
            this.hpEnhanceRate += skill.getPercentage();
            break;
        case 76:
            this.attackEnhanceRate += skill.getPercentage();
            this.defenceEnhanceRate += skill.getPercentage();
            break;
        case 101:
        	this.equipAttackEnhanceRate += skill.getPercentage();
        	this.equipDefenceEnhanceRate += skill.getPercentage();
        	this.equipHpEnhanceRate += skill.getPercentage();
        	break;
        case 103:
        	this.equipAttackEnhanceRate += skill.getPercentage();
        	this.equipDefenceEnhanceRate += skill.getPercentage();
        	break;
        case 613:
       	 	this.captainShipEnhanceValue += skill.getValue();
       	 	break;
        }
    }
    
    public float getAttackEnhanceRate() {
        return attackEnhanceRate;
    }

    public void setAttackEnhanceRate(float attackEnhanceRate) {
        this.attackEnhanceRate = attackEnhanceRate;
    }

    public float getDefenceEnhanceRate() {
        return defenceEnhanceRate;
    }

    public void setDefenceEnhanceRate(float defenceEnhanceRate) {
        this.defenceEnhanceRate = defenceEnhanceRate;
    }

    public float getEquipDefenceEnhanceRate() {
        return equipDefenceEnhanceRate;
    }

    public void setEquipDefenceEnhanceRate(float equipDefenceEnhanceRate) {
        this.equipDefenceEnhanceRate = equipDefenceEnhanceRate;
    }

    public float getEquipAttackEnhanceRate() {
        return equipAttackEnhanceRate;
    }

    public void setEquipAttackEnhanceRate(float equipAttackEnhanceRate) {
        this.equipAttackEnhanceRate = equipAttackEnhanceRate;
    }

    public float getHpEnhanceRate() {
        return hpEnhanceRate;
    }

    public void setHpEnhanceRate(float hpEnhanceRate) {
        this.hpEnhanceRate = hpEnhanceRate;
    }

    public float getCaptainShipEnhanceRate() {
        return captainShipEnhanceRate;
    }

    public void setCaptainShipEnhanceRate(float captainShipEnhanceRate) {
        this.captainShipEnhanceRate = captainShipEnhanceRate;
    }

    public float getTraingTimeEnhanceRate() {
        return traingTimeEnhanceRate;
    }

    public void setTraingTimeEnhanceRate(float traingTimeEnhanceRate) {
        this.traingTimeEnhanceRate = traingTimeEnhanceRate;
    }

    public float getRecoverEnergyEnhanceRate() {
        return recoverEnergyEnhanceRate;
    }

    public void setRecoverEnergyEnhanceRate(float recoverEnergyEnhanceRate) {
        this.recoverEnergyEnhanceRate = recoverEnergyEnhanceRate;
    }

    public float getEquipHpEnhanceRate() {
        return equipHpEnhanceRate;
    }

    public void setEquipHpEnhanceRate(float equipHpEnhanceRate) {
        this.equipHpEnhanceRate = equipHpEnhanceRate;
    }

    public float getFootmanAttackEnhanceRate() {
        return footmanAttackEnhanceRate;
    }

    public float getFootmanDefenceEnhanceRate() {
        return footmanDefenceEnhanceRate;
    }

    public float getArcherAttackEnhanceRate() {
        return archerAttackEnhanceRate;
    }

    public float getArcherDefenceEnhanceRate() {
        return archerDefenceEnhanceRate;
    }

    public float getRiderAttackEnhanceRate() {
        return riderAttackEnhanceRate;
    }

    public float getRiderDefenceEnhanceRate() {
        return riderDefenceEnhanceRate;
    }

    public float getSpecialAttackEnhanceRate() {
        return specialAttackEnhanceRate;
    }

    public float getSpecialDefenceEnhanceRate() {
        return specialDefenceEnhanceRate;
    }

	public float getCaptainShipEnhanceValue() {
		return captainShipEnhanceValue;
	}

	public void setCaptainShipEnhanceValue(float captainShipEnhanceValue) {
		this.captainShipEnhanceValue = captainShipEnhanceValue;
	}

}
