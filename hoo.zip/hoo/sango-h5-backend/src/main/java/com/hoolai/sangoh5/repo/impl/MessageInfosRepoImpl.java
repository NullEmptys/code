package com.hoolai.sangoh5.repo.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.message.MessageInfos;
import com.hoolai.sangoh5.repo.MessageInfosRepo;
import com.hoolai.sangoh5.repo.impl.key.MessageInfosKey;

@Component("messageInfosRepo")
public class MessageInfosRepoImpl implements MessageInfosRepo {

	@Autowired
	@Qualifier("userClient")
	private ExtendedMemcachedClient client;
	
	@Autowired
	private BoFactory boFactory;
	
	@Override
	public MessageInfos findMessageInfos(long userId) {
		String key = MessageInfosKey.getMessageInfosKey(userId);
		byte[] bytes = (byte[]) client.get(key);
		if(bytes == null){
			return new MessageInfos(userId);
		}
		return new MessageInfos(bytes);
	}

	@Override
	public boolean saveMessageInfos(MessageInfos messageInfos) {
		String key = MessageInfosKey.getMessageInfosKey(messageInfos.getUserId());
		return client.set(key, messageInfos.toByteArray());
	}
	
	@Override
	public long generaterUniqueId(long userId){
		String keyString = MessageInfosKey.generateMessageId(userId);
		return client.incr(keyString);
	}

}
