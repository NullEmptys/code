package com.hoolai.sangoh5.bo.battle.enhance.buff;

import java.util.Iterator;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 *
 */
public class ShanShuoTuXiBuff extends Buff {

    private int count;

    private Skill skill;

    /*
     * 触发技能后的下一回生效
     */
    @Override
    public void apply(FightUnit target) {
        this.result();
        if (target.isHaveNewTarget() && !target.getPositionManager().isReachTargetPos()) {
            this.isForFront = true;
            this.isNew = true;
            this.isCanRepeatPlay = count > 0 ? true : false;

            if (count > 0) {
                target.addBattleLog(target.name() + "使用" + targetUsedSkillXmlId + "[" + skill.getName() + "]冲锋，并让自己增加攻击力比率" + +skill.getTwoPercentage() + ",持续回合数="
                        + skill.getTwoRepeatCount());
                Buff buff = findBuff(target);
                if (buff == null) {
                    buff = new ChangeAttackBuff(targetUsedSkillXmlId, skill.getName(), target.name(), target, skill.getForceType(), Effect.DEFAULT_BUFF_LEVEL,
                            skill.getTwoPercentage());
                    buff.withActorName(target.name()).withTargetName(target.name()).withRepeatCount(skill.getTwoRepeatCount()).withKeepBuff();
                    buff.apply(target);
                    target.addAfterBuff(buff);
                    buff.setForFront(false);// 这个技能比较特殊，两个buff是衍生的，给一个主buff给前端就行了
                } else {
                    buff.setRepeatCount(skill.getTwoRepeatCount());
                    buff.setForFront(false);
                    buff.setIsNew(false);
                }
            }

            count++;
        }
    }

    private Buff findBuff(FightUnit target) {
        Iterator<Buff> iterator = target.getBuffList().iterator();
        while (iterator.hasNext()) {
            Buff buff = iterator.next();
            if (buff.getTargetUsedSkillXmlId() == targetUsedSkillXmlId && buff instanceof ChangeAttackBuff) {
                return buff;
            }
        }
        return null;
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
    }

    @Override
    protected ShanShuoTuXiBuff clone() {
        ShanShuoTuXiBuff buff = (ShanShuoTuXiBuff) super.clone(new ShanShuoTuXiBuff(this.targetUsedSkillXmlId, executeName, isForFront, currentLevel, skill));
        return buff;
    }

    public ShanShuoTuXiBuff(int targetUsedSkillXmlId, FightUnitName executeName, boolean is4front, int currentLevel, Skill skill) {
        super(targetUsedSkillXmlId, skill.getName(), executeName, currentLevel);
        this.isForFront = is4front;
        this.skill = skill;
    }

}
