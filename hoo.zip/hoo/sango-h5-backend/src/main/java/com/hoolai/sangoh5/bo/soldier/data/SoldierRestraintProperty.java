package com.hoolai.sangoh5.bo.soldier.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class SoldierRestraintProperty extends JsonProperty {

	private String solName;
	private int solType;
	private String solEnemy;
	private int solEnemyType;
	private float hurtRatio;

	public String getSolName() {
		return solName;
	}

	public void setSolName(String solName) {
		this.solName = solName;
	}

	public int getSolType() {
		return solType;
	}

	public void setSolType(int solType) {
		this.solType = solType;
	}

	public String getSolEnemy() {
		return solEnemy;
	}

	public void setSolEnemy(String solEnemy) {
		this.solEnemy = solEnemy;
	}

	public int getSolEnemyType() {
		return solEnemyType;
	}

	public void setSolEnemyType(int solEnemyType) {
		this.solEnemyType = solEnemyType;
	}

	public float getHurtRatio() {
		return hurtRatio;
	}

	public void setHurtRatio(float hurtRatio) {
		this.hurtRatio = hurtRatio;
	}

}
