package com.hoolai.sangoh5.bo.activity.data;

import java.io.IOException;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.google.common.collect.Sets;
import com.hoolai.sangoh5.util.ProbabilityUtils;
import com.hoolai.sangoh5.util.json.JsonData;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 15:42
 * @version : 1.0
 */
@Component
public class LuckyWheelData extends JsonData<LuckyWheelProperty> {

    @PostConstruct
    @Override
    public void init() {
        try {
            initData("com/hoolai/sangoh5/luckyWheel.json", LuckyWheelProperty.class);
        } catch (IOException e) {
            logger.error(e);
        }
    }

    @Override
    protected void checkProperty(LuckyWheelProperty property) {

    }

    public LuckyWheelProperty random(BestRewardProperty bestRewardProperty, int lantianyu, int totalNum) {
        if (totalNum % 10 == 0) {
            return this.getProperty(3);
        }
        Set<LuckyWheelProperty> properties = Sets.newHashSet(propertyMap.values());
        properties.add(new LuckyWheelProperty(0, "lanTianYu", -10, lantianyu, bestRewardProperty.getProbability()));

        return ProbabilityUtils.randomByWeight(properties);
    }

}
