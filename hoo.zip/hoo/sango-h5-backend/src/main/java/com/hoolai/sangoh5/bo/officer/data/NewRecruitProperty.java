package com.hoolai.sangoh5.bo.officer.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * 招募普通产出表
 * 
 * @author hp
 *
 */
public class NewRecruitProperty extends JsonProperty {

	private int type;// 招将类型
	private int goodsId;// 物品id
	private String goodsType;// 物品类型
	private int goodsStar;// 物品星级
	private int goodNum;// 物品数量
	private int proValue;// 概率值

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(int goodsId) {
		this.goodsId = goodsId;
	}

	public String getGoodsType() {
		return goodsType;
	}

	public void setGoodsType(String goodsType) {
		this.goodsType = goodsType;
	}

	public int getGoodsStar() {
		return goodsStar;
	}

	public void setGoodsStar(int goodsStar) {
		this.goodsStar = goodsStar;
	}

	public int getGoodNum() {
		return goodNum;
	}

	public void setGoodNum(int goodNum) {
		this.goodNum = goodNum;
	}

	public int getProValue() {
		return proValue;
	}

	public void setProValue(int proValue) {
		this.proValue = proValue;
	}
}
