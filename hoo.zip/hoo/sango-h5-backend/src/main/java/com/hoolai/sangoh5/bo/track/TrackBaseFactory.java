package com.hoolai.sangoh5.bo.track;

import com.dw.metrics.Counter;
import com.dw.metrics.Dau;
import com.dw.metrics.Economy;
import com.dw.metrics.GameInfo;
import com.dw.metrics.Install;
import com.dw.metrics.Milestone;
import com.dw.metrics.Payment;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.util.TimeUtil;

public class TrackBaseFactory {

    public static final Dau createDau(String source, String affiliate, String creative, String family, String genus, String ip, String userId, String fromUid, String extra) {
        Dau dau = new Dau();
        dau.setAffiliate(affiliate);
        dau.setCreative(creative);
        dau.setFamily(family);
        dau.setFromUid(fromUid);
        dau.setGenus(genus);
        dau.setIp(ip);
        dau.setSource(source);
        dau.setUserId(userId);
        String dateTimeStr = DateUtil.f(TimeUtil.currentTimeMillis(), DateUtil.DATE_FORMAT_SECONDS);
        String[] datatimeStrArray = dateTimeStr.split(" ");
        dau.setDauDate(datatimeStrArray[0]);
        dau.setDauTime(datatimeStrArray[1]);
        dau.setExtra(extra);
        //dau.processDate();
        return dau;
    }

    public static final Install createInstall(String source, String affiliate, String creative, String family, String genus, String userId, String fromUid) {
        Install install = new Install();
        install.setAffiliate(affiliate);
        install.setCreative(creative);
        install.setFamily(family);
        install.setFromUid(fromUid);
        install.setGenus(genus);
        install.setSource(source);
        install.setUserId(userId);
        String dateTimeStr = DateUtil.f(TimeUtil.currentTimeMillis(), DateUtil.DATE_FORMAT_SECONDS);
        String[] datatimeStrArray = dateTimeStr.split(" ");
        install.setInstallDate(datatimeStrArray[0]);
        install.setInstallTime(datatimeStrArray[1]);
        return install;
    }

    public static final Counter createCounter(String platformIdStr, String userLevel, String counter, String kingdom, String phylum, String classfield, String family,
            String genus, String value, String extra, String roleId) {
        Counter counterInstance = new Counter();
        counterInstance.setUserId(platformIdStr);
        counterInstance.setUserLevel(userLevel);
        counterInstance.setCounter(counter);
        counterInstance.setKingdom(kingdom);
        counterInstance.setPhylum(phylum);
        counterInstance.setClassfield(classfield);
        counterInstance.setFamily(family);
        counterInstance.setGenus(genus);
        counterInstance.setValue(value);
        counterInstance.setRoleId(roleId);
        String dateTimeStr = DateUtil.f(TimeUtil.currentTimeMillis(), DateUtil.DATE_FORMAT_SECONDS);
        String[] datatimeStrArray = dateTimeStr.split(" ");
        counterInstance.setCounterDate(datatimeStrArray[0]);
        counterInstance.setCounterTime(datatimeStrArray[1]);
        counterInstance.setExtra(extra);
        return counterInstance;
    }

    public static final GameInfo createGameInfo(String platformIdStr, String userLevel, String gameinfo, String kingdom, String phylum, String classfield, String family,
            String genus, String value, String extra) {
        GameInfo gameInfo = new GameInfo();
        gameInfo.setUserId(platformIdStr);
        gameInfo.setUserLevel(userLevel);
        gameInfo.setGameinfo(gameinfo);
        gameInfo.setKingdom(kingdom);
        gameInfo.setPhylum(phylum);
        gameInfo.setClassfield(classfield);
        gameInfo.setFamily(family);
        gameInfo.setGenus(genus);
        gameInfo.setValue(value);
        String dateTimeStr = DateUtil.f(TimeUtil.currentTimeMillis(), DateUtil.DATE_FORMAT_SECONDS);
        String[] datatimeStrArray = dateTimeStr.split(" ");
        gameInfo.setGameinfoDate(datatimeStrArray[0]);
        gameInfo.setGameinfoTime(datatimeStrArray[1]);
        gameInfo.setExtra(extra);
        return gameInfo;
    }

    public static final Economy createEconomy(String platformIdStr, String currency, String kingdom, String phylum, String classfield, String family, String genus, String amount,
            String value, String extra) {

        Economy economy = new Economy();
        economy.setUserId(platformIdStr);
        economy.setCurrency(currency);
        economy.setKingdom(kingdom);
        economy.setPhylum(phylum);
        economy.setClassfield(classfield);
        economy.setFamily(family);
        economy.setGenus(genus);
        economy.setAmount(amount);
        economy.setValue(value);
        economy.setExtra(extra);
        String dateTimeStr = DateUtil.f(TimeUtil.currentTimeMillis(), DateUtil.DATE_FORMAT_SECONDS);
        String[] datatimeStrArray = dateTimeStr.split(" ");
        economy.setEconomyDate(datatimeStrArray[0]);
        economy.setEconomyTime(datatimeStrArray[1]);
        return economy;
    }

    public static final Payment createPayment(String platformIdStr, String currency, String kingdom, String phylum, String ip, String transactionid, String status,
            String provider, String extra, String amount, String value2) {
        Payment payment = new Payment();
        payment.setUserId(platformIdStr);
        payment.setCurrency(currency);
        payment.setKingdom(kingdom);
        payment.setPhylum(phylum);
        payment.setIp(ip);
        payment.setTransactionid(transactionid);
        payment.setStatus(status);
        payment.setProvider(provider);
        payment.setExtra(extra);
        payment.setAmount(amount);
        payment.setValue2(value2);

        String dateTimeStr = DateUtil.f(TimeUtil.currentTimeMillis(), DateUtil.DATE_FORMAT_SECONDS);
        String[] datatimeStrArray = dateTimeStr.split(" ");
        payment.setPaymentDate(datatimeStrArray[0]);
        payment.setPaymentTime(datatimeStrArray[1]);
        return payment;
    }

    public static final Milestone createMilestone(String platformIdStr, String milestone, String value, String extra) {
        Milestone milestoneObj = new Milestone();
        milestoneObj.setMilestone(milestone);
        milestoneObj.setUserId(platformIdStr);
        milestoneObj.setValue(value);
        milestoneObj.setExtra(extra);

        String dateTimeStr = DateUtil.f(TimeUtil.currentTimeMillis(), DateUtil.DATE_FORMAT_SECONDS);
        String[] datatimeStrArray = dateTimeStr.split(" ");
        milestoneObj.setMilestoneDate(datatimeStrArray[0]);
        milestoneObj.setMilestoneTime(datatimeStrArray[1]);

        return milestoneObj;
    }
}
