package com.hoolai.sangoh5.bo.user.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class NameProperty extends JsonProperty {

    private int id;

    private int type;

    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
