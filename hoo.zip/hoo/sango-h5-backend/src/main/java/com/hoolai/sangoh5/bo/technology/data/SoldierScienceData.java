package com.hoolai.sangoh5.bo.technology.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class SoldierScienceData extends JsonData<SoldierScienceProperty> {

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/soldierScience.json", SoldierScienceProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void checkProperty(SoldierScienceProperty property) {
        // TODO Auto-generated method stub

    }

}
