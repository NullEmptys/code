package com.hoolai.sangoh5.bo.rescue.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class RewardData extends JsonData<RewardProperty> {

	@PostConstruct
	public void init() {
		try {
//			initData("com/hoolai/sangoh5/rescueReward.json", RewardProperty.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 根据天数获取奖励物品
	 * @return
	 */
	public Map<String, List<RewardProperty>> getDayRewardData() {
		Map<String, List<RewardProperty>> tempMap = new HashMap<String, List<RewardProperty>>();
		for (RewardProperty rewardProperty : propertyMap.values()) {
			if (!tempMap.containsKey(rewardProperty.getDayTime())) {
				List<RewardProperty> rewardList = new ArrayList<RewardProperty>();
				rewardList.add(rewardProperty);
				tempMap.put(rewardProperty.getDayTime(), rewardList);
			} else {
				List<RewardProperty> rewardList = tempMap.get(rewardProperty.getDayTime());
				rewardList.add(rewardProperty);
				tempMap.put(rewardProperty.getDayTime(), rewardList);
			}
		}
		return tempMap;
	}

	@Override
	protected void checkProperty(RewardProperty property) {
		// TODO Auto-generated method stub

	}

}
