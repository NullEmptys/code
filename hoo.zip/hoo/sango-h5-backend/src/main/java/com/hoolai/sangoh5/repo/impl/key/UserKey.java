package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class UserKey {

    private static final String prefix_platform = "ht_p";

    private static final String prefix_user = "ht_u";

    private static final String prefix_user_rank = "r";

    private static final String prefix_user_friend = "uf";

    private static final String prefix_cdkey = "cd";

    /**
     * platformId->userId
     *
     * @param platformId
     * @return
     */
    public static String getUserIdKey(String platformId) {
        return new StringBuilder().append(prefix_platform).append(Constant.separator).append(platformId).append(Constant.separator).append("uid").toString();
    }

    public static String getUserKey(long userId) {
        return new StringBuilder().append(prefix_user).append(Constant.separator).append(userId).toString();
    }

    public static String getOperationTimeKey(long userId) {
        return new StringBuilder(prefix_user).append(Constant.separator).append(userId).append("l").append(Constant.separator).append("oping").toString();
    }

    public static String getAccountStateKey(long userId) {
        return new StringBuilder().append(prefix_user).append(Constant.separator).append(userId).append(Constant.separator).append("as").toString();
    }

    public static String getPlatformIdKey(long userId) {
        return new StringBuffer().append(prefix_user).append(Constant.separator).append(userId).append(Constant.separator).append("pid").toString();
    }

    /**
     * 分等级用户Id，用于随机抽取网友
     * 
     * @return
     */
    public static String getRankUserIdsKey(int rank) {
        return new StringBuilder().append(prefix_user_rank).append(Constant.separator).append(rank).append(Constant.separator).append("uids").toString();
    }

    /**
     * 分等级分州县用户Id，用于随机抽取网友
     * 
     * @return
     */
    public static String getStateRankUserIdsKey(int rank, int state, int mainCityStatus) {
        return new StringBuilder().append(prefix_user_rank).append(Constant.separator).append(rank).append(Constant.separator).append(state).append(Constant.separator)
                .append(mainCityStatus).append(Constant.separator).append("ursids").toString();
    }

    public static String getUniqueIdKey() {
        return "htunid";
    }

    /**
     * 所有用户的Id，用于随机抽取网友
     *
     * @return
     */
    public static String getAllUserIdKey() {
        return "htau";
    }

    /**
     * 根据platformId查找serverId
     * 
     * @param platform
     * @return
     */
    public static String getServerIdKey(String platform) {
        return new StringBuilder().append(prefix_platform).append(Constant.separator).append(platform).append(Constant.separator).append("serverId").toString();
    }

    public static String getFriendKey(long userId) {
        return new StringBuilder().append(prefix_user_friend).append(Constant.separator).append(userId).append(Constant.separator).append("prefix_user_friend").toString();
    }

    public static String getLockUserKey(long userId) {
        return new StringBuilder().append(prefix_user).append(Constant.separator).append(userId).append(Constant.separator).append("lock").toString();
    }

    public static String getActivitiesKey(long userId) {
        return new StringBuilder().append(prefix_user).append(Constant.separator).append(userId).append(Constant.separator).append("activity").toString();
    }

    public static String getActivities() {
        return new StringBuilder().append(prefix_user).append(Constant.separator).append("activity").toString();
    }

    public static String getLuckyWheel() {
        return new StringBuilder().append(prefix_user).append(Constant.separator).append("luckyWheel").toString();
    }

    public static String getTrackInfo(String openid) {
        return new StringBuilder().append(prefix_platform).append(Constant.separator).append(openid).toString();
    }

    public static String getCdkeyCountKey(int id) {
        return new StringBuilder().append(prefix_cdkey).append(Constant.separator).append(id).append(Constant.separator).append("count").toString();
    }

    public static String getCdkeyKey() {
        return "cdkey";
    }

    public static String getAnnounceKey() {
        return "announce";
    }

    public static String getInviterKey(String openid) {
        return new StringBuilder().append(prefix_platform).append(Constant.separator).append(openid).append(Constant.separator).append("in").toString();
    }

    public static String getFocusonKey(String openid) {
        return new StringBuilder().append(prefix_platform).append(Constant.separator).append(openid).append(Constant.separator).append("fo").toString();
    }

    public static String getLockUserActivityKey(long userId) {
        return new StringBuilder().append(prefix_user).append(Constant.separator).append(userId).append(Constant.separator).append("aclk").toString();
    }

    public static String getLockLuckyWheelKey() {
        return "lockluckywheel";
    }

    public static String getMonarchKey(int zoneId, long monarchId) {
        return new StringBuilder().append(prefix_user).append(Constant.separator).append(zoneId).append(Constant.separator).append(monarchId).append(Constant.separator)
                .append("monarch").toString();
    }

    public static String getBindKey(String openid) {
        return new StringBuilder().append(prefix_platform).append(Constant.separator).append(openid).append(Constant.separator).append("bind").toString();
    }

    public static String getHuatengKey(long userId) {
        return new StringBuilder().append(prefix_user).append(Constant.separator).append(userId).append(Constant.separator).append("huateng").toString();
    }
}
