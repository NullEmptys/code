package com.hoolai.sangoh5.bo.battle.skill.defence.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 神盾防御
 * 
 * @author liqing
 *
 */
public class ShenDunDefence extends DefencePassiveSkill {

    private int maxDefenceValue;

    private int alreayDefenceValue;

    @Override
    public void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {
        if (effect == null || effect.getDeltaHp() < 1 || actor.isDead() || target.isDead()) {
            return;
        }
        if (alreayDefenceValue >= maxDefenceValue) {
            // TODO 在这移除有错，先不移除，只是返回，对战斗不产生影响,重新触发的时候会reset
            //			target.removeCounterAttackSkills(this);
            return;
        }

        int delHp = effect.getDeltaHp();
        alreayDefenceValue += delHp;
        effect.setDeltaHp(Math.max(alreayDefenceValue - maxDefenceValue, 0));

        // 在此需要加个buff告诉前端我抵御了
        target.addBuff(new Buff(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name()));

        target.addBattleLog(target.name() + "使用" + this.xmlId + "[" + this.name + "]防御了" + actor.name() + "的伤害，old=" + delHp + ",new=" + effect.getDeltaHp() + ",已防御伤害数="
                + alreayDefenceValue);
    }

    @Override
    public Skill clone() {
        ShenDunDefence shenDunDefence = (ShenDunDefence) super.clone(new ShenDunDefence(xmlId, name, maxDefenceValue));
        shenDunDefence.alreayDefenceValue = alreayDefenceValue;
        return shenDunDefence;
    }

    public ShenDunDefence(int xmlId, String name, int value) {
        this.xmlId = xmlId;
        this.name = name;
        this.maxDefenceValue = value;
    }

    public void reset(int value) {
        this.maxDefenceValue = value;
        this.alreayDefenceValue = 0;
    }

}
