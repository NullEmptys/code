package com.hoolai.sangoh5.bo.item;

import com.hoolai.sango.core.service.ServiceDatas;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.service.ItemDomainService;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public enum GoodsType {

    ITEM("item") {

        @Override
        public ServiceDatas buyGoods(User user, int xmlId, int num, ItemDomainService itemDomainService) {
            return itemDomainService.buyItem(user, xmlId, num);
        }
    },
    SALVENPC("slaveNpc") {

        @Override
        public ServiceDatas buyGoods(User user, int xmlId, int num, ItemDomainService itemDomainService) {
            return itemDomainService.buySlaveNpc(user, xmlId, num);
        }
    },
    SKILL("skill") {

        @Override
        public ServiceDatas buyGoods(User user, int xmlId, int num, ItemDomainService itemDomainService) {
            return itemDomainService.buyItem(user, xmlId, num);
        }
    },
    MATERIAL("material") {

        @Override
        public ServiceDatas buyGoods(User user, int xmlId, int num, ItemDomainService itemDomainService) {
            return itemDomainService.buyItem(user, xmlId, num);
        }
    },;

    private final String type;

    private GoodsType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static GoodsType convertGoodsType(String type) {
        for (GoodsType goodsType : values()) {
            if (type.equalsIgnoreCase(goodsType.getType())) {
                return goodsType;
            }
        }
        throw new BusinessException(ErrorCode.NO_THIS_TYPE);
    }

    public abstract ServiceDatas buyGoods(User user, int xmlId, int num, ItemDomainService itemDomainService);

}
