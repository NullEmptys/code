package com.hoolai.sangoh5.bo.activity.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class CumulativeLoginData extends JsonData<CumulativeLoginProperty> {

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/evendayReward.json", CumulativeLoginProperty.class);
        } catch (IOException e) {
            logger.error(e);
        }
    }

    @Override
    protected void checkProperty(CumulativeLoginProperty property) {
        // TODO Auto-generated method stub

    }

    public List<Award> getLoginDaysGift(int day) {
        CumulativeLoginProperty property = propertyMap.get(day);
        List<Award> items = new ArrayList<Award>();

        String type[] = property.getType();
        int reAward[] = property.getReward();
        int num[] = property.getNum();

        for (int i = 0; i < type.length; i++) {
            items.add(new Award(reAward[i], num[i], AwardType.converToAwardType(type[i])));
        }
        return items;
    }

    public int getSize() {
        return propertyMap.size();
    }

}
