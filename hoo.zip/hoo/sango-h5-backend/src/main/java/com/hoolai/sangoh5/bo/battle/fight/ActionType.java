package com.hoolai.sangoh5.bo.battle.fight;

public enum ActionType {
    
	/**没有动作*/
    NONE, 
	/**攻击*/
    ATTACK, 
	/**攻击停顿*/
    ATTACK_IDLE,
	/**移动*/
    MOVE,
	/**移动停顿*/
    MOVE_IDLE, 
	/***/
    MOVE_PASUE;
}
