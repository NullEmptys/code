package com.hoolai.sangoh5.bo.battle.fight;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.RoundResultProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class RoundResult implements ProtobufSerializable<RoundResultProto> {

    private int roundNum;//第几个round

    private List<ActionResult> actionResultList = new ArrayList<ActionResult>();

    public RoundResult(int roundNum) {
        this.roundNum = roundNum;
    }

    public List<ActionResult> getActionResultList() {
        return actionResultList;
    }

    public void setActionResultList(List<ActionResult> actionResultList) {
        this.actionResultList = actionResultList;
    }

    public int getRoundNum() {
        return roundNum;
    }

    public void setRoundNum(int roundNum) {
        this.roundNum = roundNum;
    }

    public void addActionResults(List<ActionResult> actionResults) {
        for (ActionResult actionResult : actionResults) {
            if (actionResult == null) continue;
            this.actionResultList.add(actionResult);
        }
    }

    public void addActionResult(ActionResult actionResult) {
        this.actionResultList.add(actionResult);
    }

    @Override
    public String toString() {
        return "RoundResult [actionResultList=" + actionResultList + ", roundNum=" + roundNum + "]";
    }

    public RoundResult() {
    }

    public RoundResult(RoundResultProto proto) {
        copyFrom(proto);
    }

    @Override
    public void copyFrom(RoundResultProto message) {
        this.roundNum = message.getRoundNum();
        int count = message.getActionResultListCount();
        if (count > 0) {
            this.actionResultList = new ArrayList<ActionResult>();
            for (int i = 0; i < count; i++) {
                actionResultList.add(new ActionResult(message.getActionResultList(i)));
            }
        }
    }

    @Override
    public RoundResultProto copyTo() {
        RoundResultProto.Builder builder = RoundResultProto.newBuilder();
        builder.setRoundNum(roundNum);
        if (actionResultList != null && actionResultList.size() > 0) {
            for (ActionResult w : actionResultList) {
                builder.addActionResultList(w.copyTo());
            }
        }
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] arg0) {
        try {
            RoundResultProto message = RoundResultProto.parseFrom(arg0);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

}
