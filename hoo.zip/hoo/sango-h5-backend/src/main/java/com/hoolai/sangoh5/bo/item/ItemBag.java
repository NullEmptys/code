package com.hoolai.sangoh5.bo.item;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.ItemBagProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class ItemBag implements ProtobufSerializable<ItemBagProto> {

    private int xmlId;

    private int num;

    public ItemBag() {
    }

    public ItemBag(int xmlId, int num) {
        this.xmlId = xmlId;
        this.num = num;
    }

    public ItemBag(ItemBagProto message) {
        copyFrom(message);
    }

    public int getXmlId() {
        return xmlId;
    }

    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    @Override
    public ItemBagProto copyTo() {
        ItemBagProto.Builder builder = ItemBagProto.newBuilder();
        builder.setNum(num);
        builder.setXmlId(xmlId);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ItemBagProto message = ItemBagProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }

    }

    @Override
    public void copyFrom(ItemBagProto message) {
        this.xmlId = message.getXmlId();
        this.num = message.getNum();
    }

    public void incrNum(int num) {
        this.num += num;
    }

    public boolean decNum(int num) {
        int remaining = getNum() - num;

        if (remaining < 0) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_ITEM);
        }

        this.num = remaining;

        return this.num == 0;
    }

    public boolean isHaveEnough(int num) {
        if (this.num < num) {
            return false;
        }
        return true;
    }

    public void checkAndDecrease(int num) {
        if (!isHaveEnough(num)) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_ITEM);
        }
        decNum(num);
    }

}
