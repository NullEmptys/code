package com.hoolai.sangoh5.bo.officerunion.data;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.officerunion.OfficerUnion;
import com.hoolai.sangoh5.bo.officerunion.OfficerUnionStar;
import com.hoolai.sangoh5.bo.officerunion.OfficerUnions;
import com.hoolai.sangoh5.repo.OfficerRepo;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class OfficerUnionData extends JsonData<OfficerUnionProperty> {

    @Autowired
    private OfficerRepo officerRepo;

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/combination.json", OfficerUnionProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(OfficerUnionProperty property) {
        // TODO Auto-generated method stub

    }

    private int findMaxStar(List<Officer> officers, int xmlId) {
        int maxStar = 0;
        Iterator<Officer> iterator = officers.iterator();
        while (iterator.hasNext()) {
            Officer officer = iterator.next();
            if (officer.getXmlId() == xmlId) {
                if (officer.getStarLevel() > maxStar) {
                    maxStar = officer.getStarLevel();
                }
                iterator.remove();
            }
        }
        return maxStar;
    }

    /**
     * 新用户初始化将领组合列表，因为还没有将领列表，应该不需要查询
     * 
     * @param userId
     * @return
     */
    public OfficerUnions createNewOfficerUnions(long userId) {
        //        List<Officer> officers = officerRepo.findOfficerList(userId);

        OfficerUnions officerUnions = new OfficerUnions(userId);
        for (OfficerUnionProperty property : this.propertyMap.values()) {
            officerUnions.addOfficerUnion(createOfficerUnion(property, null));
        }

        return officerUnions;
    }

    /**
     * 老用户更新将领组合列表，一般发生于新增组合，这时需要查询以往将领信息
     * 
     * @param officerUnions
     * @return
     */
    public OfficerUnions updateOfficerUnions(OfficerUnions officerUnions) {
        if (officerUnions.getOfficerUnions().size() < this.propertyMap.size()) {
            for (OfficerUnionProperty property : this.propertyMap.values()) {
                if (officerUnions.findOfficerUnion(property.getId()) != null) {
                    continue;
                }
                List<Officer> officers = officerRepo.findMiniOfficerList(officerUnions.getUserId());
                officerUnions.addOfficerUnion(createOfficerUnion(property, officers));
            }
        }
        return officerUnions;
    }

    private OfficerUnion createOfficerUnion(OfficerUnionProperty property, List<Officer> officers) {
        OfficerUnion officerUnion = new OfficerUnion(property.getId());
        int[] officerXmlIds = property.getOfficerID();
        for (int officerXmlId : officerXmlIds) {
            int maxStarLv = officers == null ? 0 : findMaxStar(officers, officerXmlId);
            OfficerUnionStar officerUnionStar = new OfficerUnionStar(officerXmlId, maxStarLv);
            officerUnion.addOfficerUnionStar(officerUnionStar);
        }
        return officerUnion;
    }
}
