package com.hoolai.sangoh5.bo.activity.data;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.annotate.JsonIgnore;

import com.google.common.collect.Lists;
import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.bo.user.User.CurrencyType;
import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-16 10:51
 * @version : 1.0
 */
public class ActivityItemProperty extends JsonProperty {

    /** 名称 **/
    private String name;

    /** 物品类型 **/
    private String[] type;

    /** 物品id **/
    private int[] reward;

    /** 数量 **/
    private int[] num;

    /** 价格 **/
    private String price;

    @JsonIgnore
    private CurrencyType currencyType;

    @JsonIgnore
    private int cost;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String[] getType() {
        return type;
    }

    public void setType(String[] type) {
        this.type = type;
    }

    public int[] getReward() {
        return reward;
    }

    public void setReward(int[] reward) {
        this.reward = reward;
    }

    public int[] getNum() {
        return num;
    }

    public void setNum(int[] num) {
        this.num = num;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public CurrencyType getCurrencyType() {
        return currencyType;
    }

    public int getCost() {
        return cost;
    }

    public void checkAndInit() {
        String[] split = StringUtils.split(price, "|");
        if (split.length != 3) {
            throw new RuntimeException(id + " price is error " + price);
        }
        if ("0".equalsIgnoreCase(split[0].trim())) {
            return;
        }
        this.currencyType = CurrencyType.valueOf(split[0].trim().toUpperCase());
        this.cost = Integer.valueOf(split[2]);
    }

    public List<Award> getRewardList() {
        int rewardLength = type.length;
        List<Award> awardList = Lists.newArrayListWithExpectedSize(rewardLength);
        for (int i = 0; i < rewardLength; i++) {
            awardList.add(new Award(reward[i], num[i], AwardType.converToAwardType(type[i])));
        }
        return awardList;
    }
}
