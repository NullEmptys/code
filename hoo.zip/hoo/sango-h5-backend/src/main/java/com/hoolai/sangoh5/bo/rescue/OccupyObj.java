package com.hoolai.sangoh5.bo.rescue;

/**
 * 悬赏列表
 * 
 * @author Administrator
 *
 */
public class OccupyObj {

    private long occupyId;// 占领者id

    private String userName;// 占领者名称

    private int level;// 占领者等级

    private int offerId;// 占领者将领id

    private long occupyTime;// 占领时间

    private long beRescueUserId;// 被占领者id

    public static class SingletonOccupyObj {

        private static OccupyObj occupyObj = new OccupyObj();
    }

    public OccupyObj() {

    }

    public void setOccupyObjInfo(int officerId, String userName) {
        this.userName = userName;
        this.level = 1;
        this.occupyTime = 1;
        this.offerId = officerId;
    }

    public static OccupyObj getInstance() {
        return SingletonOccupyObj.occupyObj;
    }

    public long getOccupyId() {
        return occupyId;
    }

    public void setOccupyId(long occupyId) {
        this.occupyId = occupyId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getOfferId() {
        return offerId;
    }

    public void setOfferId(int offerId) {
        this.offerId = offerId;
    }

    public long getOccupyTime() {
        return occupyTime;
    }

    public void setOccupyTime(long occupyTime) {
        this.occupyTime = occupyTime;
    }

    public long getBeRescueUserId() {
        return beRescueUserId;
    }

    public void setBeRescueUserId(long beRescueUserId) {
        this.beRescueUserId = beRescueUserId;
    }

}
