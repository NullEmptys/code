package com.hoolai.sangoh5.bo.battle.enhance.buff;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.fight.ActionResult;
import com.hoolai.sangoh5.bo.battle.fight.HpLostListener;
import com.hoolai.sangoh5.bo.battle.skill.passive.BingHun;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 战火覆盖范围内改变防御力
 */
public class CaptainshipBuff extends Buff {

    private FightUnit skillOwner;

    private final BingHun skill;

    List<FightUnit> foreUnits;

    private void addDefenceValue(TargetCollection tc, HpLostListener actorHpLostListener, List<ActionResult> actionResultList) {

        float dindex = actorHpLostListener.lostPercentage();
        int oldDIndex = skill.getAddDefenceIndex();
        int add = (int) (dindex / skill.getTwoValue());
        if (add - oldDIndex > 0) {//避免重复加，一个阶梯只加一次
            skillOwner.addBattleLog(skillOwner.name() + "使用冰魂,目前我方死亡率" + dindex);

            for (FightUnit target : foreUnits) {
                if (target.isDead()) {
                    continue;
                }
                float d = target.baseDefencePoint() * skill.getTwoPercentage() * (add - oldDIndex);
                target.changeDefencePoint(d);
                ActionResult actionResult = findActionResult(skill.getXmlId(), target, actionResultList);
                actionResult.getBuffList().add(
                        new Buff(skill.getXmlId(), skill.getName(), target.name(), Buff.DEFAULT_BUFF_LEVEL).withActorName(skillOwner.name()).withTargetName(target.name()));

                target.addBattleLog(skillOwner.name() + "使用冰魂," + target.name() + "增加防御力" + d + ",defencePoint=" + target.defencePoint());
            }

            skill.setAddDefenceIndex(add);
        }
    }

    private void addAttackValue(TargetCollection tc, HpLostListener targetHpLostListener, List<ActionResult> actionResultList) {
        float index = targetHpLostListener.lostPercentage();
        int oldIndex = skill.getAddAttackIndex();
        int add = (int) (index / skill.getTwoValue());

        if (add - oldIndex > 0) {
            skillOwner.addBattleLog(skillOwner.name() + "使用冰魂,目前对方死亡率" + index);

            for (FightUnit target : foreUnits) {
                if (target.isDead()) {
                    continue;
                }
                float a = target.baseAttackPoint() * skill.getPercentage() * (add - oldIndex);
                target.changeAttackPoint(a);
                ActionResult actionResult = findActionResult(skill.getXmlId(), target, actionResultList);
                actionResult.getBuffList().add(
                        new Buff(skill.getXmlId(), skill.getName(), target.name(), Buff.DEFAULT_BUFF_LEVEL).withActorName(skillOwner.name()).withTargetName(target.name()));

                target.addBattleLog(skillOwner.name() + "使用冰魂," + target.name() + "增加攻击力" + a + ",attackPoint=" + target.attackPoint());
            }

            skill.setAddAttackIndex(add);
        }
    }

    @Override
    public void targetEnhanceAfterExcuteBuffs(List<ActionResult> actionResultList, TargetCollection tc) {
        this.result();

        HpLostListener actorHpLostListener = skillOwner.getHpLostListener();
        HpLostListener targetHpLostListener = tc.get(FightUnitName.officerUnitName(!skillOwner.isAttacker())).getHpLostListener();

        addAttackValue(tc, targetHpLostListener, actionResultList);
        addDefenceValue(tc, actorHpLostListener, actionResultList);

    }

    @Override
    public void apply(FightUnit target) {
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * 此方法必要的时候需要在子类重写，否则会调用alive.unsilence()清除沉默产生负作用
     * 
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        //alive.removeBuff(this);
    }

    @Override
    protected CaptainshipBuff clone() {
        CaptainshipBuff buff = (CaptainshipBuff) super.clone(new CaptainshipBuff(this.targetUsedSkillXmlId, executeName, skillOwner, skill, currentLevel, isForFront, foreUnits));
        buff.skillOwner = skillOwner;
        return buff;
    }

    public CaptainshipBuff(int xmlId, FightUnitName name, FightUnit actor, BingHun skill, int currentLevel, boolean isFornt, List<FightUnit> foreUnits) {
        super(xmlId, skill.getName(), name, currentLevel);
        this.skillOwner = actor;
        this.skill = skill;
        this.isForFront = isFornt;
        this.foreUnits = foreUnits;
    }

}
