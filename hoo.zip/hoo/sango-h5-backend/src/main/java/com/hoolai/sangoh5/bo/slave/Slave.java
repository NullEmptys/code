package com.hoolai.sangoh5.bo.slave;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.IndustryProtocolBuffer.SlaveProto;
import com.hoolai.sangoh5.bo.item.data.SlaveNpcData;
import com.hoolai.sangoh5.bo.item.data.SlaveNpcProperty;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Slave implements ProtobufSerializable<SlaveProto> {

    public static final int station_free = 1;// 空闲

    public static final int station_farm = 2;// 在农田

    public static final int station_mine = 3;// 在矿洞

    public static final int station_farm_none = 4;// 其实被占君主已经收复城池，但是未在农田或者矿洞中释放

    public static final int station_mine_none = 5;// 其实被占君主已经收复城池，但是未在农田或者矿洞中释放

    private int id;//奴隶ID

    private long slaveId;// 被攻占君主的userId

    private int station = 1;// 目前状态

    private long workTime;// 干活的时间

    private boolean isProduct;// 是否已经产出过

    private int slaveXmlId; // npc奴隶的xmlId

    transient private long userId;

    transient private User slaveUser;

    transient private boolean isUpdate;

    public Slave() {
    }

    public Slave(long userId, byte[] bytes) {
        this.userId = userId;
        parseFrom(bytes);
    }

    public Slave(long userId, User slaveUser) {
        this.userId = userId;
        this.slaveId = slaveUser.getId();
        this.slaveUser = slaveUser;
    }

    public void initUser(User user, SlaveNpcData slaveNpcData) {
        this.slaveUser = user;
        if (getIsNPC()) {
            SlaveNpcProperty property = slaveNpcData.getProperty(slaveXmlId);
            user.setSex(property.getSex());
            user.setName(property.getName());
            user.setSlaveShapeType(property.getSex() == 0 ? new Random().nextInt(2) : new Random().nextInt(3));
        }
    }

    public boolean getIsNPC() {
        return slaveXmlId > 0;
    }

    public int getSlaveXmlId() {
        return slaveXmlId;
    }

    public void setSlaveXmlId(int slaveXmlId) {
        this.slaveXmlId = slaveXmlId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getSlaveId() {
        return slaveId;
    }

    public void setSlaveId(long slaveId) {
        this.slaveId = slaveId;
    }

    public int getStation() {
        return station;
    }

    public void setStation(int station) {
        this.station = station;
    }

    public User getSlaveUser() {
        return slaveUser;
    }

    public void setSlaveUser(User user) {
        this.slaveUser = user;
    }

    public long getWorkTime() {
        return workTime;
    }

    public void setWorkTime(long workTime) {
        this.workTime = workTime;
    }

    public long getUserId() {
        return userId;
    }

    @Override
    public SlaveProto copyTo() {
        SlaveProto.Builder builder = SlaveProto.newBuilder();
        builder.setId(id);
        builder.setSlaveId(slaveId);
        builder.setStation(station);
        builder.setWorkTime(workTime);
        builder.setIsProduct(isProduct);
        builder.setSlaveXmlId(slaveXmlId);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            SlaveProto message = SlaveProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(SlaveProto message) {
        this.id = message.getId();
        this.slaveId = message.getSlaveId();
        this.station = message.getStation();
        this.workTime = message.getWorkTime();
        this.isProduct = message.getIsProduct();
        this.slaveXmlId = message.getSlaveXmlId();
    }

    /**
     * 获取当前奴隶劳动时长
     * 
     * @return
     */
    public long workTimeLong() {
        long currentTimeMillis = TimeUtil.currentTimeMillis();
        long slaveMinute = Math.round(Double.valueOf(TimeUnit.MILLISECONDS.toHours(currentTimeMillis - this.getWorkTime())));
        return slaveMinute;
    }

    /**
     * 检查奴隶是否存在列表中及处于空闲状态
     */
    public void checkIsFree() {
        if (station != station_free) {
            throw new BusinessException(ErrorCode.NOT_FREE_SLAVE);
        }
    }

    public void checkIsWorkInMine() {
        if (getIsNPC()) {
            throw new BusinessException(ErrorCode.NOT_SWITCH_WORK_NPC_SLAVE);
        }

        if (station == Slave.station_mine || station == Slave.station_mine_none) {
            return;
        }
        throw new BusinessException(ErrorCode.NOT_WORK_SLAVE);
    }

    public void checkIsWorkInFarmland() {
        if (getIsNPC()) {
            throw new BusinessException(ErrorCode.NOT_SWITCH_WORK_NPC_SLAVE);
        }
        if (station == Slave.station_farm || station == Slave.station_farm_none) {
            return;
        }
        throw new BusinessException(ErrorCode.NOT_WORK_SLAVE);
    }

    public int calRealWorkHour(long referenceTime, SlaveNpcData slaveNpcData) {
        if (getIsNPC()) {
            if (!isProduct) {
                isProduct = true;
                isUpdate = true;
                SlaveNpcProperty property = slaveNpcData.getProperty(slaveXmlId);
                return property.getValue();
            }
            return 0;
        } else {
            return (int) (Math.round(Double.valueOf(TimeUnit.MILLISECONDS.toHours(referenceTime - workTime))));
        }
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public boolean isCanRemove(SlaveNpcData slaveNpcData) {
        if (getIsNPC()) {
            if (isProduct) {
                SlaveNpcProperty property = slaveNpcData.getProperty(slaveXmlId);
                double hour = Double.valueOf(TimeUnit.MILLISECONDS.toHours(TimeUtil.currentTimeMillis() - workTime));
                return hour >= property.getValue();
            }
            return false;
        } else {
            return station == Slave.station_farm_none || station == Slave.station_mine_none;
        }
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public boolean isUpdate() {
        return isUpdate;
    }

    public void checkCanToFree() {
        if (getIsNPC()) {
            throw new BusinessException(ErrorCode.NOT_FREE_NPC_SLAVE);
        }
    }

}
