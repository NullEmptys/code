package com.hoolai.sangoh5.repo;

import java.util.List;

import com.hoolai.sangoh5.bo.friend.Friend;

public interface FriendRepo {
	
  /**************************** 平台好友  **************************************/
	List<Long> getUserFriendIds(long userId, int platformType);

	List<Friend> getUserFriends(long userId, int platformType);

	boolean isFriend(long userId, long friendUserId, int platformType);

	Friend findFriendByUserId(long userId);

	void addFriend(long userId, String friendPlatformId, int platformType);

	List<Friend> findFriendsByUserIds(List<Long> userIds);

	int findFriendsCount(long userId, int platformType);

	void resetFriends(long userId, List<String> friendPlatformIds,
			int platformType);
	
	List<Friend> getFriendsExcludeUserIds(long userId, List<Long> friendIds,
			int platformType);
	
	int findFriendsMaxCount(long userId);

	void resetFriendsMaxCount(long userId, int count);
	
	/**************************** 平台好友结束  **************************************/
	
	
	
	/**************************** 游戏好友  **************************************/
	List<Friend> getGameFriends(long userId);
	
	List<Friend> getGameFriendsExcludeUserIds(long userId, List<Long> friendIds);

	List<Long> getGameFriendIds(long userId);

	boolean isGameFriend(long userId, long friendUserId);

	int findGameFriendsCount(long userId);

	void addGameFriend(long userId, long friendId);
	
	void removeGameFriend(long userId, long[] fids);
	
	void removeAllGameFriend(long userId);
	
	/**************************** 游戏好友结束  **************************************/
	
	
	
	/**************************** 申请游戏好友  **************************************/
	List<Long> getApplyFriendIds(long userId);

	List<Friend> findApplyFriends(long userId);

	void addApplyFriend(long userId, long appFid);

	void removeApplyFriend(long userId, long[] fids);

	boolean isApplied(long userId,long friendId);

	void removeAllApplyFriend(long userId);

	List<Friend> findRecommendFriends(long userId, int range,int count);

	/**************************** 申请游戏好友结束  **************************************/
	
	/**************************** 申请游戏好友  **************************************/
	/**	 */
	List<Long> getSendFriendIds(long userId);

	void addSendFriend(long userId, List<Object> sendFid);

	void clearSendFriends(long userId);

	int findApplyFriendsCount(long userId);
	
	/**************************** 申请游戏好友结束  **************************************/

}
