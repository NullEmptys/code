package com.hoolai.sangoh5.bo.track;

public class DauInstallCreative {
	
	private final String creative;
    private final String affiliate;
    private final String source;
    
    public DauInstallCreative(String creative, String affiliate, String source) {
        this.creative = creative;
        this.affiliate = affiliate;
        this.source = source;
    }
    
    public String getCreative() {
        return creative;
    }
    public String getAffiliate() {
        return affiliate;
    }
    public String getSource() {
        return source;
    }
    
}
