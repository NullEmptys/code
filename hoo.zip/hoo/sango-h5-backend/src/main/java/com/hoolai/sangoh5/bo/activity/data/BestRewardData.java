package com.hoolai.sangoh5.bo.activity.data;

import java.io.IOException;
import java.util.Collection;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 15:47
 * @version : 1.0
 */
@Component
public class BestRewardData extends JsonData<BestRewardProperty> {

    private BestRewardProperty min;

    private BestRewardProperty max;

    @PostConstruct
    @Override
    public void init() {
        try {
            initData("com/hoolai/sangoh5/bestReward.json", BestRewardProperty.class);
        } catch (IOException e) {
            logger.error(e);
        }
    }

    @Override
    protected void checkProperty(BestRewardProperty property) {
        if (min == null || min.getRange()[0] > property.getRange()[0]) {
            this.min = property;
        }

        if (max == null || max.getRange()[1] < property.getRange()[1]) {
            this.max = property;
        }

    }

    public BestRewardProperty getBestRewardProperty(int lanTianYu) {
        if (lanTianYu <= min.getRange()[0]) {
            return min;
        }
        if (lanTianYu >= max.getRange()[1]) {
            return max;
        }
        Collection<BestRewardProperty> values = this.propertyMap.values();
        for (BestRewardProperty property : values) {
            if (property.getRange()[0] <= lanTianYu && lanTianYu <= property.getRange()[1]) {
                return property;
            }
        }
        throw new RuntimeException("not found best reward");
    }

}
