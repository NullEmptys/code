package com.hoolai.sangoh5.bo.payment;

import java.util.Date;

public class PayLog {

    private int id;

    private long userId;

    private String gameOrderId;

    private String platformOrderId;

    private int amount;

    private int srcAmount;

    private Date successTime;

    private String productId;

    private Date notifyTime;

    private String platformName;

    public PayLog(long userId, String gameOrderId, String platformOrderId, int amount, int srcAmount, Date successTime, String productId, Date notifyTime, String platformName) {
        super();
        this.userId = userId;
        this.gameOrderId = gameOrderId;
        this.platformOrderId = platformOrderId;
        this.amount = amount;
        this.srcAmount = srcAmount;
        this.successTime = successTime;
        this.productId = productId;
        this.notifyTime = notifyTime;
        this.platformName = platformName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getGameOrderId() {
        return gameOrderId;
    }

    public void setGameOrderId(String gameOrderId) {
        this.gameOrderId = gameOrderId;
    }

    public String getPlatformOrderId() {
        return platformOrderId;
    }

    public void setPlatformOrderId(String platformOrderId) {
        this.platformOrderId = platformOrderId;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getSrcAmount() {
        return srcAmount;
    }

    public void setSrcAmount(int srcAmount) {
        this.srcAmount = srcAmount;
    }

    public Date getSuccessTime() {
        return successTime;
    }

    public void setSuccessTime(Date successTime) {
        this.successTime = successTime;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public Date getNotifyTime() {
        return notifyTime;
    }

    public void setNotifyTime(Date notifyTime) {
        this.notifyTime = notifyTime;
    }

    public String getPlatformName() {
        return platformName;
    }

    public void setPlatformName(String platformName) {
        this.platformName = platformName;
    }

    @Override
    public String toString() {
        return "PayLog [id=" + id + ", userId=" + userId + ", gameOrderId=" + gameOrderId + ", platformOrderId=" + platformOrderId + ", amount=" + amount + ", srcAmount="
                + srcAmount + ", successTime=" + successTime + ", productId=" + productId + ", notifyTime=" + notifyTime + ", platformName=" + platformName + "]";
    }

}
