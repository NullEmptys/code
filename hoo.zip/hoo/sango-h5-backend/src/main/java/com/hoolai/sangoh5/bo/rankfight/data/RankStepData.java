package com.hoolai.sangoh5.bo.rankfight.data;

import java.io.IOException;
import java.util.Iterator;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.IntHashMap;

@Component
public class RankStepData extends JsonData<RankStepProperty> {

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/rankStep.json", RankStepProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(RankStepProperty property) {
        // TODO Auto-generated method stub

    }

    public int findAreaValueBuyLevel(int level) {
        IntHashMap<RankStepProperty> rankAreaMap = getPropertyMap();
        Iterator<RankStepProperty> it = rankAreaMap.values().iterator();
        while (it.hasNext()) {
            RankStepProperty rankStep = it.next();
            if (rankStep.getLevel().size() < 2) {
                throw new BusinessException(ErrorCode.JSON_TABLE_ERROR);
            }
            if (level >= rankStep.getLevel().get(0) && level <= rankStep.getLevel().get(1)) {
                return rankStep.getId();
            }
        }
        throw new BusinessException(ErrorCode.JSON_TABLE_ERROR);
    }

}
