package com.hoolai.sangoh5.bo.message;

import java.util.List;

import com.google.protobuf.GeneratedMessage;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.AwardProto;
import com.hoolai.sangoh5.bo.MessageInfoProtocolBuffer.MessageInfo4FriendProto;
import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.repo.MessageInfosRepo;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class MessageInfo4Friend extends MessageInfo implements ProtobufSerializable{
	
	public static final int MSG_MAX_NUM = 200;
	
	public static final int AWARD_MAX_NUM = 20;
	
	public enum SendGiftType{
		SEND,// 好友赠送消息
		REBATE,//好友回赠消息
	}
	
	public enum SendGiftStatus{
		NO_DEAL,
		GIVED,
	}
	
	private long sendUserId;
	
	private String sendName;
	
	private int sendGiftType;
	
	private int msgStats;
	
	public MessageInfo4Friend(){}

	public MessageInfo4Friend(long userId, long sendUserId,MessageInfosRepo messageInfosRepo,
			List<Award> awards, MessageInfoType messageInfoTypepe, SendGiftType sendGiftType,
			String message, String sendName) {
		super(userId, messageInfosRepo, awards, messageInfoTypepe, message);
		this.sendUserId = sendUserId;
		this.sendGiftType = sendGiftType.ordinal();
		this.sendName = sendName;
	}
	

	public MessageInfo4Friend(MessageInfo4FriendProto mfp) {
		copyFrom(mfp);
	}

	public long getSendUserId() {
		return sendUserId;
	}

	public int getMsgStats() {
		return msgStats;
	}

	public void setMsgStats(int msgStats) {
		this.msgStats = msgStats;
	}

	public void setSendUserId(long sendUserId) {
		this.sendUserId = sendUserId;
	}

	public int getSendGiftType() {
		return sendGiftType;
	}

	public void setSendGiftType(int sendGiftType) {
		this.sendGiftType = sendGiftType;
	}
	
	@Override
	public void copyFrom(GeneratedMessage arg0) {
		MessageInfo4FriendProto message = (MessageInfo4FriendProto) arg0;
		this.id = message.getId();
		this.createTime = message.getCreateTime();
		if(message.getAwardsList() != null){
			for (AwardProto awp : message.getAwardsList()) {
				this.awards.add(new Award(awp));
			}
		}
		this.isRead = message.getIsRead();
		this.type = message.getType();
		this.sendGiftType = message.getSendGiftType();
		this.sendUserId = message.getSendUserId();
		this.msgStats = message.getMsgStats();
		this.userId = message.getUserId();
		this.sendName = message.getSendName();
	}

	@Override
	public MessageInfo4FriendProto copyTo() {
		MessageInfo4FriendProto.Builder builder = MessageInfo4FriendProto.newBuilder();
		builder.setId(id);
		builder.setCreateTime(createTime);
		builder.setIsRead(isRead);
		if(awards != null){
			for (Award aw : awards) {
				builder.addAwards(aw.copyTo());
			}
		}
		builder.setType(type);
		builder.setSendGiftType(sendGiftType);
		builder.setSendUserId(sendUserId);
		builder.setMsgStats(msgStats);
		builder.setUserId(userId);
		builder.setSendName(sendName);
		return builder.build();
	}

	@Override
	public void parseFrom(byte[] arg0) {
		try {
			MessageInfo4FriendProto message = MessageInfo4FriendProto.parseFrom(arg0);
			copyFrom(message);
		} catch (InvalidProtocolBufferException e) {
			throw new BusinessException(ErrorCode.CAN_NOT_MEM);
		}
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	public String getSendName() {
		return sendName;
	}

	public void setSendName(String sendName) {
		this.sendName = sendName;
	}
	
	
}

