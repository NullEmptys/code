package com.hoolai.sangoh5.bo.slave;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.repo.IndustryRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.service.TrackDomainService;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Slaves {

    private transient long userId;

    private transient List<Slave> slaves = new ArrayList<Slave>();

    private transient int extraAddNum;

    private IndustryRepo industryRepo;

    private ConstantsPoolData constantsPoolData;

    private TrackDomainService trackDomainService;

    private UserRepo userRepo;

    public Slaves() {

    }

    public Slaves(long userId) {
        this.userId = userId;
    }

    //TODO 纠结，NPC奴隶在这刷新吗？如果在这刷新，势必要牵扯农田矿洞的收入问题。
    // 不刷新失效的奴隶占用了奴隶数量，造成君主抓不住奴隶了
    // 还是不刷新了，让农田矿洞自己去结算比较方便合理
    public void reflesh() {
        for (Slave slave : slaves) {
            if (slave.getIsNPC()) {

            }
        }
    }

    public int[] findSlave() {
        int[] npcSalves = new int[3];
        for (Slave slave : slaves) {
            if (slave.getIsNPC()) {
                npcSalves[slave.getSlaveUser().getSex()] += 1;
            }
        }
        npcSalves[2] = slaves.size();
        return npcSalves;
    }

    public Slave addNPCSlave(int slaveXmlId, User cityOwnerUser) {
        Slave slave = new Slave(userId, cityOwnerUser);
        slave.setSlaveXmlId(slaveXmlId);
        industryRepo.saveSlave(slave);
        return slave;
    }

    public Slave addSlave(User cityOwnerUser) {
        if (industryRepo.findSlavesCount(userId) >= constantsPoolData.getProperty(32).getValue()) {
            return null;
        }
        for (Slave slave : slaves) {
            if (slave.getSlaveId() == cityOwnerUser.getId()) {
                if (slave.getStation() == Slave.station_farm_none || slave.getStation() == Slave.station_mine_none) {
                    slave.setSlaveId(Slave.station_free);
                }
                return slave;
            }
        }
        Slave slave = new Slave(userId, cityOwnerUser);
        industryRepo.saveSlave(slave);
        return slave;
    }

    public Slave findSlave(long slaveId) {
        if (slaves == null || slaves.size() < 1) {
            return null;
        }
        for (Slave slave : slaves) {
            if (slave.getSlaveId() == slaveId) {
                return slave;
            }
        }
        return null;
    }

    public long getUserId() {
        return userId;
    }

    public List<Slave> getSlaves() {
        return slaves;
    }

    public void setSlaves(List<Slave> slaves) {
        this.slaves = slaves;
    }

    public void setIndustryRepo(IndustryRepo industryRepo) {
        this.industryRepo = industryRepo;
    }

    public void cityFight(Slave slave) {
        if (slave == null) {
            return;
        }
        industryRepo.lockSlave(userId, slave.getId());
        try {

            slave = industryRepo.findSlave(userId, slave.getId());
            if (slave.getStation() == Slave.station_free) {
                industryRepo.removeSlave(userId, slave.getId());
                trackDomainService.trackRemoveSlave(userRepo.findUser(userId), slave.getId());
            } else if (slave.getStation() == Slave.station_farm) {
                slave.setStation(Slave.station_farm_none);
                industryRepo.saveSlave(slave);
            } else if (slave.getStation() == Slave.station_mine) {
                slave.setStation(Slave.station_mine_none);
                industryRepo.saveSlave(slave);
            }
        } finally {
            industryRepo.unLockSlave(userId, slave.getId());
        }
    }

    public void fillExtraAddNum(int extraAddNum) {
        this.extraAddNum = extraAddNum;
    }

    public void checkSlavesNum(int num) {
        if (industryRepo.findSlavesCount(userId) + num > constantsPoolData.getProperty(32).getValue() + extraAddNum) {
            throw new BusinessException(ErrorCode.SLAVE_OVER);
        }
    }

    public void setConstantsPoolData(ConstantsPoolData constantsPoolData) {
        this.constantsPoolData = constantsPoolData;
    }

    public void setTrackDomainService(TrackDomainService trackDomainService) {
        this.trackDomainService = trackDomainService;
    }

    public void setUserRepo(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

}
