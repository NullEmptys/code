package com.hoolai.sangoh5.bo.item;

import java.util.Set;

import com.google.common.collect.Sets;

/**
 * 道具常量 命名如：墨家全书 ITEM_MO_JIA_QUAN_SHU 类型_名称
 * 
 * @author Administrator
 *
 */
public class Item {

    /*************************** ITEM ***************************/
    public static final int ITEM_MO_JIA_CAN_YE = 101;//墨家残页

    public static final int ITEM_MO_JIA_CAN_JUAN = 102;//墨家残卷

    public static final int ITEM_MO_JIA_MI_JI = 103;//墨家秘籍

    public static final int ITEM_MO_JIA_QUAN_SHU = 104;//墨家全书

    public static final int ITEM_MO_JIA_ZHEN_JI = 105;//墨家真迹

    public static final int ITEM_LING_PAI = 106;//令牌

    public static final int ITEM_JING_XI_JIN_BI = 107;

    public static final int ITEM_FANG_CHAN_ZHENG = 108;

    public static final int ITEM_SHUI_DIAN_FEI = 109;

    public static final int ITEM_WU_YE_FEI = 110;

    public static final int ITEM_ZHAO_XIANG_LING = 111;//招降令

    public static final int ITEM_SHI_MU_YAO_SHI = 112;//实木钥匙

    public static final int ITEM_QING_TONG_YAO_SHI = 113;//青铜钥匙

    public static final int ITEM_BAI_YIN_YAO_SHI = 114;//白银钥匙

    public static final int ITEM_HUANG_JIN_YAO_SHI = 119;//黄金钥匙

    public static final int ITEM_ZUAN_SHI_YAO_SHI = 120;//钻石钥匙

    public static final int ITEM_JUAN_XIAN_1 = 115;//捐献道具1

    public static final int ITEM_JUAN_XIAN_2 = 116;//捐献道具2

    public static final int ITEM_JUAN_XIAN_3 = 117;//捐献道具3

    public static final int ITEM_JUAN_XIAN_4 = 118;//捐献道具4

    public static final int ITEM_TONG_JIAO_MU_NIU_LIU_MA = 122;

    public static final int ITEM_YIN_JIAO_MU_NIU_LIU_MA = 123;

    public static final int ITEM_JIN_JIAO_MU_NIU_LIU_MA = 124;

    public static final int ITEM_ZHAN_CHENG_KA = 125;

    public static final int ITEM_SHI_MU_BOX = 3001;//实木宝箱

    public static final int ITEM_QING_TONG_BOX = 3002;//青铜宝箱

    public static final int ITEM_BAI_YIN_BOX = 3003;//白银宝箱

    public static final int ITEM_HUANG_JIN_BOX = 3004;//黄金宝箱

    public static final int ITEM_ZUAN_SHI_BOX = 3005;//钻石宝箱

    public static final int ITEM_BING_KA = 121;//兵卡

    public static final int ITEM_SHENG_XING_DAN = 130;//升星丹

    public static final int ITEM_WU_JIANG_JING_YAN_DAN_1 = 131;//武将经验丹100

    public static final int ITEM_WU_JIANG_JING_YAN_DAN_2 = 132;//武将经验丹500

    public static final int ITEM_WU_JIANG_JING_YAN_DAN_3 = 133;//武将经验丹2000

    public static final int ITEM_CHANGE_SKILL = 134;//更换卸载技能消耗的道具

    public static final int ITEM_LA_BA = 135;//世界聊天中必须的道具

    /*************************** SKILL ***************************/
    public static final int SKILL_XIAO_YONG_SHAN_ZHAN = 20001;

    public static final int SKILL_JIAN_RUO_PAN_SHI = 20002;

    public static final int SKILL_TI_PO_QIANG_JIAN = 20003;

    public static final int SKILL_ZHUAN_GONG_RUO_DIAN = 20004;

    public static final int SKILL_WU_XIE_KE_JI = 20005;

    public static final int SKILL_DU = 20006;

    public static final int SKILL_LIU_XUE = 20007;

    public static final int SKILL_TU_ZI_WAI_TAO = 20008;

    public static final int SKILL_SA_ER_DIAN = 20009;

    public static final int SKILL_YING_MO_JIAN_JIA = 20010;

    public static final int SKILL_XUAN_YUN = 20011;

    public static final int SKILL_ZHOU_SI_LEI_DIAN = 20012;

    public static final int SKILL_BAO_JI = 20013;

    public static final int SKILL_CHEN_MO = 20014;

    public static final int SKILL_FAN_JI = 20015;

    public static final int SKILL_LIE_YAN = 20016;

    public static final int SKILL_JIU_ZHI = 20017;

    public static final int SKILL_FENG_BAO = 20018;

    public static final int[] KEYGROUP = { ITEM_SHI_MU_YAO_SHI, ITEM_QING_TONG_YAO_SHI, ITEM_BAI_YIN_YAO_SHI, ITEM_HUANG_JIN_YAO_SHI, ITEM_ZUAN_SHI_YAO_SHI };

    public static final int[] DONATIONITEM = { ITEM_JUAN_XIAN_1, ITEM_JUAN_XIAN_2, ITEM_JUAN_XIAN_3, ITEM_JUAN_XIAN_4 };

    public static final int COMMON_SKILL_GIFT = 142;

    public static final int SENIOR_SKILL_GIFT = 143;

    public static final int MATERIAL_GIFT_FIRST = 144;

    public static final int MATERIAL_GIFT_SECOND = 145;

    public static final int MATERIAL_GIFT_THIRD = 146;

    public static final int SOLDIER_GIFT = 147;

    public static final Set<Integer> USER_ITEMS = Sets.newHashSet(ITEM_JING_XI_JIN_BI, ITEM_FANG_CHAN_ZHENG, ITEM_SHUI_DIAN_FEI, ITEM_WU_YE_FEI, COMMON_SKILL_GIFT,
            SENIOR_SKILL_GIFT, MATERIAL_GIFT_FIRST, MATERIAL_GIFT_SECOND, MATERIAL_GIFT_THIRD, SOLDIER_GIFT);

    public static final Set<Integer> USER_ITEMS_FOR_GOLD = Sets.newHashSet(ITEM_JING_XI_JIN_BI, ITEM_FANG_CHAN_ZHENG, ITEM_SHUI_DIAN_FEI, ITEM_WU_YE_FEI);
}
