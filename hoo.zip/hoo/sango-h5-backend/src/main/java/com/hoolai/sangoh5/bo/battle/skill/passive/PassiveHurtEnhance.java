package com.hoolai.sangoh5.bo.battle.skill.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.effect.PassiveHurtEnhanceEffect;
import com.hoolai.sangoh5.bo.battle.skill.ForceType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class PassiveHurtEnhance extends AttributeEnhanceSkill {

    /*
     * 所有单位在背后攻击其他目标时增加10%的伤害
     */

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {

        List<FightUnit> targets = aliveTargetUnitList(tc, actor);

        for (FightUnit target : targets) {
            PassiveHurtEnhanceEffect enhanceEffect = null;
            if (forceType == ForceType.FRIEND) {
                enhanceEffect = new PassiveHurtEnhanceEffect(target, this, tc);
            } else {
                enhanceEffect = new PassiveHurtEnhanceEffect(actor, this, tc);
            }
            target.addEnhanceEffect(enhanceEffect);
        }

        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]加成比率：" + percentage + ",加成值:" + value);
        actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Effect.DEFAULT_BUFF_LEVEL).withActorName(actor.name()).withTargetName(actor.name()));
    }

    @Override
    public Skill clone() {
        return super.clone(new PassiveHurtEnhance());
    }

}
