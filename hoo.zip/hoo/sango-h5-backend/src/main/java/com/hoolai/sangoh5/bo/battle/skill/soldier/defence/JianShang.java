package com.hoolai.sangoh5.bo.battle.skill.soldier.defence;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class JianShang extends DefenceSkill {

    @Override
    public void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {

        effect.setDeltaHp(Math.round(effect.getDeltaHp() * (1 - percentage)));

        target.addBuff(new Buff(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name()));
    }

    @Override
    public Skill clone() {
        return super.clone(new JianShang());
    }

}
