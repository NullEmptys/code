package com.hoolai.sangoh5.bo.battle.skill.passive;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.YouLieZhuanHuanBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class YouLieZhuanHuan extends AttributeEnhanceSkill {

    /*
     * 我方士兵在攻击目标时，若士兵少于对方，则防御力提升10%,高于对方时，攻击增加5%
     */

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {

        Buff obuff = new YouLieZhuanHuanBuff(xmlId, actor.name(), actor, this, Effect.MONITORING_BUFF_LEVEL, aliveTargetUnitList(tc, actor)).withKeepBuff()
                .withRepeatCount(MaxRepeatCount).withActorName(actor.name()).withTargetName(actor.name());
        actor.addAfterActionBuff(obuff);
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]");
    }

    @Override
    public Skill clone() {
        return super.clone(new YouLieZhuanHuan());
    }

}
