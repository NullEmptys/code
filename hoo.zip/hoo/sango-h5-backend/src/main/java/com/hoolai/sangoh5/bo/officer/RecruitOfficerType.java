package com.hoolai.sangoh5.bo.officer;

import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public enum RecruitOfficerType {

    USE_TOKEN_FREE(1) {

        @Override
        public void checkNum(int num) {
            if (num != 1) {
                throw new BusinessException(ErrorCode.ERROR_PARAM_VALUE);
            }
        }

        @Override
        public boolean isFree() {
            return true;
        }
    },
    USE_YB_FREE(2) {

        @Override
        public void checkNum(int num) {
            if (num != 1) {
                throw new BusinessException(ErrorCode.ERROR_PARAM_VALUE);
            }
        }

        @Override
        public boolean isFree() {
            return true;
        }
    },
    USE_TOKEN(3) {

        @Override
        public void checkNum(int num) {
            if (num != 1 && num != 10) {
                throw new BusinessException(ErrorCode.ERROR_PARAM_VALUE);
            }
        }

        @Override
        public boolean isFree() {
            return false;
        }
    },
    USE_YB(4) {

        @Override
        public void checkNum(int num) {
            if (num != 1 && num != 10) {
                throw new BusinessException(ErrorCode.ERROR_PARAM_VALUE);
            }
        }

        @Override
        public boolean isFree() {
            return false;
        }
    };

    private final int type;

    public abstract void checkNum(int num);

    public abstract boolean isFree();

    private RecruitOfficerType(int type) {
        this.type = type;
    }

    public int value() {
        return type;
    }

    public static RecruitOfficerType valueOf(int value) {
        switch (value) {
            case 1:
                return USE_TOKEN_FREE;
            case 2:
                return USE_YB_FREE;
            case 3:
                return USE_TOKEN;
            case 4:
                return USE_YB;
            default:
                throw new IllegalArgumentException("there is no RecruitOfficerType enum element`s value is " + value);
        }
    }
}
