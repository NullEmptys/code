package com.hoolai.sangoh5.bo.mission;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.MissionProtocolBuffer.UserMissionProto;
import com.hoolai.sangoh5.bo.rescue.Utils;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 玩家任务数据
 * 
 * @author hp
 *
 */
public class Mission implements ProtobufSerializable<UserMissionProto> {

	private long userId;
	/** 任务定义id */
	private int missionDefineId;
	/** 任务定义categoryId */
	private int categoryId;
	/** 任务定义的属性id */
	private int propertyId;
	/** 任务完成记录统计 */
	private int missionDetail;
	/** 状态 */
	private int status;
	/** 开始时间 */
	private String startTime;
	/**
	 * 结合状态status表示 
	 * 完成未领奖表示：完成推送的时间(客户端)
	 * 已领取奖励:领取奖励(任务结束)的时间
	 */
	private String endTime;
	/** 完成时间 */
	private String finishTime;

	public Mission(byte[] bytes) {
		parseFrom(bytes);
	}

	public Mission(UserMissionProto message) {
		this.status = MissionStatus.STATUS_READY.getId();
		copyFrom(message);
	}

	public Mission() {
		this.status = MissionStatus.STATUS_STARTED.getId();
	}
	
	public Mission(int missionDetail2, int defineMissionId, String formatTime,
			long id, int category, int property) {
		initStartMission(missionDetail2, defineMissionId, formatTime, id, category, property);
	}
	
	private void initStartMission(int missionDetail2, int defineMissionId, String formatTime,
			long id, int category, int property){
		this.status = MissionStatus.STATUS_STARTED.getId();
		this.missionDetail = missionDetail2;
		this.missionDefineId = defineMissionId;
		this.startTime = formatTime;
		this.userId = id;
		this.categoryId = category;
		this.propertyId = property;
		this.endTime = "";
		this.finishTime = "";
	}
	
	public void finish(){
		this.status = MissionStatus.STATUS_FINISHED.getId();
        this.finishTime = Utils.formatTime(TimeUtil.currentTimeMillis(), Utils.DATATIMEF_STR);
        this.endTime = Utils.formatTime(TimeUtil.currentTimeMillis(), Utils.DATATIMEF_STR);
	}

	@JsonIgnore
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public int getMissionDefineId() {
		return missionDefineId;
	}

	public void setMissionDefineId(int missionDefineId) {
		this.missionDefineId = missionDefineId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	@JsonIgnore
	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

	public int getMissionDetail() {
		return missionDetail;
	}

	public void setMissionDetail(int missionDetail) {
		this.missionDetail = missionDetail;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	@JsonIgnore
	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	@JsonIgnore
	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	@JsonIgnore
	public String getFinishTime() {
		return finishTime;
	}

	public void setFinishTime(String finishTime) {
		this.finishTime = finishTime;
	}

	@Override
	public UserMissionProto copyTo() {
		UserMissionProto.Builder builder = UserMissionProto.newBuilder();
		builder.setUserId(userId);
		builder.setMissionDefineId(missionDefineId);
		builder.setCategoryId(categoryId);
		builder.setPropertyId(propertyId);
		builder.setMissionDetail(missionDetail);
		builder.setStatus(status);
		builder.setStartTime(startTime);
		builder.setEndTime(endTime);
		builder.setFinishTime(finishTime);
		return builder.build();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			UserMissionProto message = UserMissionProto.parseFrom(bytes);
			copyFrom(message);
		} catch (InvalidProtocolBufferException e) {
			throw new BusinessException(ErrorCode.CAN_NOT_MEM);
		}

	}

	@Override
	public void copyFrom(UserMissionProto message) {
		this.userId = message.getUserId();
		this.missionDefineId = message.getMissionDefineId();
		this.categoryId = message.getCategoryId();
		this.propertyId = message.getPropertyId();
		this.missionDetail = message.getMissionDetail();
		this.status = message.getStatus();
		this.startTime = message.getStartTime();
		this.endTime = message.getEndTime();
		this.finishTime = message.getFinishTime();
	}

}
