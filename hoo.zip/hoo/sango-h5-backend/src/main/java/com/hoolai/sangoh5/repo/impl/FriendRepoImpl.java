package com.hoolai.sangoh5.repo.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.platform.PlatformType;
import com.hoolai.sangoh5.bo.friend.Friend;
import com.hoolai.sangoh5.bo.platform.MobilePlatform;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.repo.FriendRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.repo.impl.key.FriendKey;
import com.hoolai.sangoh5.repo.impl.key.UserKey;

@Repository("friendRepo")
public class FriendRepoImpl implements FriendRepo {

    @Autowired
    @Qualifier("userClient")
    private ExtendedMemcachedClient client;

    @Autowired
    private UserRepo userRepo;

    @Override
    public List<Friend> getUserFriends(long userId, int platformType) {
        List<Long> userFriendIds = getUserFriendIds(userId, platformType);
        List<Long> notExistFriendIds = findNotExistFriendIds(userFriendIds);
        removeNotExistFriendIds(userId, platformType, userFriendIds, notExistFriendIds);
        List<Friend> friends = new ArrayList<Friend>();
        //        friends.add(NpcData.cloneUser().transferToFriend());
        if (userFriendIds == null || userFriendIds.isEmpty()) {
            return friends;
        }

        //        List<Long> pageUserIds = userFriendIds.subList((page-1)*pageCount, page*pageCount);
        friends.addAll(this.findFriendsByUserIds(userFriendIds));
        return friends;
    }

    private List<Long> findNotExistFriendIds(List<Long> userFriendIds) {
        List<Long> notExistFriendIds = new ArrayList<Long>();
        for (long friendId : userFriendIds) {
            //friendId != NpcData.NPC_USER_ID &&
            if (!client.keyExists(UserKey.getUserKey(friendId))) {
                notExistFriendIds.add(friendId);
            }
        }
        return notExistFriendIds;
    }

    private void removeNotExistFriendIds(long userId, int platformType, List<Long> userFriendIds, Collection<Long> notExistFriendIds) {
        if (userFriendIds.removeAll(notExistFriendIds)) {
            String userFriendIdsKey = FriendKey.getUserFriendIdsKey(userId, platformType);
            client.srem(userFriendIdsKey, notExistFriendIds);
        }
    }

    @Override
    public boolean isFriend(long userId, long friendUserId, int platformType) {
        List<Long> userfriendIds = this.getUserFriendIds(userId, platformType);
        if (userfriendIds == null) {
            return false;
        }
        return userfriendIds.contains(friendUserId);
    }

    @Override
    public Friend findFriendByUserId(long userId) {
        User user = userRepo.findUser(userId);
        return user.transferToPlatformFriend();
    }

    @Override
    public void addFriend(long userId, String friendPlatformId, int platformType) {
        if (!userRepo.isUserExist(friendPlatformId)) {
            return;
        }
        long friendUserId = userRepo.findUserId(friendPlatformId);
        String currentUserFriendIdsKey = FriendKey.getUserFriendIdsKey(userId, platformType);
        client.sadd(currentUserFriendIdsKey, friendUserId);

        String friendUserFriendIdsKey = FriendKey.getUserFriendIdsKey(friendUserId, platformType);
        client.sadd(friendUserFriendIdsKey, userId);
    }

    @Override
    public List<Friend> findFriendsByUserIds(List<Long> userIds) {
        Map<Long, User> userMap = userRepo.findUsers(userIds);
        Collection<User> values = userMap.values();
        List<Friend> friends = new ArrayList<Friend>();
        for (User user : values) {
            Friend friend = user.transferToPlatformFriend();
            friends.add(friend);
        }
        return friends;
    }

    @Override
    public int findFriendsCount(long userId, int platformType) {
        String key = FriendKey.getUserFriendIdsKey(userId, platformType);
        return (int) client.scard(key);
    }

    @Override
    public List<Long> getUserFriendIds(long userId, int platformType) {
        String userFriendIdsKey = FriendKey.getUserFriendIdsKey(userId, platformType);
        return client.smembers(userFriendIdsKey, Long.class);
    }

    @Override
    public void resetFriends(long userId, List<String> friendPlatformIds, int platformType) {
        String key = FriendKey.getUserFriendIdsKey(userId, platformType);
        // 好友为空，则清空好友列表
        if (friendPlatformIds == null || friendPlatformIds.isEmpty()) {
            client.delete(key);
            return;
        }

        String openid = userRepo.getPlatformId(userId);
        friendPlatformIds = addPlatformSuffix(openid, friendPlatformIds);
        client.delete(key);

        Map<String, Object> multiUserId = userRepo.findUsersByPlat(friendPlatformIds);
        client.sadd(key, multiUserId.values());

        int currentFriendsCount = multiUserId.size();
        if (platformType == PlatformType.KAIXIN.code) {
            resetFriendsMaxCount(userId, currentFriendsCount);
        } else {
            int currentMaxCount = findFriendsMaxCount(userId);
            if (currentFriendsCount > currentMaxCount) {
                resetFriendsMaxCount(userId, currentFriendsCount);
            }
        }
    }

    private List<String> addPlatformSuffix(String openid, List<String> friendPlatformIds) {
        MobilePlatform mobilePlatform = MobilePlatform.valueOf(User.platformSuffix(openid));
        List<String> platformSuffixFriendOpenIds = new ArrayList<String>(friendPlatformIds.size());
        for (String friendOpenid : friendPlatformIds) {
            platformSuffixFriendOpenIds.add(mobilePlatform.gameOpenid(friendOpenid));
        }
        return platformSuffixFriendOpenIds;
    }

    @Override
    public int findFriendsMaxCount(long userId) {
        String key = FriendKey.getUserFriendsMaxCountKey(userId);
        Object object = client.get(key);
        int maxCount = 0;
        if (object == null) {
            maxCount = findFriendsCount(userId, 0); // 朋友默认是0
            client.set(key, maxCount);
        } else {
            maxCount = (Integer) object;
        }

        return maxCount;
    }

    @Override
    public void resetFriendsMaxCount(long userId, int count) {
        String key = FriendKey.getUserFriendsMaxCountKey(userId);
        client.set(key, count);
    }

    @Override
    public List<Friend> getFriendsExcludeUserIds(long userId, List<Long> friendIds, int platformType) {
        List<Long> userFriendIds = getUserFriendIds(userId, platformType);
        List<Long> notExistFriendIds = findNotExistFriendIds(userFriendIds);
        removeNotExistFriendIds(userId, platformType, userFriendIds, notExistFriendIds);

        if (friendIds != null && friendIds.size() > 0) {
            userFriendIds.removeAll(friendIds);
        }

        if (userFriendIds.size() < 1) {
            return null;
        }

        return this.findFriendsByUserIds(userFriendIds);
    }

    @Override
    public List<Friend> getGameFriendsExcludeUserIds(long userId, List<Long> friendIds) {
        List<Long> userFriendIds = getGameFriendIds(userId);
        List<Long> notExistFriendIds = findNotExistFriendIds(userFriendIds);
        if (userFriendIds.removeAll(notExistFriendIds)) {
            String userFriendIdsKey = FriendKey.getGameFriendIdsKey(userId);
            client.srem(userFriendIdsKey, notExistFriendIds);
        }

        if (friendIds != null && friendIds.size() > 0) {
            userFriendIds.removeAll(friendIds);
        }

        if (userFriendIds.size() < 1) {
            return null;
        }

        return this.findFriendsByUserIds(userFriendIds);
    }

    @Override
    public List<Friend> getGameFriends(long userId) {
        List<Long> userFriendIds = getGameFriendIds(userId);
        List<Long> notExistFriendIds = findNotExistFriendIds(userFriendIds);

        if (userFriendIds.removeAll(notExistFriendIds)) {
            String userFriendIdsKey = FriendKey.getGameFriendIdsKey(userId);
            client.srem(userFriendIdsKey, notExistFriendIds);
        }

        if (userFriendIds == null || userFriendIds.isEmpty()) {
            return new ArrayList<Friend>();
        }
        return this.findFriendsByUserIds(userFriendIds);
    }

    @Override
    public List<Long> getGameFriendIds(long userId) {
        String userFriendIdsKey = FriendKey.getGameFriendIdsKey(userId);
        return client.smembers(userFriendIdsKey, Long.class);
    }

    @Override
    public boolean isGameFriend(long userId, long friendUserId) {
        List<Long> userfriendIds = this.getGameFriendIds(userId);
        if (userfriendIds == null) {
            return false;
        }
        return userfriendIds.contains(friendUserId);
    }

    @Override
    public int findGameFriendsCount(long userId) {
        String key = FriendKey.getGameFriendIdsKey(userId);
        return (int) client.scard(key);
    }

    @Override
    public void addGameFriend(long userId, long friendId) {
        String currentUserFriendIdsKey = FriendKey.getGameFriendIdsKey(userId);
        client.sadd(currentUserFriendIdsKey, friendId);

        String friendUserFriendIdsKey = FriendKey.getGameFriendIdsKey(friendId);
        client.sadd(friendUserFriendIdsKey, userId);
    }

    @Override
    public void removeGameFriend(long userId, long[] fids) {
        for (long fid : fids) {
            client.srem(FriendKey.getGameFriendIdsKey(userId), fid);
            client.srem(FriendKey.getGameFriendIdsKey(fid), userId);
        }
    }

    @Override
    public List<Long> getApplyFriendIds(long userId) {
        String applyFriendsKey = FriendKey.getApplyFriendsKey(userId);
        return client.smembers(applyFriendsKey, Long.class);
    }

    @Override
    public List<Friend> findApplyFriends(long userId) {
        List<Long> userFriendIds = getApplyFriendIds(userId);
        if (userFriendIds == null || userFriendIds.isEmpty()) {
            return new ArrayList<Friend>();
        }
        return this.findFriendsByUserIds(userFriendIds);
    }

    @Override
    public void addApplyFriend(long userId, long appFid) {
        String key = FriendKey.getApplyFriendsKey(userId);
        client.sadd(key, appFid);
    }

    @Override
    public void removeApplyFriend(long userId, long[] fids) {
        for (long fid : fids) {
            client.srem(FriendKey.getApplyFriendsKey(userId), fid);
        }
    }

    @Override
    public boolean isApplied(long userId, long friendId) {
        List<Long> applyFriendIds = this.getApplyFriendIds(userId);
        if (applyFriendIds == null) {
            return false;
        }
        return applyFriendIds.contains(friendId);
    }

    @Override
    public void removeAllApplyFriend(long userId) {
        client.set(FriendKey.getApplyFriendsKey(userId), "");
    }

    @Override
    public List<Friend> findRecommendFriends(long userId, int range, int count) {
        User user = userRepo.findUser(userId);
        int level = user.getRank();
        range = range + level;
        List<Long> friends = new ArrayList<Long>();
        while (range >= level) {
            List<Long> fids = userRepo.randomRankUser(range, count * 2, userId);
            for (long friendId : fids) {
                if (friends.size() >= count) {
                    return this.findFriendsByUserIds(friends);
                }
                if (isFriend(userId, friendId, Friend.FRINED_PLATFORM_TYPE) || isGameFriend(userId, friendId) || !userRepo.findUser(friendId).isNeedTrack()) {
                  continue;
                }
                friends.add(friendId);
            }
            range--;
        }
        return this.findFriendsByUserIds(friends);
    }

    @Override
    public List<Long> getSendFriendIds(long userId) {
        String key = FriendKey.getSendFriendsKey(userId);
        return client.smembers(key, Long.class);
    }

    @Override
    public void addSendFriend(long userId, List<Object> sendFid) {
        String key = FriendKey.getSendFriendsKey(userId);
        client.sadd(key, sendFid);
    }

    @Override
    public void clearSendFriends(long userId) {
        client.set(FriendKey.getSendFriendsKey(userId), "");
    }

    @Override
    public int findApplyFriendsCount(long userId) {
        String key = FriendKey.getApplyFriendsKey(userId);
        return (int) client.scard(key);
    }

    @Override
    public void removeAllGameFriend(long userId) {
        client.set(FriendKey.getGameFriendIdsKey(userId), "");
    }
}
