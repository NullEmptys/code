package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

/**
 * 悬赏memcache key
 * 
 * @author Administrator
 *
 */
public class RescueKey {
	public static final String prefix = "rescue";

	public static String getRescueCountKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
				.append("ch").toString();
	}

	public static String getRescueFailCountKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
				.append("occupy").toString();
	}

	public static String getExtraCountKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
				.append("buy").toString();
	}
	
	public static String upBuyLimit(long userId){
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
				.append("buyLimit").toString();
	}
	
	public static String advanceChallenageLimit(long userId){
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
				.append("challenageLimit").toString();
	}
	
	public static String getRescueLimitationKey(long userId){
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("limitation").toString();
	}

}
