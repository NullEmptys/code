package com.hoolai.sangoh5.bo.battle.enhance;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.GeneratedMessage;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.EffectProto;
import com.hoolai.sangoh5.bo.battle.skill.ForceUnitType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

@SuppressWarnings("rawtypes")
public class Effect implements ProtobufSerializable {

    protected static final Log logger = LogFactory.getLog("battle");

    public static final int NONE_USED_SKILL_ID = 0;

    /**
     * 第二层动作
     */
    public static int NEXT_BUFF_LEVEL = 2;

    /**
     * 默认执行一个动作
     */
    public static int DEFAULT_BUFF_LEVEL = 1;

    /**
     * 监控buff，不做任何效果，计时用
     */
    public static int MONITORING_BUFF_LEVEL = 0;

    /**
     * 改变的血量
     */
    protected int deltaHp;

    /**
     * 承受buff的单位名称
     */
    protected FightUnitName targetName;

    /**
     * buff的释放单位名称
     */
    protected FightUnitName actorName;

    /**
     * 这个伤害由谁执行,一般来说是actor.但是像附加在target身上的buff,比如持续伤害等,需要target自行执行
     */
    protected transient FightUnitName executeName;

    /**
     * 执行这个伤害以后target是否死亡
     */
    protected boolean isTargetDie;

    protected int targetUsedSkillXmlId = NONE_USED_SKILL_ID;//default 0 == target not used skill

    protected String skillName = "";

    /**
     * 当前属于一回合中的第一个动作
     */
    protected int currentLevel = DEFAULT_BUFF_LEVEL;

    /**
     * 是不是反伤
     */
    protected boolean isSelfHurt;

    /**
     * 是否是基本伤害
     */
    protected boolean isBaseHurt = false;

    /**
     * 造成伤害的百分比（某些特殊的技能使用，大部分技能只关心伤害值）
     */
    protected float hurtPercentage;

    /**
     * 是否已target为中心释放技能效果
     */
    protected boolean isTargetMiddle;

    /**
     * 是否是技能攻击
     * 
     * @return
     */
    public boolean isUsedSkill() {
        return targetUsedSkillXmlId > 0;
    }

    /**
     * 是否是来自士兵的攻击
     * 
     * @return
     */
    public boolean isSoldierHurt() {
        return actorName != null && actorName.info().isSoldier();
    }

    /**
     * 只做转json使用，平时必须Effect(int targetUsedSkillXmlId,FightUnitName
     * executeName)
     */
    public Effect() {

    }

    public Effect(int targetUsedSkillXmlId, String skillName, FightUnitName executeName, int executeLevel) {
        this.targetUsedSkillXmlId = targetUsedSkillXmlId;
        this.executeName = executeName;
        this.currentLevel = executeLevel;
        this.skillName = skillName;
    }

    public Effect(EffectProto message) {
        copyFrom(message);
    }

    /**
     * 是否基本伤害
     * 
     * @param isBaseHurt
     * @return
     */
    public Effect withIsBaseHurt(boolean isBaseHurt) {
        this.isBaseHurt = isBaseHurt;
        return this;
    }

    /**
     * 设置伤害值
     * 
     * @param hpHurt
     * @return
     */
    public Effect withDeltaHp(int hpHurt) {
        this.deltaHp = hpHurt;
        return this;
    }

    /**
     * 设置目标名称
     * 
     * @param targetName
     * @return
     */
    public Effect withTargetName(FightUnitName targetName) {
        this.targetName = targetName;
        return this;
    }

    /**
     * 设置伤害触发者actor的名称
     * 
     * @param actorName
     * @return
     */
    public Effect withActorName(FightUnitName actorName) {
        this.actorName = actorName;
        return this;
    }

    public Effect withHurtPercentage(float hurtPercentage) {
        this.hurtPercentage = hurtPercentage;
        return this;
    }

    public FightUnitName actorName() {
        return actorName;
    }

    public FightUnitName targetName() {
        return targetName;
    }

    /**
     * 特殊情况下效果作用之后会有加成
     * 
     * @param addedDeltaHp
     */
    public void addDeltaHp(int addedDeltaHp) {
        this.deltaHp += addedDeltaHp;
    }

    public Effect targetDie(boolean isTargetDie) {
        this.isTargetDie = isTargetDie;
        return this;
    }

    public boolean isBaseHurt() {
        return isBaseHurt || this.targetUsedSkillXmlId == NONE_USED_SKILL_ID;
    }

    /**
     * 是否自伤
     * 
     * @return
     */
    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public boolean isSelfHurt() {
        return isSelfHurt;
    }

    /**
     * 自伤值
     * 
     * @param isSelfHurt
     * @return
     */
    public Effect withSelfHurt(boolean isSelfHurt) {
        this.isSelfHurt = isSelfHurt;
        return this;
    }

    public FightUnitName getExecuteName() {
        return executeName;
    }

    public int getCurrentLevel() {
        return currentLevel;
    }

    public int getDeltaHp() {
        return deltaHp;
    }

    public void setDeltaHp(int deltaHp) {
        this.deltaHp = deltaHp;
    }

    public FightUnitName getTargetName() {
        return targetName;
    }

    public FightUnitName getActorName() {
        return actorName;
    }

    public boolean getIsTargetDie() {
        return isTargetDie;
    }

    public int getTargetUsedSkillXmlId() {
        return targetUsedSkillXmlId;
    }

    public float getHurtPercentage() {
        return hurtPercentage;
    }

    public boolean isTargetMiddle() {
        return isTargetMiddle;
    }

    @Override
    public String toString() {
        return "Effect [deltaHp=" + deltaHp + ", targetName=" + targetName + ", actorName=" + actorName + ", executeName=" + executeName + ", isTargetDie=" + isTargetDie
                + ", targetUsedSkillXmlId=" + targetUsedSkillXmlId + ", currentLevel=" + currentLevel + ", isSelfHurt=" + isSelfHurt + ", isBaseHurt=" + isBaseHurt + "]";
    }

    @Override
    public void copyFrom(GeneratedMessage proto) {
        EffectProto message = (EffectProto) proto;
        this.deltaHp = message.getDeltaHp();
        this.targetName = FightUnitName.valueOf(message.getTargetName());
        this.isTargetDie = message.getIsTargetDie();
        this.targetUsedSkillXmlId = message.getTargetUsedSkillXmlId();//default 0 == target not used skill
        this.isSelfHurt = message.getIsSelfHurt();
        this.actorName = FightUnitName.valueOf(message.getActorName());
        this.hurtPercentage = message.getHurtPercentage();
        this.isTargetMiddle = message.getIsTargetMiddle();
    }

    @Override
    public GeneratedMessage copyTo() {
        EffectProto.Builder builder = EffectProto.newBuilder();
        builder.setDeltaHp(deltaHp);
        builder.setIsSelfHurt(isSelfHurt);
        builder.setIsTargetDie(isTargetDie);
        builder.setTargetName(targetName.name());
        builder.setTargetUsedSkillXmlId(targetUsedSkillXmlId);
        builder.setActorName(actorName.name());
        builder.setHurtPercentage(hurtPercentage);
        builder.setIsTargetMiddle(isTargetMiddle);
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] arg0) {
        try {
            EffectProto message = EffectProto.parseFrom(arg0);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    public void apply(FightUnit actor, FightUnit target, Skill skill) {
        this.deltaHp = Math.max(0, deltaHp);//造成伤害最少为1点, PS如果以后有加血技能另议
        target.changeHp(deltaHp);
        specailEffect(actor.getDefender(), skill);

        this.isTargetDie = target.isDead();
        target.addBattleLog(actorName + "执行" + targetUsedSkillXmlId + "[" + skillName + "]给" + targetName + "造成的伤害" + deltaHp + ",targetHp=" + target.getHp() + ",是否死亡："
                + isTargetDie);
    }

    public void specailEffect(FightUnit defencer, Skill skill) {
        if (defencer == null) return;
        if (!skill.isNotNeedRange() && skill.getForceUnitType() == ForceUnitType.TARGET && targetName.equals(defencer.name())) {
            this.isTargetMiddle = true;
        }
    }

}
