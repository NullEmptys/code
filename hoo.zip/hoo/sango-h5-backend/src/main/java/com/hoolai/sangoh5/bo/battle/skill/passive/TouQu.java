package com.hoolai.sangoh5.bo.battle.skill.passive;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.AbsorbTargetEnhanceBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 每次击中时，吸取对方攻击力,防御力，可叠加
 * 
 * @author Administrator
 *
 */
public class TouQu extends AttributeEnhanceSkill {

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {
        actor.addBuff(new AbsorbTargetEnhanceBuff(xmlId, Effect.MONITORING_BUFF_LEVEL, actor, this).withActorName(actor.name()).withTargetName(actor.name()).withKeepBuff()
                .withRepeatCount(MaxRepeatCount));
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]");
    }

    @Override
    public Skill clone() {
        return super.clone(new TouQu());
    }
}
