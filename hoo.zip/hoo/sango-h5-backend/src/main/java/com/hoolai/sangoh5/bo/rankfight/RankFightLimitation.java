package com.hoolai.sangoh5.bo.rankfight;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.RankFightLimitationProto;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class RankFightLimitation implements ProtobufSerializable<RankFightLimitationProto> {

    private final static int MAX_BUY_FIGHT_NUM = 20;

    private int fightNum;

    private int countBuyFightNum;

    private long lastUpdateDay;

    transient private boolean isChange;

    transient private ConstantsPoolData constantsPool;

    private long userId;

    public RankFightLimitation(long userId, ConstantsPoolData constantsPool) {
        this.userId = userId;
        this.fightNum = 0;
        this.lastUpdateDay = DateUtil.getTodayIntValue();
        this.constantsPool = constantsPool;
    }

    public RankFightLimitation(long userId, byte[] bytes, ConstantsPoolData constantsPool) {
        this.userId = userId;
        this.constantsPool = constantsPool;
        parseFrom(bytes);
    }

    public void refresh() {
        if (DateUtil.getTodayIntValue() > lastUpdateDay) {
            lastUpdateDay = DateUtil.getTodayIntValue();
            this.fightNum = 0;
            this.countBuyFightNum = 0;
            isChange = true;
        }
    }

    public void checkAndAddFightNum() {
        if (fightNum >= constantsPool.getProperty(3).getValue() + countBuyFightNum) {
            //            throw new BusinessException(ErrorCode.TODAY_REACH_MAX);
        }
        addFightNum();
    }

    private void addFightNum() {
        this.fightNum += 1;
    }

    public int getFightNum() {
        return fightNum;
    }

    public void setFightNum(int fightNum) {
        this.fightNum = fightNum;
    }

    public boolean isChange() {
        return isChange;
    }

    public long getUserId() {
        return userId;
    }

    public int getCountBuyFightNum() {
        return countBuyFightNum;
    }

    public void setCountBuyFightNum(int countBuyFightNum) {
        this.countBuyFightNum = countBuyFightNum;
    }

    @Override
    public RankFightLimitationProto copyTo() {
        RankFightLimitationProto.Builder builder = RankFightLimitationProto.newBuilder();
        builder.setFightNum(fightNum);
        builder.setLastUpdateDay(lastUpdateDay);
        builder.setUserId(userId);
        builder.setBuyFightNum(countBuyFightNum);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            RankFightLimitationProto message = RankFightLimitationProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(RankFightLimitationProto message) {
        this.fightNum = message.getFightNum();
        this.lastUpdateDay = message.getLastUpdateDay();
        this.userId = message.getUserId();
        this.countBuyFightNum = message.getBuyFightNum();
    }

    private void buyFightNum() {
        this.countBuyFightNum++;
    }

    public void checkCanBuyFightNum(int extraNum) {
        if (countBuyFightNum >= MAX_BUY_FIGHT_NUM + extraNum) {
            throw new BusinessException(ErrorCode.TODAY_REACH_MAX);
        }
        buyFightNum();
    }

    public int getResidueNum() {
        return constantsPool.getProperty(3).getValue() + countBuyFightNum - fightNum;
    }
}
