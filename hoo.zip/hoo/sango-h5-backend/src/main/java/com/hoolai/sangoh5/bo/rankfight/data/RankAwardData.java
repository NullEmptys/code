package com.hoolai.sangoh5.bo.rankfight.data;

import java.io.IOException;
import java.util.Iterator;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class RankAwardData extends JsonData<RankAwardProperty> {

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/rankAward.json", RankAwardProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void checkProperty(RankAwardProperty property) {
        if (property.getRewardId().length != property.getRewardType().length) {
            throw new com.hoolai.exception.BusinessException(ErrorCode.JSON_TABLE_ERROR.code, ErrorCode.JSON_TABLE_ERROR.msg + ", 表：rankAward.json" + ", id : " + property.getId());
        }
    }

    public RankAwardProperty getCurrentRankAwardData(int rank) {
        Iterator<RankAwardProperty> it = this.getPropertyMap().values().iterator();
        while (it.hasNext()) {
            RankAwardProperty rankPro = it.next();
            int[] levelCondition = rankPro.getLevel();
            if (rank >= levelCondition[0] && rank <= levelCondition[1]) {
                return rankPro;
            }
        }
        throw new BusinessException(ErrorCode.JSON_TABLE_ERROR);
    }

}
