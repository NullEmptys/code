package com.hoolai.sangoh5.bo.farmland.data;

import java.io.IOException;
import java.util.Iterator;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.farmland.data.FarmlandAndMineProperty.FarmlandAndMineType;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class FarmlandAndMineData extends JsonData<FarmlandAndMineProperty> {

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/landLv.json", FarmlandAndMineProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(FarmlandAndMineProperty farmlandAndMineProperty) {
        // TODO Auto-generated method stub

    }

    /**
     * 可升级至最大等级
     * 
     * @param type
     * @return
     */
    public int findFarmlandOrMineMaxLevel(FarmlandAndMineType type) {
        int size = 0;
        Iterator<FarmlandAndMineProperty> iterator = this.propertyMap.values().iterator();
        while (iterator.hasNext()) {
            FarmlandAndMineProperty property = iterator.next();
            if (property.getLandType() == type.value()) {
                size++;
            }
        }
        return size;
    }

    /**
     * 升级至当前等级所需钻石数
     * 
     * @param type
     * @param level
     * @return
     */
    public int findFarmlandOrMineCostDiamond(FarmlandAndMineType type, int level) {
        Iterator<FarmlandAndMineProperty> iterator = this.propertyMap.values().iterator();
        while (iterator.hasNext()) {
            FarmlandAndMineProperty property = iterator.next();
            if (property.getLandType() == type.value() && property.getLandLv() == level) {
                return property.getCostDiamond();
            }
        }
        throw new BusinessException(ErrorCode.JSON_TABLE_ERROR);
    }

    /**
     * 升级至当前等级所需钻石数
     * 
     * @param type
     * @param level
     * @return
     */
    public int getSnatchUp(FarmlandAndMineType type, int level) {
        Iterator<FarmlandAndMineProperty> iterator = this.propertyMap.values().iterator();
        while (iterator.hasNext()) {
            FarmlandAndMineProperty property = iterator.next();
            if (property.getLandType() == type.value() && property.getLandLv() == level) {
                return property.getSciencenum();
            }
        }
        throw new BusinessException(ErrorCode.JSON_TABLE_ERROR);
    }

    /**
     * 当前等级计算时的加成值
     * 
     * @param type
     * @param level
     * @return
     */
    public float getBonuses(FarmlandAndMineType type, int level) {
        for (FarmlandAndMineProperty farmland : this.getPropertyMap().values()) {
            if (farmland.getLandType() == 1 && farmland.getLandLv() == level) {
                return (float) (farmland.getImprove() / 100.0);
            }
        }
        throw new BusinessException(ErrorCode.JSON_TABLE_ERROR);
    }

    public int findSoldierEnhance(FarmlandAndMineType type, int level) {
        Iterator<FarmlandAndMineProperty> iterator = this.propertyMap.values().iterator();
        while (iterator.hasNext()) {
            FarmlandAndMineProperty property = iterator.next();
            if (property.getLandType() == type.value() && property.getLandLv() == level) {
                return property.getSoildernum();
            }
        }
        return 0;
    }

    public int findSkillHurtEnhance(FarmlandAndMineType type, int level) {
        Iterator<FarmlandAndMineProperty> iterator = this.propertyMap.values().iterator();
        while (iterator.hasNext()) {
            FarmlandAndMineProperty property = iterator.next();
            if (property.getLandType() == type.value() && property.getLandLv() == level) {
                return property.getSkillhurt();
            }
        }
        return 0;
    }

    public int findAttackEnhance(FarmlandAndMineType type, int level) {
        Iterator<FarmlandAndMineProperty> iterator = this.propertyMap.values().iterator();
        while (iterator.hasNext()) {
            FarmlandAndMineProperty property = iterator.next();
            if (property.getLandType() == type.value() && property.getLandLv() == level) {
                return property.getAttackhurt();
            }
        }
        return 0;
    }

}
