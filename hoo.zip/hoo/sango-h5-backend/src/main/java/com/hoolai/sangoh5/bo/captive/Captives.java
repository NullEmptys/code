package com.hoolai.sangoh5.bo.captive;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.IndustryProtocolBuffer.CaptivesProto;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.officer.data.OfficerData;
import com.hoolai.sangoh5.bo.officer.data.OfficerProperty;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.repo.OfficerRepo;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Captives implements ProtobufSerializable<CaptivesProto> {

    private List<Captive> wenOfficers = new ArrayList<Captive>();

    private List<Captive> wuOfficers = new ArrayList<Captive>();

    transient private long userId;

    transient private int topLimit;

    transient private OfficerRepo officerRepo;

    transient private OfficerData officerData;

    transient private BoFactory boFactory;

    public Captives(User user) {
        this.userId = user.getId();
        if (user.getVip() != null && user.getVip().getIsVip()) {
            topLimit = 8;
        } else {
            topLimit = 6;
        }
    }

    public Captives(User user, byte[] bytes) {
        this(user);
        parseFrom(bytes);
    }

    public List<Captive> reflesh() {
        List<Captive> conquestsOfficer = new ArrayList<Captive>();
        conquestsOfficer.addAll(reflesh0(wenOfficers));
        conquestsOfficer.addAll(reflesh0(wuOfficers));
        return conquestsOfficer;
    }

    private List<Captive> reflesh0(List<Captive> captives) {
        List<Captive> conquestsOfficer = new ArrayList<Captive>();
        Iterator<Captive> iterator = captives.iterator();
        while (iterator.hasNext()) {
            Captive captive = iterator.next();
            captive.reflesh();
            captive.setOfficer(officerRepo.findOfficer(userId, captive.getOfficerId()));
        }
        return conquestsOfficer;
    }

    public Officer addCaptive(int xmlId) {
        OfficerProperty property = officerData.getProperty(xmlId);
        int type = property.getType();
        if (type == 0 && wuOfficers.size() >= topLimit) {
            return null;
        } else if (type == 1 && wenOfficers.size() >= topLimit) {
            return null;
        }

        Officer captiveOfficer = boFactory.createOfficer(userId, xmlId, Officer.station_captive);

        Captive captive = new Captive(captiveOfficer.getId(), property.getPerseverance());
        if (type == 0) {
            wuOfficers.add(captive);
        } else {
            wenOfficers.add(captive);
        }
        return captiveOfficer;
    }

    public Captive findCaptive(int officerId) {
        for (Captive captive : wenOfficers) {
            if (captive.getOfficerId() == officerId) {
                return captive;
            }
        }
        for (Captive captive : wuOfficers) {
            if (captive.getOfficerId() == officerId) {
                return captive;
            }
        }
        return null;
    }

    public boolean removeCaptive(int officerId) {
        boolean isRemove = false;
        Iterator<Captive> iterator2 = wenOfficers.iterator();
        while (iterator2.hasNext()) {
            Captive captive = iterator2.next();
            if (captive.getOfficerId() == officerId) {
                iterator2.remove();
                isRemove = true;
                break;
            }
        }

        if (!isRemove) {
            Iterator<Captive> iterator3 = wuOfficers.iterator();
            while (iterator3.hasNext()) {
                Captive captive = iterator3.next();
                if (captive.getOfficerId() == officerId) {
                    iterator3.remove();
                    break;
                }
            }
        }
        return isRemove;
    }

    public boolean giveUpCaptive(int officerId, int value) {
        boolean isRemove = false;
        Iterator<Captive> iterator2 = wenOfficers.iterator();
        while (iterator2.hasNext()) {
            Captive captive = iterator2.next();
            if (captive.getOfficerId() == officerId) {
                iterator2.remove();
                isRemove = true;
            } else {
                captive.scareMonkey(value);
            }
        }

        Iterator<Captive> iterator3 = wuOfficers.iterator();
        while (iterator3.hasNext()) {
            Captive captive = iterator3.next();
            if (captive.getOfficerId() == officerId) {
                iterator3.remove();
                isRemove = true;
            } else {
                captive.scareMonkey(value);
            }
        }
        return isRemove;
    }

    public List<Captive> getCaptive2s() {
        return wenOfficers;
    }

    public void setCaptive2s(List<Captive> captive2s) {
        this.wenOfficers = captive2s;
    }

    public List<Captive> getCaptive3s() {
        return wuOfficers;
    }

    public void setCaptive3s(List<Captive> captive3s) {
        this.wuOfficers = captive3s;
    }

    public int getTopLimit() {
        return topLimit;
    }

    public void setTopLimit(int topLimit) {
        this.topLimit = topLimit;
    }

    public long getUserId() {
        return userId;
    }

    public void setOfficerRepo(OfficerRepo officerRepo) {
        this.officerRepo = officerRepo;
    }

    public void setOfficerData(OfficerData officerData) {
        this.officerData = officerData;
    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }

    @Override
    public CaptivesProto copyTo() {
        CaptivesProto.Builder builder = CaptivesProto.newBuilder();
        if (wenOfficers.size() > 0) {
            for (Captive captive : wenOfficers) {
                builder.addCaptive2S(captive.copyTo());
            }
        }
        if (wuOfficers.size() > 0) {
            for (Captive captive : wuOfficers) {
                builder.addCaptive3S(captive.copyTo());
            }
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            CaptivesProto message = CaptivesProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(CaptivesProto message) {
        int count = message.getCaptive2SCount();
        for (int i = 0; i < count; i++) {
            this.wenOfficers.add(new Captive(message.getCaptive2S(i)));
        }

        count = message.getCaptive3SCount();
        for (int i = 0; i < count; i++) {
            this.wuOfficers.add(new Captive(message.getCaptive3S(i)));
        }
    }

    public void surrender(Captive captive, boolean surrender, int officerStubborn, int otherStubborn) {
        if (surrender) {
            captive.deductStubborn(captive.getStubbornValue());
            return;
        }
        this.decrStubborn(wenOfficers, captive, officerStubborn, otherStubborn);
        this.decrStubborn(wuOfficers, captive, officerStubborn, otherStubborn);
    }

    private void decrStubborn(List<Captive> captives, Captive currentCaptive, int officerStubborn, int otherStubborn) {
        for (Captive captive : captives) {
            if (captive.getOfficerId() == currentCaptive.getOfficerId()) {
                captive.deductStubborn(officerStubborn);
            } else {
                captive.deductStubborn(otherStubborn);
            }
        }
    }
}
