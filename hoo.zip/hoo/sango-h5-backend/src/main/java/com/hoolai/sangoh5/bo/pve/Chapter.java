package com.hoolai.sangoh5.bo.pve;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.ChapterProto;
import com.hoolai.sangoh5.bo.pve.data.ChapterProperty;
import com.hoolai.sangoh5.bo.pve.data.PveData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Chapter implements ProtobufSerializable<ChapterProto> {

    /**
     * 篇章的ID
     */
    private int chapterId;

    /**
     * 当前攻占的最大城池ID
     */
    private int maxBarrierId;

    /**
     * 在此篇章获得的星星数量
     */
    transient private int starNum;

    /**
     * 在此篇章领取的宝箱
     */
    private int[] hadBoxs;

    /**
     * 在此篇章已经打过的英雄关卡
     */
    private List<HeroBarrier> heroBarriers = new ArrayList<HeroBarrier>();

    transient private long userId;

    transient private PveData pveData;

    public Chapter() {
    }

    public Chapter(int chapterId) {
        this.chapterId = chapterId;
    }

    public Chapter(ChapterProto message, PveData pveData) {
        this.pveData = pveData;//放在最前 不然后面传递时候会null
        this.copyFrom(message);
    }

    public Chapter(long userId, byte[] bytes) {
        this.userId = userId;
        parseFrom(bytes);
    }

    public int getChapterId() {
        return chapterId;
    }

    public void setChapterId(int chapterId) {
        this.chapterId = chapterId;
    }

    public int getMaxBarrierId() {
        return maxBarrierId;
    }

    public void setMaxBarrierId(int maxBarrierId) {
        this.maxBarrierId = maxBarrierId;
    }

    public int getStarNum() {
        return starNum;
    }

    public void setStarNum(int starNum) {
        this.starNum = starNum;
    }

    public int[] getHadBoxs() {
        return hadBoxs;
    }

    public void setHadBoxs(int[] hadBoxs) {
        this.hadBoxs = hadBoxs;
    }

    public List<HeroBarrier> getHeroBarriers() {
        return heroBarriers;
    }

    public void setHeroBarriers(List<HeroBarrier> heroBarriers) {
        this.heroBarriers = heroBarriers;
    }

    public long getUserId() {
        return userId;
    }

    @Override
    public ChapterProto copyTo() {
        ChapterProto.Builder builder = ChapterProto.newBuilder();
        builder.setChapterId(chapterId);
        builder.setMaxBarrierId(maxBarrierId);

        if (hadBoxs != null && hadBoxs.length > 0) {
            for (int i = 0; i < hadBoxs.length; i++) {
                builder.addHadBoxs(hadBoxs[i]);
            }
        }

        int size = heroBarriers.size();
        if (size > 0) {
            for (int i = 0; i < size; i++) {
                builder.addHeroBarriers(heroBarriers.get(i).copyTo());
            }
        }

        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ChapterProto message = ChapterProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(ChapterProto message) {
        this.chapterId = message.getChapterId();
        this.maxBarrierId = message.getMaxBarrierId();

        int len = message.getHadBoxsCount();
        if (len > 0) {
            this.hadBoxs = new int[len];
            for (int i = 0; i < len; i++) {
                hadBoxs[i] = message.getHadBoxs(i);
            }
        }

        len = message.getHeroBarriersCount();
        if (len > 0) {
            this.heroBarriers = new ArrayList<HeroBarrier>();
            for (int i = 0; i < len; i++) {
                HeroBarrier heroBarrier = new HeroBarrier(message.getHeroBarriers(i), userId, pveData);
                heroBarriers.add(heroBarrier);
                this.starNum += heroBarrier.getMaxStarNum();
            }
        }
    }

    public HeroBarrier findHeroBarrier(int bid) {
        for (HeroBarrier heroBarrier : heroBarriers) {
            if (heroBarrier.getBarrierId() == bid) {
                return heroBarrier;
            }
        }
        throw new BusinessException(ErrorCode.NOT_BARRIER);
    }

    public void clearHeroAttackNum() {
        for (HeroBarrier heroBarrier : heroBarriers) {
            heroBarrier.clearAttackNum();
        }
    }

    public void checkAndSetStageBox(int bid) {
        HeroBarrier heroBarrier = this.findHeroBarrier(bid);
        if (heroBarrier.getBoxState() == 0) {
            throw new BusinessException(ErrorCode.NOT_HAVE_BOX);
        }
        if (heroBarrier.getBoxState() == 2) {
            throw new BusinessException(ErrorCode.HAD_BOX);
        }
        heroBarrier.setBoxState(2);
    }

    public void checkCanOpenStarBox(int boxId, ChapterProperty chapterProperty, Chapter chapter) {
        int[] boxs = chapterProperty.getBoxId();
        int[] stars = chapterProperty.getStar();
        int index = ArrayUtils.indexOf(boxs, boxId);

        if (index < 0) {
            throw new BusinessException(ErrorCode.NOT_HAVE_BOX);
        }

        if (ArrayUtils.indexOf(chapter.getHadBoxs(), boxId) >= 0) {
            throw new BusinessException(ErrorCode.HAD_BOX);
        }

        if (chapter.getStarNum() < stars[index]) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_STAR);
        }
    }

}
