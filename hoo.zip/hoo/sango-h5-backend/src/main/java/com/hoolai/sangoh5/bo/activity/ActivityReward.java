package com.hoolai.sangoh5.bo.activity;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.ActivityRewardProto;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.ActivityRewardProto.Builder;
import com.hoolai.sangoh5.bo.activity.data.CumulativePayProperty;
import com.hoolai.sangoh5.bo.activity.data.FamilyProperty;
import com.hoolai.sangoh5.bo.activity.data.RewardLvProperty;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 10:17
 * @version : 1.0
 */
public class ActivityReward implements ProtobufSerializable<ActivityRewardProto> {

    public static final int REWARD_EMPTY = 0;

    public static final int REWARD_DRAW = 1;

    public static final int REWARD_DRAWED = 2;

    /** 奖励id **/
    private int rewardId;

    /** 进度 **/
    private int count;

    /** 状态 **/
    private int status;

    /** 今日 **/
    private int todayCount;

    public ActivityReward(int rewardId) {
        this.rewardId = rewardId;
        this.count = rewardId;
        this.status = REWARD_DRAW;
        this.todayCount = 0;
    }

    public ActivityReward(int rewardId, int status) {
        this.rewardId = rewardId;
        this.count = rewardId;
        this.status = status;
        this.todayCount = 0;
    }

    public ActivityReward(ActivityRewardProto rewards) {
        this.copyFrom(rewards);
    }

    public ActivityReward(RewardLvProperty rewardProperty) {
        this.rewardId = rewardProperty.getId();
        this.count = rewardProperty.getLv();
        this.status = REWARD_DRAW;
    }

    public ActivityReward(CumulativePayProperty payProperty) {
        this.rewardId = payProperty.getId();
        this.count = 0;
        this.status = REWARD_EMPTY;
    }

    public ActivityReward(FamilyProperty payProperty) {
        this.rewardId = payProperty.getId();
        this.count = 0;
        this.status = REWARD_EMPTY;
    }

    public int getRewardId() {
        return rewardId;
    }

    public void setRewardId(int rewardId) {
        this.rewardId = rewardId;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getTodayCount() {
        return todayCount;
    }

    public void setTodayCount(int todayCount) {
        this.todayCount = todayCount;
    }

    @Override
    public ActivityRewardProto copyTo() {
        Builder newBuilder = ActivityRewardProto.newBuilder();
        newBuilder.setId(rewardId);
        newBuilder.setCount(count);
        newBuilder.setStatus(status);
        newBuilder.setTodayCount(todayCount);
        return newBuilder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ActivityRewardProto message = ActivityRewardProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(ActivityRewardProto message) {
        this.rewardId = message.getId();
        this.count = message.getCount();
        this.status = message.getStatus();
        this.todayCount = message.getTodayCount();
    }

    public void addCount(int num) {
        this.count += num;
    }

    public boolean canDrawReward() {
        return this.status == REWARD_DRAW;
    }

    public void drawReward() {
        this.status = REWARD_DRAWED;
    }

    public void accumulative(CumulativePayProperty payProperty, int condition) {
        this.addCount(condition);
        if (payProperty.getGtade() > count) {
            return;
        }
        this.count = payProperty.getGtade();
        this.status = REWARD_DRAW;
    }

    public void invite(int maxCount) {
        this.addCount(1);
        if (maxCount > this.count) {
            return;
        }
        this.status = REWARD_DRAW;
    }

    public boolean emptyReward() {
        return this.status == REWARD_EMPTY;
    }

    public boolean drawedReward() {
        return this.status == REWARD_DRAWED;
    }

    public void focuson() {
        this.status = REWARD_DRAW;
        this.count = 1;
    }

    public void refresh() {
        this.todayCount = 0;
    }

    public void addRechargeCount(int condition) {
        this.count += condition;
        this.todayCount += condition;
    }

    public void family(FamilyProperty payProperty, int condition) {
        this.addCount(condition);
        if (payProperty.getGtade() > count) {
            return;
        }
        this.count = payProperty.getGtade();
        this.status = REWARD_DRAW;
    }
}
