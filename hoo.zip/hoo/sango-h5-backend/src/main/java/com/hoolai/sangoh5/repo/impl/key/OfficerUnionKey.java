package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class OfficerUnionKey {
	
	private static final String prefix= "off_union";
	
	public static String findOfficerUninsKey(long userId){
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId)
				.append(Constant.separator).append("ous").toString();
	}

}
