package com.hoolai.sangoh5.bo.battle.skill;

/**敌方, 我方?*/
public enum ForceType {
    
    FRIEND,ENEMY,FRIEND_ENEMY,ALL;
    
}