package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.RangeSustainedBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 有几率的在一定区域内持续性攻击的类
 * 
 * @author Administrator
 *
 */
public class RangeSustainedAttack extends IndependentSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            Buff buff = target.findBuff(this.xmlId);
            int delHp = 0;
            if (buff == null) {
                delHp = calDelHp(target);
                target.addBuff(new RangeSustainedBuff(actor, target.name(), this, currentLevel, delHp).withActorName(actor.name()).withTargetName(target.name()).withKeepBuff()
                        .withRepeatCount(repeatCount));
            } else {
                delHp = ((RangeSustainedBuff) buff).getDelHpTemp();
                buff.setRepeatCount(repeatCount);
            }
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "造成持续性伤害=" + delHp + ",持续回合数=" + repeatCount);
            targets.add(target);
        }
        return targets;
    }

    @Override
    public Skill clone() {
        return super.clone(new RangeSustainedAttack());
    }

    public int calDelHp(FightUnit target) {
        return Math.round(target.getOriginalHp() * this.percentage);
    }

}
