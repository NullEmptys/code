package com.hoolai.sangoh5.bo.shop.data;

import java.util.List;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * 商城刷新配置
 * 
 * @author hp
 *
 */
public class ShopFlushProperty extends JsonProperty {

    private List<Integer> times;

    private int timesCost;

    public List<Integer> getTimes() {
        return times;
    }

    public void setTimes(List<Integer> times) {
        this.times = times;
    }

    public int getTimesCost() {
        return timesCost;
    }

    public void setTimesCost(int timesCost) {
        this.timesCost = timesCost;
    }

}
