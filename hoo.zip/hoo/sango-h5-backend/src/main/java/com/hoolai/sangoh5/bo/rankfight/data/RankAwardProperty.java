package com.hoolai.sangoh5.bo.rankfight.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class RankAwardProperty extends JsonProperty {

    private int[] level;//等级区间

    private String[] rewardType;//奖励类型

    private int[] rewardId;//奖励id

    private int[] rewardNum;//奖励数量

    public int[] getLevel() {
        return level;
    }

    public void setLevel(int[] level) {
        this.level = level;
    }

    public String[] getRewardType() {
        return rewardType;
    }

    public void setRewardType(String[] rewardType) {
        this.rewardType = rewardType;
    }

    public int[] getRewardId() {
        return rewardId;
    }

    public void setRewardId(int[] rewardId) {
        this.rewardId = rewardId;
    }

    public int[] getRewardNum() {
        return rewardNum;
    }

    public void setRewardNum(int[] rewardNum) {
        this.rewardNum = rewardNum;
    }

}
