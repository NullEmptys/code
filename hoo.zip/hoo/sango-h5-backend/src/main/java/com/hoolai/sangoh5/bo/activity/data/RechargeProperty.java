package com.hoolai.sangoh5.bo.activity.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class RechargeProperty extends JsonProperty {

    /** 每天是否重置 **/
    private int isResetting;

    /** 是否默认开启 **/
    private int isDefault;

    public int getIsResetting() {
        return isResetting;
    }

    public void setIsResetting(int isResetting) {
        this.isResetting = isResetting;
    }

    public int getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(int isDefault) {
        this.isDefault = isDefault;
    }

    public boolean isDefault() {
        return this.isDefault == 1;
    }

}
