package com.hoolai.sangoh5.bo.battle.enhance.effect;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.ForceType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 伤害加成
 */
public class PassiveHurtEnhanceEffect extends EnhanceEffect {

    protected static final Log log = LogFactory.getLog("MoreHurtEnhanceEffect");

    protected FightUnit skillOwner;

    protected Skill skill;

    protected int canEnhanceTimes = skill.MaxRepeatCount;// 可以加成几次

    protected int alrEnhanceTimes;// 已经加成几次

    protected TargetCollection tc;

    protected PassiveHurtEnhanceEffect() {
    }

    public PassiveHurtEnhanceEffect(FightUnit actor, Skill skill, TargetCollection tc) {
        this.skillOwner = actor;
        this.skill = skill;
        this.tc = tc;
    }

    @Override
    public void enhance(Effect effect) {
        enhance0(effect);
    }

    protected void enhance0(Effect effect) {
        if (isCanEnhance(effect)) {
            int oldDelHp = effect.getDeltaHp();

            float per = skill.getPercentage();
            float val = skill.getValue();
            if (skill.getForceType() == ForceType.FRIEND) {
                per = -per;
                val = -val;
            }

            effect.setDeltaHp((int) (effect.getDeltaHp() * (1 + per) + val));
            alrEnhanceTimes++;

            skillOwner.addBattleLog(skillOwner.name() + "技能(" + skill.getXmlId() + (skill.getName()) + ")效果： 加成前伤害," + oldDelHp + ", 加成后伤害：" + effect.getDeltaHp()
                    + ", actorName： " + effect.actorName() + ", targetName： " + effect.getTargetName() + ", 被加成的xmlId： " + effect.getTargetUsedSkillXmlId());
        }
    }

    private boolean isCanEnhance(Effect effect) {
        if (alrEnhanceTimes >= canEnhanceTimes) {
            return false;
        }
        if ((skill.getForceType() == ForceType.FRIEND && effect.getTargetName() != skillOwner.name())
                || (skill.getForceType() != ForceType.FRIEND && effect.getActorName() != skillOwner.name()) || effect.getDeltaHp() <= 0) {
            return false;
        }

        if (skill.getAttributeType() == AttributeType.BASEHURT && !effect.isBaseHurt()) {
            return false;
        }

        if (skill.getAttributeType() == AttributeType.SKILLHURT && effect.isBaseHurt()) {
            return false;
        }

        return true;
    }

    public EnhanceEffect withCanEnhanceTimes(int times) {
        this.canEnhanceTimes = times;
        return this;
    }

}
