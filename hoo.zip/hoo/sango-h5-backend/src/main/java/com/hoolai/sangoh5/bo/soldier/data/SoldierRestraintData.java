package com.hoolai.sangoh5.bo.soldier.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class SoldierRestraintData extends JsonData<SoldierRestraintProperty>{

	@PostConstruct
	public void init() {
		try {
    		initData("com/hoolai/sangoh5/solres.json", SoldierRestraintProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void checkProperty(SoldierRestraintProperty property) {
		// TODO Auto-generated method stub
		
	}

	public float getRestraintRate(SoldierType attackSoldierType,SoldierType defenceSoldierType){
		int attType = attackSoldierType.value();
		int defType = defenceSoldierType.value();
		for(SoldierRestraintProperty property:this.propertyMap.values()){
			if(property.getSolType() == attType && property.getSolEnemyType() == defType){
				return property.getHurtRatio();
			}
		}
		
		return 1f;
	}
}
