package com.hoolai.sangoh5.bo.officer.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class OfficerLvProperty extends JsonProperty {

    private int level;

    private int exp;

    private int totalExp;

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

    public int getTotalExp() {
        return totalExp;
    }

    public void setTotalExp(int totalExp) {
        this.totalExp = totalExp;
    }

}
