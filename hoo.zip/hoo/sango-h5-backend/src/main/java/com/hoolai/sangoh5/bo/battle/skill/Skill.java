package com.hoolai.sangoh5.bo.battle.skill;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;

import com.hoolai.sangoh5.bo.battle.fight.PositionCalculator;
import com.hoolai.sangoh5.bo.battle.fight.PositionCalculator.MoveDirection;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.OfficerUnit;
import com.hoolai.sangoh5.bo.battle.unit.SoldierUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.bo.soldier.RestraintFinder;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.util.ProbabilityGenerator;

public abstract class Skill {

    protected static final Log logger = LogFactory.getLog("battle");

    public static final int SKILL_ID_LEVEL_UP_STEP = 1000000;

    public static final int MAX_STAR_LEVEL = 5;

    public static final int NONE_USED_SKILL_ID = 0;

    protected static final Logger log = Logger.getLogger(Skill.class);

    public static final int MaxRepeatCount = 10000;

    protected int repeatCount;

    protected int xmlId;

    protected int level;

    protected int skillId;

    protected transient ProbabilityGenerator pg;

    protected transient RestraintFinder restraintFinder;

    protected float chance;//触发的概率 for example 80

    protected SkillType skillType;

    protected float percentage;//for example 8

    protected float value;//for example 250

    //第二种效果相关参数
    protected AttributeType twoAttribute;

    protected float twoPercentage;

    protected int twoValue;

    protected int twoRepeatCount;

    protected int twoImpactId;

    protected String name;

    protected int user = 0; //0是将领  大于0是士兵，步骑弓特即1、2、3、4

    /** 伤害比率 */
    protected float hurtRate;

    protected Occasion occasion;

    protected ForceType forceType;

    protected ForceUnitType forceUnitType;

    protected AttributeType attributeType;

    protected ForceDirection forceDirection;

    protected int[] range;

    /**
     * 执行的间隔回合
     */
    protected int round;

    protected String subType;

    /**
     * 谁去执行这个技能
     */
    protected ForceUnitType attackUnitType;

    //    protected ForceCore forceCore;

    public void addHurtRate(float hurtRate) {
        this.hurtRate += hurtRate;
    }

    public float getHurtRate() {
        return hurtRate;
    }

    public void setHurtRate(float hurtRate) {
        this.hurtRate = hurtRate;
    }

    public int getRepeatCount() {
        return repeatCount;
    }

    public void setRepeatCount(int repeatCount) {
        this.repeatCount = repeatCount;
    }

    public int getXmlId() {
        return xmlId;
    }

    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getSkillId() {
        return skillId;
    }

    public void setSkillId(int skillId) {
        this.skillId = skillId;
    }

    public ProbabilityGenerator getPg() {
        return pg;
    }

    public void setPg(ProbabilityGenerator pg) {
        this.pg = pg;
    }

    public float getChance() {
        return chance;
    }

    public void setChance(float chance) {
        this.chance = chance;
    }

    public SkillType getSkillType() {
        return skillType;
    }

    public void setSkillType(SkillType skillType) {
        this.skillType = skillType;
    }

    public float getPercentage() {
        return percentage;
    }

    public void setPercentage(float percentage) {
        this.percentage = percentage;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getUser() {
        return user;
    }

    public void setUser(int user) {
        this.user = user;
    }

    public Occasion getOccasion() {
        return occasion;
    }

    public void setOccasion(Occasion occasion) {
        this.occasion = occasion;
    }

    public ForceType getForceType() {
        return forceType;
    }

    public void setForceType(ForceType forceType) {
        this.forceType = forceType;
    }

    public ForceUnitType getForceUnitType() {
        return forceUnitType;
    }

    public void setForceUnitType(ForceUnitType forceUnitType) {
        this.forceUnitType = forceUnitType;
    }

    public AttributeType getAttributeType() {
        return attributeType;
    }

    public void setAttributeType(AttributeType attributeType) {
        this.attributeType = attributeType;
    }

    public ForceDirection getForceDirection() {
        return forceDirection;
    }

    public void setForceDirection(ForceDirection forceDirection) {
        this.forceDirection = forceDirection;
    }

    public int[] getRange() {
        return range;
    }

    public void setRange(int[] range) {
        this.range = range;
    }

    //	public ForceCore getForceCore() {
    //		return forceCore;
    //	}
    //
    //	public void setForceCore(ForceCore forceCore) {
    //		this.forceCore = forceCore;
    //	}

    public AttributeType getTwoAttribute() {
        return twoAttribute;
    }

    public float getTwoPercentage() {
        return twoPercentage;
    }

    public int getTwoValue() {
        return twoValue;
    }

    public int getTwoRepeatCount() {
        return twoRepeatCount;
    }

    public int getTwoImpactId() {
        return twoImpactId;
    }

    protected Skill clone(Skill skill) {
        skill.xmlId = this.xmlId;
        skill.level = this.level;
        skill.skillId = this.skillId;
        skill.skillType = this.skillType;
        skill.repeatCount = this.repeatCount;
        skill.forceType = this.forceType;
        skill.attributeType = this.attributeType;
        skill.forceUnitType = this.forceUnitType;
        skill.percentage = this.percentage;
        skill.value = this.value;
        skill.chance = this.chance;
        skill.occasion = this.occasion;
        skill.name = this.name;
        skill.user = this.user;
        skill.hurtRate = hurtRate;
        skill.forceDirection = forceDirection;
        skill.range = range;
        skill.round = round;
        skill.twoAttribute = twoAttribute;
        skill.twoPercentage = twoPercentage;
        skill.twoRepeatCount = twoRepeatCount;
        skill.twoValue = twoValue;
        skill.twoImpactId = twoImpactId;
        skill.subType = subType;
        skill.attackUnitType = attackUnitType;

        skill.pg = pg;
        skill.restraintFinder = restraintFinder;
        return skill;
    }

    /**
     * 子类必须实现用于执行确定的子类方法
     */
    @Override
    public abstract Skill clone();

    public void setProbabilityGenerator(ProbabilityGenerator pg) {
        this.pg = pg;
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public void setRestraintFinder(RestraintFinder restraintFinder) {
        this.restraintFinder = restraintFinder;
    }

    public RestraintFinder getRestraintFinder() {
        return restraintFinder;
    }

    public void setTwoAttribute(AttributeType twoAttribute) {
        this.twoAttribute = twoAttribute;
    }

    public void setTwoPercentage(float twoPercentage) {
        this.twoPercentage = twoPercentage;
    }

    public void setTwoValue(int twoValue) {
        this.twoValue = twoValue;
    }

    public void setTwoRepeatCount(int twoRepeatCount) {
        this.twoRepeatCount = twoRepeatCount;
    }

    public void setTwoImpactId(int twoImpactId) {
        this.twoImpactId = twoImpactId;
    }

    public float getRestraintRate(FightUnit actor, FightUnit target) {
        float restraintRate = 1f;

        // 计算士兵伤害相克
        if (actor.isOfficer() || target.isOfficer()) {
            return restraintFinder.findFormationRestraintRate(actor.getFormationId(), target.getFormationId());
        } else {
            restraintRate = restraintFinder.findSoldierRestraintRate(((SoldierUnit) actor).getSoldierType(), ((SoldierUnit) target).getSoldierType());
        }

        // 计算阵型伤害相克
        restraintRate *= restraintFinder.findFormationRestraintRate(actor.getFormationId(), target.getFormationId());

        return restraintRate;
    }

    /**
     * 需要根据 forceType 、 forceUnitType、range来共同确定返回的课操作对象
     * 
     * @param tc
     * @param actor
     * @return
     */
    public List<FightUnit> aliveTargetUnitList(TargetCollection tc, FightUnit actor) {
        boolean isAttacker = actor.isAttacker();

        // 先找出所有士兵
        Map<FightUnitName, FightUnit> aliveMap = null;
        switch (forceType) {
            case ENEMY:
                aliveMap = tc.aliveTargetSoldier(isAttacker);
                break;
            case FRIEND:
                aliveMap = tc.aliveTargetSoldier(!isAttacker);
                break;
            case FRIEND_ENEMY:
            case ALL:
                aliveMap = tc.aliveSoldier();
                break;
        }
        return aliveTargetUnitList(tc, aliveMap, actor);
    }

    private List<FightUnit> aliveOfficerUnit(TargetCollection tc, boolean isAttacker) {
        List<FightUnit> fightUnits = new ArrayList<FightUnit>();
        switch (forceType) {
            case ENEMY:
                FightUnit fightUnit = tc.getAlive(FightUnitName.officerUnitName(!isAttacker));
                if (fightUnit != null) {
                    fightUnits.add(fightUnit);
                }
                break;
            case FRIEND:
                fightUnit = tc.getAlive(FightUnitName.officerUnitName(isAttacker));
                if (fightUnit != null) {
                    fightUnits.add(fightUnit);
                }
                break;
            case FRIEND_ENEMY:
            case ALL:
                FightUnit fightUnit1 = tc.getAlive(FightUnitName.officerUnitName(!isAttacker));
                if (fightUnit1 != null) {
                    fightUnits.add(fightUnit1);
                }

                FightUnit fightUnit2 = tc.getAlive(FightUnitName.officerUnitName(isAttacker));
                if (fightUnit2 != null) {
                    fightUnits.add(fightUnit2);
                }
                break;
        }
        return fightUnits;
    }

    public boolean isNotNeedRange() {
        if (range == null) {
            return true;
        }
        return range[0] == 0 && range[1] == 0 && range[2] == 0 && range[3] == 0;
    }

    public List<FightUnit> aliveTargetUnitList(TargetCollection tc, Map<FightUnitName, FightUnit> aliveMap, FightUnit actor) {
        List<FightUnit> fightUnits = new ArrayList<FightUnit>();

        Set<FightUnitName> keySet = aliveMap.keySet();

        MoveDirection direction = findDirection(actor);
        switch (forceUnitType) {
            case OFFICER:
                fightUnits.addAll(aliveOfficerUnit(tc, actor.isAttacker()));
                break;
            case OFFICER_SOLDIERS:
                fightUnits.addAll(aliveOfficerUnit(tc, actor.isAttacker()));
                for (FightUnitName name : keySet) {
                    fightUnits.add(aliveMap.get(name));
                }
                break;
            case SOLDIERS:
                for (FightUnitName name : keySet) {
                    fightUnits.add(aliveMap.get(name));
                }
                break;
            case RANDOM_ONE:
                for (FightUnitName name : keySet) {
                    fightUnits.add(aliveMap.get(name));
                }
                break;
            case TARGET:
                if (isNotNeedRange()) {
                    FightUnit target = actor.getDefender();
                    if (target != null) {
                        fightUnits.add(target);
                    }
                } else {
                    fightUnits.addAll(aliveOfficerUnit(tc, actor.isAttacker()));
                    for (FightUnitName name : keySet) {
                        fightUnits.add(aliveMap.get(name));
                    }
                }
                direction = null;
                break;
            case ARCHER:
                findSoldierUnit(fightUnits, aliveMap, keySet, SoldierType.archer);
                break;
            case CROSSBOWMAN:
                findSoldierUnit(fightUnits, aliveMap, keySet, SoldierType.crossbowman);
                break;
            case FOOTMAN:
                findSoldierUnit(fightUnits, aliveMap, keySet, SoldierType.footman);
                break;
            case RIDER:
                findSoldierUnit(fightUnits, aliveMap, keySet, SoldierType.rider);
                break;
            case SPEARMAN:
                findSoldierUnit(fightUnits, aliveMap, keySet, SoldierType.spearman);
                break;
            case VEHICLEMAN:
                findSoldierUnit(fightUnits, aliveMap, keySet, SoldierType.vehicleman);
                break;
        }

        if (!isNotNeedRange()) {
            Iterator<FightUnit> iterator = fightUnits.iterator();
            int[] referPos = forceUnitType == ForceUnitType.TARGET ? actor.getDefender().getPositionManager().expectNext() : actor.getPositionManager().expectNext();
            while (iterator.hasNext()) {
                FightUnit tarUnit = iterator.next();
                int[] targetPos = tarUnit.getPositionManager().expectNext();
                if (!PositionCalculator.isRange(referPos, targetPos, range, direction)) {
                    iterator.remove();
                }
            }
        }

        return fightUnits;
    }

    private MoveDirection findDirection(FightUnit actor) {
        MoveDirection direction = actor.getPositionManager().getLeftOrRight();
        if (actor.isOfficer() && ((OfficerUnit) actor).getOfficer().isWenGuan()) {
            direction = actor.isAttacker() ? MoveDirection.RIGHT : MoveDirection.LEFT;
        }
        return direction;
    }

    private void findSoldierUnit(List<FightUnit> fightUnits, Map<FightUnitName, FightUnit> aliveMap, Set<FightUnitName> keySet, SoldierType soldierType) {
        for (FightUnitName name : keySet) {
            SoldierUnit fightUnit = (SoldierUnit) aliveMap.get(name);
            if (fightUnit.getSoldierType() == soldierType) {
                fightUnits.add(fightUnit);
                break;
            }
        }
    }

    public void changeChance(float chance) {
        this.chance += chance;
        this.chance = Math.min(this.chance, 100);
    }

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public boolean isBaseSkill() {
        return xmlId == NONE_USED_SKILL_ID;
    }

    public ForceUnitType getAttackUnitType() {
        return attackUnitType;
    }

    public void setAttackUnitType(ForceUnitType attackUnitType) {
        this.attackUnitType = attackUnitType;
    }

}
