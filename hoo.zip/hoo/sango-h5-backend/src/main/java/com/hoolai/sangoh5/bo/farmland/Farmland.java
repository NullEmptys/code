package com.hoolai.sangoh5.bo.farmland;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.IndustryProtocolBuffer.FarmlandProto;
import com.hoolai.sangoh5.bo.farmland.data.FarmlandAndMineData;
import com.hoolai.sangoh5.bo.farmland.data.FarmlandAndMineProperty.FarmlandAndMineType;
import com.hoolai.sangoh5.bo.slave.Slave;
import com.hoolai.sangoh5.service.FarmlandOrMineService;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Farmland implements ProtobufSerializable<FarmlandProto> {

    private static final int expiration_time = 3;

    private int landLevel = 1;

    private int lastProduct;// 最近的一次产出

    private int product;// 产出粮草值

    private int productTemp;//在工作加入此期间被放弃或者 转空闲，结算产出加到这个值上面

    private long lastproduceDay;

    private int lastproduceHour;

    private int[] workSlaves;

    transient private long leftTime;

    transient private List<Slave> slaves;

    transient private long userId;

    transient private boolean lamp;//领取按钮true则按钮亮，false按钮不亮

    private boolean isSettlement;

    private long lastDrawTime;//最后一次领取时间，因为结算了有可能没领取

    private long lastCalTime;//最后一次结算时间

    private static final int AM_12 = 12;

    private static final int PM_19 = 19;

    transient private long resdueRewardTime;//剩余领取时间

    public Farmland() {
    }

    public Farmland(long userId) {
        this.userId = userId;
    }

    public Farmland(long userId, byte[] bytes) {
        this(userId);
        parseFrom(bytes);
    }

    public void reflesh0(long userId, FarmlandOrMineService farmlandOrMineService, Farmland farmland) {
        long today = DateUtil.getTodayIntValue();
        long currentTimeMillis = com.hoolai.sango.util.TimeUtil.currentTimeMillis();
        int currHour = MillisToHour(currentTimeMillis);
        long am12 = getTimeLine(AM_12);//今天12点
        long pm19 = getTimeLine(PM_19);//今天19点
        if (!isIn(currentTimeMillis, am12, pm19)) {//如果不在同一连续时间段内
            lastCalTime = currentTimeMillis;//将 当前时间 付给 最后一次结算时间
            if (currHour >= 12 && currHour < 19) {
                lastproduceDay = today;
                lastproduceHour = AM_12;
                product = lastProduct = farmlandOrMineService.calProduct(userId, 17, farmland, null) + productTemp;
                productTemp = 0;
            } else if (currentTimeMillis < am12) {
                lastproduceDay = today - 1;
                lastproduceHour = PM_19;
                product = lastProduct = farmlandOrMineService.calProduct(userId, 7, farmland, null) + productTemp;
                productTemp = 0;
            } else if (currentTimeMillis > pm19) {
                lastproduceDay = today;
                lastproduceHour = PM_19;
                product = lastProduct = farmlandOrMineService.calProduct(userId, 7, farmland, null) + productTemp;
                productTemp = 0;
            }
        }
        //判断是否超过三小时，超过把product清0；
        if (currHour >= AM_12 && currHour < PM_19) {
            if (isHaveProduct()) {
                if (currHour - 12 >= expiration_time) {
                    product = 0;
                } else {
                    this.resdueRewardTime = getTimeLine(15) - lastCalTime;
                }
                isSettlement = true;
            }
        } else if (currentTimeMillis < am12) {
            if (isHaveProduct()) {
                product = 0;
                isSettlement = true;
            }
        } else if (currentTimeMillis > pm19) {
            if (isHaveProduct()) {
                if (currHour - 19 >= expiration_time) {
                    product = 0;
                } else {
                    this.resdueRewardTime = getTimeLine(22) - lastCalTime;
                }
                isSettlement = true;
            }
        }
        this.initleftTime();
        this.initlamp();
    }

    /**
     * 判断当前时间和上次结算时间是否在同一时间段
     * 
     * @param currentTimeMillis
     * @return
     */
    public boolean isIn(long currentTimeMillis, long am12, long pm19) {
        long yesterdayPm19 = pm19 - 86400000;//昨天19点
        if (((currentTimeMillis >= am12 && currentTimeMillis < pm19) && (lastCalTime >= am12 && lastCalTime < pm19)) && currentTimeMillis >= lastCalTime) {//在今天12点到今天19点之间
            return true;
        } else if (currentTimeMillis < am12 && lastCalTime >= yesterdayPm19 && lastCalTime < am12 && currentTimeMillis >= lastCalTime) {//在今天12点之前
            return true;
        } else if (currentTimeMillis >= pm19 && lastCalTime >= pm19 && currentTimeMillis >= lastCalTime) {//在今天19点之后
            return true;
        } else {
            return false;
        }
    }

    /**
     * 毫秒转当天的小时
     * 
     * @param time
     * @return
     */
    public static int MillisToHour(long time) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(time);
        int currHour = c.get(Calendar.HOUR_OF_DAY);
        return currHour;
    }

    /**
     * 给下一次收获倒计时赋值
     */
    private void initleftTime() {
        long currentTimeMillis = TimeUtil.currentTimeMillis();
        Calendar now = Calendar.getInstance();
        now.setTimeInMillis(currentTimeMillis);
        int currHour = now.get(Calendar.HOUR_OF_DAY);
        if (currHour < AM_12) {
            now.set(Calendar.HOUR_OF_DAY, AM_12);
            now.set(Calendar.MINUTE, 0);
            now.set(Calendar.SECOND, 0);
            this.setLeftTime(now.getTimeInMillis() - currentTimeMillis);
        } else if (currHour >= AM_12 && currHour < 15) {
            this.setLeftTime(0);
        } else if (currHour >= 15 && currHour < PM_19) {
            now.set(Calendar.HOUR_OF_DAY, PM_19);
            now.set(Calendar.MINUTE, 0);
            now.set(Calendar.SECOND, 0);
            this.setLeftTime(now.getTimeInMillis() - currentTimeMillis);
        } else if (currHour >= PM_19 && currHour < 22) {
            this.setLeftTime(0);
        } else if (currHour >= 22) {
            now.set(Calendar.HOUR_OF_DAY, AM_12);
            now.set(Calendar.MINUTE, 0);
            now.set(Calendar.SECOND, 0);
            now.add(Calendar.DATE, 1);
            this.setLeftTime(now.getTimeInMillis() - currentTimeMillis);
        }
    }

    private void initlamp() {
        long now = TimeUtil.currentTimeMillis();
        long am12 = getTimeLine(AM_12);
        long pm15 = getTimeLine(15);
        long pm19 = getTimeLine(PM_19);
        long pm22 = getTimeLine(22);
        long lastDrawTime = this.getLastDrawTime();
        if ((now > am12 && now < pm15) && !(lastDrawTime > am12 && lastDrawTime < pm15) && product > 0) {
            this.setLamp(true);
        }
        if ((now > pm19 && now < pm22) && !(lastDrawTime > pm19 && lastDrawTime < pm22) && product > 0) {
            this.setLamp(true);
        }
    }

    /**
     * 通过今天某一整点获取时间戳
     * 
     * @param hour
     * @return
     */
    private long getTimeLine(int hour) {
        if (hour >= 0 && hour <= 24) {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(com.hoolai.sango.util.TimeUtil.currentTimeMillis());
            c.set(Calendar.HOUR_OF_DAY, hour);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            return c.getTimeInMillis();
        } else {
            return 0;
        }
    }

    public static void main(String[] args) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(com.hoolai.sango.util.TimeUtil.currentTimeMillis());
        c.set(Calendar.HOUR_OF_DAY, 19);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        System.out.println(c.getTimeInMillis());
        System.out.println(System.currentTimeMillis());

    }

    public void setLeftTime(long leftTime) {
        this.leftTime = leftTime;
    }

    private boolean isHaveProduct() {
        return product > 0;
    }

    public void addWorkSalve(int slaveId, int maxWorkSalves) {
        if (workSlaves != null && workSlaves.length >= maxWorkSalves) {
            throw new BusinessException(ErrorCode.WORK_SLAVE_OVER);
        }
        workSlaves = ArrayUtils.add(workSlaves, slaveId);
    }

    public void addWorkSalveNotCheck(int slaveId) {
        workSlaves = ArrayUtils.add(workSlaves, slaveId);
    }

    public void addProductTemp(int product) {
        productTemp += product;
    }

    public void removeWorkSlave(int slaveId) {
        int index = ArrayUtils.indexOf(workSlaves, slaveId);
        if (index < 0) {
            throw new BusinessException(ErrorCode.NO_SLAVE);
        }
        workSlaves = ArrayUtils.remove(workSlaves, index);
    }

    public boolean isSettlement() {
        return isSettlement;
    }

    public int getLandLevel() {
        return landLevel;
    }

    public void setLandLevel(int landLevel) {
        this.landLevel = landLevel;
    }

    public int getLastProduct() {
        return lastProduct;
    }

    public void setLastProduct(int lastProduct) {
        this.lastProduct = lastProduct;
    }

    public int getProduct() {
        return product;
    }

    public void setProduct(int product) {
        this.product = product;
    }

    public long getLastproduceDay() {
        return lastproduceDay;
    }

    public void setLastproduceDay(long lastproduceDay) {
        this.lastproduceDay = lastproduceDay;
    }

    public int getLastproduceHour() {
        return lastproduceHour;
    }

    public void setLastproduceHour(int lastproduceHour) {
        this.lastproduceHour = lastproduceHour;
    }

    public int[] getWorkSlaves() {
        return workSlaves;
    }

    public void setWorkSlaves(int[] workSlaves) {
        this.workSlaves = workSlaves;
    }

    public long getUserId() {
        return userId;
    }

    public void setSlaves(List<Slave> slaves) {
        this.slaves = slaves;
    }

    public long getLeftTime() {
        return leftTime;
    }

    public void setSettlement(boolean isSettlement) {
        this.isSettlement = isSettlement;
    }

    public long getLastDrawTime() {
        return lastDrawTime;
    }

    public void setLastDrawTime(long lastDrawTime) {
        this.lastDrawTime = lastDrawTime;
    }

    public void setLamp(boolean lamp) {
        this.lamp = lamp;
    }

    public boolean isLamp() {
        return lamp;
    }

    public int getProductTemp() {
        return productTemp;
    }

    public void setProductTemp(int productTemp) {
        this.productTemp = productTemp;
    }

    public long getLastCalTime() {
        return lastCalTime;
    }

    public void setLastCalTime(long lastCalTime) {
        this.lastCalTime = lastCalTime;
    }

    @JsonIgnore
    public List<Slave> getSlaves() {
        return slaves;
    }

    @Override
    public FarmlandProto copyTo() {
        FarmlandProto.Builder builder = FarmlandProto.newBuilder();
        builder.setLandLevel(landLevel);
        builder.setLastproduceDay(lastproduceDay);
        builder.setLastproduceHour(lastproduceHour);
        builder.setLastProduct(lastProduct);
        builder.setProduct(product);
        builder.setIsSettlement(isSettlement);
        builder.setLastDrawTime(lastDrawTime);
        builder.setLastCalTime(lastCalTime);
        builder.setProductTemp(productTemp);

        if (workSlaves != null && workSlaves.length > 0) {
            for (int w : workSlaves) {
                builder.addWorkSlaves(w);
            }
        }

        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            FarmlandProto message = FarmlandProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(FarmlandProto message) {
        this.landLevel = message.getLandLevel();
        this.lastproduceDay = message.getLastproduceDay();
        this.lastproduceHour = message.getLastproduceHour();
        this.lastProduct = message.getLastProduct();
        this.product = message.getProduct();
        this.isSettlement = message.getIsSettlement();
        this.lastDrawTime = message.getLastDrawTime();
        this.lastCalTime = message.getLastCalTime();
        this.productTemp = message.getProductTemp();

        int count = message.getWorkSlavesCount();

        this.workSlaves = new int[count];
        if (count > 0) {
            for (int i = 0; i < count; i++) {
                workSlaves[i] = message.getWorkSlaves(i);
            }
        }
    }

    public void levelUpLandLevel() {
        this.landLevel++;
    }

    public long getResdueRewardTime() {
        return resdueRewardTime;
    }

    public List<Integer> findSkill(FarmlandAndMineData farmlandAndMineData) {
        List<Integer> skills = new ArrayList<Integer>();
        //        int attackXmlId = farmlandAndMineData.findAttackEnhance(FarmlandAndMineType.FARM_LAND, this.landLevel);
        //        if (attackXmlId > 0) {
        //            skills.add(attackXmlId);
        //        }
        int hurtXmlId = farmlandAndMineData.findSkillHurtEnhance(FarmlandAndMineType.FARM_LAND, this.landLevel);
        if (hurtXmlId > 0) {
            skills.add(hurtXmlId);
        }
        return skills;
    }

}
