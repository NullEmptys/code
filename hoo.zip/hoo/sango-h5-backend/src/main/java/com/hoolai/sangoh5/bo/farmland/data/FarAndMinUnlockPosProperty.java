package com.hoolai.sangoh5.bo.farmland.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class FarAndMinUnlockPosProperty extends JsonProperty {

    private int landType;

    private UnlockCondition openCondition;

    public int getLandType() {
        return landType;
    }

    public void setLandType(int landType) {
        this.landType = landType;
    }

    public UnlockCondition getOpenCondition() {
        return openCondition;
    }

    public void setOpenCondition(UnlockCondition openCondition) {
        this.openCondition = openCondition;
    }

}
