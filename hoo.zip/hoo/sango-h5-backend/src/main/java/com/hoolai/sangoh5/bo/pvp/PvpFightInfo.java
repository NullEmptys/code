package com.hoolai.sangoh5.bo.pvp;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.PvpFightInfoProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class PvpFightInfo implements ProtobufSerializable<PvpFightInfoProto> {

    private long launchUserId;// 主动发起挑战的人launchUserId == userId说明是主动挑战，反之被挑战

    private long fightUserId; // 战斗对方的userId

    private int fightUserRank;// 战斗对方当时的user等级

    private long fightTime;// 战斗时间

    private boolean isWin;// 是否胜利

    private int battleId; // 战报ID

    private String fightUserName;// 战斗对方的名字

    private String fightUserImage;// 战斗对方的头像

    private String fightUserStateName;// 所属州的名称

    private boolean revengeSucc;//是否复仇成功

    private long userId;// 这条信息属于谁

    public PvpFightInfo(long ownerUserId, long launchUserId, long fightUserId, int fightUserRank, long fightTime, boolean isWin, int battleId, String fightUserName,
            String fightUserImage, String fightUserStateName) {
        super();
        this.userId = ownerUserId;
        this.launchUserId = launchUserId;
        this.fightUserId = fightUserId;
        this.fightUserRank = fightUserRank;
        this.fightTime = fightTime;
        this.isWin = isWin;
        this.battleId = battleId;
        this.fightUserName = fightUserName;
        this.fightUserImage = fightUserImage;
        this.fightUserStateName = fightUserStateName;
    }

    public PvpFightInfo() {

    }

    public PvpFightInfo(byte[] bytes) {
        this.parseFrom(bytes);
    }

    @Override
    public PvpFightInfoProto copyTo() {
        PvpFightInfoProto.Builder builder = PvpFightInfoProto.newBuilder();
        builder.setLaunchUserId(launchUserId);
        builder.setFightUserId(fightUserId);
        builder.setFightUserRank(fightUserRank);
        builder.setFightTime(fightTime);
        builder.setIsWin(isWin);
        builder.setBattleId(battleId);
        builder.setFightUserName(fightUserName);
        if (fightUserImage != null) {
            builder.setFightUserImage(fightUserImage);
        }
        builder.setFightUserStateName(fightUserStateName);
        builder.setUserId(userId);
        builder.setRevengeSucc(revengeSucc);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            PvpFightInfoProto message = PvpFightInfoProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }

    }

    @Override
    public void copyFrom(PvpFightInfoProto message) {
        this.launchUserId = message.getLaunchUserId();
        this.fightUserId = message.getFightUserId();
        this.fightUserRank = message.getFightUserRank();
        this.fightTime = message.getFightTime();
        this.isWin = message.getIsWin();
        this.battleId = message.getBattleId();
        this.fightUserName = message.getFightUserName();
        this.fightUserImage = message.getFightUserImage();
        this.fightUserStateName = message.getFightUserStateName();
        this.userId = message.getUserId();
        this.revengeSucc = message.getRevengeSucc();
    }

    public long getLaunchUserId() {
        return launchUserId;
    }

    public void setLaunchUserId(long launchUserId) {
        this.launchUserId = launchUserId;
    }

    public long getFightUserId() {
        return fightUserId;
    }

    public void setFightUserId(long fightUserId) {
        this.fightUserId = fightUserId;
    }

    public int getFightUserRank() {
        return fightUserRank;
    }

    public void setFightUserRank(int fightUserRank) {
        this.fightUserRank = fightUserRank;
    }

    public long getFightTime() {
        return fightTime;
    }

    public void setFightTime(long fightTime) {
        this.fightTime = fightTime;
    }

    public boolean isWin() {
        return isWin;
    }

    public void setWin(boolean isWin) {
        this.isWin = isWin;
    }

    public int getBattleId() {
        return battleId;
    }

    public void setBattleId(int battleId) {
        this.battleId = battleId;
    }

    public String getFightUserName() {
        return fightUserName;
    }

    public void setFightUserName(String fightUserName) {
        this.fightUserName = fightUserName;
    }

    public String getFightUserImage() {
        return fightUserImage;
    }

    public void setFightUserImage(String fightUserImage) {
        this.fightUserImage = fightUserImage;
    }

    public String getFightUserStateName() {
        return fightUserStateName;
    }

    public void setFightUserStateName(String fightUserStateName) {
        this.fightUserStateName = fightUserStateName;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public boolean isRevengeSucc() {
        return revengeSucc;
    }

    public void setRevengeSucc(boolean revengeSucc) {
        this.revengeSucc = revengeSucc;
    }

}
