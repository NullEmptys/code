package com.hoolai.sangoh5.bo.battle.fight;

import com.hoolai.sangoh5.bo.battle.unit.FightUnit;

/**
 * 战斗出手队列接口
 *
 */
public interface ActorSequence {
    
	/**
	 * 往添出手队列中添加战斗单元（一般战斗前初始化里面添加）
	 * @param actor
	 */
    public void put(FightUnit actor);
    
    /**
     * 下一个出手的战斗单元
     * @return
     */
    public FightUnit next();
    
    /**
     * 从出手队列中移除战斗单元（一般死亡的话就移除掉）
     * @param actor
     */
    public void remove(FightUnit actor);

    /**
     * 是否轮到下一回合
     * @return
     */
    public boolean isNextRoundTurn();

    /**
     * 结束当前回合
     */
    public void endCurrentRound();

    /**
     * 是否当前动作的是攻击方
     * @return
     */
    boolean currentActorIsAttacker();
    
}
