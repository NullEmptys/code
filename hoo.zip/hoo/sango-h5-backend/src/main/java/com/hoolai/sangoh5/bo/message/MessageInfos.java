package com.hoolai.sangoh5.bo.message;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.MessageInfoProtocolBuffer.MessageInfo4FriendProto;
import com.hoolai.sangoh5.bo.MessageInfoProtocolBuffer.MessageInfoProto;
import com.hoolai.sangoh5.bo.MessageInfoProtocolBuffer.MessageInfosProto;

public class MessageInfos implements ProtobufSerializable<MessageInfosProto> {

    private transient long userId;

    private List<MessageInfo> messageInfos = new ArrayList<MessageInfo>();

    private List<MessageInfo4Friend> giftMessages = new ArrayList<MessageInfo4Friend>();

    private int giveGiftNum;// 每日接受好友赠送礼物的次数

    public MessageInfos(long userId) {
        super();
        this.userId = userId;
    }

    public MessageInfos(byte[] bytes) {
        super();
        parseFrom(bytes);
    }

    @Override
    public MessageInfosProto copyTo() {
        MessageInfosProto.Builder builder = MessageInfosProto.newBuilder();
        for (MessageInfo messageInfo : messageInfos) {
            builder.addMessageInfos((MessageInfoProto) messageInfo.copyTo());
        }
        for (MessageInfo4Friend messageInfo4Friend : giftMessages) {
            builder.addGiftMessages(messageInfo4Friend.copyTo());
        }
        builder.setUserId(userId);
        builder.setGiveGiftNum(giveGiftNum);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            copyFrom(MessageInfosProto.parseFrom(bytes));
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void copyFrom(MessageInfosProto message) {
        for (MessageInfoProto mp : message.getMessageInfosList()) {
            this.messageInfos.add(new MessageInfo(mp));
        }
        for (MessageInfo4FriendProto mfp : message.getGiftMessagesList()) {
            this.giftMessages.add(new MessageInfo4Friend(mfp));
        }
        this.userId = message.getUserId();
        this.giveGiftNum = message.getGiveGiftNum();
    }

    public long getUserId() {
        return userId;
    }

    public List<MessageInfo> getMessageInfos() {
        return messageInfos;
    }

    public void setMessageInfos(List<MessageInfo> messageInfos) {
        this.messageInfos = messageInfos;
    }

    public int getMessagesCount() {
        return messageInfos.size();
    }

    public void addMessageInfos(MessageInfo mInfo) {
        this.messageInfos.add(mInfo);
    }

    public boolean remMessageInfos(MessageInfo mInfo) {
        return this.messageInfos.remove(mInfo);
    }

    public MessageInfo findMessage(int id) {
        List<MessageInfo> query = findAllMessage();

        for (MessageInfo messageInfo : query) {
            if (id == messageInfo.getId()) {
                return messageInfo;
            }
        }
        return null;
    }

    public MessageInfo findMessageInfo(int id) {
        for (MessageInfo messageInfo : messageInfos) {
            if (id == messageInfo.getId()) {
                return messageInfo;
            }
        }
        return null;
    }

    public void addFriendMessageInfos(MessageInfo4Friend mInfo) {
        if (giftMessages.size() >= MessageInfo4Friend.MSG_MAX_NUM) {
            giftMessages = giftMessages.subList(giftMessages.size() - MessageInfo4Friend.MSG_MAX_NUM, giftMessages.size() - 1);
        }
        this.giftMessages.add(mInfo);
    }

    public boolean remFriendMessageInfos(MessageInfo4Friend mInfo) {
        return this.giftMessages.remove(mInfo);
    }

    public MessageInfo4Friend findFriendMessageInfo(int id) {
        for (MessageInfo4Friend messageInfo : this.giftMessages) {
            if (id == messageInfo.getId()) {
                return messageInfo;
            }
        }
        return null;
    }

    public List<MessageInfo4Friend> getGiftMessages() {
        return giftMessages;
    }

    public void addGiveGiftNum(int num) {
        this.giveGiftNum += num;
    }

    public void clearGiveGiftNum() {
        this.giveGiftNum = 0;
    }

    public boolean isOverGiveGiftNum() {
        return giveGiftNum >= MessageInfo4Friend.AWARD_MAX_NUM;
    }

    public boolean isNew() {
        List<MessageInfo> query = findAllMessage();

        for (MessageInfo messageInfo : query) {
            if (!messageInfo.getIsRead()) {
                return true;
            }
        }
        return false;
    }

    private List<MessageInfo> findAllMessage() {
        List<MessageInfo> query = new ArrayList<MessageInfo>();
        query.addAll(messageInfos);
        query.addAll(giftMessages);
        return query;
    }

    public int getLeftGiveGiftNum() {//给前端用的
        return MessageInfo4Friend.AWARD_MAX_NUM - this.giveGiftNum;
    }

}
