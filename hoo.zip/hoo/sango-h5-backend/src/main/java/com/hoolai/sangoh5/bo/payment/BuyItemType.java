package com.hoolai.sangoh5.bo.payment;

import java.util.HashSet;
import java.util.Set;

import org.springframework.util.Assert;

import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;

public enum BuyItemType {

	first_nonios(1, 1, 13812, 100),
	second_nonios(2, 1, 13836, 300),
	third_nonios(3, 1, 13837, 60),
	fouth_nonios(4, 1, 13838, 300),
	five_nonios(5, 1, 13839, 980),
	six_nonios(6, 1, 13840, 1980),
	seven_nonios(7, 1, 13841, 3280),
	eight_nonios(8, 1, 13842, 6480),
	first2_nonios(1, 1, 15631, 90),
	fouth2_nonios(2, 1, 15639, 200),
	fouth3_nonios(2, 1, 15637, 220),
	fouth4_nonios(2, 1, 15635, 250),
	fouth5_nonios(2, 1, 15633, 270),
	
	first_ios(1, 2, 13813, 100),
	second_ios(2, 2, 13843, 300),
	third_ios(3, 2, 13844, 60),
	fouth_ios(4, 2, 13845, 300),
	five_ios(5, 2, 13846, 980),
	six_ios(6, 2, 13847, 1980),
	seven_ios(7, 2, 13848, 3280),
	eight_ios(8, 2, 13849, 6480),
	first2_ios(1, 2, 15632, 90),
	fouth2_ios(2, 2, 15640, 270),
	fouth3_ios(2, 2, 15638, 250),
	fouth4_ios(2, 2, 15636, 220),
	fouth5_ios(2, 2, 15634, 200)
	;
	
	public int index;
	public int zoneid;
	public int itemId;
	
	/** 价格就对应给的钻石数目 */
	public int price;
	
	private BuyItemType(int index, int zoneid, int itemId, int price){
		this.index = index;
		this.zoneid = zoneid;
		this.itemId = itemId;
		this.price = price;
	}
	
	public Award award(){
		return new Award(Award.diamond, price, AwardType.DIAMOND);
	}
	
	public static BuyItemType valueOf(int itemId){
		for(BuyItemType type:values()){
			if(type.itemId == itemId){
				return type;
			}
		}
		throw new IllegalArgumentException("未识别的购买道具类型itemId="+itemId);
	}
	
	public static BuyItemType valueOfByPriceAndIndex(int zoneid, int price, int index){
		for(BuyItemType type:values()){
			if(type.zoneid == zoneid && type.price == price && type.index == index){
				return type;
			}
		}
		throw new IllegalArgumentException("未识别的购买道具类型price="+price);
	}
	
	public static void init() {
    	Set<Integer> uniqueChecker = new HashSet<Integer>();
    	for(BuyItemType type:values()){
    		Assert.isTrue(uniqueChecker.add(type.index), "存在重复的购买道具类型index="+type.index); 			
    	}
    	uniqueChecker = null;
    }
	
}
