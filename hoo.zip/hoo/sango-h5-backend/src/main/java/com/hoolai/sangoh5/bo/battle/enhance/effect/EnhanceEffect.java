package com.hoolai.sangoh5.bo.battle.enhance.effect;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;

public abstract class EnhanceEffect {

    protected static final Log logger = LogFactory.getLog("battle");

    public abstract void enhance(Effect effect);

}
