package com.hoolai.sangoh5.bo.equip;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.EquipsProto;
import com.hoolai.sangoh5.bo.equip.Equip.ItemPosition;
import com.hoolai.sangoh5.bo.equip.data.EquipData;
import com.hoolai.sangoh5.repo.ItemRepo;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Equips implements ProtobufSerializable<EquipsProto>{

	private List<Equip> equips = new ArrayList<Equip>();
	
	transient private long userId;
	transient private boolean hasChange;
	
	
	transient private ItemRepo itemRepo;
	transient private EquipData equipData;

	public Equips(){}
	public Equips(long userId) {
		this();
		this.userId = userId;
	}

	public Equips(long userId, byte[] bytes) {
		this(userId);
		parseFrom(bytes);
	}

	public List<Equip> getEquips() {
		return equips;
	}

	public void setEquips(List<Equip> equips) {
		this.equips = equips;
	}

	public void setItemRepo(ItemRepo itemRepo) {
		this.itemRepo = itemRepo;
	}
	public void setEquipData(EquipData equipData) {
		this.equipData = equipData;
	}
	@Override
	public EquipsProto copyTo() {
		EquipsProto.Builder builder = EquipsProto.newBuilder();
		if(equips.size()>0){
			for(int index=0;index<equips.size();index++){
				builder.addEquips(equips.get(index).copyTo());
			}
		}
		return builder.build();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			EquipsProto message = EquipsProto.parseFrom(bytes);
			copyFrom(message);
		} catch (InvalidProtocolBufferException e) {
			throw new BusinessException(ErrorCode.CAN_NOT_MEM);
		}
	}

	@Override
	public void copyFrom(EquipsProto message) {
		int count = message.getEquipsCount();
		if(count > 0){
			for(int index=0;index<count;index++){
				this.equips.add(new Equip(message.getEquips(index)));
			}
		}
	}

	public long getUserId() {
		return userId;
	}
	
	public int[] addNewEquip(Equip... addEquips) {
		int[] equipIds = new int[addEquips.length];
		int i = 0;
		for (Equip equip : addEquips) {
			equipIds[i++] = addNewEquip0(equip);
        }
		return equipIds;
	}
	
	private int addNewEquip0(Equip equip) {
		int equipId = equip.getId();
		if (equipId > 0) {// 如果你已经有身份证了那么我认为你不是一个新生命,我将拒绝为你服务
		    return equipId;
		}
		equipId = itemRepo.getUniqueEquipId(userId);
		equip.setId(equipId);
		equips.add(equip);
		hasChange = true;
		return equipId;
	}
	
	public int[] addNewEquip(List<Equip> equipList) {
		int[] equipIds = new int[equipList.size()];
		int i = 0;
		for (Equip equip : equipList) {
			equipIds[i++] = addNewEquip0(equip);
		}
		return equipIds;
	}
	 
	 public boolean hasChange(){
		 return hasChange;
	 }
	public Equip findEquip(int equipId) {
		for(Equip equip:equips){
			if(equip.getId() == equipId){
				return equip;
			}
		}
		return null;
	}
	public List<Equip> equipList() {
		List<Equip> equipList = new ArrayList<Equip>();
		for(Equip equip:equips){
			if(equip.getPosition() == ItemPosition.in_bag.ordinal()){
				equipList.add(equip);
			}
		}
		return equipList;
	}
	public void backToBag(int... equips) {
		for(int equipId:equips){
			if(equipId<0){
				continue;
			}
			Equip equip = findEquip(equipId);
			equip.setPosition(ItemPosition.in_bag.ordinal());
		}
	}
	public void loadToOfficer(int... equips) {
		for(int equipId:equips){
			Equip equip = findEquip(equipId);
			equip.setPosition(ItemPosition.in_officer.ordinal());
		}
	}
//	public Equip checkAndLoadEquip(int equipId,int offLv) {
//		Equip equip = findEquip(equipId);
//		if(equip == null){
//			throw new BusinessException(ErrorCode.NO_EQUIP);
//		}
//		EquipProperty property = equipData.getProperty(equip.getXmlId());
//		if(property.getNeedOfficerLv() > offLv){
//			throw new BusinessException(ErrorCode.OFFICER_NOT_ENOUGH_LEVEL);
//		}
//		equip.setPosition(ItemPosition.in_officer.ordinal());
//		return equip;
//	}
	
	public void remEquips(int[] equipId){
		for (Iterator iterator = equips.iterator(); iterator.hasNext();) {
			Equip equip = (Equip) iterator.next();
			if(ArrayUtils.contains(equipId, equip.getId())){
				iterator.remove();
			}
		}
	}
}
