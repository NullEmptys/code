package com.hoolai.sangoh5.bo.pvp.data;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-13 11:03
 * @version : 1.0
 */
public class RegionConProperty extends ConBoxReward {

    /** 荣誉区间 **/
    private int[] personalConValve;

    public int[] getPersonalConValve() {
        return personalConValve;
    }

    public void setPersonalConValve(int[] personalConValve) {
        this.personalConValve = personalConValve;
    }

    @Override
    public boolean contains(int contribute) {
        return personalConValve[0] <= contribute && personalConValve[1] >= contribute;
    }

}
