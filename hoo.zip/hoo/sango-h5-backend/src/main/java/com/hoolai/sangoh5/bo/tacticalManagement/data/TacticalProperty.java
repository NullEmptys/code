package com.hoolai.sangoh5.bo.tacticalManagement.data;

import org.apache.commons.lang.ArrayUtils;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class TacticalProperty extends JsonProperty {

    private String name;

    private int type;

    private String oneXy;

    private String twoXy;

    private String threeXy;

    private String fourXy;

    private String fiveXy;

    private String sixXy;

    private String officerXy;

    private int[] oneRow;

    private int[] twoRow;

    private int[] threeRow;

    private int[] promoteNeedFigNum;

    private int[] resTac;

    private String[] resProperty;

    private int[] resValPer;

    private String[] tacProperty;

    private int[] oneStaValPer;

    private int[] oneStaValFix;

    private int[] twoStaValPer;

    private int[] twoStaValFix;

    private int[] threeStaValPer;

    private int[] threeStaValFix;

    private int[] fourStaValPer;

    private int[] fourStaValFix;

    private int[] fiValeStaValPer;

    private int[] fiValeStaValFix;

    private int[][] getXy(String xyStr) {
        String[] xy = xyStr.split(";");
        String[] att = xy[0].split("\\|");
        String[] def = xy[1].split("\\|");
        int[][] xys = new int[][] { { Integer.valueOf(att[0]), Integer.valueOf(att[1]) }, { Integer.valueOf(def[0]), Integer.valueOf(def[1]) } };
        return xys;
    }

    public int[] getAttackOfficerXy() {
        return getXy(officerXy)[0];
    }

    public int[] getDefenceOfficerXy() {
        return getXy(officerXy)[1];
    }

    public int[] getAttackOneXy() {
        return getXy(oneXy)[0];
    }

    public int[] getDefenceOneXy() {
        return getXy(oneXy)[1];
    }

    public int[] getAttackTwoXy() {
        return getXy(twoXy)[0];
    }

    public int[] getDefenceTwoXy() {
        return getXy(twoXy)[1];
    }

    public int[] getAttackThreeXy() {
        return getXy(threeXy)[0];
    }

    public int[] getDefenceThreeXy() {
        return getXy(threeXy)[1];
    }

    public int[] getAttackFourXy() {
        return getXy(fourXy)[0];
    }

    public int[] getDefenceFourXy() {
        return getXy(fourXy)[1];
    }

    public int[] getAttackFiveXy() {
        return getXy(fiveXy)[0];
    }

    public int[] getDefenceFiveXy() {
        return getXy(fiveXy)[1];
    }

    public int[] getAttackSixXy() {
        return getXy(sixXy)[0];
    }

    public int[] getDefenceSixXy() {
        return getXy(sixXy)[1];
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOneXy() {
        return oneXy;
    }

    public void setOneXy(String oneXy) {
        this.oneXy = oneXy;
    }

    public String getTwoXy() {
        return twoXy;
    }

    public void setTwoXy(String twoXy) {
        this.twoXy = twoXy;
    }

    public String getThreeXy() {
        return threeXy;
    }

    public void setThreeXy(String threeXy) {
        this.threeXy = threeXy;
    }

    public String getFourXy() {
        return fourXy;
    }

    public void setFourXy(String fourXy) {
        this.fourXy = fourXy;
    }

    public String getFiveXy() {
        return fiveXy;
    }

    public void setFiveXy(String fiveXy) {
        this.fiveXy = fiveXy;
    }

    public String getSixXy() {
        return sixXy;
    }

    public void setSixXy(String sixXy) {
        this.sixXy = sixXy;
    }

    public String getOfficerXy() {
        return officerXy;
    }

    public void setOfficerXy(String officerXy) {
        this.officerXy = officerXy;
    }

    public int[] getOneRow() {
        return oneRow;
    }

    public void setOneRow(int[] oneRow) {
        this.oneRow = oneRow;
    }

    public int[] getTwoRow() {
        return twoRow;
    }

    public void setTwoRow(int[] twoRow) {
        this.twoRow = twoRow;
    }

    public int[] getThreeRow() {
        return threeRow;
    }

    public void setThreeRow(int[] threeRow) {
        this.threeRow = threeRow;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int[] getPromoteNeedFigNum() {
        return promoteNeedFigNum;
    }

    public void setPromoteNeedFigNum(int[] promoteNeedFigNum) {
        this.promoteNeedFigNum = promoteNeedFigNum;
    }

    public int[] getResTac() {
        return resTac;
    }

    public void setResTac(int[] resTac) {
        this.resTac = resTac;
    }

    public String[] getResProperty() {
        return resProperty;
    }

    public void setResProperty(String[] resProperty) {
        this.resProperty = resProperty;
    }

    public int[] getResValPer() {
        return resValPer;
    }

    public void setResValPer(int[] resValPer) {
        this.resValPer = resValPer;
    }

    public String[] getTacProperty() {
        return tacProperty;
    }

    public void setTacProperty(String[] tacProperty) {
        this.tacProperty = tacProperty;
    }

    public int[] getOneStaValPer() {
        return oneStaValPer;
    }

    public void setOneStaValPer(int[] oneStaValPer) {
        this.oneStaValPer = oneStaValPer;
    }

    public int[] getOneStaValFix() {
        return oneStaValFix;
    }

    public void setOneStaValFix(int[] oneStaValFix) {
        this.oneStaValFix = oneStaValFix;
    }

    public int[] getTwoStaValPer() {
        return twoStaValPer;
    }

    public void setTwoStaValPer(int[] twoStaValPer) {
        this.twoStaValPer = twoStaValPer;
    }

    public int[] getTwoStaValFix() {
        return twoStaValFix;
    }

    public void setTwoStaValFix(int[] twoStaValFix) {
        this.twoStaValFix = twoStaValFix;
    }

    public int[] getThreeStaValPer() {
        return threeStaValPer;
    }

    public void setThreeStaValPer(int[] threeStaValPer) {
        this.threeStaValPer = threeStaValPer;
    }

    public int[] getThreeStaValFix() {
        return threeStaValFix;
    }

    public void setThreeStaValFix(int[] threeStaValFix) {
        this.threeStaValFix = threeStaValFix;
    }

    public int[] getFourStaValPer() {
        return fourStaValPer;
    }

    public void setFourStaValPer(int[] fourStaValPer) {
        this.fourStaValPer = fourStaValPer;
    }

    public int[] getFourStaValFix() {
        return fourStaValFix;
    }

    public void setFourStaValFix(int[] fourStaValFix) {
        this.fourStaValFix = fourStaValFix;
    }

    public int[] getFiValeStaValPer() {
        return fiValeStaValPer;
    }

    public void setFiValeStaValPer(int[] fiValeStaValPer) {
        this.fiValeStaValPer = fiValeStaValPer;
    }

    public int[] getFiValeStaValFix() {
        return fiValeStaValFix;
    }

    public void setFiValeStaValFix(int[] fiValeStaValFix) {
        this.fiValeStaValFix = fiValeStaValFix;
    }

    public int getRow(int pos) {
        if (ArrayUtils.contains(oneRow, pos)) {
            return 1;
        } else if (ArrayUtils.contains(twoRow, pos)) {
            return 2;
        } else if (ArrayUtils.contains(threeRow, pos)) {
            return 3;
        }

        return 0;
    }

    public int[] getPer(int starLv) {
        int[] pers = new int[] { 0, 0 };
        switch (starLv) {
            case 1:
                pers = this.getOneStaValPer();
                break;
            case 2:
                pers = this.getTwoStaValPer();
                break;
            case 3:
                pers = this.getThreeStaValPer();
                break;
            case 4:
                pers = this.getFourStaValPer();
                break;
            case 5:
                pers = this.getFiValeStaValPer();
                break;
        }
        return pers;
    }

    public int[] getValue(int starLv) {
        int[] values = new int[] { 0, 0 };
        switch (starLv) {
            case 1:
                values = this.getOneStaValFix();
                break;
            case 2:
                values = this.getTwoStaValFix();
                break;
            case 3:
                values = this.getThreeStaValFix();
                break;
            case 4:
                values = this.getFourStaValFix();
                break;
            case 5:
                values = this.getFiValeStaValFix();
                break;
        }
        return values;
    }
}
