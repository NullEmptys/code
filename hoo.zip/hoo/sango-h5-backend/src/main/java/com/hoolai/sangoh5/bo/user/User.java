package com.hoolai.sangoh5.bo.user;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.Sets;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.platform.PlatformUser;
import com.hoolai.platform.PlatformUserVIPInfo;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.StringUtil;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.UserProto;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillData;
import com.hoolai.sangoh5.bo.friend.Friend;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryRankData;
import com.hoolai.sangoh5.bo.platform.MobilePlatform;
import com.hoolai.sangoh5.bo.platform.Platform;
import com.hoolai.sangoh5.bo.platform.PlatformInfo;
import com.hoolai.sangoh5.bo.platform.wanba.WanbaUserScore;
import com.hoolai.sangoh5.bo.user.data.InitUserData;
import com.hoolai.sangoh5.bo.user.data.UserData;
import com.hoolai.sangoh5.util.Constant;
import com.hoolai.sangoh5.util.ProbabilityGenerator;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * @author hoolai
 *
 */
public class User implements ProtobufSerializable<UserProto> {

    private static final Log logger = LogFactory.getLog(User.class);

    public static final long MONSTER_USER_ID = -999;

    private long id;

    /** 平台修改名字的时候用 changeNum(String name) 方法 */
    private String name;

    private boolean isChangeName;//更新mysql数据库用

    private int exp; // 经验

    private int rank; // 等级

    private int gold;// 金币 4级货币

    private int diamond; // 钻石 2级货币

    private int moonstone;// 月长石4级货币

    private int friendship;

    private int lanTianYu; // 蓝田玉 3级货币 还没存

    private int meteorite;// 士兵科技陨铁 暂时存储在这

    private Vip vip;

    private String platformId;

    private int sangoState;// 属于哪个州

    private long createTime; // 创建时间

    private long lastLoginTime;

    private long lastSynAt;

    private String image;

    private int sex;

    private int slaveShapeType;

    private int militaryRank;//军衔等级

    private int militaryExploits;//军功

    private String militaryName;

    private int guideStep;

    /** 分组id **/
    private int rankGroupId;

    private Set<String> cdkeys;

    private Set<Integer> functionGuide;

    private Set<Integer> noviceRewardRec;

    private int announceVersion = Announce.ANNOUNCE_INIT_VERSION;// 阅读最新公告的版本，因为新用户不强弹公告

    private transient boolean isLevelUp;

    private transient int oldRank;

    private int freeSendWorldMessageNum;

    private boolean isFirstPay;// 未存TODO

    private int isViewMilitary;

    private int leftEar;

    /** pc版 zoneId **/
    private int pcZoneId;

    /** pc版君主id **/
    private long monarchId;

    /** 花藤id **/
    private long huatengId;

    private int userType;// 0普通游戏用户，1系统创建的功能用户

    @JsonIgnore
    private transient UserData userData;

    @JsonIgnore
    private transient MilitaryRankData militaryRankData;

    @JsonIgnore
    private transient SkillData skillData;

    @JsonIgnore
    private transient ProbabilityGenerator pg;

    private transient boolean isShowAnnounce;

    private final Map<Integer, PlatformInfo> platformInfos = new HashMap<Integer, PlatformInfo>();

    //    private int lastSyncAt;

    private WanbaUserScore wanbaUserScore = new WanbaUserScore();

    public User(byte[] bytes) {
        parseFrom(bytes);
    }

    public User() {
    }

    public User(long userId, String openid) {
        this.id = userId;
        this.platformId = openid;
    }

    public void toNpcUser(int rank) {
        this.rank = rank;
        this.id = -999;
        this.name = "胡莱莱";
        this.image = "http://down.the51.com/download/vector_cartoon-pic/2007110122214954.png";
        this.platformId = "1";
    }

    public User init(String name, InitUserData initUserData) {
        changeNum(name);
        this.rank = 1;
        this.gold = initUserData.getAward(AwardType.GOLD).getNum();
        this.friendship = initUserData.getAward(AwardType.FRIENDSHIP).getNum();
        this.moonstone = initUserData.getAward(AwardType.MOONSTONE).getNum();
        this.diamond = initUserData.getAward(AwardType.DIAMOND).getNum();
        this.lanTianYu = initUserData.getAward(AwardType.LANTIANYU).getNum();
        this.militaryRank = 1;
        this.militaryExploits = 0;
        this.militaryName = militaryRankData.getProperty(militaryRank).getName();
        this.image = "";
        this.createTime = TimeUtil.currentTimeMillis();
        return this;
    }

    public User(long userId) {
        this.id = userId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public int getDiamond() {
        return diamond;
    }

    public void setDiamond(int diamond) {
        this.diamond = diamond;
    }

    public int getLanTianYu() {
        return lanTianYu;
    }

    public void setLanTianYu(int lanTianYu) {
        this.lanTianYu = lanTianYu;
    }

    public Vip getVip() {
        return vip;
    }

    public int getFriendship() {
        return friendship;
    }

    public void setFriendship(int friendship) {
        this.friendship = friendship;
    }

    public void setVip(Vip vip) {
        this.vip = vip;
    }

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public int getSangoState() {
        return sangoState;
    }

    public void setSangoState(int sangoState) {
        this.sangoState = sangoState;
    }

    public long getLastSynAt() {
        return lastSynAt;
    }

    public void setLastSynAt(long lastSynAt) {
        this.lastSynAt = lastSynAt;
    }

    public boolean isLevelUp() {
        return isLevelUp;
    }

    public void setLevelUp(boolean isLevelUp) {
        this.isLevelUp = isLevelUp;
    }

    public int getOldRank() {
        return oldRank;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getSlaveShapeType() {
        return slaveShapeType;
    }

    public void setSlaveShapeType(int slaveShapeType) {
        this.slaveShapeType = slaveShapeType;
    }

    public void setUserData(UserData userData) {
        this.userData = userData;
    }

    public int getRankGroupId() {
        return rankGroupId;
    }

    public void setRankGroupId(int rankGroupId) {
        this.rankGroupId = rankGroupId;
    }

    public Set<String> getCdkeys() {
        return cdkeys;
    }

    public void setCdkeys(Set<String> cdkeys) {
        this.cdkeys = cdkeys;
    }

    public Set<Integer> getFunctionGuide() {
        return functionGuide;
    }

    public void setFunctionGuide(Set<Integer> functionGuide) {
        this.functionGuide = functionGuide;
    }

    public Set<Integer> getNoviceRewardRec() {
        return noviceRewardRec;
    }

    public void setNoviceRewardRec(Set<Integer> noviceRewardRec) {
        this.noviceRewardRec = noviceRewardRec;
    }

    public int getPcZoneId() {
        return pcZoneId;
    }

    public void setPcZoneId(int pcZoneId) {
        this.pcZoneId = pcZoneId;
    }

    public long getMonarchId() {
        return monarchId;
    }

    public void setMonarchId(long monarchId) {
        this.monarchId = monarchId;
    }

    public long getHuatengId() {
        return huatengId;
    }

    public void setHuatengId(long huatengId) {
        this.huatengId = huatengId;
    }

    @Override
    public void copyFrom(UserProto message) {
        this.createTime = message.getCreateTime();
        this.exp = message.getExp();
        this.friendship = message.getFriendship();
        this.gold = message.getGold();
        this.id = message.getId();
        this.name = message.getName();
        this.rank = message.getRank();
        this.diamond = message.getYuanbao();
        this.lanTianYu = message.getLanTianYu();
        this.platformId = message.getPlatformId();
        this.sangoState = message.getSangoState();
        this.sex = message.getSex();
        this.slaveShapeType = message.getSlaveShapeType();
        if (message.hasVip()) {
            this.vip = new Vip(message.getVip());
        }
        this.lastSynAt = message.getLastSynAt();
        this.moonstone = message.getMoonstone();
        this.militaryExploits = message.getMilitaryExploits();
        this.militaryName = message.getMilitaryName();
        this.militaryRank = message.getMilitaryRank();
        this.lastLoginTime = message.getLastLoginTime();
        this.guideStep = message.getGuideStep();
        this.image = message.getImage();
        this.rankGroupId = message.getRankGroupId();
        this.isFirstPay = message.getIsFirstPay();
        this.lanTianYu = message.getLanTianYu();
        int count = message.getCdkeyCount();
        this.cdkeys = Sets.newHashSetWithExpectedSize(count);
        for (int i = 0; i < count; i++) {
            this.cdkeys.add(message.getCdkey(i));
        }
        this.isViewMilitary = message.getIsViewMilitary();
        this.announceVersion = message.getAnnounceVersion();
        this.leftEar = message.getLeftEar();
        this.meteorite = message.getMeteorite();
        int functionCount = message.getFunctionGuideCount();
        this.functionGuide = Sets.newHashSetWithExpectedSize(count);
        for (int i = 0; i < functionCount; i++) {
            this.functionGuide.add(message.getFunctionGuide(i));
        }
        if (message.hasWanbaUserScore()) {
            wanbaUserScore = new WanbaUserScore(message.getWanbaUserScore());
        }
        int noviceRewardCount = message.getNoviceRewardRecCount();
        this.noviceRewardRec = Sets.newHashSetWithExpectedSize(noviceRewardCount);
        for (int i = 0; i < noviceRewardCount; i++) {
            this.noviceRewardRec.add(message.getNoviceRewardRec(i));
        }
        this.pcZoneId = message.getMonarchZoneId();
        this.monarchId = message.getMonarchId();
        this.huatengId = message.getHuaTengId();
        this.userType = message.getUserType();
        this.meteorite = message.getMeteorite();
    }

    @Override
    public UserProto copyTo() {
        UserProto.Builder builder = UserProto.newBuilder();
        builder.setId(id);
        builder.setName(name == null ? "" : name);
        builder.setCreateTime(createTime);
        builder.setExp(exp);
        builder.setFriendship(friendship);
        builder.setGold(gold);
        builder.setRank(rank);
        builder.setYuanbao(diamond);
        builder.setLanTianYu(lanTianYu);
        builder.setPlatformId(platformId == null ? "" : platformId);
        builder.setSangoState(sangoState);
        builder.setSex(sex);
        builder.setSlaveShapeType(slaveShapeType);
        if (vip != null) {
            builder.setVip(vip.copyTo());
        }
        builder.setLastSynAt(lastSynAt);
        builder.setMoonstone(moonstone);
        builder.setMilitaryExploits(militaryExploits);
        if (!StringUtil.isBlank(militaryName)) {
            builder.setMilitaryName(militaryName);
        }
        builder.setMilitaryRank(militaryRank);
        builder.setLastLoginTime(lastLoginTime);
        builder.setGuideStep(guideStep);
        builder.setImage(image == null ? "" : image);
        builder.setRankGroupId(rankGroupId);
        builder.setLanTianYu(lanTianYu);
        builder.setIsFirstPay(isFirstPay);
        if (CollectionUtils.isNotEmpty(cdkeys)) {
            if (cdkeys.size() > 0) {
                for (String key : cdkeys) {
                    builder.addCdkey(key);
                }
            }
        }
        builder.setIsViewMilitary(isViewMilitary);
        builder.setAnnounceVersion(announceVersion);
        builder.setLeftEar(leftEar);
        if (wanbaUserScore != null) {
            builder.setWanbaUserScore(wanbaUserScore.copyTo());
        }
        if (CollectionUtils.isNotEmpty(functionGuide)) {
            if (functionGuide.size() > 0) {
                for (int key : functionGuide) {
                    builder.addFunctionGuide(key);
                }
            }
        }
        if (CollectionUtils.isNotEmpty(noviceRewardRec)) {
            if (noviceRewardRec.size() > 0) {
                for (int key : noviceRewardRec) {
                    builder.addNoviceRewardRec(key);
                }
            }
        }
        builder.setMonarchZoneId(pcZoneId);
        builder.setMonarchId(monarchId);
        builder.setHuaTengId(huatengId);
        builder.setUserType(userType);
        builder.setMeteorite(meteorite);
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] data) {
        try {
            UserProto message = UserProto.parseFrom(data);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    public void checkLevel(int level) {
        if (level > this.rank) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_LEVEL);
        }
    }

    public void checkGold(int needGold) {
        if (this.gold <= 0 || needGold > this.gold) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_GOLD);
        }
    }

    public void decrGold(int needGold) {
        this.gold -= needGold;
    }

    public void checkAndDecGold(int gold) {
        checkGold(gold);
        decrGold(gold);
    }

    public void addGold(int gold) {
        this.gold += gold;
    }

    public void checkAndDecDiamond(int yuanbao) {
        if (yuanbao < 0 || yuanbao > this.diamond) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_YUANBAO);
        }
        this.diamond -= yuanbao;
    }

    public void addDiamond(int diamond) {
        this.diamond = this.diamond + diamond;
    }

    public void checkAndLanTianYu(int lanTianYu) {
        if (lanTianYu < 0 || lanTianYu > this.lanTianYu) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_LANTIANYU);
        }
        this.lanTianYu -= lanTianYu;
    }

    public void checkVip(int vipLevel) {
        if (this.vip == null || vipLevel > this.getVip().getVipLevel()) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_VIP_LEVEL);
        }
    }

    public void addMoonstone(int moonstone) {
        this.moonstone += moonstone;
    }

    public void addMeteorite(int sciece) {
        this.meteorite += sciece;
    }

    public void checkAndDecMoonstone(int decMoonstone) {
        if (this.moonstone < 0 || this.moonstone < decMoonstone) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_HONOR);
        }
        this.moonstone -= decMoonstone;
    }

    public void addLeftEar(int leftEar) {
        this.leftEar += leftEar;
    }

    public int checkAndDecCurrency(CurrencyType type, int decNum) {
        if (decNum < 0) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
        switch (type) {
            case DIAMOND:
                if (diamond < decNum) {
                    throw new BusinessException(ErrorCode.NOT_ENOUGH_YUANBAO);
                }
                return diamond -= decNum;
            case GOLD:
                if (gold < decNum) {
                    throw new BusinessException(ErrorCode.NOT_ENOUGH_GOLD);
                }
                return gold -= decNum;
            case MOONSTONE:
                if (moonstone < decNum) {
                    throw new BusinessException(ErrorCode.NOT_ENOUGH_HONOR);
                }
                return moonstone -= decNum;
            case FRIENDSHIP:
                if (friendship < decNum) {
                    throw new BusinessException(ErrorCode.FRIENDSHIP_NOT_ENOUGH);
                }
                return friendship -= decNum;
            case LANTIANYU:
                if (lanTianYu < decNum) {
                    throw new BusinessException(ErrorCode.NOT_ENOUGH_LANTIANYU);
                }
                return lanTianYu -= decNum;
            case LEFTEAR:
                if (leftEar < decNum) {
                    throw new BusinessException(ErrorCode.NOT_ENOUGH_LEFTEAR);
                }
                return leftEar -= decNum;
            case METEORITE:
                if (meteorite < decNum) {
                    throw new BusinessException(ErrorCode.NOT_ENOUGH_SCIECE);
                }
                return meteorite -= decNum;
            default:
                throw new BusinessException(ErrorCode.ERROR_PARAM_VALUE);
        }
    }

    public enum CurrencyType {
        LANTIANYU(1, "yb"), GOLD(2, "gold"), MOONSTONE(3, "ms"), FRIENDSHIP(4, "fs"), DIAMOND(5, "diamond"), MILITARYEXPLOITS(6, "me"), METEORITE(7, "meteorite"), LEFTEAR(8,
                "leftEar");

        private int currencyType;

        private String name;

        private CurrencyType(int currencyType, String name) {
            this.currencyType = currencyType;
            this.name = name;
        }

        public int getCurrencyType() {
            return currencyType;
        }

        public String getName() {
            return name;
        }

        public static CurrencyType find(int currencyType) {
            for (CurrencyType ct : CurrencyType.values()) {
                if (ct.currencyType == currencyType) {
                    return ct;
                }
            }
            throw new BusinessException(ErrorCode.NOT_FIND_THIS_TYPE);
        }

    }

    public int getMoonstone() {
        return moonstone;
    }

    public void setMoonstone(int moonstone) {
        this.moonstone = moonstone;
    }

    /**
     * 添加经验并刷新等级
     */
    public void addAndRefreshLv(int fameAdd) {
        if (rank >= userData.getPropertyMap().size()) {
            this.exp = 0;
            return;
        }
        this.exp += fameAdd;
        this.oldRank = this.rank;
        while (rank < userData.getPropertyMap().size() && exp >= userData.getProperty(rank).getExp()) {
            exp -= userData.getProperty(rank).getExp();
            rank++;
            isLevelUp = true;
            if (rank == userData.getPropertyMap().size()) {
                this.exp = 0;
            }
        }
    }

    public int getMilitaryRank() {
        return militaryRank;
    }

    public void setMilitaryRank(int militaryRank) {
        this.militaryRank = militaryRank;
    }

    public int getMilitaryExploits() {
        return militaryExploits;
    }

    public void setMilitaryExploits(int militaryExploits) {
        this.militaryExploits = militaryExploits;
    }

    public void setMilitaryRankData(MilitaryRankData militaryRankData) {
        this.militaryRankData = militaryRankData;
    }

    public void setSkillData(SkillData skillData) {
        this.skillData = skillData;
    }

    public void setPg(ProbabilityGenerator pg) {
        this.pg = pg;
    }

    public Friend transferToPlatformFriend() {
        Friend friend = new Friend(id, name, image, rank, militaryRank, militaryName);
        return friend;
    }

    public void setIsShowAnnounce(boolean isShowAnnounce) {
        this.isShowAnnounce = isShowAnnounce;
    }

    public boolean getIsShowAnnounce() {
        return isShowAnnounce;
    }

    public void compareServerVersion(int version) {
        if (version > announceVersion) {
            this.announceVersion = version;
            this.isShowAnnounce = true;
        }
    }

    /**
     * 升级军衔
     * 
     * @param addExploits
     */
    public void refreshMilitaryRank(int addExploits) {
        int maxilitaryRank = militaryRankData.getPropertyMap().size();
        this.militaryExploits += addExploits;
        if (this.militaryRank >= maxilitaryRank) {
            this.militaryExploits = Math.min(militaryExploits, militaryRankData.getProperty(maxilitaryRank).getExploit());
            this.militaryName = militaryRankData.getProperty(maxilitaryRank).getName();
            return;
        }
        int needExploits = militaryRankData.getProperty(militaryRank).getExploit();
        while (militaryExploits > needExploits && militaryRank < maxilitaryRank) {
            this.militaryExploits -= needExploits;
            this.militaryRank++;
            this.setIsViewMilitary(1);
            needExploits = militaryRankData.getProperty(militaryRank).getExploit();
        }
        this.militaryName = militaryRankData.getProperty(militaryRank).getName();
    }

    public String getMilitaryName() {
        return militaryName;
    }

    public void setMilitaryName(String militaryName) {
        this.militaryName = militaryName;
    }

    private void changeNum(String name) {
        this.name = name;
        isChangeName = true;
    }

    public boolean isChangeName() {
        return isChangeName;
    }

    public void addFriendShip(int num) {
        this.friendship += num;
    }

    public long getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(long lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    //	public static void main(String[] args) {
    //		User user = new User(111);
    //		user.setRank(1);
    //		user.setExp(0);
    //		user.refreshLv(90060);
    //		System.out.println("rank: "+user.getRank()+" , exp: "+user.getExp());
    //	}
    public User fillSendWorldMessageNum(int num) {
        this.freeSendWorldMessageNum = num;
        return this;
    }

    public int getFreeSendWorldMessageNum() {
        return freeSendWorldMessageNum;
    }

    public int getGuideStep() {
        return guideStep;
    }

    public void setGuideStep(int guideStep) {
        this.guideStep = guideStep;
    }

    public void addLanTianYu(int lanTianYu) {
        this.lanTianYu += lanTianYu;
    }

    public boolean getIsFirstPay() {
        return isFirstPay;
    }

    public void setIsFirstPay(boolean isFirstPay) {
        this.isFirstPay = isFirstPay;
    }

    public void firstPay() {
        this.isFirstPay = true;
    }

    public int getIsViewMilitary() {
        return isViewMilitary;
    }

    public void setIsViewMilitary(int isViewMilitary) {
        this.isViewMilitary = isViewMilitary;
    }

    public int getLeftEar() {
        return leftEar;
    }

    public void setLeftEar(int leftEar) {
        this.leftEar = leftEar;
    }

    @Override
    public User clone() {
        User user = new User(id, platformId);
        user.createTime = getCreateTime();
        user.exp = getExp();
        user.friendship = getFriendship();
        user.gold = getGold();
        user.id = getId();
        user.name = getName();
        user.rank = getRank();
        user.diamond = getDiamond();
        user.lanTianYu = getLanTianYu();
        user.platformId = getPlatformId();
        user.sangoState = getSangoState();
        user.sex = getSex();
        user.slaveShapeType = getSlaveShapeType();
        user.vip = new Vip(getVip());
        user.lastSynAt = getLastSynAt();
        user.moonstone = getMoonstone();
        user.militaryExploits = getMilitaryExploits();
        user.militaryName = getMilitaryName();
        user.militaryRank = getMilitaryRank();
        user.lastLoginTime = getLastLoginTime();
        user.guideStep = getGuideStep();
        user.image = getImage();
        user.rankGroupId = getRankGroupId();
        user.isFirstPay = getIsFirstPay();
        user.lanTianYu = getLanTianYu();
        user.leftEar = getLeftEar();
        user.meteorite = getMeteorite();
        return user;
    }

    public static boolean isValidPlatformId(String platformId) {
        int _index = platformId.lastIndexOf('_');
        if (_index == -1) {
            return false;
        }
        String platformSuffix = platformSuffix(platformId);
        return MobilePlatform.ios.name().equals(platformSuffix) || MobilePlatform.nonios.name().equals(platformSuffix);
    }

    public static String platformSuffix(String platformId) {
        return platformId.substring(platformId.lastIndexOf('_') + 1);
    }

    public static String realPlatformId(String platformId) {
        return platformId.substring(0, platformId.lastIndexOf('_'));
    }

    public static int getZoneId(String platformId) {
        return getMobilePlatform(platformId).type;
    }

    public static MobilePlatform getMobilePlatform(String platformId) {
        if (!isValidPlatformId(platformId)) {
            throw new UnsupportedOperationException("zoneid只针对玩吧平台才有");
        }
        return MobilePlatform.valueOf(platformSuffix(platformId));
    }

    public static void checkOpenid(String platformId) {
        Assert.isTrue(isValidPlatformId(platformId));
    }

    public PlatformInfo getPlatformInfo(int platformType) {
        return platformInfos.get(platformType);
    }

    public void setWanbaUserScore(WanbaUserScore wanbaUserScore) {
        this.wanbaUserScore = wanbaUserScore;
    }

    @JsonIgnore
    public int getZoneId() {
        return getZoneId(platformId);
    }

    public void updateCurrentPlatformInfo(int platformType, String name, String image) {
        logger.info("updateCurrentPlatformInfo name :" + name);
        logger.info("updateCurrentPlatformInfo Image :" + image);
        PlatformInfo platformInfo = new PlatformInfo();
        platformInfo.setPlatformType(platformType);
        platformInfo.setName(this.name = name);
        platformInfo.setImage(this.image = image);
        platformInfo.setLastSyncAt((int) lastSynAt);
        platformInfos.put(platformType, platformInfo);
    }

    public void updatePlatfromUser(PlatformUser platformUser) {
        transferToPlatfromUser();
        setSex(platformUser.getGender().value());
    }

    public void updateVipInfo(PlatformUserVIPInfo platformUserVIPInfo) {
        if (platformUserVIPInfo != null) {
            //    		vip.update(platformUserVIPInfo.isYellow, platformUserVIPInfo.isYearYellow, platformUserVIPInfo.getIsYellowHighVip(),platformUserVIPInfo.yellowLevel);
        }
    }

    /**
     * 是否有当前平台的信息
     * 
     * @return
     */
    @JsonIgnore
    public int getMaxSyncAt() {
        int maxSyncAt = 0;
        for (Platform platform : Platform.values()) {
            PlatformInfo platformInfo = platformInfos.get(platform.type);
            if (platformInfo != null && platformInfo.getLastSyncAt() > maxSyncAt) {
                maxSyncAt = platformInfo.getLastSyncAt();
            }
        }
        return maxSyncAt;
    }

    public User transferToPlatfromUser() {
        PlatformInfo platformInfo = platformInfos.get(Constant.PLATFORM_TYPE);
        logger.info("platformInfo name :" + platformInfo.getName());
        logger.info("platformInfo Image :" + platformInfo.getImage());
        if (platformInfo != null) {
            this.setName(platformInfo.getName());
            this.setImage(platformInfo.getImage());
            //            this.setLastSynAt(platformInfo.getLastSyncAt());
        }
        logger.info("user name :" + this.getName());
        logger.info("user Image :" + this.getImage());
        return this;
    }

    public void updateRank(int rank) {
        this.oldRank = this.rank;
        this.rank = rank;
        if (this.oldRank < rank) {
            this.isLevelUp = true;
        }
    }

    @JsonIgnore
    public boolean isWanbaVip() {
        return wanbaUserScore == null ? false : wanbaUserScore.getIs_vip();
    }

    public void addMonarch(int zoneId, long monarchId) {
        this.pcZoneId = zoneId;
        this.monarchId = monarchId;
    }

    public WanbaUserScore getWanbaUserScore() {
        return wanbaUserScore;
    }

    public int getUserType() {
        return userType;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }

    public int getMeteorite() {
        return meteorite;
    }

    public void setMeteorite(int meteorite) {
        this.meteorite = meteorite;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public boolean isNeedTrack() {
        return userType == 0;
    }

}
