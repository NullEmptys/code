package com.hoolai.sangoh5.bo.user;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.BattleSimpleUserProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class BattleSimpleUser implements ProtobufSerializable<BattleSimpleUserProto> {

    private long id;

    private String image;

    private int militaryRank;//军衔等级

    private int rank;

    private String name;

    public BattleSimpleUser(User user) {
        this.id = user.getId();
        this.image = user.getImage();
        this.militaryRank = user.getMilitaryRank();
        this.rank = user.getRank();
        this.name = user.getName();
    }

    public BattleSimpleUser(byte[] bytes) {
        parseFrom(bytes);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getMilitaryRank() {
        return militaryRank;
    }

    public void setMilitaryRank(int militaryRank) {
        this.militaryRank = militaryRank;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public BattleSimpleUserProto copyTo() {
        BattleSimpleUserProto.Builder builder = BattleSimpleUserProto.newBuilder();
        builder.setId(id);
        builder.setImage(image == null ? "" : image);
        builder.setMilitaryRank(militaryRank);
        builder.setRank(rank);
        builder.setName(name == null ? "" : name);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            BattleSimpleUserProto message = BattleSimpleUserProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(BattleSimpleUserProto message) {
        this.id = message.getId();
        this.image = message.getImage();
        this.militaryRank = message.getMilitaryRank();
        this.rank = message.getRank();
        this.name = message.getName();
    }

}
