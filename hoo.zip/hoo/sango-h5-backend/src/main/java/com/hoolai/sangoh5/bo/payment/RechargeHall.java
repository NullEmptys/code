package com.hoolai.sangoh5.bo.payment;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.RechargeHallProto;
import com.hoolai.sangoh5.bo.payment.data.RechargeHallData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 充值大厅
 *
 */
public class RechargeHall implements ProtobufSerializable<RechargeHallProto> {

    private int firstPay;

    transient private long userId;

    /**
     * 档位首充状态值
     * 1，代表相应档位未充值
     * 2，代表相应档位已充值
     */
    transient private int[] firstPayStatus;

    transient private RechargeHallData rechargeHallData;

    public RechargeHall() {
    }

    public RechargeHall(long userId) {
        this.userId = userId;
    }

    public RechargeHall(long userId, byte[] bytes) {
        this(userId);
        parseFrom(bytes);
    }

    public void recharge(int index) {
        firstPay = firstPay | (1 << index);
    }

    /** 已经首冲过,值为true */
    @JsonIgnore
    public boolean isIndexFirstPaid(int index) {
        int temp = 1 << index;
        if ((firstPay & temp) == temp) {
            return true;
        }
        return false;
    }

    /**
     * 是否双倍首充
     * 
     * @return
     */
    public int[] getFirstPayStatus() {
        int ids[] = rechargeHallData.getFirstPayIds();
        firstPayStatus = new int[ids.length];
        int i = 0;
        for (int id : ids) {
            firstPayStatus[i++] = isIndexFirstPaid(id) ? 2 : 1;
        }
        return firstPayStatus;
    }

    public void setFirstPayStatus(int[] firstPayStatus) {
        this.firstPayStatus = firstPayStatus;
    }

    public long getUserId() {
        return userId;
    }

    public void setRechargeHallData(RechargeHallData rechargeHallData) {
        this.rechargeHallData = rechargeHallData;
    }

    @Override
    public RechargeHallProto copyTo() {
        RechargeHallProto.Builder builder = RechargeHallProto.newBuilder();
        builder.setFirstPay(firstPay);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            RechargeHallProto proto = RechargeHallProto.parseFrom(bytes);
            copyFrom(proto);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.SYSTEM_ERROR);
        }
    }

    @Override
    public void copyFrom(RechargeHallProto proto) {
        this.firstPay = proto.getFirstPay();
    }

}
