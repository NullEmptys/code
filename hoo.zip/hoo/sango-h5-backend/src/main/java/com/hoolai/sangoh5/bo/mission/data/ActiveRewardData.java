package com.hoolai.sangoh5.bo.mission.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class ActiveRewardData extends JsonData<ActiveRewardProperty> {

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/activeReward.json", ActiveRewardProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void checkProperty(ActiveRewardProperty property) {
        // TODO Auto-generated method stub

    }

}
