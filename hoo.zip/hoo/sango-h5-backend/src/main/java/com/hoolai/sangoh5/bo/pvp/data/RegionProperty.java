package com.hoolai.sangoh5.bo.pvp.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class RegionProperty extends JsonProperty{

	private String region;

    private String province;
    
    private int area;

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public int getArea() {
		return area;
	}

	public void setArea(int area) {
		this.area = area;
	}
}
