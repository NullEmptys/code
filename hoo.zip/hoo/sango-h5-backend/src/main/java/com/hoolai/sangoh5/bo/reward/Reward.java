package com.hoolai.sangoh5.bo.reward;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.item.ItemBag;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.slave.Slave;

public class Reward {

    private List<ItemBag> itemList = new ArrayList<ItemBag>();

    private List<Officer> officerList = new ArrayList<Officer>();

    private Slave slave;

    private int moonstone;

    public void addItemBag(ItemBag addItemBag) {
        if (addItemBag.getXmlId() <= 0) {
            return;
        }
        ItemBag itemBag = findItemBag(addItemBag.getXmlId());
        if (itemBag == null) {
            itemList.add(addItemBag);
        } else {
            itemBag.incrNum(addItemBag.getNum());
        }
    }

    public ItemBag findItemBag(int xmlId) {
        for (ItemBag itemBag : this.itemList) {
            if (itemBag.getXmlId() == xmlId) {
                return itemBag;
            }
        }
        return null;
    }

    public void addOfficer(Officer officer) {
        this.officerList.add(officer);
    }

    public void addMoonstone(int moonstone) {
        this.moonstone += moonstone;
    }

    public void catchSlave(Slave slave) {
        this.slave = slave;
    }

    public List<ItemBag> getItemList() {
        return itemList;
    }

    public void setItemList(List<ItemBag> itemList) {
        this.itemList = itemList;
    }

    public List<Officer> getOfficerList() {
        return officerList;
    }

    public void setOfficerList(List<Officer> officerList) {
        this.officerList = officerList;
    }

    public int getMoonstone() {
        return moonstone;
    }

    public void setMoonstone(int moonstone) {
        this.moonstone = moonstone;
    }

    public Slave getSlave() {
        return slave;
    }

}
