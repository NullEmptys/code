package com.hoolai.sangoh5.bo.pve.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class PveData extends JsonData<PveProperty> {

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/pve.json", PveProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int[] getHeroBarrier(int[] barriers) {
        List<Integer> h = new ArrayList<Integer>();
        for (int bid : barriers) {
            PveProperty property = this.getProperty(bid);
            if (property.isHeroStage()) {
                h.add(bid);
            }
        }
        return toArray(h);
    }

    @Override
    protected void checkProperty(PveProperty property) {
        int length = property.getRewardId().length;
        if (property.getRewardNum().length != length || property.getRewardType().length != length || property.getProbability().length != length) {
            throw new RuntimeException("pve关卡id = " + property.getId() + " 的奖励id，num, type, probability数组长度不一致");
        }
    }

    public int getRankMonster() {

        return 0;
    }

}
