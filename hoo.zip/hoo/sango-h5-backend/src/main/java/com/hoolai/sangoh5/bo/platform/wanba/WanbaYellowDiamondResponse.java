package com.hoolai.sangoh5.bo.platform.wanba;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class WanbaYellowDiamondResponse extends WanbaResponse{

	private WanbaYellowDiamond[] data;
	
	public WanbaYellowDiamondResponse(){
		
	}
	
	private WanbaYellowDiamondResponse(int code){
		this.code = code;
	}
	
	public static WanbaYellowDiamondResponse success() {
		return new WanbaYellowDiamondResponse(WanbaResponse.SUCCESS_CODE);
	}
	
	public static WanbaYellowDiamondResponse error() {
		return new WanbaYellowDiamondResponse(WanbaResponse.ERROR_CODE);
	}
	
	public List<WanbaYellowDiamond> getDataList(){
		if(data == null){
			return Collections.emptyList();
		}
		return Arrays.asList(data);
	}
	
	@Override
	public String toString() {
		return "WanbaYellowDiamondResponse [data=" + Arrays.toString(data) + ", code=" + code + ", message=" + message + ", subcode=" + subcode
				+ "]";
	}
	
	public WanbaYellowDiamond[] getData() {
		return data;
	}
	public void setData(WanbaYellowDiamond[] data) {
		this.data = data;
	}
	
}
