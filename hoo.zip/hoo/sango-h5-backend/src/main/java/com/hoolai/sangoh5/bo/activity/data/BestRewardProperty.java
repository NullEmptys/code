package com.hoolai.sangoh5.bo.activity.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 15:45
 * @version : 1.0
 */
public class BestRewardProperty extends JsonProperty {

    /** id **/
    private int id;

    /** 蓝田玉数量 **/
    private int[] range;

    /** 概率 **/
    private int probability;

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    public int[] getRange() {
        return range;
    }

    public void setRange(int[] range) {
        this.range = range;
    }

    public int getProbability() {
        return probability;
    }

    public void setProbability(int probability) {
        this.probability = probability;
    }

}
