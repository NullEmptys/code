package com.hoolai.sangoh5.bo.item.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class SlaveNpcProperty extends JsonProperty {

    private String name;

    private String type;

    private int value;

    private int sex;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

}
