package com.hoolai.sangoh5.bo.pvp;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.PvpLimitationProto;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class PvpLimitation implements ProtobufSerializable<PvpLimitationProto> {

    private static final int DAY_LIMIT = 10;

    transient private long userId;

    private int countBuyFightNum;

    private int hasFightNum;

    /**
     * 来自军衔增加的pvp战斗次数
     */
    private int pvpFightNumAdd;

    private transient ConstantsPoolData constantsPool;

    public PvpLimitation(long userId, ConstantsPoolData constantsPool) {
        this.userId = userId;
        this.constantsPool = constantsPool;
    }

    public PvpLimitation(long userId, byte[] bytes, ConstantsPoolData constantsPool) {
        this(userId, constantsPool);
        parseFrom(bytes);
    }

    public int getFightNum() {
        return countBuyFightNum + pvpFightNumAdd + constantsPool.getProperty(1).getValue() - hasFightNum;
    }

    public long getUserId() {
        return userId;
    }

    public void addHasFightNum() {
        hasFightNum += 1;
    }

    public void checkAndAddAttackNum() {
        if (hasFightNum >= countBuyFightNum + pvpFightNumAdd + constantsPool.getProperty(1).getValue()) {
            throw new BusinessException(ErrorCode.TODAY_REACH_MAX);
        }
        addHasFightNum();
    }

    public void resetAttackNum() {
        this.hasFightNum = 0;
        this.countBuyFightNum = 0;
    }

    public int getCountBuyFightNum() {
        return countBuyFightNum;
    }

    public void setCountBuyFightNum(int countBuyFightNum) {
        this.countBuyFightNum = countBuyFightNum;
    }

    @Override
    public PvpLimitationProto copyTo() {
        PvpLimitationProto.Builder builder = PvpLimitationProto.newBuilder();
        builder.setHasFightNum(hasFightNum);
        builder.setCountBuyFightNum(countBuyFightNum);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            PvpLimitationProto message = PvpLimitationProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(PvpLimitationProto message) {
        this.hasFightNum = message.getHasFightNum();
        this.countBuyFightNum = message.getCountBuyFightNum();
    }

    public void buyFightNum() {
        this.countBuyFightNum++;
    }

    public void addFightNum() {
        this.hasFightNum--;
    }

    public void setHasFightNum(int hasFightNum) {
        this.hasFightNum = hasFightNum;
    }

    public void fillPvpFightNumAdd(int pvpFightNumAdd) {
        this.pvpFightNumAdd = pvpFightNumAdd;
    }

}
