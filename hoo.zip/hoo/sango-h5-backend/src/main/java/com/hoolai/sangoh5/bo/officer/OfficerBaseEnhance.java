package com.hoolai.sangoh5.bo.officer;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillProperty;
import com.hoolai.sangoh5.bo.equip.data.EquipProperty;
import com.hoolai.sangoh5.bo.equip.data.SuitsProperty;
import com.hoolai.sangoh5.bo.officer.Officer.EnhanceType;
import com.hoolai.sangoh5.bo.officerunion.data.OfficerUnionProperty;
import com.hoolai.sangoh5.bo.officerunion.data.OfficerUnionProperty.EnhanceProperty;
import com.hoolai.sangoh5.bo.tacticalManagement.data.TacticalProperty;

public class OfficerBaseEnhance {

    /** 攻击属性加成 */
    private float attackEnhanceRate;

    /** 攻击属性固定值加成 */
    private float attackEnhanceValue;

    /** 防御属性加成 */
    private float defenceEnhanceRate;

    /** 防御属性固定值加成 */
    private float defenceEnhanceValue;

    /** HP属性的加成 */
    private float hpEnhanceRate;

    /** HP属性固定值加成 */
    private float hpEnhanceValue;

    /** 武将带兵上限的加成 */
    private float captainShipEnhanceRate;

    /** 武将带兵上限的固定值加成 */
    private float captainShipEnhanceValue;

    private final EnhanceType enhanceType;

    public OfficerBaseEnhance(EnhanceType enhanceType) {
        this.enhanceType = enhanceType;
    }

    @Override
    public OfficerBaseEnhance clone() {
        OfficerBaseEnhance officerBaseEnhance = new OfficerBaseEnhance(enhanceType);
        officerBaseEnhance.attackEnhanceRate = attackEnhanceRate;
        officerBaseEnhance.attackEnhanceValue = attackEnhanceValue;
        officerBaseEnhance.captainShipEnhanceRate = captainShipEnhanceRate;
        officerBaseEnhance.captainShipEnhanceValue = captainShipEnhanceValue;
        officerBaseEnhance.defenceEnhanceRate = defenceEnhanceRate;
        officerBaseEnhance.defenceEnhanceValue = defenceEnhanceValue;
        officerBaseEnhance.hpEnhanceRate = hpEnhanceRate;
        officerBaseEnhance.hpEnhanceValue = hpEnhanceValue;
        return officerBaseEnhance;

    }

    private void enhance0(AttributeType attributeType, float[] per, int[] value) {
        switch (attributeType) {
            case ATTACK:
                this.attackEnhanceRate += per[0] / 100f;
                this.attackEnhanceValue += value[0];
                break;
            case DEFENCE:
                this.defenceEnhanceRate += per[0] / 100f;
                this.defenceEnhanceValue += value[0];
                break;
            case HP:
                this.hpEnhanceRate += per[0] / 100f;
                this.hpEnhanceValue += value[0];
                break;
            case CAPTAINSHIP:
                this.captainShipEnhanceRate += per[0] / 100f;
                this.captainShipEnhanceValue += value[0];
                break;
            case ATTACK_DEFENCE:
                this.attackEnhanceRate += per[0] / 100f;
                this.attackEnhanceValue += value[0];

                this.defenceEnhanceRate += per[1] / 100f;
                this.defenceEnhanceValue += value[1];
                break;
            case ATTACK_DEFENCE_HP:
                this.attackEnhanceRate += per[0] / 100f;
                this.attackEnhanceValue += value[0];

                this.defenceEnhanceRate += per[1] / 100f;
                this.defenceEnhanceValue += value[1];

                this.hpEnhanceRate += per[2] / 100f;
                this.hpEnhanceValue += value[2];
                break;
            case HP_DEFENCE:
                this.hpEnhanceRate += per[0] / 100f;
                this.hpEnhanceValue += value[0];

                this.defenceEnhanceRate += per[1] / 100f;
                this.defenceEnhanceValue += value[1];
                break;
            case HP_CAPTAINSHIP:
                this.hpEnhanceRate += per[0] / 100f;
                this.hpEnhanceValue += value[0];

                this.captainShipEnhanceRate += per[1] / 100f;
                this.captainShipEnhanceValue += value[1];
                break;
        }
    }

    public void enhance(EquipProperty property) {
        String attribute = property.getAttribute();
        AttributeType attributeType = AttributeType.convertType(attribute);
        enhance0(attributeType, property.getPercentage(), property.getValue());
    }

    public void enhance(SuitsProperty suitProperty) {
        String attribute = suitProperty.getSuitAttribute();
        AttributeType attributeType = AttributeType.convertType(attribute);
        enhance0(attributeType, new float[] { suitProperty.getSuitPercentage() }, new int[] { suitProperty.getSuitValue() });
    }

    /**
     * 除了加成技能能加攻防血以外
     * 将领技能在这只能算加兵加成
     * 其他属性都直接以战斗力形式
     * 战斗中技能单独会再计算攻防血的
     * 
     * @param property
     */
    public void enhance(SkillProperty property) {
        switch (property.getId()) {
            //            case 20001:
            //            	 this.attackEnhanceRate += property.getPercentage();
            //                 this.attackEnhanceValue += property.getValue();
            //                 break;
            //            case 20002:
            //            	 this.defenceEnhanceRate += property.getPercentage();
            //                 this.defenceEnhanceValue += property.getValue();
            //                 break;
        }
    }

    public void enhanceBattleEnhance(SkillProperty property) {
        AttributeType attributeType = AttributeType.valueOf(property.getAttribute().toUpperCase());
        float per = property.getPercentage();
        int value = property.getValue();
        switch (attributeType) {
            case ATTACK:
            case DEFENCE:
            case HP:
            case CAPTAINSHIP:
                enhance0(attributeType, new float[] { per }, new int[] { value });
                break;
            case ATTACK_DEFENCE:
            case HP_CAPTAINSHIP:
            case HP_DEFENCE:
                enhance0(attributeType, new float[] { per, per }, new int[] { value, value });
                break;
            case ATTACK_DEFENCE_HP:
                enhance0(attributeType, new float[] { per, per, per }, new int[] { value, value, value });
                break;
        }
    }

    public void enhance(OfficerUnionProperty property, int minStarLv) {
        List<EnhanceProperty> enhanceProperties = property.findEnhances(minStarLv);
        for (EnhanceProperty enhanceProperty : enhanceProperties) {
            enhance0(enhanceProperty.getAttributeType(), new float[] { enhanceProperty.getPer() }, new int[] { enhanceProperty.getValue() });
        }
    }

    public void enhance(TacticalProperty property, int starLv) {
        String[] tacp = property.getTacProperty();

        int[] pers = property.getPer(starLv);
        int[] values = property.getValue(starLv);

        for (int i = 0; i < tacp.length; i++) {
            String type = tacp[i];
            switch (type) {
                case "officerDef":
                    this.defenceEnhanceRate += pers[i] / 100f;
                    this.defenceEnhanceValue += values[i];
                    break;
            }
        }
    }

    public float getAttackEnhanceRate() {
        return attackEnhanceRate;
    }

    public void setAttackEnhanceRate(float attackEnhanceRate) {
        this.attackEnhanceRate = attackEnhanceRate;
    }

    public float getAttackEnhanceValue() {
        return attackEnhanceValue;
    }

    public void setAttackEnhanceValue(float attackEnhanceValue) {
        this.attackEnhanceValue = attackEnhanceValue;
    }

    public float getDefenceEnhanceRate() {
        return defenceEnhanceRate;
    }

    public void setDefenceEnhanceRate(float defenceEnhanceRate) {
        this.defenceEnhanceRate = defenceEnhanceRate;
    }

    public float getDefenceEnhanceValue() {
        return defenceEnhanceValue;
    }

    public void setDefenceEnhanceValue(float defenceEnhanceValue) {
        this.defenceEnhanceValue = defenceEnhanceValue;
    }

    public float getHpEnhanceRate() {
        return hpEnhanceRate;
    }

    public void setHpEnhanceRate(float hpEnhanceRate) {
        this.hpEnhanceRate = hpEnhanceRate;
    }

    public float getHpEnhanceValue() {
        return hpEnhanceValue;
    }

    public void setHpEnhanceValue(float hpEnhanceValue) {
        this.hpEnhanceValue = hpEnhanceValue;
    }

    public float getCaptainShipEnhanceRate() {
        return captainShipEnhanceRate;
    }

    public void setCaptainShipEnhanceRate(float captainShipEnhanceRate) {
        this.captainShipEnhanceRate = captainShipEnhanceRate;
    }

    public float getCaptainShipEnhanceValue() {
        return captainShipEnhanceValue;
    }

    public void setCaptainShipEnhanceValue(float captainShipEnhanceValue) {
        this.captainShipEnhanceValue = captainShipEnhanceValue;
    }

    @JsonIgnore
    @com.fasterxml.jackson.annotation.JsonIgnore
    public EnhanceType getEnhanceType() {
        return enhanceType;
    }

    public float[] calEnhance(AttributeType attributeType) {
        float per = 0;
        float value = 0;
        switch (attributeType) {
            case ATTACK:
                per += this.getAttackEnhanceRate();
                value += this.getAttackEnhanceValue();
                break;
            case DEFENCE:
                per += this.getDefenceEnhanceRate();
                value += this.getDefenceEnhanceValue();
                break;
            case HP:
                per += this.getHpEnhanceRate();
                value += this.getHpEnhanceValue();
                break;
            case CAPTAINSHIP:
                per += this.getCaptainShipEnhanceRate();
                value += this.getCaptainShipEnhanceValue();
                break;
        }
        return new float[] { per, value };
    }

    public OfficerBaseEnhance addEnhance(OfficerBaseEnhance... enhances) {
        for (OfficerBaseEnhance enhance : enhances) {
            if (enhance == null) {
                continue;
            }
            attackEnhanceRate += enhance.getAttackEnhanceRate();
            attackEnhanceValue += enhance.getAttackEnhanceValue();
            captainShipEnhanceRate += enhance.getCaptainShipEnhanceRate();
            captainShipEnhanceValue += enhance.getCaptainShipEnhanceValue();
            defenceEnhanceRate += enhance.getDefenceEnhanceRate();
            defenceEnhanceValue += enhance.getDefenceEnhanceValue();
            hpEnhanceRate += enhance.getHpEnhanceRate();
            hpEnhanceValue += enhance.getHpEnhanceValue();
        }
        return this;
    }

}
