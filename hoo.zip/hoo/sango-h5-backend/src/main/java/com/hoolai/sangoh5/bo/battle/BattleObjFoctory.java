package com.hoolai.sangoh5.bo.battle;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.battle.fight.Battle;
import com.hoolai.sangoh5.bo.battle.fight.BattleEnhance;
import com.hoolai.sangoh5.bo.battle.fight.BattleLog;
import com.hoolai.sangoh5.bo.battle.fight.BattleType;
import com.hoolai.sangoh5.bo.battle.fight.HpLostListener;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.active.BaseOfficerPhysicsSkill;
import com.hoolai.sangoh5.bo.battle.skill.data.BattleEnhanceData;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillData;
import com.hoolai.sangoh5.bo.battle.skill.soldier.active.BaseSoldierPhysicsSkill;
import com.hoolai.sangoh5.bo.battle.unit.Army;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName.FightType;
import com.hoolai.sangoh5.bo.battle.unit.OfficerUnit;
import com.hoolai.sangoh5.bo.battle.unit.SoldierUnit;
import com.hoolai.sangoh5.bo.equip.data.EquipData;
import com.hoolai.sangoh5.bo.farmland.Farmland;
import com.hoolai.sangoh5.bo.farmland.data.FarmlandAndMineData;
import com.hoolai.sangoh5.bo.mine.Mine;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.officer.data.OfficerData;
import com.hoolai.sangoh5.bo.soldier.FightSoldier;
import com.hoolai.sangoh5.bo.soldier.RestraintFinder;
import com.hoolai.sangoh5.bo.soldier.data.SoldierData;
import com.hoolai.sangoh5.bo.soldier.data.SoldierRestraintData;
import com.hoolai.sangoh5.bo.tacticalManagement.Formation;
import com.hoolai.sangoh5.bo.tacticalManagement.data.TacticalData;
import com.hoolai.sangoh5.bo.technology.SoldierTechnologies;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.repo.BarrackRepo;
import com.hoolai.sangoh5.repo.IndustryRepo;
import com.hoolai.sangoh5.repo.ItemRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.util.ProbabilityGenerator;

@Component
public class BattleObjFoctory {

    @Autowired
    private ProbabilityGenerator probabilityGenerator;

    @Autowired
    private OfficerData officerData;

    @Autowired
    private SkillData skillData;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private BarrackRepo barrackRepo;

    @Autowired
    private ItemRepo itemRepo;

    @Autowired
    private EquipData equipData;

    @Autowired
    private SoldierData soldierData;

    @Autowired
    private SoldierRestraintData soldierRestraintData;

    @Autowired
    private TacticalData tacticalData;

    @Autowired
    private BattleEnhanceData battleEnhanceData;

    @Autowired
    private BoFactory boFactory;

    public Battle createBattle(BattleType battleType, User attackUser, User defenseUser, Officer attackOfficer, Officer defenseOffcier) {

        BattleEnhance attackBattleEnhance = createBattleEnhance(attackUser.getId(), attackOfficer);
        BattleEnhance defenceBattleEnhance = createBattleEnhance(defenseUser.getId(), defenseOffcier);

        Battle battle = new Battle(battleType, attackUser, defenseUser, attackOfficer, defenseOffcier, attackBattleEnhance, defenceBattleEnhance);
        battle.setBoFactory(boFactory);
        battle.setBattleObjFoctory(this);
        battle.init();
        return battle;
    }

    private BattleEnhance createBattleEnhance(long userId, Officer ownerOfficer) {

        BattleEnhance attackBattleEnhance = new BattleEnhance();
        List<Integer> skills = findEnhanceSkillIds(userId);

        Formation ownerFormation = ownerOfficer.getCurrFormation();
        List<Skill> otherSkills = tacticalData.getEnhanceSkill(ownerFormation.getId(), ownerFormation.getStarLevel(), this);
        if (skills != null) {
            attackBattleEnhance.addOtherSkills(otherSkills);
        }

        if (userId > 0) {
            SoldierTechnologies soldierTechnologies = boFactory.getSoldierScienceRepo().findSoldierTechnologies(userId);
            attackBattleEnhance.getOtherEnhanceSkills().addAll(soldierTechnologies.findSkill(battleEnhanceData));

            for (Integer skillXmlId : skills) {
                attackBattleEnhance.addSkill(battleEnhanceData.findSkill(skillXmlId));
            }
        }

        return attackBattleEnhance;
    }

    private List<Integer> findEnhanceSkillIds(long userId) {
        List<Integer> skills = new ArrayList<Integer>();

        IndustryRepo industryRepo = boFactory.getIndustryRepo();
        FarmlandAndMineData farmlandAndMineData = boFactory.getFarmlandAndMineData();

        Farmland farmland = industryRepo.findSimpleFarmland(userId);
        if (farmland != null) {
            skills.addAll(farmland.findSkill(farmlandAndMineData));
        }

        Mine mine = industryRepo.findSimpleMine(userId);
        if (mine != null) {
            skills.addAll(mine.findSkill(farmlandAndMineData));
        }

        return skills;
    }

    /**
     * @param battleType
     * @return
     */
    public RestraintFinder newRestraintFinder() {
        RestraintFinder srf = new RestraintFinder();
        srf.setSoldierRestraintData(soldierRestraintData);
        srf.setTacticalData(tacticalData);
        return srf;
    }

    public OfficerUnit newOfficerUnit(boolean isAttacker, Officer officer, Army army, BattleEnhance battleEnhance, BattleLog battleLog) {
        OfficerUnit officerUnit = new OfficerUnit(isAttacker, officer, army, new BaseOfficerPhysicsSkill(this.newRestraintFinder(), probabilityGenerator), battleEnhance, battleLog);
        officerUnit.setSkillData(skillData);
        officerUnit.init();
        return officerUnit;
    }

    public SoldierUnit newSoldierUnit(FightType type, Officer officer, FightSoldier fightSoldier, HpLostListener hpLostListener, BattleEnhance battleEnhance, BattleLog battleLog) {

        SoldierUnit soldierUnit = new SoldierUnit(type, officer, fightSoldier, hpLostListener, new BaseSoldierPhysicsSkill(this.newRestraintFinder(), probabilityGenerator),
                battleEnhance, battleLog);
        soldierUnit.setSkillData(skillData);
        soldierUnit.setSoldierData(soldierData);
        soldierUnit.init();
        return soldierUnit;
    }

}
