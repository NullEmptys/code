package com.hoolai.sangoh5.bo.pvp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang3.tuple.Pair;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.CampsProto;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Camps implements ProtobufSerializable<CampsProto> {

    public static final int[] campIds = new int[] { 1, 2, 3 };

    private List<Camp> camps = new ArrayList<Camp>();

    private long lastUpdateDay;

    private boolean isWeekRank;

    transient private long userId;

    public Camps() {
    }

    public Camps(byte[] bytes) {
        parseFrom(bytes);
    }

    /**
     * 批量查询用户所属势力，List<Camp>与users长度相同，并且一一对应
     * 
     * @param users
     * @return
     */
    public List<Camp> findCampByUsers(User... users) {
        List<Camp> camps = new ArrayList<Camp>(this.camps.size());
        camps.addAll(this.camps);

        List<Camp> list = new ArrayList<Camp>(users.length);
        OUT: for (User user : users) {
            for (Camp camp : camps) {
                if (list.size() < users.length && camp.userIsAtThisCamp(user.getSangoState())) {
                    list.add(camp);
                } else if (list.size() == users.length) {
                    break OUT;
                }
            }
        }
        return list;
    }

    public long getUserId() {
        return userId;
    }

    public List<Camp> getCamps() {
        return camps;
    }

    public void setCamps(List<Camp> camps) {
        this.camps = camps;
    }

    @JsonIgnore
    public boolean isWeekRank() {
        return isWeekRank;
    }

    public void setWeekRank(boolean isWeekRank) {
        this.isWeekRank = isWeekRank;
    }

    @JsonIgnore
    public long getLastUpdateDay() {
        return lastUpdateDay;
    }

    public void setLastUpdateDay(long lastUpdateDay) {
        this.lastUpdateDay = lastUpdateDay;
    }

    @Override
    public CampsProto copyTo() {
        CampsProto.Builder builder = CampsProto.newBuilder();
        for (Camp camp : camps) {
            builder.addCamps(camp.copyTo());
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            CampsProto message = CampsProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(CampsProto message) {
        int count = message.getCampsCount();
        camps = new ArrayList<Camp>(count);
        for (int i = 0; i < count; i++) {
            camps.add(new Camp(message.getCamps(i)));
        }
    }

    public Camp findCamp(int campId) {
        for (Camp camp : camps) {
            if (camp.getId() == campId) {
                return camp;
            }
        }
        throw new BusinessException(ErrorCode.ERROR_PARAM_VALUE);
    }

    public Camp findCampByCampId(int campId) {
        for (Camp camp : camps) {
            if (camp.getId() == campId) {
                return camp;
            }
        }
        return null;
    }

    public Camp findOtherCamp(int myCampId) {
        Collections.shuffle(camps, new Random(TimeUtil.currentTimeMillis()));
        for (Camp camp : camps) {
            if (camp.getId() != myCampId) {
                return camp;
            }
        }
        throw new BusinessException(ErrorCode.ERROR_PARAM_VALUE);
    }

    public boolean isNeedUpdate() {
        return DateUtil.getTodayIntValue() >= (lastUpdateDay + 7);
    }

    public Camp findCampByStateId(int stateId) {
        for (Camp camp : camps) {
            if (camp.getStates().contains(stateId)) {
                return camp;
            }
        }
        return null;
//        throw new BusinessException(ErrorCode.ERROR_PARAM_VALUE);
    }

    public Camp findLastWeekCampByStateId(int stateId) {
        for (Camp camp : camps) {
            if (camp.findLastWeekStates().contains(stateId)) {
                return camp;
            }
        }
        return null;
    }

    public Set<Integer> findOtherCampState(int stateId) {
        Set<Integer> otherStates = Sets.newHashSetWithExpectedSize(6);
        for (Camp camp : camps) {
            if (!camp.getStates().contains(stateId)) {
                otherStates.addAll(camp.getStates());
            }
        }
        return otherStates;
    }

    public List<Pair<Integer, Integer>> findStateKeyGroups(int stateId) {
    	List<Pair<Integer, Integer>> keyGroups = Lists.newArrayListWithExpectedSize(18);
    	Camp camp = findCampByStateId(stateId);
    	if(camp == null){
    		return keyGroups;
    	}
        Set<Integer> states = camp.getStates();
        Set<Integer> otherStates = findOtherCampState(stateId);
        
        for (int state : states) {
            for (int otherState : otherStates) {
                keyGroups.add(Pair.of(otherState, state));
            }
        }
        return keyGroups;

    }

    public Set<Integer> findOtherStates(int stateId) {
        Set<Integer> otherStates = Sets.newHashSetWithExpectedSize(8);
        for (Camp camp : camps) {
            otherStates.addAll(camp.getStates());
        }
        otherStates.remove(stateId);
        return otherStates;
    }
}
