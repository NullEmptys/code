package com.hoolai.sangoh5.bo.battle.skill.soldier.active;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.soldier.FengXingBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class FengXing extends BaseSoldierPhysicsSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {

        List<FightUnit> targets = aliveTargetUnitList(tc, actor);
        for (FightUnit fightUnit : targets) {
            Buff buff = fightUnit.findBuff(xmlId);
            if (buff == null) {
                fightUnit.addBuff(new FengXingBuff(xmlId, name, fightUnit.name(), true, currentLevel).withActorName(actor.name()).withTargetName(fightUnit.name())
                        .withRepeatCount(repeatCount).withKeepBuff());
                fightUnit.shieldBaseHurt();
            } else {
                buff.setRepeatCount(repeatCount);
            }
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]让" + fightUnit.name() + "无视普攻");
        }

        return targets;
    }

    @Override
    public Skill clone() {
        return super.clone(new FengXing());
    }

}
