package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class WanBaInviteKey {

    private static final String prefix= "WanBaI";
	
    public static String getWanBaInviteKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("id").toString();
    }

	public static String getGiftRewardKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("gift").toString();
	}
	
}
