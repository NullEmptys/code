package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.ForceUnitType;
import com.hoolai.sangoh5.bo.battle.skill.Occasion;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.SkillType;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.bo.soldier.RestraintFinder;
import com.hoolai.sangoh5.util.ProbabilityGenerator;

public class BaseOfficerPhysicsSkill extends IndependentSkill {

    public BaseOfficerPhysicsSkill() {
        this.xmlId = 0;
        this.skillId = 0;
        this.level = 0;
        this.occasion = Occasion.BEFORE_ACTION;
        this.percentage = 0;
        this.value = 0;
        this.skillType = SkillType.ACTIVE;
        this.chance = 100;
        this.attackUnitType = ForceUnitType.OFFICER;
    }

    public BaseOfficerPhysicsSkill(RestraintFinder restraintFinder, ProbabilityGenerator probabilityGenerator) {
        this();
        this.restraintFinder = restraintFinder;
        this.pg = probabilityGenerator;
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        if (actor.getDefender() == null) {
            return null;
        }
        FightUnitName targetName = actor.getDefender().name();
        FightUnit target = tc.getAlive(targetName);
        if (target == null) return null;
        return exec(actor, target, tc, currentLevel);
    }

    protected List<FightUnit> exec(FightUnit actor, FightUnit target, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();
        int baseLostPoint = calculateLostPoint(actor, target);
        Effect effect = new Effect(Effect.NONE_USED_SKILL_ID, "物理攻击", target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name())
                .withDeltaHp(baseLostPoint).withIsBaseHurt(true);
        //        if (logger.isDebugEnabled()) {
        //        logger.debug(actor.name()+":attackPoint="+actor.attackPoint()
        //    			+";"+target.name()+":defencePoint="+target.defencePoint()+",伤害="+baseLostPoint);
        //    }

        actor.addBattleLog(actor.name() + "使用物理攻击给" + target.name() + "造成伤害=" + effect.getDeltaHp());

        target.addEffect(effect);
        targets.add(target);

        targetDefence(actor, target, effect, null, tc, targets, currentLevel);
        return targets;
    }

    protected int calculateLostPoint(FightUnit actor, FightUnit target) {
        float baseLostPoint = 0;
        if (target.isOfficer()) {
            baseLostPoint = Math.round((actor.attackPoint() - target.defencePoint()) * 0.35f);
        } else {
            baseLostPoint = (actor.attackPoint()) / (target.attackPoint() + target.defencePoint()) * (actor.getOfficerLevel() * 7 + 185) * 0.6f;
        }

        baseLostPoint *= getRestraintRate(actor, target);

        //        return randomLostPoint(baseLostPoint);
        return Math.round(baseLostPoint);
    }

    protected int calculateLostPoint4Skill(FightUnit actor, FightUnit target) {
        float baseLostPoint = 0;
        float attackPoint = actor.attackPoint();
        if (xmlId > 0) {
            attackPoint = attackPoint * percentage;
        }

        if (target.isOfficer()) {
            baseLostPoint = Math.round((attackPoint - target.defencePoint()) * 0.35f);
        } else {
            baseLostPoint = attackPoint / (target.attackPoint() + target.defencePoint()) * (actor.getOfficerLevel() * 7 + 185) * 0.6f;
        }

        baseLostPoint *= getRestraintRate(actor, target);
        baseLostPoint += value;

        //        return randomLostPoint(baseLostPoint);
        return Math.round(baseLostPoint);
    }

    protected int randomLostPoint(float lostPoint) {
        // 伤害浮动 最小值：INT(伤害*0.8-1)最大值：INT(伤害*1.0+1)
        int lostMinPoint = Math.round(lostPoint * 0.95f - 1);
        int lostMaxPoint = Math.round(lostPoint * 1.0f + 1);

        return lostMinPoint > 0 ? pg.getRandomNumber(lostMinPoint, lostMaxPoint) : 1;
    }

    @Override
    public Skill clone() {
        return this;
    }

}
