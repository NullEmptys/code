package com.hoolai.sangoh5.bo.arena;

import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.sangoh5.bo.ArenaProtocolBuffer.ArenaUserProto;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class ArenaUser implements ProtobufSerializable<ArenaUserProto>, Comparable<ArenaUser> {

    private int lastScore = 1000;//昨日战绩

    private int currentScore = 1000;//今日战绩

    private long currentRank;//当前排名

    private int winNum;//胜利次数

    private int loseNum;//失败次数

    private int currentOfficerId = -1;//当前上阵将领

    private int todayWinNum;//今天胜利次数

    private int todayLoseNum;//今天失败次数

    private int lastUpdateDay;

    private int honorPoint;

    private LinkedList<Integer> last100Score = new LinkedList<Integer>();//历史成绩

    transient private long userId;

    transient private String name;

    transient private BoFactory bofactory;

    transient private String unionName;

    transient private String userImage;

    transient private int userLevel;

    public ArenaUser(long userId) {
        this.userId = userId;
    }

    public ArenaUser(long userId, String name) {
        this.userId = userId;
        this.name = name;
        this.lastUpdateDay = DateUtil.getTodayIntValue();
    }

    public ArenaUser(long userId, byte[] bytes) {
        this.userId = userId;
        parseFrom(bytes);
    }

    public ArenaUser(long userId, String name, byte[] bytes) {
        this(userId, name);
        parseFrom(bytes);
    }

    public void assignOfficer(int officerId) {
        this.currentOfficerId = officerId;
    }

    public int checkAndFindOfficerId() {
        if (currentOfficerId < 1) {
            throw new BusinessException(ErrorCode.NOT_ASSIGN_OFFICER);
        }
        return currentOfficerId;
    }

    @JsonIgnore
    public int getFightNum() {
        return winNum + loseNum;
    }

    @JsonIgnore
    public int getTodayFightNum() {
        return todayWinNum + todayLoseNum;
    }

    public void addScore(int score) {
        this.currentScore += score;
        recordScore(currentScore);
    }

    public void decScore(int score) {
        this.currentScore -= score;
        recordScore(currentScore);
    }

    private void recordScore(int score) {
        int temp = last100Score.size() - 100 + 1;
        if (temp > 0) {
            for (int i = 0; i < temp; i++) {
                last100Score.removeFirst();
            }
        }
        last100Score.addLast(score);
    }

    public void addWinNum() {
        this.winNum++;
        this.todayWinNum++;
    }

    public void addLoseNum() {
        this.loseNum++;
        this.todayLoseNum++;
    }

    public int getLastScore() {
        return lastScore;
    }

    public void setLastScore(int lastScore) {
        this.lastScore = lastScore;
    }

    public int getCurrentScore() {
        return currentScore;
    }

    public void setCurrentScore(int currentScore) {
        this.currentScore = currentScore;
        recordScore(currentScore);
    }

    public long getCurrentRank() {
        return bofactory.getArenaRepo().getRankByUserId(userId);
    }

    public void setCurrentRank(long currentRank) {
        this.currentRank = currentRank;
    }

    public int getWinNum() {
        return winNum;
    }

    public void setWinNum(int winNum) {
        this.winNum = winNum;
    }

    public int getLoseNum() {
        return loseNum;
    }

    public void setLoseNum(int loseNum) {
        this.loseNum = loseNum;
    }

    public int getCurrentOfficerId() {
        return currentOfficerId;
    }

    public void setCurrentOfficerId(int currentOfficerId) {
        this.currentOfficerId = currentOfficerId;
    }

    public int getTodayWinNum() {
        return todayWinNum;
    }

    public void setTodayWinNum(int todayWinNum) {
        this.todayWinNum = todayWinNum;
    }

    public int getTodayLoseNum() {
        return todayLoseNum;
    }

    public void setTodayLoseNum(int todayLoseNum) {
        this.todayLoseNum = todayLoseNum;
    }

    public int getLastUpdateDay() {
        return lastUpdateDay;
    }

    public void setLastUpdateDay(int lastUpdateDay) {
        this.lastUpdateDay = lastUpdateDay;
    }

    public List<Integer> getLast100Score() {
        return last100Score;
    }

    public int getLastTimeScore() {
        int last = 0;//上一场的积分
        if (last100Score == null || last100Score.size() < 2) {
            last = lastScore;
        } else {
            last = last100Score.get(last100Score.size() - 2);
        }
        return last;
    }

    public void setLast100Score(LinkedList<Integer> last100Score) {
        this.last100Score = last100Score;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int gethonorPoint() {
        return honorPoint;
    }

    public void sethonorPoint(int honorPoint) {
        this.honorPoint = honorPoint;
    }

    public ArenaUser cloneArenaUser() {
        ArenaUser arenaUser = new ArenaUser(this.userId, this.name);
        arenaUser.currentOfficerId = currentOfficerId;
        arenaUser.currentRank = currentRank;
        arenaUser.currentScore = currentScore;
        arenaUser.lastScore = lastScore;
        arenaUser.lastUpdateDay = lastUpdateDay;
        arenaUser.loseNum = loseNum;
        arenaUser.todayLoseNum = todayLoseNum;
        arenaUser.todayWinNum = todayWinNum;
        arenaUser.winNum = winNum;
        return arenaUser;
    }

    @Override
    public ArenaUserProto copyTo() {
        ArenaUserProto.Builder builder = ArenaUserProto.newBuilder();
        builder.setCurrentOfficerId(currentOfficerId);
        builder.setCurrentRank(currentRank);
        builder.setCurrentScore(currentScore);
        builder.setLastScore(lastScore);
        builder.setLastUpdateDay(lastUpdateDay);
        builder.setLoseNum(loseNum);
        builder.setTodayLoseNum(todayLoseNum);
        builder.setTodayWinNum(todayWinNum);
        builder.setWinNum(winNum);
        builder.setHonorPoint(honorPoint);

        if (last100Score.size() > 0) {
            for (Integer score : last100Score) {
                builder.addLast100Score(score);
            }
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ArenaUserProto message = ArenaUserProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(ArenaUserProto message) {
        this.currentOfficerId = message.getCurrentOfficerId();
        this.currentRank = message.getCurrentRank();
        this.currentScore = message.getCurrentScore();
        this.lastScore = message.getLastScore();
        this.loseNum = message.getLoseNum();
        this.lastUpdateDay = message.getLastUpdateDay();
        this.todayLoseNum = message.getTodayLoseNum();
        this.todayWinNum = message.getTodayWinNum();
        this.winNum = message.getWinNum();
        this.honorPoint = message.getHonorPoint();

        int count = message.getLast100ScoreCount();
        this.last100Score = new LinkedList<Integer>();
        for (int i = 0; i < count; i++) {
            last100Score.addLast(message.getLast100Score(i));
        }

        if (DateUtil.getTodayIntValue() > lastUpdateDay) {
            this.lastUpdateDay = DateUtil.getTodayIntValue();
            this.todayLoseNum = 0;
            this.todayWinNum = 0;
            this.lastScore = currentScore;
        }
    }

    @Override
    public int compareTo(ArenaUser arenaUser) {
        long diff = arenaUser.getCurrentScore() - getCurrentScore(); //降序，从大到小
        if (diff == 0) {
            return sgn(getUserId() - arenaUser.getUserId()); //升序，从小到大
        }
        return sgn(diff);
    }

    private int sgn(long diff) {
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        } else {
            return 0;
        }
    }

    public void checkAndDecHonorPoint(int honorPoint) {
        if (honorPoint < 0 || honorPoint > this.honorPoint) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_HONORPOINT);
        }
        this.honorPoint -= honorPoint;
    }

    public void addHonorPoint(int honorPoint) {
        this.honorPoint += honorPoint;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUnionName() {
        return unionName;
    }

    public void setUnionName(String unionName) {
        this.unionName = unionName;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

    public int getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(int userLevel) {
        this.userLevel = userLevel;
    }

    public void setBofactory(BoFactory bofactory) {
        this.bofactory = bofactory;
    }

    public void addNum(boolean win) {
        if (win) {
            addWinNum();
            return;
        }
        addLoseNum();
    }

}
