package com.hoolai.sangoh5.bo.pvp.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-13 10:14
 * @version : 1.0
 */
@Component
public class UnionConBoxData extends ConBoxData<UnionConProperty> {

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/unionConBox.json", UnionConProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(UnionConProperty property) {
        if (property.getRewardIds().length != property.getRewardNums().length || property.getRewardIds().length != property.getRewardTypes().length) {
            throw new RuntimeException("unionCoinBoxData id = " + property.getId() + " 的奖励id，rewardsId, rewardsNums, rewardTypes 数组长度不一致");
        }
        if (property.getUnionConValve().length != 2) {
            throw new RuntimeException("unionCoinBoxData id = " + property.getId() + " 的奖励id，unionConValve length error");
        }
    }
}
