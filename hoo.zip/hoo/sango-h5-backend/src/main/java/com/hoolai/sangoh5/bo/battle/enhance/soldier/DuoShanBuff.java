package com.hoolai.sangoh5.bo.battle.enhance.soldier;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;

public class DuoShanBuff extends Buff {

    public float chance;

    public DuoShanBuff(int targetUsedSkillXmlId, String skillName, FightUnitName executeName, int currentLevel) {
        super(targetUsedSkillXmlId, skillName, executeName, currentLevel);
    }

    public DuoShanBuff withChance(float chance) {
        this.chance = chance;
        return this;
    }

    @Override
    public void apply(FightUnit target) {
        //        this.result();
    }

    @Override
    protected void doClear(FightUnit alive) {
        alive.changeSkillChance(targetUsedSkillXmlId, chance);
        alive.addBattleLog(targetUsedSkillXmlId + "[" + skillName + "]" + alive.name() + "冷却时间结束");
    }

    public float getChance() {
        return chance;
    }

}
