package com.hoolai.sangoh5.bo.shop;

/**
 * 给客户端的数据
 * 
 * @author hp
 *
 */
public class ShopListIdsAndNum {
	private int id;// 道具id
	private int numHave;// 道具拥有的数量
	private int isBuy;// 0已经购买1可以购买

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNumHave() {
		return numHave;
	}

	public void setNumHave(int numHave) {
		this.numHave = numHave;
	}

	public int getIsBuy() {
		return isBuy;
	}

	public void setIsBuy(int isBuy) {
		this.isBuy = isBuy;
	}

}
