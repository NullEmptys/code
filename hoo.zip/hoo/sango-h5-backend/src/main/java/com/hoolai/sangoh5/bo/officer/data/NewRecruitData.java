package com.hoolai.sangoh5.bo.officer.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.springframework.stereotype.Component;
import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.IntHashMap;

@Component
public class NewRecruitData extends JsonData<NewRecruitProperty> {

	private static final IntHashMap<List<NewRecruitProperty>> RECRUIT_DATA = new IntHashMap<List<NewRecruitProperty>>();

	@PostConstruct
	public void init() {
		try {
			initData("com/hoolai/sangoh5/recruit.json", NewRecruitProperty.class);
			initRecruitGoodsData();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void initRecruitGoodsData() {
		IntHashMap<NewRecruitProperty> newRecruit = getPropertyMap();
		for (NewRecruitProperty recruitProperty : newRecruit.values()) {
			if (RECRUIT_DATA.containsKey(recruitProperty.getType())) {
				RECRUIT_DATA.get(recruitProperty.getType()).add(recruitProperty);
			} else {
				List<NewRecruitProperty> recruitPropertyList = new ArrayList<NewRecruitProperty>();
				recruitPropertyList.add(recruitProperty);
				RECRUIT_DATA.put(recruitProperty.getType(), recruitPropertyList);
			}
		}
	}

	@Override
	protected void checkProperty(NewRecruitProperty property) {
		// TODO Auto-generated method stub

	}

	public static IntHashMap<List<NewRecruitProperty>> getNewRecruitPropertyData() {
		return RECRUIT_DATA;
	}

}
