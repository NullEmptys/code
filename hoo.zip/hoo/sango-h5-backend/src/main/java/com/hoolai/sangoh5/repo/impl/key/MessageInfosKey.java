package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class MessageInfosKey {
	
	private static final String prefix= "minfo";

    public static String getMessageInfosKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("s").toString();
    }
    
    public static final String me_id = "u_mes_id";
    
    public static String generateMessageId(long userId){
    	return new StringBuilder().append(me_id).append(Constant.separator).append(userId).toString();
    }

}
