package com.hoolai.sangoh5.bo.constant;

public enum ConstantsType {
//	PVP(1),
//	RESCUE(2),
//	RANK_FIGHT(3),
//	ARENA_FIGHT(4);
	
}
