package com.hoolai.sangoh5.event.event;

import com.hoolai.sangoh5.bo.battle.fight.BattleResult;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.event.EventType;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 17:53
 * @version : 1.0
 */
public class PvpoccupyEvent extends UserEvent {

    private final boolean win;

    /** 剩余兵力百分比 **/
    private final int remainPercentage;

    /** 防御者/攻击者战斗力 **/
    private final int fightPowerPercentage;

    public PvpoccupyEvent(User owner, boolean win, int remainPercentage, int fightPowerPercentage) {
        super(owner);
        this.win = win;
        this.remainPercentage = remainPercentage;
        this.fightPowerPercentage = fightPowerPercentage;
    }

    public PvpoccupyEvent(User owner, BattleResult battleResult) {
        super(owner);
        this.win = battleResult.getIsAttackerBattleWin();
        this.remainPercentage = 100 - (int) battleResult.getAttackArmy().lostPercentage();
        this.fightPowerPercentage = (battleResult.getDefenceOfficerAfterBattle().getFightPower() * 100) / battleResult.getAttackOfficerAfterBattle().getFightPower() - 100;
    }

    @Override
    public EventType getType() {
        return EventType.Pvpoccupy;
    }

    public boolean isWin() {
        return win;
    }

    public int getRemainPercentage() {
        return remainPercentage;
    }

    public int getFightPowerPercentage() {
        return fightPowerPercentage;
    }

}
