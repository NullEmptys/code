package com.hoolai.sangoh5.bo.battle.unit;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.fight.ActionType;
import com.hoolai.sangoh5.bo.battle.fight.BattleEnhance;
import com.hoolai.sangoh5.bo.battle.fight.BattleLog;
import com.hoolai.sangoh5.bo.battle.fight.HpLostListener;
import com.hoolai.sangoh5.bo.battle.fight.PositionManager;
import com.hoolai.sangoh5.bo.battle.skill.Occasion;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.skill.passive.AttributeEnhanceSkill;
import com.hoolai.sangoh5.bo.battle.skill.soldier.active.BaseSoldierPhysicsSkill;
import com.hoolai.sangoh5.bo.battle.skill.trigger.SoldierSkillTriger;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName.FightType;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.officer.SoldierBaseEnhance;
import com.hoolai.sangoh5.bo.soldier.FightSoldier;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.soldier.SoldierType.AttackType;
import com.hoolai.sangoh5.bo.soldier.data.SoldierData;
import com.hoolai.sangoh5.bo.soldier.data.SoldierProperty;
import com.hoolai.sangoh5.bo.tacticalManagement.Formation;

public class SoldierUnit extends FightUnit {

    private final SoldierType soldierType;

    private AttackType soldierFightType;

    private final FightUnitName name;

    private BaseSoldierPhysicsSkill soldierAttackSkill;

    private float beHurtedEhanceRate;

    private SoldierData soldierData;

    private transient FightSoldier fightSoldier;

    private transient SoldierProperty soldierProperty;

    public SoldierUnit(boolean isAttacker, int pos, int originalHp, SoldierType soldierType) {
        super(isAttacker, originalHp);
        this.soldierType = soldierType;
        this.name = FightUnitName.unitName(isAttacker, pos);
        //        this.recoverHpTop = originalHp;
        this.attackers = new ArrayList<FightUnit>();
    }

    public SoldierUnit(FightType fightType, Officer officer, FightSoldier fightSoldier, HpLostListener hpLostListener, BaseSoldierPhysicsSkill baseSoldierPhysicsSkill,
            BattleEnhance battleEnhance, BattleLog battleLog) {

        this(fightType == FightType.attack, fightSoldier.getPos(), fightSoldier.getOriginalNum(), fightSoldier.findSoldierType());
        Formation formation = officer.getCurrFormation();

        this.officer = officer;
        this.fightSoldier = fightSoldier;
        this.hpLostListener = hpLostListener;
        this.soldierAttackSkill = baseSoldierPhysicsSkill;
        this.initPos = fightSoldier.getPos();
        this.initPosition = formation.takeSoldierPos(fightSoldier.getPos(), fightType);
        this.initRow = formation.takeSoldierRow(fightSoldier.getPos());
        this.soldierFightType = soldierType.attackType();
        this.battleEnhance = battleEnhance;
        this.battleLog = battleLog;
    }

    @Override
    public void changeHp(int deltaHp) {
        if (isDead()) {
            return;
        }
        deltaHp = deltaHp < 0 ? deltaHp : calDeltaHp(deltaHp);//计算血量
        hpLostListenerApply(deltaHp);

        //        if (logger.isDebugEnabled()) {
        //        logger.debug(name.name()+"原血量："+hp+"，损失血量："+deltaHp+"，剩余血量："+(hp-deltaHp));
        //}
    }

    private void hpLostListenerApply(int deltaHp) {
        changeHp0(deltaHp);//改变生命值
    }

    private void changeHp0(int deltaHp) {
        this.hpLostListener.onHpLost(this.name(), deltaHp);
        this.hp = Math.min(this.originalHp, this.hp - deltaHp);
        if (isDead()) {
            this.die();
        }
    }

    public void die() {
        if (logger.isDebugEnabled()) {
            logger.debug(this.name + "死掉啦~~~~~~~~~~~~~~~~~~~~~~");
        }
        //        int leftHp = this.hp;
        this.hp = 0;

        this.clearAttackersStatus();
        lifecycleListener.onKnockedout(this);
    }

    private void clearAttackersStatus() {
        if (defender != null) {
            this.defender.removeAttacker(this);
            if (defender.getDefender() != null && defender.getDefender().name().equals(this.name)) {
                defender.setDefender(null);
            }
        }

        Iterator<FightUnit> iterator = attackers.iterator();
        while (iterator.hasNext()) {
            FightUnit unit = iterator.next();
            if (unit.name().equals(this.name)) {
                continue;
            }
            unit.setDefender(null);
        }

        iterator = companionAttacker.iterator();
        while (iterator.hasNext()) {
            FightUnit unit = iterator.next();
            if (unit.name().equals(this.name)) {
                continue;
            }
            unit.removeCompanionAttacker(this);
        }

        this.attackers.clear();
        this.companionAttacker.clear();
    }

    private int calDeltaHp(int deltaHp) {
        return (int) (deltaHp * (1 + this.beHurtedEhanceRate));// 造成伤害增加技能的效果
    }

    @Override
    public boolean isDead() {
        return hp < 1;
    }

    @Override
    public FightUnitName name() {
        return this.name;
    }

    @Override
    public Action action(int roundCounter) {
        Action action = null;
        actionCounter++;

        if (behavior.isSlince()) {
            if (soldierFightType == AttackType.LONG_RANGE || positionManager.isReachTargetPos()) {
                if (logger.isDebugEnabled()) {
                    logger.debug(roundCounter + "回合" + this.name + "眩晕，攻击停顿");
                }
                action = new Action(this, ActionType.ATTACK_IDLE, IndependentSkill.NONE);
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug(roundCounter + "回合" + this.name + "眩晕，移动停顿");
                }
                action = new Action(this, ActionType.MOVE_IDLE, IndependentSkill.NONE);
            }
            return action;
        }

        if (defender == null) {
            if (logger.isDebugEnabled()) {
                logger.debug(roundCounter + "回合" + this.name + "攻击目标" + positionManager.getLockActtackrName() + "死亡，攻击停顿");
            }
            action = new Action(this, ActionType.ATTACK_IDLE, IndependentSkill.NONE);
            return action;
        }

        //        if (logger.isDebugEnabled()) {
        //		logger.debug(String.format("actName : %s , acterCurPos : %s , actTarPos : %s , defName :< %s >, defCur : %s , defTarPos : %s ;", 
        //				name, Arrays.toString(positionManager.getCurrentPosition()),Arrays.toString(positionManager.getTargetPosition()), 
        //				defender.name(),Arrays.toString(defender.getPositionManager().getCurrentPosition()), Arrays.toString(defender.getPositionManager().getTargetPosition())));
        //    }
        if (soldierFightType == AttackType.LONG_RANGE) {
            action = attack(roundCounter);
        } else if (positionManager.isReachTargetPos() && defender != null && defender.getPositionManager().isReachTargetPos()) {
            action = attack(roundCounter);
        } else if (positionManager.isReachTargetPos() && defender != null && !defender.getPositionManager().isReachTargetPos()) {
            if (logger.isDebugEnabled()) {
                logger.debug(roundCounter + "回合" + this.name + "到达目标，等待对方到达");
            }
            action = new Action(this, ActionType.MOVE_IDLE, IndependentSkill.NONE);
        } else {
            attackRoundCounter = 0;
            positionManager.addCounter();
            int mod = Math.round(moveSpeed / ROUND_SPEND);
            if (positionManager.counter() % mod == 0) {
                //                if (logger.isDebugEnabled()) {
                //				logger.debug(roundCounter+"回合"+this.name+"移动"+ArrayUtils.toString(positionManager.expectNext()));
                //            }
                action = new Action(this, ActionType.MOVE, IndependentSkill.NONE);
            } else {
                //                if (logger.isDebugEnabled()) {
                //				logger.debug(roundCounter+"回合"+this.name+"移动停顿");
                //            }
                action = new Action(this, ActionType.MOVE_IDLE, IndependentSkill.NONE);
            }
        }

        return action;
    }

    private Action attack(int roundCounter) {
        Action action;
        if (attackRoundCounter == 0) {
            //            if (logger.isDebugEnabled()) {
            //			 logger.debug(roundCounter+"回合"+this.name+"跑到目标点开始攻击");
            //        }
            positionManager.clear();
            action = new Action(this, ActionType.ATTACK, useSkill());
        } else {
            float mod = attackSpeed / ROUND_SPEND;
            if (attackRoundCounter % mod == 0) {
                //                if (logger.isDebugEnabled()) {
                //				logger.debug(roundCounter+"回合"+this.name+"攻击");
                //            }
                //				action = new Action(this, ActionType.ATTACK, defender.isOfficer() ? useKillSoldierSkill() : useKillOfficerSkill());
                action = new Action(this, ActionType.ATTACK, useSkill());
            } else {
                //                if (logger.isDebugEnabled()) {
                //				logger.debug(roundCounter+"回合"+this.name+"攻击停顿");
                //            }
                action = new Action(this, ActionType.ATTACK_IDLE, IndependentSkill.NONE);
            }
        }
        attackRoundCounter++;
        return action;
    }

    private IndependentSkill useSkill() {
        if (behavior.isChenMo()) {
            return soldierAttackSkill;
        }
        IndependentSkill skill = trigger.triggerAttackSkill();
        return skill;
    }

    @Override
    protected void initAttributes() {
        SoldierBaseEnhance baseEnhance = officer.getSoldierBaseEnhance();
        SoldierBaseEnhance otherEnhance = officer.getSoldierOtherEnhance();

        this.baseAttackPoint = (fightSoldier.getBaseAttack() + baseEnhance.getAttackEnhanceValue(soldierType)) * (1 + baseEnhance.getAttackEnhanceRate(soldierType));
        this.baseDefencePoint = (fightSoldier.getBaseDefence() + baseEnhance.getDefenceEnhanceValue(soldierType)) * (1 + baseEnhance.getDefenceEnhanceRate(soldierType));

        this.attackPoint = baseAttackPoint * (1 + otherEnhance.getAttackEnhanceRate(soldierType)) + otherEnhance.getAttackEnhanceValue(soldierType);
        this.defencePoint = baseDefencePoint * (1 + otherEnhance.getDefenceEnhanceRate(soldierType)) + otherEnhance.getDefenceEnhanceValue(soldierType);

        fightSoldier.enhanceAttackAndDefence(attackPoint, defencePoint);

        this.soldierFightType = AttackType.convertToType(soldierProperty.getAttackType());
        this.moveSpeed = baseMoveSpeed = fightSoldier.getMoveSpeed();
        this.attackSpeed = baseAttackSpeed = fightSoldier.getAttackSpeed();
    }

    @Override
    public void init() {
        soldierProperty = soldierData.getProperty(fightSoldier.getXmlId());

        initPos();
        initAttributes();
        initSkills();

        if (logger.isDebugEnabled()) {
            logger.debug(name + "," + soldierType + "：攻击速度：【" + attackSpeed + "】,移动速度：【" + moveSpeed + "】,攻击力：" + this.attackPoint + ",防御力：" + this.defencePoint + ",血量:" + hp
                    + ",base攻击力：" + this.baseAttackPoint + ",base防御力：" + this.baseDefencePoint);
        }
        this.battleLog.add(name + "," + soldierType + "：攻击速度：【" + attackSpeed + "】,移动速度：【" + moveSpeed + "】,攻击力：" + this.attackPoint + ",防御力：" + this.defencePoint + ",血量:" + hp
                + ",base攻击力：" + this.baseAttackPoint + ",base防御力：" + this.baseDefencePoint);
    }

    private void initPos() {
        this.positionManager = new PositionManager(this);
        this.fightSoldier.setInitPos(initPosition);
        setPosition(initPosition[0], initPosition[1]);
        setCurrentPosition(initPosition[0], initPosition[1]);
        setLockTargetInitPos(initPosition[0], initPosition[1]);
    }

    public void setPosition(int x, int y) {
        int position[] = { x, y };
        this.positionManager.setPosition(position);
    }

    public void setCurrentPosition(int x, int y) {
        int position[] = { x, y };
        this.positionManager.setCurrentPosition(position);
    }

    public void setLockTargetInitPos(int x, int y) {
        int position[] = { x, y };
        this.positionManager.setLockTargetInitPos(position);
    }

    //	public void addAttacker(FightUnit fightUnit){
    //		this.attackers.add(fightUnit);
    //		if (!this.attackers.contains(fightUnit)) {
    //            this.attackers.add(fightUnit);
    //            fightUnit.defender = this;
    //
    //            if (this.attackers.size() > 1) {
    //                convergeAttack();
    //            }
    //        }
    //	}

    //    private void convergeAttack() {
    //        this.isConvergedAttacking = true;
    //
    //    }

    public FightUnit firstAttacker() {
        return attackers.get(0);
    }

    @Override
    public void removeAttacker(FightUnit unit) {
        Iterator<FightUnit> it = attackers.iterator();
        while (it.hasNext()) {
            if (it.next() == unit) {
                it.remove();
                return;
            }
        }
    }

    public AttackType getSoldierFightType() {
        return soldierFightType;
    }

    public void setSoldierData(SoldierData soldierData) {
        this.soldierData = soldierData;
    }

    @Override
    public int getXmlId() {
        return fightSoldier.getXmlId();
    }

    @Override
    public void initSkills() {
        int[] skills = fightSoldier.getSkills();
        List<Skill> battleEnhaceSkills = battleEnhance.getSoldierEnhanceSkill(soldierType);
        List<Skill> otherEnhaceSkills = battleEnhance.getSoldierOtherEnhanceSkills(soldierType);

        this.activeSkills = skillData.findActiveSkills(skills, battleEnhaceSkills, otherEnhaceSkills);//获取这个兵种的主动技能
        this.passiveSkills = skillData.findPassiveSkills(skills, battleEnhaceSkills, otherEnhaceSkills);//获取这个兵种的被动技能
        this.counterAttackSkills = skillData.findCounterAttackSkills(skills, battleEnhaceSkills, otherEnhaceSkills);

        this.trigger = new SoldierSkillTriger(this, soldierAttackSkill.getRestraintFinder(), pg, activeSkills);//士兵的触发器
    }

    @Override
    public float baseAttackPoint() {
        return this.baseAttackPoint;
    }

    @Override
    public float baseDefencePoint() {
        return baseDefencePoint;
    }

    @Override
    public float baseHp() {
        return this.originalHp;
    }

    @Override
    public void applyBeforeBattleSkill(TargetCollection tc) {
        for (AttributeEnhanceSkill skill : this.passiveSkills) {
            if (Occasion.BEFORE_BATTLE == skill.getOccasion()) {
                skill.apply(this, tc);
            }
        }
    }

    @Override
    public DefenceSkill useDefenceSkill() {
        return trigger.triggerDefenceSkill();
    }

    @Override
    public List<FightUnit> targetEnhance(FightUnit actor, FightUnit target, TargetCollection targetCollection, Action action) {
        List<FightUnit> fightUnits = new ArrayList<FightUnit>();
        for (Buff buff : buffList) {
            fightUnits.addAll(buff.targetEnhance(actor, target, targetCollection, action));
        }
        return super.targetEnhance(actor, target, targetCollection, action);
    }

    @Override
    public float baseAttackSpeed() {
        return baseAttackSpeed;
    }

    @Override
    public float baseMoveSpeed() {
        return baseMoveSpeed;
    }

    public SoldierType getSoldierType() {
        return soldierType;
    }

    @Override
    public void processStealSkillEffects(TargetCollection tc) {
        return;
    }

    public BaseSoldierPhysicsSkill getSoldierAttackSkill() {
        return soldierAttackSkill;
    }

}
