package com.hoolai.sangoh5.bo.shop.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * 友情商店配置表
 * 
 * @author hp
 *
 */
public class FriendShipShopProperty extends JsonProperty {
	
	private String type;//道具类型
	private int costAmount;//所需友情点数
	private int onSale;//是否可以出售
	private int unlockLv;//道具可出售的等级限制

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getCostAmount() {
		return costAmount;
	}

	public void setCostAmount(int costAmount) {
		this.costAmount = costAmount;
	}

	public int getOnSale() {
		return onSale;
	}

	public void setOnSale(int onSale) {
		this.onSale = onSale;
	}

	public int getUnlockLv() {
		return unlockLv;
	}

	public void setUnlockLv(int unlockLv) {
		this.unlockLv = unlockLv;
	}

	
}
