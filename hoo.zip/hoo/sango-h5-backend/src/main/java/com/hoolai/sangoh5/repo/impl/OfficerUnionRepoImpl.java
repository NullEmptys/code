package com.hoolai.sangoh5.repo.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.sangoh5.bo.officerunion.OfficerUnions;
import com.hoolai.sangoh5.bo.officerunion.data.OfficerUnionData;
import com.hoolai.sangoh5.repo.OfficerUnionRepo;
import com.hoolai.sangoh5.repo.impl.key.OfficerUnionKey;

@Repository("officerUnionRepo")
public class OfficerUnionRepoImpl implements OfficerUnionRepo {

    @Autowired
    private OfficerUnionData officerUnionData;

    @Autowired
    @Qualifier("itemClient")
    private ExtendedMemcachedClient client;

    @Override
    public OfficerUnions findOfficerUnions(long userId) {
        String key = OfficerUnionKey.findOfficerUninsKey(userId);
        Object o = client.get(key);
        OfficerUnions officerUnions = null;
        if (o != null) {
            officerUnions = officerUnionData.updateOfficerUnions(new OfficerUnions((byte[]) o));
        }
        return officerUnions;
    }

    @Override
    public void saveOfficerUnions(OfficerUnions officerUnions) {
        String key = OfficerUnionKey.findOfficerUninsKey(officerUnions.getUserId());
        client.set(key, officerUnions.toByteArray());
    }

}
