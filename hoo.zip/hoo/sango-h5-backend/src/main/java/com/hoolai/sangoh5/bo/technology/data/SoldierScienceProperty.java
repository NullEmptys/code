package com.hoolai.sangoh5.bo.technology.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class SoldierScienceProperty extends JsonProperty {

    private String name;

    private int scienceId;

    private int level;

    private int maxlevel;

    private int tab;

    private String type;

    private int effectId;

    private float num;

    private String front;

    private int time;

    private int sciece;

    private int nextLv;

    public enum ScienceType {
        BATTLEEFFECT, LEVELUP, ADD;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScienceId() {
        return scienceId;
    }

    public void setScienceId(int scienceId) {
        this.scienceId = scienceId;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getTab() {
        return tab;
    }

    public void setTab(int tab) {
        this.tab = tab;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getMaxlevel() {
        return maxlevel;
    }

    public void setMaxlevel(int maxlevel) {
        this.maxlevel = maxlevel;
    }

    public int getEffectId() {
        return effectId;
    }

    public void setEffectId(int effectId) {
        this.effectId = effectId;
    }

    public float getNum() {
        return num;
    }

    public void setNum(float num) {
        this.num = num;
    }

    public String getFront() {
        return front;
    }

    public void setFront(String front) {
        this.front = front;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getSciece() {
        return sciece;
    }

    public void setSciece(int sciece) {
        this.sciece = sciece;
    }

    /**
     * 其实是上一级
     * 
     * @return
     */
    public int getNextLv() {
        return nextLv;
    }

    public void setNextLv(int nextLv) {
        this.nextLv = nextLv;
    }

    public boolean isAnd() {
        return front.contains("&");
    }

    public int[] fronts() {
        String[] strArr = null;
        if (isAnd()) {
            strArr = front.split("\\&");
        } else {
            strArr = front.split("\\|");
        }
        int[] arr = new int[strArr.length];
        int i = 0;
        for (String str : strArr) {
            arr[i++] = Integer.valueOf(str);
        }
        return arr;
    }

}
