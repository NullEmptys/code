package com.hoolai.sangoh5.bo.item.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.Constant;
import com.hoolai.sangoh5.bo.officer.data.RecruitGoodsData;
import com.hoolai.sangoh5.util.json.JsonData;


@Component
public class BoxData extends JsonData<BoxProperty>{
	
	@Autowired
	private RecruitGoodsData recruitGoodsData;

	@PostConstruct
    public void init(){
    	try {
    		initData("com/hoolai/sangoh5/box.json", BoxProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
	
	public int randomBoxItem(int boxId){
		BoxProperty boxProperty = getProperty(boxId);
		int skillPro = boxProperty.getSkillPro();
		int boxLvIndex = Constant.pg.getRandomChoiceWithPercentArr(boxProperty.getLvPro());
		if(Constant.pg.getRandomWithPercentage(skillPro)){
			return recruitGoodsData.randomBoxItem("skills", boxProperty.getGoodsLv()[boxLvIndex]);
		}else{
			return recruitGoodsData.randomBoxItem("item", boxProperty.getGoodsLv()[boxLvIndex]);
		}
	}

	@Override
	protected void checkProperty(BoxProperty property) {
		// TODO Auto-generated method stub
		
	}
	
}
