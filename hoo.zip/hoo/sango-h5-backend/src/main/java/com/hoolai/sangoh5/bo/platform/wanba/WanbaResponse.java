package com.hoolai.sangoh5.bo.platform.wanba;

public class WanbaResponse {

	public static final int SUCCESS_CODE = 0;
	public static final int ERROR_CODE = -1;
	public static final int NOT_LOGIN = 1002;
	
	protected int code = ERROR_CODE;
	protected int subcode;
	protected String message;
	
	public WanbaResponse(){
		
	}
	
	protected WanbaResponse(int code){
		this.code = code;
	}
	
	public boolean isValid(){
		return code == SUCCESS_CODE;
	}
	
	public boolean noLogin(){
		return code == NOT_LOGIN;
	}
	
	@Override
	public String toString() {
		return "TencentWanbaResponse [code=" + code + ", message=" + message + ", subcode=" + subcode + "]";
	}
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public int getSubcode() {
		return subcode;
	}
	public void setSubcode(int subcode) {
		this.subcode = subcode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
