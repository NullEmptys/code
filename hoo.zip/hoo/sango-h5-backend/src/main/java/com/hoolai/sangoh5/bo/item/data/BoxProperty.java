package com.hoolai.sangoh5.bo.item.data;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.util.json.JsonProperty;

public class BoxProperty extends JsonProperty {

    private String name;

    private String type;

    private int[] rewardId;

    private int[] rewardNum;

    private String[] rewardType;

    private int requireItem;

    private int[] skillsQuantity;

    private int skillsNum;

    private int skillPro;

    private int[] goodsLv;

    private int[] lvPro;

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    public int[] getRewardId() {
        return rewardId;
    }

    public void setRewardId(int[] rewardId) {
        this.rewardId = rewardId;
    }

    public int[] getRewardNum() {
        return rewardNum;
    }

    public void setRewardNum(int[] rewardNum) {
        this.rewardNum = rewardNum;
    }

    public String[] getRewardType() {
        return rewardType;
    }

    public void setRewardType(String[] rewardType) {
        this.rewardType = rewardType;
    }

    public int getRequireItem() {
        return requireItem;
    }

    public void setRequireItem(int requireItem) {
        this.requireItem = requireItem;
    }

    public int getSkillPro() {
        return skillPro;
    }

    public void setSkillPro(int skillPro) {
        this.skillPro = skillPro;
    }

    public int[] getGoodsLv() {
        return goodsLv;
    }

    public void setGoodsLv(int[] goodsLv) {
        this.goodsLv = goodsLv;
    }

    public int[] getLvPro() {
        return lvPro;
    }

    public void setLvPro(int[] lvPro) {
        this.lvPro = lvPro;
    }

    public int[] getSkillsQuantity() {
        return skillsQuantity;
    }

    public void setSkillsQuantity(int[] skillsQuantity) {
        this.skillsQuantity = skillsQuantity;
    }

    public int getSkillsNum() {
        return skillsNum;
    }

    public void setSkillsNum(int skillsNum) {
        this.skillsNum = skillsNum;
    }

    public List<Award> getAwards(int times) {
        List<Award> items = new ArrayList<Award>();

        String type[] = rewardType;
        int reAward[] = rewardId;
        int num[] = rewardNum;

        for (int i = 0; i < type.length; i++) {
            items.add(new Award(reAward[i], num[i] * times, AwardType.converToAwardType(type[i])));
        }
        return items;
    }
}
