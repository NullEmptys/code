package com.hoolai.sangoh5.bo.user;

import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import com.hoolai.sango.util.DateUtil;
import com.hoolai.sangoh5.util.IdCardValidator;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.util.TimeUtil;

public class AntiInfo {

    public static final long THREE_HOUR = TimeUnit.HOURS.toMillis(3);

    public static final long FIVE_HOUR = TimeUnit.HOURS.toMillis(5);

    private static final long REMIND_INTERVAL = TimeUnit.HOURS.toMillis(1);//TimeUnit.MINUTES.toMillis(1);

    private final long userId;

    private long gameTime;

    private long remindTime;

    private int remindCount;

    private int lastUpdateTime;

    private boolean checkEnter;

    private long leaveTime;

    public AntiInfo(long userId) {
        this.userId = userId;
        remindTime = gameTime + REMIND_INTERVAL;
    }

    public boolean refresh() {
        int todayIntValue = DateUtil.getTodayIntValue();
        if (todayIntValue > lastUpdateTime) {
            lastUpdateTime = todayIntValue;
            resetGameTime();
            return true;
        }
        return false;
    }

    public void incrGameTime(long value) {
        gameTime += value;
        System.out.println(getActualGameTimeStr());
        if (gameTime >= FIVE_HOUR && !checkEnter) {
            checkEnter = true;
            leaveTime = TimeUtil.currentTimeMillis();
        }
    }

    public int affectIncome(int num) {
        return affectIncome(gameTime, num);
    }

    public static int affectIncome(long gameTime, int num) {
        if (gameTime >= 0 && gameTime < THREE_HOUR) {
            System.out.println("影响收益不变num=" + num);
            return num;
        } else if (gameTime >= THREE_HOUR && gameTime < FIVE_HOUR) {
            System.out.println("影响收益减半num=" + num / 2);
            return num / 2;
        } else {
            System.out.println("影响收益为0");
            return 0;
        }
    }

    public boolean remind() {
        return gameTime >= remindTime;
    }

    //特殊处理进行取整给前端显示
    public long getGameTime() {
        if (remindCount == 0) {
            return gameTime;
        } else if (remindCount > 0 && remindCount <= 3) {
            return TimeUnit.HOURS.toMillis(remindCount);
        } else if (remindCount > 3 && remindCount <= 7) {
            return TimeUnit.HOURS.toMillis(3) + TimeUnit.MINUTES.toMillis((remindCount - 3) * 30);
        } else {
            return TimeUnit.HOURS.toMillis(5) + TimeUnit.MINUTES.toMillis((remindCount - 7) * 15);
        }
    }

    public String getActualGameTimeStr() {
        return "userId=" + userId + "在线" + timeStr(gameTime);
    }

    public static void main(String[] args) {
        //		AntiInfo antiInfo = new AntiInfo(1);
        //		for(int i=0;i<10;i++){
        //			antiInfo.recordRemindTime();
        //			System.out.println(TimeUnit.MILLISECONDS.toMinutes(antiInfo.getGameTime()));
        //		}

        //		long t = TimeUnit.HOURS.toMillis(3) + TimeUnit.MINUTES.toMillis(58) + TimeUnit.SECONDS.toMillis(12);
        //		
        //		long hour = TimeUnit.MILLISECONDS.toHours(t);
        //		long minute = TimeUnit.MILLISECONDS.toMinutes(t-TimeUnit.HOURS.toMillis(hour));
        //		long second = TimeUnit.MILLISECONDS.toSeconds(t-TimeUnit.HOURS.toMillis(hour)-TimeUnit.MINUTES.toMillis(minute));
        //		System.out.println(hour+"小时"+minute+"分钟"+second+"秒");
        //		
        //		System.out.println(TimeUnit.MILLISECONDS.toMillis(t));
        //		System.out.println(TimeUnit.MILLISECONDS.toSeconds(t));
        //		System.out.println(TimeUnit.MILLISECONDS.toMinutes(t));
        //		System.out.println(TimeUnit.MILLISECONDS.toHours(t));
        //		
        //		System.out.println(timeStr(t));

        System.out.println(affectIncome(TimeUnit.HOURS.toMillis(-2), 10));
        System.out.println(affectIncome(TimeUnit.HOURS.toMillis(-1), 10));
        System.out.println(affectIncome(TimeUnit.HOURS.toMillis(0), 10));
        System.out.println(affectIncome(TimeUnit.HOURS.toMillis(1), 10));
        System.out.println(affectIncome(TimeUnit.HOURS.toMillis(2), 10));
        System.out.println(affectIncome(TimeUnit.HOURS.toMillis(3), 10));
        System.out.println(affectIncome(TimeUnit.HOURS.toMillis(4), 10));
        System.out.println(affectIncome(TimeUnit.HOURS.toMillis(5), 10));
        System.out.println(affectIncome(TimeUnit.HOURS.toMillis(6), 10));
        System.out.println(affectIncome(TimeUnit.HOURS.toMillis(7), 10));
    }

    public static String timeStr(long t) {
        long hour = TimeUnit.MILLISECONDS.toHours(t);
        long minute = TimeUnit.MILLISECONDS.toMinutes(t - TimeUnit.HOURS.toMillis(hour));
        long second = TimeUnit.MILLISECONDS.toSeconds(t - TimeUnit.HOURS.toMillis(hour) - TimeUnit.MINUTES.toMillis(minute));
        return hour + "小时" + minute + "分钟" + second + "秒";
    }

    public long getUserId() {
        return userId;
    }

    private long hadLeaveTime;

    public boolean canEnter() {
        if (!checkEnter) {
            return true;
        }

        hadLeaveTime = TimeUtil.currentTimeMillis() - leaveTime;

        return hadLeaveTime >= FIVE_HOUR;
    }

    public String getHadLeaveTimeStr() {
        return timeStr(hadLeaveTime);
    }

    public void resetGameTime() {
        gameTime = 0;
        remindCount = 0;
        remindTime = gameTime + REMIND_INTERVAL;

        checkEnter = false;
        leaveTime = 0;
    }

    public void recordRemindTime() {
        remindCount++;
        remindTime = gameTime + //REMIND_INTERVAL;
                (remindCount >= 3 ? remindCount >= 7 ? TimeUnit.MINUTES.toMillis(15) : TimeUnit.MINUTES.toMillis(30) : REMIND_INTERVAL);
        System.out.println("remindCount=" + remindCount + ", remindTime=" + timeStr(remindTime));
    }

    public static void checkRealName(String realName) {
        if (!isRealName(realName)) {
            throw new BusinessException(ErrorCode.ERROR_REAL_NAME);
        }
    }

    public static boolean isRealName(String realName) {
        Pattern pattern = Pattern.compile("[\u4E00-\u9FA5]{2,5}(?:·[\u4E00-\u9FA5]{2,5})*");
        if (pattern.matcher(realName).matches()) {
            return true;
        }
        return false;
    }

    public static void checkIsIdCard(String idCard) {
        if (!isIdCard(idCard)) {
            throw new BusinessException(ErrorCode.ERROR_ID_CARD);
        }
    }

    public static boolean isIdCard(String idCard) {
        return new IdCardValidator().isValidatedAllIdcard(idCard);
    }

}
