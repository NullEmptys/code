package com.hoolai.sangoh5.bo.battle.fight;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.ActionResultProto;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.EffectProto;
import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 一次Action（动作）的结果 <br/>
 * 可以扩展，加上特殊的动作结果
 * 
 * @author joseph
 * 
 */
public class ActionResult implements ProtobufSerializable<ActionResultProto> {

    private int skillXmlId;//if == 0 普通攻击

    private FightUnitName actorName;

    private List<Effect> effectList = new ArrayList<Effect>();

    private List<Buff> buffList = new ArrayList<Buff>();

    private ActionType actionType;

    private ActionResult next;

    private boolean isHaveNewTarget;

    private PositionManager positionManager;

    private int currentLevel;

    public int getSkillXmlId() {
        return skillXmlId;
    }

    public void setSkillXmlId(int skillXmlId) {
        this.skillXmlId = skillXmlId;
    }

    public FightUnitName getActorName() {
        return actorName;
    }

    public void setActorName(FightUnitName actorName) {
        this.actorName = actorName;
    }

    public List<Effect> getEffectList() {
        return effectList;
    }

    public void setEffectList(List<Effect> effectList) {
        this.effectList = effectList;
    }

    public ActionType getActionType() {
        return actionType;
    }

    public void setActionType(ActionType actionType) {
        this.actionType = actionType;
    }

    public List<Buff> getBuffList() {
        return buffList;
    }

    public void setBuffList(List<Buff> buffList) {
        this.buffList = buffList;
    }

    public ActionResult getNext() {
        return next;
    }

    public void setNext(ActionResult next) {
        this.next = next;
    }

    public PositionManager getPositionManager() {
        return positionManager;
    }

    public void setPositionManager(PositionManager positionManager) {
        this.positionManager = positionManager;
    }

    public boolean getIsHaveNewTarget() {
        return isHaveNewTarget;
    }

    public void setIsHaveNewTarget(boolean isHaveNewTarget) {
        this.isHaveNewTarget = isHaveNewTarget;
    }

    @Override
    public String toString() {
        return "ActionResult [actorName=" + actorName + ", buffList=" + buffList + ", effectList=" + effectList + ", actionType=" + actionType + ", skillXmlId=" + skillXmlId + "]";
    }

    public ActionResult(ActionResultProto message) {
        copyFrom(message);
    }

    public ActionResult() {
    }

    public ActionResult(int skillId, FightUnitName actorName, ActionType actionType, int currentLevel) {
        this.skillXmlId = skillId;
        this.actorName = actorName;
        this.actionType = actionType;
        this.currentLevel = currentLevel;
    }

    @Override
    public void copyFrom(ActionResultProto message) {
        this.skillXmlId = message.getSkillXmlId();//if == 0 普通攻击
        this.actorName = FightUnitName.valueOf(message.getActorName());

        int count = message.getEffectListCount();
        if (count > 0) {
            this.effectList = new ArrayList<Effect>();
            for (int i = 0; i < count; i++) {
                effectList.add(new Effect(message.getEffectList(i)));
            }
        }

        int count1 = message.getBuffListCount();
        if (count1 > 0) {
            this.buffList = new ArrayList<Buff>();
            for (int i = 0; i < count1; i++) {
                buffList.add(new Buff(message.getBuffList(i)));
            }
        }

        this.actionType = ActionType.valueOf(message.getActionType());
        if (message.hasNext()) {
            this.next = new ActionResult(message.getNext());
        }
        this.isHaveNewTarget = message.getIsHaveNewTarget();
        this.positionManager = new PositionManager(message.getPositionManager());
    }

    @Override
    public ActionResultProto copyTo() {
        ActionResultProto.Builder builder = ActionResultProto.newBuilder();
        builder.setActionType(actionType.name());
        if (actorName != null) {
            builder.setActorName(actorName.name());
        }
        if (effectList != null && !effectList.isEmpty()) {
            for (Effect w : effectList) {
                builder.addEffectList((EffectProto) w.copyTo());
            }
        }
        if (buffList != null && !buffList.isEmpty()) {
            for (Buff w : buffList) {
                builder.addBuffList(w.copyTo());
            }
        }
        builder.setSkillXmlId(skillXmlId);
        if (positionManager != null) {
            builder.setPositionManager(positionManager.copyTo());
        }
        if (next != null) {
            builder.setNext(next.copyTo());
        }
        builder.setIsHaveNewTarget(isHaveNewTarget);
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] arg0) {
        try {
            ActionResultProto message = ActionResultProto.parseFrom(arg0);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    public int getCurrentLevel() {
        return currentLevel;
    }

    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
    }

    public boolean isHaveDynamics() {
        return effectList.size() > 0 || buffList.size() > 0 || getIsHaveNewTarget();
    }

}
