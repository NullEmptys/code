package com.hoolai.sangoh5.bo.platform;

public enum Platform {

    local(-100), xiaoyou(0), qzone(1), kaixin(2), manyou(3), qplus(4), wanba_ts(5), localtest(6), wechat(7);

    public final int type;

    private Platform(int type) {
        this.type = type;
    }

}
