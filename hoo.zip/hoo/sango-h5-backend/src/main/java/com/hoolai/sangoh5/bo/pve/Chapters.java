package com.hoolai.sangoh5.bo.pve;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.ChaptersProto;
import com.hoolai.sangoh5.bo.pve.data.ChapterData;
import com.hoolai.sangoh5.bo.pve.data.PveData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Chapters implements ProtobufSerializable<ChaptersProto> {

    public static final int CHAPTER_SPACE = 100;

    /**
     * 当前打到的最大篇章ID
     */
    private int maxChapterId;

    private List<Chapter> chapters = new ArrayList<Chapter>();

    private transient Map<Integer, Chapter> chapterMap = Maps.newHashMap();

    private transient long userId;

    transient private ChapterData chapterData;

    transient private PveData pveData;

    public Chapters() {
    }

    public Chapters(long userId, byte[] bytes) {
        this.userId = userId;
        parseFrom(bytes);
    }

    public Chapters(long userId) {
        this.userId = userId;
    }

    public Chapter findChapter(int chapterId) {
        return chapterMap.get(chapterId);
    }

    public Chapter checkAndFindChapter(int chapterId) {
        if (maxChapterId < chapterId) {
            throw new BusinessException(ErrorCode.NO_REACH_CHAPTER);
        }
        Chapter chapter = findChapter(chapterId);
        if (chapter == null) {
            if (chapterId == maxChapterId && chapters.size() == 0) {// 第一个篇章
                chapter = new Chapter(chapterId);
                addChapter(chapter);
            } else if ((maxChapterId + CHAPTER_SPACE) == chapterId) {//当前篇章的下一个篇章
                // 查找当前篇章是否已经通关
                Chapter maxChapter = findChapter(maxChapterId);
                int[] statges = chapterData.getProperty(maxChapterId).getStageId();
                if (maxChapter.getMaxBarrierId() == statges[statges.length - 1]) {
                    // 如果已经通关
                    chapter = new Chapter(chapterId);
                    addChapter(chapter);
                } else {
                    // 如果没有，报错
                    throw new BusinessException(ErrorCode.NO_REACH_CHAPTER);
                }
            } else if ((maxChapterId + CHAPTER_SPACE) < chapterId) {
                // 报错，不能跳着打
                throw new BusinessException(ErrorCode.NO_REACH_CHAPTER);
            }
        }
        return chapter;
    }

    private void addChapter(Chapter chapter) {
        this.chapters.add(chapter);
        this.chapterMap.put(chapter.getChapterId(), chapter);
    }

    public int getMaxBarrierId() {
        Chapter chapter = this.findChapter(this.getMaxChapterId());
        int maxBarrierId = 0;
        if (chapter != null) {
            maxBarrierId = chapter.getMaxBarrierId();
            int[] tempidSortArr = chapterData.idSortArr();
            if (chapter.getMaxBarrierId() == 0 && chapter.getChapterId() != tempidSortArr[0]) {
                maxBarrierId = this.findChapter(this.getMaxChapterId() - Chapters.CHAPTER_SPACE).getMaxBarrierId();
            }
        }
        return maxBarrierId;
    }

    @Override
    public ChaptersProto copyTo() {
        ChaptersProto.Builder builder = ChaptersProto.newBuilder();
        builder.setMaxChapterId(maxChapterId);
        for (Chapter chapter : chapters) {
            builder.addChapters(chapter.copyTo());
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ChaptersProto message = ChaptersProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(ChaptersProto message) {
        this.maxChapterId = message.getMaxChapterId();
        int len = message.getChaptersCount();
        for (int i = 0; i < len; i++) {
            Chapter chapter = new Chapter(message.getChapters(i), pveData);
            addChapter(chapter);
        }
    }

    public int getMaxChapterId() {
        return maxChapterId;
    }

    public void setMaxChapterId(int maxChapterId) {
        this.maxChapterId = maxChapterId;
    }

    public List<Chapter> getChapters() {
        return chapters;
    }

    public void setChapters(List<Chapter> chapters) {
        this.chapters = chapters;
    }

    public long getUserId() {
        return userId;
    }

    public void setChapterData(ChapterData chapterData) {
        this.chapterData = chapterData;
    }

    public void setPveData(PveData pveData) {
        this.pveData = pveData;
    }

    public void clearHeroAttackNum() {
        for (Chapter chapter : chapters) {
            chapter.clearHeroAttackNum();
        }
    }

}
