package com.hoolai.sangoh5.repo.impl;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.hoolai.keyvalue.memcached.ExtendedMemcachedClient;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.adddesktopstatus.AddDesktopStatus;
import com.hoolai.sangoh5.repo.AddDesktopRepo;
import com.hoolai.sangoh5.repo.impl.key.AddDesktopKey;

@Repository("addDesktopRepo")
public class AddDesktopRepoImpl implements AddDesktopRepo{
	
	@Autowired
    @Qualifier("itemClient")
    private ExtendedMemcachedClient client;

	@Override
	public AddDesktopStatus findAddDesktop(long userId) {
		String key = AddDesktopKey.getAddDesktopKey(userId);
		client.get(key);
		byte[] bytes = (byte[])client.get(key);
		if(bytes == null){
			AddDesktopStatus addDesktopStatus = new AddDesktopStatus(userId);
			client.add(key, addDesktopStatus.toByteArray());
			return addDesktopStatus;
		}
		AddDesktopStatus addDesktopStatus = new AddDesktopStatus(userId, bytes);
		if(isOverBomdTime(addDesktopStatus)){
			addDesktopStatus.setAddDesktopStatus(4);
			saveAddDesktop(addDesktopStatus);
		}
		return addDesktopStatus;
	}

	/**
	 * 过了强弹时间
	 * @param addDesktopStatus
	 * @return
	 */
	private boolean isOverBomdTime(AddDesktopStatus addDesktopStatus) {
		return addDesktopStatus.getAddDesktopStatus() ==1 && addDesktopStatus.getTime() != 0 && (TimeUtil.currentTimeMillis() - addDesktopStatus.getTime() > TimeUnit.DAYS.toMillis(3));
	}

	@Override
	public void saveAddDesktop(AddDesktopStatus addDesktopStatus) {
		String key = AddDesktopKey.getAddDesktopKey(addDesktopStatus.getUserId());
		client.set(key, addDesktopStatus.toByteArray());
	}

}
