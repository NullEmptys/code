package com.hoolai.sangoh5.bo.user;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.VipProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Vip implements ProtobufSerializable<VipProto> {

    private boolean isVip;

    private int vipLevel;

    public Vip(Vip vip) {
        if (vip != null) {
            this.isVip = vip.isVip;
            this.vipLevel = vip.vipLevel;
        }
    }

    public Vip() {
    }

    public Vip(VipProto vip) {
        this.copyFrom(vip);
    }

    public boolean getIsVip() {
        return isVip;
    }

    public void setIsVip(boolean isVip) {
        this.isVip = isVip;
    }

    public int getVipLevel() {
        return vipLevel;
    }

    public void setVipLevel(int vipLevel) {
        this.vipLevel = vipLevel;
    }

    @Override
    public void copyFrom(VipProto message) {
        this.isVip = message.getIsVip();
        this.vipLevel = message.getVipLevel();
    }

    @Override
    public VipProto copyTo() {
        VipProto.Builder builder = VipProto.newBuilder();
        builder.setIsVip(isVip);
        builder.setVipLevel(vipLevel);
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] data) {
        try {
            VipProto message = VipProto.parseFrom(data);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

}
