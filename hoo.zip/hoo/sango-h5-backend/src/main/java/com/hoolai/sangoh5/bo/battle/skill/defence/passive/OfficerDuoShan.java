package com.hoolai.sangoh5.bo.battle.skill.defence.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.soldier.DuoShanBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class OfficerDuoShan extends DefencePassiveSkill {

    @Override
    public void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {

        DuoShanBuff duoshanBuff = (DuoShanBuff) target.findBuff(xmlId);
        if (duoshanBuff == null) {
            if (pg.getRandomWithPercentage(chance)) {
                if (buff != null) {
                    buff.clear(tc);
                    target.removeBuff(buff);
                }

                target.addBuff(new DuoShanBuff(xmlId, name, target.name(), currentLevel).withChance(chance).withActorName(actor.name()).withTargetName(target.name())
                        .withKeepBuff().withRepeatCount(twoRepeatCount));

                effect.setDeltaHp(0);
                target.changeSkillChance(xmlId, -chance);

                target.addBattleLog(target.name() + "使用" + this.xmlId + "[" + this.name + "]完全抵御了" + actor.name() + "的伤害");
            }
        } else {
            if (twoRepeatCount - duoshanBuff.getRepeatCount() <= repeatCount) {
                if (pg.getRandomWithPercentage(duoshanBuff.getChance())) {
                    if (buff != null) {
                        buff.clear(tc);
                        target.removeBuff(buff);
                    }
                    effect.setDeltaHp(0);
                    duoshanBuff.needRepeatPlay();
                    target.addBattleLog(target.name() + "使用" + this.xmlId + "[" + this.name + "]完全抵御了" + actor.name() + "的伤害");
                }
            }
        }
    }

    @Override
    public Skill clone() {
        return super.clone(new OfficerDuoShan());
    }

}
