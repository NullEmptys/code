package com.hoolai.sangoh5.bo.platform.wanba;

import com.hoolai.platform.RequestInfo;

public interface WanbaPlatformService {

	WanbaUserScoreResponse findWanbaUserScore(RequestInfo requestInfo, int zoneid);
	
	WanbaBuyItemResponse buyWanbaItem(RequestInfo requestInfo, int zoneid, int itemid, int count);

	WanbaBuyItemResponse buyWanbaItem(RequestInfo requestInfo, int zoneid,
			int itemid, int count, String billno);
	
}
