package com.hoolai.sangoh5.bo.officer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.OfficerLimitationProto;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.util.TimeUtil;

public class OfficerLimitation implements ProtobufSerializable<OfficerLimitationProto> {

    public static final long FIVE_MINUTE = 5l * 60l * 1000l;

    public static final long oneHourToMil = 60l * 60l * 1000l;

    @JsonIgnore
    transient private long userId;

    /** 月长石已经招募将领免费次数（每天更新清零） */
    private int tokenRecrNum;

    /** 今天令牌免费招募的总次数（根据计算得出的 不用存数据库） */
    private int tokenRecrTotalNum;

    /** 下一次元宝可免费招募将领的时间 */
    @JsonIgnore
    private long nextYbRecrOffTime;

    /** 下一次令牌可免费招募将领的时间 */
    @JsonIgnore
    private long nextTokenRecrTime;

    /** 蓝田玉免费招募剩余时间 */
    transient private long leftYbRecrTime;

    /** 月长石招募免费招募剩余时间 */
    transient private long leftTokenRecrTime;

    /** 10次必出3星将 */
    private int oneDiamondRecruitNum;

    /** 首次蓝田玉单抽必得1-2星将 */
    private boolean firstOneDiamondRecruit;

    public OfficerLimitation() {
    }

    public OfficerLimitation(long userId, int totalTokenRecrNum) {
        this();
        this.userId = userId;
        tokenRecrTotalNum = totalTokenRecrNum;
    }

    public OfficerLimitation(long userId, byte[] data, int totalTokenRecrNum) {
        this(userId, totalTokenRecrNum);
        parseFrom(data);
        this.refresh();
    }

    public void refresh() {
        this.leftYbRecrTime = Math.max(nextYbRecrOffTime - TimeUtil.currentTimeMillis(), 0) / 1000;
        this.leftTokenRecrTime = Math.max(nextTokenRecrTime - TimeUtil.currentTimeMillis(), 0) / 1000;
        if (this.tokenRecrNum >= tokenRecrTotalNum) {
            this.leftTokenRecrTime = 0;
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public OfficerLimitationProto copyTo() {
        OfficerLimitationProto.Builder builder = OfficerLimitationProto.newBuilder();
        builder.setNextYbRecrOffTime(nextYbRecrOffTime);
        builder.setTokenRecrNum(tokenRecrNum);
        builder.setNextTokenRecrTime(nextTokenRecrTime);
        builder.setOneDiamondRecruitNum(oneDiamondRecruitNum);
        builder.setFirstOneDiamondRecruit(firstOneDiamondRecruit);
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            OfficerLimitationProto message = OfficerLimitationProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(OfficerLimitationProto message) {
        this.nextTokenRecrTime = message.getNextTokenRecrTime();
        this.nextYbRecrOffTime = message.getNextYbRecrOffTime();
        this.tokenRecrNum = message.getTokenRecrNum();
        this.oneDiamondRecruitNum = message.getOneDiamondRecruitNum();
        this.firstOneDiamondRecruit = message.getFirstOneDiamondRecruit();
    }

    public int getTokenRecrNum() {
        return tokenRecrNum;
    }

    public void setTokenRecrNum(int tokenRecrNum) {
        this.tokenRecrNum = tokenRecrNum;
    }

    public long getNextYbRecrOffTime() {
        return nextYbRecrOffTime;
    }

    public void setNextYbRecrOffTime(long nextYbRecrOffTime) {
        this.nextYbRecrOffTime = nextYbRecrOffTime;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getLeftYbRecrTime() {
        return leftYbRecrTime;
    }

    public void setLeftYbRecrTime(long leftYbRecrTime) {
        this.leftYbRecrTime = leftYbRecrTime;
    }

    public long getNextTokenRecrTime() {
        return nextTokenRecrTime;
    }

    public void setNextTokenRecrTime(long nextTokenRecrTime) {
        this.nextTokenRecrTime = nextTokenRecrTime;
    }

    public long getLeftTokenRecrTime() {
        return leftTokenRecrTime;
    }

    public void setLeftTokenRecrTime(long leftTokenRecrTime) {
        this.leftTokenRecrTime = leftTokenRecrTime;
    }

    public int getTokenRecrLeftNum() {
        return tokenRecrTotalNum - tokenRecrNum;
    }

    public void setTokenRecrLeftNum(int tokenRecrLeftNum) {
    }

    public int getOneDiamondRecruitNum() {
        return oneDiamondRecruitNum;
    }

    public boolean isFirstOneDiamondRecruit() {
        return firstOneDiamondRecruit;
    }

    public void setFirstOneDiamondRecruit(boolean firstOneDiamondRecruit) {
        this.firstOneDiamondRecruit = firstOneDiamondRecruit;
    }

    public void checkCanRecruitOfficer(RecruitOfficerType recruitOfficerType) {
        if (recruitOfficerType.value() == RecruitOfficerType.USE_TOKEN_FREE.value()) {
            if (this.tokenRecrNum >= tokenRecrTotalNum) {
                throw new BusinessException(ErrorCode.TODAY_REACH_MAX);
            }
            if (this.leftTokenRecrTime > 0) {
                throw new BusinessException(ErrorCode.NO_COOLDOWN);
            }
        } else if (recruitOfficerType.value() == RecruitOfficerType.USE_YB_FREE.value()) {
            if (this.leftYbRecrTime > 0) {
                throw new BusinessException(ErrorCode.NO_COOLDOWN);
            }
        }
    }

    public void recruitOfficer(RecruitOfficerType recruitOfficerType, ConstantsPoolData constantsPool) {
        if (recruitOfficerType.value() == RecruitOfficerType.USE_TOKEN_FREE.value()) {
            this.tokenRecrNum += 1;
            this.nextTokenRecrTime = TimeUtil.currentTimeMillis() + FIVE_MINUTE;
        } else if (recruitOfficerType.value() == RecruitOfficerType.USE_YB_FREE.value()) {
            this.nextYbRecrOffTime = TimeUtil.currentTimeMillis() + constantsPool.getProperty(37).getValue() * oneHourToMil;
        }
    }

    /**
     * 单次钻石招募次数
     */
    public void addOneDiamondRecruitNum() {
        this.oneDiamondRecruitNum++;
    }

    public void addTenDiamondRecruitNum() {
        this.oneDiamondRecruitNum += 10;
    }

    public void resetTokenRecrNum() {
        this.tokenRecrNum = 0;
        this.oneDiamondRecruitNum = 0;
        this.firstOneDiamondRecruit = false;
    }

    public int diamondRecruit() {
        return oneDiamondRecruitNum % 10;
    }

    public int diamondRecruitActivityNum() {
        return oneDiamondRecruitNum / 10;
    }

}
