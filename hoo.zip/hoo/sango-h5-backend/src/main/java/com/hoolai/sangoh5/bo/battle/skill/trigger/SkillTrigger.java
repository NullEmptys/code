package com.hoolai.sangoh5.bo.battle.skill.trigger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.util.ProbabilityGenerator;

public abstract class SkillTrigger {

    /**
     * 所有技能
     */
    protected List<Skill> skills;

    /**
     * 有概率性的主动技能
     */
    protected List<Skill> independentSkills = new ArrayList<Skill>();

    /**
     * 概率性的防御技能
     */
    protected List<Skill> defenceSkills = new ArrayList<Skill>();;

    protected ProbabilityGenerator pg;

    /**
     * before_action有概率性的主动技能
     */
    protected List<Skill> beforeActionIndeSkills = new ArrayList<Skill>();

    /**
     * after_action的主动概率性技能
     */
    protected List<Skill> afterActionIndeSkills = new ArrayList<Skill>();;

    protected List<Skill> nextAttackSkills = new ArrayList<Skill>(); //此技能变量给后续攻击技能使用(例如以血换血)，此技能都是100%动作后续触发的

    protected IndependentSkill officerAttackSkill;

    protected IndependentSkill solderAttackSkill;

    protected int actionSkillIndex;

    protected int nextAttackSkillIndex;

    protected int independentSkillIndex;

    protected int defenceSkillIndex;

    /**
     * 加强此技能触发器内已存在的技能
     * 
     * @param skillList
     */
    public void enhanceSameSkills(Collection<Skill> skillList, float percentage) {
        Iterator<Skill> skillIterator = skillList.iterator();
        while (skillIterator.hasNext()) {
            Skill skill = skillIterator.next();
            for (Skill existSkill : skills) {
                if (skill.getSkillId() != existSkill.getSkillId()) {
                    continue;
                }
                skillIterator.remove();
                //类型为NONE的并无效果可言，比如闭月斩，要么沉默要么不沉默
                if (existSkill.getAttributeType() == AttributeType.NONE) {
                    continue;
                }
                if (existSkill.getAttributeType() == AttributeType.HURT) {
                    float originalHurtRate = existSkill.getHurtRate();
                    existSkill.setHurtRate(Math.abs(skill.getHurtRate() + originalHurtRate));
                    //                    if (logger.isDebugEnabled()) {
                    //logger.debug("HURT："+existSkill.getName()+"，伤害增加"+existSkill.getHurtRate());
                    //                }
                } else {
                    float originalPercentage = existSkill.getPercentage();
                    existSkill.setPercentage(originalPercentage * (1 + percentage));
                    //                    if (logger.isDebugEnabled()) {
                    //logger.debug(existSkill.getAttributeType()+"："+existSkill.getName()+"，原伤害："+originalPercentage+"，伤害："+existSkill.getPercentage());
                    //                }
                }
            }
        }
    }

    public void addSkills(Skill... skills) {
        addSkills(Arrays.asList(skills));
    }

    public void addSkills(Collection<Skill> skillList) {
        boolean isChanged = false;
        for (Skill skill : skillList) {
            isChanged |= addSkill(skill);
        }
        if (isChanged) {
            init();
        }
    }

    private boolean addSkill(Skill skill) {
        if (!skills.contains(skill)) {
            return skills.add(skill);
        }
        return false;
    }

    public void removeSkills(Skill... skills) {
        removeSkills(Arrays.asList(skills));
    }

    /**
     * 从出手列表中移除技能
     * PS:出手列表会从新初始化
     * 
     * @param skillList
     */
    public void removeSkills(Collection<Skill> skillList) {
        boolean isChanged = false;
        for (Skill skill : skillList) {
            isChanged |= removeSkill(skill);
        }
        if (isChanged) {
            init();
        }
    }

    /**
     * 删除技能的时候，需要判断下是不是特殊的技能
     * 
     * @param skill
     */
    private boolean removeSkill(Skill skill) {
        return skills.remove(skill);
    }

    public SkillTrigger() {
    }

    protected abstract void init();

    public abstract DefenceSkill triggerDefenceSkill();

    //    public IndependentSkill useKillSoldierSkill() {
    //        int index = pg.getAverageChoiceIndex(killSoldierSkillsPercentageArr);
    //        return index == -1 ? solderAttackSkill : (IndependentSkill) skills.get(index);
    //    }

    public IndependentSkill triggerSoldierAttackSkill() {
        return null;
    }

    /**
     * after_action的技能，按概率
     * 
     * @return
     */
    public abstract IndependentSkill triggerActionSkill();

    /**
     * after_action的技能，按概率
     * 
     * @return
     */
    //    public IndependentSkill triggerSoldierActionSkill() {
    //    	int index = pg.getAverageChoiceIndex(actionSoldierSkillPercentageArr);
    //        return index == -1 ? IndependentSkill.NONE : (IndependentSkill) actionSkills.get(index);
    //    }

    /**
     * 触发后续100%概率的主动技能（可看成被动技能）
     * 
     * @return
     */
    public List<Skill> triggerNextAttackSkills() {
        if (nextAttackSkills == null || nextAttackSkills.isEmpty()) {
            return Collections.emptyList();
        }
        List<Skill> triggerSkills = new ArrayList<Skill>();
        for (Skill nextAttackSkill : nextAttackSkills) {
            if (pg.getRandomNumber(99) < nextAttackSkill.getChance()) {
                triggerSkills.add(nextAttackSkill);
            }
        }
        return triggerSkills;
    }

    public abstract IndependentSkill triggerAttackSkill();

    //    public IndependentSkill triggerAttackSkill(boolean slinceSoldierSkill) {
    //    	return null;
    //    }
    //    
    public Integer[] skillIds() {
        List<Integer> skillIds = new ArrayList<Integer>();
        for (Skill skill : skills) {
            skillIds.add(skill.getXmlId());
        }
        return skillIds.toArray(new Integer[0]);
    }

    public abstract void changeAllSkillChance(float chance);

    public void silence() {
        //do nothing
    }

    public void unsilence() {
        //do nothing
    }

    public void recordChangeChance(float chance) {
        //do nothing
    }

    public DefenceSkill triggerDefenceSkill(boolean slinceSoldierSkill) {
        return null;
    }

    public boolean changeSkillChance(int xmlId, float chance) {
        return false;
    }

    public IndependentSkill getOfficerAttackSkill() {
        return officerAttackSkill;
    }

    public List<Skill> getActionSkills() {
        return afterActionIndeSkills;
    }

}
