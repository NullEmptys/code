package com.hoolai.sangoh5.bo.battle.skill.trigger;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.skill.Occasion;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.SkillType;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.skill.soldier.active.BaseSoldierPhysicsSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.soldier.RestraintFinder;
import com.hoolai.sangoh5.util.ProbabilityGenerator;

public class SoldierSkillTriger extends SkillTrigger {

    private FightUnit actor;

    //士兵的trigger
    public SoldierSkillTriger(FightUnit actor, RestraintFinder finder, ProbabilityGenerator pg, List<Skill> skills) {
        this.pg = pg;
        this.solderAttackSkill = new BaseSoldierPhysicsSkill(finder, pg);
        this.skills = skills;
        this.actor = actor;
        init();
    }

    @Override
    protected void init() {
        for (Skill skill : this.skills) {
            SkillType skillType = skill.getSkillType();
            switch (skillType) {
                case ACTIVE:
                    independentSkills.add(skill);
                    if (skill.getOccasion() == Occasion.AFTER_ACTION) {
                        afterActionIndeSkills.add(skill);
                    } else if (skill.getOccasion() == Occasion.BEFORE_ACTION) {
                        beforeActionIndeSkills.add(skill);
                    }
                    break;
                case DEFENCE:
                    defenceSkills.add(skill);
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public IndependentSkill triggerAttackSkill() {
        if (beforeActionIndeSkills.size() < 1) {
            return solderAttackSkill;
        }

        int index = independentSkillIndex % beforeActionIndeSkills.size();
        independentSkillIndex++;

        Skill skill = beforeActionIndeSkills.get(index);
        boolean isLuck = pg.getRandomWithPercentage(skill.getChance());
        if (isLuck) {
            actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发成功");
            return (IndependentSkill) skill;
        } else {
            actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发失败");
        }

        return solderAttackSkill;

    }

    @Override
    public DefenceSkill triggerDefenceSkill(boolean slinceSoldierSkill) {
        if (!slinceSoldierSkill) {
            return triggerDefenceSkill();
        }
        return DefenceSkill.NONE;
    }

    @Override
    public void changeAllSkillChance(float chance) {
        chance = chance / 100f;
        for (int index = 0; index < independentSkills.size(); index++) {
            Skill skill = independentSkills.get(index);
            skill.changeChance(skill.getChance() * chance);
        }

        for (int index = 0; index < defenceSkills.size(); index++) {
            Skill skill = defenceSkills.get(index);
            skill.changeChance(skill.getChance() * chance);
        }
    }

    @Override
    public boolean changeSkillChance(int xmlId, float chance) {
        return changeActiveSkill(xmlId, chance) || changeDefenceSkill(xmlId, chance);
    }

    private boolean changeActiveSkill(int xmlId, float chance) {
        int index = 0;
        for (; index < independentSkills.size(); index++) {
            if (independentSkills.get(index).getXmlId() == xmlId) {
                break;
            }
        }

        if (index == independentSkills.size()) {
            return false;
        }
        Skill skill = independentSkills.get(index);
        skill.changeChance(chance);
        return true;
    }

    private boolean changeDefenceSkill(int xmlId, float chance) {
        int index = 0;
        for (; index < defenceSkills.size(); index++) {
            if (defenceSkills.get(index).getXmlId() == xmlId) {
                break;
            }
        }

        if (index == defenceSkills.size()) {
            return false;
        }
        Skill skill = defenceSkills.get(index);
        skill.changeChance(chance);
        return true;
    }

    @Override
    public DefenceSkill triggerDefenceSkill() {
        if (defenceSkills.size() < 1) {
            return DefenceSkill.NONE;
        }

        int index = defenceSkillIndex % defenceSkills.size();
        defenceSkillIndex++;

        Skill skill = defenceSkills.get(index);
        boolean isLuck = pg.getRandomWithPercentage(skill.getChance());
        if (isLuck) {
            actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发成功");
            return (DefenceSkill) skill;
        } else {
            actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发 失败");
        }

        return DefenceSkill.NONE;
    }

    @Override
    public IndependentSkill triggerActionSkill() {
        int index = actionSkillIndex % afterActionIndeSkills.size();
        actionSkillIndex++;

        Skill skill = afterActionIndeSkills.get(index);
        if (pg.getRandomWithPercentage(skill.getChance())) {
            actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发成功");
            return (IndependentSkill) skill;
        } else {
            actor.addBattleLog(actor.name() + "选取技能=" + skill.getName() + "触发失败");
        }

        return IndependentSkill.NONE;
    }
}
