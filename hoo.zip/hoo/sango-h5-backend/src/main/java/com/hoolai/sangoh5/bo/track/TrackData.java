package com.hoolai.sangoh5.bo.track;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.stereotype.Component;

@Component
public class TrackData {

    public final Map<String, DauInstallCreative> install_source = new HashMap<String, DauInstallCreative>();

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/track/install_sources.xml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    protected void initData(String path) throws IOException, DocumentException {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        InputStream input = loader.getResourceAsStream(path);
        if (input == null) {
            throw new IllegalArgumentException("找不到配置文件" + path);
        }

        SAXReader reader = new SAXReader();
        Document doc = reader.read(input);
        List<Element> elements = doc.getRootElement().elements();
        for (Element element : elements) {
            String creative = element.element("creative").getStringValue().trim();
            String affiliate = element.element("affiliate").getStringValue().trim();
            String source = element.element("source").getStringValue().trim();
            String key = creative.replaceAll("[0-9]+", "0").toUpperCase();
            install_source.put(key, new DauInstallCreative(creative, affiliate, source));
        }
    }

    public DauInstallCreative get(String key) {
        return install_source.get(key);
    }

}
