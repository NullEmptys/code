package com.hoolai.sangoh5.bo.rankfight;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.RankFightUserProto;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class RankFightUser implements ProtobufSerializable<RankFightUserProto> {

    private long userId;

    /** 将领的战力 */
    private int fightValue;

    /** 当前所属阶段 */
    private int step;

    private int box;

    /** 将领id */
    private int officerId;

    /** 声望值 */
    private int reputation;

    /** 排名 */
    transient private int rank;

    transient private int officerXml;

    transient private String username;

    transient private String image;

    transient private int level;

    transient private Officer officer;

    public RankFightUser(long userId) {
        this.userId = userId;
    }

    public RankFightUser(int step, int rank) {
        this.step = step;
        this.rank = rank;
    }

    public RankFightUser(long userId, byte[] bytes) {
        this.userId = userId;
        parseFrom(bytes);
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int getFightValue() {
        return fightValue;
    }

    public void setFightValue(int fightValue) {
        this.fightValue = fightValue;
    }

    public int getStep() {
        return step;
    }

    public void setStep(int step) {
        this.step = step;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getBox() {
        return box;
    }

    public void setBox(int box) {
        this.box = box;
    }

    public int getOfficerId() {
        return officerId;
    }

    public void setOfficerId(int officerId) {
        this.officerId = officerId;
    }

    public int getOfficerXml() {
        return officerXml;
    }

    public void setOfficerXml(int officerXml) {
        this.officerXml = officerXml;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getReputation() {
        return reputation;
    }

    public void setReputation(int reputation) {
        this.reputation = reputation;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public RankFightUser initRobot() {
        this.fightValue = 1000;
        this.userId = User.MONSTER_USER_ID;
        return this;
    }

    @Override
    public RankFightUserProto copyTo() {
        RankFightUserProto.Builder builder = RankFightUserProto.newBuilder();
        builder.setBox(box);
        builder.setFightValue(fightValue);
        builder.setOfficerId(officerId);
        builder.setStep(step);
        builder.setUserId(userId);
        builder.setReputation(reputation);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            RankFightUserProto message = RankFightUserProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(RankFightUserProto message) {
        this.box = message.getBox();
        this.fightValue = message.getFightValue();
        this.officerId = message.getOfficerId();
        this.step = message.getStep();
        this.userId = message.getUserId();
        this.reputation = message.getReputation();
    }

    public void checkAndDecReputation(int reputation) {
        if (reputation < 0 || reputation > this.reputation) {
            throw new BusinessException(ErrorCode.NOT_ENOUGH_REPUTATION);
        }
        this.reputation -= reputation;
    }

    public void addReputation(int reputation) {
        this.reputation += reputation;
    }

    public Officer getOfficer() {
        return officer;
    }

    public void setOfficer(Officer officer) {
        this.officer = officer;
    }

}
