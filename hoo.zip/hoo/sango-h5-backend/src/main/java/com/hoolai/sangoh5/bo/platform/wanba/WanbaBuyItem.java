package com.hoolai.sangoh5.bo.platform.wanba;

public class WanbaBuyItem {

	private String billno;
	private int cost;
	
	@Override
	public String toString() {
		return "TencentWanbaBuyItem [billno=" + billno + ", cost=" + cost + "]";
	}
	
	public String getBillno() {
		return billno;
	}
	public void setBillno(String billno) {
		this.billno = billno;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	
}
