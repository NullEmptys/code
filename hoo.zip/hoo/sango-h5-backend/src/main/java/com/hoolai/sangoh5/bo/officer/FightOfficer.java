package com.hoolai.sangoh5.bo.officer;

import java.util.Arrays;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.FightOfficerProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 战斗使用的
 * 
 * @author Administrator
 *
 */
public class FightOfficer implements ProtobufSerializable<FightOfficerProto> {

    private int id;

    private int xmlId;

    private int level;

    private float hp;

    private float attack;

    private float defence;

    private int starLevel;

    private int combinationLevel;

    private int[] skills;

    private int[] initPosition;

    private float moveSpeed;

    public FightOfficer(Officer officer) {
        this.id = officer.getId();
        this.xmlId = officer.getXmlId();
        this.level = officer.getLevel();
        this.hp = officer.getHp();
        this.attack = officer.getAttack();
        this.defence = officer.getDefence();
        this.moveSpeed = officer.getMoveSpeed();
        this.starLevel = officer.getStarLevel();
        this.combinationLevel = officer.getCombinationLevel();
        this.skills = Arrays.copyOf(officer.getSkills(), officer.getSkills().length);
        this.initPosition = officer.getInitPosition();
    }

    public FightOfficer(FightOfficerProto message) {
        copyFrom(message);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getXmlId() {
        return xmlId;
    }

    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public float getHp() {
        return hp;
    }

    public void setHp(float hp) {
        this.hp = hp;
    }

    public float getAttack() {
        return attack;
    }

    public void setAttack(float attack) {
        this.attack = attack;
    }

    public float getDefence() {
        return defence;
    }

    public void setDefence(float defence) {
        this.defence = defence;
    }

    public int getStarLevel() {
        return starLevel;
    }

    public void setStarLevel(int starLevel) {
        this.starLevel = starLevel;
    }

    public int getCombinationLevel() {
        return combinationLevel;
    }

    public void setCombinationLevel(int combinationLevel) {
        this.combinationLevel = combinationLevel;
    }

    public int[] getSkills() {
        return skills;
    }

    public void setSkills(int[] skills) {
        this.skills = skills;
    }

    public int[] getInitPosition() {
        return initPosition;
    }

    public void setInitPosition(int[] initPosition) {
        this.initPosition = initPosition;
    }

    public float getMoveSpeed() {
        return moveSpeed;
    }

    public void setMoveSpeed(float moveSpeed) {
        this.moveSpeed = moveSpeed;
    }

    @Override
    public FightOfficerProto copyTo() {
        FightOfficerProto.Builder builder = FightOfficerProto.newBuilder();
        builder.setAttack(attack);
        builder.setCombinationLevel(combinationLevel);
        builder.setDefence(defence);
        builder.setHp(hp);
        builder.setId(id);
        builder.setLevel(level);
        builder.setStarLevel(starLevel);
        builder.setXmlId(xmlId);
        builder.setMoveSpeed(moveSpeed);
        if (skills != null && skills.length > 0) {
            for (int skill : skills) {
                builder.addSkills(skill);
            }
        }
        if (initPosition != null && initPosition.length > 0) {
            builder.addInitPosition(initPosition[0]);
            builder.addInitPosition(initPosition[1]);
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            FightOfficerProto message = FightOfficerProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(FightOfficerProto message) {
        this.attack = message.getAttack();
        this.defence = message.getDefence();
        this.combinationLevel = message.getCombinationLevel();
        this.hp = message.getHp();
        this.id = message.getId();
        this.level = message.getLevel();
        this.starLevel = message.getStarLevel();
        this.xmlId = message.getXmlId();
        this.moveSpeed = message.getMoveSpeed();
        if (message.getSkillsCount() > 0) {
            int c = message.getSkillsCount();
            this.skills = new int[c];
            for (int i = 0; i < c; i++) {
                skills[i] = message.getSkills(i);
            }
        }

        int count = message.getInitPositionCount();
        if (count > 1) {
            int x = message.getInitPosition(0);
            int y = message.getInitPosition(1);
            this.initPosition = new int[] { x, y };
        }
    }

}
