package com.hoolai.sangoh5.bo.soldier.data;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.JSONUtils;

@Component
public class SoldierData extends JsonData<SoldierProperty> {

    public static int initFootmanId = 0;

    public static int initRiderId = 0;

    public static int initSpearmanId = 0;

    public static int initArcherId = 0;

    public static int initCrossbowmanId = 0;

    public static int initVehiclemanId = 0;

    public static List<Integer> openFootmanIds = new ArrayList<Integer>();

    public static List<Integer> openRiderIds = new ArrayList<Integer>();

    public static List<Integer> openSpearmanIds = new ArrayList<Integer>();

    public static List<Integer> openArcherIds = new ArrayList<Integer>();

    public static List<Integer> openCrossbowmanIds = new ArrayList<Integer>();

    public static List<Integer> openVehiclemanIds = new ArrayList<Integer>();

    //    private Map<Integer,List<SoldierProperty>> solderTypeMap = new HashMap<Integer,List<SoldierProperty>>();

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/soldier.json", SoldierProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void initData(String path, Class<SoldierProperty> clazz) throws IOException {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        InputStream input = loader.getResourceAsStream(path);
        if (input == null) {
            throw new IllegalArgumentException("找不到配置文件" + path);
        }

        String jsonStr = IOUtils.toString(input);
        List<SoldierProperty> properties = JSONUtils.fromJSONToList(jsonStr, clazz);
        for (SoldierProperty property : properties) {
            int id = property.getId();
            Assert.isTrue(!propertyMap.containsKey(id), path + " 存在相同的id=" + id);
            checkProperty(property);

            if (property.getIsFirstSoldierId() == 1) {
                SoldierType soldierType = SoldierType.valueOf(property.getSoldierType());
                switch (soldierType) {
                    case footman:
                        initFootmanId = id;
                        openFootmanIds.add(id);
                        break;
                    case rider:
                        initRiderId = id;
                        openRiderIds.add(id);
                        break;
                    case spearman:
                        initSpearmanId = id;
                        openSpearmanIds.add(id);
                        break;
                    case archer:
                        initArcherId = id;
                        openArcherIds.add(id);
                        break;
                    case crossbowman:
                        initCrossbowmanId = id;
                        openCrossbowmanIds.add(id);
                        break;
                    case vehicleman:
                        initVehiclemanId = id;
                        openVehiclemanIds.add(id);
                        break;
                }
            }

            propertyMap.put(id, property);
            //			logger.info("Json Loaded "+property);

            initForEach(property);
        }
    }

    @Override
    protected void checkProperty(SoldierProperty property) {
        // TODO Auto-generated method stub

    }

    public int nextSoldier(int id) {
        int next = getProperty(id).getNextSoldierId();
        if (next <= 0) {
            throw new BusinessException(ErrorCode.MAX_SOLDIER_LEVEL);
        }
        return next;
    }

}
