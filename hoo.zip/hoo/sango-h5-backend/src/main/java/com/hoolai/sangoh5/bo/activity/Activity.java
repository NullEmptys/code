package com.hoolai.sangoh5.bo.activity;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.compass.core.util.CollectionUtils;

import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.ActivityProto;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.ActivityProto.Builder;
import com.hoolai.sangoh5.bo.activity.data.ActivityBaseProperty;
import com.hoolai.sangoh5.bo.activity.data.CumulativePayProperty;
import com.hoolai.sangoh5.bo.activity.data.FamilyProperty;
import com.hoolai.sangoh5.bo.activity.data.RewardLvProperty;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 10:22
 * @version : 1.0
 */
public class Activity implements ProtobufSerializable<ActivityProto> {

    /** 活动id **/
    private int activityId;

    /** 奖励列表 **/
    private Map<Integer, ActivityReward> rewardMap;

    /** 结束时间 **/
    private long endTime;

    /** 领取完奖励个数 **/
    private int finishCount;

    /** 可刷新类型 **/
    private int dayValue;

    public Activity(ActivityBaseProperty property) {
        this.activityId = property.getId();
        this.rewardMap = Maps.newHashMapWithExpectedSize(10);
        this.endTime = property.getTime() == 0 ? property.getTime() : TimeUtil.currentTimeMillis() + TimeUnit.HOURS.toMillis(property.getTime());
        this.refresh();
    }

    public Activity(ActivityProto activity) {
        this.copyFrom(activity);
        this.refresh();
    }

    public Activity(ActivityBaseProperty property, OperationalActivity operationalActivity) {
        this.activityId = property.getId();
        this.rewardMap = Maps.newHashMapWithExpectedSize(1);
        this.endTime = operationalActivity.getEndTime();
        this.refresh();
    }

    public int getActivityId() {
        return activityId;
    }

    public void setActivityId(int activityId) {
        this.activityId = activityId;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    @Override
    public ActivityProto copyTo() {
        Builder newBuilder = ActivityProto.newBuilder();
        newBuilder.setId(activityId);
        newBuilder.setEndTime(endTime);
        Collection<ActivityReward> values = this.rewardMap.values();
        for (ActivityReward activityReward : values) {
            newBuilder.addRewards(activityReward.copyTo());
        }
        newBuilder.setFinishCount(finishCount);
        newBuilder.setDayValue(dayValue);
        return newBuilder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ActivityProto message = ActivityProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(ActivityProto message) {
        this.activityId = message.getId();
        this.endTime = message.getEndTime();
        int count = message.getRewardsCount();
        this.rewardMap = Maps.newHashMapWithExpectedSize(count);
        for (int i = 0; i < count; i++) {
            ActivityReward activityReward = new ActivityReward(message.getRewards(i));
            addReward(activityReward);
        }
        this.finishCount = message.getFinishCount();
        this.dayValue = message.getDayValue();
    }

    public Map<Integer, ActivityReward> getRewardMap() {
        return rewardMap;
    }

    private void addReward(ActivityReward activityReward) {
        this.rewardMap.put(activityReward.getRewardId(), activityReward);
    }

    public void finishLoginTimes(int maxTimes) {
        int loginTime = rewardMap.size() + 1;
        if (loginTime > maxTimes) {
            return;
        }
        this.rewardMap.put(loginTime, new ActivityReward(loginTime));
    }

    public boolean activityFinished() {
        if (this.endTime <= 0) {
            return false;
        }
        return TimeUtil.currentTimeMillis() >= this.endTime;
    }

    public int checkAndAddLuckWheelCount(int maxCount, int num) {
        ActivityReward activityReward = rewardMap.get(0);
        if (activityReward != null && maxCount - activityReward.getCount() < num && num != 1) {
            throw new com.hoolai.sango.core.exception.BusinessException(ErrorCode.DARW_REWARD_NOT_ENOUGH.code, "抽奖次数不足以连转" + num + "次啦，请明日再来~");
        } else if (activityReward != null && (activityReward.getCount() == maxCount)) {
            throw new BusinessException(ErrorCode.ERROR_CHALLENAGE_COUNT);
        }
        if (activityReward == null) {
            activityReward = new ActivityReward(0);
            this.addReward(activityReward);
        }
        activityReward.addCount(num);
        return activityReward.getCount() == num ? num - 1 : num;
    }

    public int findLuckyWheelLastTime(int maxCount) {
        ActivityReward activityReward = rewardMap.get(0);
        return activityReward == null ? maxCount : maxCount - activityReward.getCount();
    }

    public long getRemainTime() {
        return this.endTime <= 0 ? 0 : TimeUtil.currentTimeMillis() < this.endTime ? this.endTime - TimeUtil.currentTimeMillis() : 0;
    }

    public void checkCumulativeLoginReward(int day) {
        this.checkAndDraw(day);
    }

    private void checkAndDraw(int rewardId) {
        if (this.activityFinished()) {
            throw new BusinessException(ErrorCode.OVER_INDEX);
        }
        ActivityReward activityReward = rewardMap.get(rewardId);
        if (activityReward == null || !activityReward.canDrawReward()) {
            throw new BusinessException(ErrorCode.OVER_INDEX);
        }
        activityReward.drawReward();
        this.finishCount++;
    }

    public boolean finishFirstPay(int rewardId) {
        ActivityReward activityReward = rewardMap.get(rewardId);
        if (activityReward != null && !activityReward.emptyReward()) {
            return false;
        }
        activityReward = new ActivityReward(rewardId);
        this.addReward(activityReward);
        return true;
    }

    public boolean finishRewardLevel(RewardLvProperty rewardProperty) {
        if (rewardMap.containsKey(rewardProperty.getId())) {
            return false;
        }
        ActivityReward activityReward = new ActivityReward(rewardProperty);
        this.addReward(activityReward);
        return true;
    }

    public void accumulative(CumulativePayProperty payProperty, int condition) {
        ActivityReward activityReward = rewardMap.get(payProperty.getId());
        if (activityReward != null && activityReward.drawedReward()) {
            return;
        }
        if (activityReward == null) {
            activityReward = new ActivityReward(payProperty);
            this.addReward(activityReward);
        }
        activityReward.accumulative(payProperty, condition);
    }

    public void invite(int maxCount) {
        ActivityReward activityReward = rewardMap.get(0);
        if (activityReward != null && activityReward.drawedReward()) {
            return;
        }
        if (activityReward == null) {
            activityReward = new ActivityReward(0, ActivityReward.REWARD_EMPTY);
            this.addReward(activityReward);
        }
        activityReward.invite(maxCount);
    }

    public void focuson() {
        ActivityReward activityReward = rewardMap.get(0);
        if (activityReward != null && activityReward.drawedReward()) {
            return;
        }
        if (activityReward == null) {
            activityReward = new ActivityReward(0);
            this.addReward(activityReward);
        }
        activityReward.focuson();
    }

    public void checkAndDrawReward(int rewardId) {
        this.checkAndDraw(rewardId);
    }

    public void addFirstPayReward(int fistPayId) {
        ActivityReward activityReward = rewardMap.get(fistPayId);
        if (activityReward != null) {
            return;
        }
        activityReward = new ActivityReward(fistPayId, ActivityReward.REWARD_EMPTY);
        this.addReward(activityReward);
    }

    public boolean finishedLuckDraw() {
        ActivityReward activityReward = rewardMap.get(0);
        return activityReward != null;
    }

    public boolean finishLuckDraw() {
        ActivityReward activityReward = rewardMap.get(0);
        if (activityReward != null) {
            return false;
        }
        activityReward = new ActivityReward(0);
        this.addReward(activityReward);
        this.dayValue = DateUtil.getTodayIntValue();
        return true;
    }

    public boolean finishedInvite() {
        ActivityReward activityReward = rewardMap.get(0);
        return activityReward != null && activityReward.drawedReward();
    }

    public boolean finishedFosuson() {
        ActivityReward activityReward = rewardMap.get(0);
        return activityReward != null;
    }

    public int findFinishCount() {
        return this.finishCount;
    }

    public boolean finishSpecialSoldier(int condition) {
        ActivityReward activityReward = rewardMap.get(condition);
        if (activityReward != null) {
            return false;
        }
        activityReward = new ActivityReward(condition);
        this.addReward(activityReward);
        this.checkAndDrawReward(condition);
        return true;
    }

    public void refresh() {
        if (!ActivityId.needRefresh(activityId) || DateUtil.getTodayIntValue() == dayValue) {
            return;
        }
        if (activityId == ActivityId.LuckyWheel.getId()) {
            this.rewardMap.remove(Integer.valueOf(0));
        } else if (activityId == ActivityId.Recharge.getId()) {
            ActivityReward activityReward = this.rewardMap.get(Integer.valueOf(0));
            if (activityReward != null) {
                activityReward.refresh();
            }
        } else {
            this.rewardMap.clear();
        }
        this.dayValue = DateUtil.getTodayIntValue();
        this.finishCount = 0;
    }

    public boolean canDrawReward() {
        if (CollectionUtils.isEmpty(rewardMap)) {
            return false;
        }
        Collection<ActivityReward> values = rewardMap.values();
        for (ActivityReward reward : values) {
            if (reward.canDrawReward()) {
                return true;
            }
        }
        return false;
    }

    public int addAndGetLuckWheelNum() {
        ActivityReward activityReward = rewardMap.get(1);
        if (activityReward == null) {
            activityReward = new ActivityReward(1);
            this.addReward(activityReward);
        }
        activityReward.addCount(1);
        return activityReward.getCount();
    }

    public void recharge(int condition) {
        ActivityReward activityReward = rewardMap.get(0);
        if (activityReward == null) {
            activityReward = new ActivityReward(0);
            this.addReward(activityReward);
        }
        activityReward.addRechargeCount(condition);
    }

    public void family(FamilyProperty payProperty, int condition) {
        ActivityReward activityReward = rewardMap.get(payProperty.getId());
        if (activityReward != null && activityReward.drawedReward()) {
            return;
        }
        if (activityReward == null) {
            activityReward = new ActivityReward(payProperty);
            this.addReward(activityReward);
        }
        activityReward.family(payProperty, condition);
    }

}
