package com.hoolai.sangoh5.bo.battle.fight;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.OfficerUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.bo.tacticalManagement.Formation;

/**
 * 环境（Match）要监听FightUnit的属性变化，
 * 并进行回合制的轮流处理
 *
 */
public class Match implements LifecycleListener, BuffCollection {

    private static final Log logger = LogFactory.getLog("battle");

    private final ActorSequence actorSequence;//出手顺序

    private final TargetCollection targetCollection;//所有参战单元集合

    //    private Formation attackerFormation;
    //    
    //    private Formation defencerFormation;

    private int roundCounter;// 回合计数器

    public static final int maxRound = 7200;

    private boolean isAttackerBattleWin;

    private transient BoFactory boFactory;

    private EnumMap<FightUnitName, FightUnit> fightUnitMap; //战斗中所有的战斗单元map

    private final Set<Buff> buffs = new HashSet<Buff>();

    public TargetCollection getTargetCollection() {
        return targetCollection;
    }

    public Match(ActorSequence actorSequence, TargetCollection targetCollection, Formation attackerFormation, Formation defencerFormation) {
        this.actorSequence = actorSequence;
        this.targetCollection = targetCollection;
        //	    this.attackerFormation = attackerFormation;
        //	    this.defencerFormation = defencerFormation;
    }

    private void setListener() {
        for (FightUnit fightUnit : fightUnitMap.values()) {
            fightUnit.setLifecycleListener(this);
        }
    }

    public Match(ActorSequence actorSequence, TargetCollection targetCollection, EnumMap<FightUnitName, FightUnit> fightUnitMap, Formation attackerFormation,
            Formation defencerFormation) {
        this(actorSequence, targetCollection, attackerFormation, defencerFormation);
        this.fightUnitMap = fightUnitMap;
        setListener();
    }

    private List<Action> actions;

    /**
     * actor确定用什么技能，建立一个action，包含actor和skill
     * 
     * @return
     */
    public void nextRound() {
        roundCounter++;
        if (logger.isDebugEnabled()) {
            logger.debug("第" + roundCounter + "回合开始：");
        }

        targetCollection.get(FightUnitName.att_officer).addBattleLog("第" + roundCounter + "回合开始：");
        actions = new ArrayList<Action>();
        while (!isNextRoundTurn()) {
            Action action = nextAction();
            if (action != null) {
                actions.add(action.execute(targetCollection, this, Action.DEFAULT_ACTION_LEVEL));
            }
        }
    }

    private boolean isNextRoundTurn() {
        return actorSequence.isNextRoundTurn();
    }

    public RoundResult endCurrentRound() {
        RoundResult roundResult = new RoundResult(roundCounter);
        List<ActionResult> results = new ArrayList<ActionResult>();

        for (Action action : actions) {
            ActionResult actionResult = action.apply(this, targetCollection);
            results.add(actionResult);
            if (actionResult.isHaveDynamics()) {
                targetCollection.get(FightUnitName.att_officer).addBattleLog("-----------------------------------------");
            }
        }

        AfterRound afterRound = new AfterRound(results, targetCollection);
        afterRound.finalSpeHurtEnhance();

        clearBuffs();
        actorSequence.endCurrentRound();

        if (logger.isDebugEnabled()) {
            logger.debug(String.format("回合数 ： %s ，活着的有 ： %s ，死了的有 ：%s 。", roundCounter, targetCollection.getAliveUnitMap().keySet(), targetCollection.getDeadUnitMap().keySet()));
        }
        //        targetCollection.get(FightUnitName.att_officer).addBattleLog("第" + roundCounter + "回合结束");

        if (results.size() < 1) {
            return null;
        } else {
            roundResult.setActionResultList(results);
            return roundResult;
        }
    }

    private void clearBuffs() {
        Iterator<Buff> it = buffs.iterator();
        while (it.hasNext()) {
            Buff buff = it.next();
            buff.repeatedOnce(targetCollection);//Buff效果又持续一回合了
            boolean isCanRemove = false;
            if (!buff.available()) {
                buff.clear(targetCollection);
                isCanRemove = true;
            }
            if (isCanRemove) {
                FightUnit unit = targetCollection.get(buff.getExecuteName());
                if (unit != null) {
                    unit.removeBuff(buff);
                }
                it.remove();
            }
        }
    }

    private Action nextAction() {
        FightUnit actor = actorSequence.next();
        if (actor == null) {
            return null;
        }
        if (logger.isDebugEnabled()) {
            //        logger.debug("出手者："+actor.name());            
        }
        lockTarget(actor);

        Action action = actor.action(this.roundCounter);
        return action;
    }

    /**
     * 选择攻击目标
     * 
     * @param actor
     */
    private void lockTarget(FightUnit actor) {
        PositionCalculator calculator = boFactory.createPositionCalculator(actor, roundCounter, targetCollection);
        calculator.calPos();
    }

    public boolean currentActorIsAttacker() {
        return actorSequence.currentActorIsAttacker();
    }

    @Override
    public void onRecovered(FightUnit unit) {
        this.actorSequence.put(unit);
        this.targetCollection.addUnit(unit);
    }

    @Override
    public void onRecoveredOfficer(FightUnit unit) {
        this.actorSequence.put(unit);
        this.targetCollection.addUnit(unit);
    }

    public boolean isAttackerBattleWin() {
        return this.isAttackerBattleWin;
    }

    public void setIsAttackerBattleWin(boolean isAttackerBattleWin) {
        this.isAttackerBattleWin = isAttackerBattleWin;
    }

    public boolean isFinished() {
        OfficerUnit attackOfficer = (OfficerUnit) fightUnitMap.get(FightUnitName.att_officer);
        if (attackOfficer.isBattleFailed()) {
            this.isAttackerBattleWin = false;
            return true;
        }

        OfficerUnit defenceOfficer = (OfficerUnit) fightUnitMap.get(FightUnitName.def_officer);
        if (defenceOfficer.isBattleFailed()) {
            this.isAttackerBattleWin = true;
            return true;
        }

        if (roundCounter > maxRound) {
            this.isAttackerBattleWin = attackOfficer.getArmy().lostPercentage() < defenceOfficer.getArmy().lostPercentage();
            return true;
        }

        return false;
    }

    @Override
    public void onDefeated(FightUnit unit) {

    }

    @Override
    public void addBuff(Buff buff) {
        this.buffs.add(buff);
    }

    @Override
    public void addBuffs(List<Buff> buffs) {
        this.buffs.addAll(buffs);
    }

    @Override
    public void onKnockedout(FightUnit unit) {
        this.actorSequence.remove(unit);
        this.targetCollection.removeUnit(unit);
    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }
}
