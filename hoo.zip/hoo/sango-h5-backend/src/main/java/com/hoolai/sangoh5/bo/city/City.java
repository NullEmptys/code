package com.hoolai.sangoh5.bo.city;

import com.hoolai.sangoh5.bo.officer.Officer;

public class City {

	
}
