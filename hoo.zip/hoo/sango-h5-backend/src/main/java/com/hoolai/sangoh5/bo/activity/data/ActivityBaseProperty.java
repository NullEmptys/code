package com.hoolai.sangoh5.bo.activity.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 11:09
 * @version : 1.0
 */
public class ActivityBaseProperty extends JsonProperty {

    /** 活动类型 **/
    private int type;

    /** 描述 **/
    private String desc;

    /** 持续时间 **/
    private int time;

    /** 十连抽活动打折 **/
    private int discount;

    /** 是否开启 **/
    private boolean isOpen;

    /** 注册第几天开启 **/
    private int starDay;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public boolean getIsOpen() {
        return isOpen;
    }

    public void setIsOpen(boolean isOpen) {
        this.isOpen = isOpen;
    }

    public int getStarDay() {
        return starDay;
    }

    public void setStarDay(int starDay) {
        this.starDay = starDay;
    }

    public int getDayValue() {
        int value = time / 24;
        return time % 24 == 0 ? value : value + 1;
    }

}
