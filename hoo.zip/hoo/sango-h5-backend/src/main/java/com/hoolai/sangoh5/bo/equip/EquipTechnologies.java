package com.hoolai.sangoh5.bo.equip;

public class EquipTechnologies {

}
