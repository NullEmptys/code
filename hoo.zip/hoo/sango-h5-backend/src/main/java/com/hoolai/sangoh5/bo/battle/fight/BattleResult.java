package com.hoolai.sangoh5.bo.battle.fight;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.BattleResultProto;
import com.hoolai.sangoh5.bo.battle.unit.Army;
import com.hoolai.sangoh5.bo.officer.FightOfficer;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.user.BattleSimpleUser;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class BattleResult implements ProtobufSerializable<BattleResultProto> {

    private int battleId;

    private BattleSimpleUser attackUser;

    private BattleSimpleUser defenceUser;

    private FightOfficer attackOfficer;

    private FightOfficer defenceOfficer;

    private Army attackArmy;

    private Army defenceArmy;

    private int[] attEnhanceSkills;

    private int[] defEnhanceSkills;

    private int[] attOtherEnhanceSkills;

    private int[] defOtherEnhanceSkills;

    transient private User attackPerfectUser;

    transient private User defencePerfectUser;

    transient private Officer attackOfficerAfterBattle;

    transient private Officer defenceOfficerAfterBattle;

    //战斗过程，每回合为一个RoundResult
    private List<RoundResult> roundResultList;

    private boolean isAttackerBattleWin;

    private BattleType battleType;

    //进攻方剩余生命百分比
    public transient double attackUserLastHp;

    //防守方剩余生命百分比
    public transient double defenceUserLastHp;

    public transient BattleLog battleLog;

    public BattleResult(Officer attackOfficer, Officer defenceOfficer) {
        this.attackOfficer = new FightOfficer(attackOfficer);
        this.defenceOfficer = new FightOfficer(defenceOfficer);
        this.attackOfficerAfterBattle = attackOfficer;
        this.defenceOfficerAfterBattle = defenceOfficer;
    }

    public BattleResult(byte[] bytes) {
        parseFrom(bytes);
    }

    public BattleSimpleUser getAttackUser() {
        return attackUser;
    }

    public BattleSimpleUser getDefenceUser() {
        return defenceUser;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public User getAttackPerfectUser() {
        return attackPerfectUser;
    }

    public void setAttackPerfectUser(User attackPerfectUser) {
        this.attackPerfectUser = attackPerfectUser;
        this.attackUser = new BattleSimpleUser(attackPerfectUser);
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public User getDefencePerfectUser() {
        return defencePerfectUser;
    }

    public void setDefencePerfectUser(User defencePerfectUser) {
        this.defencePerfectUser = defencePerfectUser;
        this.defenceUser = new BattleSimpleUser(defencePerfectUser);
    }

    public FightOfficer getAttackOfficer() {
        return attackOfficer;
    }

    public void setAttackOfficer(FightOfficer attackOfficer) {
        this.attackOfficer = attackOfficer;
    }

    public FightOfficer getDefenceOfficer() {
        return defenceOfficer;
    }

    public void setDefenceOfficer(FightOfficer defenceOfficer) {
        this.defenceOfficer = defenceOfficer;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public int getAttackArmyCurrLostPoint() {
        return attackArmy.getCurrLostPoint();
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public int getDefenceArmyCurrLostPoint() {
        return defenceArmy.getCurrLostPoint();
    }

    public Army getAttackArmy() {
        return attackArmy;
    }

    public void setAttackArmy(Army attackArmy) {
        this.attackArmy = attackArmy;
    }

    public Army getDefenceArmy() {
        return defenceArmy;
    }

    public void setDefenceArmy(Army defenceArmy) {
        this.defenceArmy = defenceArmy;
    }

    public Officer getAttackOfficerAfterBattle() {
        return attackOfficerAfterBattle;
    }

    public void setAttackOfficerAfterBattle(Officer attackOfficerAfterBattle) {
        this.attackOfficerAfterBattle = attackOfficerAfterBattle;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public Officer getDefenceOfficerAfterBattle() {
        return defenceOfficerAfterBattle;
    }

    public void setDefenceOfficerAfterBattle(Officer defenceOfficerAfterBattle) {
        this.defenceOfficerAfterBattle = defenceOfficerAfterBattle;
    }

    public List<RoundResult> getRoundResultList() {
        return roundResultList;
    }

    public void setRoundResultList(List<RoundResult> roundResultList) {
        this.roundResultList = roundResultList;
    }

    public boolean isAttackerBattleWin() {
        return isAttackerBattleWin;
    }

    public boolean getIsAttackerBattleWin() {
        return isAttackerBattleWin;
    }

    public void setIsAttackerBattleWin(boolean isAttackerBattleWin) {
        this.isAttackerBattleWin = isAttackerBattleWin;
    }

    public BattleType getBattleType() {
        return battleType;
    }

    public void setBattleType(BattleType battleType) {
        this.battleType = battleType;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public double getAttackUserLastHp() {
        return attackUserLastHp;
    }

    public void setAttackUserLastHp(double attackUserLastHp) {
        this.attackUserLastHp = attackUserLastHp;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public double getDefenceUserLastHp() {
        return defenceUserLastHp;
    }

    public void setDefenceUserLastHp(double defenceUserLastHp) {
        this.defenceUserLastHp = defenceUserLastHp;
    }

    public int getBattleId() {
        return battleId;
    }

    public void setBattleId(int battleId) {
        this.battleId = battleId;
    }

    public int[] getAttEnhanceSkills() {
        return attEnhanceSkills;
    }

    public void setAttEnhanceSkills(int[] attEnhanceSkills) {
        this.attEnhanceSkills = attEnhanceSkills;
    }

    public int[] getDefEnhanceSkills() {
        return defEnhanceSkills;
    }

    public void setDefEnhanceSkills(int[] defEnhanceSkills) {
        this.defEnhanceSkills = defEnhanceSkills;
    }

    public int[] getAttOtherEnhanceSkills() {
        return attOtherEnhanceSkills;
    }

    public void setAttOtherEnhanceSkills(int[] attOtherEnhanceSkills) {
        this.attOtherEnhanceSkills = attOtherEnhanceSkills;
    }

    public int[] getDefOtherEnhanceSkills() {
        return defOtherEnhanceSkills;
    }

    public void setDefOtherEnhanceSkills(int[] defOtherEnhanceSkills) {
        this.defOtherEnhanceSkills = defOtherEnhanceSkills;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public BattleLog getBattleLog() {
        return battleLog;
    }

    public void setBattleLog(BattleLog battleLog) {
        this.battleLog = battleLog;
        battleLog.add("------------------战斗结束-------------------");
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void copyFrom(BattleResultProto message) {
        this.attackArmy = new Army(message.getAttackArmy());
        this.attackOfficer = new FightOfficer(message.getAttackOfficer());
        this.attackUser = new BattleSimpleUser(message.getAttackUser().toByteArray());
        this.defenceUser = new BattleSimpleUser(message.getDefenceUser().toByteArray());
        this.isAttackerBattleWin = message.getIsAttackerBattleWin();
        this.battleId = message.getBattleId();
        BattleType.valueOf(message.getBattleType());

        int count = message.getRoundResultListCount();
        this.roundResultList = new ArrayList<RoundResult>(count);
        for (int i = 0; i < count; i++) {
            this.roundResultList.add(new RoundResult(message.getRoundResultList(i)));
        }

        this.defenceArmy = new Army(message.getDefenceArmy());
        this.defenceOfficer = new FightOfficer(message.getDefenceOfficer());

        count = message.getAttEnhanceSkillsCount();
        this.attEnhanceSkills = new int[count];
        for (int i = 0; i < count; i++) {
            attEnhanceSkills[i] = message.getAttEnhanceSkills(i);
        }

        count = message.getDefEnhanceSkillsCount();
        this.defEnhanceSkills = new int[count];
        for (int i = 0; i < count; i++) {
            defEnhanceSkills[i] = message.getDefEnhanceSkills(i);
        }

        count = message.getAttOtherEnhanceSkillsCount();
        this.attOtherEnhanceSkills = new int[count];
        for (int i = 0; i < count; i++) {
            attOtherEnhanceSkills[i] = message.getAttOtherEnhanceSkills(i);
        }

        count = message.getDefOtherEnhanceSkillsCount();
        this.defOtherEnhanceSkills = new int[count];
        for (int i = 0; i < count; i++) {
            defOtherEnhanceSkills[i] = message.getDefOtherEnhanceSkills(i);
        }
    }

    @Override
    public BattleResultProto copyTo() {
        BattleResultProto.Builder builder = BattleResultProto.newBuilder();
        builder.setAttackArmy(attackArmy.copyTo());
        builder.setAttackOfficer(attackOfficer.copyTo());
        builder.setAttackUser(attackUser.copyTo());
        builder.setIsAttackerBattleWin(isAttackerBattleWin);
        builder.setDefenceUser(defenceUser.copyTo());
        builder.setBattleId(battleId);
        builder.setBattleType(battleType.name());
        if (roundResultList != null && roundResultList.size() > 0) {
            for (RoundResult rr : roundResultList) {
                builder.addRoundResultList(rr.copyTo());
            }
        }
        builder.setDefenceArmy(defenceArmy.copyTo());
        builder.setDefenceOfficer(defenceOfficer.copyTo());

        if (attEnhanceSkills != null && attEnhanceSkills.length > 0) {
            for (int skillId : attEnhanceSkills) {
                builder.addAttEnhanceSkills(skillId);
            }
        }
        if (defEnhanceSkills != null && defEnhanceSkills.length > 0) {
            for (int skillId : defEnhanceSkills) {
                builder.addDefEnhanceSkills(skillId);
            }
        }

        if (attOtherEnhanceSkills != null && attOtherEnhanceSkills.length > 0) {
            for (int skillId : attOtherEnhanceSkills) {
                builder.addAttOtherEnhanceSkills(skillId);
            }
        }
        if (defOtherEnhanceSkills != null && defOtherEnhanceSkills.length > 0) {
            for (int skillId : defOtherEnhanceSkills) {
                builder.addDefOtherEnhanceSkills(skillId);
            }
        }
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] arg0) {
        try {
            BattleResultProto message = BattleResultProto.parseFrom(arg0);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

}
