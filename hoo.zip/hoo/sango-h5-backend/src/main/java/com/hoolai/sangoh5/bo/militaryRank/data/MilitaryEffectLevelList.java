package com.hoolai.sangoh5.bo.militaryRank.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.AllMilitaryEffectProto;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class MilitaryEffectLevelList implements ProtobufSerializable<AllMilitaryEffectProto> {

    List<MilitaryEffectLevel> allMilitaryEffectLevel = new ArrayList<>();

    public List<MilitaryEffectLevel> getAllMilitaryEffectLevel() {
        return allMilitaryEffectLevel;
    }

    public void setAllMilitaryEffectLevel(List<MilitaryEffectLevel> allMilitaryEffectLevel) {
        this.allMilitaryEffectLevel = allMilitaryEffectLevel;
    }

    public MilitaryEffectLevelList(byte[] bytes) {
        parseFrom(bytes);
    }

    public MilitaryEffectLevelList() {

    }

    @Override
    public AllMilitaryEffectProto copyTo() {
        AllMilitaryEffectProto.Builder builder = AllMilitaryEffectProto.newBuilder();
        if (allMilitaryEffectLevel.size() > 0) {
            for (MilitaryEffectLevel militaryEffect : allMilitaryEffectLevel) {
                builder.addMilitaryProto(militaryEffect.copyTo());
            }
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            AllMilitaryEffectProto message = AllMilitaryEffectProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(AllMilitaryEffectProto message) {
        int count = message.getMilitaryProtoCount();
        this.allMilitaryEffectLevel = new ArrayList<MilitaryEffectLevel>();
        for (int i = 0; i < count; i++) {
            MilitaryEffectLevel militaryEffect = new MilitaryEffectLevel(message.getMilitaryProto(i));
            allMilitaryEffectLevel.add(militaryEffect);
        }
    }

    public Map<Integer, Integer> militaryEffectToMap() {
        Map<Integer, Integer> militaryLevelMap = Maps.newHashMap();
        if (this.allMilitaryEffectLevel.size() > 0) {
            for (MilitaryEffectLevel mel : this.allMilitaryEffectLevel) {
                if (!militaryLevelMap.containsKey(mel.getType())) {
                    militaryLevelMap.put(mel.getType(), mel.getLevel());
                }
            }
        }
        return militaryLevelMap;
    }

    public boolean isRedPoint(User user, MilitaryEffectLevelData militaryEffectLevelData) {
        Map<Integer, Integer> militaryMap = militaryEffectToMap();
        for (MilitaryEffectType effectType : MilitaryEffectType.values()) {
            Integer effectTypeLevel = militaryMap.get(effectType.getId());
            if (effectTypeLevel != null) {
                int needLeftEar = militaryEffectLevelData.getProperty(effectTypeLevel.intValue()).getNeedEarNum();
                if (effectTypeLevel.intValue() < user.getMilitaryRank() && user.getLeftEar() >= needLeftEar) {
                    return true;
                }
            } else {
                boolean contain = false;
                switch (effectType) {
                    case OPENSOLDIER:
                    case HONORNUMADD:
                    case TRAINSOLDIERGOLD:
                    case TRAINSOLDIERNUM:
                    case DONATEINTEGRATEADD:
                    case DEDUCTLOYALTYADD:
                    case RECRUITOFFICER:
                    case NORMALRECNUMADD:
                    case BOUNTYNUMADD:
                        break;
                    default:
                        contain = true;
                }
                if (contain) {
                    int needLeftEar = militaryEffectLevelData.getProperty(1).getNeedEarNum();
                    if (user.getLeftEar() >= needLeftEar) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
