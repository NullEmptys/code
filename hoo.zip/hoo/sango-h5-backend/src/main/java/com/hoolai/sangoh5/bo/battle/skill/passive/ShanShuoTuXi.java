package com.hoolai.sangoh5.bo.battle.skill.passive;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ChangeAttackBuff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ShanShuoTuXiBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 瞬间出现敌人面前并增加N%攻击力，持续一段时间
 * 
 * @author Administrator
 *
 */
public class ShanShuoTuXi extends AttributeEnhanceSkill {

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {
        actor.setMoveSpeed(FightUnit.ROUND_SPEND);

        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]冲锋，并让自己增加攻击力比率" + +twoPercentage + ",持续回合数=" + twoRepeatCount);

        ChangeAttackBuff buff = new ChangeAttackBuff(xmlId, name, actor.name(), actor, forceType, Effect.DEFAULT_BUFF_LEVEL, twoPercentage);
        buff.withActorName(actor.name()).withTargetName(actor.name()).withRepeatCount(twoRepeatCount).withKeepBuff();
        buff.apply(actor);
        actor.addBuff(buff);
        buff.setForFront(false);// 这个技能比较特殊，两个buff是衍生的，给一个主buff给前端就行了

        actor.addBuff(new ShanShuoTuXiBuff(xmlId, actor.name(), false, Effect.MONITORING_BUFF_LEVEL, this).withActorName(actor.name()).withTargetName(actor.name())
                .withRepeatCount(MaxRepeatCount).withKeepBuff());
    }

    @Override
    public Skill clone() {
        return super.clone(new ShanShuoTuXi());
    }
}
