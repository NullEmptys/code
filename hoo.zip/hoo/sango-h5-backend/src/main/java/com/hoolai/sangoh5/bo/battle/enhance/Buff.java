package com.hoolai.sangoh5.bo.battle.enhance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.GeneratedMessage;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.BuffProto;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.fight.ActionResult;
import com.hoolai.sangoh5.bo.battle.fight.ActionType;
import com.hoolai.sangoh5.bo.battle.fight.Match;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 技能Buff，可被视为是有延续效果的Effect，有两个作用 <br/>
 * （1）前端显示Buff的动画效果，repeatCount为1代表当前这一个回合，repeatCount为0代表永久效果，仅给前端显示用 <br/>
 * （2）后端使用Buff特效处理战斗，Match下clearBuffs根据repeatCount决定Buff延续的回合数，
 * repeatCount为2代表延续至下一回合（当前回合1+下一回合1=2）
 *
 */
public class Buff extends Effect implements ProtobufSerializable {

    protected static final int maxRepeatCount = Match.maxRound;

    /**
     * 是否是一个新添加的buff
     * 后端用，用来避免math中持续性buff重复，1回合自减多次
     */
    protected boolean isNew = true;

    /**
     * buff上一回合的备份
     */
    protected transient Buff result;

    /**
     * buff持续的回合数
     */
    protected int repeatCount;

    /**
     * buff执行的回合数
     */
    protected int executeCount;

    /**
     * 是否是持续性的buff
     */
    protected boolean isKeep = false;

    /**
     * 是否需要给前端展示这个buff，一般被用做后端跟踪使用的buff可以不给前端展示<br>
     * 或者有的buff并不是每回合都有伤害，而是间断性的
     */
    protected boolean isForFront = true;

    /**
     * 是否需要反复给前端效果
     */
    protected boolean isCanRepeatPlay = false;

    protected AttributeType attributeType;

    public Buff(int targetUsedSkillXmlId, String skillName, FightUnitName executeName, int executeLevel, AttributeType attributeType) {
        super(targetUsedSkillXmlId, skillName, executeName, executeLevel);
        this.attributeType = attributeType;
    }

    @Override
    public void apply(FightUnit actor, FightUnit target, Skill skill) {
        apply(target);
    }

    public void apply(FightUnit target) {
        this.result();
        this.deltaHp = Math.max(0, deltaHp);//造成伤害最少为0点, PS如果以后有加血技能另议
        if (deltaHp == 0) return;

        target.changeHp(deltaHp);
        this.isTargetDie = target.isDead();
        target.addBattleLog(actorName + "执行" + targetUsedSkillXmlId + "[" + skillName + "]给" + targetName + "造成的伤害" + deltaHp + ",targetHp=" + target.getHp() + ",是否死亡："
                + isTargetDie);
    }

    //    public void apply(FightUnit target, Skill skill) {
    //        apply(target);
    //    }

    public Buff(BuffProto message) {
        copyFrom(message);
    }

    @Override
    public Buff withActorName(FightUnitName actorName) {
        super.withActorName(actorName);
        return this;
    }

    @Override
    public Buff withDeltaHp(int hpHurt) {
        super.withDeltaHp(hpHurt);
        return this;
    }

    @Override
    public Buff withTargetName(FightUnitName targetName) {
        super.withTargetName(targetName);
        return this;
    }

    public Buff withKeepBuff() {
        this.isKeep = true;
        return this;
    }

    protected Buff clone(Buff buff) {
        buff.isNew = this.isNew;
        buff.repeatCount = this.repeatCount;
        buff.actorName = this.actorName;
        buff.deltaHp = this.deltaHp;
        buff.isTargetDie = this.isTargetDie;
        buff.targetName = this.targetName;
        buff.targetUsedSkillXmlId = this.targetUsedSkillXmlId;
        buff.isForFront = this.isForFront;
        buff.isTrigger = this.isTrigger;
        buff.isKeep = this.isKeep;
        buff.isNew = this.isNew;
        buff.executeName = this.executeName;
        buff.currentLevel = this.currentLevel;
        buff.executeCount = this.executeCount;
        return buff;
    }

    public boolean isForFront() {
        return isForFront;
    }

    public void setForFront(boolean isForFront) {
        this.isForFront = isForFront;
    }

    @Override
    protected Buff clone() {
        return clone(new Buff(targetUsedSkillXmlId, skillName, executeName, currentLevel));
    }

    public Buff withRepeatCount(int repeatCount) {
        if (repeatCount == 0) {
            repeatCount = maxRepeatCount;
        }
        this.repeatCount = repeatCount;
        //        isForFront = true;
        return this;
    }

    public boolean available() {
        return this.repeatCount > 0;
    }

    /** buff的当前状态 */
    public Buff cloneRealTime() {
        return clone();
    }

    /** 某回合apply之前的所有数据, apply之后可能会改变数据, 本回合需要展示的数据的结果存放在这里 */
    public Buff result() {
        if (result == null) {
            result = clone();
        }
        return result;
    }

    public int getRepeatCount() {
        return repeatCount;
    }

    public void setRepeatCount(int repeatCount) {
        this.repeatCount = repeatCount;
        isForFront = true;
        isNew = true;
        isCanRepeatPlay = true;
    }

    @Override
    public String toString() {
        return "Buff [isNew=" + isNew + ", repeatCount=" + repeatCount + ", executeCount=" + executeCount + ", isKeep=" + isKeep + ", isForFront=" + isForFront
                + ", isCanRepeatPlay=" + isCanRepeatPlay + ", attributeType=" + attributeType + ", isTrigger=" + isTrigger + "]";
    }

    /**
     * 清除Buff效果
     * 
     * @param targetCollection
     */
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * @param alive
     */
    protected void doClear(FightUnit alive) {
    }

    public void repeatedOnce() {
        this.repeatCount--;
        this.executeCount++;
        this.isNew = false;
        this.isForFront = false;
    }

    public void repeatedOnce(TargetCollection tc) {
        repeatedOnce();
    }

    public boolean exchangeActorAndTarget() {
        FightUnitName temp = this.actorName;
        this.actorName = this.targetName;
        this.targetName = temp;
        return true;
    }

    public Buff(int targetUsedSkillXmlId, String skillName, FightUnitName executeName, int currentLevel) {
        super(targetUsedSkillXmlId, skillName, executeName, currentLevel);
    }

    public Buff(int targetUsedSkillXmlId, String skillName, FightUnitName executeName, boolean is4front, int currentLevel) {
        super(targetUsedSkillXmlId, skillName, executeName, currentLevel);
        this.isForFront = is4front;
    }

    public boolean isCan4FrontAttacking() {
        return true;
    }

    public List<FightUnit> targetEnhance(FightUnit actor, FightUnit target, TargetCollection targetCollection) {
        return new ArrayList<FightUnit>();
    }

    @Override
    public void copyFrom(GeneratedMessage arg0) {
        BuffProto message = (BuffProto) arg0;
        this.isNew = message.getIsNew();
        this.repeatCount = message.getRepeatCount();
        this.isKeep = message.getIsKeep();
        this.isForFront = message.getIs4Front();
        this.deltaHp = message.getDeltaHp();
        this.targetName = FightUnitName.valueOf(message.getTargetName());
        this.isTargetDie = message.getIsTargetDie();
        this.targetUsedSkillXmlId = message.getTargetUsedSkillXmlId();// default 0 ==target not used skill
        this.isSelfHurt = message.getIsSelfHurt();
        this.actorName = FightUnitName.valueOf(message.getActorName());

        int attri = message.getAttributeType();
        if (attri >= 0) {
            this.attributeType = AttributeType.values()[attri];
        }
    }

    @Override
    public BuffProto copyTo() {
        BuffProto.Builder builder = BuffProto.newBuilder();
        builder.setActorName(actorName.name());
        builder.setIs4Front(isForFront);
        builder.setIsKeep(isKeep);
        builder.setIsNew(isNew);
        builder.setRepeatCount(repeatCount);
        builder.setDeltaHp(deltaHp);
        builder.setIsSelfHurt(isSelfHurt);
        builder.setIsTargetDie(isTargetDie);
        builder.setTargetName(targetName.name());
        builder.setTargetUsedSkillXmlId(targetUsedSkillXmlId);

        if (this.attributeType != null) {
            builder.setAttributeType(attributeType.ordinal());
        } else {
            builder.setAttributeType(-1);
        }
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] arg0) {
        try {
            BuffProto message = BuffProto.parseFrom(arg0);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @SuppressWarnings("unchecked")
    public List<FightUnit> targetEnhance(FightUnit actor, FightUnit target, TargetCollection targetCollection, Action action) {
        return Collections.EMPTY_LIST;
    }

    @Override
    public int getCurrentLevel() {
        return currentLevel;
    }

    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
    }

    public boolean isKeep() {
        return isKeep;
    }

    protected boolean isTrigger = false;

    public boolean isTrigger() {
        return isTrigger;
    }

    public void setTrigger(boolean isTrigger) {
        this.isTrigger = isTrigger;
    }

    public boolean getIsNew() {
        return isNew;
    }

    public void setIsNew(boolean isNew) {
        this.isNew = isNew;
    }

    public AttributeType getAttributeType() {
        return attributeType;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public boolean isCanRepeatPlay() {
        return isCanRepeatPlay;
    }

    public void setCanRepeatPlay(boolean isCanRepeatPlay) {
        this.isCanRepeatPlay = isCanRepeatPlay;
    }

    /**
     * 一回合中执行了所有的伤害之后执行的buff
     * 
     * @param actionResultList
     * @param tc
     */
    public void targetEnhanceAfterExcuteBuffs(List<ActionResult> actionResultList, TargetCollection tc) {
        return;
    }

    protected ActionResult findActionResult(int skillXmlId, FightUnit actor, List<ActionResult> actionResultList) {
        for (ActionResult actionResult : actionResultList) {
            if (actionResult.getActorName().equals(actor.name())) {
                return actionResult;
            }
        }

        // 一般不会有这种情况
        ActionResult actionResult = new ActionResult(skillXmlId, actor.name(), ActionType.NONE, Buff.DEFAULT_BUFF_LEVEL);
        actionResult.setBuffList(new ArrayList<Buff>());
        return actionResult;
    }

    public void needRepeatPlay() {
        this.isForFront = true;
        this.isNew = true;
        this.isCanRepeatPlay = true;
    }
}
