package com.hoolai.sangoh5.bo.battle.skill.soldier.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.ForceUnitType;
import com.hoolai.sangoh5.bo.battle.skill.Occasion;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.SkillType;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.bo.soldier.RestraintFinder;
import com.hoolai.sangoh5.util.ProbabilityGenerator;

public class BaseSoldierPhysicsSkill extends IndependentSkill {

    protected FightUnit target;

    protected FightUnit actor;

    public BaseSoldierPhysicsSkill() {
        this.xmlId = 0;
        this.skillId = 0;
        this.level = 0;
        this.occasion = Occasion.BEFORE_ACTION;
        this.percentage = 0;
        this.value = 0;
        this.skillType = SkillType.ACTIVE;
        this.chance = 100;
        this.attackUnitType = ForceUnitType.SOLDIER;
    }

    public BaseSoldierPhysicsSkill(RestraintFinder finder, ProbabilityGenerator probabilityGenerator) {
        this();
        this.restraintFinder = finder;
        this.pg = probabilityGenerator;
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        this.actor = actor;
        target = actor.getDefender();
        if (null == target) {
            return null;
        }

        List<FightUnit> targets = new ArrayList<FightUnit>();
        Effect effect = new Effect(Effect.NONE_USED_SKILL_ID, "物理攻击", target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name()).withIsBaseHurt(true)
                .withDeltaHp(calculateLostPoint());
        // 传给前端显示顺序修改，因为targetDefence可能是加血技能
        target.addEffect(effect);

        targets.add(target);
        targetDefence(actor, target, effect, null, tc, targets, currentLevel);
        return targets;
    }

    public int calculateLostPoint() {
        int lostHp = 0;

        if (target.isOfficer()) {
            lostHp = calculateLostPointToOfficer();
        } else {
            lostHp = calculateLostPointToSoldier();
        }

        if (lostHp > 1500) {
            if (logger.isDebugEnabled()) {
                logger.debug(actor.name() + "攻击" + target.name() + ",伤害=" + lostHp);
            }
        }
        return lostHp;
    }

    protected int calculateLostPointToSoldier() {
        if (logger.isDebugEnabled()) {
            // logger.debug("actor="+actor.name()+",target="+target.name());
        }
        int lostPoint = calculateLostPointToSoldier(actor.getOriginalHp(), actor.getAttNum(), actor.attackPoint(), target.defencePoint(), getRestraintRate(actor, target));

        return lostPoint;
    }

    /**
     * 士兵对士兵的伤害
     * 
     * 兵间战斗伤害公式 伤害 = 士兵总攻击 * 士兵数量 * 数量差的百分比 / 敌方总防御 * 系数(0.09) - 修正值(25)
     * 士兵总攻击 =
     * 基础攻击 * (1 + 技能攻击加成 + buff攻击加成 - 敌方技能削弱攻击百分比) 士兵总防御 = 基础防御 * (1 +
     * 技能防御加成 +
     * buff防御加成 - 敌方技能削弱防御百分比)
     * 
     * 供给技能中临时改变基本属性的计算伤害
     * 
     * @param attackerNum
     *        攻击者的剩余兵力
     * @param attOffLv
     *        攻击者将领等级
     * @param attackPoint
     *        攻击者的攻击属性（可根据技能临时增加或减少）
     * @param defencePoint
     *        防御者的防御属性（可根据技能临时增加或减少）
     * @return
     */
    protected int calculateLostPointToSoldier(int attackerOriginalNum, int attackerNum, float attackPoint, float defencePoint, float restraintRate) {

        float a = Math.max(0.45f, Float.valueOf(attackerNum) / attackerOriginalNum);

        double realHp = ((attackPoint * attackerOriginalNum * a / defencePoint * 0.04) + value) * restraintRate;
        //        if (logger.isDebugEnabled()) {
        // logger.debug(":attackerNum="+attackerNum+",attackPoint="+attackPoint
        // +",defencePoint="+defencePoint+",defenderNum="+defenderNum+",伤害="+a);
        //    }

        return (int) realHp;
    }

    /**
     * 士兵对将领的伤害公式 提供给技能中临时改变基本属性的计算伤害
     * 
     * @param actor
     *        攻击者
     * @param target
     *        防御者
     * @param attackPoint
     *        攻击者的攻击属性（可根据技能临时增加或减少）
     * @param attackNum
     *        攻击者的剩余兵力
     * @param attackOfficerLv
     *        攻击者的将领等级
     * @param defencePoint
     *        防御者的防御属性（可根据技能临时增加或减少）
     * @return
     */
    protected int calculateLostPointToOfficer(int attOriginalNum, int attNum, float attackPoint, float targetAttackPoint, float targetDefencePoint, int targetOfficerStarLevel,
            int targetOfficerLv, float restraintRate) {
        float a = Math.max(0.45f, Float.valueOf(attNum) / attOriginalNum);// 数量差系数

        double realHp = (attackPoint * attOriginalNum * a / ((targetAttackPoint + targetDefencePoint) * targetOfficerLv)) * (targetOfficerLv * targetOfficerStarLevel / 1.5) + 180;
        realHp = (realHp * 0.3f + value) * restraintRate;

        return (int) realHp;
    }

    protected int calculateLostPointToOfficer() {
        int realHp = calculateLostPointToOfficer(actor.getOriginalHp(), actor.getAttNum(), actor.attackPoint(), target.attackPoint(), target.defencePoint(),
                target.getOfficerStarLevel(), target.getOfficerLevel(), getRestraintRate(actor, target));
        //        if (logger.isDebugEnabled()) {
        // logger.debug(actor.name()+":AttNum="+actor.getAttNum()+",attackPoint="+actor.attackPoint()
        // +",defencePoint="+target.defencePoint()+",伤害="+a);
        //    }
        return realHp;
    }

    public int calculateLostPoint4AttackSkill(FightUnit actor, FightUnit target) {
        int lostHp = 0;

        float attackPoint = actor.attackPoint() * percentage;
        if (target.isOfficer()) {
            lostHp = calculateLostPointToOfficer(actor.getOriginalHp(), actor.getAttNum(), attackPoint, target.attackPoint(), target.defencePoint(), target.getOfficerStarLevel(),
                    target.getOfficerLevel(), getRestraintRate(actor, target));
        } else {
            lostHp = calculateLostPointToSoldier(actor.getOriginalHp(), actor.getAttNum(), attackPoint, target.defencePoint(), getRestraintRate(actor, target));
        }

        return lostHp;
    }

    protected int randomLostPoint(float lostPoint) {
        // 伤害浮动 最小值：INT(伤害*1)最大值：INT(伤害*1.1)
        int lostMinPoint = Math.round(lostPoint * 1f);
        int lostMaxPoint = Math.round(lostPoint * 1.1f);

        return lostMinPoint > 0 ? pg.getRandomNumber(lostMinPoint, lostMaxPoint) : 1;
    }

    public FightUnit getTarget() {
        return target;
    }

    @Override
    public void setProbabilityGenerator(ProbabilityGenerator pg) {
        this.pg = pg;
    }

    @Override
    public Skill clone() {
        return super.clone(new BaseSoldierPhysicsSkill());
    }

}
