package com.hoolai.sangoh5.bo.user.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class UserProperty extends JsonProperty {

    private int exp;

    private int foodLimit;

    private int goldAdd;

    private int trainSoldierNum;

    private int scienceAdd;

    private int plunder;

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

    public int getFoodLimit() {
        return foodLimit;
    }

    public void setFoodLimit(int foodLimit) {
        this.foodLimit = foodLimit;
    }

    public int getGoldAdd() {
        return goldAdd;
    }

    public void setGoldAdd(int goldAdd) {
        this.goldAdd = goldAdd;
    }

    public int getTrainSoldierNum() {
        return trainSoldierNum;
    }

    public void setTrainSoldierNum(int trainSoldierNum) {
        this.trainSoldierNum = trainSoldierNum;
    }

    public int getScienceAdd() {
        return scienceAdd;
    }

    public void setScienceAdd(int scienceAdd) {
        this.scienceAdd = scienceAdd;
    }

    public int getPlunder() {
        return plunder;
    }

    public void setPlunder(int plunder) {
        this.plunder = plunder;
    }

}
