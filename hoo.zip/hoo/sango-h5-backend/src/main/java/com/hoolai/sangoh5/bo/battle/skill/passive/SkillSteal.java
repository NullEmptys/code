package com.hoolai.sangoh5.bo.battle.skill.passive;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 进入战斗后随机偷学敌将任意一个技能(不区分文武将)
 * 
 * @author Administrator
 *
 */
public class SkillSteal extends AttributeEnhanceSkill {

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {

        super.apply(actor, tc);

        FightUnit target = tc.getAlive(FightUnitName.officerUnitName(!actor.isAttacker()));
        int[] skills = target.getOfficerSkills();
        if (skills.length > 1) {
            int index = pg.getRandomNumber(1, skills.length - 1);
            int skillId = skills[index];
            actor.addStealSkill(skillId);
            actor.addBeforeBattleBuff(new Buff(xmlId, name, actor.name(), Effect.DEFAULT_BUFF_LEVEL).withActorName(actor.name()).withTargetName(actor.name())
                    .withRepeatCount(skillId));
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]偷取对方" + skillId);
        }
    }

    @Override
    public Skill clone() {
        return super.clone(new SkillSteal());
    }
}
