package com.hoolai.sangoh5.bo.battle.skill;

public enum ForceCore {

	NONE, // 对现匹配的target周围的敌方有效
	SELF; // 对自己周围的敌方都有效
	
	public static ForceCore convert(String core){
		if("0".equals(core)){
			return ForceCore.NONE;
		}else{
			return ForceCore.valueOf(core.toUpperCase());
		}
	}
}
