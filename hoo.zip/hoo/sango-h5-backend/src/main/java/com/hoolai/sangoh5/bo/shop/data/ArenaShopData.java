package com.hoolai.sangoh5.bo.shop.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

@Component
public class ArenaShopData extends ShopData {

	@PostConstruct
	public void init() {
		try {
			initData("com/hoolai/sangoh5/arenaGoods.json", ShopProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
