package com.hoolai.sangoh5.bo.pve;

import java.util.concurrent.TimeUnit;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.ProvisionProto;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryEffectType;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryRankProperty;
import com.hoolai.sangoh5.bo.payment.MoonWeekCard;
import com.hoolai.sangoh5.bo.payment.data.MoonWeekCardData;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.bo.user.data.UserData;
import com.hoolai.sangoh5.bo.user.data.UserProperty;
import com.hoolai.sangoh5.repo.ItemRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.service.BusinessDomainService;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Provision implements ProtobufSerializable<ProvisionProto> {

    private int provision;

    private long lastRevertTime;

    transient private int revertLeftTime;

    transient private long userId;

    transient private int topLimit;// 粮草购买上限

    transient private int revertLimit;// 粮草恢复上限

    transient private UserData userData;

    transient private UserRepo userRepo;

    transient private ItemRepo itemRepo;

    transient private MoonWeekCardData moonWeekCardData;

    transient private BusinessDomainService businessDomainService;

    public void setUserRepo(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public Provision(String value) {
        String[] members = value.split(",");
        this.provision = Integer.parseInt(members[0]);
        this.lastRevertTime = Long.parseLong(members[1]);
    }

    public Provision() {
    }

    public Provision(long userId) {
        this.userId = userId;
        this.provision = 0;
    }

    public Provision(long userId, byte[] bytes) {
        this(userId);
        parseFrom(bytes);
    }

    public void checkCanAddProvision() {
        if (provision >= topLimit) {
            throw new BusinessException(ErrorCode.PRIVISION_ALREADY_FULL);
        }
    }

    public void addProvision(int provisionAdd) {
        provision += provisionAdd;
    }

    public void refresh(ConstantsPoolData constantsPool) {
        User user = userRepo.findUser(userId);
        UserProperty userProperty = userData.getProperty(user.getRank());
        long revertNeedTime = (int) TimeUnit.MINUTES.toMillis(constantsPool.getProperty(4).getValue());
        MilitaryRankProperty militaryRankProperty = businessDomainService.getMilitaryEffectValue(userId, MilitaryEffectType.FOODLIMITADD);
        MoonWeekCard moonWeekCard = itemRepo.findMoonWeekCard(userId);

        int userFoodLimit = userProperty.getFoodLimit();// 用户等级
        int militaryRankLimit = militaryRankProperty == null ? 0 : militaryRankProperty.getFoodLimitAdd();// 军功
        int moonWeekLimit = moonWeekCard.provisionNum(moonWeekCardData);

        // 粮草恢复上限
        revertLimit = userFoodLimit + militaryRankLimit + moonWeekLimit;
        topLimit = revertLimit * 3;

        long currentTimeMillis = com.hoolai.sango.util.TimeUtil.currentTimeMillis();
        if (lastRevertTime == 0) {//第一次打开农田
            // this.provision = revertLimit;
            this.lastRevertTime = currentTimeMillis;
            this.revertLeftTime = (int) TimeUnit.MILLISECONDS.toSeconds(this.lastRevertTime + revertNeedTime - currentTimeMillis);
        } else if (lastRevertTime > 0) {
            int revertedTimes = (int) ((currentTimeMillis - lastRevertTime) / revertNeedTime);
            int topLimitLeftProvision = revertLimit - this.provision;
            if (topLimitLeftProvision > 0 && revertedTimes > 0) {
                this.provision = Math.min(this.provision + revertedTimes * 1, revertLimit);
            }
            this.lastRevertTime = this.provision == revertLimit ? currentTimeMillis : (lastRevertTime + revertedTimes * revertNeedTime);

            this.revertLeftTime = (int) TimeUnit.MILLISECONDS.toSeconds(this.lastRevertTime + revertNeedTime - currentTimeMillis);
        }
    }

    public String value() {
        return new StringBuilder().append(this.provision).append(",").append(this.lastRevertTime).toString();
    }

    public void checkEnough(int reduceProvision) {
        if (this.provision < reduceProvision) {
            throw new BusinessException(ErrorCode.PROVISTION_NOT_ENOUGH);
        }
    }

    public void reduce(int reduceProvision) {
        this.provision -= reduceProvision;
    }

    public void setUserData(UserData userData) {
        this.userData = userData;
    }

    @Override
    public void copyFrom(ProvisionProto message) {
        this.lastRevertTime = message.getLastRevertTime();
        this.provision = message.getProvision();
    }

    @Override
    public ProvisionProto copyTo() {
        ProvisionProto.Builder builder = ProvisionProto.newBuilder();
        builder.setProvision(provision);
        builder.setLastRevertTime(lastRevertTime);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ProvisionProto message = ProvisionProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    public int getTopLimit() {
        return topLimit;
    }

    public void setTopLimit(int topLimit) {
        this.topLimit = topLimit;
    }

    public long getLastRevertTime() {
        return lastRevertTime;
    }

    public void setLastRevertTime(long lastRevertTime) {
        this.lastRevertTime = lastRevertTime;
    }

    public int getProvision() {
        return provision;
    }

    public void setProvision(int provision) {
        this.provision = provision;
    }

    public int getRevertLeftTime() {
        return revertLeftTime;
    }

    public void setRevertLeftTime(int revertLeftTime) {
        this.revertLeftTime = revertLeftTime;
    }

    public int getRevertLimit() {
        return revertLimit;
    }

    public void setRevertLimit(int revertLimit) {
        this.revertLimit = revertLimit;
    }

    /**
     * @return the userId
     */
    public long getUserId() {
        return userId;
    }

    public void setBoFactory(BoFactory boFactory) {

    }

    public void setItemRepo(ItemRepo itemRepo) {
        this.itemRepo = itemRepo;
    }

    public void setMoonWeekCardData(MoonWeekCardData moonWeekCardData) {
        this.moonWeekCardData = moonWeekCardData;
    }

    public void setBusinessDomainService(BusinessDomainService businessDomainService) {
        this.businessDomainService = businessDomainService;
    }

}
