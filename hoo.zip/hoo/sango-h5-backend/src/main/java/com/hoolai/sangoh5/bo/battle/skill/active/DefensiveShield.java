package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.DefensiveShieldBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.ShenDunDefence;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 
 * 施放技能为自身增加一个护盾，该护盾生命值为将领生命值上限的5%
 * 
 * @author Administrator
 *
 */
public class DefensiveShield extends BaseOfficerPhysicsSkill {

    @Override
    public Skill clone() {
        return super.clone(new DefensiveShield());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {

        ShenDunDefence shenDunDefence = (ShenDunDefence) actor.findDefencePassiveSkill(xmlId);
        Buff buff = actor.findBuff(xmlId);
        if (shenDunDefence == null) {
            shenDunDefence = new ShenDunDefence(xmlId, name, Math.round(actor.getOriginalHp() * percentage));
            actor.addCounterAttackSkills(shenDunDefence);
            actor.addBuff(new DefensiveShieldBuff(xmlId, actor.name(), false, currentLevel, shenDunDefence).withActorName(actor.name()).withTargetName(actor.name())
                    .withRepeatCount(repeatCount).withKeepBuff());
        } else {
            shenDunDefence.reset(Math.round(actor.getOriginalHp() * percentage));
            buff.setRepeatCount(repeatCount);
        }

        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给自己增加血量护盾,持续回合数=" + repeatCount);

        return new ArrayList<FightUnit>();
    }
}
