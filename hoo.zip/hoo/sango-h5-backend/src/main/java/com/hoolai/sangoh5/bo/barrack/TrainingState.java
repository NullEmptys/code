package com.hoolai.sangoh5.bo.barrack;

import java.util.concurrent.TimeUnit;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.BarrackProtocolBuffer.TrainingStateProto;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.bo.item.data.ItemData;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryEffectType;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryRankProperty;
import com.hoolai.sangoh5.bo.user.data.UserData;
import com.hoolai.sangoh5.service.BusinessDomainService;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.util.TimeUtil;

/**
 * 训练士兵的状态
 * 
 * 
 */
public class TrainingState implements ProtobufSerializable<TrainingStateProto> {

    @SuppressWarnings("unused")
    private static final long serialVersionUID = -6087840878745576720L;

    public static enum SpeedUpItemType {
        reduceHalfAnHour(101) {

            @Override
            public String toString() {
                return "墨家残页";
            }
        },
        reduceOneHour(102) {

            @Override
            public String toString() {
                return "墨家残卷";
            }
        },
        reduceTwoHours(103) {

            @Override
            public String toString() {
                return "墨家秘籍";
            }
        },
        reduceFourHours(104) {

            @Override
            public String toString() {
                return "墨家全书";
            }
        };
        //        finishImmediately(105) {
        //
        //            @Override
        //            public String toString() {
        //                return "墨家真迹";
        //            }
        //        };

        private int itemXmlId;

        SpeedUpItemType(int itemXmlId) {
            this.itemXmlId = itemXmlId;
        }

        public int itemXmlId() {
            return itemXmlId;
        }

        public long applyReduceTime(long needTime, ItemData itemData) {
            //            if (this == finishImmediately) {
            //                return 0;
            //            }
            //            return needTime - TimeUnit.MINUTES.toMillis((int) Math.pow(2, this.ordinal()));
            return needTime - TimeUnit.MINUTES.toMillis(itemData.getProperty(this.itemXmlId).getValue());
        }

        public static SpeedUpItemType getType(int itemXmlId) {
            // 从101到105，对应ordinal是0到4
            int startIndex = 101;
            return SpeedUpItemType.values()[itemXmlId - startIndex];
        }
    }

    /**
     * 本次训兵数量
     */
    private int trainingNum;

    /**
     * 开始训练时间（毫秒）
     */
    private long startTrainingTime;

    /**
     * 需要训练的时间（毫秒）
     */
    private long needTrainingTime;

    /**
     * 花费的金钱， 不持久化
     */
    transient private int expense;

    /**
     * 剩余时间（毫秒），不持久化
     */
    transient private long leftTrainingTime;

    transient private ConstantsPoolData constantsPool;

    transient private UserData userData;

    transient private BusinessDomainService businessDomainService;

    /**
     * 新建一个训练
     * 
     * @param userRank
     */
    public TrainingState(long userId, int trainingNum, ConstantsPoolData constantsPool, UserData userData, int level, BusinessDomainService businessDomainService) {
        this.businessDomainService = businessDomainService;
        this.constantsPool = constantsPool;
        this.userData = userData;
        this.startTrainingTime = TimeUtil.currentTimeMillis();
        this.businessDomainService = businessDomainService;
        this.trainingNum = calTrainSoldierNum(userId, trainingNum, level);
        this.needTrainingTime = calculateNeedTime(userId, this.trainingNum);
        this.expense = calculateExpense(userId, this.trainingNum);
        this.leftTrainingTime = calculateLeftTime();
    }

    /**
     * */
    public int calculateExpense(long userId, int trainingNum) {
        int trainSoldierGoldDec = 0;
        MilitaryRankProperty property = businessDomainService.getMilitaryEffectValue(userId, MilitaryEffectType.TRAINSOLDIERGOLD);
        if (property != null) {
            trainSoldierGoldDec = property.getTrainSoldierGoldDec();
        }
        //        return (int)Math.round(0.5f * trainingNum * (100- trainSoldierGoldDec)/100.0);
        return ((int) Math.round((trainingNum - trainSoldierGoldDec) / 100)) * constantsPool.getProperty(28).getValue();
    }

    public long calculateNeedTime(long userId, int soldierNum) {
        int trainSoldierTimeDec = 0;
        MilitaryRankProperty militaryRankProperty = businessDomainService.getMilitaryEffectValue(userId, MilitaryEffectType.TRAINSOLDIERTIME);
        if (militaryRankProperty != null) {
            trainSoldierTimeDec = militaryRankProperty.getTrainSoldierTimeDec();
        }
        long soldierTime = (soldierNum / 200) * constantsPool.getProperty(38).getValue() * 1000;
        long militaryDecTime = (long) Math.floor((trainSoldierTimeDec / 100.0) * soldierTime);
        return soldierTime - militaryDecTime;
    }

    public boolean isFinished() {
        this.setLeftTrainingTime(calculateLeftTime());
        return this.getLeftTrainingTime() <= 0;
    }

    /**
     * @param userRank
     * @param speedUpItemType
     */
    public void speedUp(SpeedUpItemType speedUpItemType, ItemData itemData) {
        if (isFinished()) {
            throw new BusinessException(ErrorCode.SHALL_CALL_FINISH_FIRST);
        }
        setNeedTrainingTime(speedUpItemType.applyReduceTime(getNeedTrainingTime(), itemData));
        this.setLeftTrainingTime(calculateLeftTime());
    }

    public void speedUp(float rate) {
        if (!isFinished()) {
            this.setNeedTrainingTime((long) (this.getNeedTrainingTime() * rate));
        }
    }

    private long calculateLeftTime() {
        return (this.getStartTrainingTime() + this.getNeedTrainingTime() - TimeUtil.currentTimeMillis()) / 1000;
    }

    public int getExpense() {
        return expense;
    }

    public void setExpense(int expense) {
        this.expense = expense;
    }

    public int getTrainingNum() {
        return trainingNum;
    }

    public void setTrainingNum(int trainingNum) {
        this.trainingNum = trainingNum;
    }

    public long getLeftTrainingTime() {
        return leftTrainingTime;
    }

    public void setLeftTrainingTime(long leftTrainingTime) {
        this.leftTrainingTime = leftTrainingTime;
    }

    public long getStartTrainingTime() {
        return startTrainingTime;
    }

    public void setStartTrainingTime(long startTrainingTime) {
        this.startTrainingTime = startTrainingTime;
    }

    public long getNeedTrainingTime() {
        return needTrainingTime;
    }

    public void setNeedTrainingTime(long needTrainingTime) {
        this.needTrainingTime = needTrainingTime;
    }

    /**
     * Constructs a <code>String</code> with all attributes in name = value
     * format.
     * 
     * @return a <code>String</code> representation of this object.
     */
    public String toString() {
        final String TAB = "    ";
        StringBuilder retValue = new StringBuilder();
        retValue.append("TrainingState ( ").append(super.toString()).append(TAB).append("trainingNum = ").append(this.trainingNum).append(TAB).append("startTrainingTime = ")
                .append(this.startTrainingTime).append(TAB).append("needTrainingTime = ").append(this.needTrainingTime).append(TAB).append("expense = ").append(this.expense)
                .append(TAB).append("leftTrainingTime = ").append(this.leftTrainingTime).append(TAB).append(" )");
        return retValue.toString();
    }

    public TrainingStateProto copyTo() {
        TrainingStateProto.Builder protoBuilder = TrainingStateProto.newBuilder();
        protoBuilder.setStartTrainingTime((getStartTrainingTime()));
        protoBuilder.setNeedTrainingTime((getNeedTrainingTime()));
        protoBuilder.setTrainingNum((getTrainingNum()));
        return protoBuilder.build();
    }

    public void copyFrom(TrainingStateProto proto) {
        setStartTrainingTime((proto.getStartTrainingTime()));
        setNeedTrainingTime((proto.getNeedTrainingTime()));
        setTrainingNum((proto.getTrainingNum()));
    }

    public byte[] toByteArray() {
        throw new RuntimeException("not surpport");
    }

    public void parseFrom(byte[] input) {
        try {
            TrainingStateProto proto = TrainingStateProto.parseFrom(input);
            copyFrom(proto);
        } catch (InvalidProtocolBufferException ex) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    public TrainingState() {
    }

    public TrainingState(TrainingStateProto message) {
        this();
        this.copyFrom(message);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (needTrainingTime ^ (needTrainingTime >>> 32));
        result = prime * result + (int) (startTrainingTime ^ (startTrainingTime >>> 32));
        result = prime * result + trainingNum;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        TrainingState other = (TrainingState) obj;
        if (needTrainingTime != other.needTrainingTime) return false;
        if (startTrainingTime != other.startTrainingTime) return false;
        if (trainingNum != other.trainingNum) return false;
        return true;
    }

    private int calTrainSoldierNum(long userId, int num, int level) {
        MilitaryRankProperty property = businessDomainService.getMilitaryEffectValue(userId, MilitaryEffectType.TRAINSOLDIERNUM);
        return Math.min(num, userData.getProperty(level).getTrainSoldierNum() + (property == null ? 0 : property.getTrainSoldierNumAdd()));
    }
}
