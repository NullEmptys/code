package com.hoolai.sangoh5.bo.item.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.stereotype.Component;

import com.hoolai.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonData;


@Component
public class GoodsData extends JsonData<GoodsProperty>{
	
	@PostConstruct
    public void init(){
    	try {
    		initData("com/hoolai/sangoh5/goods.json", GoodsProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }

	@Override
	protected void checkProperty(GoodsProperty property) {
		int id = property.getId();
		int onSale = property.getOnSale();
		if(onSale != 1 && onSale != 2){
			throw new BusinessException(ErrorCode.SYSTEM_ERROR.code, "该道具是卖呢还是不卖呢？-----> xmlId : " + id);
		}
		
		if(ArrayUtils.contains(property.getCostAmount(), 0)){
			throw new BusinessException(ErrorCode.SYSTEM_ERROR.code, "该道具是免费的么？为什么消耗0货币呢？-----> xmlId : " + id);
		}
		
		if(property.getCostType().length != property.getCostAmount().length){
			throw new BusinessException(ErrorCode.SYSTEM_ERROR.code, "货币长度不一致----> xmlId : "+id);
		}
	}
}
