package com.hoolai.sangoh5.bo.battle.skill.enhance;

import java.util.Arrays;

import com.hoolai.sangoh5.bo.battle.skill.Skill;

/**
 * 对独立存在的技能进行加成的技能
 * 比如增加指定技能的伤害百分比或触发几率
 * 
 * 暂时这类技能不能被改变
 */
public abstract class EnhanceSkill extends Skill {

    protected int[] mainSkillIds;

    protected boolean isForceAllSkill = true;// 是否是针对所有技能都加成，否，mainSkillIds一定要设置值

    public EnhanceSkill() {
    }

    public void setMainSkillIds(int[] mainSkillIds) {
        this.isForceAllSkill = false;
        this.mainSkillIds = mainSkillIds;
    }

    protected boolean inMainSkillIds(int skillId) {
        Arrays.sort(mainSkillIds);
        return Arrays.binarySearch(mainSkillIds, skillId) >= 0;
    }

    /**
     * 判断是否需要进行加成
     * 
     * @param mainSkill
     * @return
     */
    public void enhance(Skill mainSkill) {
        if (isForceAllSkill || inMainSkillIds(mainSkill.getSkillId())) {
            switch (this.forceType) {
                case FRIEND:
                    enhance0(mainSkill, this.percentage);//对自己增加
                    //                    if (logger.isDebugEnabled()) {
                    //logger.debug(this.name + "对自己技能"+mainSkill.name+"进行增加了【" + findPercentage() + "】，增加后的percentage："+mainSkill.getPercentage());
                    //                    }
                    break;
                case ENEMY:
                    //enhance0(mainSkill, -1 * findPercentage());//对敌人减少
            }
        }
    }

    public void enhance4Enemy(Skill mainSkill) {
        if (mainSkill.getXmlId() <= 0) { //好友加成不能被削弱
            return;
        }

        enhance0(mainSkill, -this.percentage);//对敌人减少
    }

    /**
     * 真正对技能进行加成
     * 
     * @param mainSkill
     */
    protected abstract void enhance0(Skill mainSkill, float percentageAdd);

}
