package com.hoolai.sangoh5.repo.impl.key;

import java.util.concurrent.TimeUnit;

import com.hoolai.sangoh5.util.Constant;

public class PvpKey {

    public static final long LOCK_CITY_EXPTIME = TimeUnit.MINUTES.toMillis(1);

    public static final long LOCK_OFFICER_EXPTIME = TimeUnit.MINUTES.toMillis(1);

    private static final String prefix = "pvp";

    public static String getCampsKey() {
        return new StringBuilder().append(prefix).append(Constant.separator).append("cid").toString();
    }

    public static String getPvpUserKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("uid").toString();
    }

    public static String getPvpLimitationKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("lit").toString();
    }

    public static String getMainCityKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("mid").toString();
    }

    public static String getFightUserKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("ufid").toString();
    }

    public static String getLockCityKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("lcid").toString();
    }

    public static String getLockOfficerKey(long userId, int officerId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append(officerId).append(Constant.separator).append("loid")
                .toString();
    }

    public static String getPvpUserDifLevelOccupyKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("occupyids").toString();
    }

    public static String getSangoStateKey(int stateId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(stateId).append(Constant.separator).append("stid").toString();
    }

    public static String getPvpRevengeInfoKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("revenge").toString();
    }
}
