package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ChangeAttackBuff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ChangeDefenseBuff;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 
 * 以自身为中心点，所有敌人受到一定伤害,并降低攻防
 * 
 * @author Administrator
 *
 */
public class HanWuJi extends BaseOfficerPhysicsSkill {

    @Override
    public Skill clone() {
        return super.clone(new HanWuJi());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            Effect effect = rangeHurt(actor, target, currentLevel);
            Buff buff = keepHurt(actor, target, currentLevel);
            targets.add(target);
            targetDefence(actor, target, effect, buff, tc, targets, currentLevel);
        }
        return targets;
    }

    /**
     * 持续伤害
     * 
     * @param actor
     * @param currentLevel
     * @param target
     */
    private Buff keepHurt(FightUnit actor, FightUnit target, int currentLevel) {
        Buff buff = target.findBuff(this.xmlId);
        String logTemp = "";
        if (buff == null) {
            if (this.twoAttribute == AttributeType.ATTACK) {
                logTemp = "减少攻击力比率";
                buff = new ChangeAttackBuff(xmlId, name, target.name(), actor, forceType, Action.DEFAULT_ACTION_LEVEL, twoPercentage).withKeepBuff().withActorName(actor.name())
                        .withTargetName(target.name()).withRepeatCount(twoRepeatCount);
            } else if (this.twoAttribute == AttributeType.DEFENCE) {
                logTemp = "减少防御力比率";
                buff = new ChangeDefenseBuff(xmlId, name, target.name(), actor, forceType, Action.DEFAULT_ACTION_LEVEL, twoPercentage).withKeepBuff().withActorName(actor.name())
                        .withTargetName(target.name()).withRepeatCount(twoRepeatCount);
            }
            buff.apply(target);
            target.addBuff(buff);
        } else {
            buff.setRepeatCount(twoRepeatCount);
        }

        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]让" + target.name() + logTemp + +twoPercentage + ",持续回合数=" + twoRepeatCount);
        return buff;
    }

    /**
     * 范围内伤害
     * 
     * @param actor
     * @param currentLevel
     * @param referPos
     * @param target
     */
    private Effect rangeHurt(FightUnit actor, FightUnit target, int currentLevel) {
        Effect effect = new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withDeltaHp(calculateLostPoint4Skill(actor, target))
                .withTargetName(target.name());
        target.addEffect(effect);
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "造成伤害=" + effect.getDeltaHp());
        return effect;
    }
}
