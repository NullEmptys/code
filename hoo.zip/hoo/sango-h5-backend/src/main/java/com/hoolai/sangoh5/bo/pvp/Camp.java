package com.hoolai.sangoh5.bo.pvp;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import com.google.common.collect.Sets;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.CampProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 阵营
 * 
 * @author Administrator
 *
 */
public class Camp implements ProtobufSerializable<CampProto> {

    private int id;

    private String name;

    private Set<Integer> states;

    /** 本周排名 **/
    private int rank;

    /** 上周排名 **/
    private int lastRank;

    /** 上周阵营 **/
    private Set<Integer> lastWeekStates;

    private transient List<SangoState> sangoStates;

    public Camp(int id, String name, Set<Integer> states) {
        this.id = id;
        this.name = name;
        this.states = states;
        this.lastWeekStates = Collections.emptySet();
    }

    public Camp(CampProto message) {
        copyFrom(message);
    }

    public boolean userIsAtThisCamp(int userState){
    	if(states.contains(userState)){
    		return true;
    	}
    	return false;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Integer> getStates() {
        return states;
    }

    public void setStates(Set<Integer> states) {
        this.states = states;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    @Override
    public CampProto copyTo() {
        CampProto.Builder builder = CampProto.newBuilder();
        builder.setId(id);
        builder.setName(name);

        for (int state : states) {
            builder.addStates(state);
        }
        for (int lastState : lastWeekStates) {
            builder.addLastWeekStates(lastState);
        }
        builder.setRank(rank);
        builder.setLastRank(lastRank);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            CampProto message = CampProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }

    }

    @Override
    public void copyFrom(CampProto message) {
        this.id = message.getId();
        this.name = message.getName();

        int count = message.getStatesCount();
        states = Sets.newHashSetWithExpectedSize(count);
        for (int i = 0; i < count; i++) {
            states.add(message.getStates(i));
        }

        count = message.getLastWeekStatesCount();
        lastWeekStates = Sets.newHashSetWithExpectedSize(count);
        for (int i = 0; i < count; i++) {
            lastWeekStates.add(message.getLastWeekStates(i));
        }
        this.rank = message.getRank();
        this.lastRank = message.getLastRank();

    }

    public List<SangoState> getSangoStates() {
        return sangoStates;
    }

    public void setSangoStates(List<SangoState> sangoStates) {
        this.sangoStates = sangoStates;
    }

    public void changeRank(int rank) {
        this.lastRank = this.rank;
        this.rank = rank;
    }

    public void chanageStats(String name, Set<Integer> states) {
        this.name = name;
        this.lastWeekStates = this.states;
        this.states = states;
    }

    public Set<Integer> findLastWeekStates() {
        return this.lastWeekStates;
    }

    public int findLastWeekRank() {
        return this.lastRank;
    }

}
