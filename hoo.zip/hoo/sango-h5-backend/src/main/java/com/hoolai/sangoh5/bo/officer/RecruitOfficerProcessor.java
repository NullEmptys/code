package com.hoolai.sangoh5.bo.officer;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.bo.award.AwardChannel;
import com.hoolai.sangoh5.bo.award.AwardProcessor;
import com.hoolai.sangoh5.bo.award.OfficerAward;
import com.hoolai.sangoh5.bo.client.ChatClientRepo;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.bo.item.ItemBags;
import com.hoolai.sangoh5.bo.officer.data.NewRecruitData;
import com.hoolai.sangoh5.bo.officer.data.NewRecruitProperty;
import com.hoolai.sangoh5.bo.officer.data.OfficerData;
import com.hoolai.sangoh5.bo.officer.data.RecruitHeroData;
import com.hoolai.sangoh5.bo.officer.data.RecruitHeroProperty;
import com.hoolai.sangoh5.bo.officer.data.RecruitmentData;
import com.hoolai.sangoh5.bo.officer.data.RecruitmentProperty;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.bo.user.User.CurrencyType;
import com.hoolai.sangoh5.repo.ItemRepo;
import com.hoolai.sangoh5.repo.LimitationRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.service.ChatMsgFactory;
import com.hoolai.sangoh5.service.TrackDomainService;
import com.hoolai.sangoh5.service.activity.ActivityService;
import com.hoolai.sangoh5.util.ProbabilityGenerator;
import com.hoolai.util.IntHashMap;

public class RecruitOfficerProcessor {

    private static final int THUTMOSE_OFFICER_ID = 30030;

    private final long userId;

    private final int num;

    private final RecruitOfficerType recruitOfficerType;

    private final List<Award> awardList = new ArrayList<Award>();

    private AwardProcessor awardProcessor;

    private RecruitmentProperty recrProperty;

    private ItemBags itemBags;

    private User user;

    private OfficerLimitation limitation;

    private RecruitmentData recruitmentData;

    private ItemRepo itemRepo;

    private UserRepo userRepo;

    private LimitationRepo limitationRepo;

    private BoFactory boFactory;

    private ProbabilityGenerator pg;

    private ChatClientRepo chatClientRepo;

    private OfficerData officerData;

    private NewRecruitData newRecruitData;

    private ChatMsgFactory chatMsgFactory;

    private ActivityService activityService;

    private TrackDomainService trackDomainService;

    private ConstantsPoolData constantsPool;

    public RecruitOfficerProcessor(long userId, int type, int num) {
        this.userId = userId;
        this.num = num;
        this.recruitOfficerType = RecruitOfficerType.valueOf(type);
    }

    public void init() {
        recruitOfficerType.checkNum(num);
        recrProperty = recruitmentData.getProperty(1);
        itemBags = itemRepo.findItemBags(userId);
        user = userRepo.findUser(userId);
        limitation = limitationRepo.findOfficerLimitation(userId);
        awardProcessor = boFactory.createAwardProcessor(userId, num == 1 ? AwardChannel.Recruit : AwardChannel.TenRecruit);
    }

    public void setChatMsgFactory(ChatMsgFactory chatMsgFactory) {
        this.chatMsgFactory = chatMsgFactory;
    }

    public void setTrackDomainService(TrackDomainService trackDomainService) {
        this.trackDomainService = trackDomainService;
    }

    public RecruitmentProperty getRecrProperty() {
        return recrProperty;
    }

    public ItemBags getItemBags() {
        return itemBags;
    }

    public User getUser() {
        return user;
    }

    public OfficerLimitation getLimitation() {
        return limitation;
    }

    public void setRecruitmentData(RecruitmentData recruitmentData) {
        this.recruitmentData = recruitmentData;
    }

    public void setItemRepo(ItemRepo itemRepo) {
        this.itemRepo = itemRepo;
    }

    public void setUserRepo(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public void setLimitationRepo(LimitationRepo limitationRepo) {
        this.limitationRepo = limitationRepo;
    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }

    public void setPg(ProbabilityGenerator pg) {
        this.pg = pg;
    }

    public AwardProcessor getAwardProcessor() {
        return awardProcessor;
    }

    public void setChatClientRepo(ChatClientRepo chatClientRepo) {
        this.chatClientRepo = chatClientRepo;
    }

    public void setOfficerData(OfficerData officerData) {
        this.officerData = officerData;
    }

    public void setNewRecruitData(NewRecruitData newRecruitData) {
        this.newRecruitData = newRecruitData;
    }

    public void setActivityService(ActivityService activityService) {
        this.activityService = activityService;
    }

    public void setConstantsPool(ConstantsPoolData constantsPool) {
        this.constantsPool = constantsPool;
    }

    public void sendMsg(int officerXmlId) {
        chatClientRepo.sendMsg(chatMsgFactory.buildRecruitOfficer(user, officerXmlId, officerData, recruitOfficerType));
    }

    /**
     * 招募
     */
    public void recruitOfficer() {

        switch (recruitOfficerType) {
            case USE_TOKEN_FREE:
            case USE_TOKEN: {
                checkToken();
                if (num == 1) {
                    oneRecruitOfficer(RecruitOfficerType.USE_TOKEN_FREE.value());
                } else {
                    tenRecruitOfficer(RecruitOfficerType.USE_TOKEN_FREE.value());
                }
                break;
            }
            case USE_YB_FREE:
            case USE_YB: {
                checkYuanbao();
                if (num == 1) {
                    limitation.addOneDiamondRecruitNum();
                    if (!limitation.isFirstOneDiamondRecruit()) {
                        limitation.setFirstOneDiamondRecruit(true);
                        getRandomOfficerByType(RecruitOfficerType.USE_TOKEN.value());
                        break;
                    }
                    if (limitation.diamondRecruit() == 0) {
                        getRandomOfficerByType(RecruitOfficerType.USE_YB_FREE.value());
                        break;
                    }
                    oneRecruitOfficer(RecruitOfficerType.USE_YB_FREE.value());
                } else {
                    limitation.addTenDiamondRecruitNum();
                    tenRecruitOfficer(RecruitOfficerType.USE_YB_FREE.value());
                }
                break;
            }
            default:
                throw new IllegalArgumentException("there is no RecruitOfficerType enum element`s value is " + recruitOfficerType.value());
        }

        awardProcessor.transforAward(awardList);
        awardProcessor.awardPesistent(user, itemBags);
        userRepo.saveUser(user);
        limitationRepo.saveOfficerLimitation(limitation);
        limitation.refresh();
        awardProcessor.saveRepItemBags(awardList);

        trackDomainService.traceRecruit(user, recruitOfficerType, num);
    }

    /**
     * 检查月长石
     */
    private void checkToken() {
        if (recruitOfficerType.isFree()) {
            limitation.checkCanRecruitOfficer(recruitOfficerType);
            limitation.recruitOfficer(recruitOfficerType, constantsPool);
        } else {
            int cost = num == 1 ? recrProperty.getMoonstoneRecruitCost() : recrProperty.getMoonstoneTenRecruitCost();
            user.checkAndDecMoonstone(cost);
            trackDomainService.trackExpenditureEconomy(user, num == 1 ? AwardChannel.Recruit : AwardChannel.TenRecruit, CurrencyType.MOONSTONE, cost);
        }
    }

    /**
     * 检查蓝田玉
     */
    private void checkYuanbao() {
        if (recruitOfficerType.isFree()) {
            limitation.checkCanRecruitOfficer(recruitOfficerType);
            limitation.recruitOfficer(recruitOfficerType, constantsPool);
        } else {
            int costYuanBao = 0;
            if (num == 1) {
                costYuanBao = recrProperty.getDiamondRecruitCost();
            } else {
                costYuanBao = recrProperty.getDiamondTenRecruitCost() * activityService.getLuckDrawDiscount(userId) / 100;
            }
            user.checkAndLanTianYu(costYuanBao);

            trackDomainService.trackExpenditureEconomy(user, num == 1 ? AwardChannel.Recruit : AwardChannel.TenRecruit, CurrencyType.LANTIANYU, costYuanBao);

            if (num != 1) {
                activityService.luckyDrawDiscount(userId);
            }
        }
    }

    /**
     * 招募一次
     * 
     * @param type
     */
    public void oneRecruitOfficer(int type) {
        IntHashMap<List<NewRecruitProperty>> newRecruit = NewRecruitData.getNewRecruitPropertyData();
        List<NewRecruitProperty> recruitProperty = newRecruit.get(type);
        int id = this.getRandomItem(recruitProperty);
        NewRecruitProperty choiceRecruitProperty = newRecruitData.getProperty(id);
        if (choiceRecruitProperty.getGoodsType().equals("officer")) {
            awardList.add(new OfficerAward(choiceRecruitProperty.getGoodsId(), choiceRecruitProperty.getGoodNum(), choiceRecruitProperty.getGoodsStar(), 1));
            if (choiceRecruitProperty.getGoodsStar() >= 3) {
                sendMsg(choiceRecruitProperty.getGoodsId());
            }
        } else {
            awardList.add(new Award(choiceRecruitProperty.getGoodsId(), choiceRecruitProperty.getGoodNum(), AwardType.ITEM));
        }
    }

    /**
     * 十次招募
     * 
     * @param type
     */
    public void tenRecruitOfficer(int type) {
        getRandomOfficerByType(type);
        for (int i = 0; i < num - 1; i++) {
            oneRecruitOfficer(type);
        }
    }

    /**
     * 获取随机的将领
     * 
     * @param type 为1,2时必出3星将
     */
    public void getRandomOfficerByType(int type) {
        if (isThutmose(type)) {
            awardList.add(new OfficerAward(THUTMOSE_OFFICER_ID, 1, 3, 1));
            sendMsg(THUTMOSE_OFFICER_ID);
            return;
        }
        IntHashMap<List<RecruitHeroProperty>> newRecruit = RecruitHeroData.getRecruitHeroPropertyData();
        List<RecruitHeroProperty> recruitHero = newRecruit.get(type);
        RecruitHeroProperty recrutiHeroProperty = recruitHero.get(pg.getRandomNumber(recruitHero.size() - 1));
        awardList.add(new OfficerAward(recrutiHeroProperty.getGoodsId(), 1, recrutiHeroProperty.getGoodsStar(), 1));
        if (recrutiHeroProperty.getGoodsStar() >= 3) {
            sendMsg(recrutiHeroProperty.getGoodsId());
        }
    }

    private boolean isThutmose(int type) {
        if (type != RecruitOfficerType.USE_YB_FREE.value()) {
            return false;
        }
        if (!activityService.inThutmoseActivity(userId)) {
            return false;
        }
        //        int diamondRecruitActivityNum = limitation.diamondRecruitActivityNum();
        //        if (diamondRecruitActivityNum % 2 == 0) {
        //            return true;
        //        }
        //        return pg.getRandomWithPercentage(20);
        return true;
    }

    /**
     * 获取随机的物品
     * 
     * @param poolList
     * @return
     */
    public int getRandomItem(List<NewRecruitProperty> recruitProperty) {
        int totalWeight = 0;
        for (NewRecruitProperty recruit : recruitProperty) {
            totalWeight += recruit.getProValue();
        }
        Random ran = new Random();
        int randomNum = ran.nextInt(totalWeight);
        int count = 0;
        int id = 0;
        for (NewRecruitProperty pools : recruitProperty) {
            int temp = count;
            count = count + pools.getProValue();
            if (randomNum >= temp && randomNum <= count) {
                id = pools.getId();
                break;
            }
        }
        return id;
    }

}
