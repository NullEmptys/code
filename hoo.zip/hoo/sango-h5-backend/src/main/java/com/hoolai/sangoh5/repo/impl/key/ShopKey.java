package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class ShopKey {

    public static final String prefix = "shop";

    public static String getShopIdsKey(long userId, int type) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append(type).append("ids").toString();
    }

    public static String getShopAutoFlushKey(long userId, int type) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append(type).append("auto").toString();
    }

    public static String getShopManualFlushKey(long userId, int type) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append(type).append("handle").toString();
    }

    public static String getShopBuyKey(long userId, int type) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append(type).append("buy").toString();
    }

    public static String getShopBuyKeys(long userId, int type) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append(type).append("limit").toString();
    }

    public static String getAllShopBuyKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("allshop").toString();
    }
}
