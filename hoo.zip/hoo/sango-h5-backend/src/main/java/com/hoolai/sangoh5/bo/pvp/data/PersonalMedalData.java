package com.hoolai.sangoh5.bo.pvp.data;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class PersonalMedalData extends JsonData<PersonalMedalProperty> {

    private final ListMultimap<MedalTriggerType, PersonalMedalProperty> medalData = ArrayListMultimap.create();

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/personalMedal.json", PersonalMedalProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void initForEach(PersonalMedalProperty property) {
        medalData.put(property.getType(), property);
        super.initForEach(property);
    }

    @Override
    protected void checkProperty(PersonalMedalProperty property) {

    }

    public List<PersonalMedalProperty> getPropertiesByTriggerType(MedalTriggerType triggerType) {
        return medalData.get(triggerType);
    }

}
