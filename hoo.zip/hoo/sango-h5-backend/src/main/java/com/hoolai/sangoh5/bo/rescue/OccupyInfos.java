package com.hoolai.sangoh5.bo.rescue;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.google.common.collect.Lists;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.PvpOccupysProto;
import com.hoolai.sangoh5.bo.pvp.Camp;
import com.hoolai.sangoh5.repo.PvpRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 玩家占领的城池记录 根据玩家等级分，每个等级的玩家占领其他玩家城池的记录
 * 
 * @author hp
 *
 */
public class OccupyInfos implements ProtobufSerializable<PvpOccupysProto> {

    private List<OccupyInfo> occupyInfos = new ArrayList<OccupyInfo>();

    public OccupyInfos(byte[] bytes) {
        parseFrom(bytes);
    }

    public OccupyInfos() {

    }

    /**
     * 获取当前等级下占领满24H的玩家列表 R
     * 
     * @return
     */
    public List<OccupyInfo> getConditionsOccupyInfos(long userId, UserRepo userRepo, PvpRepo pvpRepo) {
        List<OccupyInfo> occupyInfos = new ArrayList<OccupyInfo>();
        List<Camp> camps = pvpRepo.findCamps().getCamps();
        for (OccupyInfo occupyInfo : this.occupyInfos) {
            // System.currentTimeMillis() - occupyInfo.getOccupyStartTime() >=
            // 24 * 60 * 60 * 1000&&
            if (occupyInfo.getOccupyId() != userId && occupyInfo.getUserId() != userId) {
                int userState = userRepo.findUser(userId).getSangoState();//user
                int occupyState = userRepo.findUser(occupyInfo.getOccupyId()).getSangoState();//占领者
                int beOccupyState = userRepo.findUser(occupyInfo.getUserId()).getSangoState();//被占领者
                Camp userCamp = null;
                Camp occupyStateCamp = null;
                Camp beOccupyStateCamp = null;
                Iterator<Camp> it = camps.iterator();
                while (it.hasNext()) {
                    Camp camp = it.next();
                    List<Integer> states = Lists.newArrayList(camp.getStates());
                    if (states.contains(userState)) {
                        userCamp = camp;
                    }
                    if (states.contains(occupyState)) {
                        occupyStateCamp = camp;
                    }
                    if (states.contains(beOccupyState)) {
                        beOccupyStateCamp = camp;
                    }
                }
                if (userCamp.getId() != occupyStateCamp.getId() && userCamp.getId() == beOccupyStateCamp.getId() && occupyStateCamp.getId() != beOccupyStateCamp.getId()) {
                    occupyInfos.add(occupyInfo);
                }
            }
        }
        return occupyInfos;

    }

    public List<OccupyInfo> getOccupyInfos() {
        return occupyInfos;
    }

    public void setOccupyInfos(List<OccupyInfo> occupyInfos) {
        this.occupyInfos = occupyInfos;
    }

    @Override
    public PvpOccupysProto copyTo() {
        PvpOccupysProto.Builder builder = PvpOccupysProto.newBuilder();
        if (occupyInfos.size() > 0) {
            for (OccupyInfo occupyInfo : occupyInfos) {
                builder.addOccupyInfo(occupyInfo.copyTo());
            }
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            PvpOccupysProto message = PvpOccupysProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(PvpOccupysProto message) {
        int count = message.getOccupyInfoCount();
        for (int i = 0; i < count; i++) {
            occupyInfos.add(new OccupyInfo(message.getOccupyInfo(i)));
        }
    }

    /**
     * 添加一个占领记录
     * 
     * @param occupyInfo
     */
    public void addOccupyInfo(OccupyInfo occupyInfo) {
        this.occupyInfos.add(occupyInfo);
    }

    /**
     * 当前等级占领城池的玩家
     * 
     * @return
     */
    public int getCurrentOccupySize() {
        return this.occupyInfos.size();
    }

    /**
     * 城池被解救
     * 
     * @param occupyId
     *        占领值id
     * @param rescueId
     *        被占领者id
     */
    public boolean deleteOccupyInfo(long occupyId, long rescueId) {
        Iterator<OccupyInfo> it = occupyInfos.iterator();
        OccupyInfo occupyInfo = null;
        while (it.hasNext()) {
            occupyInfo = it.next();
            if (occupyInfo.getOccupyId() == occupyId && occupyInfo.getUserId() == rescueId) {
                it.remove();
                return true;
            }
        }
        return false;
    }

}
