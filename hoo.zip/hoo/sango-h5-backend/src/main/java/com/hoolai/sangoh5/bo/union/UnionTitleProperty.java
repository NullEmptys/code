package com.hoolai.sangoh5.bo.union;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class UnionTitleProperty extends JsonProperty {

    private int id;

    private String name;

    private int titlePoint;

    private int titleGet;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTitlePoint() {
        return titlePoint;
    }

    public void setTitlePoint(int titlePoint) {
        this.titlePoint = titlePoint;
    }

    public int getTitleGet() {
        return titleGet;
    }

    public void setTitleGet(int titleGet) {
        this.titleGet = titleGet;
    }

}
