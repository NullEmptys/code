package com.hoolai.sangoh5.bo.soldier;

import com.hoolai.sangoh5.bo.soldier.data.SoldierRestraintData;
import com.hoolai.sangoh5.bo.tacticalManagement.data.TacticalData;

/**
 * 相克公式查找者
 *
 */
public class RestraintFinder {

    private SoldierRestraintData soldierRestraintData;
    private TacticalData tacticalData;
    
    public RestraintFinder() {
    }

    /**
     * 兵种相克
     * @return
     */
    public float findSoldierRestraintRate(SoldierType actorSoldierType,SoldierType targetSoldierType) {
        return soldierRestraintData.getRestraintRate(actorSoldierType, targetSoldierType);
    }
    
    /**
     * 阵型相克
     * @param actorFormationId
     * @param targetFormationId
     * @return
     */
    public float findFormationRestraintRate(int actorFormationId,int targetFormationId){
    	return tacticalData.getRestraintRate(actorFormationId,targetFormationId);
    }

    public void setSoldierRestraintData(SoldierRestraintData soldierRestraintData) {
		this.soldierRestraintData = soldierRestraintData;
	}

	public void setTacticalData(TacticalData tacticalData) {
		this.tacticalData = tacticalData;
	}
    
}
