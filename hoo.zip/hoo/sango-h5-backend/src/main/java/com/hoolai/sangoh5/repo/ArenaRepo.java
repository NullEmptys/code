package com.hoolai.sangoh5.repo;

import java.util.List;

import com.hoolai.protobuf.BytesList;
import com.hoolai.sangoh5.bo.arena.ArenaOfficer;
import com.hoolai.sangoh5.bo.arena.ArenaOfficers;
import com.hoolai.sangoh5.bo.arena.ArenaUser;

public interface ArenaRepo {

    ArenaUser findArenaUser(long userId);

    void saveArenaUser(ArenaUser arenaUser);

    void saveArenaOfficers(ArenaOfficers arenaOfficers);

    ArenaOfficers findArenaOfficers(long userId);

    boolean saveServerArenaOfficer(ArenaOfficer arenaOfficer);

    ArenaOfficer findServerArenaOfficer(int xmlId);

    boolean lockArenaSortRanking(long hour);

    void unLockArenaSortRanking(long hour);

    boolean lockArenaUser(long userId);

    void unLockArenaUser(long userId);

    long findSortListTotalPageNum();

    List<ArenaUser> findRankSortList(long pageNum);

    void casArenaUser(ArenaUser arenaUser);

    BytesList getRankArenaOfficers(int xmlId);

    void deleteRankArenaOfficer(int xmlId);

    Long getRankByUserId(long userId);

    List<Long> getUsersByRank(int start, int stop);

    void addUserScoreToRedis(int score, long userId);

    void zaddRankArenaOfficer(long userId, int xmlId, int score);

    long getRankArenaOfficersTopOne(int xmlId);

    boolean zremByRankArenaOfficer(int xmlId, int start, int stop);

    int getRankArenaOfficersCount(int xmlId);

}
