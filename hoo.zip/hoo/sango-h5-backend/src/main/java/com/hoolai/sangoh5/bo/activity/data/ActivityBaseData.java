package com.hoolai.sangoh5.bo.activity.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 15:47
 * @version : 1.0
 */
@Component
public class ActivityBaseData extends JsonData<ActivityBaseProperty> {

    @PostConstruct
    @Override
    public void init() {
        try {
            initData("com/hoolai/sangoh5/activityBase.json", ActivityBaseProperty.class);
        } catch (IOException e) {
            logger.error(e);
        }
    }

    @Override
    protected void checkProperty(ActivityBaseProperty property) {

    }

}
