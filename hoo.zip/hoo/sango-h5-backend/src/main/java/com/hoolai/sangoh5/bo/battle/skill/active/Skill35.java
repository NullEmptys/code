//package com.hoolai.sangoh5.bo.battle.skill.active;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import com.hoolai.sangoh5.bo.battle.enhance.buff.MoreHurtEnhanceBuff;
//import com.hoolai.sangoh5.bo.battle.enhance.effect.MoreHurtEnhanceEffect;
//import com.hoolai.sangoh5.bo.battle.skill.Skill;
//import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
//import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
////随着回合的递增，伤害递增
//public class Skill35 extends IndependentSkill {
//
//	@Override
//	public Skill clone() {
//		return super.clone(new Skill35());
//	}
//
//	@Override
//	public List<FightUnit> execute(FightUnit actor, TargetCollection tc,int currentLevel) {
//		List<FightUnit> targets = new ArrayList<FightUnit>();
//		
//		FightUnit defender = actor.getDefender();
//		if(defender != null){
//			MoreHurtEnhanceEffect enhanceEffect = new MoreHurtEnhanceEffect(this.xmlId, this.name, this.percentage);
//			
//			defender.addEnhanceEffect(enhanceEffect);
//			
//			defender.addBuff(new MoreHurtEnhanceBuff(xmlId, defender.name(), currentLevel,enhanceEffect)
//			.withActorName(actor.name()).withTargetName(defender.name()).withRepeatCount(repeatCount)
//			.withKeepBuff());
//			
//			targets.add(defender);
//		}
//		
//		return targets;
//	}
//
//}
