package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class MissionKey {

    public static final String prefix = "mission";

    public static final String prefix2 = "active";

    public static String getMissionKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).toString();
    }

    public static String getActiveKey(long userId) {
        return new StringBuilder().append(prefix2).append(Constant.separator).append(userId).append(Constant.separator).toString();
    }
}
