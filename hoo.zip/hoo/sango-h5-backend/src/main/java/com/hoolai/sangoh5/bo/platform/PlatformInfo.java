package com.hoolai.sangoh5.bo.platform;


public class PlatformInfo  {
	
	private Long id;
	
	private long userId;

    private String image;

    private String name;

    private int lastSyncAt;

    private int platformType;

    public PlatformInfo(){
    	
    }
    
    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLastSyncAt() {
        return lastSyncAt;
    }

    public void setLastSyncAt(int lastSyncAt) {
        this.lastSyncAt = lastSyncAt;
    }

    public int getPlatformType() {
        return platformType;
    }

    public void setPlatformType(int platformType) {
        this.platformType = platformType;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

}
