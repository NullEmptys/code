package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class BaoJi extends BaseOfficerPhysicsSkill {

    @Override
    public Skill clone() {
        return super.clone(new BaoJi());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        FightUnit target = actor.getDefender();
        if (target != null) {
            Effect effect = new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withDeltaHp(calLostPoint(actor, target)).withTargetName(target.name());
            target.addEffect(effect);

            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "造成伤害=" + effect.getDeltaHp());

            targetDefence(actor, target, effect, null, tc, targets, currentLevel);
            targets.add(target);
        }

        return targets;
    }

    private int calLostPoint(FightUnit actor, FightUnit target) {
        float baseLostPoint = super.calculateLostPoint(actor, target);
        baseLostPoint = baseLostPoint * (1 + percentage) + value;
        return Math.round(baseLostPoint);
    }

}
