package com.hoolai.sangoh5.bo.mission;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.MissionProtocolBuffer.UserMissionsProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class MissionList implements ProtobufSerializable<UserMissionsProto> {

    private List<Mission> userMissions = new ArrayList<Mission>();

    public MissionList(byte[] bytes) {
        parseFrom(bytes);
    }

    public MissionList() {

    }

    @Override
    public UserMissionsProto copyTo() {
        UserMissionsProto.Builder builder = UserMissionsProto.newBuilder();
        if (userMissions.size() > 0) {
            for (Mission userMission : userMissions) {
                builder.addUserMission(userMission.copyTo());
            }
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            UserMissionsProto message = UserMissionsProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }

    }

    @Override
    public void copyFrom(UserMissionsProto message) {
        int count = message.getUserMissionCount();
        this.userMissions = new ArrayList<Mission>();
        for (int i = 0; i < count; i++) {
            Mission mission = new Mission(message.getUserMission(i));
            userMissions.add(mission);
        }
    }

    public List<Mission> getUserMissions() {
        return userMissions;
    }

    public void setUserMissions(List<Mission> userMissions) {
        this.userMissions = userMissions;
    }

}
