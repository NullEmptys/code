package com.hoolai.sangoh5.bo.battle.fight;

public enum BattleType {

    /** 普通战斗 */
    NORMAL,
    ONLY_OFFICER_FIGHT;
}
