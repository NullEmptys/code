package com.hoolai.sangoh5.bo.platform;

import com.hoolai.sangoh5.util.Constant;


public enum MobilePlatform {

	nonios(1), ios(2);
	
	public int type;
	
	private MobilePlatform(int type){
		this.type = type;
	}
	
	@Override
	public String toString() {
		return Constant.separator + name();
	}
	
	public String gameOpenid(String openid){
		return openid + this;
	}
	
	public static MobilePlatform valueOf(int type){
		for(MobilePlatform mobilePlatform:values()){
			if(mobilePlatform.type == type){
				return mobilePlatform;
			}
		}
		//throw new IllegalArgumentException("未识别的手机平台platform="+type);
		return MobilePlatform.nonios;
	}
	
}
