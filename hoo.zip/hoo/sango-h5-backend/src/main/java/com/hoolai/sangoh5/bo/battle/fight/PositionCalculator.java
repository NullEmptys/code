package com.hoolai.sangoh5.bo.battle.fight;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.OfficerUnit;
import com.hoolai.sangoh5.bo.battle.unit.SoldierUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.soldier.SoldierType.AttackType;
import com.hoolai.sangoh5.bo.soldier.data.SoldierData;
import com.hoolai.sangoh5.bo.soldier.data.SoldierProperty;
import com.hoolai.sangoh5.util.Constant;

public class PositionCalculator {

    private static final Log logger = LogFactory.getLog("battle");

    private static final int MAX_X = 28;

    private static final int MAX_Y = 12;

    private static final int MIN_X = 1;

    private static final int MIN_Y = 1;

    private static final int BASE_PLACEHOLDER = 3;

    private final FightUnit actor;

    private FightUnit target;

    private SoldierData soldierData;

    private List<ConvergeFightUnit> convergeFightUnits;

    private final TargetCollection tc;

    private final int roundCounter;

    public PositionCalculator(FightUnit actor, int roundCounter, TargetCollection targetCollection) {
        this.actor = actor;
        this.roundCounter = roundCounter;
        this.tc = targetCollection;
    }

    public enum MoveDirection {
        IDLE, LEFT, RIGHT, UP, DOWN;
    }

    /**
     * 用来选取最快抵达目标位置对象的类
     * 
     * @author Administrator
     *
     */
    class ConvergeFightUnit implements Comparable<ConvergeFightUnit> {

        private final double needTime;

        private final int pos;

        private final FightUnit fightUnit;

        public ConvergeFightUnit(FightUnit fightUnit, int pos, double needTime) {
            this.fightUnit = fightUnit;
            this.needTime = needTime;
            this.pos = pos;
        }

        public FightUnit getFightUnit() {
            return fightUnit;
        }

        @Override
        public int compareTo(ConvergeFightUnit o) {
            if (needTime > o.needTime) {
                return 0;
            } else if (needTime == o.needTime) {
                if (pos > o.pos) {
                    return 0;
                }
            }
            return 1;
        }

    }

    /**
     * 挑选最近的夹击目标攻击
     * 近战有8个位置，远战不定
     * 近战位置空缺需补位
     */
    private void findMinDistanceConvergeAttacker(FightUnit actor, TargetCollection tc) {

        FightUnit longUnit = null;
        double minDistince = Integer.MAX_VALUE;

        List<ConvergeFightUnit> convergeFightUnits = new ArrayList<PositionCalculator.ConvergeFightUnit>();
        List<FightUnit> attackers = actor.getAttackers();
        int actorPos[] = actor.getPositionManager().getCurrentPosition();
        int[] diePos = actor.getLastDefender().getPositionManager().getTargetPosition();

        Iterator<FightUnit> iterator = attackers.iterator();
        while (iterator.hasNext()) {
            FightUnit fightUnit = iterator.next();
            if (tc.getAlive(fightUnit.name()) == null) {
                iterator.remove();
            } else {
                int targetPos[] = fightUnit.getPositionManager().getCurrentPosition();
                int pos = fightUnit.getPositionManager().getAttackPos();
                if (pos < 1) {
                    double len = Math.sqrt(Math.pow(Math.abs(actorPos[0] - targetPos[0]), 2) + Math.pow(Math.abs(actorPos[1] - targetPos[1]), 2));
                    if (len < minDistince) {
                        minDistince = len;
                        longUnit = fightUnit;
                    }
                } else {
                    double len = Math.sqrt(Math.pow(Math.abs(diePos[0] - targetPos[0]), 2) + Math.pow(Math.abs(diePos[1] - targetPos[1]), 2));

                    double needTime = len * fightUnit.getMoveSpeed();
                    convergeFightUnits.add(new ConvergeFightUnit(fightUnit, pos, needTime));
                }
            }
        }

        if (convergeFightUnits.size() < 1) {
            target = longUnit;
        } else {
            Collections.sort(convergeFightUnits);
            target = convergeFightUnits.get(0).getFightUnit();
            this.convergeFightUnits = convergeFightUnits;
        }
        if (logger.isDebugEnabled()) {
            if (target == null) {
                logger.debug(actor.name() + "选择夹击者失败：" + actor.getAttackers().size());
            } else {
                logger.debug(actor.name() + "选择夹击者：" + target.name());
            }
        }

    }

    /**
     * 8个位置依次往最靠近攻击对象的位置移动
     * 
     * @param actor_init_x
     * @param actor_init_y
     * @param tp
     * @param isExceptedTarget
     */
    private void changePos(int actor_init_x, int actor_init_y, int[] tp, boolean isExceptedTarget) {
        //如果被夹击者主动去选择夹击者，说明肯定有一夹击者死亡。夹击位置空出，其他夹击者补位。
        for (ConvergeFightUnit cfightUnit : convergeFightUnits) {

            FightUnit fightUnit = cfightUnit.getFightUnit();

            int target_init_x = fightUnit.getPositionManager().getCurrentPosition()[0];
            int target_init_y = fightUnit.getPositionManager().getCurrentPosition()[1];

            if (isExceptedTarget && fightUnit.name().equals(target.name())) {
                continue;
            }

            //同一水平线上的相邻位置不用挪动
            if (fightUnit.name().equals(target.name()) && target_init_y == actor_init_y && Math.abs(target_init_x - actor_init_x) == 1) {
                continue;
            }

            Map<String, Object> ret = selectPos(fightUnit, tp, fightUnit.getPositionManager().getCurrentPosition(), 8);
            int[] convergeAttackPos = (int[]) ret.get("pos");
            setupPos(fightUnit, actor, target_init_x, target_init_y, convergeAttackPos[0], convergeAttackPos[1]);
            fightUnit.getPositionManager().setAttackPos((Integer) ret.get("place"));
        }
    }

    /**
     * 选择对方最小夹击的单元
     * 
     * @param isAttacker
     * @param tc
     * @return
     */
    private List<FightUnit> findMinAttackerUnit(boolean isAttacker, TargetCollection tc) {
        List<FightUnit> fightUnits0 = new ArrayList<FightUnit>();
        List<FightUnit> fightUnits1 = new ArrayList<FightUnit>();
        List<FightUnit> fightUnits2 = new ArrayList<FightUnit>();
        List<FightUnit> fightUnits3 = new ArrayList<FightUnit>();
        List<FightUnit> fightUnits4 = new ArrayList<FightUnit>();
        List<FightUnit> fightUnits5 = new ArrayList<FightUnit>();
        List<FightUnit> fightUnits6 = new ArrayList<FightUnit>();
        List<FightUnit> fightUnits7 = new ArrayList<FightUnit>();

        Map<FightUnitName, FightUnit> aliveMap = tc.aliveTargetUnit(isAttacker);
        Set<FightUnitName> keySet = aliveMap.keySet();
        for (FightUnitName name : keySet) {
            FightUnit fightUnit = aliveMap.get(name);
            int num = fightUnit.getAttackers().size();
            switch (num) {
                case 0:
                    fightUnits0.add(fightUnit);
                    break;
                case 1:
                    fightUnits1.add(fightUnit);
                    break;
                case 2:
                    fightUnits2.add(fightUnit);
                    break;
                case 3:
                    fightUnits3.add(fightUnit);
                    break;
                case 4:
                    fightUnits4.add(fightUnit);
                    break;
                case 5:
                    fightUnits5.add(fightUnit);
                    break;
                case 6:
                    fightUnits6.add(fightUnit);
                    break;
                case 7:
                    fightUnits7.add(fightUnit);
                    break;
            }
        }

        return fightUnits0.size() > 0 ? fightUnits0 : fightUnits1.size() > 0 ? fightUnits1 : fightUnits2.size() > 0 ? fightUnits2 : fightUnits3.size() > 0 ? fightUnits3
                : fightUnits4.size() > 0 ? fightUnits4 : fightUnits5.size() > 0 ? fightUnits5 : fightUnits6.size() > 0 ? fightUnits6 : fightUnits7;
    }

    private FightUnit findMinDistanceTarget(FightUnit actor, List<FightUnit> rowUnit) {
        double minDistince = Integer.MAX_VALUE;
        FightUnit unit = rowUnit.get(0);

        int[] actorPos = actor.getPositionManager().getCurrentPosition();

        if (actor.isOfficer()) {
            if (logger.isDebugEnabled()) {
                //			logger.debug(actor.name()+"目前位置："+ArrayUtils.toString(actorPos));
                logger.debug(actor.name() + "目前位置：" + ArrayUtils.toString(actorPos));
            }
        }

        for (FightUnit fightUnit : rowUnit) {
            int[] targetPos = fightUnit.getPositionManager().getCurrentPosition();
            double len = Math.sqrt(Math.pow(Math.abs(actorPos[0] - targetPos[0]), 2) + Math.pow(Math.abs(actorPos[1] - targetPos[1]), 2));
            if (len < minDistince) {
                minDistince = len;
                unit = fightUnit;
            }
            if (actor.isOfficer()) {
                if (logger.isDebugEnabled()) {
                    logger.debug(fightUnit.name() + "目前位置：" + ArrayUtils.toString(targetPos) + ",距离=" + len);
                }
            }
        }
        if (actor.isOfficer()) {
            if (logger.isDebugEnabled()) {
                logger.debug("最后选定目标：" + unit.name());
            }

        }
        return unit;
    }

    private int[] findAttackRow(SoldierType soldierType) {
        switch (soldierType) {
            case rider:
                return new int[] { 3, 2, 1 };
            case archer:
                return new int[] { 2, 1, 3 };
            case crossbowman:
                return new int[] { 1, 2, 3 };
            case footman:
                return new int[] { 1, 2, 3 };
            case spearman:
                return new int[] { 2, 1, 3 };
            case vehicleman:
                return new int[] { 3, 2, 1 };
            default:
                return new int[] { 1, 2, 3 };
        }
    }

    private FightUnit selectTarget(int[] row, FightUnit actor, List<FightUnit> targetList) {
        for (int i = 0; i < row.length; i++) {
            int rowIndex = row[i];
            List<FightUnit> rowUnit = findRowFightUnit(rowIndex, targetList);
            if (rowUnit.size() > 0) {
                FightUnit unit = findMinDistanceTarget(actor, rowUnit);
                return unit;
            }
        }
        return null;
    }

    private List<FightUnit> findRowFightUnit(int row, List<FightUnit> targetList) {
        List<FightUnit> list = new ArrayList<FightUnit>();
        for (FightUnit fightUnit : targetList) {
            if (fightUnit.getInitRow() == row) {
                list.add(fightUnit);
            }
        }
        return list;
    }

    private void lockTarget() {
        // 没有夹击目标
        boolean isAttacker = actor.isAttacker();
        boolean isOfficer = actor.isOfficer();

        // 选择对方最小夹击的单元
        List<FightUnit> targetList = findMinAttackerUnit(isAttacker, tc);
        if (targetList.size() < 1) {
            return;
        }

        FightUnit officer = tc.getAlive(isAttacker ? FightUnitName.def_officer : FightUnitName.att_officer);
        if (isOfficer) {
            if (roundCounter == 1) {//如果是第一次选择目标则随机选择，其后就近选择
                int randomIndex = Constant.pg.getRandomNumber(targetList.size() - 1);
                target = targetList.get(randomIndex);
                if (logger.isDebugEnabled()) {
                    logger.debug(actor.name() + "将领选择随机目标:" + target.name());
                }
            } else {
                target = findMinDistanceTarget(actor, targetList);
                if (logger.isDebugEnabled()) {
                    logger.debug(actor.name() + "将领就近选择目标:" + target.name());
                }
            }
        } else {
            // 如果是士兵，按照士兵类型与阵型规则选择
            SoldierUnit soldierUnit = (SoldierUnit) actor;
            SoldierType soldierType = soldierUnit.getSoldierType();
            AttackType attackType = soldierUnit.getSoldierFightType();

            // 有一定概率优选选择攻击将领
            if (officer != null && targetList.contains(officer) && roundCounter == 1) {//如果士兵有几率选择将领的话，会导致将领无法就近选择攻击目标
                if (attackType == AttackType.CLOSE_COMBAT && Constant.pg.getRandomWithPercentage(40)) {
                    target = officer;
                } else if (attackType == AttackType.LONG_RANGE && Constant.pg.getRandomWithPercentage(30)) {
                    target = officer;
                }
            }

            // 对方将领已死或者没有选中将领，选择士兵
            if (target == null) {
                target = selectTarget(findAttackRow(soldierType), actor, targetList);
                if (target == null && !officer.isDead()) {//如果士兵已经全部死掉，将领没死，选择将领
                    target = officer;
                    if (logger.isDebugEnabled()) {
                        logger.debug(actor.name() + "最后选择没死的目标：" + (target == null ? "空的~~~！！！" : target.name()));
                    }
                } else if (target == null && officer.isDead()) {
                    return;
                }
                if (logger.isDebugEnabled()) {
                    logger.debug(actor.name() + "按照规则选择目标：" + (target == null ? "空的~~~！！！" : target.name()));
                }
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug(actor.name() + "随机到将领攻击：" + target.name());
                }
            }
        }
        if (target == null) {
            if (logger.isDebugEnabled()) {
                logger.debug(actor.name() + "没有选择到任何目标");
            }
        }
    }

    private void convergeAttack() {
        SoldierProperty actorType = soldierData.getProperty(actor.getXmlId());
        int actor_init_x = actor.getPositionManager().getCurrentPosition()[0];
        int actor_init_y = actor.getPositionManager().getCurrentPosition()[1];
        int[] tp = actor.getPositionManager().getTargetPosition();

        findMinDistanceConvergeAttacker(actor, tc);
        if (target == null) {
            return;
        }
        SoldierProperty targetType = soldierData.getProperty(target.getXmlId());
        // 夹击者是近战兵，需要保证近战兵移动到自己x轴相同的位置，自己不管是近战兵还是远战兵都不动.
        //夹击者是远程兵的话就需要动到远程兵的位置。

        if (isNotNeedMove(actorType, actor) && isNotNeedMove(targetType, target)) {//如果两个都是远程兵
            // 都是远程兵，都不需要挪动
        } else if (!isNotNeedMove(actorType, actor) && isNotNeedMove(targetType, target)) {
            // 攻击者是近战兵，夹击者是远程兵
            //如果当前选择夹击者目标时远程兵，说明此单元周围无近战兵围绕夹击，此单元要移动到远程兵的位置，也无需夹击者补位
            tp = target.getPositionManager().getTargetPosition();// 这时候得需要更改围绕位置
            Map<String, Object> ret = selectPos(actor, tp, actor.getPositionManager().getCurrentPosition(), 8);
            int[] convergeAttackPos = (int[]) ret.get("pos");
            setupPos(actor, target, actor_init_x, actor_init_y, convergeAttackPos[0], convergeAttackPos[1]);
            target.getPositionManager().setAttackPos((Integer) ret.get("place"));
            if (logger.isDebugEnabled()) {
                logger.debug(target.name() + "是远程兵，" + actor.name() + "挪动到" + Arrays.toString(convergeAttackPos));
            }
        } else if (isNotNeedMove(actorType, actor) && !isNotNeedMove(targetType, target)) {
            // 攻击者是远程兵，夹击者是近战兵，夹击挪位即可 
            changePos(actor_init_x, actor_init_y, tp, false);
            if (logger.isDebugEnabled()) {
                logger.debug(target.name() + "是近战兵，夹击者挪位.");
            }
        } else {
            // 攻击者是近战，夹击者也是近战
            if (target.getPositionManager().isReachTargetPos()) {
                changePos(actor_init_x, actor_init_y, tp, false);
                if (logger.isDebugEnabled()) {
                    logger.debug(target.name() + "是近战兵，夹击者挪位2");
                }
            } else {
                boolean isAllNotAt = true;
                for (ConvergeFightUnit cfightUnit : convergeFightUnits) {
                    FightUnit fightUnit = cfightUnit.getFightUnit();
                    if (fightUnit.getPositionManager().isReachTargetPos()) {
                        isAllNotAt = false;
                        break;
                    }
                }
                if (isAllNotAt) {
                    oneToOne();
                    if (logger.isDebugEnabled()) {
                        logger.debug("所有夹击者没有跑到位置");
                    }
                    changePos(actor_init_x, actor_init_y, tp, true);
                    if (logger.isDebugEnabled()) {
                        logger.debug(target.name() + "是近战兵，夹击者挪位4");
                    }
                } else {
                    changePos(actor_init_x, actor_init_y, tp, false);
                    if (logger.isDebugEnabled()) {
                        logger.debug(target.name() + "是近战兵，夹击者挪位3");
                    }
                }

            }
        }
        actor.setDefender(target);//一定要放到最后，免得把lastDefener覆盖掉
    }

    private void normalAttack() {
        int attackerNum = target.getAttackers().size() + (target.getDefender() == null ? 0 : 1);

        SoldierProperty targetType = soldierData.getProperty(target.getXmlId());
        SoldierProperty actorType = soldierData.getProperty(actor.getXmlId());
        int actor_init_x = actor.getPositionManager().getCurrentPosition()[0];
        int actor_init_y = actor.getPositionManager().getCurrentPosition()[1];

        if (isNotNeedMove(targetType, target) && isNotNeedMove(actorType, actor)) {//如果攻击者和目标都是远程兵
            if (attackerNum == 0) {
                actor.addAttacker(target);
                target.setDefender(actor);
            }
        } else if (isNotNeedMove(actorType, actor) && !isNotNeedMove(targetType, target)) {//攻击者是远程兵，目标时近战兵
            if (attackerNum == 0) {
                int[] tp = actor.getPositionManager().getPosition();
                int target_init_x = target.getPositionManager().getCurrentPosition()[0];
                int target_init_y = target.getPositionManager().getCurrentPosition()[1];

                int[] targetPos = (int[]) selectPos(target, tp, target.getPositionManager().getCurrentPosition(), attackerNum + 1).get("pos");
                setupPos(target, actor, target_init_x, target_init_y, targetPos[0], targetPos[1]);

                actor.addAttacker(target);
                target.setDefender(actor);
                target.getPositionManager().clear();
            }
        } else if (!isNotNeedMove(actorType, actor) && isNotNeedMove(targetType, target)) {//攻击者是近战兵，目标时远程兵
            int[] tp = target.getPositionManager().getPosition();

            int[] actorPos = (int[]) selectPos(actor, tp, actor.getPositionManager().getCurrentPosition(), attackerNum + 1).get("pos");
            setupPos(actor, target, actor_init_x, actor_init_y, actorPos[0], actorPos[1]);

            if (attackerNum == 0) {
                actor.addAttacker(target);
                target.setDefender(actor);
            }

            actor.getPositionManager().setAttackPos(attackerNum + 1);

        } else {
            if (attackerNum == 0 && target.getDefender() == null) {
                oneToOne();
                actor.addAttacker(target);
                target.setDefender(actor);
                target.getPositionManager().clear();
            } else {
                int[] tp = target.getPositionManager().getTargetPosition();//近战兵要取最后的位置

                Map<String, Object> ret = selectPos(actor, tp, actor.getPositionManager().getCurrentPosition(), attackerNum + 1);
                int[] actorPos = (int[]) ret.get("pos");
                setupPos(actor, target, actor_init_x, actor_init_y, actorPos[0], actorPos[1]);
                actor.getPositionManager().setAttackPos((int) ret.get("place"));
            }

        }

        actor.setDefender(target);
        for (FightUnit unit : target.getAttackers()) {
            unit.addCompanionAttacker(actor);
            actor.addCompanionAttacker(unit);
        }
        target.addAttacker(actor);

    }

    public void calPos() {

        // 攻击者并不需要寻找新的被攻击者，只是检查被攻击者的位置
        FightUnit defener = actor.getDefender();
        if (defener != null && tc.getAlive(defener.name()) != null) {
            //            int actor_init_x = actor.getPositionManager().getCurrentPosition()[0];
            //            int actor_init_y = actor.getPositionManager().getCurrentPosition()[1];
            //            int[] tp = actor.getPositionManager().getTargetPosition();
            //
            //            int target_init_x = defener.getPositionManager().getCurrentPosition()[0];
            //            int target_init_y = defener.getPositionManager().getCurrentPosition()[1];
            //
            //            //同一水平线上的相邻位置不用挪动
            //            if (target_init_y == actor_init_y && Math.abs(target_init_x - actor_init_x) == BASE_PLACEHOLDER) {
            //                return;
            //            }
            //
            //            Map<String, Object> ret = selectPos(defener, tp, defener.getPositionManager().getCurrentPosition(), 8);
            //            int[] convergeAttackPos = (int[]) ret.get("pos");
            //            setupPos(defener, actor, target_init_x, target_init_y, convergeAttackPos[0], convergeAttackPos[1]);
            //            defener.getPositionManager().setAttackPos((Integer) ret.get("place"));
            return;
        }

        // 如果还有夹击者优先选择夹击者攻击
        if (actor.getAttackers() != null && actor.getAttackers().size() > 0) {
            convergeAttack();
        }

        //如果夹击者全部死亡或者没有夹击者，重新选择对象攻击
        if (target == null) {
            lockTarget();// 锁定攻击对象
            if (target != null) {
                normalAttack(); // 确定攻击位置
            } else {
                // 很少会出现这种情况吧，可能在最后一轮选择的时候，对方士兵已全部死亡
                if (logger.isDebugEnabled()) {
                    logger.debug(actor.name() + "选择 target is null");
                }
                return;
            }
        }

        PositionManager actorPositionManager = actor.getPositionManager();
        PositionManager targetpPositionManager = target.getPositionManager();
        if (logger.isDebugEnabled()) {
            logger.debug("**********************************************");
            logger.debug(actor.name()
                    + "位置信息：curr="
                    + Arrays.toString(actorPositionManager.getCurrentPosition())
                    + ",tar="
                    + (actorPositionManager.getTargetPosition() == null ? Arrays.toString(actorPositionManager.getPosition()) : Arrays.toString(actorPositionManager
                            .getTargetPosition())));
            logger.debug(target.name()
                    + "位置信息：curr="
                    + Arrays.toString(targetpPositionManager.getCurrentPosition())
                    + ",tar="
                    + (targetpPositionManager.getTargetPosition() == null ? Arrays.toString(targetpPositionManager.getPosition()) : Arrays.toString(targetpPositionManager
                            .getTargetPosition())));
            logger.debug("**********************************************");
        }
    }

    private void oneToOne() {
        int actor_init_x = actor.getPositionManager().getCurrentPosition()[0];
        int actor_init_y = actor.getPositionManager().getCurrentPosition()[1];

        int target_init_x = target.getPositionManager().getCurrentPosition()[0];
        int target_init_y = target.getPositionManager().getCurrentPosition()[1];

        int X = actor_init_x - target_init_x + ((actor_init_x - target_init_x) > 0 ? -BASE_PLACEHOLDER : BASE_PLACEHOLDER);
        float Z = 1 - actor.getMoveSpeed() / (actor.getMoveSpeed() + target.getMoveSpeed());

        int actor_x = actor_init_x - Math.round(X * Z);
        int actor_y = actor_init_y - Math.round((actor_init_y - target_init_y) * Z);

        int target_x = target_init_x + (X - Math.round(X * Z));
        int target_y = actor_init_y - Math.round((actor_init_y - target_init_y) * Z);

        int[][] pos = checkAndSelectFightPos(actor, new int[] { actor_x, actor_y }, target, new int[] { target_x, target_y });

        setupPos(actor, target, actor_init_x, actor_init_y, pos[0][0], pos[0][1]);
        setupPos(target, actor, target_init_x, target_init_y, pos[1][0], pos[1][1]);

        actor.getPositionManager().setAttackPos(1);
    }

    public int[][] checkAndSelectFightPos(FightUnit actor, int[] axy, FightUnit target, int[] txy) {
        if (logger.isDebugEnabled()) {
            logger.debug("一对一,初始选定位置：actor=" + Arrays.toString(axy) + ",target=" + Arrays.toString(txy));
        }

        if (!isNeedChange(actor, axy[0], axy[1]) && !isNeedChange(target, txy[0], txy[1])) {
            if (logger.isDebugEnabled()) {
                logger.debug("一对一,最后选定位置：actor=" + Arrays.toString(axy) + ",target=" + Arrays.toString(txy));
            }
            return new int[][] { axy, txy };
        }

        for (int i = 1; i <= MAX_X; i++) {
            int[][][] xy = defaultFightPos(axy, txy, i);
            int[][] actorXy = xy[0];
            int[][] targetXy = xy[1];
            for (int j = 0; j < actorXy.length; j++) {
                if (actorXy[j][0] < MIN_X || actorXy[j][1] < MIN_Y || actorXy[j][0] > MAX_X || actorXy[j][1] > MAX_Y || targetXy[j][0] < MIN_X || targetXy[j][1] < MIN_Y
                        || targetXy[j][0] > MAX_X || targetXy[j][1] > MAX_Y) {
                    continue;
                }
                if (logger.isDebugEnabled()) {
                    logger.debug("一对一," + i + "_" + j + "次选定位置：actor=" + Arrays.toString(actorXy[j]) + ",target=" + Arrays.toString(targetXy[j]));
                }
                if ((!isNeedChange(actor, actorXy[j][0], actorXy[j][1]) && !isNeedChange(target, targetXy[j][0], targetXy[j][1]))
                        || (!isNeedChange(target, actorXy[j][0], actorXy[j][1]) && !isNeedChange(actor, targetXy[j][0], targetXy[j][1]))) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("一对一,最后选定位置：actor=" + Arrays.toString(actorXy[j]) + ",target=" + Arrays.toString(targetXy[j]));
                    }
                    return new int[][] { actorXy[j], targetXy[j] };
                }
            }
        }
        return new int[][] { axy, txy };
    }

    public int[][][] defaultFightPos(int[] axy, int[] txy, int point) {
        int[][] actor = { { axy[0] + point, axy[1] }, { axy[0] - point, axy[1] }, { axy[0], axy[1] - point }, { axy[0], axy[1] + point }, };
        int[][] target = { { txy[0] + point, txy[1] }, { txy[0] - point, txy[1] }, { txy[0], txy[1] - point }, { txy[0], txy[1] + point }, };
        return new int[][][] { actor, target };
    }

    /**
     * 选择夹击的8个位置 左1 、右2 、左下3、 右下4 、左上5 、右上6 、正上7 、正下8
     * 左上：12536478
     * 右上：21645378
     * 左下：12354687
     * 右下：21463587
     * 
     * @param tp 攻击目标位置
     * @param ap 攻击者位置
     * @param point 位移指针
     * @return
     */
    public Map<String, Object> defaultPos(int[] tp, int[] ap, int point) {
        Map<String, Object> defaultPosMap = new HashMap<String, Object>();
        if (tp[0] - ap[0] >= 0 && tp[1] - ap[1] >= 0) {// 左上
            int[][] xy = { { tp[0] - point, tp[1] }, { tp[0] + point, tp[1] }, { tp[0] - point, tp[1] - point }, { tp[0] - point, tp[1] + point },
                    { tp[0] + point, tp[1] + point }, { tp[0] + point, tp[1] + point }, { tp[0], tp[1] - point }, { tp[0], tp[1] + point } };
            defaultPosMap.put("posArr", new int[] { 1, 2, 5, 3, 6, 4, 7, 8 });
            defaultPosMap.put("xyArr", xy);
            return defaultPosMap;
        } else if (tp[0] - ap[0] <= 0 && tp[1] - ap[1] >= 0) {// 右上
            int[][] xy = { { tp[0] + point, tp[1] }, { tp[0] - point, tp[1] }, { tp[0] + point, tp[1] + point }, { tp[0] + point, tp[1] + point },
                    { tp[0] - point, tp[1] - point }, { tp[0] - point, tp[1] + point }, { tp[0], tp[1] - point }, { tp[0], tp[1] + point } };
            defaultPosMap.put("posArr", new int[] { 2, 1, 6, 4, 5, 3, 7, 8 });
            defaultPosMap.put("xyArr", xy);
            return defaultPosMap;
        } else if (tp[0] - ap[0] >= 0 && tp[1] - ap[1] <= 0) {// 左下
            int[][] xy = { { tp[0] - point, tp[1] }, { tp[0] + point, tp[1] }, { tp[0] - point, tp[1] + point }, { tp[0] - point, tp[1] - point },
                    { tp[0] + point, tp[1] + point }, { tp[0] + point, tp[1] + point }, { tp[0], tp[1] + point }, { tp[0], tp[1] - point } };
            defaultPosMap.put("posArr", new int[] { 1, 2, 3, 5, 4, 6, 8, 7 });
            defaultPosMap.put("xyArr", xy);
            return defaultPosMap;
        } else {// 右下
            int[][] xy = { { tp[0] + point, tp[1] }, { tp[0] - point, tp[1] }, { tp[0] + point, tp[1] + point }, { tp[0] + point, tp[1] + point },
                    { tp[0] - point, tp[1] + point }, { tp[0] - point, tp[1] - point }, { tp[0], tp[1] + point }, { tp[0], tp[1] - point } };
            defaultPosMap.put("posArr", new int[] { 2, 1, 4, 6, 3, 5, 8, 7 });
            defaultPosMap.put("xyArr", xy);
            return defaultPosMap;
        }
    }

    /**
     * 选择攻击位置
     * 
     * @param unit actor
     * @param tp 需要去的位置
     * @param ap actor现在的位置
     * @param defaultPlace 默认位置
     * @return
     */
    public Map<String, Object> selectPos(FightUnit unit, int[] tp, int[] ap, int defaultPlace) {
        if (logger.isDebugEnabled()) {
            logger.debug(unit.name() + "夹击位置：" + Arrays.toString(tp) + ",初始位置=" + Arrays.toString(ap));
        }

        Map<String, Object> ret = new HashMap<String, Object>();
        ret.put("pos", ap);
        ret.put("place", defaultPlace);

        for (int i = BASE_PLACEHOLDER; i <= MAX_X; i++) {
            Map<String, Object> dp = defaultPos(tp, ap, i);
            int[][] xy = (int[][]) dp.get("xyArr");
            int[] posInt = (int[]) dp.get("posArr");
            int index = 0;
            for (int[] pos : xy) {
                if (pos[0] < MIN_X || pos[1] < MIN_Y || pos[0] > MAX_X || pos[1] > MAX_Y) {
                    index++;
                    continue;
                }
                if (logger.isDebugEnabled()) {
                    logger.debug(unit.name() + "夹击位置：" + Arrays.toString(tp) + "," + i + "_" + index + "次选定位置=" + Arrays.toString(pos));
                }
                if (!isNeedChange(unit, pos[0], pos[1])) {
                    ret.put("pos", pos);
                    ret.put("place", posInt[index]);
                    return ret;
                }
                index++;
            }
        }
        return ret;
    }

    public boolean isNeedChange(FightUnit owner, int x, int y) {
        if (x >= MAX_X || x <= MIN_X || y >= MAX_Y || y <= MIN_Y || isHaveUnitPos(owner, x, y)) {
            return true;
        }
        return false;
    }

    /**
     * 是否远程兵或者文官
     * 
     * @param type
     * @param target
     * @return 是 true 否 false
     */
    private boolean isNotNeedMove(SoldierProperty type, FightUnit target) {
        if (type != null && type.getAttackType() == AttackType.LONG_RANGE.typeInt() || (type == null && target.isOfficer() && ((OfficerUnit) target).getOfficer().isWenGuan())) {
            return true;
        }
        return false;
    }

    /**
     * 这个坐标上是否有常驻单元或者将要有常驻单元
     * 
     * @param a_x
     * @param a_y
     * @return
     */
    public boolean isHaveUnitPos(FightUnit unit, int a_x, int a_y) {
        Map<FightUnitName, FightUnit> aliveMap = tc.getAliveUnitMap();
        Set<FightUnitName> keySet = aliveMap.keySet();
        for (FightUnitName name : keySet) {
            FightUnit fightUnit = aliveMap.get(name);
            int[] targetPos = fightUnit.getPositionManager().getTargetPosition();
            if (targetPos == null) {
                continue;
            }

            if (!fightUnit.name().equals(unit.name()) && (Math.abs(a_x - targetPos[0]) < BASE_PLACEHOLDER && Math.abs(a_y - targetPos[1]) < BASE_PLACEHOLDER)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 根据计算的最终坐标计算移动的格子数以及方向
     * 
     * @param owner
     * @param target
     * @param init_x
     * @param init_y
     * @param target_x
     * @param target_y
     */
    private void setupPos(FightUnit owner, FightUnit target, int init_x, int init_y, int target_x, int target_y) {
        int actor_move_num = Math.abs(target_x - init_x) + Math.abs(target_y - init_y);

        MoveDirection actor_lr = null;
        MoveDirection actor_ud = target_y - init_y > 0 ? MoveDirection.DOWN : MoveDirection.UP;
        if (target_x - init_x == 0) {
            int defencePos[] = target.getPositionManager().getTargetPosition();
            if (defencePos == null) {
                actor_lr = MoveDirection.RIGHT;
                if (logger.isDebugEnabled()) {
                    logger.debug(actor.name() + "锁定" + target.name() + ",defencePos is null");
                }
            } else {
                actor_lr = target_x - defencePos[0] > 0 ? MoveDirection.LEFT : MoveDirection.RIGHT;
            }
        } else {
            actor_lr = target_x - init_x > 0 ? MoveDirection.RIGHT : MoveDirection.LEFT;
        }

        int actor_lr_move_num = Math.abs(target_x - init_x);
        int actor_ud_move_num = Math.abs(target_y - init_y);

        PositionManager actorPositionManager = owner.getPositionManager();
        actorPositionManager.clear();
        actorPositionManager.setLeftOrRight(actor_lr);
        actorPositionManager.setLockActtackrName(target.name());
        actorPositionManager.setLockTargetInitPos(new int[] { init_x, init_y });
        actorPositionManager.setLrMoveNum(actor_lr_move_num);
        actorPositionManager.setUdMoveNum(actor_ud_move_num);
        actorPositionManager.setTargetPosition(new int[] { target_x, target_y });
        actorPositionManager.setMoveNum(actor_move_num);
        actorPositionManager.setUpOrDown(actor_ud);
        actorPositionManager.setLeftOrRight(actor_lr);

        owner.setIsHaveNewTarget(true);
    }

    public void setSoldierData(SoldierData soldierData) {
        this.soldierData = soldierData;
    }

    /**
     * 判断是否在范围内 [0,0,0,0]表示全局
     * 
     * @param referPos 技能触发者的位置
     * @param targetPos 技能作用者
     * @param range 技能覆盖范围 数值规则：前后上下
     * @param attackDirection 技能覆盖走向
     * @return
     */
    public static boolean isRange(int[] referPos, int[] targetPos, int[] range, MoveDirection attackDirection) {
        if (range[0] == 0 && range[1] == 0 && range[2] == 0 && range[3] == 0) {
            return true;
        }

        int[] x = null;
        int[] y = new int[] { referPos[1] - range[2], referPos[0] + range[3] };
        if (attackDirection == null) {
            x = new int[] { referPos[0] - range[0], referPos[0] + range[1] };
        } else {
            switch (attackDirection) {
                case LEFT:
                    x = new int[] { referPos[0] - range[0], referPos[0] + range[1] };
                    break;
                case RIGHT:
                    x = new int[] { referPos[0] - range[1], referPos[0] + range[0] };
                default:
                    break;
            }

        }

        if (targetPos[0] >= x[0] && targetPos[0] <= x[1] && targetPos[1] >= y[0] && targetPos[1] <= y[1]) {
            return true;
        }
        return false;
    }

}
