package com.hoolai.sangoh5.bo.pvp.data;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-13 11:20
 * @version : 1.0
 */
public class LineupConBoxProperty extends ConBoxReward {

    /** 排行 **/
    private int lineuprank;

    public int getLineuprank() {
        return lineuprank;
    }

    public void setLineuprank(int lineuprank) {
        this.lineuprank = lineuprank;
    }

    @Override
    public boolean contains(int contribute) {
        return lineuprank == contribute;
    }

}
