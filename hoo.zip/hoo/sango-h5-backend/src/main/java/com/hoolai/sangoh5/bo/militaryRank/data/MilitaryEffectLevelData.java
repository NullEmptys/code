package com.hoolai.sangoh5.bo.militaryRank.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class MilitaryEffectLevelData extends JsonData<MilitaryEffectLeveProperty> {

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/leftEar.json", MilitaryEffectLeveProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void checkProperty(MilitaryEffectLeveProperty property) {
        // TODO Auto-generated method stub

    }
}
