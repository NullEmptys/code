package com.hoolai.sangoh5.bo.pvp.data;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-13 10:15
 * @version : 1.0
 */
public class UnionConProperty extends ConBoxReward {

    /** 荣誉区间 **/
    private int[] unionConValve;

    public int[] getUnionConValve() {
        return unionConValve;
    }

    public void setUnionConValve(int[] unionConValve) {
        this.unionConValve = unionConValve;
    }

    @Override
    public boolean contains(int contribute) {
        return unionConValve[0] <= contribute && unionConValve[1] >= contribute;
    }

}
