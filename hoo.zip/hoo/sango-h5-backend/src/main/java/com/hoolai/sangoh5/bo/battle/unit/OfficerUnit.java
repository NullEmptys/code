package com.hoolai.sangoh5.bo.battle.unit;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;

import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.fight.ActionType;
import com.hoolai.sangoh5.bo.battle.fight.BattleEnhance;
import com.hoolai.sangoh5.bo.battle.fight.BattleLog;
import com.hoolai.sangoh5.bo.battle.fight.PositionManager;
import com.hoolai.sangoh5.bo.battle.fight.RoundResult;
import com.hoolai.sangoh5.bo.battle.skill.Occasion;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.active.BaseOfficerPhysicsSkill;
import com.hoolai.sangoh5.bo.battle.skill.active.IndependentSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.DefenceSkill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.DefencePassiveSkill;
import com.hoolai.sangoh5.bo.battle.skill.passive.AttributeEnhanceSkill;
import com.hoolai.sangoh5.bo.battle.skill.trigger.OfficerSkillTrigger;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.officer.OfficerBaseEnhance;

/**
 * officer unit
 */
public class OfficerUnit extends FightUnit {

    private FightUnitName name;

    private RoundResult round;

    private Army army;

    private BaseOfficerPhysicsSkill physicsSkill;

    public OfficerUnit(boolean isAttacker, Officer officer) {
        super(isAttacker, Math.round(officer.getHp()));
        this.officer = officer;
        this.name = isAttacker ? FightUnitName.att_officer : FightUnitName.def_officer;
    }

    private void initPosition(boolean isAttacker) {
        int[] xy = officer.getCurrFormation().takeOfficerPos(isAttacker);
        officer.setInitPosition(new int[] { xy[0], xy[1] });
        setPosition(xy[0], xy[1]);
        setCurrentPosition(xy[0], xy[1]);
        setLockTargetInitPos(xy[0], xy[1]);
    }

    public void setPosition(int x, int y) {
        int position[] = { x, y };
        this.positionManager.setPosition(position);
    }

    public void setCurrentPosition(int x, int y) {
        int position[] = { x, y };
        this.positionManager.setCurrentPosition(position);
    }

    public void setLockTargetInitPos(int x, int y) {
        int position[] = { x, y };
        this.positionManager.setLockTargetInitPos(position);
    }

    public OfficerUnit(boolean isAttacker, Officer officer, Army army, BaseOfficerPhysicsSkill physicsSkill, BattleEnhance battleEnhance, BattleLog battleLog) {
        this(isAttacker, officer);
        this.army = army;
        this.hpLostListener = army;
        this.physicsSkill = physicsSkill;
        this.battleEnhance = battleEnhance;
        this.battleLog = battleLog;
    }

    @Override
    public void changeHp(int deltaHp) {
        this.hpLostListener.onHpLost(this.name(), deltaHp);

        this.hp -= deltaHp;

        if (this.hp < 0 && deltaHp > 0) {
            this.die();
        }

        if (isDead()) {
            lifecycleListener.onDefeated(this);
        }
    }

    public void die() {
        if (logger.isDebugEnabled()) {
            logger.debug(this.name + "死掉啦~~~~~~~~~~~~~~~~~~~~~~");
        }
        //        this.hp = Integer.MIN_VALUE;
        this.clearAttackersStatus();
        lifecycleListener.onDefeated(this);
        lifecycleListener.onKnockedout(this);
    }

    private void clearAttackersStatus() {
        if (this.defender != null) {
            this.defender.removeAttacker(this);
            if (defender.getDefender() != null && defender.getDefender().name().equals(this.name)) {
                defender.setDefender(null);
            }
        }

        Iterator<FightUnit> iterator = attackers.iterator();
        while (iterator.hasNext()) {
            FightUnit unit = iterator.next();
            if (unit.name().equals(this.name)) {
                continue;
            }
            unit.setDefender(null);
        }

        iterator = companionAttacker.iterator();
        while (iterator.hasNext()) {
            FightUnit unit = iterator.next();
            if (unit.name().equals(this.name)) {
                continue;
            }
            unit.removeCompanionAttacker(this);
        }
        this.attackers.clear();
        this.companionAttacker.clear();
    }

    @Override
    public boolean isDead() {
        return this.hp < 0;
    }

    @Override
    public FightUnitName name() {
        return this.name;
    }

    public void setRound(RoundResult roundResult) {
        this.round = roundResult;
    }

    public boolean isBattleFailed() {
        if (!army.hasRemainSoldiers() && this.hp < 0) {
            return true;
        }

        return false;
    }

    public int totalLostPoint() {
        if (isDead()) {
            return originalHp;
        }
        return this.originalHp - this.hp;
    }

    public Officer getOfficer() {
        return officer;
    }

    public void setOfficer(Officer officer) {
        this.officer = officer;
    }

    public FightUnitName getName() {
        return name;
    }

    public void setName(FightUnitName name) {
        this.name = name;
    }

    public Army getArmy() {
        return army;
    }

    public void setArmy(Army army) {
        this.army = army;
    }

    public RoundResult getRound() {
        return round;
    }

    @Override
    public Action action(int roundCounter) {
        Action action = null;
        actionCounter++;

        if (behavior.isSlince()) {
            if (positionManager.isReachTargetPos()) {
                if (logger.isDebugEnabled()) {
                    logger.debug(roundCounter + "回合" + this.name + "眩晕，攻击停顿");
                }
                action = new Action(this, ActionType.ATTACK_IDLE, IndependentSkill.NONE);
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug(roundCounter + "回合" + this.name + "眩晕，移动停顿");
                }
                action = new Action(this, ActionType.MOVE_IDLE, IndependentSkill.NONE);
            }
            return action;
        }

        if (defender == null) {
            if (logger.isDebugEnabled()) {
                logger.debug(roundCounter + "回合" + this.name + "攻击目标" + positionManager.getLockActtackrName() + "死亡，攻击停顿");
            }
            action = new Action(this, ActionType.ATTACK_IDLE, IndependentSkill.NONE);
            return action;
        }
        //        if (logger.isDebugEnabled()) {
        //		logger.debug(String.format("actName : %s , acterCurPos : %s , actTarPos : %s , defName :< %s >, defCur : %s , defTarPos : %s ;", 
        //				name, Arrays.toString(positionManager.getCurrentPosition()),Arrays.toString(positionManager.getTargetPosition()), 
        //				defender.name(),Arrays.toString(defender.getPositionManager().getCurrentPosition()), Arrays.toString(defender.getPositionManager().getTargetPosition())));
        //    }
        if (this.positionManager.isReachTargetPos() && defender != null) {
            if (officer.isWenGuan() || defender.getPositionManager().isReachTargetPos()) {
                action = attack(roundCounter);
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug(roundCounter + "回合" + this.name + "到达目标，等待对方到达");
                }
                action = new Action(this, ActionType.MOVE_IDLE, IndependentSkill.NONE);
            }
        } else {
            attackRoundCounter = 0;
            positionManager.addCounter();
            float mod = Math.round(moveSpeed / ROUND_SPEND);
            if (positionManager.counter() % mod == 0) {
                //				positionManager.next();
                //                if (logger.isDebugEnabled()) {
                //				logger.debug(roundCounter+"回合"+this.name+"移动"+ArrayUtils.toString(positionManager.expectNext()));
                //            }
                action = new Action(this, ActionType.MOVE, IndependentSkill.NONE);
            } else {
                //                if (logger.isDebugEnabled()) {
                //				logger.debug(roundCounter+"回合"+this.name+"移动停顿");
                //            }
                action = new Action(this, ActionType.MOVE_IDLE, IndependentSkill.NONE);
            }
        }
        return action;
    }

    private Action attack(int roundCounter) {
        Action action;
        if (attackRoundCounter == 0) {
            if (logger.isDebugEnabled()) {
                logger.debug(roundCounter + "回合" + this.name + "跑到目标点开始攻击");
            }
            positionManager.clear();
            action = doActions();
        } else {
            int mod = (int) (attackSpeed / ROUND_SPEND);
            if (attackRoundCounter % mod == 0) {
                //                if (logger.isDebugEnabled()) {
                //				logger.debug(roundCounter+"回合"+this.name+"攻击");
                //            }
                action = doActions();
            } else {
                //                if (logger.isDebugEnabled()) {
                //				logger.debug(roundCounter+"回合"+this.name+"攻击停顿");
                //            }
                action = new Action(this, ActionType.ATTACK_IDLE, IndependentSkill.NONE);
            }
        }
        attackRoundCounter++;
        return action;
    }

    private Action doActions() {
        Action action = new Action(this, ActionType.ATTACK, useAttackSkill());
        if (isHaveNextAction()) {
            Action next = new Action(this, ActionType.ATTACK, useNexAttackSkill());
            action.withNext(next);
        }
        return action;
    }

    //	private IndependentSkill useNexKillSoldierSkill() {
    //		boolean isUserNullSkill = isDead() || behavior.isChenMo();
    //		return isUserNullSkill ? IndependentSkill.NONE : trigger.triggerSoldierActionSkill();
    //	}

    private IndependentSkill useNexAttackSkill() {
        boolean isUserNullSkill = isDead() || behavior.isChenMo();
        return isUserNullSkill ? IndependentSkill.NONE : trigger.triggerActionSkill();
    }

    private boolean isHaveNextAction() {
        return this.trigger.getActionSkills().size() > 0;
    }

    private IndependentSkill useAttackSkill() {
        if (behavior.isChenMo()) {
            this.battleLog.add(name + "沉默，触发普攻");
            return physicsSkill;
        }
        IndependentSkill skill = trigger.triggerAttackSkill();
        if (officer.isWenGuan() && skill.isBaseSkill()) {
            return IndependentSkill.NONE;
        }
        return skill;
    }

    public double getLostHPPercentage() {
        int leftHp = this.hp;
        if (leftHp < 0) {
            leftHp = 0;
        }
        return (double) leftHp / this.originalHp;
    }

    @Override
    protected void initAttributes() {
        OfficerBaseEnhance officerBaseEnhance = officer.getOfficerBaseEnhance();
        baseAttackPoint = (officer.getBaseAttack() + officerBaseEnhance.getAttackEnhanceValue()) * (1 + officerBaseEnhance.getAttackEnhanceRate());
        baseDefencePoint = (officer.getBaseDefence() + officerBaseEnhance.getDefenceEnhanceValue()) * (1 + officerBaseEnhance.getDefenceEnhanceRate());
        baseHp = (officer.getBaseHp() + officerBaseEnhance.getHpEnhanceValue()) * (1 + officerBaseEnhance.getHpEnhanceRate());

        attackPoint = officer.getAttack();
        defencePoint = officer.getDefence();
        originalHp = Math.round(officer.getHp());

        if (logger.isDebugEnabled()) {
            logger.debug(name + "：" + officer.getXmlId() + "攻击力：" + baseAttackPoint + "=【" + attackPoint + "】" + ",防御力：" + baseDefencePoint + "=【" + defencePoint + "】" + ",血量："
                    + baseHp + "=【" + originalHp + "】");
        }
        this.battleLog.add(name + "：" + officer.getXmlId() + "攻击力：" + baseAttackPoint + "=【" + attackPoint + "】" + ",防御力：" + baseDefencePoint + "=【" + defencePoint + "】" + ",血量："
                + baseHp + "=【" + originalHp + "】");

        hp = originalHp;

        this.moveSpeed = officer.getMoveSpeed();
        this.attackSpeed = officer.getAttackSpeed();

        //        if (logger.isDebugEnabled()) {
        //        logger.debug(name+"："+officer.getXmlId()+"移动速度："+moveSpeed+"=【"+moveSpeed+"】"
        //        		+",攻击速度："+attackSpeed+"=【"+attackSpeed+"】");
        //    }
    }

    @Override
    public void initSkills() {
        int[] skills = officer.getSkills();
        List<Skill> battleEnhaceSkills = battleEnhance.getOfficerEnhanceSkill();
        List<Skill> otherEnhaceSkills = battleEnhance.getOfficerOtherEnhanceSkills();

        this.passiveSkills = skillData.findPassiveSkills(skills, battleEnhaceSkills, otherEnhaceSkills);
        this.activeSkills = skillData.findActiveSkills(skills, battleEnhaceSkills, otherEnhaceSkills);
        this.counterAttackSkills = skillData.findCounterAttackSkills(skills, battleEnhaceSkills, otherEnhaceSkills);

        this.trigger = new OfficerSkillTrigger(this, physicsSkill, activeSkills);
    }

    @Override
    public void init() {
        initAttributes();
        initSkills();
        this.positionManager = new PositionManager(this);
        initPosition(isAttacker);
    }

    @Override
    public boolean isOfficer() {
        return true;
    }

    @Override
    public int getXmlId() {
        return officer.getXmlId();
    }

    @Override
    public float baseAttackPoint() {
        return baseAttackPoint;
    }

    @Override
    public float baseDefencePoint() {
        return baseDefencePoint;
    }

    @Override
    public float baseHp() {
        return baseHp;
    }

    @Override
    public void applyBeforeBattleSkill(TargetCollection tc) {
        Iterator<AttributeEnhanceSkill> iterator = passiveSkills.iterator();
        while (iterator.hasNext()) {
            AttributeEnhanceSkill skill = iterator.next();
            if (Occasion.BEFORE_BATTLE == skill.getOccasion()) {
                skill.apply(this, tc);
            }
        }
    }

    @Override
    public DefenceSkill useDefenceSkill() {
        return this.trigger.triggerDefenceSkill();
    }

    @Override
    public float baseAttackSpeed() {
        return officer.getAttackSpeed();
    }

    @Override
    public float baseMoveSpeed() {
        return officer.getMoveSpeed();
    }

    @Override
    public void addStealSkill(int skillId) {
        int[] skills = new int[] { skillId };
        if (stealSkills == null) {
            this.stealSkills = skills;
        } else {
            Arrays.fill(stealSkills, skillId);
        }
    }

    @Override
    public void processStealSkillEffects(TargetCollection tc) {
        if (ArrayUtils.isEmpty(stealSkills)) {
            return;
        }
        List<AttributeEnhanceSkill> newPassiveSkills = skillData.findPassiveSkills(stealSkills, null, null);
        List<Skill> newActiveSkills = skillData.findActiveSkills(stealSkills, null, null);
        List<DefencePassiveSkill> newCounterAttackSkills = skillData.findCounterAttackSkills(stealSkills, null, null);

        if (newPassiveSkills.size() > 0) {
            AttributeEnhanceSkill skill = newPassiveSkills.get(0);
            if (Occasion.BEFORE_BATTLE == skill.getOccasion()) {
                skill.apply(this, tc);
            }
            this.passiveSkills.add(skill);
        } else if (newActiveSkills.size() > 0) {
            this.activeSkills.add(newActiveSkills.get(0));
            this.trigger = new OfficerSkillTrigger(this, physicsSkill, this.activeSkills);
        } else if (newCounterAttackSkills.size() > 0) {
            this.counterAttackSkills.add(newCounterAttackSkills.get(0));
        }
    }
}
