package com.hoolai.sangoh5.bo.user.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class BuildingProperty extends JsonProperty {

    private String name;

    private int openLevel;

    private String[] rewardType;

    private int[] rewardId;

    private int[] rewardNum;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOpenLevel() {
        return openLevel;
    }

    public void setOpenLevel(int openLevel) {
        this.openLevel = openLevel;
    }

    public String[] getRewardType() {
        return rewardType;
    }

    public void setRewardType(String[] rewardType) {
        this.rewardType = rewardType;
    }

    public int[] getRewardId() {
        return rewardId;
    }

    public void setRewardId(int[] rewardId) {
        this.rewardId = rewardId;
    }

    public int[] getRewardNum() {
        return rewardNum;
    }

    public void setRewardNum(int[] rewardNum) {
        this.rewardNum = rewardNum;
    }

}
