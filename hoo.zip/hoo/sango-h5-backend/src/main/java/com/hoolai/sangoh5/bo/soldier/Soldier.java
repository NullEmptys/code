package com.hoolai.sangoh5.bo.soldier;

import com.google.protobuf.GeneratedMessage;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.SoldierProto;
import com.hoolai.sangoh5.bo.officer.data.OfficerProperty;
import com.hoolai.sangoh5.bo.soldier.data.SoldierData;
import com.hoolai.sangoh5.bo.soldier.data.SoldierProperty;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Soldier implements ProtobufSerializable {

    protected SoldierType soldierType; // 士兵的类型

    protected int xmlId; // 士兵的xmlId

    transient protected int baseNum;// 士兵不加成的数量

    transient protected float attackSpeed; //攻击速度

    transient protected float moveSpeed; //移动速度

    transient protected int num;//战斗时或者驻防带的士兵数量

    transient protected int baseAttack; //攻击

    transient protected int baseDefence;//防御

    transient protected int[] skills;

    protected SoldierData soldierData;

    public Soldier() {
    }

    public Soldier(SoldierType soldierType) {
        this.soldierType = soldierType;
    }

    public Soldier(SoldierType soldierType, int xmlId, int baseNum) {
        this.soldierType = soldierType;
        this.xmlId = xmlId;
        this.baseNum = baseNum;
    }

    public Soldier(SoldierProto message) {
        copyFrom(message);
    }

    public Soldier(Soldier soldier) {
        this.attackSpeed = soldier.attackSpeed;
        this.moveSpeed = soldier.moveSpeed;
        this.baseNum = soldier.baseNum;
        this.baseAttack = soldier.baseAttack;
        this.baseDefence = soldier.baseDefence;
        this.soldierType = soldier.soldierType;
        this.xmlId = soldier.xmlId;
        this.num = soldier.num;
        this.skills = soldier.getSkills();
    }

    public SoldierType findSoldierType() {
        return soldierType;
    }

    // 4前端
    public int getSoldierType() {
        if (soldierType != null) {
            return soldierType.value();
        }
        return 0;
    }

    public void setSoldierType(SoldierType soldierType) {
        this.soldierType = soldierType;
    }

    public int getBaseNum() {
        return baseNum;
    }

    public void setBaseNum(int num) {
        this.baseNum = num;
    }

    public float getAttackSpeed() {
        return attackSpeed;
    }

    public void setAttackSpeed(float attackSpeed) {
        this.attackSpeed = attackSpeed;
    }

    public float getMoveSpeed() {
        return moveSpeed;
    }

    public void setMoveSpeed(float moveSpeed) {
        this.moveSpeed = moveSpeed;
    }

    public void setSoldierData(SoldierData soldierData) {
        this.soldierData = soldierData;
    }

    public int getXmlId() {
        return xmlId;
    }

    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int captainship) {
        this.num = captainship;
    }

    public int[] getSkills() {
        return skills;
    }

    public void setSkills(int[] skills) {
        this.skills = skills;
    }

    @Override
    public GeneratedMessage copyTo() {
        SoldierProto.Builder builder = SoldierProto.newBuilder();
        builder.setSoldierType(this.soldierType.value());
        builder.setXmlId(xmlId);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            SoldierProto message = SoldierProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(GeneratedMessage proto) {
        SoldierProto message = (SoldierProto) proto;
        if (message.hasSoldierType() && message.getSoldierType() > 0) {
            this.soldierType = SoldierType.valueOf(message.getSoldierType());
        }
        this.xmlId = message.getXmlId();
    }

    public Soldier cloneSoldier() {
        Soldier soldier = new Soldier(this);
        return soldier;
    }

    public int getBaseAttack() {
        return baseAttack;
    }

    public void setBaseAttack(int baseAttack) {
        this.baseAttack = baseAttack;
    }

    public int getBaseDefence() {
        return baseDefence;
    }

    public void setBaseDefence(int baseDefence) {
        this.baseDefence = baseDefence;
    }

    public void init() {
        SoldierProperty soldierProperty = soldierData.getProperty(xmlId);
        this.attackSpeed = soldierProperty.getAttackSpeed();
        this.moveSpeed = soldierProperty.getMoveSpeed();
        this.baseAttack = soldierProperty.getBaseAttack()[0];
        this.baseDefence = soldierProperty.getBaseDefence()[0];
    }

    public void refleshSoldier(OfficerProperty officerProperty, int level, int starLevel) {
        if (xmlId > 0) {
            init();
        }
        this.baseNum = officerProperty.getSoldierAmount() + (officerProperty.getSoldierAdd()[starLevel - 1] * level);
    }

}
