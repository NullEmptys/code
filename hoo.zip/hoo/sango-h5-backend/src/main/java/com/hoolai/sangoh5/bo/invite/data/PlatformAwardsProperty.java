package com.hoolai.sangoh5.bo.invite.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class PlatformAwardsProperty extends JsonProperty {

	private int id;
	private int type;
	private String[] rewardType;
	private int[] rewardId;
	private int[] rewardNum;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String[] getRewardType() {
		return rewardType;
	}
	public void setRewardType(String[] rewardType) {
		this.rewardType = rewardType;
	}
	public int[] getRewardId() {
		return rewardId;
	}
	public void setRewardId(int[] rewardId) {
		this.rewardId = rewardId;
	}
	public int[] getRewardNum() {
		return rewardNum;
	}
	public void setRewardNum(int[] rewardNum) {
		this.rewardNum = rewardNum;
	}

}
