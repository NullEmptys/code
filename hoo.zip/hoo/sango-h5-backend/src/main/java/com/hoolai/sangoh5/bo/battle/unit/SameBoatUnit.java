package com.hoolai.sangoh5.bo.battle.unit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;

public class SameBoatUnit {

    private static final Log logger = LogFactory.getLog("battle");

    private final FightUnit actor;

    private final int skillXmlId;

    private final String skillName;

    private final int executeLevel;

    private final FightUnit fightUnit;

    private final float percentage;

    private final int value;

    public SameBoatUnit(FightUnit actor, FightUnit target, int skillXmlId, String skillName, int executeLevel, float percentage, int value) {
        this.actor = actor;
        this.skillXmlId = skillXmlId;
        this.executeLevel = executeLevel;
        this.fightUnit = target;
        this.percentage = percentage;
        this.value = value;
        this.skillName = skillName;
    }

    public void addTongShangEffect(Effect effect) {
        if (!fightUnit.isDead()) {
            fightUnit.addTongShangEffect(new Effect(skillXmlId, skillName, fightUnit.name(), executeLevel).withActorName(effect.getActorName()).withTargetName(fightUnit.name())
                    .withDeltaHp(Math.round(effect.getDeltaHp() * percentage + value)));

            if (logger.isDebugEnabled()) {
                logger.debug(fightUnit.name() + "被" + effect.getTargetName() + "同伤" + Math.round(effect.getDeltaHp() * percentage + value));
            }
        }
    }

    public FightUnit getFightUnit() {
        return fightUnit;
    }

    public float getPercentage() {
        return percentage;
    }

    public int getValue() {
        return value;
    }

    public int getSkillXmlId() {
        return skillXmlId;
    }

    public boolean equals(SameBoatUnit sameBoatUnit) {
        if (sameBoatUnit.actor.name().equals(actor.name()) && sameBoatUnit.fightUnit.name().equals(fightUnit.name()) && sameBoatUnit.skillXmlId == skillXmlId
                && sameBoatUnit.percentage == percentage && sameBoatUnit.value == value) {
            return true;
        }
        return false;
    }

}
