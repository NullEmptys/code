package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class BarrackKey {

    private static final String prefix= "br";
	
    public static String getBarrackKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("id").toString();
    }
}
