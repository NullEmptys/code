package com.hoolai.sangoh5.bo.activity.data;

import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class RechargeData extends JsonData<RechargeProperty> {

    @PostConstruct
    @Override
    public void init() {
        try {
            initData("com/hoolai/sangoh5/cumulativePayPc.json", RechargeProperty.class);
        } catch (IOException e) {
            logger.error(e);
        }
    }

    @Override
    protected void checkProperty(RechargeProperty property) {

    }

    public List<Integer> getDefaultIds() {
        Collection<RechargeProperty> values = this.propertyMap.values();
        List<Integer> ids = Lists.newArrayListWithExpectedSize(values.size());
        for (RechargeProperty rechargeProperty : values) {
            if (rechargeProperty.isDefault()) {
                ids.add(rechargeProperty.getId());
            }
        }
        Collections.sort(ids);
        return ids;
    }

}
