package com.hoolai.sangoh5.bo.tacticalManagement;

import java.util.Arrays;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.FormationPosProto;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 各兵种站位
 * 
 * @author Administrator
 *
 */
public class FormationPos implements ProtobufSerializable<FormationPosProto> {

    public final static int OFFICER_POS_INT = 7;

    private int posInt;

    private boolean isOfficer;

    private SoldierType soldierType;

    private int[] pos;

    public FormationPos(int posInt, SoldierType soldierType) {
        this.posInt = posInt;
        this.isOfficer = false;
        this.soldierType = soldierType;
    }

    public FormationPos(int posInt) {
        this.posInt = posInt;
        this.isOfficer = true;
    }

    public FormationPos(FormationPos formationPos) {
        this.isOfficer = formationPos.isOfficer;
        this.posInt = formationPos.posInt;
        this.soldierType = formationPos.soldierType;
        this.pos = Arrays.copyOf(formationPos.pos, formationPos.pos.length);
    }

    public FormationPos(FormationPosProto message) {
        copyFrom(message);
    }

    @Override
    public FormationPos clone() {
        FormationPos formationPos = new FormationPos(this);
        return formationPos;
    }

    public int[] getPos() {
        return pos;
    }

    public void setPos(int[] pos) {
        this.pos = pos;
    }

    public boolean isOfficer() {
        return isOfficer;
    }

    public void setOfficer(boolean isOfficer) {
        this.isOfficer = isOfficer;
    }

    public SoldierType getSoldierType() {
        return soldierType;
    }

    public int getSoldierTypeInt() {
        return soldierType == null ? 7 : soldierType.value();
    }

    public void setSoldierType(SoldierType soldierType) {
        this.soldierType = soldierType;
    }

    public int getPosInt() {
        return posInt;
    }

    public void setPosInt(int posInt) {
        this.posInt = posInt;
    }

    @Override
    public FormationPosProto copyTo() {
        FormationPosProto.Builder builder = FormationPosProto.newBuilder();
        builder.setIsOfficer(isOfficer);
        builder.setPosInt(posInt);
        if (soldierType != null) {
            builder.setSoldierType(soldierType.value());
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            FormationPosProto proto = FormationPosProto.parseFrom(bytes);
            copyFrom(proto);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(FormationPosProto message) {
        this.isOfficer = message.getIsOfficer();
        this.posInt = message.getPosInt();
        if (message.getSoldierType() > 0) {
            this.soldierType = SoldierType.valueOf(message.getSoldierType());
        }
    }

}
