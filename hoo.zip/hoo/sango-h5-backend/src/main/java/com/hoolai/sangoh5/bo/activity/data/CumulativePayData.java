package com.hoolai.sangoh5.bo.activity.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.award.Award;
import com.hoolai.sangoh5.bo.award.Award.AwardType;
import com.hoolai.sangoh5.util.json.JsonData;
import com.hoolai.util.IntHashMap;

@Component
public class CumulativePayData extends JsonData<CumulativePayProperty> {

    protected IntHashMap<CumulativePayProperty> gtadeMap = new IntHashMap<CumulativePayProperty>();

    private CumulativePayProperty firstPay;

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/cumulativePay.json", CumulativePayProperty.class);
            initGtade();
        } catch (IOException e) {
            logger.error(e);
        }
    }

    private void initGtade() {
        Collection<CumulativePayProperty> values = propertyMap.values();
        for (CumulativePayProperty property : values) {
            if (property.getGtade() == 0) {
                firstPay = property;
            } else {
                gtadeMap.put(property.getGtade(), property);
            }
        }
    }

    @Override
    protected void checkProperty(CumulativePayProperty property) {

    }

    public Collection<CumulativePayProperty> getPays() {
        return gtadeMap.values();
    }

    public List<Award> getFirstPayGift(int gtade) {
        List<Award> items = new ArrayList<Award>();

        String type[] = firstPay.getType();
        int reAward[] = firstPay.getReward();
        int num[] = firstPay.getNum();

        for (int i = 0; i < type.length; i++) {
            items.add(new Award(reAward[i], num[i], AwardType.converToAwardType(type[i])));
        }
        return items;
    }

    public List<Award> getReward(int rewardId) {
        CumulativePayProperty property = propertyMap.get(rewardId);
        List<Award> items = new ArrayList<Award>();

        String type[] = property.getType();
        int reAward[] = property.getReward();
        int num[] = property.getNum();

        for (int i = 0; i < type.length; i++) {
            items.add(new Award(reAward[i], num[i], AwardType.converToAwardType(type[i])));
        }
        return items;
    }

    public int getFistPayId() {
        return firstPay.getId();
    }

    public int getSize() {
        return gtadeMap.size();
    }

}
