package com.hoolai.sangoh5.bo.activity;

import com.hoolai.sangoh5.bo.activity.data.LuckyWheelProperty;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 17:02
 * @version : 1.0
 */
public class LuckyWheel {

    private int lantianyu;

    private long casUnique;

    public int getLantianyu() {
        return lantianyu;
    }

    public void setLantianyu(int lantianyu) {
        this.lantianyu = lantianyu;
    }

    public long getCasUnique() {
        return casUnique;
    }

    public void setCasUnique(long casUnique) {
        this.casUnique = casUnique;
    }

    public void update(LuckyWheelProperty luckyWheelProperty, ConstantsPoolData constantsPoolData) {
        if (luckyWheelProperty.getId() == 0) {
            this.lantianyu = constantsPoolData.getProperty(26).getValue();
        }
        this.lantianyu += constantsPoolData.getProperty(27).getValue();
        if (this.lantianyu > constantsPoolData.getProperty(25).getValue()) {
            this.lantianyu = constantsPoolData.getProperty(25).getValue();
        }
    }

}
