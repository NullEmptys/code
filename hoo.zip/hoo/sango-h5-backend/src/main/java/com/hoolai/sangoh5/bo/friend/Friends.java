package com.hoolai.sangoh5.bo.friend;

import java.util.ArrayList;
import java.util.List;

public class Friends {

	public List<Long> platformFriends = new ArrayList<Long>();
	
	public List<Long> gameFriends = new ArrayList<Long>();
	
	public List<Long> applyUserIds = new ArrayList<Long>();
	
	transient private List<String> platformIds = new ArrayList<String>();
	
	public void updatePlatformFriends(List<String> platformIds){
		this.platformIds = platformIds;
	}
}
