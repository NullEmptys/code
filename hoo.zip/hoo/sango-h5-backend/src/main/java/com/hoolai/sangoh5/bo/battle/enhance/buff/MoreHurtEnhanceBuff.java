//package com.hoolai.sangoh5.bo.battle.enhance.buff;
//
//import com.hoolai.sangoh5.bo.battle.enhance.Buff;
//import com.hoolai.sangoh5.bo.battle.enhance.effect.MoreHurtEnhanceEffect;
//import com.hoolai.sangoh5.bo.battle.skill.Skill;
//import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
//import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
//import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
//
//public class MoreHurtEnhanceBuff extends Buff{
//	
//	public MoreHurtEnhanceEffect enhanceEffect;
//
//	public MoreHurtEnhanceBuff(int targetUsedSkillXmlId, FightUnitName executeName,
//			int currentLevel,MoreHurtEnhanceEffect enhanceEffect) {
//		super(targetUsedSkillXmlId, executeName,currentLevel);
//		this.enhanceEffect = enhanceEffect;
//	}
//	
//	@Override
//    public void apply(FightUnit target) {
//        this.result();
//        enhanceEffect.setRepeatCount(repeatCount);
//    }
//    
//    public void apply(FightUnit target, Skill skill) {
//    	apply(target);
//    }
//    
//    public void clear(TargetCollection tc) {
//        FightUnit alive = tc.getAlive(this.targetName);
//        if(alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
//            doClear(alive);
//        }
//    }
//    
//    /**
//     * @param alive
//     */
//    protected void doClear(FightUnit alive) {
//    	alive.removeEnhanceEffect(enhanceEffect);
//    }
//
//
//    @Override
//    protected MoreHurtEnhanceBuff clone() {
//    	MoreHurtEnhanceBuff buff = (MoreHurtEnhanceBuff) super.clone(new MoreHurtEnhanceBuff(this.targetUsedSkillXmlId,executeName,currentLevel,enhanceEffect));
//		return buff;
//    }
//
//}
