package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.PhyChenMoBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 物理攻击沉默，只能触发技能，如果没有技能或者未触发技能，攻击停顿
 * 
 * @author Administrator
 *
 */
public class Skill3 extends IndependentSkill {

    @Override
    public Skill clone() {
        return super.clone(new Skill3());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();
        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            Buff buff = target.findBuff(this.xmlId);
            if (buff == null) {
                target.addBuff(new PhyChenMoBuff(xmlId, name, target.name(), true, currentLevel).withActorName(actor.name()).withKeepBuff().withRepeatCount(repeatCount)
                        .withTargetName(target.name()));
            } else {
                buff.setRepeatCount(repeatCount);
            }
            target.phyChenMo();
            targets.add(target);
        }
        return targets;
    }

}
