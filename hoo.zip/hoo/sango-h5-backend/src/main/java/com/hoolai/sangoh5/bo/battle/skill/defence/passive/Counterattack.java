package com.hoolai.sangoh5.bo.battle.skill.defence.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 反击类技能
 * 
 * @author liqing
 *
 */
public class Counterattack extends DefencePassiveSkill {

    @Override
    public void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {
        if (effect == null || effect.getDeltaHp() < 1 || actor.isDead() || target.isDead()) {
            return;
        }
        if (pg.getRandomWithPercentage(chance)) {
            int delHp = effect.getDeltaHp();
            int counterattackHp = (int) (delHp * this.percentage);

            Buff buff1 = new Buff(this.xmlId, name, actor.name(), currentLevel).withActorName(actor.name()).withTargetName(actor.name()).withDeltaHp(counterattackHp);
            buff1.setIsNew(false);
            actor.addBuff(buff1);

            target.addBuff(new Buff(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name()));

            target.addBattleLog(target.name() + "使用" + this.xmlId + "[" + this.name + "]防御了" + actor.name() + "的伤害，old=" + delHp + ",new=" + effect.getDeltaHp());
        }
    }

    @Override
    public Skill clone() {
        return super.clone(new Counterattack());
    }

}
