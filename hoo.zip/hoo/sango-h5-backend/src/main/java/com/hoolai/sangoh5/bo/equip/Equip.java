package com.hoolai.sangoh5.bo.equip;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.EquipProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Equip implements ProtobufSerializable<EquipProto>{
	
	public enum ItemPosition{
		in_bag,in_officer;
	}

	private int id;
	private int xmlId;
	private int position;
	
	public Equip(){
		this.position = ItemPosition.in_bag.ordinal();//在包裹
	}
	public Equip(int xmlId,int pos){
		this();
		this.xmlId = xmlId;
		this.position = pos;
	}
	
	@Override
	public Equip clone(){
		Equip equip = new Equip();
		equip.id = this.id;
		equip.xmlId = this.xmlId;
		equip.position = this.position;
		return equip;
	}
	
	public Equip(EquipProto equips) {
		copyFrom(equips);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getXmlId() {
		return xmlId;
	}
	public void setXmlId(int xmlId) {
		this.xmlId = xmlId;
	}
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	@Override
	public EquipProto copyTo() {
		EquipProto.Builder builder = EquipProto.newBuilder();
		builder.setId(id);
		builder.setXmlId(xmlId);
		builder.setPosition(position);
		return builder.build();
	}
	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}
	@Override
	public void parseFrom(byte[] bytes) {
		try {
			EquipProto message = EquipProto.parseFrom(bytes);
			copyFrom(message);
		} catch (InvalidProtocolBufferException e) {
			throw new BusinessException(ErrorCode.CAN_NOT_MEM);
		}
	}
	@Override
	public void copyFrom(EquipProto message) {
		this.id = message.getId();
		this.xmlId = message.getXmlId();
		this.position = message.getPosition();
	}
	public void levelUp() {
		this.xmlId += 1;
	}
	
	
}
