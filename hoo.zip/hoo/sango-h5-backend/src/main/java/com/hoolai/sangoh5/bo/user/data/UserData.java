package com.hoolai.sangoh5.bo.user.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;
@Component
public class UserData extends JsonData<UserProperty>{

	@PostConstruct
	public void init() {
		try {
    		initData("com/hoolai/sangoh5/character.json", UserProperty.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void checkProperty(UserProperty property) {
		
	}


}
