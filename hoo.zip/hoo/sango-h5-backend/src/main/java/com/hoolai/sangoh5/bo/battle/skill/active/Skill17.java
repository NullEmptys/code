//package com.hoolai.sangoh5.bo.battle.skill.active;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//import com.hoolai.sangoh5.bo.battle.enhance.Effect;
//import com.hoolai.sangoh5.bo.battle.fight.PositionCalculator;
//import com.hoolai.sangoh5.bo.battle.skill.Skill;
//import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
//import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
//import com.hoolai.sangoh5.bo.battle.unit.OfficerUnit;
//import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
// // 给自己队友加血，并给敌方造成一定伤害
//public class Skill17 extends IndependentSkill{
//
//	@Override
//	public List<FightUnit> execute(FightUnit actor, TargetCollection tc,
//			int currentLevel) {
//		List<FightUnit> targets = new ArrayList<FightUnit>();
//		boolean isAttacker = actor.isAttacker();
//		
//		// 给自己加血
//		actor.changeHp((int)value);
//		Map<FightUnitName, FightUnit> ownerAliveMap = tc.aliveTargetSoldier(!isAttacker);
//		Set<FightUnitName> okeySet = ownerAliveMap.keySet();
//		for(FightUnitName name:okeySet){
//			FightUnit target = ownerAliveMap.get(name);
//			target.changeHp((int)value);
//		}
//					
//		Map<FightUnitName, FightUnit> aliveMap = tc.aliveTargetSoldier(isAttacker);
//		Set<FightUnitName> keySet = aliveMap.keySet();
//		int[] referPos = actor.getPositionManager().getCurrentPosition();// 技能的触发者肯定不会在移动状态
//		for(FightUnitName name:keySet){
//			FightUnit target = aliveMap.get(name);
//			int[] targetPos = target.getPositionManager().expectNext();
//			if(PositionCalculator.isRange(referPos, targetPos, range, forceDirection)){
//				target.addEffect(new Effect(xmlId, actor.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name())
//						.withDeltaHp(calLostPoint(actor.baseAttackPoint())));
//			    targets.add(target);
//			}
//		}
//		return targets;
//	}
//
//	private int calLostPoint(float baseAttackPoint) {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//
//	@Override
//	public Skill clone() {
//		return super.clone(new Skill17());
//	}
//
//}
