package com.hoolai.sangoh5.bo.officer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.OfficerProto;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.SoldierProto;
import com.hoolai.sangoh5.bo.barrack.Barrack;
import com.hoolai.sangoh5.bo.battle.fight.Battle;
import com.hoolai.sangoh5.bo.battle.skill.SkillUseCon;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillData;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillProperty;
import com.hoolai.sangoh5.bo.battle.unit.Army;
import com.hoolai.sangoh5.bo.equip.Equip;
import com.hoolai.sangoh5.bo.equip.Equip.ItemPosition;
import com.hoolai.sangoh5.bo.equip.Equips;
import com.hoolai.sangoh5.bo.equip.data.EquipData;
import com.hoolai.sangoh5.bo.equip.data.EquipProperty;
import com.hoolai.sangoh5.bo.equip.data.EquipProperty.EquipType;
import com.hoolai.sangoh5.bo.equip.data.SuitData;
import com.hoolai.sangoh5.bo.equip.data.SuitsProperty;
import com.hoolai.sangoh5.bo.farmland.Farmland;
import com.hoolai.sangoh5.bo.farmland.data.FarmlandAndMineProperty.FarmlandAndMineType;
import com.hoolai.sangoh5.bo.mine.Mine;
import com.hoolai.sangoh5.bo.mission.data.MissionProperty;
import com.hoolai.sangoh5.bo.officer.data.OfficerData;
import com.hoolai.sangoh5.bo.officer.data.OfficerLvData;
import com.hoolai.sangoh5.bo.officer.data.OfficerLvProperty;
import com.hoolai.sangoh5.bo.officer.data.OfficerProperty;
import com.hoolai.sangoh5.bo.officerunion.OfficerUnion;
import com.hoolai.sangoh5.bo.officerunion.OfficerUnions;
import com.hoolai.sangoh5.bo.officerunion.data.OfficerUnionData;
import com.hoolai.sangoh5.bo.officerunion.data.OfficerUnionProperty;
import com.hoolai.sangoh5.bo.soldier.FightSoldier;
import com.hoolai.sangoh5.bo.soldier.Soldier;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.soldier.data.SoldierProperty;
import com.hoolai.sangoh5.bo.tacticalManagement.Formation;
import com.hoolai.sangoh5.bo.tacticalManagement.data.TacticalProperty;
import com.hoolai.sangoh5.bo.union.Union;
import com.hoolai.sangoh5.bo.union.UnionBadgeProperty;
import com.hoolai.sangoh5.bo.union.UnionTitleProperty;
import com.hoolai.sangoh5.bo.union.UnionUser;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.event.event.MissionEvent;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.util.IntHashMap;

public class Officer implements ProtobufSerializable<OfficerProto> {

    public static final int ID_NOT_DEFINED = -1;

    public static final int station_barrack = 1;// 在将营

    public static final int station_main_city = 2;//在主城驻守

    public static final int station_sub_city = 3;//在别人家的主城驻守

    public static final int station_captive = 4;// 在俘虏营

    /*  ------------------- 基本属性  --------------------- */
    private int id;

    private String name;

    private int xmlId;

    private int level;

    private int experience;

    private float hp;

    private float attack;

    private float defence;

    private int station;

    private int withdrawType;

    private float attackSpeed;//攻击速度

    private float moveSpeed;//移动速度

    private int type;//武将类型

    private int showFightPower;//展示战斗力

    /*  ------------------- 星级相关的  --------------------- */
    private int starLevel;

    /*  ------------------- 带兵  --------------------- */
    //这个之所以要存，是策划说以后将领还可以改变带兵类型，需要按照SoldierType的value排序。
    private List<Soldier> soldierList = new ArrayList<Soldier>();

    // 此将领开通的阵型
    private List<Formation> formations = new ArrayList<Formation>();

    // 正在使用的阵型
    transient private Formation currFormation;

    /* ------------------- 技能相关的 ------------------- */

    private int[] skills;

    /* ------------------- 战斗相关的 ------------------- */
    /** 将领是否死亡 */
    private boolean isDead;

    /** 将领一场战斗中丢失的血量 */
    private int lostPoint;

    transient int[] initPosition;//战报里面需要存储

    /* ------------------- 装备相关 ------------------- */
    @JsonIgnore
    private int[] equips;

    transient private List<Equip> equipList;

    transient private Map<EnhanceType, OfficerBaseEnhance> officerEnhanceMap = new HashMap<EnhanceType, OfficerBaseEnhance>();

    transient private Map<EnhanceType, SoldierBaseEnhance> soldierEnhanceMap = new HashMap<EnhanceType, SoldierBaseEnhance>();

    transient private int skillFightValue;

    /* ------------------- 城池相关 ------------------- */
    private long cityUserId;// 如果占领其他城池的话，需要存储其他城池的原主人，方便撤防

    private String cityUserName;

    @JsonIgnore
    transient private boolean isNeedSave;

    @JsonIgnore
    transient private long userId;

    @JsonIgnore
    transient private BoFactory boFactory;

    @JsonIgnore
    transient private OfficerProperty officerProperty;

    @JsonIgnore
    transient private OfficerLvData officerLvData;;

    transient private User cityUser;

    transient private int combinationLevel;

    transient private OfficerBaseEnhance officerBaseEnhance;

    transient private OfficerBaseEnhance officerOtherEnhance;

    transient private SoldierBaseEnhance soldierBaseEnhance;

    transient private SoldierBaseEnhance soldierOtherEnhance;

    public Officer() {
        this.id = ID_NOT_DEFINED;
    }

    public Officer(OfficerProto proto) {
        copyFrom(proto);
    }

    public Officer(long userId) {
        this();
        this.userId = userId;
    }

    public void initNewOfficer(int officerXmlId) {
        OfficerData officerData = boFactory.getOfficerData();
        officerProperty = officerData.getProperty(officerXmlId);
        initNewOfficer0(officerXmlId);
    }

    public void initNewOfficer(OfficerProperty officerProperty) {
        this.officerProperty = officerProperty;
        initNewOfficer0(officerProperty.getId());
    }

    private void initNewOfficer0(int officerXmlId) {
        this.level = 1;
        this.starLevel = 1;
        this.hp = officerProperty.getBaseHp() + level * officerProperty.getHpUp()[starLevel - 1];
        this.attack = officerProperty.getBaseAt() + level * officerProperty.getAtUp()[starLevel - 1];
        this.defence = officerProperty.getBaseDef() + +level * officerProperty.getDefUp()[starLevel - 1];
        this.xmlId = officerXmlId;
        this.name = officerProperty.getName();
        this.attackSpeed = officerProperty.getBaseAs();
        this.moveSpeed = officerProperty.getMs();
        this.type = officerProperty.getType();

        this.station = station_barrack;
        this.withdrawType = 0;
        this.experience = 0;

        Integer[] defaultEquipXmlIds = { officerProperty.getWeapon(), officerProperty.getArmor(), officerProperty.getHelmet(), officerProperty.getHorse() };
        this.equipList = new ArrayList<Equip>();
        for (int xmlId : defaultEquipXmlIds) {
            equipList.add(new Equip(xmlId, ItemPosition.in_officer.ordinal()));
        }

        int inbornSkillId = officerProperty.getTalentSkill();
        if (inbornSkillId != -1) {
            this.skills = new int[] { inbornSkillId };
        } else {
            this.skills = new int[0];
        }

        //初始化阵法
        IntHashMap<TacticalProperty> tacticalData = boFactory.getTacticalData().getPropertyMap();
        for (TacticalProperty tacticalProperty : tacticalData.values()) {
            if (tacticalProperty.getType() == officerProperty.getType()) {
                Formation formation = new Formation(boFactory.getTacticalData(), tacticalProperty.getId(), officerProperty.getSoldierType(), officerProperty.getOneXy(),
                        officerProperty.getTwoXy());
                this.formations.add(formation);
            }
        }
        this.currFormation = this.findFormation(officerProperty.getDefaultTactical());

        this.fillAllOfficerEnhance();

        int[] soldierTypes = officerProperty.getSoldierType();
        Arrays.sort(soldierTypes);// 按照近战远战排序
        for (int type : soldierTypes) {
            SoldierType soldierType = SoldierType.valueOf(type);
            Soldier soldier = new Soldier(soldierType);
            boFactory.inject(soldier);
            soldier.refleshSoldier(officerProperty, this.level, this.starLevel);
            this.soldierList.add(soldier);
        }
    }

    public Officer(Officer officer) {
        this.id = officer.id;
        this.name = officer.name;
        this.xmlId = officer.xmlId;
        this.level = officer.level;
        this.experience = officer.experience;
        this.hp = officer.hp;
        this.attack = officer.attack;
        this.defence = officer.defence;
        this.station = officer.station;
        this.withdrawType = officer.withdrawType;
        this.attackSpeed = officer.attackSpeed;//攻击速度
        this.moveSpeed = officer.moveSpeed;//移动速度
        this.starLevel = officer.starLevel;
        this.soldierList = officer.copySoldiers();
        this.type = officer.type;
        this.officerProperty = officer.officerProperty;
        this.userId = officer.userId;
        this.combinationLevel = officer.combinationLevel;
        this.officerBaseEnhance = officer.officerBaseEnhance.clone();
        this.officerOtherEnhance = officer.officerOtherEnhance.clone();
        this.soldierBaseEnhance = officer.soldierBaseEnhance.clone();
        this.soldierOtherEnhance = officer.soldierOtherEnhance.clone();
        this.officerEnhanceMap = officer.copyOfficerEnhanceMap();
        this.soldierEnhanceMap = officer.copySoldierEnhanceMap();

        if (officer.skills != null) {
            this.skills = Arrays.copyOf(officer.skills, officer.skills.length);
        }

        if (officer.equips != null) {
            this.equips = Arrays.copyOf(officer.equips, officer.equips.length);
            this.equipList = officer.copyEquipList();
        }

        this.currFormation = officer.getCurrFormation().clone();
        if (officer.formations != null) {
            this.formations = officer.copyFormations();
        }

        if (officer.initPosition != null) {
            this.initPosition = Arrays.copyOf(officer.initPosition, officer.initPosition.length);
        }
    }

    private Map<EnhanceType, SoldierBaseEnhance> copySoldierEnhanceMap() {
        Map<EnhanceType, SoldierBaseEnhance> copyMap = new HashMap<Officer.EnhanceType, SoldierBaseEnhance>();

        for (SoldierBaseEnhance baseEnhance : soldierEnhanceMap.values()) {
            copyMap.put(baseEnhance.getEnhanceType(), baseEnhance.clone());
        }
        return copyMap;
    }

    private Map<EnhanceType, OfficerBaseEnhance> copyOfficerEnhanceMap() {
        Map<EnhanceType, OfficerBaseEnhance> copyMap = new HashMap<Officer.EnhanceType, OfficerBaseEnhance>();

        for (OfficerBaseEnhance baseEnhance : officerEnhanceMap.values()) {
            copyMap.put(baseEnhance.getEnhanceType(), baseEnhance.clone());
        }
        return copyMap;
    }

    private List<Formation> copyFormations() {
        if (formations != null && formations.size() > 0) {
            List<Formation> newFormations = new ArrayList<Formation>();
            for (Formation formation : formations) {
                newFormations.add(formation.clone());
            }
            return newFormations;
        }
        return null;
    }

    private List<Soldier> copySoldiers() {
        if (soldierList != null && this.soldierList.size() > 0) {
            List<Soldier> soldiers = new ArrayList<Soldier>();
            for (Soldier soldier : soldierList) {
                soldiers.add(soldier.cloneSoldier());
            }
            return soldiers;
        }
        return null;
    }

    private List<Equip> copyEquipList() {
        if (equipList != null && this.equipList.size() > 0) {
            List<Equip> equips = new ArrayList<Equip>();
            for (Equip equip : equipList) {
                equips.add(equip.clone());
            }
            return equips;
        }
        return null;
    }

    public Officer(long userId, byte[] data) {
        this();
        this.userId = userId;
        parseFrom(data);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getXmlId() {
        return xmlId;
    }

    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    public int getLevel() {
        return level;
    }

    /**
     * 基本是系统指定相关等级才调用的方法，其他功能慎用<br>
     * 跟等级相关的属性有攻防血和士兵
     * 
     * @param starLevel
     */
    public void setLevel(int level) {
        this.level = level;
        if (officerProperty != null) {
            refleshBase();
            refleshSoldier();
        }
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public void fillAllOfficerEnhance() {
        if (officerBaseEnhance == null || officerOtherEnhance == null) {
            officerBaseEnhance = new OfficerBaseEnhance(EnhanceType.BASE);
            List<EnhanceType> baseEnhanceTypes = EnhanceType.findBaseEnhanceType();
            for (EnhanceType enhanceType : baseEnhanceTypes) {
                officerBaseEnhance.addEnhance(officerEnhanceMap.get(enhanceType));
            }

            officerOtherEnhance = new OfficerBaseEnhance(EnhanceType.OTHER);
            List<EnhanceType> oherEnhanceTypes = EnhanceType.findOtherEnhanceType();
            for (EnhanceType enhanceType : oherEnhanceTypes) {
                officerOtherEnhance.addEnhance(officerEnhanceMap.get(enhanceType));
            }
        }

        if (soldierBaseEnhance == null || soldierOtherEnhance == null) {
            soldierBaseEnhance = new SoldierBaseEnhance(EnhanceType.BASE);
            List<EnhanceType> baseEnhanceTypes = EnhanceType.findBaseEnhanceType();
            for (EnhanceType enhanceType : baseEnhanceTypes) {
                soldierBaseEnhance.addEnhance(soldierEnhanceMap.get(enhanceType));
            }

            soldierOtherEnhance = new SoldierBaseEnhance(EnhanceType.OTHER);
            List<EnhanceType> oherEnhanceTypes = EnhanceType.findOtherEnhanceType();
            for (EnhanceType enhanceType : oherEnhanceTypes) {
                soldierOtherEnhance.addEnhance(soldierEnhanceMap.get(enhanceType));
            }
        }
    }

    public enum EnhanceType {
        BASE(0), OTHER(0),
        // 装备
        EQUIP(1),
        // 套装
        EQUIP_SUIT(1),
        // 技能
        SKILL(4),
        // 矿洞
        MINE(3),
        // 农田
        FARMLAND(3),
        // 阵型
        FORMATION(3),
        // 将领组合
        OFFICERUNION(2),
        // 将领驻守
        OFFICERDEFENCE(2),
        // 联盟
        UNION(2),
        // 药水
        POTION(2);

        // 1.base属性; 2.base属性加成   3.既有base属性加成，又有技能加成   4.全是技能加成
        private final int type;

        private EnhanceType(int type) {
            this.type = type;
        }

        public static List<EnhanceType> findBaseEnhanceType() {
            List<EnhanceType> enhanceTypes = new ArrayList<Officer.EnhanceType>();
            for (EnhanceType enhanceType : values()) {
                if (enhanceType.type == 1) {
                    enhanceTypes.add(enhanceType);
                }
            }
            return enhanceTypes;
        }

        public static List<EnhanceType> findOtherEnhanceType() {
            List<EnhanceType> enhanceTypes = new ArrayList<Officer.EnhanceType>();
            for (EnhanceType enhanceType : values()) {
                if (enhanceType.type == 2 || enhanceType.type == 3) {
                    enhanceTypes.add(enhanceType);
                }
            }
            return enhanceTypes;
        }

        public static List<EnhanceType> findSkillEnhanceType() {
            List<EnhanceType> enhanceTypes = new ArrayList<Officer.EnhanceType>();
            for (EnhanceType enhanceType : values()) {
                if (enhanceType.type == 3) {
                    enhanceTypes.add(enhanceType);
                }
            }
            return enhanceTypes;
        }
    }

    public float getHp() {
        if (officerBaseEnhance == null || officerOtherEnhance == null) {
            return hp;
        }
        return Math.round(((hp + officerBaseEnhance.getHpEnhanceValue()) * (1 + officerBaseEnhance.getHpEnhanceRate())) * (1 + officerOtherEnhance.getHpEnhanceRate())
                + officerOtherEnhance.getHpEnhanceValue());
    }

    public void setHp(float hp) {
        this.hp = hp;
    }

    public float getAttack() {
        if (officerBaseEnhance == null || officerOtherEnhance == null) {
            return attack;
        }
        return Math.round(((attack + officerBaseEnhance.getAttackEnhanceValue()) * (1 + officerBaseEnhance.getAttackEnhanceRate()))
                * (1 + officerOtherEnhance.getAttackEnhanceRate()) + officerOtherEnhance.getAttackEnhanceValue());
    }

    public void setAttack(float attack) {
        this.attack = attack;
    }

    public float getDefence() {
        if (officerBaseEnhance == null || officerOtherEnhance == null) {
            return defence;
        }
        return Math.round(((defence + officerBaseEnhance.getDefenceEnhanceValue()) * (1 + officerBaseEnhance.getDefenceEnhanceRate()))
                * (1 + officerOtherEnhance.getDefenceEnhanceRate()) + officerOtherEnhance.getDefenceEnhanceValue());
    }

    public void setDefence(float defence) {
        this.defence = defence;
    }

    public float getBaseHp() {
        return hp;
    }

    public float getBaseAttack() {
        return attack;
    }

    public float getBaseDefence() {
        return defence;
    }

    public int getStation() {
        return station;
    }

    public void setStation(int station) {
        this.station = station;
    }

    public int getWithdrawType() {
        return withdrawType;
    }

    public void setWithdrawType(int withdrawType) {
        this.withdrawType = withdrawType;
    }

    public int[] getSkills() {
        return skills;
    }

    public void setSkills(int[] skills) {
        this.skills = skills;
    }

    public boolean isDead() {
        return isDead;
    }

    public boolean getIsDead() {
        return isDead;
    }

    public void setIsDead(boolean isDead) {
        this.isDead = isDead;
    }

    public int getLostPoint() {
        return lostPoint;
    }

    public void setLostPoint(int lostPoint) {
        this.lostPoint = lostPoint;
    }

    @JsonIgnore
    public int[] getEquips() {
        return equips;
    }

    public void setEquips(int[] equips) {
        this.equips = equips;
    }

    public List<Equip> getEquipList() {
        return equipList;
    }

    public void setEquipList(List<Equip> equipList) {
        this.equipList = equipList;
    }

    public float getAttackSpeed() {
        return attackSpeed;
    }

    public void setAttackSpeed(float attackSpeed) {
        this.attackSpeed = attackSpeed;
    }

    public float getMoveSpeed() {
        return moveSpeed;
    }

    public void setMoveSpeed(float moveSpeed) {
        this.moveSpeed = moveSpeed;
    }

    public List<Soldier> getSoldiers() {
        return soldierList;
    }

    public void setSoldiers(List<Soldier> soldiers) {
        this.soldierList = soldiers;
    }

    public int getStarLevel() {
        return starLevel;
    }

    /**
     * 基本是系统指定相关星级才调用的方法，其他功能慎用<br>
     * 跟星级相关的属性有攻防血和士兵
     * 
     * @param starLevel
     */
    public void setStarLevel(int starLevel) {
        this.starLevel = starLevel;
        if (officerProperty != null) {
            refleshBase();
            refleshSoldier();
        }
    }

    //	public int getTalentNum() {
    //		return talentNum;
    //	}
    //
    //	public void setTalentNum(int talentNum) {
    //		this.talentNum = talentNum;
    //	}

    public Officer cloneOfficer() {
        Officer clone = new Officer(this);
        return clone;
    }

    public void fightedSoldierNum(Army army) {
        Map<SoldierType, FightSoldier> map = army.changeListToMap();
        if (soldierList != null) {
            for (Soldier soldier : soldierList) {
                FightSoldier fightSoldier = map.get(soldier.findSoldierType());
                if (fightSoldier != null) {
                    soldier.setNum(fightSoldier.remainNum());
                }
            }
        }
    }

    public void restoreSoldierNum(Army army) {
        Map<SoldierType, FightSoldier> map = army.changeListToMap();
        if (soldierList != null) {
            for (Soldier soldier : soldierList) {
                FightSoldier fightSoldier = map.get(soldier.findSoldierType());
                if (fightSoldier != null) {
                    soldier.setNum(fightSoldier.getOriginalNum());
                }
            }
        }
    }

    public void setBoFactory(BoFactory boFactory) {
        this.boFactory = boFactory;
    }

    /**
     * 如果将领带兵驻防，刷新带兵等级
     * 
     * @param barrack
     */
    public void fillSoldier(Barrack barrack) {
        if (soldierList != null) {
            for (Soldier soldier : soldierList) {
                boFactory.inject(soldier);
                SoldierType soldierType = soldier.findSoldierType();
                switch (soldierType) {
                    case footman:
                        soldier.setXmlId(barrack.getCurrFootmanId());
                        soldier.setSkills(barrack.getFootmanSkills());
                        break;
                    case rider:
                        soldier.setXmlId(barrack.getCurrRiderId());
                        soldier.setSkills(barrack.getRiderSkills());
                        break;
                    case spearman:
                        soldier.setXmlId(barrack.getCurrSpearmanId());
                        soldier.setSkills(barrack.getSpearmanSkills());
                        break;
                    case archer:
                        soldier.setXmlId(barrack.getCurrArcherId());
                        soldier.setSkills(barrack.getArcherSkills());
                        break;
                    case crossbowman:
                        soldier.setXmlId(barrack.getCurrCrossbowmanId());
                        soldier.setSkills(barrack.getCrossbowmanSkills());
                        break;
                    case vehicleman:
                        soldier.setXmlId(barrack.getCurrVehiclemanId());
                        soldier.setSkills(barrack.getVehiclemanSkills());
                        break;
                    default:
                        break;
                }

                soldier.refleshSoldier(officerProperty, this.level, this.starLevel);
                fillCaptainship(soldier);
            }
        }
    }

    public boolean isNeedSave() {
        return isNeedSave;
    }

    @Override
    public OfficerProto copyTo() {
        OfficerProto.Builder builder = OfficerProto.newBuilder();
        builder.setAttack(attack);
        builder.setAttackSpeed(attackSpeed);
        builder.setDefence(defence);
        builder.setExperience(experience);
        builder.setHp(hp);
        builder.setId(id);
        builder.setLevel(level);
        builder.setMoveSpeed(moveSpeed);
        builder.setStation(station);
        builder.setWithdrawType(withdrawType);
        builder.setXmlId(xmlId);
        builder.setStarLevel(starLevel);
        builder.setName(name);
        builder.setCityUserId(cityUserId);
        builder.setType(type);
        if (cityUserName != null) {
            builder.setCityUserName(cityUserName);
        }

        if (soldierList != null && soldierList.size() > 0) {
            for (Soldier soldier : soldierList) {
                builder.addSoldierList((SoldierProto) soldier.copyTo());
            }
        }
        if (equips != null && equips.length > 0) {
            for (int equip : equips) {
                builder.addEquips(equip);
            }
        }
        if (skills != null && skills.length > 0) {
            for (int skill : skills) {
                builder.addSkills(skill);
            }
        }

        if (currFormation != null) {
            builder.setCurrFormation(currFormation.copyTo());
        }

        if (formations != null && formations.size() > 0) {
            for (Formation formation : formations) {
                builder.addFormations(formation.copyTo());
            }
        }

        if (initPosition != null && initPosition.length > 0) {
            builder.addInitPosition(initPosition[0]);
            builder.addInitPosition(initPosition[1]);
        }
        builder.setShowFightPower(showFightPower);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            OfficerProto message = OfficerProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }

    }

    @Override
    public void copyFrom(OfficerProto message) {
        this.attack = message.getAttack();
        this.attackSpeed = message.getAttackSpeed();
        this.defence = message.getDefence();
        this.experience = message.getExperience();
        this.hp = message.getHp();
        this.id = message.getId();
        this.level = message.getLevel();
        this.moveSpeed = message.getMoveSpeed();
        this.station = message.getStation();
        this.withdrawType = message.getWithdrawType();
        this.xmlId = message.getXmlId();
        this.starLevel = message.getStarLevel();
        this.name = message.getName();
        this.cityUserId = message.getCityUserId();
        this.cityUserName = message.getCityUserName();
        this.type = message.getType();
        if (message.getSoldierListCount() > 0) {
            int c = message.getSoldierListCount();
            this.soldierList = new ArrayList<Soldier>(c);
            for (int i = 0; i < c; i++) {
                soldierList.add(new Soldier(message.getSoldierList(i)));
            }
        }

        if (message.getEquipsCount() > 0) {
            int c = message.getEquipsCount();
            this.equips = new int[c];
            for (int i = 0; i < c; i++) {
                equips[i] = message.getEquips(i);
            }
        }

        if (message.getSkillsCount() > 0) {
            int c = message.getSkillsCount();
            this.skills = new int[c];
            for (int i = 0; i < c; i++) {
                skills[i] = message.getSkills(i);
            }
        }

        int count = message.getFormationsCount();
        for (int i = 0; i < count; i++) {
            this.formations.add(new Formation(message.getFormations(i)));
        }

        if (message.hasCurrFormation()) {
            Formation currFormationTemp = new Formation(message.getCurrFormation());
            this.currFormation = findFormation(currFormationTemp.getId());
        }

        count = message.getInitPositionCount();
        if (count > 1) {
            int x = message.getInitPosition(0);
            int y = message.getInitPosition(1);
            this.initPosition = new int[] { x, y };
        }
        this.showFightPower = message.getShowFightPower();
    }

    @JsonIgnore
    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public Map<EnhanceType, OfficerBaseEnhance> getEnhanceMap() {
        return officerEnhanceMap;
    }

    @JsonIgnore
    public OfficerProperty getOfficerProperty() {
        return officerProperty;
    }

    public void setOfficerProperty(OfficerProperty officerProperty) {
        this.officerProperty = officerProperty;
    }

    public long getCityUserId() {
        return cityUserId;
    }

    public void setCityUserId(long cityUserId) {
        this.cityUserId = cityUserId;
    }

    public String getCityUserName() {
        return cityUserName;
    }

    public void setCityUserName(String cityUserName) {
        this.cityUserName = cityUserName;
    }

    public boolean isStationBarrack() {
        return this.station == station_barrack;
    }

    public void checkAndLearnSkill(int skillXmlId) {
        if (this.skills.length >= 5) {
            throw new BusinessException(ErrorCode.NO_LEARN_SKILL);
        }

        int index = this.skills.length;
        if (level < officerProperty.getSkillBoxLv()[index]) {
            throw new BusinessException(ErrorCode.OFFICER_NOT_ENOUGH_LEVEL);
        }

        SkillData skillData = boFactory.getSkillData();
        SkillProperty property = skillData.getProperty(skillXmlId);
        checkSkill(property);
        isExitSkill(property);

        int[] newSkillItemIds = Arrays.copyOf(skills, skills.length + 1);
        newSkillItemIds[skills.length] = skillXmlId;
        this.skills = newSkillItemIds;
        fillSkillEnhance();

        this.changeShowFightPower();
    }

    /**
     * 检查技能
     * 
     * @param property
     */
    private void checkSkill(SkillProperty property) {
        if (property == null) {
            throw new BusinessException(ErrorCode.NO_SKILL);
        }

        if (property.getLevel() == 0) {
            throw new BusinessException(ErrorCode.CAN_NOT_LEARN_BORN_SKILL);
        }

        if (level < property.getLevel()) {
            throw new BusinessException(ErrorCode.OFFICER_NOT_ENOUGH_LEVEL);
        }

        if ((property.getUseCon() == SkillUseCon.wen_guan.value() && !isWenGuan()) || (property.getUseCon() == SkillUseCon.wu_guan.value() && !isWuGuan())) {
            throw new BusinessException(ErrorCode.CAN_NOT_LEARN_SKILL);
        }
    }

    /**
     * 查询某一类技能是否存在
     * 
     * @param property
     * @return
     */
    private boolean isExitSkill(SkillProperty property) {
        SkillData skillData = boFactory.getSkillData();
        for (int skill : skills) {
            SkillProperty skillProperty = skillData.getProperty(skill);
            if (skillProperty.getSkillId() == property.getSkillId()) {
                throw new BusinessException(ErrorCode.EXIST_LEARN_SKILL);
            }
        }
        return false;
    }

    public void checkAndTroops(Barrack barrack) {
        if (!isStationBarrack()) {
            throw new BusinessException(ErrorCode.OFFICER_NOT_STATION_BARRACK);
        }
        troops(barrack);
    }

    public void troops(Barrack barrack) {
        // 目前没有clear的
        if (soldierList == null) {
            soldierList = new ArrayList<Soldier>();
        }

        int soldierCapta = findAndFillCaptainship();
        barrack.checkAndTroops(soldierCapta);
    }

    private void fillCaptainship(Soldier soldier) {
        int capTemp = (int) (((soldier.getBaseNum() + officerBaseEnhance.getCaptainShipEnhanceValue()) * (1 + officerBaseEnhance.getCaptainShipEnhanceRate()))
                * (1 + officerOtherEnhance.getCaptainShipEnhanceRate()) + officerOtherEnhance.getCaptainShipEnhanceValue());
        soldier.setNum(capTemp);
    }

    public Soldier findSoldierByType(SoldierType type) {
        for (Soldier soldier : soldierList) {
            if (soldier.getSoldierType() == type.value()) {
                return soldier;
            }
        }
        return null;
    }

    public int findAndFillCaptainship() {
        int cap = 0;
        List<SoldierType> soldierTypes = this.getCurrFormation().takeSoldierTypes();
        for (SoldierType soldierType : soldierTypes) {
            Soldier soldier = findSoldier(soldierType);
            if (soldier == null) {
                continue;
            }
            fillCaptainship(soldier);
            cap += soldier.getNum();
        }
        return cap;
    }

    public int findSoldierNum() {
        int cap = 0;
        List<SoldierType> soldierTypes = this.getCurrFormation().takeSoldierTypes();
        for (SoldierType soldierType : soldierTypes) {
            Soldier soldier = findSoldier(soldierType);
            if (soldier == null) {
                continue;
            }
            cap += soldier.getNum();
        }
        return cap;
    }

    /**
     * 确保equipList is not null 的时候使用
     */
    public void fillEquip() {
        EquipData equipData = boFactory.getEquipData();
        int[] suits = new int[equipList.size()];
        int s = 0;
        OfficerBaseEnhance officerEquipEnhance = createOfficerEnhance(EnhanceType.EQUIP);
        SoldierBaseEnhance soldierBaseEnhance = createSoldierEnhance(EnhanceType.EQUIP);
        for (Equip equip : equipList) {
            suits[s++] = fillEquipEnhance(equipData, equip, officerEquipEnhance, soldierBaseEnhance);
        }
        fillEquipSuitsEnhance(suits);
    }

    public void fillEquip(Equips allEquips) {
        if (equips == null || equips.length < 1) {
            return;
        }
        EquipData equipData = boFactory.getEquipData();
        //        if (this.equipList == null) {
        int[] suits = new int[equips.length];
        equipList = new ArrayList<Equip>();
        int defaultEquipId = 0;
        int s = 0;

        OfficerBaseEnhance officerEquipEnhance = createOfficerEnhance(EnhanceType.EQUIP);
        SoldierBaseEnhance soldierBaseEnhance = createSoldierEnhance(EnhanceType.EQUIP);
        for (int equipId : equips) {
            defaultEquipId--;
            Equip equip = equipData.isDefaultByEquipId(equipId) ? equipData.findDefaultEquip(equipId) : allEquips.findEquip(equipId);
            if (equip == null) {
                equip = equipData.findDefaultEquip(defaultEquipId);
            }
            equipList.add(equip);

            suits[s++] = fillEquipEnhance(equipData, equip, officerEquipEnhance, soldierBaseEnhance);

        }
        fillEquipSuitsEnhance(suits);
        //        }
    }

    /**
     * 每次都是创建的新的，以保证新属性能够修改
     * 
     * @param enhanceType
     * @return
     */
    private OfficerBaseEnhance createOfficerEnhance(EnhanceType enhanceType) {
        OfficerBaseEnhance enhance = new OfficerBaseEnhance(enhanceType);
        officerEnhanceMap.put(enhanceType, enhance);
        return enhance;
    }

    /**
     * 每次都是创建的新的，以保证新属性能够修改
     * 
     * @param enhanceType
     * @return
     */
    private SoldierBaseEnhance createSoldierEnhance(EnhanceType enhanceType) {
        SoldierBaseEnhance enhance = new SoldierBaseEnhance(enhanceType);
        soldierEnhanceMap.put(enhanceType, enhance);
        return enhance;
    }

    private int fillEquipEnhance(EquipData equipData, Equip equip, OfficerBaseEnhance officerEquipEnhance, SoldierBaseEnhance soldierBaseEnhance) {
        EquipProperty property = equipData.getProperty(equip.getXmlId());
        if (property == null) {
            return -1;
        }

        officerEquipEnhance.enhance(property);
        soldierBaseEnhance.enhance(property);
        return property.getSuit();
    }

    private void fillEquipSuitsEnhance(int[] suits) {
        int min = Integer.MAX_VALUE;
        for (int suit : suits) {
            if (suit < min) {
                min = suit;
            }
        }
        if (min < 0) {
            return;
        }
        SuitData suitData = boFactory.getSuitData();
        SuitsProperty suitProperty = suitData.getProperty(min);

        OfficerBaseEnhance equipEnhance = createOfficerEnhance(EnhanceType.EQUIP_SUIT);
        equipEnhance.enhance(suitProperty);
    }

    /**
     * 技能里的属性加成暂不计算，战斗力直接读技能里面的值
     */
    public void fillSkillEnhance() {
        this.skillFightValue = 0;
        if (skills != null && this.skills.length > 0) {
            SkillData skillData = boFactory.getSkillData();
            OfficerBaseEnhance equipEnhance = createOfficerEnhance(EnhanceType.SKILL);
            for (int skill : skills) {
                SkillProperty property = skillData.getProperty(skill);
                equipEnhance.enhance(property);
                skillFightValue += property.getFight();
            }
        }
    }

    private int findSkillIndex(int skillXmlId) {
        for (int i = 0; i < skills.length; i++) {
            if (skills[i] == skillXmlId) {
                return i;
            }
        }
        return -1;
    }

    public void checkAndChangeSkill(int skillXmlId, int changeSkillXmlId) {

        int index = findSkillIndex(skillXmlId);
        if (index < 0) {
            throw new BusinessException(ErrorCode.NO_LEARNED_SKILL);
        }

        if (isBornSkill(skillXmlId)) {
            throw new BusinessException(ErrorCode.CAN_NOT_CHANGE_BORN_SKILL);
        }

        if (isExistSkill(changeSkillXmlId)) {
            throw new BusinessException(ErrorCode.EXIST_LEARN_SKILL);
        }
        SkillData skillData = boFactory.getSkillData();
        SkillProperty property = skillData.getProperty(changeSkillXmlId);
        for (int skill : skills) {
            SkillProperty skillProperty = skillData.getProperty(skill);
            if (skillProperty.getSkillId() == property.getSkillId() && findSkillIndex(skill) != index) {
                throw new BusinessException(ErrorCode.EXIST_LEARN_SKILL);
            }
        }
        checkSkill(property);

        // 替换不要改变原来的位置
        skills[index] = changeSkillXmlId;
        fillSkillEnhance();

        this.changeShowFightPower();
    }

    public void changeShowFightPower() {
        this.showFightPower = this.getFightPower();
    }

    private boolean isBornSkill(int skillXmlId) {
        if (officerProperty == null) {
            officerProperty = boFactory.getOfficerData().getProperty(xmlId);
        }

        return officerProperty.getTalentSkill() == skillXmlId;
    }

    public void checkAndRemoveSkill(int skillXmlId) {
        if (this.skills.length <= 1 || !isExistSkill(skillXmlId)) {
            throw new BusinessException(ErrorCode.NO_LEARNED_SKILL);
        }
        if (isBornSkill(skillXmlId)) {
            throw new BusinessException(ErrorCode.CAN_NOT_UNLOAD_BORN_SKILL);
        }
        //        if (!isStationBarrack()) {
        //            throw new BusinessException(ErrorCode.OFFICER_NOT_STATION_BARRACK);
        //        }

        removeSkill(skillXmlId);
        fillSkillEnhance();

        this.changeShowFightPower();
    }

    /**
     * 精确查找某一个技能是否存在
     * 
     * @param skillXmlId
     * @return
     */
    private boolean isExistSkill(int skillXmlId) {
        for (int skill : skills) {
            if (skill == skillXmlId) {
                return true;
            }
        }
        return false;
    }

    private void removeSkill(int skillXmlId) {
        int[] newSkill = new int[skills.length - 1];
        int i = 0;
        for (int skill : skills) {
            if (skill != skillXmlId) {
                newSkill[i++] = skill;
            }
        }
        this.skills = newSkill;
    }

    private boolean isExistEquip(int equipId) {
        for (int equip : equips) {
            if (equip == equipId) {
                return true;
            }
        }
        return false;
    }

    public int[] fastLoadEquip(Equips addEquips) {
        if (!isStationBarrack()) {
            throw new BusinessException(ErrorCode.OFFICER_NOT_STATION_BARRACK);
        }
        addEquips.backToBag(this.equips);

        EquipData equipData = boFactory.getEquipData();
        this.equips = equipData.findMaxOfficerEquip(this, addEquips);
        addEquips.loadToOfficer(this.equips);
        return equips;
    }

    public void fastUnLoadEquip(Equips addEquips) {
        if (!isStationBarrack()) {
            throw new BusinessException(ErrorCode.OFFICER_NOT_STATION_BARRACK);
        }
        addEquips.backToBag(this.equips);

        EquipData equipData = boFactory.getEquipData();
        this.equips = equipData.findDefaultEquips();
    }

    public int loadEquip(Equip equip) {
        if (equip == null) {
            throw new BusinessException(ErrorCode.NO_EQUIP);
        }
        if (!isStationBarrack()) {
            throw new BusinessException(ErrorCode.OFFICER_NOT_STATION_BARRACK);
        }

        EquipData equipData = boFactory.getEquipData();
        EquipProperty property = equipData.getProperty(equip.getXmlId());
        if (property.getNeedOfficerLv() > this.level) {
            throw new BusinessException(ErrorCode.OFFICER_NOT_ENOUGH_LEVEL);
        }

        EquipType equipType = EquipType.convertEquipType(property.getType());
        int changeEquipId = this.equips[equipType.ordinal()];
        this.equips[equipType.ordinal()] = equip.getId();

        return changeEquipId;
    }

    public void unLoadEquip(Equip equip) {
        if (equip == null) {
            throw new BusinessException(ErrorCode.NO_EQUIP);
        }
        if (!isExistEquip(equip.getId())) {
            throw new BusinessException(ErrorCode.NO_LOAD_EQUIP);
        }
        if (!isStationBarrack()) {
            throw new BusinessException(ErrorCode.OFFICER_NOT_STATION_BARRACK);
        }

        EquipData equipData = boFactory.getEquipData();
        EquipProperty property = equipData.getProperty(equip.getXmlId());
        EquipType equipType = EquipType.convertEquipType(property.getType());

        this.equips[equipType.ordinal()] = equipData.findDefaultEquipId(equipType);
    }

    public Officer refleshEquip(Equips equips) {
        this.equipList = null;
        this.fillEquip(equips);
        this.refleshSoldier();
        this.changeShowFightPower();
        return this;
    }

    public boolean levelUp(int exp, int roleLevel) {
        this.experience += exp;
        if (this.level >= officerLvData.getPropertyMap().size()) {
            this.experience = 0;
            return false;
        }
        OfficerLvProperty property = officerLvData.getProperty(level);
        int needExp = property.getExp();

        int beforelevel = level;
        while (experience >= needExp && level < officerLvData.getPropertyMap().size()) {
            int nextLevel = level + 1;
            if (nextLevel > officerLvData.getPropertyMap().size()) {
                experience = 0;
                break;
            }
            if (nextLevel > roleLevel) {
                break;
            }
            ++level;
            this.experience -= needExp;
            needExp = officerLvData.getProperty(level).getExp();
            refleshBase();
            refleshSoldier();
            skillLvUp();
        }
        if (level > beforelevel) {
            this.changeShowFightPower();
            boFactory.getMissionEngine().onEvent(new MissionEvent(MissionProperty.PROPERTY_升级_任意将领_MISSION, 1, userId));
            return true;
        }
        return false;
    }

    private void skillLvUp() {
        int bornSkillId = this.skills[0];
        SkillProperty skillProperty = boFactory.getSkillData().getProperty(bornSkillId);
        if (skillProperty.getNextLv() == 0) {
            return;
        }

        int skillLv = skillProperty.getSkillLv();
        if (this.level >= officerProperty.getSkillLvup()[skillLv - 1]) {
            this.skills[0] = skillProperty.getNextLv();
            fillSkillEnhance();
        }
    }

    //	public void refleshLevel() {
    //		boolean isCanAddLevel = true;
    //		do{
    //			int nextLevel = this.level + 1;
    //			if(nextLevel > MAX_OFFICER_LEVEL) break;
    //			int needExp = EXPERIENCE_RANGE[nextLevel];
    //			if(this.experience - needExp >= 0){
    //				setLevel(nextLevel);
    //				this.talentNum += 1;
    //				this.attack += officerProperty.getAtUp()[starLevel-1];
    //				this.defence += officerProperty.getDefUp()[starLevel-1];
    //				this.hp += officerProperty.getHpUp()[starLevel-1];
    //				
    //				experience -= needExp;
    //				isNeedSave = true;
    //			}else{
    //				isCanAddLevel = false;
    //			}
    //	   }while(isCanAddLevel);
    //	}

    //	public void allotTalent(SoldierType soldierType,int talent){
    //		int soldierTalentNum = soldierAllTalentNum();
    //		if(soldierTalentNum + talent > this.level){
    //			throw new BusinessException(ErrorCode.NOT_ENOUGH_LEVEL);
    //		}
    //		Soldier soldier = findSoldier(soldierType);
    //		if(soldier == null){
    //			throw new BusinessException(ErrorCode.NO_SOLDIER);
    //		}
    //		soldier.addTalent(talent);
    //		this.talentNum -= talent;
    //		soldier.refleshSoldier(officerProperty, level,starLevel);
    //	}

    public Soldier findSoldier(SoldierType soldierType) {
        for (Soldier soldier : soldierList) {
            if (soldier.findSoldierType() == soldierType) {
                return soldier;
            }
        }
        return null;
    }

    public void defence(long cityUserId, String cityUserName) {
        this.station = station_main_city;
        this.cityUserId = cityUserId;
        this.cityUserName = cityUserName;
        fillOfficerDefenceEnhance();
    }

    public void occupy(long cityUserId, String cityUserName) {
        this.station = station_sub_city;
        this.cityUserId = cityUserId;
        this.cityUserName = cityUserName;
    }

    public void clearSoldier() {
        for (Soldier soldier : soldierList) {
            soldier.setNum(0);
        }
    }

    public void backBarrack() {
        clearSoldier();
        this.station = station_barrack;
        this.cityUserId = 0;
        this.cityUserName = "";
    }

    /**
     * type == 0
     */
    public boolean isWuGuan() {
        return 0 == type;
    }

    /**
     * type == 1
     */
    public boolean isWenGuan() {
        return 1 == type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public List<Formation> getFormations() {
        return formations;
    }

    public void setFormations(List<Formation> formations) {
        this.formations = formations;
    }

    public Formation getCurrFormation() {
        return currFormation == null ? formations.get(0) : currFormation;
    }

    public void setCurrFormation(Formation currFormation) {
        this.currFormation = currFormation;
    }

    public void fillFormations() {
        for (Formation forma : formations) {
            forma.init(boFactory.getTacticalData());
        }

        refleshFormation();
    }

    private void refleshFormation() {
        Formation formation = getCurrFormation();
        formation.init(boFactory.getTacticalData());

        OfficerBaseEnhance formationEnhance = createOfficerEnhance(EnhanceType.FORMATION);
        SoldierBaseEnhance soldierBaseEnhance = createSoldierEnhance(EnhanceType.FORMATION);
        formationEnhance.enhance(boFactory.getTacticalData().getProperty(formation.getId()), formation.getStarLevel());
        soldierBaseEnhance.enhance(boFactory.getTacticalData().getProperty(formation.getId()), formation.getStarLevel());
    }

    public int[] getInitPosition() {
        return initPosition;
    }

    public void setInitPosition(int[] initPosition) {
        this.initPosition = initPosition;
    }

    public Formation findFormation(int fid) {
        for (Formation formation : formations) {
            if (formation.getId() == fid) {
                return formation;
            }
        }
        return null;
    }

    public void changeCurrFormation(int fid) {
        Formation formation = findFormation(fid);
        if (formation == null) {
            throw new BusinessException(ErrorCode.NO_HAVE_FORMATION);
        }
        this.currFormation = formation;
        refleshFormation();
        this.changeShowFightPower();
    }

    public Formation learnFormation(int fid, TacticalProperty tacticalProperty) {

        if (findFormation(fid) != null) {
            throw new BusinessException(ErrorCode.HAVE_FORMATION);
        }

        OfficerData officerData = boFactory.getOfficerData();
        officerProperty = officerData.getProperty(this.xmlId);

        Formation formation = new Formation(boFactory.getTacticalData(), fid, officerProperty.getSoldierType(), officerProperty.getOneXy(), officerProperty.getTwoXy());
        this.formations.add(formation);
        return formation;
    }

    public Soldier learnSoldier(Barrack barrack, int soldierTypeInt) {
        SoldierType soldierType = SoldierType.valueOf(soldierTypeInt);

        Soldier soldier = findSoldier(soldierType);
        if (soldier != null) {
            throw new BusinessException(ErrorCode.HAVE_SOLDIER);
        }

        soldier = new Soldier(soldierType);
        boFactory.inject(soldier);
        this.soldierList.add(soldier);

        fillSoldier(barrack);

        this.changeShowFightPower();
        return soldier;
    }

    public void checkStarLevel() {
        if (starLevel >= 5) {
            throw new BusinessException(ErrorCode.STAR_LEVEL_HAS_OVER_LIMIT);
        }
    }

    public void LevelUpStar() {
        this.starLevel++;
        refleshBase();
        refleshSoldier();
        this.changeShowFightPower();
    }

    public void setOfficerLvData(OfficerLvData officerLvData) {
        this.officerLvData = officerLvData;
    }

    public void refleshBase() {
        this.hp = officerProperty.getBaseHp() + level * officerProperty.getHpUp()[starLevel - 1];
        this.attack = officerProperty.getBaseAt() + level * officerProperty.getAtUp()[starLevel - 1];
        this.defence = officerProperty.getBaseDef() + +level * officerProperty.getDefUp()[starLevel - 1];
    }

    public void refleshSoldier() {
        for (Soldier soldier : soldierList) {
            soldier.refleshSoldier(officerProperty, level, this.starLevel);
            fillCaptainship(soldier);
        }
    }

    public boolean whetherHaveOfficerUnion() {
        return this.officerProperty.isHaveOfficerUnion();
    }

    public int findCombinationId() {
        return this.officerProperty.getCombinationId();
    }

    public void fillOfficerUnions(OfficerUnions officerUnions) {
        if (officerUnions == null) {
            return;
        }
        OfficerUnion officerUnion = officerUnions.findOfficerUnion(this.findCombinationId());

        OfficerUnionData officerUnionData = boFactory.getOfficerUnionData();
        OfficerUnionProperty property = officerUnionData.getProperty(this.findCombinationId());

        OfficerBaseEnhance enhance = createOfficerEnhance(EnhanceType.OFFICERUNION);
        this.combinationLevel = officerUnion.getMinStarLv();
        enhance.enhance(property, combinationLevel);
    }

    public void findFormationAndModification(int fid) {
        for (Formation formation : formations) {
            if (formation.getId() == fid) {
                formation.addFightNum();
            }
        }
    }

    public User getCityUser() {
        return cityUser;
    }

    public void setCityUser(User cityUser) {
        this.cityUser = cityUser;
    }

    public void fillLandMineEnhance(Mine mine, Farmland farmland) {
        int landRate = boFactory.getFarmlandAndMineData().findSoldierEnhance(FarmlandAndMineType.FARM_LAND, farmland.getLandLevel());
        int mineRate = boFactory.getFarmlandAndMineData().findSoldierEnhance(FarmlandAndMineType.MINE, mine.getLandLevel());

        OfficerBaseEnhance enhance = createOfficerEnhance(EnhanceType.MINE);
        enhance.setCaptainShipEnhanceRate(enhance.getCaptainShipEnhanceRate() + mineRate / 100f);

        OfficerBaseEnhance fenhance = createOfficerEnhance(EnhanceType.FARMLAND);
        fenhance.setCaptainShipEnhanceRate(fenhance.getCaptainShipEnhanceRate() + landRate / 100f);
    }

    public float soldierFightValue() {
        float soldierFightValue = 0;
        List<SoldierType> soldierTypes = this.getCurrFormation().takeSoldierTypes();
        for (SoldierType soldierType : soldierTypes) {
            Soldier soldier = findSoldier(soldierType);
            if (soldier == null) {
                continue;
            }
            SoldierProperty soldierProperty = boFactory.getSoldierData().getProperty(soldier.getXmlId());
            if (soldierProperty != null) {
                soldierFightValue += soldier.getNum() * soldierProperty.getFight();
            }
        }
        return soldierFightValue;
    }

    public int getFightPower() {
        // (生命值+攻击力*10+防御力*40+(等级+星级)*移速*400+(2-攻速)*(等级+星级)*1500)/8+技能战斗力+兵种战斗力

        float base = (getHp() + getAttack() * 10 + getDefence() * 40 + (level + starLevel) * moveSpeed * 400 + (2 - attackSpeed) * (level + starLevel) * 1500) / 8;

        return (int) (base + skillFightValue + soldierFightValue());
    }

    public void fillOfficerDefenceEnhance() {
        OfficerBaseEnhance enhance = createOfficerEnhance(EnhanceType.OFFICERDEFENCE);
        enhance.enhanceBattleEnhance(boFactory.getBattleEnhanceData().getProperty(Battle.OFFICER_DEFENCE_ENHANCE_SKILL));
    }

    public void fillUnionEnhance(Union union, UnionUser unionUser) {
        if (union != null) {
            OfficerBaseEnhance enhance = createOfficerEnhance(EnhanceType.UNION);

            UnionBadgeProperty property = boFactory.getUnionBadgeData().getProperty(union.getLevel());
            UnionTitleProperty unionTitleProperty = boFactory.getUnionTitleData().getProperty(unionUser.getPosition());

            if (property != null && union.getLevel() != 0) {
                float realGet = unionTitleProperty.getTitleGet() / 100f;
                List<Integer> skills = property.getEnhanceSkillS();
                for (int skillId : skills) {
                    SkillProperty skillProperty = boFactory.getBattleEnhanceData().getProperty(skillId);
                    skillProperty.setPercentage(skillProperty.getPercentage() * realGet);
                    skillProperty.setValue(Math.round(skillProperty.getValue() * realGet));
                    enhance.enhanceBattleEnhance(skillProperty);
                }
            }
        }
    }

    public void fillPotion(List<SkillProperty> skillProperties) {
        if (skillProperties == null || skillProperties.size() < 1) {
            return;
        }
        OfficerBaseEnhance enhance = createOfficerEnhance(EnhanceType.POTION);
        for (SkillProperty skillProperty : skillProperties) {
            enhance.enhanceBattleEnhance(skillProperty);
        }
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public SoldierBaseEnhance getSoldierBaseEnhance() {
        return soldierBaseEnhance;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public SoldierBaseEnhance getSoldierOtherEnhance() {
        return soldierOtherEnhance;
    }

    @JsonIgnore
    @org.codehaus.jackson.annotate.JsonIgnore
    public OfficerBaseEnhance getOfficerBaseEnhance() {
        return officerBaseEnhance;
    }

    public int getCombinationLevel() {
        return combinationLevel;
    }

    public void setCombinationLevel(int combinationLevel) {
        this.combinationLevel = combinationLevel;
    }

    public int findShowFightPower() {
        return this.showFightPower;
    }

    public void reachOfficerUnions(OfficerUnions officerUnions) {
        this.fillOfficerUnions(officerUnions);
        this.changeShowFightPower();
    }

    public void changeFormationPos(int fid, int pos, int soldierTypeInt) {
        Formation formation = this.findFormation(fid);
        if (formation == null) {
            throw new BusinessException(ErrorCode.NO_HAVE_FORMATION);
        }
        formation.changeFormationPos(pos, soldierTypeInt);
        if (getCurrFormation().getId() == fid) {
            this.changeShowFightPower();
        }
    }

}
