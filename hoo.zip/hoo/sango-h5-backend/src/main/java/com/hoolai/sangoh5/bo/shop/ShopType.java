package com.hoolai.sangoh5.bo.shop;

import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public enum ShopType {
	RANK_FIGHT_SHOP(1, "排位战商店"), 
	ARENA_SHOP(2, "竞技场商店"), 
	UNIOIN_SHOP(3, "联盟商店");

	private int type;
	private String desc;

	private ShopType(int type, String desc) {
		this.type = type;
		this.desc = desc;
	}
	
	public static ShopType getValue(int type){
		for(ShopType shopType :ShopType.values()){
			if(shopType.getType() == type){
				return shopType;
			}
		}
		throw new BusinessException(ErrorCode.NOT_EXIST_SHOP);
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
