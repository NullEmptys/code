package com.hoolai.sangoh5.bo.platform.wanba;


import java.util.Map;

import com.hoolai.platform.RequestInfo;
import com.hoolai.platform.RequestInfoFactory;
import com.hoolai.platform.service.tencent.TencentRequestInfo;
import com.hoolai.sango.util.JSONUtils;
import com.hoolai.sangoh5.bo.platform.MobilePlatform;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.util.Constant;
import com.hoolai.util.StringUtil;

/**
 * <p>描述：玩吧H5平台因为明确规定IOS和非IOS登陆必须是2个不同的用户，所以我们在User的openId上添加了后缀_ios和_nonios区分</p>
 * <p>此类的主要作用是在需要调用腾讯API的时候，需要调用checkRequestInfo方法把删除掉后缀_ios和_nonios，确保调用腾讯API时使用正确的openId</p>
 * @author whg
 * @date 2016-12-22 下午01:17:01
 */
public class PlatformRequestInfo {

	private final String requestInfoStr;
	
	private RequestInfo requestInfo;
	private String openid;
	private String realPlatformId;
	private String via = Constant.PLATFORM_NAME;
	
	private String token;
	
	public PlatformRequestInfo(String requestInfoStr) {
		this.requestInfoStr = requestInfoStr;
	}
	
	/** 确保调用腾讯API时使用正确的openId，调用此方法后使用getRequestInfo获取删除掉后缀_ios和_nonios的正确RequestInfo */
	public void checkRequestInfo(){
		checkRequestInfo(false);
	}
	
	public void checkRequestInfo4H5(){
		checkRequestInfo(true);
	}
	
	/**
	 * 确保调用腾讯API时使用正确的openId，调用此方法后使用getRequestInfo获取删除掉后缀_ios和_nonios的正确RequestInfo
	 * 
	 * @param isForH5 是否专门为腾讯玩吧H5平台调用,是玩吧H5平台则pf值必须是wanba_ts
	 */
	public void checkRequestInfo(boolean isForH5){
		requestInfo = RequestInfoFactory.parseRequestInfo(Constant.platformType, requestInfoStr);
		openid = requestInfo.findPid();
		TencentRequestInfo tencentRequestInfo = null;
		if(!User.isValidPlatformId(openid)){
			openid = MobilePlatform.nonios.gameOpenid(openid);
		}
		
		realPlatformId = User.realPlatformId(openid);
		if(requestInfo instanceof TencentRequestInfo){
			tencentRequestInfo = (TencentRequestInfo)requestInfo;
			via = tencentRequestInfo.getVia();
			if(isForH5 || StringUtil.isEmpty(tencentRequestInfo.getPf())){
				tencentRequestInfo.setPf(Constant.PLATFORM_NAME);
			}
			tencentRequestInfo.setOpenid(realPlatformId);
		}
	}

	public RequestInfo getRequestInfo() {
		return requestInfo;
	}

	public String getOpenid() {
		return openid;
	}
	
	public String getRealPlatformId() {
		return realPlatformId;
	}
	
	public int getZoneId(){
		return User.getZoneId(openid);
	}

	public String getVia() {
		return via;
	}
	
	public String getPf(){
		if(requestInfo instanceof TencentRequestInfo){
			return ((TencentRequestInfo)requestInfo).getPf();
		}
		return Constant.PLATFORM_NAME;
	}
	
	public String getToken(){
		Map<String,Object> map = JSONUtils.fromJSON(requestInfoStr, Map.class);
		token = map.get("token").toString();
		return token;
	}
}
