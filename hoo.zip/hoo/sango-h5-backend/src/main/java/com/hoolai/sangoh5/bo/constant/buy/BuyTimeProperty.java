package com.hoolai.sangoh5.bo.constant.buy;

import java.util.List;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class BuyTimeProperty extends JsonProperty {

    private List<Integer> buyTimes;

    private int buyTimesCost;

    public List<Integer> getBuyTimes() {
        return buyTimes;
    }

    public void setBuyTimes(List<Integer> buyTimes) {
        this.buyTimes = buyTimes;
    }

    public int getBuyTimesCost() {
        return buyTimesCost;
    }

    public void setBuyTimesCost(int buyTimesCost) {
        this.buyTimesCost = buyTimesCost;
    }

}
