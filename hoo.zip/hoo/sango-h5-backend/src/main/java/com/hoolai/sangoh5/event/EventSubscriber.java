package com.hoolai.sangoh5.event;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 17:29
 * @version : 1.0
 */
public interface EventSubscriber<T extends Event> {

    public void onEvent(T event);

}
