package com.hoolai.sangoh5.bo.battle.skill.passive;

import java.util.Map;
import java.util.Set;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.CaptainshipBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class Skill32 extends AttributeEnhanceSkill {

	/*
	 * 对方每死亡一个单位，则增加N%的攻击力。对方单位死亡时给予50%于你杀死这个单位时给予的生命恢复   
	 */
	
	@Override
	public void apply(FightUnit actor, TargetCollection tc) {
//		boolean isAttacker = actor.isAttacker();
//		
//		FightUnit offcier = tc.get(FightUnitName.officerUnitName(!isAttacker));
//		Buff obuff = new CaptainshipBuff(xmlId, offcier.name(),actor,this,Effect.MONITORING_BUFF_LEVEL).withKeepBuff().withRepeatCount(MaxRepeatCount)
//				.withActorName(actor.name()).withTargetName(offcier.name());
//		offcier.addAfterBuff(obuff);
//		
//		Map<FightUnitName, FightUnit> aliveMap = tc.aliveTargetSoldier(isAttacker);
//		Set<FightUnitName> keySet = aliveMap.keySet();
//		for(FightUnitName name:keySet){
//			FightUnit target = aliveMap.get(name);
//			
//			Buff sbuff = new CaptainshipBuff(xmlId, target.name(),actor,this,Effect.MONITORING_BUFF_LEVEL).withKeepBuff().withRepeatCount(MaxRepeatCount)
//					.withActorName(actor.name()).withTargetName(target.name());
//			target.addAfterBuff(sbuff);
//		}
	}

	@Override
	public Skill clone() {
		return super.clone(new Skill32());
	}

}
