package com.hoolai.sangoh5.bo.barrack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.BarrackProtocolBuffer.BarrackProto;
import com.hoolai.sangoh5.bo.barrack.TrainingState.SpeedUpItemType;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.bo.item.data.ItemData;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.soldier.data.SoldierData;
import com.hoolai.sangoh5.bo.soldier.data.SoldierProperty;
import com.hoolai.sangoh5.bo.user.data.UserData;
import com.hoolai.sangoh5.repo.BarrackRepo;
import com.hoolai.sangoh5.service.BusinessDomainService;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Barrack implements ProtobufSerializable<BarrackProto> {

    private int soldierNum;

    private List<Integer> openFootmanIds = new ArrayList<Integer>();

    private List<Integer> openRiderIds = new ArrayList<Integer>();

    private List<Integer> openSpearmanIds = new ArrayList<Integer>();

    private List<Integer> openArcherIds = new ArrayList<Integer>();

    private List<Integer> openCrossbowmanIds = new ArrayList<Integer>();

    private List<Integer> openVehiclemanIds = new ArrayList<Integer>();

    private TrainingState trainingState;

    private int[] footmanSkills;

    private int[] riderSkills;

    private int[] spearmanSkills;

    private int[] archerSkills;

    private int[] crossbowmanSkills;

    private int[] vehiclemanSkills;

    transient private int currFootmanId = 0;

    transient private int currRiderId = 0;

    transient private int currSpearmanId = 0;

    transient private int currArcherId = 0;

    transient private int currCrossbowmanId = 0;

    transient private int currVehiclemanId = 0;

    transient private BarrackRepo barrackRepo;

    transient private SoldierData soldierData;

    transient private long userId;

    transient private ConstantsPoolData constantsPool;

    transient private ItemData itemData;

    transient private UserData userData;

    transient private BusinessDomainService businessDomainService;

    public Barrack() {
        this.openFootmanIds = SoldierData.openFootmanIds;
        this.openRiderIds = SoldierData.openRiderIds;
        this.openSpearmanIds = SoldierData.openSpearmanIds;
        this.openArcherIds = SoldierData.openArcherIds;
        this.openCrossbowmanIds = SoldierData.openCrossbowmanIds;
        this.openVehiclemanIds = SoldierData.openVehiclemanIds;
    }

    public boolean init() {
        this.currFootmanId = openFootmanIds.get(openFootmanIds.size() - 1);
        this.currArcherId = openArcherIds.get(openArcherIds.size() - 1);
        this.currCrossbowmanId = openCrossbowmanIds.get(openCrossbowmanIds.size() - 1);
        this.currRiderId = openRiderIds.get(openRiderIds.size() - 1);
        this.currSpearmanId = openSpearmanIds.get(openSpearmanIds.size() - 1);
        this.currVehiclemanId = openVehiclemanIds.get(openVehiclemanIds.size() - 1);

        return initSkills();
    }

    private boolean initSkills() {
        boolean isChange = false;
        if (isChange = footmanSkills == null) {
            SoldierProperty soldierProperty = soldierData.getProperty(currFootmanId);
            footmanSkills = new int[] { soldierProperty.getBornSkill() };
        }

        if (archerSkills == null) {
            SoldierProperty soldierProperty = soldierData.getProperty(currArcherId);
            archerSkills = new int[] { soldierProperty.getBornSkill() };
        }

        if (crossbowmanSkills == null) {
            SoldierProperty soldierProperty = soldierData.getProperty(currCrossbowmanId);
            crossbowmanSkills = new int[] { soldierProperty.getBornSkill() };
        }

        if (riderSkills == null) {
            SoldierProperty soldierProperty = soldierData.getProperty(currRiderId);
            riderSkills = new int[] { soldierProperty.getBornSkill() };
        }

        if (spearmanSkills == null) {
            SoldierProperty soldierProperty = soldierData.getProperty(currSpearmanId);
            spearmanSkills = new int[] { soldierProperty.getBornSkill() };
        }

        if (vehiclemanSkills == null) {
            SoldierProperty soldierProperty = soldierData.getProperty(currVehiclemanId);
            vehiclemanSkills = new int[] { soldierProperty.getBornSkill() };
        }

        return isChange;
    }

    public Barrack(long userId, byte[] bytes) {
        this.userId = userId;
        parseFrom(bytes);
    }

    /**
     * 训练士兵
     * 
     * @param num
     * @param militaryRank TODO
     * @return
     */
    public TrainingState training(long userId, int num, int militaryRank, int userLevel) {
        checkCanTraining(num);
        this.trainingState = new TrainingState(userId, num, constantsPool, userData, userLevel, businessDomainService);
        this.soldierNum += num;
        return trainingState;
    }

    /**
     * 加速训练
     * 
     * @return
     */
    public TrainingState accelerate(int xmlId) {
        checkCanAccelerate();
        this.trainingState.speedUp(SpeedUpItemType.getType(xmlId), itemData);
        this.reflush();
        return trainingState;
    }

    /**
     * 刷新训练状态 如果有士兵训练完，删掉此记录，将训练好的士兵数量累加到兵营数量中
     *
     * @return 返回完成的训练状态对象
     */
    public Barrack reflushBarrack() {
        // 是否有改变
        if (init() || reflush()) {
            barrackRepo.saveBarrack(this);
        }
        return this;
    }

    public int nextSoldier(SoldierType soldierType) {
        int nextSoldierNum = 0;
        switch (soldierType) {
            case footman:
                nextSoldierNum = soldierData.nextSoldier(currFootmanId);
                break;
            case rider:
                nextSoldierNum = soldierData.nextSoldier(currRiderId);
                break;
            case spearman:
                nextSoldierNum = soldierData.nextSoldier(currSpearmanId);
                break;
            case archer:
                nextSoldierNum = soldierData.nextSoldier(currArcherId);
                break;
            case crossbowman:
                nextSoldierNum = soldierData.nextSoldier(currCrossbowmanId);
                break;
            case vehicleman:
                nextSoldierNum = soldierData.nextSoldier(currVehiclemanId);
                break;
        }
        return nextSoldierNum;
    }

    public List<Integer> currOpenSoldierIds(SoldierType soldierType) {
        switch (soldierType) {
            case footman:
                return openFootmanIds;
            case rider:
                return openRiderIds;
            case spearman:
                return openSpearmanIds;
            case archer:
                return openArcherIds;
            case crossbowman:
                return openCrossbowmanIds;
            case vehicleman:
                return openVehiclemanIds;
            default:
                throw new BusinessException(ErrorCode.NO_SOLDIER);
        }
    }

    /**
     * 开启下一阶段的士兵
     * 
     * @param soldierType
     */
    public void openSoldier(SoldierType soldierType, int soliderId) {
        switch (soldierType) {
            case footman:
                this.openFootmanIds.add(soliderId);
                break;
            case rider:
                this.openRiderIds.add(soliderId);
                break;
            case spearman:
                this.openSpearmanIds.add(soliderId);
                break;
            case archer:
                this.openArcherIds.add(soliderId);
                break;
            case crossbowman:
                this.openCrossbowmanIds.add(soliderId);
                break;
            case vehicleman:
                this.openVehiclemanIds.add(soliderId);
                break;
        }
    }

    private void reflushTraningState(TrainingState trainingState) {
        //        addSoldier(trainingState.getTrainingNum());
        this.trainingState = null;
    }

    public void addSoldier(int trainingNum) {
        this.soldierNum += trainingNum;
    }

    public boolean reflush() {
        if (trainingState != null && trainingState.isFinished()) {
            reflushTraningState(trainingState);
            return true;
        } else {
            return false;
        }
    }

    private void checkCanAccelerate() {
        if (trainingState == null || trainingState.isFinished()) {
            throw new BusinessException(ErrorCode.CAN_NOT_TRAINING);
        }
    }

    private void checkCanTraining(int num) {
        if (num <= 0 || (trainingState != null && !trainingState.isFinished())) {
            throw new BusinessException(ErrorCode.CAN_NOT_TRAINING);
        }
    }

    public void levelUpSoldierSkills(SoldierType soldierType, int skillId) {
        switch (soldierType) {
            case footman:
                this.footmanSkills[0] = skillId;
                break;
            case rider:
                this.riderSkills[0] = skillId;
                break;
            case spearman:
                this.spearmanSkills[0] = skillId;
                break;
            case archer:
                this.archerSkills[0] = skillId;
                break;
            case crossbowman:
                this.crossbowmanSkills[0] = skillId;
                break;
            case vehicleman:
                this.vehiclemanSkills[0] = skillId;
                break;
        }
    }

    public void addSoldierSkills(SoldierType soldierType, int skillId) {
        switch (soldierType) {
            case footman:
                footmanSkills = ArrayUtils.add(footmanSkills, skillId);
                break;
            case rider:
                riderSkills = ArrayUtils.add(riderSkills, skillId);
                break;
            case spearman:
                spearmanSkills = ArrayUtils.add(spearmanSkills, skillId);
                break;
            case archer:
                archerSkills = ArrayUtils.add(archerSkills, skillId);
                break;
            case crossbowman:
                crossbowmanSkills = ArrayUtils.add(crossbowmanSkills, skillId);
                break;
            case vehicleman:
                vehiclemanSkills = ArrayUtils.add(vehiclemanSkills, skillId);
                break;
        }
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public void setBarrackRepo(BarrackRepo barrackRepo) {
        this.barrackRepo = barrackRepo;
    }

    public int getSoldierNum() {
        return soldierNum;
    }

    public void setSoldierNum(int soldierNum) {
        this.soldierNum = soldierNum;
    }

    public int getCurrFootmanId() {
        return currFootmanId;
    }

    public void setCurrFootmanId(int currFootmanId) {
        this.currFootmanId = currFootmanId;
    }

    public int getCurrRiderId() {
        return currRiderId;
    }

    public void setCurrRiderId(int currRiderId) {
        this.currRiderId = currRiderId;
    }

    public int getCurrSpearmanId() {
        return currSpearmanId;
    }

    public void setCurrSpearmanId(int currSpearmanId) {
        this.currSpearmanId = currSpearmanId;
    }

    public int getCurrArcherId() {
        return currArcherId;
    }

    public void setCurrArcherId(int currArcherId) {
        this.currArcherId = currArcherId;
    }

    public int getCurrCrossbowmanId() {
        return currCrossbowmanId;
    }

    public void setCurrCrossbowmanId(int currCrossbowmanId) {
        this.currCrossbowmanId = currCrossbowmanId;
    }

    public int getCurrVehiclemanId() {
        return currVehiclemanId;
    }

    public void setCurrVehiclemanId(int currVehiclemanId) {
        this.currVehiclemanId = currVehiclemanId;
    }

    public TrainingState getTrainingState() {
        return trainingState;
    }

    public void setTrainingState(TrainingState trainingState) {
        this.trainingState = trainingState;
    }

    public int[] getFootmanSkills() {
        return footmanSkills;
    }

    public int[] getRiderSkills() {
        return riderSkills;
    }

    public int[] getSpearmanSkills() {
        return spearmanSkills;
    }

    public int[] getArcherSkills() {
        return archerSkills;
    }

    public int[] getCrossbowmanSkills() {
        return crossbowmanSkills;
    }

    public int[] getVehiclemanSkills() {
        return vehiclemanSkills;
    }

    @Override
    public BarrackProto copyTo() {
        BarrackProto.Builder builder = BarrackProto.newBuilder();
        builder.setSoldierNum(soldierNum);
        if (openFootmanIds.size() > 0) {
            Collections.sort(openFootmanIds);
            for (int id : openFootmanIds) {
                builder.addOpenFootmanIds(id);
            }
        }
        if (openRiderIds.size() > 0) {
            Collections.sort(openRiderIds);
            for (int id : openRiderIds) {
                builder.addOpenRiderIds(id);
            }
        }
        if (openSpearmanIds.size() > 0) {
            Collections.sort(openSpearmanIds);
            for (int id : openSpearmanIds) {
                builder.addOpenSpearmanIds(id);
            }
        }
        if (openArcherIds.size() > 0) {
            Collections.sort(openArcherIds);
            for (int id : openArcherIds) {
                builder.addOpenArcherIds(id);
            }
        }
        if (openCrossbowmanIds.size() > 0) {
            Collections.sort(openCrossbowmanIds);
            for (int id : openCrossbowmanIds) {
                builder.addOpenCrossbowmanIds(id);
            }
        }
        if (openVehiclemanIds.size() > 0) {
            Collections.sort(openVehiclemanIds);
            for (int id : openVehiclemanIds) {
                builder.addOpenVehiclemanIds(id);
            }
        }

        if (footmanSkills != null) {
            for (int i = 0; i < footmanSkills.length; i++) {
                builder.addFootmanSkills(footmanSkills[i]);
            }
        }

        if (riderSkills != null) {
            for (int i = 0; i < riderSkills.length; i++) {
                builder.addRiderSkills(riderSkills[i]);
            }
        }

        if (spearmanSkills != null) {
            for (int i = 0; i < spearmanSkills.length; i++) {
                builder.addSpearmanSkills(spearmanSkills[i]);
            }
        }

        if (archerSkills != null) {
            for (int i = 0; i < archerSkills.length; i++) {
                builder.addArcherSkills(archerSkills[i]);
            }
        }

        if (crossbowmanSkills != null) {
            for (int i = 0; i < crossbowmanSkills.length; i++) {
                builder.addCrossbowmanSkills(crossbowmanSkills[i]);
            }
        }

        if (vehiclemanSkills != null) {
            for (int i = 0; i < vehiclemanSkills.length; i++) {
                builder.addVehiclemanSkills(vehiclemanSkills[i]);
            }
        }

        if (trainingState == null) {
            builder.clearTrainingState();
        } else {
            builder.setTrainingState(trainingState.copyTo());
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            BarrackProto message = BarrackProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(BarrackProto message) {
        this.soldierNum = message.getSoldierNum();
        int openFootCount = message.getOpenFootmanIdsCount();
        for (int i = 0; i < openFootCount; i++) {
            openFootmanIds.add(message.getOpenFootmanIds(i));
        }
        int openRiderCount = message.getOpenRiderIdsCount();
        for (int i = 0; i < openRiderCount; i++) {
            openRiderIds.add(message.getOpenRiderIds(i));
        }
        int openSpearmanCount = message.getOpenSpearmanIdsCount();
        for (int i = 0; i < openSpearmanCount; i++) {
            openSpearmanIds.add(message.getOpenSpearmanIds(i));
        }
        int openArcherCount = message.getOpenArcherIdsCount();
        for (int i = 0; i < openArcherCount; i++) {
            openArcherIds.add(message.getOpenArcherIds(i));
        }
        int openCrossbowman = message.getOpenCrossbowmanIdsCount();
        for (int i = 0; i < openCrossbowman; i++) {
            openCrossbowmanIds.add(message.getOpenCrossbowmanIds(i));
        }
        int openVehiclemanCount = message.getOpenVehiclemanIdsCount();
        for (int i = 0; i < openVehiclemanCount; i++) {
            openVehiclemanIds.add(message.getOpenVehiclemanIds(i));
        }

        int skillCount = message.getFootmanSkillsCount();
        if (skillCount > 0) {
            footmanSkills = new int[skillCount];
            for (int i = 0; i < skillCount; i++) {
                footmanSkills[i] = message.getFootmanSkills(i);
            }
        }

        skillCount = message.getArcherSkillsCount();
        if (skillCount > 0) {
            archerSkills = new int[skillCount];
            for (int i = 0; i < skillCount; i++) {
                archerSkills[i] = message.getArcherSkills(i);
            }
        }

        skillCount = message.getCrossbowmanSkillsCount();
        if (skillCount > 0) {
            crossbowmanSkills = new int[skillCount];
            for (int i = 0; i < skillCount; i++) {
                crossbowmanSkills[i] = message.getCrossbowmanSkills(i);
            }
        }

        skillCount = message.getSpearmanSkillsCount();
        if (skillCount > 0) {
            spearmanSkills = new int[skillCount];
            for (int i = 0; i < skillCount; i++) {
                spearmanSkills[i] = message.getSpearmanSkills(i);
            }
        }

        skillCount = message.getRiderSkillsCount();
        if (skillCount > 0) {
            riderSkills = new int[skillCount];
            for (int i = 0; i < skillCount; i++) {
                riderSkills[i] = message.getRiderSkills(i);
            }
        }

        skillCount = message.getVehiclemanSkillsCount();
        if (skillCount > 0) {
            vehiclemanSkills = new int[skillCount];
            for (int i = 0; i < skillCount; i++) {
                vehiclemanSkills[i] = message.getVehiclemanSkills(i);
            }
        }

        if (message.hasTrainingState()) {
            this.trainingState = new TrainingState(message.getTrainingState());
        }
    }

    public void checkAndTroops(int soldierNum) {
        if (!isCanTroops(soldierNum)) {
            throw new BusinessException(ErrorCode.SOLDIER_NO_ENOUGH);
        }
        troops(soldierNum);
    }

    public void troops(int soldierNum) {
        this.soldierNum -= soldierNum;
    }

    public boolean isCanTroops(int soldierNum) {
        if (this.soldierNum < soldierNum) {
            return false;
        }
        return true;
    }

    public void setSoldierData(SoldierData soldierData) {
        this.soldierData = soldierData;
    }

    public void setConstantsPool(ConstantsPoolData constantsPool) {
        this.constantsPool = constantsPool;
    }

    public void setUserData(UserData userData) {
        this.userData = userData;
    }

    public void setItemData(ItemData itemData) {
        this.itemData = itemData;
    }

    public List<Integer> getOpenFootmanIds() {
        return openFootmanIds;
    }

    public void setOpenFootmanIds(List<Integer> openFootmanIds) {
        this.openFootmanIds = openFootmanIds;
    }

    public List<Integer> getOpenRiderIds() {
        return openRiderIds;
    }

    public void setOpenRiderIds(List<Integer> openRiderIds) {
        this.openRiderIds = openRiderIds;
    }

    public List<Integer> getOpenSpearmanIds() {
        return openSpearmanIds;
    }

    public void setOpenSpearmanIds(List<Integer> openSpearmanIds) {
        this.openSpearmanIds = openSpearmanIds;
    }

    public List<Integer> getOpenArcherIds() {
        return openArcherIds;
    }

    public void setOpenArcherIds(List<Integer> openArcherIds) {
        this.openArcherIds = openArcherIds;
    }

    public List<Integer> getOpenCrossbowmanIds() {
        return openCrossbowmanIds;
    }

    public void setOpenCrossbowmanIds(List<Integer> openCrossbowmanIds) {
        this.openCrossbowmanIds = openCrossbowmanIds;
    }

    public List<Integer> getOpenVehiclemanIds() {
        return openVehiclemanIds;
    }

    public void setOpenVehiclemanIds(List<Integer> openVehiclemanIds) {
        this.openVehiclemanIds = openVehiclemanIds;
    }

    public void setBusinessDomainService(BusinessDomainService businessDomainService) {
        this.businessDomainService = businessDomainService;
    }

    public void setFootmanSkills(int[] footmanSkills) {
        this.footmanSkills = footmanSkills;
    }

    public void setRiderSkills(int[] riderSkills) {
        this.riderSkills = riderSkills;
    }

    public void setSpearmanSkills(int[] spearmanSkills) {
        this.spearmanSkills = spearmanSkills;
    }

    public void setArcherSkills(int[] archerSkills) {
        this.archerSkills = archerSkills;
    }

    public void setCrossbowmanSkills(int[] crossbowmanSkills) {
        this.crossbowmanSkills = crossbowmanSkills;
    }

    public void setVehiclemanSkills(int[] vehiclemanSkills) {
        this.vehiclemanSkills = vehiclemanSkills;
    }

}
