package com.hoolai.sangoh5.bo.officerunion;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.OfficerUnionsProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class OfficerUnions implements ProtobufSerializable<OfficerUnionsProto> {

    private long userId;

    private List<OfficerUnion> officerUnions = new ArrayList<OfficerUnion>();

    public OfficerUnions() {
    }

    public OfficerUnions(long userId) {
        this.userId = userId;
    }

    public OfficerUnions(byte[] bytes) {
        parseFrom(bytes);
    }

    @Override
    public OfficerUnionsProto copyTo() {
        OfficerUnionsProto.Builder builder = OfficerUnionsProto.newBuilder();
        builder.setUserId(userId);
        for (OfficerUnion officerUnion : officerUnions) {
            builder.addOfficerUnions(officerUnion.copyTo());
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            OfficerUnionsProto message = OfficerUnionsProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(OfficerUnionsProto message) {
        this.userId = message.getUserId();

        int count = message.getOfficerUnionsCount();
        for (int i = 0; i < count; i++) {
            this.officerUnions.add(new OfficerUnion(message.getOfficerUnions(i)));
        }
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public List<OfficerUnion> getOfficerUnions() {
        return officerUnions;
    }

    public void setOfficerUnions(List<OfficerUnion> officerUnions) {
        this.officerUnions = officerUnions;
    }

    public OfficerUnion findOfficerUnion(int unionId) {
        for (OfficerUnion officerUnion : officerUnions) {
            if (officerUnion.getUnionId() == unionId) {
                return officerUnion;
            }
        }
        return null;
    }

    public void addOfficerUnion(OfficerUnion officerUnion) {
        if (findOfficerUnion(officerUnion.getUnionId()) == null) {
            this.officerUnions.add(officerUnion);
        }
    }

    public boolean collect(OfficerUnion officerUnion, int xmlId, int starLv) {
        if(officerUnion != null){
            return officerUnion.collect(xmlId,starLv);
        }
        return false;
    }
}
