package com.hoolai.sangoh5.bo.battle.unit;

import java.util.Collection;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import com.hoolai.sango.util.IntHashMap;

/**
 * 战斗单元集合（包括全部战斗单元map），
 */
public class TargetCollection {

    private final Map<FightUnitName, FightUnit> unitMap; //全部战斗单元

    private final Map<FightUnitName, FightUnit> aliveUnitMap; //存活的战斗单元

    private final Map<FightUnitName, FightUnit> deadUnitMap; //死亡的战斗单元

    public TargetCollection(EnumMap<FightUnitName, FightUnit> unitMap) {
        this.unitMap = unitMap;
        this.aliveUnitMap = new EnumMap<FightUnitName, FightUnit>(FightUnitName.class);
        this.deadUnitMap = new EnumMap<FightUnitName, FightUnit>(FightUnitName.class);
    }

    public void removeUnit(FightUnit unit) {
        aliveUnitMap.remove(unit.name());
        deadUnitMap.put(unit.name(), unit);
    }

    public void addUnit(FightUnit unit) {
        aliveUnitMap.put(unit.name(), unit);
    }

    public Map<FightUnitName, FightUnit> getAliveUnitMap() {
        return aliveUnitMap;
    }

    public Map<FightUnitName, FightUnit> getUnitMap() {
        return unitMap;
    }

    public Map<FightUnitName, FightUnit> getDeadUnitMap() {
        return deadUnitMap;
    }

    public FightUnit getAlive(FightUnitName name) {
        return aliveUnitMap.get(name);
    }

    public FightUnit get(FightUnitName name) {
        return this.unitMap.get(name);
    }

    public Collection<FightUnit> aliveValues() {
        return aliveUnitMap.values();
    }

    public Map<FightUnitName, FightUnit> aliveUnitMap() {
        Map<FightUnitName, FightUnit> map = new HashMap<FightUnitName, FightUnit>();
        for (FightUnitName name : aliveUnitMap.keySet()) {
            map.put(name, aliveUnitMap.get(name));
        }
        return map;
    }

    public Collection<FightUnit> deadValues() {
        return deadUnitMap.values();
    }

    /**
     * 返回与isAttacker相对立的活着的单元
     * 
     * @param isAttacker
     * @return
     */
    public int aliveTargetSoldierCount(boolean isAttacker) {
        return targetSoldierCount(isAttacker, true);
    }

    public int targetSoldierCount(boolean isAttacker, boolean isAlive) {
        int count = 0;
        for (FightUnitName name : (isAlive ? aliveUnitMap.keySet() : deadUnitMap.keySet())) {
            if (name.info().isAttacker() != isAttacker && name.info().isSoldier()) {
                count++;
            }
        }
        return count;
    }

    public Map<FightUnitName, FightUnit> aliveTargetSoldier(boolean isAttacker) {
        return targetSoldier(isAttacker, true);
    }

    public IntHashMap<FightUnit> aliveTargetSoldierPos(boolean isAttacker) {
        Map<FightUnitName, FightUnit> names = targetSoldier(isAttacker, true);
        IntHashMap<FightUnit> fs = new IntHashMap<FightUnit>();
        for (FightUnitName name : names.keySet()) {
            FightUnit unit = names.get(name);
            fs.put(unit.getInitPos(), unit);
        }
        return fs;
    }

    /**
     * 目前场上所有活着的士兵
     * 
     * @return
     */
    public Map<FightUnitName, FightUnit> aliveSoldier() {
        Map<FightUnitName, FightUnit> fightUnitNames = new HashMap<FightUnitName, FightUnit>();
        for (FightUnitName name : aliveUnitMap.keySet()) {
            if (name.info().isSoldier()) {
                fightUnitNames.put(name, this.get(name));
            }
        }
        return fightUnitNames;
    }

    public Map<FightUnitName, FightUnit> targetSoldier(boolean isAttacker, boolean isAlive) {
        Map<FightUnitName, FightUnit> fightUnitNames = new HashMap<FightUnitName, FightUnit>();
        for (FightUnitName name : (isAlive ? aliveUnitMap.keySet() : deadUnitMap.keySet())) {
            if (name.info().isAttacker() != isAttacker && name.info().isSoldier()) {
                fightUnitNames.put(name, this.get(name));
            }
        }
        return fightUnitNames;
    }

    public Map<FightUnitName, FightUnit> aliveTargetUnit(boolean isAttacker) {
        return targetUnit(isAttacker, true);
    }

    public Map<FightUnitName, FightUnit> targetUnit(boolean isAttacker, boolean isAlive) {
        Map<FightUnitName, FightUnit> fightUnitNames = new HashMap<FightUnitName, FightUnit>();
        for (FightUnitName name : (isAlive ? aliveUnitMap.keySet() : deadUnitMap.keySet())) {
            if (name.info().isAttacker() != isAttacker && name.info().isSoldier()) {
                fightUnitNames.put(name, this.get(name));
            }
        }
        FightUnit officer = aliveUnitMap.get(isAttacker ? FightUnitName.def_officer : FightUnitName.att_officer);
        if (officer != null) {
            fightUnitNames.put(officer.name(), officer);
        }
        return fightUnitNames;
    }

    //对方的将领单元是否下马
    public boolean isTargetOfficerDie(boolean isAttacker) {
        return (isAttacker ? get(FightUnitName.def_officer) : get(FightUnitName.att_officer)).isDead();
    }

}
