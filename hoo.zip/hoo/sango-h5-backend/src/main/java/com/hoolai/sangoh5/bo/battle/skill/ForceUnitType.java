package com.hoolai.sangoh5.bo.battle.skill;

/** 将领, 所有士兵, 随机一种士兵, 步, 骑, 弓, 特 */
public enum ForceUnitType {

    OFFICER, // 将领 
    SOLDIERS, // 所有士兵
    SOLDIER, RANDOM_ONE, // 随机一个对象
    FOOTMAN, // 步兵
    RIDER, // 骑兵
    SPEARMAN, // 矛兵 
    ARCHER, // 弓箭兵
    CROSSBOWMAN, // 弩兵 
    VEHICLEMAN, // 车兵
    OFFICER_SOLDIERS, // 将领与所有士兵
    TARGET, // 正在攻击的目标
    CLOSE_COMBAT, // 近战
    LONG_RANGE, // 远战
    SELF // 自己
    ;

}
