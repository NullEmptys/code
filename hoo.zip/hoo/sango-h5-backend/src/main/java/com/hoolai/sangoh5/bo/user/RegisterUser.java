package com.hoolai.sangoh5.bo.user;

public class RegisterUser {

    private long id;

    private String platformId;

    private String name;

    private String password;

    private String idCard;

    private String realName;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public RegisterUser(String platformId, String name, String password, String idCard, String realName) {
        super();
        this.platformId = platformId;
        this.name = name;
        this.password = password;
        this.idCard = idCard;
        this.realName = realName;
    }

    public RegisterUser(String platformId, String name, String password) {
        this(platformId, name, password, "", "");
    }

    public RegisterUser() {
    }

}
