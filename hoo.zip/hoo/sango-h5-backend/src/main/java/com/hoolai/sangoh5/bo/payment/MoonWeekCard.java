package com.hoolai.sangoh5.bo.payment;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.DateUtil;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.MoonWeekCardProto;
import com.hoolai.sangoh5.bo.payment.data.MoonWeekCardData;
import com.hoolai.sangoh5.bo.payment.data.MoonWeekProperty;
import com.hoolai.sangoh5.bo.payment.data.RechargeHallProperty.RechargeType;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 周卡、月卡
 * 
 * @author Administrator
 *
 */
public class MoonWeekCard implements ProtobufSerializable<MoonWeekCardProto> {

    private static final long week_time = 7l * 24l * 60l * 60l * 1000l;

    private static final long moon_time = 30l * 24l * 60l * 60l * 1000l;

    // 购买周卡的次数
    private int weekCardTimes;

    // 购买月卡的次数
    private int moonCarsTimes;

    // 周卡有效结束时间
    private long weekCardEndTime;

    // 月卡有效结束时间
    private long moonCardEndTime;

    // 获得周卡每日奖励的日期
    private int giveWeekCardGiftDay;

    // 获得月卡每日奖励的日期
    private int giveMoonCardGiftDay;

    transient private long userId;

    public MoonWeekCard(long userId) {
        this.userId = userId;
    }

    public MoonWeekCard(long userId, byte[] bytes) {
        this(userId);
        parseFrom(bytes);
    }

    public void buyWeekCard() {
        long currTime = TimeUtil.currentTimeMillis();
        if (currTime > weekCardEndTime) {
            weekCardEndTime = currTime + week_time;
        } else {
            weekCardEndTime = weekCardEndTime + week_time;
        }
        weekCardTimes += 1;
    }

    public void buyMoonCard() {
        long currTime = TimeUtil.currentTimeMillis();
        if (currTime > moonCardEndTime) {
            moonCardEndTime = currTime + moon_time;
        } else {
            moonCardEndTime = moonCardEndTime + moon_time;
        }
        moonCarsTimes += 1;
    }

    public void checkAndGiveWeekCardGift() {
        if (!isInWeekCardTime()) {
            throw new BusinessException(ErrorCode.WEEK_CARD_INVALID);
        }

        if (isGivedWeekCardGift()) {
            throw new BusinessException(ErrorCode.GIVED_WEEK_CARD);
        }
        giveWeekCardGiftDay = DateUtil.getTodayIntValue();
    }

    public void checkAndGiveMoonCardGift() {
        if (!isInMoonCardTime()) {
            throw new BusinessException(ErrorCode.MOON_CARD_INVALID);
        }

        if (isGivedMoonCardGift()) {
            throw new BusinessException(ErrorCode.GIVED_MOON_CARD);
        }
        giveMoonCardGiftDay = DateUtil.getTodayIntValue();
    }

    private boolean isGivedWeekCardGift() {
        int day = DateUtil.getTodayIntValue();
        if (day <= giveWeekCardGiftDay) {
            return true;
        }
        return false;
    }

    private boolean isGivedMoonCardGift() {
        int day = DateUtil.getTodayIntValue();
        if (day <= giveMoonCardGiftDay) {
            return true;
        }
        return false;
    }

    private boolean isInMoonCardTime() {
        return getLeftMoonCardEndTime() > 0;
    }

    private boolean isInWeekCardTime() {
        return getLeftWeekCardEndTime() > 0;
    }

    /**
     * 是否领取周卡每日奖励
     * 
     * @return
     */
    public boolean getIsCanGiveWeekCardGift() {
        return isInWeekCardTime() && !isGivedWeekCardGift();
    }

    /**
     * 是否领取了周卡每日奖励
     * 
     * @return
     */
    public boolean getIsCanGiveMoonCardGift() {
        return isInMoonCardTime() && !isGivedMoonCardGift();
    }

    public int getWeekCardTimes() {
        return weekCardTimes;
    }

    public int getMoonCarsTimes() {
        return moonCarsTimes;
    }

    /**
     * 周卡剩余有效时间
     * 
     * @return
     */
    public long getLeftWeekCardEndTime() {
        long currTime = TimeUtil.currentTimeMillis();
        long left = weekCardEndTime - currTime;
        if (left < 0) {
            left = 0;
        }
        return left;
    }

    /**
     * 月卡剩余有效
     * 
     * @return
     */
    public long getLeftMoonCardEndTime() {
        long currTime = TimeUtil.currentTimeMillis();
        long left = moonCardEndTime - currTime;
        if (left < 0) {
            left = 0;
        }
        return left;
    }

    public long getUserId() {
        return userId;
    }

    @Override
    public MoonWeekCardProto copyTo() {
        MoonWeekCardProto.Builder builder = MoonWeekCardProto.newBuilder();
        builder.setGiveMoonCardGiftDay(giveMoonCardGiftDay);
        builder.setGiveWeekCardGiftDay(giveWeekCardGiftDay);
        builder.setMoonCardEndTime(moonCardEndTime);
        builder.setMoonCarsTimes(moonCarsTimes);
        builder.setWeekCardEndTime(weekCardEndTime);
        builder.setWeekCardTimes(weekCardTimes);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            MoonWeekCardProto message = MoonWeekCardProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(MoonWeekCardProto message) {
        this.giveMoonCardGiftDay = message.getGiveMoonCardGiftDay();
        this.giveWeekCardGiftDay = message.getGiveWeekCardGiftDay();
        this.moonCardEndTime = message.getMoonCardEndTime();
        this.moonCarsTimes = message.getMoonCarsTimes();
        this.weekCardEndTime = message.getWeekCardEndTime();
        this.weekCardTimes = message.getWeekCardTimes();
    }

    public int provisionNum(MoonWeekCardData moonWeekCardData) {
        int limit = 0;
        if (isInMoonCardTime()) {
            MoonWeekProperty property = moonWeekCardData.getMoonCardProperty(RechargeType.MOON_CARD.getType());
            limit += property.getValue1();
        }
        if (isInWeekCardTime()) {
            MoonWeekProperty property = moonWeekCardData.getMoonCardProperty(RechargeType.WEEK_CARD.getType());
            limit += property.getValue1();
        }
        return limit;
    }

    public int pvpFightNum(MoonWeekCardData moonWeekCardData) {
        int limit = 0;
        if (isInMoonCardTime()) {
            MoonWeekProperty property = moonWeekCardData.getMoonCardProperty(RechargeType.MOON_CARD.getType());
            limit += property.getValue2();
        }
        if (isInWeekCardTime()) {
            MoonWeekProperty property = moonWeekCardData.getMoonCardProperty(RechargeType.WEEK_CARD.getType());
            limit += property.getValue2();
        }
        return limit;
    }

}
