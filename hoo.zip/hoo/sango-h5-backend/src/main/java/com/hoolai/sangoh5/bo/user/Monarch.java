package com.hoolai.sangoh5.bo.user;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.MonarchProto;
import com.hoolai.sangoh5.bo.UserProtocolBuffer.MonarchProto.Builder;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Monarch implements ProtobufSerializable<MonarchProto> {

    /** h5 用户id **/
    private long userId;

    /** pc版 等级 **/
    private int rank;

    /** pc版 昵称 **/
    private String name;

    /** pc版 图片 **/
    private String image;

    /** pc版 zoneId **/
    private transient int zoneId;

    /** pc版 君主id **/
    private transient long monarchId;

    public Monarch(int zoneId, long monarchId, byte[] bytes) {
        super();
        this.zoneId = zoneId;
        this.monarchId = monarchId;
        this.parseFrom(bytes);
    }

    public Monarch(int zoneId, long monarchId, int rank, String name, String image, long userId) {
        this.zoneId = zoneId;
        this.monarchId = monarchId;
        this.rank = rank;
        this.name = name;
        this.image = image;
        this.userId = userId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getZoneId() {
        return zoneId;
    }

    public void setZoneId(int zoneId) {
        this.zoneId = zoneId;
    }

    public long getMonarchId() {
        return monarchId;
    }

    public void setMonarchId(long monarchId) {
        this.monarchId = monarchId;
    }

    @Override
    public MonarchProto copyTo() {
        Builder newBuilder = MonarchProto.newBuilder();
        newBuilder.setUserId(userId);
        newBuilder.setRank(rank);
        newBuilder.setName(name);
        newBuilder.setImage(image);
        return newBuilder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            MonarchProto message = MonarchProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(MonarchProto message) {
        this.userId = message.getUserId();
        this.rank = message.getRank();
        this.name = message.getName();
        this.image = message.getImage();
    }

}
