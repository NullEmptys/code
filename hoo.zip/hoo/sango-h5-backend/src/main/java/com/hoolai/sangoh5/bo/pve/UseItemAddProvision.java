package com.hoolai.sangoh5.bo.pve;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.UseItemAddProvisionProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class UseItemAddProvision implements ProtobufSerializable<UseItemAddProvisionProto> {

    private int itemXmlId;

    private int count;

    public UseItemAddProvision(UseItemAddProvisionProto message) {
        copyFrom(message);
    }

    public UseItemAddProvision() {

    }

    @Override
    public UseItemAddProvisionProto copyTo() {
        UseItemAddProvisionProto.Builder builder = UseItemAddProvisionProto.newBuilder();
        builder.setItemXmlId(itemXmlId);
        builder.setCount(count);
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            UseItemAddProvisionProto message = UseItemAddProvisionProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }

    }

    @Override
    public void copyFrom(UseItemAddProvisionProto message) {
        this.itemXmlId = message.getItemXmlId();
        this.count = message.getCount();
    }

    public int getItemXmlId() {
        return itemXmlId;
    }

    public void setItemXmlId(int itemXmlId) {
        this.itemXmlId = itemXmlId;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

}
