package com.hoolai.sangoh5.bo.rankfight;

import java.util.Calendar;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.ChestProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Chest implements ProtobufSerializable<ChestProto> {

    private long lastDrawTime;//根据此时间来判断   是否可以领

    private long userId;

    private long lastOpenTime;//根据此时间来判断是否刷新奖励

    public void refresh() {

    }

    public Chest(long userId) {
        this.userId = userId;
    }

    public Chest(long userId, byte[] bytes) {
        this.userId = userId;
        parseFrom(bytes);
    }

    public long getLastDrawTime() {
        return lastDrawTime;
    }

    public void setLastDrawTime(long lastDrawTime) {
        this.lastDrawTime = lastDrawTime;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getLastOpenTime() {
        return lastOpenTime;
    }

    public void setLastOpenTime(long lastOpenTime) {
        this.lastOpenTime = lastOpenTime;
    }

    public boolean checkDraw(Chest chest) {
        long lastDrawTime = chest.getLastDrawTime();
        long now = TimeUtil.currentTimeMillis();
        long today21 = getTimeLine(21);
        long yestToday21 = today21 - 86400000;

        if ((now > yestToday21 && now < today21 && lastDrawTime > yestToday21 && lastDrawTime < today21) || (now > today21 && lastDrawTime > today21)) {
            return false;
        }
        return true;
    }

    public boolean checkRefresh(Chest chest) {
        long lastOpenTime = chest.getLastOpenTime();
        long now = TimeUtil.currentTimeMillis();
        long today21 = getTimeLine(21);
        long yestToday21 = today21 - 86400000;

        if ((now > yestToday21 && now < today21 && lastOpenTime > yestToday21 && lastOpenTime < today21) || (now > today21 && lastOpenTime > today21)) {
            return false;
        }
        return true;
    }

    /**
     * 通过今天某一整点获取时间戳
     * 
     * @param hour
     * @return
     */
    private long getTimeLine(int hour) {
        if (hour >= 0 && hour <= 24) {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(TimeUtil.currentTimeMillis());
            c.set(Calendar.HOUR_OF_DAY, hour);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            long timeLine = c.getTime().getTime();
            return timeLine;
        } else {
            return 0;
        }
    }

    @Override
    public void copyFrom(ChestProto message) {
        this.lastDrawTime = message.getLastDrawTime();
        this.lastOpenTime = message.getLastOpenTime();
    }

    @Override
    public ChestProto copyTo() {
        ChestProto.Builder builder = ChestProto.newBuilder();
        builder.setLastDrawTime(lastDrawTime);
        builder.setLastOpenTime(lastOpenTime);
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ChestProto message = ChestProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

}
