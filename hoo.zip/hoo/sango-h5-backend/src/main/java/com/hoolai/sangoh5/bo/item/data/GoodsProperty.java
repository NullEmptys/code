package com.hoolai.sangoh5.bo.item.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class GoodsProperty extends JsonProperty{
	
	private String name;
	
	/** 1代表元宝，2代表金币，3代表功勋 */
	private int[] costType;
	
	private int[] costAmount;
	
	/** 1代表正常出售，2代表暂不出售 */
	private int onSale;
	
	/** 目前分为1-5个品质，数字越大，品质越低 */
	private String description;
	
	private String type;
	
	private int borderColor;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int[] getCostType() {
		return costType;
	}
	public void setCostType(int[] costType) {
		this.costType = costType;
	}
	public int[] getCostAmount() {
		return costAmount;
	}
	public void setCostAmount(int[] costAmount) {
		this.costAmount = costAmount;
	}
	public int getOnSale() {
		return onSale;
	}
	public void setOnSale(int onSale) {
		this.onSale = onSale;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getBorderColor() {
		return borderColor;
	}
	public void setBorderColor(int borderColor) {
		this.borderColor = borderColor;
	}
	
	
}
