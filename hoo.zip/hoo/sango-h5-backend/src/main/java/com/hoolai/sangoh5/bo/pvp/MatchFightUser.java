package com.hoolai.sangoh5.bo.pvp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.compass.core.util.CollectionUtils;

import com.google.common.collect.Lists;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillData;
import com.hoolai.sangoh5.bo.city.MainCity;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.pve.data.MonsterData;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.bo.user.data.BuildingData;
import com.hoolai.sangoh5.repo.PvpRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.util.Constant;
import com.hoolai.sangoh5.util.ProbabilityGenerator;

public class MatchFightUser {

    private final int matchBaseLevel;

    private final Camp matchCamp;

    private final PvpUser owner;

    private final User user;

    private PvpRepo pvpRepo;

    private UserRepo userRepo;

    private BuildingData buildingData;

    private ProbabilityGenerator pg;

    private SkillData skillData;

    transient private User matchUser = null;

    public MatchFightUser(User user, PvpUser pvpUser, int matchBaseLevel, Camp matchCamp) {
        this.matchBaseLevel = matchBaseLevel;
        this.matchCamp = matchCamp;
        this.owner = pvpUser;
        this.user = user;
    }

    public void initRepo(PvpRepo pvpRepo, UserRepo userRepo, BuildingData buildingData, SkillData skillData, ProbabilityGenerator pg) {
        this.buildingData = buildingData;
        this.pg = pg;
        this.pvpRepo = pvpRepo;
        this.userRepo = userRepo;
        this.skillData = skillData;
    }

    public User matchUser() {
        List<Integer> types = Arrays.asList(1, 2, 3);
        Collections.shuffle(types, new Random(TimeUtil.currentTimeMillis()));

        for (int i = 0; i < 3; i++) {
            switch (types.get(i)) {
                case 1:
                    matchOccupyDefenceUser();
                    break;
                case 2:
                    matchOccupyUser();
                    break;
                case 3:
                    matchDesertedUser();
                    break;
            }
            if (matchUser != null) {
                break;
            }
        }

        return matchUser;
    }

    /**
     * 选取对方驻守的玩家
     */
    private void matchOccupyDefenceUser() {
        int matchLevel = matchBaseLevel;
        do {
            matchUser = findCanOccupyDefenceUser(matchLevel);
            matchLevel--;
        } while (matchUser == null && matchLevel >= buildingData.getProperty(3).getOpenLevel() && matchLevel >= (matchBaseLevel - 5));
    }

    /**
     * 被其他势力占领的玩家-5级
     */
    private void matchOccupyUser() {
        int matchLevel = matchBaseLevel;
        do {
            matchUser = findCanOccupyUser(matchLevel);
            matchLevel--;
        } while (matchUser == null && matchLevel >= buildingData.getProperty(3).getOpenLevel() && matchLevel >= (matchBaseLevel - 5));
    }

    /**
     * 空城
     */
    private void matchDesertedUser() {
        int matchLevel = matchBaseLevel;
        do {
            matchUser = findDesertedUser(matchLevel);
            matchLevel--;
        } while (matchUser == null && matchLevel >= buildingData.getProperty(3).getOpenLevel() && matchLevel >= (matchBaseLevel - 5));
    }

    private int randomSangoState() {
        List<Integer> sangoStates = shuffle();
        return sangoStates.get(0);
    }

    private static final String[] names = new String[] { "战三国", "小猪佩奇", "汪汪队", "奥特曼赛斯", "小妖精", "我们的曾经", "等风来", "去他的青春", "我要非得更高" };

    public static User createNpcUser(long userId, int sangoState, ProbabilityGenerator pg, UserRepo userRepo, SkillData skillData) {

        long uId = 0;

        List<Integer> ranks = Arrays.asList(10, 11, 12);
        Collections.shuffle(ranks, new Random(TimeUtil.currentTimeMillis()));

        List<Integer> ranksList = new ArrayList<Integer>(ranks);
        List<Integer> arrayList = Arrays.asList(1, 2, 3);
        ranksList.addAll(arrayList);

        for (int i = 0; i < ranks.size(); i++) {
            List<Long> userIds = userRepo.randomRankUser(ranks.get(i), 1, userId);
            if (userIds.size() > 0) {
                uId = userIds.get(0);
                break;
            }
        }

        User user = null;
        if (uId == 0) {
            user = userRepo.findUser(userId);
            user.setName(names[pg.getRandomNumber(0, names.length - 1)]);
            user.setImage(skillData.ids().get(pg.getRandomNumber(skillData.ids().size() - 1)).toString());
        } else {
            user = userRepo.findUser(uId);
        }
        User npcUser = user.clone();
        npcUser.setSangoState(sangoState);
        npcUser.setId(-uId);
        npcUser.setRank(npcUser.getRank() < 10 ? 10 : npcUser.getRank());
        return npcUser;
    }

    /**
     * 选择要攻占的势力中已驻防的城池
     * 
     * @param rank
     * @return
     */
    private User findCanOccupyDefenceUser(int rank) {
        List<Integer> matchStats = shuffle();
        for (int state : matchStats) {
            List<Long> userIds = userRepo.randomStateRankUser(rank, state, MainCity.status_defence, 10, owner.getUserId());
            if (CollectionUtils.isEmpty(userIds)) {
                continue;
            }
            long userId = userIds.get(Constant.pg.getRandomNumber(userIds.size() - 1));

            //            MainCity mainCity = pvpRepo.findMainCity(userId);
            //            if (mainCity.getLordId() == owner.getUserId()) {
            //                continue;
            //            }
            User user = userRepo.findUser(userId);
            if (user != null) {
                return user;
            }
        }
        return null;
    }

    /**
     * 选择要攻占的势力中空的城池
     * 
     * @param rank
     * @return
     */
    private User findDesertedUser(int rank) {
        List<Integer> matchStats = shuffle();
        for (int state : matchStats) {
            List<Long> userIds = userRepo.randomStateRankUser(rank, state, MainCity.status_deserted, 10, owner.getUserId());
            if (userIds != null && userIds.size() > 0) {
                long userId = userIds.get(Constant.pg.getRandomNumber(userIds.size() - 1));
                return userRepo.findUser(userId);
            }
        }
        return null;
    }

    /**
     * 选择要攻占的势力范围内被其他势力占领的城池
     * 但是有可能被自己的势力占领，每级给以10*4次机会筛选其他势力占领的城池
     * 
     * @param rank
     * @return
     */
    private User findCanOccupyUser(int rank) {
        List<Integer> matchStats = shuffle();
        for (int state : matchStats) {
            List<Long> userIds = userRepo.randomStateRankUser(rank, state, MainCity.status_occupy, 10, owner.getUserId());
            if (CollectionUtils.isEmpty(userIds)) {
                continue;
            }
            for (long userId : userIds) {
                MainCity mainCity = pvpRepo.findMainCity(userId);
                if (mainCity.getLordId() <= 0) {
                    return userRepo.findUser(userId);
                }
                PvpUser pvpUser = pvpRepo.findPvpUser(mainCity.getLordId());
                if (pvpUser.getCamp().getId() != owner.getCamp().getId()) {
                    return userRepo.findUser(userId);
                }
            }
        }
        return null;
    }

    /**
     * 打乱随机势力的州
     * 
     * @return
     */
    private List<Integer> shuffle() {
        List<Integer> matchStates = Lists.newArrayList(matchCamp.getStates());
        Collections.shuffle(matchStates, new Random(TimeUtil.currentTimeMillis()));
        return matchStates;
    }

    public static MainCity createMainCity(long userId, MonsterData monsterData) {
        MainCity mainCity = new MainCity(userId);
        mainCity.defence(1);
        mainCity.setOfficer(createNpcOfficer(userId, monsterData));
        return mainCity;
    }

    private static Officer createNpcOfficer(long userId, MonsterData monsterData) {
        Officer npcOfficer = monsterData.generPvpMonster();
        npcOfficer.setUserId(userId);
        return npcOfficer;
    }

}
