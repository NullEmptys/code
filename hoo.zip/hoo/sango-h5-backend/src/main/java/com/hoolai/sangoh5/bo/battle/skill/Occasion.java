package com.hoolai.sangoh5.bo.battle.skill;

public enum Occasion {

    BEFORE_BATTLE, 
    BEFORE_ACTION,
    AFTER_ACTION;

}