package com.hoolai.sangoh5.bo.pvp.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.util.Constant;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class RegionData extends JsonData<RegionProperty> {

    private static final int PROVINCE_IN_STATE_NUM = 3;//多少个省在一个州

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/region.json", RegionProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getState(String province) {
        for (RegionProperty property : propertyMap.values()) {
            if (province.contains(property.getProvince())) {
                return property.getId();
            }
        }
        return idArr()[Constant.pg.getRandomNumber(propertyMap.size() - 1)];
    }

    public Map<Integer, List<Integer>> randomCamps() {
        List<Integer> ids = ids();

        Map<Integer, List<Integer>> map = new HashMap<Integer, List<Integer>>();
        List<Integer> a = new ArrayList<Integer>();
        List<Integer> b = new ArrayList<Integer>();
        List<Integer> c = new ArrayList<Integer>();

        Random rand = new Random(TimeUtil.currentTimeMillis());
        Collections.shuffle(ids, rand);

        a.add(ids.get(0));
        a.add(ids.get(1));
        a.add(ids.get(2));

        b.add(ids.get(3));
        b.add(ids.get(4));
        b.add(ids.get(5));

        c.add(ids.get(6));
        c.add(ids.get(7));
        c.add(ids.get(8));

        map.put(1, a);
        map.put(2, b);
        map.put(3, c);
        return map;
    }

    @Override
    protected void checkProperty(RegionProperty property) {
        // TODO Auto-generated method stub

    }

}
