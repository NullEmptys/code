package com.hoolai.sangoh5.bo.shop.data;

import java.io.IOException;
import javax.annotation.PostConstruct;
import org.springframework.stereotype.Component;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class FriendShipShopData extends JsonData<FriendShipShopProperty>{
	
	@PostConstruct
	public void init() {
		try {
			initData("com/hoolai/sangoh5/friendGoods.json", FriendShipShopProperty.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	protected void checkProperty(FriendShipShopProperty property) {
		// TODO Auto-generated method stub
		
	}

}
