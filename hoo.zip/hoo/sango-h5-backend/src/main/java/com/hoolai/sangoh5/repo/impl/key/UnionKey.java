package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.keyvalue.jredis.StorageKeyProtobuf;
import com.hoolai.sangoh5.repo.redis.RedisKeyFalg;
import com.hoolai.sangoh5.util.Constant;

public class UnionKey {

    public static final String UNION_PREFIX = "uin";

    /**
     * 生成全局唯一的unionId key
     * 
     * @return
     */
    public static String getUnionIdGeneratorKey() {
        return "uin_unique_id";
    }

    /**
     * 联盟key
     */
    public static String getUnionKey(long unionId) {
        return new StringBuilder().append(UNION_PREFIX).append(Constant.separator).append("id").append(Constant.separator).append(unionId).toString();
    }

    /**
     * 联盟玩家key
     */
    public static String getUnionUseKey(long userId) {
        return new StringBuilder().append(UNION_PREFIX).append(Constant.separator).append("user").append(Constant.separator).append(userId).toString();

    }

    /**
     * 州的联盟key
     */
    public static String getStateUnion(int state) {
        return new StringBuilder().append(UNION_PREFIX).append(Constant.separator).append("state").append(Constant.separator).append(state).toString();
    }

    public static byte[] getUnionRankKey() {
        return StorageKeyProtobuf.getByteArray(RedisKeyFalg.UNION_RANK_KEY, RedisKeyFalg.UNION_RANK_KEY, RedisKeyFalg.DEFAULT_KEY_FLAG);
    }

    public static String getUnionContributesKey(long unionId) {
        return new StringBuilder().append(UNION_PREFIX).append(Constant.separator).append("ct").append(Constant.separator).append(unionId).toString();
    }

    public static String getLockUnionKey(long unionId) {
        return new StringBuilder().append(UNION_PREFIX).append(Constant.separator).append("lock").append(Constant.separator).append(unionId).toString();
    }

}
