//package com.hoolai.sangoh5.bo.battle.skill.passive;
//
//import java.util.Map;
//import java.util.Set;
//
//import com.hoolai.sangoh5.bo.battle.enhance.effect.Skill31HurtEnhanceEffect;
//import com.hoolai.sangoh5.bo.battle.skill.Skill;
//import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
//import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
//import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
//
//public class Skill31 extends AttributeEnhanceSkill {
//
//	/*
//	 * 每隔一段时间给予一次致命一击的机会，减慢目标25%的攻击速度，造成1.5倍伤害的致命一击
//	 */
//	
//	@Override
//	public void apply(FightUnit actor, TargetCollection tc) {
//		boolean isAttacker = actor.isAttacker();
//		
//		FightUnit officer = tc.get(FightUnitName.officerUnitName(!isAttacker));
//		Skill31HurtEnhanceEffect enhanceEffect = new Skill31HurtEnhanceEffect(actor, officer,this);
//		officer.addEnhanceEffect(enhanceEffect);
//		
//		Map<FightUnitName, FightUnit> aliveMap = tc.aliveTargetSoldier(isAttacker);
//		Set<FightUnitName> keySet = aliveMap.keySet();
//		for(FightUnitName name:keySet){
//			FightUnit target = aliveMap.get(name);
//			
//			enhanceEffect = new Skill31HurtEnhanceEffect(actor, target, this);
//			target.addEnhanceEffect(enhanceEffect);
//		}
//	}
//
//	@Override
//	public Skill clone() {
//		return super.clone(new Skill31());
//	}
//
//}
