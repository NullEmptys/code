package com.hoolai.sangoh5.bo.pvp;

import java.util.Collection;
import java.util.Map;

import org.compass.core.util.CollectionUtils;

import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.PersonalMedalProto;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.PersonalMedalsProto;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.PersonalMedalsProto.Builder;
import com.hoolai.sangoh5.bo.pvp.data.PersonalMedalProperty;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 15:23
 * @version : 1.0
 */
public class PersonalMedals implements ProtobufSerializable<PersonalMedalsProto> {

    public static final PersonalMedals EMPTY = new PersonalMedals();

    /** 徽章id 与 进度 **/
    private Map<Integer, PersonalMedal> medalMap;

    /** 完成个数 **/
    private int finishCount;

    public PersonalMedals() {
    }

    public PersonalMedals(PersonalMedalsProto personalMedals) {
        this.copyFrom(personalMedals);
    }

    public Map<Integer, PersonalMedal> getMedalMap() {
        return medalMap;
    }

    //    public Collection<PersonalMedal> getMedals() {
    //        return medalMap.values();
    //    }

    @Override
    public PersonalMedalsProto copyTo() {
        if (CollectionUtils.isEmpty(medalMap)) {
            return PersonalMedalsProto.getDefaultInstance();
        }
        Builder newBuilder = PersonalMedalsProto.newBuilder();
        Collection<PersonalMedal> values = medalMap.values();
        for (PersonalMedal personalMedal : values) {
            newBuilder.addPersonalMedals(personalMedal.copyTo());
        }
        newBuilder.setFinishCount(finishCount);
        return newBuilder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            PersonalMedalsProto message = PersonalMedalsProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(PersonalMedalsProto message) {
        int personalMedalsCount = message.getPersonalMedalsCount();
        medalMap = personalMedalsCount <= 0 ? Maps.newHashMapWithExpectedSize(4) : Maps.newHashMapWithExpectedSize(personalMedalsCount);
        for (int i = 0; i < personalMedalsCount; i++) {
            PersonalMedalProto personalMedals = message.getPersonalMedals(i);
            PersonalMedal personalMedal = new PersonalMedal(personalMedals);
            medalMap.put(personalMedal.getMedalId(), personalMedal);
        }
        this.finishCount = message.getFinishCount();
    }

    public void initMedal(PersonalMedalProperty property) {
        PersonalMedal personalMedal = new PersonalMedal(property.getId());
        medalMap.put(personalMedal.getMedalId(), personalMedal);
    }

    public boolean notEmpty() {
        return !CollectionUtils.isEmpty(medalMap);
    }

    public PersonalMedal findPersonalMedal(PersonalMedalProperty property) {
        if (medalMap.containsKey(property.getId())) {
            return medalMap.get(property.getId());
        }
        this.initMedal(property);
        return medalMap.get(property.getId());
    }

    public boolean finished(PersonalMedal personalMedal, PersonalMedalProperty property) {
        if (!personalMedal.finish(property)) {
            return false;
        }
        this.finishCount++;
        personalMedal.setOrder(finishCount);
        return true;
    }

    public int getFinishCount() {
        return finishCount;
    }

}
