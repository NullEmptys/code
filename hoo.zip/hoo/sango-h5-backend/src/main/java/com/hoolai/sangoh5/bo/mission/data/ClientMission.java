package com.hoolai.sangoh5.bo.mission.data;

public class ClientMission {

    /** 任务定义id */
    private int missionDefineId;

    /** 任务完成记录统计 */
    private int missionDetail;

    /** 任务类型 */
    private int categoryId;

    /** 状态 */
    private int status;

    public int getMissionDefineId() {
        return missionDefineId;
    }

    public void setMissionDefineId(int missionDefineId) {
        this.missionDefineId = missionDefineId;
    }

    public int getMissionDetail() {
        return missionDetail;
    }

    public void setMissionDetail(int missionDetail) {
        this.missionDetail = missionDetail;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

}
