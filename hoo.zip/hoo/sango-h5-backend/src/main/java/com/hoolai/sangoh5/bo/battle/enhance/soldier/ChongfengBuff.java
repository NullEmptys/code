package com.hoolai.sangoh5.bo.battle.enhance.soldier;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.fight.ActionResult;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 战火覆盖范围内改变防御力
 */
public class ChongfengBuff extends Buff {

    private FightUnit skillOwner;

    private Skill skill;

    private boolean isDoMove;

    private boolean isFinishMove;

    @Override
    public void targetEnhanceAfterExcuteBuffs(List<ActionResult> actionResultList, TargetCollection tc) {
        this.result();
        ActionResult actionResult = findActionResult(skill.getXmlId(), skillOwner, actionResultList);
        if (!isDoMove) {
            if (actionResult.getIsHaveNewTarget()) {
                int old = actionResult.getPositionManager().getMoveNum();
                int newNum = (int) (old / (skillOwner.baseMoveSpeed() / FightUnit.ROUND_SPEND));
                actionResult.getPositionManager().setMoveNum(newNum);
                actionResult.getBuffList()
                        .add(new Buff(skill.getXmlId(), skill.getName(), skillOwner.name(), 1).withActorName(skillOwner.name()).withTargetName(skillOwner.name()));
                isDoMove = true;
            }
        }
        if (!isFinishMove && skillOwner.getPositionManager() != null && skillOwner.getPositionManager().isReachTargetPos()) {
            skillOwner.setMoveSpeed(skillOwner.baseMoveSpeed());
            isFinishMove = true;
            repeatCount = 0;
        }
    }

    @Override
    public void apply(FightUnit target) {
        //        apply(target);
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * 此方法必要的时候需要在子类重写，否则会调用alive.unsilence()清除沉默产生负作用
     * 
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        //alive.removeBuff(this);
    }

    @Override
    protected ChongfengBuff clone() {
        ChongfengBuff buff = (ChongfengBuff) super.clone(new ChongfengBuff(this.targetUsedSkillXmlId, executeName, skillOwner, skill, currentLevel));
        buff.skillOwner = skillOwner;
        return buff;
    }

    public ChongfengBuff(int xmlId, FightUnitName name, FightUnit actor, Skill skill, int currentLevel) {
        super(xmlId, skill.getName(), name, currentLevel);
        this.skillOwner = actor;
        this.skill = skill;
        this.isForFront = false;
    }

}
