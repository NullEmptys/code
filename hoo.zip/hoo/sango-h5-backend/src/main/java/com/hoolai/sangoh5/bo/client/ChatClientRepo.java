package com.hoolai.sangoh5.bo.client;

import com.hoolai.sangoh5.proto.ChatProto.ChatMsgProto;

public interface ChatClientRepo {

    void sendMsg(ChatMsgProto chatMsg);
}
