package com.hoolai.sangoh5.bo.officerunion;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.OfficerUnionStarProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class OfficerUnionStar implements ProtobufSerializable<OfficerUnionStarProto>{

	private int officerXmlId;
	
	private int maxStarLv;

	public OfficerUnionStar(OfficerUnionStarProto message) {
		copyFrom(message);
	}
	
	public OfficerUnionStar(){}

	public OfficerUnionStar(int officerXmlId, int maxStar) {
		this.officerXmlId = officerXmlId;
		this.maxStarLv = maxStar;
	}

	@Override
	public OfficerUnionStarProto copyTo() {
		OfficerUnionStarProto.Builder builder = OfficerUnionStarProto.newBuilder();
		builder.setOfficerXmlId(officerXmlId);
		builder.setMaxStarLv(maxStarLv);
		return builder.build();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			OfficerUnionStarProto message = OfficerUnionStarProto.parseFrom(bytes);
			copyFrom(message);
		} catch (InvalidProtocolBufferException e) {
			throw new BusinessException(ErrorCode.CAN_NOT_MEM);
		}
	}

	@Override
	public void copyFrom(OfficerUnionStarProto message) {
		this.officerXmlId = message.getOfficerXmlId();
		this.maxStarLv = message.getMaxStarLv();
	}

	public int getOfficerXmlId() {
		return officerXmlId;
	}

	public void setOfficerXmlId(int officerXmlId) {
		this.officerXmlId = officerXmlId;
	}

	public int getMaxStarLv() {
		return maxStarLv;
	}

	public void setMaxStarLv(int maxStarLv) {
		this.maxStarLv = maxStarLv;
	}

	public boolean updateStarLv(int starLevel) {
		if(this.maxStarLv < starLevel){
			this.maxStarLv = starLevel;
			return true;
		}
		return false;
	}

	public boolean collect(int xmlId, int starLv) {
		if(starLv > this.maxStarLv){
			this.maxStarLv = starLv;
			return true;
		}
		return false;
	}
	
}
