package com.hoolai.sangoh5.bo.platform.wanba;

import java.util.Set;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hoolai.platform.Config;
import com.hoolai.platform.RequestInfo;
import com.hoolai.platform.service.tencent.TencentRequestInfo;
import com.hoolai.platform.service.tencent.TencentV3Support;
import com.hoolai.sangoh5.util.Constant;
import com.hoolai.url.RequestProperty;
import com.hoolai.util.JSONUtils;
import com.hoolai.util.StringUtil;
import com.hoolai.util.net.HoolaiURLEncoder;

/**
 * <p>描述：玩吧平台（pf为wanba_ts）支付接口</p>
 * @author whg
 * @date 2016-8-5 下午07:22:00
 */
public class WanbaV3Support extends TencentV3Support implements WanbaPlatformService{

	private static final Logger logger = LoggerFactory.getLogger(WanbaV3Support.class);
	
    private static final String user_score_uri = "/v3/user/get_playzone_userinfo";
    private static final String buy_item_uri = "/v3/user/buy_playzone_item";
	
	public WanbaV3Support(Config config) {
		super(config);
	}
	
	private static class singleLetionHolder{
		private static WanbaV3Support instance = null;
		
		static{
			Config config = new Config(Constant.APP_ID, Constant.SECRETKEY
					,  Constant.SECRETKEY,Constant.API_URL);
			
			instance = new WanbaV3Support(config);
		}
	}
	
	public static WanbaV3Support getInstance(){
		return singleLetionHolder.instance;
	}
	
	@Override
	public WanbaUserScoreResponse findWanbaUserScore(RequestInfo requestInfo, int zoneid){
		TreeMap<String, String> params = publicParams(requestInfo);
		params.put("zoneid", String.valueOf(zoneid));
		String responseTxt = doRequest(user_score_uri, params);
		if (null == responseTxt) {
            return WanbaUserScoreResponse.error();//返回错误信息
        }
		WanbaUserScoreResponse response = JSONUtils.fromJSON(extractJson(responseTxt), WanbaUserScoreResponse.class);
        return response;
	}
	
	@Override
	public WanbaBuyItemResponse buyWanbaItem(RequestInfo requestInfo, int zoneid, int itemid, int count, String billno){
		TreeMap<String, String> params = publicParams(requestInfo);
		params.put("zoneid", String.valueOf(zoneid));
		params.put("itemid", String.valueOf(itemid));
		params.put("count", String.valueOf(count));
		params.put("billno", billno);
		String responseTxt = doRequest(buy_item_uri, params);
		if (null == responseTxt) {
            return WanbaBuyItemResponse.error();//返回错误信息
        }
		WanbaBuyItemResponse response = JSONUtils.fromJSON(extractJson(responseTxt), WanbaBuyItemResponse.class);
        return response;
	}
	
	/** 从jsonp返回格式中提取json数据 */
	private String extractJson(String responseTxt){
		int startIndex = responseTxt.indexOf('{');
		int endIndex= responseTxt.lastIndexOf('}');
		return responseTxt.substring(startIndex, endIndex+1);
	}
	
	/**
	 * 腾讯API接口请求的公共参数<br/><br/>
	 * 
	 * 腾讯doc上公布的公共参数为：
	 * 1、openid，2、openkey，3、appid，4、sig，5、pf<br/>
	 * 注意sig不在此处生成，sig最后才生成，因为需要结合所有请求参数去生成
	 * @return
	 */
	private TreeMap<String, String> publicParams(RequestInfo requestInfo){
		TencentRequestInfo info = (TencentRequestInfo) requestInfo;
		TreeMap<String, String> params = new TreeMap<String, String>();
		params.put("openid", info.getOpenid());
		params.put("openkey", info.getOpenkey());
		params.put("appid", this.config.appId + "");
		params.put("pf", info.getPf());
		return params;
	}
	
	private String doRequest(String uri, TreeMap<String, String> params){
    	StringBuilder requestParam = new StringBuilder();
        requestParam.append(sortRequestParams(params));
    	String requestUrl = generateReqeustUrl(uri, requestParam);
//    	logger.info("wanba url:" + requestUrl);//生成的url通过浏览器访问
        String res = httpService.doGet(requestUrl, new RequestProperty[0]);
//        logger.info("wanba result="+res);
        return res;
    }
	
	private String sortRequestParams(TreeMap<String,String> params){
        StringBuilder requestParam = new StringBuilder();
        Set<String> keys = params.keySet();
        int index = 0;
        for(String key:keys){
            requestParam.append(key);
            requestParam.append("=");
            requestParam.append(params.get(key));
            if(index != keys.size()-1){
                requestParam.append("&");    
            }
            index++;
        }
        return requestParam.toString();
    }
	
	private String generateReqeustUrl(String uri,StringBuilder requestParam){
        String uriCoded = HoolaiURLEncoder.encode(uri);

        String sigData = "GET" + "&" + uriCoded + "&" + HoolaiURLEncoder.encode(requestParam.toString());

        String sigkey = this.config.apiKey + "&";

        String sig = StringUtil.hmacSHA1ToBase64(sigkey, sigData);
        requestParam.append("&sig=").append(HoolaiURLEncoder.encode(sig));
        String requestUrl = requestParam.insert(0, "?").insert(0, uri).insert(0, this.config.apiUrl).toString();
        return requestUrl;
    }

	@Override
	public WanbaBuyItemResponse buyWanbaItem(RequestInfo requestInfo,
			int zoneid, int itemid, int count) {
		return null;
	}


}
