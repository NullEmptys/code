package com.hoolai.sangoh5.bo.battle.skill.passive;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.KuangBaoBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class KuangBao extends AttributeEnhanceSkill {

    /*
     * 每损失7%的血量就能够得到相应的攻击力和攻击速度的提升，提升次数无上限
     */

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {
        Buff obuff = new KuangBaoBuff(xmlId, actor.name(), actor, this, Effect.MONITORING_BUFF_LEVEL).withKeepBuff().withRepeatCount(MaxRepeatCount).withActorName(actor.name())
                .withTargetName(actor.name());
        actor.addAfterActionBuff(obuff);
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]");
    }

    @Override
    public Skill clone() {
        return super.clone(new KuangBao());
    }

}
