package com.hoolai.sangoh5.bo.mission;

/**
 * 任务状态
 * 
 * @author hp
 *
 */
public enum MissionStatus {

	STATUS_READY(0, "任务还没有开始"), 
	STATUS_STARTED(1, "任务已经开始，没有完成"),
	STATUS_FINISHED(2, "任务已经完成，没有领取奖励"), 
	STATUS_END(3,"任务已经结束"), 
	STATUS_EXPIRE(4, "任务已过期");

	private int id;
	private String desc;

	private MissionStatus(int id, String desc) {
		this.id = id;
		this.desc = desc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
