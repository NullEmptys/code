package com.hoolai.sangoh5.bo.battle.enhance.buff;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.defence.passive.ShenDunDefence;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 每10秒为所有单位增加一个护盾，抵挡1000点伤害后消失
 */
public class ShenDunBuff extends Buff {

    private final List<FightUnit> fightUnits;

    private final Skill belongSkill;

    private final FightUnit actor;

    @Override
    public void apply(FightUnit target) {

        this.result();
        if (belongSkill.getRound() == 0) {
            if (logger.isDebugEnabled()) {
                logger.debug("buffInterval:" + belongSkill.getRound() + ",xmlId=" + targetUsedSkillXmlId);
            }
            return;
        }

        if (!actor.isDead() && (executeCount % belongSkill.getRound() == 0)) {
            for (FightUnit fightUnit : fightUnits) {
                if (fightUnit.isDead()) {
                    continue;
                }
                ShenDunDefence shenDunDefence = (ShenDunDefence) fightUnit.findDefencePassiveSkill(targetUsedSkillXmlId);
                if (shenDunDefence == null) {
                    fightUnit.addCounterAttackSkills(new ShenDunDefence(targetUsedSkillXmlId, belongSkill.getName(), Math.round(belongSkill.getValue())));
                } else {
                    shenDunDefence.reset(Math.round(belongSkill.getValue()));
                }
                actor.addBattleLog(actor.name() + "使用" + targetUsedSkillXmlId + "[" + skillName + "]给" + fightUnit.name() + "增加护盾,抵挡伤害上限=" + belongSkill.getValue());
            }
            super.needRepeatPlay();
        }
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    @Override
    protected ShenDunBuff clone() {
        ShenDunBuff buff = (ShenDunBuff) super.clone(new ShenDunBuff(this.targetUsedSkillXmlId, executeName, currentLevel, fightUnits, belongSkill, actor));
        return buff;
    }

    public ShenDunBuff(int targetUsedSkillXmlId, FightUnitName executeName, int currentLevel, List<FightUnit> fightUnits, Skill skill, FightUnit actor) {
        super(targetUsedSkillXmlId, skill.getName(), executeName, currentLevel);
        this.fightUnits = fightUnits;
        this.belongSkill = skill;
        this.actor = actor;
        this.isForFront = false;
    }

}
