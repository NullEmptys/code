package com.hoolai.sangoh5.bo.battle.enhance.buff;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.fight.ActionResult;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 战火覆盖范围内改变防御力
 */
public class KuangXueShouHuaBuff extends Buff {

    private FightUnit skillOwner;

    private final Skill skill;

    @Override
    public void targetEnhanceAfterExcuteBuffs(List<ActionResult> actionResults, TargetCollection tc) {
        this.result();

        float hpPer = skillOwner.getHp() / skillOwner.getOriginalHp();
        if (deltaHp == 0 && hpPer < skill.getPercentage()) {
            int chp = -Math.round(skillOwner.getOriginalHp() * skill.getTwoPercentage());
            skillOwner.changeHp(chp);
            this.deltaHp = chp;

            skillOwner
                    .addBattleLog(this.targetUsedSkillXmlId + "[" + this.skillName + "]执行" + skillOwner.name() + "当前血量比率=" + hpPer + ",回血=" + chp + ",当前血量=" + skillOwner.getHp());

            ActionResult actionResult = findActionResult(skill.getXmlId(), skillOwner, actionResults);
            actionResult.getBuffList().add(
                    new Buff(skill.getXmlId(), skill.getName(), skillOwner.name(), Buff.DEFAULT_BUFF_LEVEL).withActorName(skillOwner.name()).withTargetName(skillOwner.name())
                            .withDeltaHp(deltaHp));
        }

    }

    @Override
    public void apply(FightUnit target) {
        //        apply(target);
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * 此方法必要的时候需要在子类重写，否则会调用alive.unsilence()清除沉默产生负作用
     * 
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        //alive.removeBuff(this);
    }

    @Override
    protected KuangXueShouHuaBuff clone() {
        KuangXueShouHuaBuff buff = (KuangXueShouHuaBuff) super.clone(new KuangXueShouHuaBuff(this.targetUsedSkillXmlId, executeName, skillOwner, skill, currentLevel, isForFront));
        buff.skillOwner = skillOwner;
        return buff;
    }

    public KuangXueShouHuaBuff(int xmlId, FightUnitName name, FightUnit actor, Skill skill, int currentLevel, boolean isFornt) {
        super(xmlId, skill.getName(), name, currentLevel);
        this.skillOwner = actor;
        this.skill = skill;
        super.isForFront = isFornt;
    }

}
