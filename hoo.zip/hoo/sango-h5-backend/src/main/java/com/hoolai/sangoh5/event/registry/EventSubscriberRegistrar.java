package com.hoolai.sangoh5.event.registry;

import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.event.EventDispatcher;
import com.hoolai.sangoh5.event.EventSubscriber;
import com.hoolai.sangoh5.event.EventType;
import com.hoolai.sangoh5.event.annotation.Subscriber;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 17:30
 * @version : 1.0
 */
@Component
public class EventSubscriberRegistrar implements BeanPostProcessor {

    @Autowired
    private List<EventDispatcher> eventDispatchers;

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        return bean;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {

        Class<?> beanClass = bean.getClass();
        Subscriber subscriber = beanClass.getAnnotation(Subscriber.class);

        if (subscriber == null) {
            return bean;
        }

        if (!(bean instanceof EventSubscriber<?>)) {
            return bean;
        }

        for (EventDispatcher eventDispatcher : eventDispatchers) {
            for (EventType eventType : subscriber.value()) {
                eventDispatcher.subscribe(eventType, (EventSubscriber<?>) bean);
            }
        }
        return bean;
    }
}
