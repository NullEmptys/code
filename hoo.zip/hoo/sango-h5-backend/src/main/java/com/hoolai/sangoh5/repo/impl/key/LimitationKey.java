package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.bo.Limitation;
import com.hoolai.sangoh5.util.Constant;

public class LimitationKey {

    private static final String prefix= "lm";
    
    private static final String oper_prefix="ht_u";
    
    public static String getOfficerLimitationKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("ol").toString();
    }
    
    public static String getOperationTimeKey(long userId) {
        return new StringBuilder(oper_prefix).append(Constant.separator).append(userId).append("l").append(Constant.separator).append("oping").toString();
    }
    
    public static String getDayLimitationKey(long userId, Limitation.Type type){
		return new StringBuilder(prefix).append(Constant.separator).append(userId).append(Constant.separator)
				.append("day").append(Constant.separator).append(type.ordinal()).toString();
    }
}
