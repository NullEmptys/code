package com.hoolai.sangoh5.bo.shop.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;

import com.google.common.collect.Lists;
import com.hoolai.sango.core.exception.BusinessException;
import com.hoolai.sango.util.ProbabilityGenerator;
import com.hoolai.sango.util.ProbabilityGeneratorImpl;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonData;

public class ShopData extends JsonData<ShopProperty> {

    public static final int SHOP_NUM = 8;

    protected final Map<Integer, List<ShopProperty>> shopPropertyAsType = new HashMap<Integer, List<ShopProperty>>();

    protected ProbabilityGenerator probabilityGenerator = new ProbabilityGeneratorImpl();

    @Override
    public void init() {

    }

    @Override
    protected void checkProperty(ShopProperty property) {
        if (property.getSellType() >= SHOP_NUM || property.getSellType() < 0) {
            throw new BusinessException(ErrorCode.SYSTEM_ERROR.code, "售卖类型错误 : " + property.getSellType());
        }
    }

    @Override
    protected void initForEach(ShopProperty sp) {
        List<ShopProperty> propertys = shopPropertyAsType.get(sp.getSellType());
        if (propertys == null) {
            propertys = new ArrayList<ShopProperty>();
            shopPropertyAsType.put(sp.getSellType(), propertys);
        }
        propertys.add(sp);
    }

    /**
     * 根据类型，等级 数量随机
     * 
     * @param key 类型
     * @param userRank
     * @param num
     * @return
     */
    public List<Integer> findIds(int key, int userRank, int num) {
        List<ShopProperty> shopPropertys = shopPropertyAsType.get(key);
        if (shopPropertys == null || shopPropertys.isEmpty() || num <= 0) {
            return Collections.emptyList();
        }

        List<ShopProperty> findShopProperties = new ArrayList<ShopProperty>();
        for (ShopProperty sp : shopPropertys) {
            if (userRank >= sp.getUnlockLv()) {
                findShopProperties.add(sp);
            }
        }

        int[] xmlIds = new int[findShopProperties.size()];
        int[] probability = new int[findShopProperties.size()];
        for (int i = 0; i < findShopProperties.size(); i++) {
            xmlIds[i] = findShopProperties.get(i).getId();
            probability[i] = findShopProperties.get(i).getProbability();
        }
        if (ArrayUtils.isEmpty(probability)) {
            return Collections.emptyList();
        }
        if (probability.length <= num) {
            return Lists.newArrayList(ArrayUtils.toObject(xmlIds));
        }

        int[] indexs = probabilityGenerator.getMutilRandomChoiceWithRatioArr(probability, num);
        List<Integer> ids = new ArrayList<Integer>();
        for (int i = 0; i < indexs.length; i++) {
            ids.add(xmlIds[indexs[i]]);
        }
        return ids;

    }

}
