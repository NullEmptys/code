package com.hoolai.sangoh5.bo.arena;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ArenaProtocolBuffer.ArenaOfficersProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class ArenaOfficers implements ProtobufSerializable<ArenaOfficersProto> {

    private List<ArenaOfficer> arenaOfficers = new ArrayList<ArenaOfficer>();

    transient private long userId;

    public ArenaOfficers(long userId, byte[] bytes) {
        this.userId = userId;
        parseFrom(bytes);
    }

    public ArenaOfficers(long userId) {
        this.userId = userId;
    }

    public void addArenaOfficer(ArenaOfficer arenaOfficer) {
        this.arenaOfficers.add(arenaOfficer);
    }

    public ArenaOfficer findArenaOfficer(int xmlId) {
        for (ArenaOfficer arenaOfficer : arenaOfficers) {
            if (arenaOfficer.getOfficerXmlId() == xmlId) {
                return arenaOfficer;
            }
        }
        ArenaOfficer arenaOfficer = new ArenaOfficer(xmlId);
        this.arenaOfficers.add(arenaOfficer);
        return arenaOfficer;
    }

    public List<ArenaOfficer> getArenaOfficers() {
        return arenaOfficers;
    }

    public void clear() {
        this.arenaOfficers.clear();
    }

    public long getUserId() {
        return userId;
    }

    @Override
    public ArenaOfficersProto copyTo() {
        ArenaOfficersProto.Builder builder = ArenaOfficersProto.newBuilder();
        if (arenaOfficers.size() > 0) {
            for (ArenaOfficer arenaOfficer : arenaOfficers) {
                builder.addArenaOfficers(arenaOfficer.copyTo());
            }
        }
        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ArenaOfficersProto message = ArenaOfficersProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(ArenaOfficersProto message) {
        int count = message.getArenaOfficersCount();
        this.arenaOfficers = new ArrayList<ArenaOfficer>();
        for (int i = 0; i < count; i++) {
            arenaOfficers.add(new ArenaOfficer(userId, message.getArenaOfficers(i)));
        }
    }

    public double top10OfficerAvgScore() {
        List<ArenaOfficer> arenaOfficers = this.getArenaOfficers();
        if (arenaOfficers.size() < 10) {
            double score = 0;
            for (ArenaOfficer arenaOfficer : arenaOfficers) {
                score += arenaOfficer.getScore();
            }
            score += (10 - arenaOfficers.size()) * 1000d;
            return score / 10d;
        }
        double score = 0;
        int count = 0;
        for (ArenaOfficer arenaOfficer : arenaOfficers) {
            if (count >= 10) {
                break;
            }
            if (arenaOfficer.getScore() != 1000) {
                score += arenaOfficer.getScore();
                count++;
            }

        }
        if (count < 10) {
            score += (10 - count) * 1000d;
            return score / 10d;
        }
        return score / 10d;
    }
}
