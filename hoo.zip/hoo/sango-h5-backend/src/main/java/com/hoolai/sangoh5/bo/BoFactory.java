package com.hoolai.sangoh5.bo;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.hoolai.keyvalue.jredis.JRedis;
import com.hoolai.sangoh5.bo.arena.ArenaUser;
import com.hoolai.sangoh5.bo.arena.MatchArenaUserProcessor;
import com.hoolai.sangoh5.bo.award.AwardChannel;
import com.hoolai.sangoh5.bo.award.AwardProcessor;
import com.hoolai.sangoh5.bo.award.OfficerAward;
import com.hoolai.sangoh5.bo.barrack.Barrack;
import com.hoolai.sangoh5.bo.battle.BattleObjFoctory;
import com.hoolai.sangoh5.bo.battle.fight.ActorSequence;
import com.hoolai.sangoh5.bo.battle.fight.Match;
import com.hoolai.sangoh5.bo.battle.fight.PositionCalculator;
import com.hoolai.sangoh5.bo.battle.skill.data.BattleEnhanceData;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillData;
import com.hoolai.sangoh5.bo.battle.unit.Army;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;
import com.hoolai.sangoh5.bo.captive.Captives;
import com.hoolai.sangoh5.bo.client.ChatClientRepo;
import com.hoolai.sangoh5.bo.constant.ConstantsPoolData;
import com.hoolai.sangoh5.bo.equip.Equips;
import com.hoolai.sangoh5.bo.equip.data.EquipData;
import com.hoolai.sangoh5.bo.equip.data.SuitData;
import com.hoolai.sangoh5.bo.farmland.data.FarmlandAndMineData;
import com.hoolai.sangoh5.bo.item.ItemBags;
import com.hoolai.sangoh5.bo.item.data.GoodsData;
import com.hoolai.sangoh5.bo.item.data.ItemData;
import com.hoolai.sangoh5.bo.item.data.MaterialData;
import com.hoolai.sangoh5.bo.militaryRank.data.MilitaryRankData;
import com.hoolai.sangoh5.bo.mission.data.MissionData;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.officer.OfficerFactory;
import com.hoolai.sangoh5.bo.officer.RecruitOfficerProcessor;
import com.hoolai.sangoh5.bo.officer.data.NewRecruitData;
import com.hoolai.sangoh5.bo.officer.data.OfficerData;
import com.hoolai.sangoh5.bo.officer.data.OfficerLvData;
import com.hoolai.sangoh5.bo.officer.data.OfficerProperty;
import com.hoolai.sangoh5.bo.officer.data.RecruitGoodsData;
import com.hoolai.sangoh5.bo.officer.data.RecruitmentData;
import com.hoolai.sangoh5.bo.officerunion.data.OfficerUnionData;
import com.hoolai.sangoh5.bo.payment.data.MoonWeekCardData;
import com.hoolai.sangoh5.bo.payment.data.RechargeHallData;
import com.hoolai.sangoh5.bo.platform.wanba.WanbaV3Support;
import com.hoolai.sangoh5.bo.potion.OfficerEnhancePotion;
import com.hoolai.sangoh5.bo.pve.Chapters;
import com.hoolai.sangoh5.bo.pve.Provision;
import com.hoolai.sangoh5.bo.pve.data.ChapterData;
import com.hoolai.sangoh5.bo.pve.data.MonsterData;
import com.hoolai.sangoh5.bo.pve.data.PveData;
import com.hoolai.sangoh5.bo.pvp.Camp;
import com.hoolai.sangoh5.bo.pvp.Camps;
import com.hoolai.sangoh5.bo.pvp.MatchFightUser;
import com.hoolai.sangoh5.bo.pvp.PvpUser;
import com.hoolai.sangoh5.bo.pvp.data.LineupConBoxData;
import com.hoolai.sangoh5.bo.pvp.data.RegionConBoxData;
import com.hoolai.sangoh5.bo.pvp.data.RegionData;
import com.hoolai.sangoh5.bo.pvp.data.UnionConBoxData;
import com.hoolai.sangoh5.bo.rankfight.data.RankStepData;
import com.hoolai.sangoh5.bo.slave.Slaves;
import com.hoolai.sangoh5.bo.soldier.Soldier;
import com.hoolai.sangoh5.bo.soldier.data.SoldierData;
import com.hoolai.sangoh5.bo.tacticalManagement.Formation;
import com.hoolai.sangoh5.bo.tacticalManagement.data.TacticalData;
import com.hoolai.sangoh5.bo.technology.SoldierTechnologies;
import com.hoolai.sangoh5.bo.technology.data.SoldierScienceData;
import com.hoolai.sangoh5.bo.union.UnionUser;
import com.hoolai.sangoh5.bo.union.data.UnionBadgeData;
import com.hoolai.sangoh5.bo.union.data.UnionTitleData;
import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.bo.user.UserLoginProcessor;
import com.hoolai.sangoh5.bo.user.UserValidation;
import com.hoolai.sangoh5.bo.user.WanBaUserLoginProcessor;
import com.hoolai.sangoh5.bo.user.data.BuildingData;
import com.hoolai.sangoh5.bo.user.data.InitUserData;
import com.hoolai.sangoh5.bo.user.data.UserData;
import com.hoolai.sangoh5.repo.ArenaRepo;
import com.hoolai.sangoh5.repo.BarrackRepo;
import com.hoolai.sangoh5.repo.FriendRepo;
import com.hoolai.sangoh5.repo.IndustryRepo;
import com.hoolai.sangoh5.repo.ItemRepo;
import com.hoolai.sangoh5.repo.JdbcSqlRepo;
import com.hoolai.sangoh5.repo.LimitationRepo;
import com.hoolai.sangoh5.repo.MessageInfosRepo;
import com.hoolai.sangoh5.repo.MissionRepo;
import com.hoolai.sangoh5.repo.OfficerRepo;
import com.hoolai.sangoh5.repo.OfficerUnionRepo;
import com.hoolai.sangoh5.repo.PveRepo;
import com.hoolai.sangoh5.repo.PvpRepo;
import com.hoolai.sangoh5.repo.SoldierScienceRepo;
import com.hoolai.sangoh5.repo.UnionRepo;
import com.hoolai.sangoh5.repo.UserRepo;
import com.hoolai.sangoh5.repo.impl.UserMilitaryRepoImpl;
import com.hoolai.sangoh5.repo.redis.PveAreaRankRepo;
import com.hoolai.sangoh5.repo.redis.RankFightRepo;
import com.hoolai.sangoh5.service.AntiPluginDomainService;
import com.hoolai.sangoh5.service.BusinessDomainService;
import com.hoolai.sangoh5.service.ChatMsgFactory;
import com.hoolai.sangoh5.service.TrackDomainService;
import com.hoolai.sangoh5.service.UpgradeEngine;
import com.hoolai.sangoh5.service.activity.ActivityService;
import com.hoolai.sangoh5.service.mission.MissionEngine;
import com.hoolai.sangoh5.service.remoting.OfficerUnionRemoteService;
import com.hoolai.sangoh5.service.remoting.TrackRemoteService;
import com.hoolai.sangoh5.service.remoting.WanBaInviteRemoteService;
import com.hoolai.sangoh5.util.ProbabilityGenerator;
import com.hoolai.sangoh5.util.operation.Operation;

@Component
public class BoFactory {

    @Autowired
    private SoldierData soldierData;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private AntiPluginDomainService auAntiPluginDomainService;

    @Autowired
    private LimitationRepo limitationRepo;

    @Autowired
    private BarrackRepo barrackRepo;

    @Autowired
    private ItemRepo itemRepo;

    @Autowired
    private OfficerData officerData;

    @Autowired
    private SkillData skillData;

    @Autowired
    private ItemData itemData;

    @Autowired
    private EquipData equipData;

    @Autowired
    private SuitData suitData;

    @Autowired
    private OfficerRepo officerRepo;

    @Autowired
    private GoodsData goodsData;

    @Autowired
    private RecruitmentData recruitmentData;

    @Autowired
    private ProbabilityGenerator pg;

    @Autowired
    private PveData pveData;

    @Autowired
    private ChapterData chapterData;

    @Autowired
    private BattleObjFoctory battleObjFoctory;

    @Autowired
    private IndustryRepo industryRepo;

    @Autowired
    private RegionData regionData;

    @Autowired
    private PvpRepo pvpRepo;

    @Autowired
    private PveRepo pveRepo;

    @Autowired
    private RankFightRepo rankFightRepo;

    @Autowired
    private UserData userData;

    @Autowired
    private ArenaRepo arenaRepo;

    @Autowired
    private TacticalData tacticalData;

    @Autowired
    private MaterialData materialData;

    @Autowired
    private RecruitGoodsData recruitGoodsData;

    @Autowired
    private OfficerLvData officerLvData;

    @Autowired
    private UnionRepo unionRepo;

    @Autowired
    private MonsterData monsterData;

    @Autowired
    private MessageInfosRepo messageInfosRepo;

    @Autowired
    private OfficerUnionData officerUnionData;

    @Autowired
    private OfficerUnionRepo officerUnionRepo;

    @Autowired
    private MilitaryRankData militaryRankData;

    @Autowired
    private JdbcSqlRepo jdbcSqlRepo;

    @Autowired
    private BuildingData buildingData;

    @Autowired
    private ChatClientRepo chatClientRepo;

    @Autowired
    private NewRecruitData newRecruitData;

    @Autowired
    private UnionConBoxData unionCoinBoxData;

    @Autowired
    private RegionConBoxData regionConBoxData;

    @Autowired
    private LineupConBoxData lineupConBoxData;

    @Autowired
    private ConstantsPoolData constantsPool;

    @Autowired
    private ChatMsgFactory chatMsgFactory;

    @Autowired
    private FarmlandAndMineData farmlandAndMineData;

    @Autowired
    private BattleEnhanceData battleEnhanceData;

    @Autowired
    private ActivityService activityService;

    @Autowired
    private RechargeHallData rechargeHallData;

    @Autowired
    private MoonWeekCardData moonWeekCardData;

    @Autowired
    private UnionBadgeData unionBadgeData;

    @Autowired
    private TrackDomainService trackDomainService;

    @Autowired
    @Qualifier("jRedis")
    private JRedis jRedis;

    @Autowired
    private UnionTitleData unionTitleData;

    @Autowired
    private RankStepData rankSetpData;

    @Autowired
    private BusinessDomainService businessDomainService;

    @Autowired
    private UpgradeEngine upgradeEngine;

    @Autowired
    private TrackRemoteService trackRemoteService;

    @Autowired
    private MissionRepo missionRepo;

    @Autowired
    private MissionData missionData;

    @Autowired
    private PveAreaRankRepo pveAreaRankRepo;

    @Autowired
    private FriendRepo friendRepo;

    @Autowired
    private UserMilitaryRepoImpl militaryRepo;

    @Autowired
    private MissionEngine missionEngine;

    @Autowired
    private InitUserData initUserData;

    @Autowired
    private WanBaInviteRemoteService wanBaInviteRemoteService;

    @Autowired
    private WanbaV3Support platformService;

    @Autowired
    private RankStepData rankStepData;

    @Autowired
    private SoldierScienceData scienceData;

    @Autowired
    private SoldierScienceRepo soldierScienceRepo;

    public void inject(Soldier soldier) {
        soldier.setSoldierData(soldierData);
    }

    public Army createArmy(Officer officer) {
        Army army = new Army(officer);
        return army;
    }

    public SoldierData getSoldierData() {
        return soldierData;
    }

    public Match createMatch(ActorSequence actorSequence, TargetCollection targetCollection, EnumMap<FightUnitName, FightUnit> fightUnitMap, Formation attFormation,
            Formation defFormation) {
        Match match = new Match(actorSequence, targetCollection, fightUnitMap, attFormation, defFormation);
        match.setBoFactory(this);
        return match;
    }

    public PositionCalculator createPositionCalculator(FightUnit actor, int roundCounter, TargetCollection targetCollection) {
        PositionCalculator calculator = new PositionCalculator(actor, roundCounter, targetCollection);
        calculator.setSoldierData(soldierData);
        return calculator;
    }

    public UserValidation createUserValidation(long userId) {
        UserValidation userValidation = new UserValidation(userId);
        userValidation.setUserRepo(userRepo);
        userValidation.setAntiPluginDomainService(auAntiPluginDomainService);
        return userValidation;
    }

    public void inject(Officer officer) {
        officer.setBoFactory(this);
        officer.setOfficerProperty(officerData.getProperty(officer.getXmlId()));
        officer.setOfficerLvData(officerLvData);
    }

    public Operation createOperation(long userId) {
        Operation op = new Operation(userId);
        op.setLimitationRepo(limitationRepo);
        return op;
    }

    public void inject(Barrack barrack) {
        barrack.setBarrackRepo(barrackRepo);
        barrack.setConstantsPool(constantsPool);
        barrack.setUserData(userData);
        barrack.setSoldierData(soldierData);
        barrack.setBusinessDomainService(businessDomainService);
        barrack.setItemData(itemData);
    }

    public UserLoginProcessor createUserLoginProcessor(String requestInfoStr) {
        UserLoginProcessor processor = new UserLoginProcessor(requestInfoStr);
        processor.setBarrackRepo(barrackRepo);
        processor.setUserRepo(userRepo);
        processor.setItemRepo(itemRepo);
        processor.setBoFactory(this);
        processor.setIndustryRepo(industryRepo);
        processor.setPg(pg);
        processor.setRegionData(regionData);
        processor.setPvpRepo(pvpRepo);
        processor.setSkillData(skillData);
        processor.setSoldierData(soldierData);
        processor.setOfficerUnionData(officerUnionData);
        processor.setOfficerUnionRepo(officerUnionRepo);
        processor.setMilitaryRankData(militaryRankData);
        processor.setJdbcSqlRepo(jdbcSqlRepo);
        processor.setPveRepo(pveRepo);
        processor.setActivityService(activityService);
        processor.setTrackRemoteService(trackRemoteService);
        processor.setPveAreaRankRepo(pveAreaRankRepo);
        processor.setInitUserData(initUserData);
        processor.setSoldierScienceRepo(soldierScienceRepo);
        return processor;
    }

    public WanBaUserLoginProcessor createWanBaUserLoginProcessor(String requestInfoStr) {
        WanBaUserLoginProcessor processor = new WanBaUserLoginProcessor(requestInfoStr, this);
        processor.setBarrackRepo(barrackRepo);
        processor.setUserRepo(userRepo);
        processor.setItemRepo(itemRepo);
        processor.setBoFactory(this);
        processor.setIndustryRepo(industryRepo);
        processor.setPg(pg);
        processor.setRegionData(regionData);
        processor.setPvpRepo(pvpRepo);
        processor.setSkillData(skillData);
        processor.setSoldierData(soldierData);
        processor.setOfficerUnionData(officerUnionData);
        processor.setOfficerUnionRepo(officerUnionRepo);
        processor.setMilitaryRankData(militaryRankData);
        processor.setJdbcSqlRepo(jdbcSqlRepo);
        processor.setPveRepo(pveRepo);
        processor.setActivityService(activityService);
        processor.setTrackRemoteService(trackRemoteService);
        processor.setPveAreaRankRepo(pveAreaRankRepo);
        processor.setInitUserData(initUserData);
        processor.setSoldierScienceRepo(soldierScienceRepo);
        return processor;
    }

    public RecruitOfficerProcessor createRecruitOfficerProcessor(long userId, int type, int num) {
        RecruitOfficerProcessor processor = new RecruitOfficerProcessor(userId, type, num);
        processor.setUserRepo(userRepo);
        processor.setItemRepo(itemRepo);
        processor.setLimitationRepo(limitationRepo);
        processor.setRecruitmentData(recruitmentData);
        processor.setBoFactory(this);
        processor.setPg(pg);
        processor.setChatClientRepo(chatClientRepo);
        processor.setNewRecruitData(newRecruitData);
        processor.setOfficerData(officerData);
        processor.setChatMsgFactory(chatMsgFactory);
        processor.setActivityService(activityService);
        processor.setTrackDomainService(trackDomainService);
        processor.setConstantsPool(constantsPool);
        processor.init();
        return processor;
    }

    public void inject(User user) {
        user.setUserData(userData);
        user.setMilitaryRankData(militaryRankData);
    }

    public void inject(ItemBags itemBags) {
        itemBags.setBoFactory(this);
    }

    public Chapters createChapters(long userId) {
        Chapters chapters = new Chapters(userId);
        chapters.setMaxChapterId(chapterData.idSortArr()[0]);
        inject(chapters);
        return chapters;
    }

    public void inject(Chapters chapters) {
        chapters.setChapterData(chapterData);
        chapters.setPveData(pveData);
    }

    public UserRepo getUserRepo() {
        return userRepo;
    }

    public AntiPluginDomainService getAuAntiPluginDomainService() {
        return auAntiPluginDomainService;
    }

    public LimitationRepo getLimitationRepo() {
        return limitationRepo;
    }

    public BarrackRepo getBarrackRepo() {
        return barrackRepo;
    }

    public ItemRepo getItemRepo() {
        return itemRepo;
    }

    public OfficerData getOfficerData() {
        return officerData;
    }

    public SkillData getSkillData() {
        return skillData;
    }

    public ItemData getItemData() {
        return itemData;
    }

    public EquipData getEquipData() {
        return equipData;
    }

    public SuitData getSuitData() {
        return suitData;
    }

    public void inject(Equips equips) {
        equips.setItemRepo(itemRepo);
        equips.setEquipData(equipData);
    }

    public OfficerRepo getOfficerRepo() {
        return officerRepo;
    }

    public GoodsData getGoodsData() {
        return goodsData;
    }

    public RecruitmentData getRecruitmentData() {
        return recruitmentData;
    }

    public void setPg(ProbabilityGenerator pg) {
        this.pg = pg;
    }

    public Camps createCamps() {
        Camps camps = new Camps();
        inject(camps);
        return camps;
    }

    public void inject(Camps camps) {
        //      camps.setRegionData(regionData);
    }

    public Slaves createSlaves(long userId) {
        Slaves slaves = new Slaves(userId);
        slaves.setIndustryRepo(industryRepo);
        slaves.setConstantsPoolData(constantsPool);
        slaves.setTrackDomainService(trackDomainService);
        slaves.setUserRepo(userRepo);
        return slaves;
    }

    public MatchFightUser createMatchFightUser(User user, PvpUser pvpUser, int rank, Camp camp) {
        MatchFightUser matchFightUser = new MatchFightUser(user, pvpUser, rank, camp);
        matchFightUser.initRepo(pvpRepo, userRepo, buildingData, skillData, pg);
        return matchFightUser;
    }

    public void inject(Captives captives) {
        captives.setOfficerData(officerData);
        captives.setOfficerRepo(officerRepo);
        captives.setBoFactory(this);
    }

    public void inject(Provision provision) {
        provision.setUserData(userData);
        provision.setUserRepo(userRepo);
        provision.setItemRepo(itemRepo);
        provision.setMoonWeekCardData(moonWeekCardData);
        provision.setBusinessDomainService(businessDomainService);
    }

    public MatchArenaUserProcessor createMatchArenaUserProcessor(ArenaUser arenaUser) {
        MatchArenaUserProcessor processor = new MatchArenaUserProcessor(arenaUser);
        processor.setArenaRepo(arenaRepo);
        processor.setBoFactory(this);
        return processor;
    }

    public AwardProcessor createAwardProcessor(long userId, AwardChannel awardChannel) {
        AwardProcessor awardProcessor = new AwardProcessor(awardChannel);
        awardProcessor.setUserId(userId);
        inject(awardProcessor);
        return awardProcessor;
    }

    public void inject(AwardProcessor awardProcessor) {
        awardProcessor.setBoFactory(this);
        awardProcessor.setItemRepo(itemRepo);
        awardProcessor.setUserRepo(userRepo);
        awardProcessor.setUnionCoinBoxData(unionCoinBoxData);
        awardProcessor.setRegionConBoxData(regionConBoxData);
        awardProcessor.setLineupConBoxData(lineupConBoxData);
        awardProcessor.setUpgradeEngine(upgradeEngine);
        awardProcessor.setTrackDomainService(trackDomainService);
    }

    public void inject(ArenaUser arenaUser) {
        arenaUser.setBofactory(this);
    }

    public TacticalData getTacticalData() {
        return tacticalData;
    }

    public MaterialData getMaterialData() {
        return materialData;
    }

    public PveData getPveData() {
        return pveData;
    }

    public ProbabilityGenerator getPg() {
        return pg;
    }

    public ChapterData getChapterData() {
        return chapterData;
    }

    public BattleObjFoctory getBattleObjFoctory() {
        return battleObjFoctory;
    }

    public IndustryRepo getIndustryRepo() {
        return industryRepo;
    }

    public RegionData getRegionData() {
        return regionData;
    }

    public PvpRepo getPvpRepo() {
        return pvpRepo;
    }

    public RankFightRepo getRankFightRepo() {
        return rankFightRepo;
    }

    public UserData getUserData() {
        return userData;
    }

    public ArenaRepo getArenaRepo() {
        return arenaRepo;
    }

    public RecruitGoodsData getRecruitGoodsData() {
        return recruitGoodsData;
    }

    public OfficerLvData getOfficerLvData() {
        return officerLvData;
    }

    public UnionRepo getUnionRepo() {
        return unionRepo;
    }

    public MonsterData getMonsterData() {
        return monsterData;
    }

    public OfficerUnionData getOfficerUnionData() {
        return officerUnionData;
    }

    public FarmlandAndMineData getFarmlandAndMineData() {
        return farmlandAndMineData;
    }

    public OfficerEnhancePotion createOfficerEnhancePotion(long userId) {
        OfficerEnhancePotion officerEnhancePotion = new OfficerEnhancePotion(userId);
        inject(officerEnhancePotion);
        return officerEnhancePotion;
    }

    public void inject(OfficerEnhancePotion officerEnhancePotion) {
        officerEnhancePotion.setBattleEnhanceData(battleEnhanceData);
        officerEnhancePotion.setItemData(itemData);
    }

    public Officer createOfficer(long userId, byte[] data) {
        OfficerFactory officerFactory = createOfficerFactory(userId);
        officerFactory.setData(data);
        return officerFactory.createOfficer(false);
    }

    public List<Officer> createOfficers(long userId, Map<Long, byte[]> members) {
        List<Officer> officers = Lists.newArrayListWithExpectedSize(members.size());
        OfficerFactory officerFactory = createOfficerFactory(userId);
        for (Entry<Long, byte[]> member : members.entrySet()) {
            officerFactory.setData(member.getValue());

            officers.add(officerFactory.createOfficer(true));
        }
        return officers;
    }

    public List<Officer> createOfficer(long userId, List<OfficerAward> officerAwards) {
        OfficerFactory officerFactory = createOfficerFactory(userId);

        List<Officer> officerList = Lists.newArrayListWithExpectedSize(officerAwards.size());
        for (OfficerAward officerAward : officerAwards) {
            Officer officer = officerFactory.createOfficer(officerAward);
            officerRepo.saveNewOfficer(officer);

            itemRepo.saveEquips(officerFactory.getAllEquips());

            officerList.add(officer);

            trackDomainService.trackOfficer(userId, officer);
        }
        return officerList;
    }

    public Officer createOfficer(long userId, int xmlId, int station) {
        Equips equips = itemRepo.findEquips(userId);
        Officer officer = new Officer(userId);
        officer.setBoFactory(this);
        officer.setOfficerProperty(officerData.getProperty(officer.getXmlId()));
        officer.setOfficerLvData(officerLvData);

        OfficerProperty property = officerData.getProperty(xmlId);
        officer.initNewOfficer(property);

        int[] equipIds = equips.addNewEquip(officer.getEquipList());
        officer.setEquips(equipIds);
        officer.setStation(station);
        officer.changeShowFightPower();
        officerRepo.saveNewOfficer(officer);
        itemRepo.saveEquips(equips);

        trackDomainService.trackOfficer(userId, officer);
        return officer;
    }

    private OfficerFactory createOfficerFactory(long userId) {
        OfficerFactory officerFactory = new OfficerFactory(userId);
        officerFactory.setAllEquips(itemRepo.findEquips(userId));
        officerFactory.setBarrack(barrackRepo.findBarrack(userId));
        officerFactory.setBoFactory(this);
        officerFactory.setFarmland(industryRepo.findSimpleFarmland(userId));
        officerFactory.setMainCityDefence(pvpRepo.isMainCityDefence(userId));
        officerFactory.setMine(industryRepo.findSimpleMine(userId));
        officerFactory.setOfficerData(officerData);
        officerFactory.setOfficerLvData(officerLvData);
        officerFactory.setOfficerUnionOpen(businessDomainService.isFunctionOpen(userId, OfficerUnionRemoteService.BUILDING_ID));
        officerFactory.setOfficerUnions(officerUnionRepo.findOfficerUnions(userId));
        officerFactory.setEnhancePotion(itemRepo.findOfficerEnhancePotion(userId));
        officerFactory.setUserRepo(userRepo);

        UnionUser unionUser = unionRepo.findUnionUser(userId);
        if (unionUser != null) {
            officerFactory.setUnionUser(unionUser);
            officerFactory.setUnion(unionRepo.findUnion(unionUser.getUnionId()));
        }
        return officerFactory;
    }

    public ArenaUser createArenaUserr(long userId, byte[] o) {
        ArenaUser arenaUser = new ArenaUser(userId, o);
        arenaUser.setBofactory(this);
        return arenaUser;
    }

    public BattleEnhanceData getBattleEnhanceData() {
        return battleEnhanceData;
    }

    public RechargeHallData getRechargeHallData() {
        return rechargeHallData;
    }

    public UnionBadgeData getUnionBadgeData() {
        return unionBadgeData;
    }

    public JdbcSqlRepo getJdbcSqlRepo() {
        return jdbcSqlRepo;
    }

    public JRedis getjRedis() {
        return jRedis;
    }

    public void setjRedis(JRedis jRedis) {
        this.jRedis = jRedis;
    }

    public UnionTitleData getUnionTitleData() {
        return unionTitleData;
    }

    public RankStepData getRankSetpData() {
        return rankSetpData;
    }

    public ConstantsPoolData getConstantsPool() {
        return constantsPool;
    }

    public MissionRepo getMissionRepo() {
        return missionRepo;
    }

    public void setMissionRepo(MissionRepo missionRepo) {
        this.missionRepo = missionRepo;
    }

    public MissionData getMissionData() {
        return missionData;
    }

    public void setMissionData(MissionData missionData) {
        this.missionData = missionData;
    }

    public OfficerUnionRepo getOfficerUnionRepo() {
        return officerUnionRepo;
    }

    public void setOfficerUnionRepo(OfficerUnionRepo officerUnionRepo) {
        this.officerUnionRepo = officerUnionRepo;
    }

    public PveRepo getPveRepo() {
        return this.pveRepo;
    }

    public TrackDomainService getTrackDomainService() {
        return this.trackDomainService;
    }

    public PveAreaRankRepo getPveAreaRankRepo() {
        return pveAreaRankRepo;
    }

    public FriendRepo getFriendRepo() {
        return friendRepo;
    }

    public MilitaryRankData getMilitaryRankData() {
        return militaryRankData;
    }

    public UserMilitaryRepoImpl getMilitaryRepo() {
        return militaryRepo;
    }

    public WanbaV3Support getPlatformService() {
        return platformService;
    }

    public MissionEngine getMissionEngine() {
        return missionEngine;
    }

    public ActivityService getActivityService() {
        return activityService;
    }

    public WanBaInviteRemoteService getWanBaInviteRemoteService() {
        return wanBaInviteRemoteService;
    }

    public RankStepData getRankStepData() {
        return rankStepData;
    }

    public void inject(SoldierTechnologies soldierTechnologies) {
        soldierTechnologies.setScienceData(scienceData);
        soldierTechnologies.setBarrackRepo(barrackRepo);
    }

    public SoldierScienceRepo getSoldierScienceRepo() {
        return soldierScienceRepo;
    }

}
