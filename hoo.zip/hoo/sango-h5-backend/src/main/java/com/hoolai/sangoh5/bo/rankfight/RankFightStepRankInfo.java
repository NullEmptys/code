package com.hoolai.sangoh5.bo.rankfight;

public class RankFightStepRankInfo {

    private long userId;

    private String userName;

    private int userLevel;

    private String unionName;

    private int defenceForce;//防守战力

    private String userImage;

    private int stateId;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(int userLevel) {
        this.userLevel = userLevel;
    }

    public String getUnionName() {
        return unionName;
    }

    public void setUnionName(String unionName) {
        this.unionName = unionName;
    }

    public int getDefenceForce() {
        return defenceForce;
    }

    public void setDefenceForce(int defenceForce) {
        this.defenceForce = defenceForce;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

    public int getStateId() {
        return stateId;
    }

    public void setStateId(int stateId) {
        this.stateId = stateId;
    }

}
