package com.hoolai.sangoh5.repo;

import com.hoolai.sangoh5.bo.adddesktopstatus.AddDesktopStatus;

public interface AddDesktopRepo {
	
	public AddDesktopStatus findAddDesktop(long userId);

	public void saveAddDesktop(AddDesktopStatus addDesktopStatus);
}
