package com.hoolai.sangoh5.bo.equip.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class SuitsProperty extends JsonProperty{
	
	private String name;
	private int suitStage;
	private String suitAttribute;
	private float suitPercentage;
	private int suitValue;
	private int[] intensifyMaxId;
	private int needIntensifyNum;
	private int lv;
	private int diamonds;
	
	
	public int getSuitStage() {
		return suitStage;
	}
	public void setSuitStage(int suitStage) {
		this.suitStage = suitStage;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSuitAttribute() {
		return suitAttribute;
	}
	public void setSuitAttribute(String suitAttribute) {
		this.suitAttribute = suitAttribute;
	}
	public float getSuitPercentage() {
		return suitPercentage;
	}
	public void setSuitPercentage(float suitPercentage) {
		this.suitPercentage = suitPercentage;
	}
	public int getSuitValue() {
		return suitValue;
	}
	public void setSuitValue(int suitValue) {
		this.suitValue = suitValue;
	}
	public int[] getIntensifyMaxId() {
		return intensifyMaxId;
	}
	public void setIntensifyMaxId(int[] intensifyMaxId) {
		this.intensifyMaxId = intensifyMaxId;
	}
	public int getNeedIntensifyNum() {
		return needIntensifyNum;
	}
	public void setNeedIntensifyNum(int needIntensifyNum) {
		this.needIntensifyNum = needIntensifyNum;
	}
	public int getLv() {
		return lv;
	}
	public void setLv(int lv) {
		this.lv = lv;
	}
	public int getDiamonds() {
		return diamonds;
	}
	public void setDiamonds(int diamonds) {
		this.diamonds = diamonds;
	}
	
}
