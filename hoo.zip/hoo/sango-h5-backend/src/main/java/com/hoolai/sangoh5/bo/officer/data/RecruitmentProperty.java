package com.hoolai.sangoh5.bo.officer.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

/**
 * 招募配置表
 * 
 * @author
 *
 */
public class RecruitmentProperty extends JsonProperty {

    /*单次蓝田玉招募**/
    private int diamondRecruitCost;

    /*10次蓝田玉招募**/
    private int diamondTenRecruitCost;

    /*单次月光石招募**/
    private int moonstoneRecruitCost;

    /*10次月光石招募**/
    private int moonstoneTenRecruitCost;

    public int getDiamondRecruitCost() {
        return diamondRecruitCost;
    }

    public void setDiamondRecruitCost(int diamondRecruitCost) {
        this.diamondRecruitCost = diamondRecruitCost;
    }

    public int getDiamondTenRecruitCost() {
        return diamondTenRecruitCost;
    }

    public void setDiamondTenRecruitCost(int diamondTenRecruitCost) {
        this.diamondTenRecruitCost = diamondTenRecruitCost;
    }

    public int getMoonstoneRecruitCost() {
        return moonstoneRecruitCost;
    }

    public void setMoonstoneRecruitCost(int moonstoneRecruitCost) {
        this.moonstoneRecruitCost = moonstoneRecruitCost;
    }

    public int getMoonstoneTenRecruitCost() {
        return moonstoneTenRecruitCost;
    }

    public void setMoonstoneTenRecruitCost(int moonstoneTenRecruitCost) {
        this.moonstoneTenRecruitCost = moonstoneTenRecruitCost;
    }

}
