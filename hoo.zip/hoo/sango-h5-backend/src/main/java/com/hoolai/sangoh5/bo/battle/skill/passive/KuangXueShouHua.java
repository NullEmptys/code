package com.hoolai.sangoh5.bo.battle.skill.passive;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.KuangXueShouHuaBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/*
 * 当将领生命值降低到30%时，进行兽化变身，变身后回复自身生命值上限的30%
 */
public class KuangXueShouHua extends AttributeEnhanceSkill {

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {
        actor.addAfterActionBuff(new KuangXueShouHuaBuff(xmlId, actor.name(), actor, this, Effect.MONITORING_BUFF_LEVEL, false).withKeepBuff().withRepeatCount(MaxRepeatCount)
                .withActorName(actor.name()).withTargetName(actor.name()));
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]");
    }

    @Override
    public Skill clone() {
        return super.clone(new KuangXueShouHua());
    }
}
