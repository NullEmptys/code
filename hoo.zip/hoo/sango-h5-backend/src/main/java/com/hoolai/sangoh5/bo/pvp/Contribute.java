package com.hoolai.sangoh5.bo.pvp;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.ContributeProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Contribute implements ProtobufSerializable<ContributeProto> {

    public enum PvpBattleType {
        occupy, rescue, resumed, revenge;

        public static PvpBattleType convertPvpBattleType(int index) {
            for (PvpBattleType pvpBattleType : values()) {
                if (pvpBattleType.ordinal() == index) {
                    return pvpBattleType;
                }
            }
            throw new BusinessException(ErrorCode.NO_THIS_TYPE);
        }
    }

    /** 天数 **/
    private int day;

    /** 攻击次数 **/
    private int attackNum;

    /** 防御次数 **/
    private int defenceNum;

    /** 解救次数 **/
    private int rescueNum;

    /** 州贡献奖励是否领取 **/
    private boolean state;

    /** 联盟贡献奖是否领取 **/
    private boolean union;

    public Contribute(ContributeProto message) {
        copyFrom(message);
    }

    public Contribute(int day) {
        this.day = day;
    }

    public int getDay() {
        return day;
    }

    public int getAttackNum() {
        return attackNum;
    }

    public int getDefenceNum() {
        return defenceNum;
    }

    public int getRescueNum() {
        return rescueNum;
    }

    public boolean isUnion() {
        return union;
    }

    public boolean isState() {
        return state;
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            ContributeProto message = ContributeProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(ContributeProto message) {
        this.day = message.getDay();
        this.attackNum = message.getAttackNum();
        this.defenceNum = message.getDefenceNum();
        this.rescueNum = message.getRescueNum();
        this.state = message.getState();
        this.union = message.getUnion();
    }

    @Override
    public ContributeProto copyTo() {
        ContributeProto.Builder builder = ContributeProto.newBuilder();
        builder.setDay(day);
        builder.setAttackNum(attackNum);
        builder.setDefenceNum(defenceNum);
        builder.setRescueNum(rescueNum);
        builder.setState(state);
        builder.setUnion(union);
        return builder.build();
    }

    public void addAttackNum() {
        this.attackNum += 1;
    }

    public void addDefenceNum() {
        this.defenceNum += 1;
    }

    public void addRescueNum() {
        this.rescueNum += 1;
    }

    public int getContribute() {
        return attackNum + defenceNum + rescueNum;
    }

    public boolean drawedUnionGift() {
        return this.union;
    }

    public void drawUnionGift() {
        this.union = true;
    }

    public boolean drawedStateGift() {
        return this.state;
    }

    public void drawStateGift() {
        this.state = true;
    }

    public void changeNum(String attackNum, String defenceNum, String rescueNum) {
        this.attackNum = Integer.valueOf(attackNum);
        this.defenceNum = Integer.valueOf(defenceNum);
        this.rescueNum = Integer.valueOf(rescueNum);
    }

}
