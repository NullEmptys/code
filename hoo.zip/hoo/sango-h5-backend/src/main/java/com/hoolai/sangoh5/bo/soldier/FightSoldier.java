package com.hoolai.sangoh5.bo.soldier;

import org.apache.commons.lang.ArrayUtils;

import com.google.protobuf.GeneratedMessage;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.BarrackProtocolBuffer.FightSoldierProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class FightSoldier extends Soldier implements ProtobufSerializable {

    private int originalNum; //士兵的原始带兵数量

    private int lostPoint;

    private int revivalNum;

    private float skillRevivalRate;

    private int pos;

    private int[] initPos;

    private float attack;

    private float defence;

    public FightSoldier(Soldier soldier, int pos) {
        super(soldier.findSoldierType(), soldier.getXmlId(), soldier.getBaseNum());
        this.originalNum = soldier.getNum();
        this.num = originalNum;
        this.moveSpeed = soldier.getMoveSpeed();
        this.attackSpeed = soldier.getAttackSpeed();
        this.baseAttack = soldier.getBaseAttack();
        this.baseDefence = soldier.getBaseDefence();
        this.skills = soldier.getSkills();
        this.pos = pos;
    }

    public FightSoldier(FightSoldierProto fs) {
        copyFrom(fs);
    }

    public void enhanceAttackAndDefence(float attack, float defence) {
        this.attack = attack;
        this.defence = defence;
    }

    public int remainNum() {
        return Math.min(this.originalNum, this.originalNum - this.lostPoint + this.revivalNum);
    }

    public int getLostPoint() {
        return lostPoint;
    }

    public void setLostPoint(int lostPoint) {
        this.lostPoint = lostPoint;
    }

    public int getRevivalNum() {
        return revivalNum;
    }

    public void setRevivalNum(int revivalNum) {
        this.revivalNum = revivalNum;
    }

    public float getSkillRevivalRate() {
        return skillRevivalRate;
    }

    public void setSkillRevivalRate(float skillRevivalRate) {
        this.skillRevivalRate = skillRevivalRate;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public int onHpLost(int lostP) {
        int lostHp = Math.min(remainNum(), lostP);
        lostPoint = Math.min(originalNum, Math.max(lostP + lostPoint, 0));

        return lostHp;
    }

    public void onHpRevival(int revivalPoint) {
        this.lostPoint = Math.max(0, this.lostPoint - revivalPoint);
    }

    public int getOriginalNum() {
        return originalNum;
    }

    public void setOriginalNum(int originalNum) {
        this.originalNum = originalNum;
    }

    public float getAttack() {
        return attack;
    }

    public void setAttack(float attack) {
        this.attack = attack;
    }

    public float getDefence() {
        return defence;
    }

    public void setDefence(float defence) {
        this.defence = defence;
    }

    @Override
    public int[] getSkills() {
        return skills;
    }

    @Override
    public void setSkills(int[] skills) {
        this.skills = skills;
    }

    @Override
    public void copyFrom(GeneratedMessage arg0) {
        FightSoldierProto message = (FightSoldierProto) arg0;
        this.lostPoint = message.getLostPoint();
        this.originalNum = message.getOriginalNum();
        this.revivalNum = message.getRevivalNum();
        this.skillRevivalRate = message.getSkillRevivalRate();
        if (message.hasSoldierType() && message.getSoldierType() > 0) {
            this.soldierType = SoldierType.valueOf(message.getSoldierType());
        }
        this.attackSpeed = message.getAttackSpeed();
        this.num = message.getNum();
        this.moveSpeed = message.getMoveSpeed();
        this.xmlId = message.getXmlId();
        this.pos = message.getPos();
        this.attack = message.getAttack();
        this.defence = message.getDefence();

        int count = message.getInitPosCount();
        if (count > 1) {
            int x = message.getInitPos(0);
            int y = message.getInitPos(1);
            this.initPos = new int[] { x, y };
        }
        if (message.getSkillsCount() > 0) {
            int c = message.getSkillsCount();
            this.skills = new int[c];
            for (int i = 0; i < c; i++) {
                skills[i] = message.getSkills(i);
            }
        }

    }

    public int[] getInitPos() {
        return initPos;
    }

    public void setInitPos(int[] initPos) {
        this.initPos = initPos;
    }

    @Override
    public FightSoldierProto copyTo() {
        FightSoldierProto.Builder builder = FightSoldierProto.newBuilder();
        builder.setLostPoint(lostPoint);
        builder.setOriginalNum(originalNum);
        builder.setRevivalNum(revivalNum);
        builder.setSkillRevivalRate(skillRevivalRate);
        builder.setSoldierType(this.soldierType.value());
        builder.setNum(num);
        builder.setXmlId(xmlId);
        builder.setAttackSpeed(attackSpeed);
        builder.setMoveSpeed(moveSpeed);
        builder.setPos(pos);
        builder.setAttack(attack);
        builder.setDefence(defence);

        if (!ArrayUtils.isEmpty(initPos)) {
            builder.addInitPos(initPos[0]);
            builder.addInitPos(initPos[1]);
        }
        if (skills != null && skills.length > 0) {
            for (int skill : skills) {
                builder.addSkills(skill);
            }
        }
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] arg0) {
        try {
            FightSoldierProto message = FightSoldierProto.parseFrom(arg0);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }
}
