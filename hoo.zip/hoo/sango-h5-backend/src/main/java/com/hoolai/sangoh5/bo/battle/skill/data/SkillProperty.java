package com.hoolai.sangoh5.bo.battle.skill.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class SkillProperty extends JsonProperty {

    private int skillId;

    private String name;

    private int level;

    private String caster;

    private String occasion;

    private String force;

    private String unit;

    private String attribute;

    private float percentage;

    private int value;

    private float chance;

    private String type;

    private int repeat;

    private String twoAttribute;

    private float twoPercentage;

    private int twoValue;

    private int twoRepeat;

    private int twoImpactId;

    private String direction;

    private int[] range;

    private String core;

    private String icon;

    private String description;

    private int round;

    private int borderColor;

    private String subType;

    private int useCon;

    private int fight;

    private int skillLv;

    private int nextLv;

    public int getSkillId() {
        return skillId;
    }

    public void setSkillId(int skillId) {
        this.skillId = skillId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getOccasion() {
        return occasion;
    }

    public void setOccasion(String occasion) {
        this.occasion = occasion;
    }

    public String getForce() {
        return force;
    }

    public void setForce(String force) {
        this.force = force;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public float getPercentage() {
        return percentage;
    }

    public void setPercentage(float percentage) {
        this.percentage = percentage;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public float getChance() {
        return chance;
    }

    public void setChance(float chance) {
        this.chance = chance;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getRepeat() {
        return repeat;
    }

    public void setRepeat(int repeat) {
        this.repeat = repeat;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public int[] getRange() {
        return range;
    }

    public void setRange(int[] range) {
        this.range = range;
    }

    public String getCore() {
        return core;
    }

    public void setCore(String core) {
        this.core = core;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public int getBorderColor() {
        return borderColor;
    }

    public void setBorderColor(int borderColor) {
        this.borderColor = borderColor;
    }

    public String getCaster() {
        return caster;
    }

    public void setCaster(String caster) {
        this.caster = caster;
    }

    public String getTwoAttribute() {
        return twoAttribute;
    }

    public void setTwoAttribute(String twoAttribute) {
        this.twoAttribute = twoAttribute;
    }

    public float getTwoPercentage() {
        return twoPercentage;
    }

    public void setTwoPercentage(float twoPercentage) {
        this.twoPercentage = twoPercentage;
    }

    public int getTwoValue() {
        return twoValue;
    }

    public void setTwoValue(int twoValue) {
        this.twoValue = twoValue;
    }

    public int getTwoRepeat() {
        return twoRepeat;
    }

    public void setTwoRepeat(int twoRepeat) {
        this.twoRepeat = twoRepeat;
    }

    public int getTwoImpactId() {
        return twoImpactId;
    }

    public void setTwoImpactId(int twoImpactId) {
        this.twoImpactId = twoImpactId;
    }

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public int getUseCon() {
        return useCon;
    }

    public void setUseCon(int useCon) {
        this.useCon = useCon;
    }

    public int getFight() {
        return fight;
    }

    public void setFight(int fight) {
        this.fight = fight;
    }

    public int getSkillLv() {
        return skillLv;
    }

    public void setSkillLv(int skillLv) {
        this.skillLv = skillLv;
    }

    public int getNextLv() {
        return nextLv;
    }

    public void setNextLv(int nextLv) {
        this.nextLv = nextLv;
    }

}
