package com.hoolai.sangoh5.bo.farmland.data;

/**
 * 工作奴隶解锁新位置
 * 
 * @author hp
 *
 */
public class UnlockCondition {

    private int characterLv;

    private int landLv;

    public int getCharacterLv() {
        return characterLv;
    }

    public void setCharacterLv(int characterLv) {
        this.characterLv = characterLv;
    }

    public int getLandLv() {
        return landLv;
    }

    public void setLandLv(int landLv) {
        this.landLv = landLv;
    }

}
