package com.hoolai.sangoh5.bo.battle.skill.soldier.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

public class WuShiHuJia extends BaseSoldierPhysicsSkill {

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        FightUnit target = actor.getDefender();
        if (target != null) {
            target.addEffect(new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withDeltaHp(calculateLostPoint(actor, target))
                    .withTargetName(target.name()));
            targets.add(target);
        }

        return targets;
    }

    protected int calculateLostPoint(FightUnit actor, FightUnit target) {
        int baseLostPoint = 0;
        if (target.isOfficer()) {
            baseLostPoint = super
                    .calculateLostPointToOfficer(actor.getOriginalHp(), actor.getAttNum(), actor.attackPoint(), target.attackPoint(),
                            (target.defencePoint() - target.baseDefencePoint() * percentage), target.getOfficerStarLevel(), target.getOfficerLevel(),
                            super.getRestraintRate(actor, target));
        } else {
            baseLostPoint = calculateLostPointToSoldier(actor.getOriginalHp(), actor.getAttNum(), actor.attackPoint(), target.defencePoint() - target.baseDefencePoint()
                    * percentage, super.getRestraintRate(actor, target));
        }
        //        return randomLostPoint(baseLostPoint);
        return Math.round(baseLostPoint);
    }

    @Override
    public Skill clone() {
        return super.clone(new WuShiHuJia());
    }

}
