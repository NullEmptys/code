package com.hoolai.sangoh5.event.event;

import com.hoolai.sangoh5.bo.user.User;
import com.hoolai.sangoh5.event.EventType;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 17:55
 * @version : 1.0
 */
public class PvpoccupiedEvent extends UserEvent {

    private final boolean attackWin;

    public PvpoccupiedEvent(User owner, boolean attackWin) {
        super(owner);
        this.attackWin = attackWin;
    }

    @Override
    public EventType getType() {
        return EventType.Pvpoccupied;
    }

    public boolean isAttackWin() {
        return attackWin;
    }

}
