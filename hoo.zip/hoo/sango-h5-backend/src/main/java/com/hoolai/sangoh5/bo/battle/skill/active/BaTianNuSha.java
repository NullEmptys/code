package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.ChangeDefenseBuff;
import com.hoolai.sangoh5.bo.battle.fight.Action;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 霸天戮杀
 * 
 * 范围内固定伤害且持续性防御力降低
 * 
 * @author Administrator
 *
 */
@Deprecated
public class BaTianNuSha extends IndependentSkill {

    @Override
    public Skill clone() {
        return super.clone(new BaTianNuSha());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {
        List<FightUnit> targets = new ArrayList<FightUnit>();

        List<FightUnit> aliveMap = aliveTargetUnitList(tc, actor);
        for (FightUnit target : aliveMap) {
            Effect effect = rangeHurt(actor, currentLevel, target);
            Buff buff = keepHurt(actor, currentLevel, target);
            targets.add(target);
            targetDefence(actor, target, effect, buff, tc, targets, currentLevel);
        }
        return targets;
    }

    /**
     * 持续伤害
     * 
     * @param actor
     * @param currentLevel
     * @param target
     */
    private Buff keepHurt(FightUnit actor, int currentLevel, FightUnit target) {
        Buff buff = target.findBuff(this.xmlId);
        if (buff == null) {
            buff = new ChangeDefenseBuff(xmlId, name, target.name(), actor, forceType, Action.DEFAULT_ACTION_LEVEL, twoPercentage).withKeepBuff().withActorName(actor.name())
                    .withTargetName(target.name()).withRepeatCount(twoRepeatCount);
            buff.apply(target);
            target.addBuff(buff);
        } else {
            buff.setRepeatCount(twoRepeatCount);
        }
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "降低防御力=" + twoPercentage + ",持续回合数=" + twoRepeatCount);
        return buff;
    }

    /**
     * 范围内伤害
     * 
     * @param actor
     * @param currentLevel
     * @param referPos
     * @param target
     */
    private Effect rangeHurt(FightUnit actor, int currentLevel, FightUnit target) {
        Effect effect = new Effect(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withDeltaHp(Math.round(this.value)).withTargetName(target.name());
        target.addEffect(effect);
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "造成伤害=" + effect.getDeltaHp());
        return effect;
    }
}
