package com.hoolai.sangoh5.bo.officer.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class OfficerProperty extends JsonProperty {

    private int id;

    private String name;

    private String image;

    private String mcName;

    private int type;

    private int gender;

    private int baseAt;

    private int[] atUp;

    private int baseDef;

    private int[] defUp;

    private int baseHp;

    private int[] hpUp;

    private int baseQms;//法伤

    private int[] intUp;//法伤成长值

    private int baseMag;

    private int[] magUp;

    private float baseMaSp;

    private float[] maSpUp;

    private float baseAs;

    private float ms;

    private int res;

    private int country;

    private int generalRank;

    private String description;

    private int soldierAmount;

    private int[] soldierAdd;

    private int talentSkill;

    private int weapon;

    private int armor;

    private int helmet;

    private int horse;

    //	private int onRecruit;
    private int defaultTactical;

    private int[] soldierType;

    private int[] oneXy;

    private int[] twoXy;

    private int[] starItemNum;

    private int[] needLevel;

    private int combinationId;

    private int perseverance;

    private int[] skillBoxLv;

    private int[] tacticalLv;

    private int[] skillLvup;

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getMcName() {
        return mcName;
    }

    public void setMcName(String mcName) {
        this.mcName = mcName;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public float getMs() {
        return ms;
    }

    public void setMs(float ms) {
        this.ms = ms;
    }

    public int getCountry() {
        return country;
    }

    public void setCountry(int country) {
        this.country = country;
    }

    public int getGeneralRank() {
        return generalRank;
    }

    public void setGeneralRank(int generalRank) {
        this.generalRank = generalRank;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int[] getSoldierType() {
        return soldierType;
    }

    public void setSoldierType(int[] soldierType) {
        this.soldierType = soldierType;
    }

    public int getSoldierAmount() {
        return soldierAmount;
    }

    public void setSoldierAmount(int soldierAmount) {
        this.soldierAmount = soldierAmount;
    }

    public int[] getSoldierAdd() {
        return soldierAdd;
    }

    public void setSoldierAdd(int[] soldierAdd) {
        this.soldierAdd = soldierAdd;
    }

    public int getTalentSkill() {
        return talentSkill;
    }

    public void setTalentSkill(int talentSkill) {
        this.talentSkill = talentSkill;
    }

    public int getWeapon() {
        return weapon;
    }

    public void setWeapon(int weapon) {
        this.weapon = weapon;
    }

    public int getArmor() {
        return armor;
    }

    public void setArmor(int armor) {
        this.armor = armor;
    }

    public int getHelmet() {
        return helmet;
    }

    public void setHelmet(int helmet) {
        this.helmet = helmet;
    }

    public int getHorse() {
        return horse;
    }

    public void setHorse(int horse) {
        this.horse = horse;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int[] getIntUp() {
        return intUp;
    }

    public void setIntUp(int[] intUp) {
        this.intUp = intUp;
    }

    public int getRes() {
        return res;
    }

    public void setRes(int res) {
        this.res = res;
    }

    public boolean isHaveSoldier(int soldierType) {
        for (int s : this.soldierType) {
            if (s == soldierType) {
                return true;
            }
        }
        return false;
    }

    public int[] getAtUp() {
        return atUp;
    }

    public void setAtUp(int[] atUp) {
        this.atUp = atUp;
    }

    public int[] getDefUp() {
        return defUp;
    }

    public void setDefUp(int[] defUp) {
        this.defUp = defUp;
    }

    public int[] getHpUp() {
        return hpUp;
    }

    public void setHpUp(int[] hpUp) {
        this.hpUp = hpUp;
    }

    public int[] getMagUp() {
        return magUp;
    }

    public void setMagUp(int[] magUp) {
        this.magUp = magUp;
    }

    public float[] getMaSpUp() {
        return maSpUp;
    }

    public void setMaSpUp(float[] maSpUp) {
        this.maSpUp = maSpUp;
    }

    public int getBaseAt() {
        return baseAt;
    }

    public void setBaseAt(int baseAt) {
        this.baseAt = baseAt;
    }

    public int getBaseDef() {
        return baseDef;
    }

    public void setBaseDef(int baseDef) {
        this.baseDef = baseDef;
    }

    public int getBaseHp() {
        return baseHp;
    }

    public void setBaseHp(int baseHp) {
        this.baseHp = baseHp;
    }

    public int getBaseQms() {
        return baseQms;
    }

    public void setBaseQms(int baseQms) {
        this.baseQms = baseQms;
    }

    public int getBaseMag() {
        return baseMag;
    }

    public void setBaseMag(int baseMag) {
        this.baseMag = baseMag;
    }

    public float getBaseMaSp() {
        return baseMaSp;
    }

    public void setBaseMaSp(float baseMaSp) {
        this.baseMaSp = baseMaSp;
    }

    public float getBaseAs() {
        return baseAs;
    }

    public void setBaseAs(float baseAs) {
        this.baseAs = baseAs;
    }

    public int getDefaultTactical() {
        return defaultTactical;
    }

    public void setDefaultTactical(int defaultTactical) {
        this.defaultTactical = defaultTactical;
    }

    public int[] getOneXy() {
        return oneXy;
    }

    public void setOneXy(int[] oneXy) {
        this.oneXy = oneXy;
    }

    public int[] getTwoXy() {
        return twoXy;
    }

    public void setTwoXy(int[] twoXy) {
        this.twoXy = twoXy;
    }

    public int[] getStarItemNum() {
        return starItemNum;
    }

    public void setStarItemNum(int[] starItemNum) {
        this.starItemNum = starItemNum;
    }

    public int[] getNeedLevel() {
        return needLevel;
    }

    public void setNeedLevel(int[] needLevel) {
        this.needLevel = needLevel;
    }

    public int getCombinationId() {
        return combinationId;
    }

    public void setCombinationId(int combinationId) {
        this.combinationId = combinationId;
    }

    public boolean isHaveOfficerUnion() {
        return combinationId > 0;
    }

    public int getPerseverance() {
        return perseverance;
    }

    public void setPerseverance(int perseverance) {
        this.perseverance = perseverance;
    }

    public int[] getSkillBoxLv() {
        return skillBoxLv;
    }

    public void setSkillBoxLv(int[] skillBoxLv) {
        this.skillBoxLv = skillBoxLv;
    }

    public int[] getTacticalLv() {
        return tacticalLv;
    }

    public void setTacticalLv(int[] tacticalLv) {
        this.tacticalLv = tacticalLv;
    }

    public int[] getSkillLvup() {
        return skillLvup;
    }

    public void setSkillLvup(int[] skillLvup) {
        this.skillLvup = skillLvup;
    }

}
