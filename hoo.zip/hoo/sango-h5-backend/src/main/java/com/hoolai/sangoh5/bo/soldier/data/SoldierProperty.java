package com.hoolai.sangoh5.bo.soldier.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class SoldierProperty extends JsonProperty {

    private String name;

    private int soldierType;

    private float moveSpeed;

    private float attackSpeed;

    private int attackType;

    private int[] baseAttack;

    private int[] baseDefence;

    private OpenCondition openCondition;

    private int upStarAt;

    private int upStarDe;

    private int bornSkill;

    private int isFirstSoldierId;

    private int nextSoldierId;

    private float fight;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getMoveSpeed() {
        return moveSpeed;
    }

    public void setMoveSpeed(float moveSpeed) {
        this.moveSpeed = moveSpeed;
    }

    public float getAttackSpeed() {
        return attackSpeed;
    }

    public void setAttackSpeed(float attackSpeed) {
        this.attackSpeed = attackSpeed;
    }

    public int[] getBaseAttack() {
        return baseAttack;
    }

    public void setBaseAttack(int[] baseAttack) {
        this.baseAttack = baseAttack;
    }

    public int[] getBaseDefence() {
        return baseDefence;
    }

    public void setBaseDefence(int[] baseDefence) {
        this.baseDefence = baseDefence;
    }

    public int getSoldierType() {
        return soldierType;
    }

    public void setSoldierType(int soldierType) {
        this.soldierType = soldierType;
    }

    public int getAttackType() {
        return attackType;
    }

    public void setAttackType(int attackType) {
        this.attackType = attackType;
    }

    public OpenCondition getOpenCondition() {
        return openCondition;
    }

    public void setOpenCondition(OpenCondition openCondition) {
        this.openCondition = openCondition;
    }

    public int getUpStarAt() {
        return upStarAt;
    }

    public void setUpStarAt(int upStarAt) {
        this.upStarAt = upStarAt;
    }

    public int getUpStarDe() {
        return upStarDe;
    }

    public void setUpStarDe(int upStarDe) {
        this.upStarDe = upStarDe;
    }

    public int getBornSkill() {
        return bornSkill;
    }

    public void setBornSkill(int bornSkill) {
        this.bornSkill = bornSkill;
    }

    public int getIsFirstSoldierId() {
        return isFirstSoldierId;
    }

    public void setIsFirstSoldierId(int isFirstSoldierId) {
        this.isFirstSoldierId = isFirstSoldierId;
    }

    public int getNextSoldierId() {
        return nextSoldierId;
    }

    public void setNextSoldierId(int nextSoldierId) {
        this.nextSoldierId = nextSoldierId;
    }

    public float getFight() {
        return fight;
    }

    public void setFight(float fight) {
        this.fight = fight;
    }

}
