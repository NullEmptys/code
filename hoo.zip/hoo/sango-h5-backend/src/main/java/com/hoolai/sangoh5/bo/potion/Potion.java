package com.hoolai.sangoh5.bo.potion;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.PotionProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * 
 * @author Administrator
 *
 */
public class Potion implements ProtobufSerializable<PotionProto>{

	private int xmlId;// 药水的itemId
	
	private long drinkTime;// 药水喝下的时间
	
	private long loseEfficacyTime;// 药水的失效时间
	
	public Potion(){}
	
	public Potion(int xmlId,int times){
		this.xmlId = xmlId;
		this.drinkTime = TimeUtil.currentTimeMillis();
		this.loseEfficacyTime = drinkTime + times * 1000l;
	}

	public Potion(PotionProto message) {
		copyFrom(message);
	}

	public int getXmlId() {
		return xmlId;
	}

	public void setXmlId(int xmlId) {
		this.xmlId = xmlId;
	}

	public long getDrinkTime() {
		return drinkTime;
	}

	public void setDrinkTime(long drinkTime) {
		this.drinkTime = drinkTime;
	}

	public long getLoseEfficacyTime() {
		return loseEfficacyTime;
	}

	public void setLoseEfficacyTime(long loseEfficacyTime) {
		this.loseEfficacyTime = loseEfficacyTime;
	}

	@Override
	public PotionProto copyTo() {
		PotionProto.Builder builder = PotionProto.newBuilder();
		builder.setDrinkTime(drinkTime);
		builder.setLoseEfficacyTime(loseEfficacyTime);
		builder.setXmlId(xmlId);
		return builder.build();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			PotionProto message = PotionProto.parseFrom(bytes);
			copyFrom(message);
		} catch (InvalidProtocolBufferException e) {
			throw new BusinessException(ErrorCode.CAN_NOT_MEM);
		}
	}

	@Override
	public void copyFrom(PotionProto message) {
		this.xmlId = message.getXmlId();
		this.loseEfficacyTime = message.getLoseEfficacyTime();
		this.drinkTime = message.getDrinkTime();
	}
}
