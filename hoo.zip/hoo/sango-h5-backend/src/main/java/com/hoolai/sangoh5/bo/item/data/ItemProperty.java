package com.hoolai.sangoh5.bo.item.data;

import com.hoolai.sangoh5.util.json.JsonProperty;

public class ItemProperty extends JsonProperty {

	private String name;
	private String type;
	private int quantity;
	private int value;
	private int isCanUse;
	private String description;
	private int borderColor;
	private int valueOfDonate;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getIsCanUse() {
		return isCanUse;
	}

	public void setIsCanUse(int isCanUse) {
		this.isCanUse = isCanUse;
	}

	public int getBorderColor() {
		return borderColor;
	}

	public void setBorderColor(int borderColor) {
		this.borderColor = borderColor;
	}

	public int getValueOfDonate() {
		return valueOfDonate;
	}

	public void setValueOfDonate(int valueOfDonate) {
		this.valueOfDonate = valueOfDonate;
	}

}
