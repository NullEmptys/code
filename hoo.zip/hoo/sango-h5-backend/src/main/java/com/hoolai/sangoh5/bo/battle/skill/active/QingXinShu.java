package com.hoolai.sangoh5.bo.battle.skill.active;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.buff.QingXinShuBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 
 * 移除所有队友的控制状态
 * 
 * @author Administrator
 *
 */
public class QingXinShu extends BaseOfficerPhysicsSkill {

    @Override
    public Skill clone() {
        return super.clone(new QingXinShu());
    }

    @Override
    public List<FightUnit> execute(FightUnit actor, TargetCollection tc, int currentLevel) {

        List<FightUnit> alives = aliveTargetUnitList(tc, actor);
        for (FightUnit target : alives) {
            Buff buff = target.findBuff(xmlId);
            if (buff == null) {
                target.addBuff(new QingXinShuBuff(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name()).withKeepBuff()
                        .withRepeatCount(repeatCount));
            } else {
                buff.setRepeatCount(repeatCount);
            }
            target.shieldControl();
            actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]给" + target.name() + "清除控制状态,持续回合数=" + repeatCount);
        }

        return new ArrayList<FightUnit>();
    }

}
