package com.hoolai.sangoh5.bo.shop.data;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class ShopFlushData extends JsonData<ShopFlushProperty> {

    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/shopReset.json", ShopFlushProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(ShopFlushProperty property) {
        // TODO Auto-generated method stub

    }

}
