package com.hoolai.sangoh5.event.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.event.EventType;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-27 17:29
 * @version : 1.0
 */
@Component
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Subscriber {

    /**
     * 事件类型
     * 
     * @return
     */
    public EventType[] value();

    /**
     * 优先级
     * 
     * @return
     */
    public int priority() default 1;
}
