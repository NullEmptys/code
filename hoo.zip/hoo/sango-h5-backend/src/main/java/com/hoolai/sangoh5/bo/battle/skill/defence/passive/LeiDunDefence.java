package com.hoolai.sangoh5.bo.battle.skill.defence.passive;

import java.util.List;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 雷盾的反击技能
 * 
 * @author liqing
 *
 */
public class LeiDunDefence extends DefencePassiveSkill {

    private int maxAttackNum;

    private int alreayAttackNum;

    @Override
    public void defence(FightUnit actor, FightUnit target, Effect effect, Buff buff, TargetCollection tc, List<FightUnit> targets, int currentLevel) {
        //        if (effect == null || effect.getDeltaHp() < 1 || actor.isDead() || target.isDead()) {
        //            return;
        //        }
        //        if (alreayAttackNum >= maxAttackNum) {
        //            // TODO 在这移除有错，先不移除，只是返回，对战斗不产生影响,重新触发的时候会reset
        //            //			target.removeCounterAttackSkills(this);
        //
        //            List<FightUnit> fightUnits = aliveTargetUnitList(tc, target);
        //            for (FightUnit fightUnit : fightUnits) {
        //                fightUnit.removeBuff(xmlId, target.name());
        //            }
        //            return;
        //        }
        //        alreayAttackNum++;
        //
        //        int oldDelHp = effect.getDeltaHp();
        //        int counterattackHp = (int) (oldDelHp * (1 - this.percentage));
        //        effect.setDeltaHp(counterattackHp);
        //
        //        // 在此需要加个buff告诉前端我抵御了
        //        target.addBuff(new Buff(xmlId, name, target.name(), currentLevel).withActorName(actor.name()).withTargetName(target.name()));
        //
        //        target.addBattleLog(target.name() + "使用" + this.xmlId + "[" + this.name + "]第" + alreayAttackNum + "次防御了" + actor.name() + "的伤害，old=" + oldDelHp + ",new="
        //                + effect.getDeltaHp());
    }

    @Override
    public Skill clone() {
        return super.clone(new LeiDunDefence(xmlId, maxAttackNum));
    }

    public LeiDunDefence(int xmlId, int attackNum) {
        this.xmlId = xmlId;
        this.maxAttackNum = attackNum;
    }

    public void reset(int attackNum) {
        this.maxAttackNum = attackNum;
        this.alreayAttackNum = 0;
    }

}
