package com.hoolai.sangoh5.bo.pvp;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.PersonalMedalProto;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.PersonalMedalProto.Builder;
import com.hoolai.sangoh5.bo.pvp.data.PersonalMedalProperty;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-04-28 10:23
 * @version : 1.0
 */
public class PersonalMedal implements ProtobufSerializable<PersonalMedalProto> {

    /** 勋章 id **/
    private int medalId;

    /** 完成次数 **/
    private int completeCount;

    /** 0未完成 1 是完成 **/
    private boolean status;

    /** 完成顺序 **/
    private int order;

    public PersonalMedal(int medalId) {
        this.medalId = medalId;
        this.completeCount = 0;
        this.status = false;
        this.order = 0;
    }

    public PersonalMedal(PersonalMedalProto personalMedals) {
        this.copyFrom(personalMedals);
    }

    public int getMedalId() {
        return medalId;
    }

    public void setMedalId(int medalId) {
        this.medalId = medalId;
    }

    public int getCompleteCount() {
        return completeCount;
    }

    public void setCompleteCount(int completeCount) {
        this.completeCount = completeCount;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    @Override
    public PersonalMedalProto copyTo() {
        Builder newBuilder = PersonalMedalProto.newBuilder();
        newBuilder.setMedalId(medalId);
        newBuilder.setCompleteCount(completeCount);
        newBuilder.setStatus(status);
        newBuilder.setOrder(order);
        return newBuilder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            PersonalMedalProto message = PersonalMedalProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(PersonalMedalProto message) {
        this.medalId = message.getMedalId();
        this.completeCount = message.getCompleteCount();
        this.status = message.getStatus();
        this.order = message.getOrder();
    }

    public boolean finished() {
        return this.status;
    }

    public void count() {
        this.completeCount++;
    }

    public void resetCount() {
        this.completeCount = 0;
    }

    public boolean finish(PersonalMedalProperty property) {
        this.status = property.isFinish(completeCount);
        return this.status;
    }

}
