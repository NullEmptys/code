package com.hoolai.sangoh5.bo.battle.unit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.BarrackProtocolBuffer.ArmyProto;
import com.hoolai.sangoh5.bo.battle.fight.HpLostListener;
import com.hoolai.sangoh5.bo.officer.Officer;
import com.hoolai.sangoh5.bo.soldier.FightSoldier;
import com.hoolai.sangoh5.bo.soldier.Soldier;
import com.hoolai.sangoh5.bo.soldier.SoldierType;
import com.hoolai.sangoh5.bo.tacticalManagement.Formation;
import com.hoolai.sangoh5.bo.tacticalManagement.FormationPos;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class Army implements HpLostListener, ProtobufSerializable<ArmyProto> {

    private List<FightSoldier> fightSoldiers;

    /** 当前损失的士兵总数 */
    private int currLostPoint;

    public Army() {
        fightSoldiers = new ArrayList<FightSoldier>();
    }

    public Army(ArmyProto proto) {
        copyFrom(proto);
    }

    public Army(Officer officer) {
        this();
        Formation formation = officer.getCurrFormation();
        List<FormationPos> formationPoses = formation.getCorps();
        for (FormationPos formationPos : formationPoses) {
            if (!formationPos.isOfficer()) {
                Soldier soldier = officer.findSoldier(formationPos.getSoldierType());
                if (soldier == null) {
                    throw new BusinessException(ErrorCode.NO_SOLDIER);
                }
                FightSoldier fightSoldier = new FightSoldier(soldier, formationPos.getPosInt());
                this.fightSoldiers.add(fightSoldier);
            }
        }
    }

    public Map<SoldierType, FightSoldier> changeListToMap() {
        Map<SoldierType, FightSoldier> map = new HashMap<SoldierType, FightSoldier>();
        for (FightSoldier fightSoldier : fightSoldiers) {
            map.put(fightSoldier.findSoldierType(), fightSoldier);
        }
        return map;
    }

    /** 损失百分比 */
    @Override
    public float lostPercentage() {
        int lostPoint = 0;
        int originalNum = 0;
        for (FightSoldier fightSoldier : fightSoldiers) {
            lostPoint += fightSoldier.getLostPoint();
            originalNum += fightSoldier.getOriginalNum();
        }
        return (Float.valueOf(lostPoint) * 100f) / Float.valueOf(originalNum);
    }

    @Override
    public void onHpLost(FightUnitName name, int lostPoint) {
        int lostHp = 0;
        for (FightSoldier fightSoldier : fightSoldiers) {
            if (fightSoldier.getPos() == name.info().getPos()) {
                lostHp = fightSoldier.onHpLost(lostPoint);
            }
        }
        currLostPoint += lostHp;
    }

    @Override
    public int getCurrLostPoint() {
        return currLostPoint;
    }

    public void clearCurrLostPoint() {
        currLostPoint = 0;
    }

    @Override
    public void onHpRevival(FightUnitName name, int revivalPoint) {
        for (FightSoldier fightSoldier : fightSoldiers) {
            if (fightSoldier.getPos() == name.info().getPos()) {
                fightSoldier.onHpRevival(revivalPoint);
            }
        }
    }

    public int findSoldierNumber() {
        int num = 0;
        for (FightSoldier fightSoldier : fightSoldiers) {
            num += fightSoldier.getOriginalNum();
        }
        return num;
    }

    public int findRemainSoldierNumber() {
        int num = 0;
        for (FightSoldier fightSoldier : fightSoldiers) {
            num += fightSoldier.remainNum();
        }
        return num;
    }

    public int findRealLostSoliders() {
        return Math.max(0, lostSoldiersNum() - revivalSoldiersNum());
    }

    private int lostSoldiersNum() {
        int lostHp = 0;
        for (FightSoldier fightSoldier : fightSoldiers) {
            lostHp += fightSoldier.getLostPoint();
        }
        return lostHp;
    }

    private int revivalSoldiersNum() {
        int revivalHp = 0;
        for (FightSoldier fightSoldier : fightSoldiers) {
            revivalHp += fightSoldier.getLostPoint();
        }
        return revivalHp;
    }

    public List<FightSoldier> getFightSoldiers() {
        return fightSoldiers;
    }

    public void setFightSoldiers(List<FightSoldier> fightSoldiers) {
        this.fightSoldiers = fightSoldiers;
    }

    public void setCurrLostPoint(int currLostPoint) {
        this.currLostPoint = currLostPoint;
    }

    public boolean hasRemainSoldiers() {
        return findRemainSoldierNumber() > 0;
    }

    @Override
    public void copyFrom(ArmyProto message) {
        this.currLostPoint = message.getCurrLostPoint();
        int count = message.getFightSoldierProtoCount();
        this.fightSoldiers = new ArrayList<FightSoldier>(count);
        if (count > 0) {
            for (int i = 0; i < count; i++) {
                this.fightSoldiers.add(new FightSoldier(message.getFightSoldierProto(i)));
            }
        }
    }

    @Override
    public ArmyProto copyTo() {
        ArmyProto.Builder builder = ArmyProto.newBuilder();
        builder.setCurrLostPoint(currLostPoint);
        if (fightSoldiers != null && fightSoldiers.size() > 0) {
            for (FightSoldier w : fightSoldiers) {
                builder.addFightSoldierProto(w.copyTo());
            }
        }
        return builder.build();
    }

    @Override
    public void parseFrom(byte[] arg0) {
        try {
            ArmyProto message = ArmyProto.parseFrom(arg0);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

}
