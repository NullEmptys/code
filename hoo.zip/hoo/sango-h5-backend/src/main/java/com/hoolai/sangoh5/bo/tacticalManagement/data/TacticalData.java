package com.hoolai.sangoh5.bo.tacticalManagement.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.hoolai.sangoh5.bo.battle.BattleObjFoctory;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.ForceDirection;
import com.hoolai.sangoh5.bo.battle.skill.ForceType;
import com.hoolai.sangoh5.bo.battle.skill.ForceUnitType;
import com.hoolai.sangoh5.bo.battle.skill.Occasion;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.skill.SkillType;
import com.hoolai.sangoh5.bo.battle.skill.passive.PassiveHurtEnhance;
import com.hoolai.sangoh5.util.json.JsonData;

@Component
public class TacticalData extends JsonData<TacticalProperty> {

    @Override
    @PostConstruct
    public void init() {
        try {
            initData("com/hoolai/sangoh5/tactical.json", TacticalProperty.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void checkProperty(TacticalProperty property) {
        // TODO Auto-generated method stub

    }

    public float getRestraintRate(int actorFormationId, int targetFormationId) {
        TacticalProperty property = getProperty(actorFormationId);

        String[] type = property.getResProperty();
        int[] resVals = property.getResValPer();
        int[] resTac = property.getResTac();
        for (int index = 0; index < resTac.length; index++) {
            if (resTac[index] == targetFormationId) {
                if ("hurtAdd".equals(type[index])) {
                    return 1 + Float.valueOf(resVals[index]) / 100f;
                } else {
                    return 1 - Float.valueOf(resVals[index]) / 100f;
                }
            }
        }

        return 1;
    }

    public List<Skill> getEnhanceSkill(int ownerFormationId, int ownerFormationLv, BattleObjFoctory battleObjFoctory) {

        TacticalProperty property = getProperty(ownerFormationId);

        List<Skill> skills = new ArrayList<Skill>();
        String[] tacp = property.getTacProperty();

        int[] pers = property.getPer(ownerFormationLv);
        int[] values = property.getValue(ownerFormationLv);

        for (int i = 0; i < tacp.length; i++) {
            String type = tacp[i];
            Skill enhance = null;
            switch (type) {
                case "officerHur":
                    enhance = new PassiveHurtEnhance();
                    enhance.setXmlId(ownerFormationId);
                    enhance.setAttributeType(AttributeType.HURT);
                    enhance.setForceType(ForceType.ENEMY);
                    enhance.setForceUnitType(ForceUnitType.OFFICER_SOLDIERS);
                    enhance.setAttackUnitType(ForceUnitType.OFFICER);
                    break;
                case "remoteSolHur":
                    enhance = new PassiveHurtEnhance();
                    enhance.setXmlId(ownerFormationId);
                    enhance.setAttributeType(AttributeType.HURT);
                    enhance.setForceType(ForceType.ENEMY);
                    enhance.setForceUnitType(ForceUnitType.OFFICER_SOLDIERS);
                    enhance.setAttackUnitType(ForceUnitType.LONG_RANGE);
                    break;
                case "meleeCreHur":
                    enhance = new PassiveHurtEnhance();
                    enhance.setXmlId(ownerFormationId);
                    enhance.setAttributeType(AttributeType.HURT);
                    enhance.setForceType(ForceType.ENEMY);
                    enhance.setForceUnitType(ForceUnitType.OFFICER_SOLDIERS);
                    enhance.setAttackUnitType(ForceUnitType.CLOSE_COMBAT);
                    break;
            //                case "officerDef"://将领在算防御力的时候已经算过 了
            //                    enhance = new AttributeEnhanceSkill();
            //                    enhance.setXmlId(23005);//因为阵型没有配技能，所以加防御力的先用这个技能代替一下，方便前端正常播放
            //                    enhance.setAttributeType(AttributeType.DEFENCE);
            //                    enhance.setForceType(ForceType.FRIEND);
            //                    enhance.setForceUnitType(ForceUnitType.OFFICER);
            //                    enhance.setAttackUnitType(ForceUnitType.OFFICER);
            //                    break;
            //                case "remoteSolDef":
            //                    enhance = new AttributeEnhanceSkill();
            //                    enhance.setXmlId(23005);//因为阵型没有配技能，所以加防御力的先用这个技能代替一下，方便前端正常播放
            //                    enhance.setAttributeType(AttributeType.DEFENCE);
            //                    enhance.setForceType(ForceType.FRIEND);
            //                    enhance.setForceUnitType(ForceUnitType.LONG_RANGE);
            //                    enhance.setAttackUnitType(ForceUnitType.OFFICER);
            //                    break;
            //                case "meleeCreDef":
            //                    enhance = new AttributeEnhanceSkill();
            //                    enhance.setXmlId(23005);//因为阵型没有配技能，所以加防御力的先用这个技能代替一下，方便前端正常播放
            //                    enhance.setAttributeType(AttributeType.DEFENCE);
            //                    enhance.setForceType(ForceType.FRIEND);
            //                    enhance.setForceUnitType(ForceUnitType.CLOSE_COMBAT);
            //                    enhance.setAttackUnitType(ForceUnitType.OFFICER);
            //                    break;
            }
            if (enhance != null) {
                //                enhance.setXmlId(ownerFormationId);
                enhance.setOccasion(Occasion.BEFORE_BATTLE);
                enhance.setChance(100);
                enhance.setForceDirection(ForceDirection.XY);
                enhance.setRange(new int[] { 0, 0, 0, 0 });
                enhance.setName("阵型加成");
                enhance.setPercentage(pers[i] / 100f);
                enhance.setValue(values[i]);
                enhance.setPg(pg);
                enhance.setRestraintFinder(battleObjFoctory.newRestraintFinder());
                enhance.setSkillId(ownerFormationId);
                enhance.setSkillType(SkillType.PASSIVE);

                skills.add(enhance);
            }
        }

        return skills;
    }

}
