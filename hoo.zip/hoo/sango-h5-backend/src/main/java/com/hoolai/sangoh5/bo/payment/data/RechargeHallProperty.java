package com.hoolai.sangoh5.bo.payment.data;

import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;
import com.hoolai.sangoh5.util.json.JsonProperty;

public class RechargeHallProperty extends JsonProperty{
	
	private int type;
    private String costType;
    private int rmb;
    private int costNumber;
    private String rewardType;
    private int rewardNumber;
    private float normalRate;
    private float firstChargeRate;
    
    public enum RechargeType{
    	WEEK_CARD(1),MOON_CARD(2),NOMAL(3);
    	
    	private final int type;
    	private RechargeType(int type){
    		this.type = type;
    	}
    	
    	public int getType(){
    		return type;
    	}
    	
    	public static RechargeType convertRechargeType(int type){
    		for(RechargeType rechargeType:values()){
    			if(rechargeType.getType() == type){
    				return rechargeType;
    			}
    		}
    		throw new BusinessException(ErrorCode.NO_THIS_TYPE);
    	}
    }
    
    
	public float getNormalRate() {
		return normalRate;
	}
	public void setNormalRate(float normalRate) {
		this.normalRate = normalRate;
	}
	public float getFirstChargeRate() {
		return firstChargeRate;
	}
	public void setFirstChargeRate(float firstChargeRate) {
		this.firstChargeRate = firstChargeRate;
	}
	public String getRewardType() {
		return rewardType;
	}
	public void setRewardType(String rewardType) {
		this.rewardType = rewardType;
	}
	public int getRewardNumber() {
		return rewardNumber;
	}
	public void setRewardNumber(int rewardNumber) {
		this.rewardNumber = rewardNumber;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getCostType() {
		return costType;
	}
	public void setCostType(String costType) {
		this.costType = costType;
	}
	public int getCostNumber() {
		return costNumber;
	}
	public void setCostNumber(int costNumber) {
		this.costNumber = costNumber;
	}
	public int getNomalNumber(boolean isIndexFirstPaid) {
		if(isIndexFirstPaid){
			return (int)(rewardNumber * (normalRate/100f));
		}else{
			return (int)(rewardNumber * (firstChargeRate/100f));
		}
	}
	public int getRmb() {
		return rmb;
	}
	public void setRmb(int rmb) {
		this.rmb = rmb;
	}
}
