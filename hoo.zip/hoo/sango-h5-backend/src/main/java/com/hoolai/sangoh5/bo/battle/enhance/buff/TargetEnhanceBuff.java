package com.hoolai.sangoh5.bo.battle.enhance.buff;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.sangoh5.bo.RankFightProtocolBuffer.BuffProto;
import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 薄葬在接下来的5秒内阻止所有将导致目标死亡的伤害
 * 
 * @author Administrator
 *
 */
public class TargetEnhanceBuff extends Buff {

    private float percentage;

    FightUnit owner;

    public TargetEnhanceBuff(int targetUsedSkillXmlId, String skillName, int currentLevel, float percentage, FightUnit owner) {
        super(targetUsedSkillXmlId, skillName, owner.name(), currentLevel);
        this.percentage = percentage;
        this.owner = owner;
    }

    @Override
    public List<FightUnit> targetEnhance(FightUnit actor, FightUnit target, TargetCollection tc) {
        List<FightUnit> targets = new ArrayList<FightUnit>();
        if (actor.name().equals(owner.name()) || !target.name().equals(owner.name())) {
            return targets;
        }

        for (Effect effect : target.getEffectList()) {
            targets.addAll(enhance(actor, target, tc, effect));
        }

        return new ArrayList<FightUnit>();
    }

    private List<FightUnit> enhance(FightUnit actor, FightUnit target, TargetCollection tc, Effect effect) {
        List<FightUnit> targets = new ArrayList<FightUnit>();
        if (effect.getDeltaHp() > 1) {
            effect.setDeltaHp(0);
            targets.add(target);
        }

        return targets;
    }

    @Override
    public void apply(FightUnit target) {
        this.result();
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * 此方法必要的时候需要在子类重写，否则会调用alive.unsilence()清除沉默产生负作用
     * 
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
    }

    public TargetEnhanceBuff(BuffProto message) {
        super(message);
    }

}
