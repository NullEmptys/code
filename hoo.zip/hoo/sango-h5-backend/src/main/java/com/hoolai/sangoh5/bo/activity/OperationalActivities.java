package com.hoolai.sangoh5.bo.activity;

import java.util.Collection;
import java.util.Map;

import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.OperationalActivitiesProto;
import com.hoolai.sangoh5.bo.ActivitesProtocolBuffer.OperationalActivitiesProto.Builder;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

/**
 * @author : joey(shimingjie@hoolai.com)
 * @createtime :2017-05-11 10:57
 * @version : 1.0
 */
public class OperationalActivities implements ProtobufSerializable<OperationalActivitiesProto> {

    private Map<Integer, OperationalActivity> activityMap;

    public OperationalActivities(Map<Integer, OperationalActivity> activityMap) {
        this.activityMap = activityMap;
    }

    public OperationalActivities(byte[] bytes) {
        this.parseFrom(bytes);
    }

    @Override
    public OperationalActivitiesProto copyTo() {
        Builder newBuilder = OperationalActivitiesProto.newBuilder();
        Collection<OperationalActivity> values = activityMap.values();
        for (OperationalActivity operationalActivity : values) {
            newBuilder.addActivity(operationalActivity.copyTo());
        }
        return newBuilder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            OperationalActivitiesProto message = OperationalActivitiesProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(OperationalActivitiesProto message) {
        int count = message.getActivityCount();
        this.activityMap = Maps.newHashMapWithExpectedSize(count);
        for (int i = 0; i < count; i++) {
            OperationalActivity operationalActivity = new OperationalActivity(message.getActivity(i));
            this.addActivity(operationalActivity);
        }
    }

    public void addActivity(OperationalActivity operationalActivity) {
        this.activityMap.put(operationalActivity.getId(), operationalActivity);
    }

    public OperationalActivity findActivity(int id) {
        return activityMap.get(id);
    }

    public Map<Integer, OperationalActivity> getActivityMap() {
        return activityMap;
    }

    public boolean deleteActivity(int id) {
        return activityMap.remove(id) != null;
    }

    public boolean finished(int activityId) {
        OperationalActivity activity = findActivity(activityId);
        return activity == null || activity.finished();
    }

}
