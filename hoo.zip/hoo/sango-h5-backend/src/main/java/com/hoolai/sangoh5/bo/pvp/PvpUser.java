package com.hoolai.sangoh5.bo.pvp;

import java.util.Calendar;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sango.util.TimeUtil;
import com.hoolai.sangoh5.bo.FightProtocolBuffer.PvpUserProto;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class PvpUser implements ProtobufSerializable<PvpUserProto> {

    /** 用户id **/
    private long userId;

    /** 隶属州县 **/
    private int pvpState;

    /** 军衔 **/
    private int militaryRank;

    /** 荣誉 **/
    private Contributes contributes;

    /** 个人徽章 **/
    private PersonalMedals personalMedals;

    transient Camp camp;

    /** 州奖励宝箱状态 **/
    private transient int stateGiftIndex;

    /** 联盟奖励宝箱状态 **/
    private transient int unionGiftIndex;

    /** 阵营奖励宝箱状态 **/
    private transient int campGiftIndex;

    public PvpUser() {

    }

    public PvpUser(long userId, int state) {
        this.userId = userId;
        this.pvpState = state;
        this.personalMedals = new PersonalMedals();
        this.contributes = new Contributes(userId);
    }

    public PvpUser(long userId, int state, int militaryRank) {
        this(userId, state);
        this.militaryRank = militaryRank;
    }

    public PvpUser(byte[] bytes) {
        parseFrom(bytes);
    }

    public int getIndex() {
        long now = TimeUtil.currentTimeMillis();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(now);

        int day = calendar.get(Calendar.DAY_OF_WEEK);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        if (hour >= 21) {
            return day;
        } else {
            return day - 1;
        }
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int getPvpState() {
        return pvpState;
    }

    public void setPvpState(int pvpState) {
        this.pvpState = pvpState;
    }

    public int getMilitaryRank() {
        return militaryRank;
    }

    public void setMilitaryRank(int militaryRank) {
        this.militaryRank = militaryRank;
    }

    public Camp getCamp() {
        return camp;
    }

    public void setCamp(Camp camp) {
        this.camp = camp;
    }

    @Override
    public PvpUserProto copyTo() {
        PvpUserProto.Builder builder = PvpUserProto.newBuilder();
        builder.setMilitaryRank(militaryRank);
        builder.setPvpState(pvpState);
        builder.setUserId(userId);
        builder.setContributes(contributes.copyTo());
        builder.setPersonalMedals(personalMedals.copyTo());

        return builder.build();
    }

    @Override
    public byte[] toByteArray() {
        return copyTo().toByteArray();
    }

    @Override
    public void parseFrom(byte[] bytes) {
        try {
            PvpUserProto message = PvpUserProto.parseFrom(bytes);
            copyFrom(message);
        } catch (InvalidProtocolBufferException e) {
            throw new BusinessException(ErrorCode.CAN_NOT_MEM);
        }
    }

    @Override
    public void copyFrom(PvpUserProto message) {
        this.militaryRank = message.getMilitaryRank();
        this.pvpState = message.getPvpState();
        this.userId = message.getUserId();
        this.contributes = new Contributes(message.getContributes());
        this.personalMedals = new PersonalMedals(message.getPersonalMedals());
    }

    public void reflesh(Camps camps) {
        for (Camp camp : camps.getCamps()) {
            if (camp.getStates().contains(pvpState)) {
                this.camp = camp;
                break;
            }
        }
        this.contributes.refreshPvpUser();
    }

    public void checkAndReceiveUnionGift() {
        contributes.checkAndReceiveUnionGift();
    }

    public int checkAndFindContribute() {
        return contributes.checkAndFindContribute();
    }

    public void checkAndReceiveCampGift() {
        contributes.checkAndReceiveCampGift();
    }

    public void refreshGift(int unionContirubte) {
        this.campGiftIndex = contributes.drawedGampGift() ? 2 : 1;

        Contribute contribute = contributes.getLastContribute();
        if (contribute == null) {
            return;
        }
        this.stateGiftIndex = contribute.drawedStateGift() ? 2 : 1;
        this.unionGiftIndex = unionContirubte > 0 ? contribute.drawedUnionGift() ? 2 : 1 : 0;

    }

    public int getStateGiftIndex() {
        return stateGiftIndex;
    }

    public int getUnionGiftIndex() {
        return unionGiftIndex;
    }

    public int getCampGiftIndex() {
        return campGiftIndex;
    }

    public PersonalMedals getPersonalMedals() {
        return personalMedals;
    }

    //    public Map<String, Integer> findContributes() {
    //        return contributes.findContributes();
    //    }

    public Contributes findContributes() {
        return contributes;
    }

    public int getContribute() {
        Contribute contribute = contributes.getLastContribute();
        return contribute == null ? 0 : contribute.getContribute();
    }
}
