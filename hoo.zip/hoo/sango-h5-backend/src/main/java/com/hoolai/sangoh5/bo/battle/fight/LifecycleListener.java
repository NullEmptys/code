package com.hoolai.sangoh5.bo.battle.fight;

import com.hoolai.sangoh5.bo.battle.unit.FightUnit;

public interface LifecycleListener {

	/**
	 * 监听战斗单元被淘汰（死亡）
	 * @param unit
	 */
    void onKnockedout(FightUnit unit);
    
    /**
     * 监听战斗单元（将领）被击败
     * @param unit
     */
    void onDefeated(FightUnit unit);

    /**
     * 监听战斗单元（目前仅用于士兵）复活
     * @param unit
     */
    void onRecovered(FightUnit unit);
    
    /**
     * 监听战斗单元（将领）复活
     * @param unit
     */
    void onRecoveredOfficer(FightUnit unit);
    

    LifecycleListener NONE = new LifecycleListener() {
        @Override
        public void onKnockedout(FightUnit unit) {
            // do nothing
        }

        @Override
        public void onRecovered(FightUnit unit) {
            // do nothing
        }
        
        @Override
        public void onDefeated(FightUnit unit) {
            // do nothing
        }

		@Override
		public void onRecoveredOfficer(FightUnit unit) {
			// TODO Auto-generated method stub
			
		}

    };
}
