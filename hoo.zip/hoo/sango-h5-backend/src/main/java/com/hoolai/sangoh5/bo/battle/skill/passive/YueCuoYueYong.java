package com.hoolai.sangoh5.bo.battle.skill.passive;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.enhance.Effect;
import com.hoolai.sangoh5.bo.battle.enhance.buff.CaptainshipSelfBuff;
import com.hoolai.sangoh5.bo.battle.skill.Skill;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/*
 * 我方每死亡N%的兵力，则增加N%的攻击力。
 */
public class YueCuoYueYong extends AttributeEnhanceSkill {

    // 记录一下增加攻击力的序号，如果一个单元的buff，捕捉到可以加攻击力的条件，应该给所有单元加上攻击力
    // 因为有的单元在跑动中，可能不去执行afterbuff
    private int addAttackIndex;

    @Override
    public void apply(FightUnit actor, TargetCollection tc) {
        Buff sbuff = new CaptainshipSelfBuff(xmlId, actor.name(), actor, this, Effect.MONITORING_BUFF_LEVEL, false).withKeepBuff().withRepeatCount(MaxRepeatCount)
                .withActorName(actor.name()).withTargetName(actor.name());
        actor.addAfterActionBuff(sbuff);
        actor.addBattleLog(actor.name() + "使用" + this.xmlId + "[" + this.name + "]");
    }

    @Override
    public Skill clone() {
        return super.clone(new YueCuoYueYong());
    }

    public int getAddAttackIndex() {
        return addAttackIndex;
    }

    public void setAddAttackIndex(int addAttackIndex) {
        this.addAttackIndex = addAttackIndex;
    }

}
