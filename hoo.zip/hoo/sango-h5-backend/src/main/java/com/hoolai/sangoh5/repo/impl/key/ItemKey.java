package com.hoolai.sangoh5.repo.impl.key;

import com.hoolai.sangoh5.util.Constant;

public class ItemKey {

    private static final String prefix= "item";
	
    public static String getItemBagsKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("id").toString();
    }
    
    public static String getEquipsKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator).append("eqsid").toString();
    }
    
    public static String getUniqueEquipIdKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
                .append("eqid").toString();
    }
    
    public static String getOfficerEnhancePotionKey(long userId) {
        return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
                .append("ofenpo").toString();
    }

	public static String getRechargeHallKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
        .append("recharge").toString();
	}

	public static String getMoonWeekCardKey(long userId) {
		return new StringBuilder().append(prefix).append(Constant.separator).append(userId).append(Constant.separator)
		        .append("mwc").toString();
	}
}
