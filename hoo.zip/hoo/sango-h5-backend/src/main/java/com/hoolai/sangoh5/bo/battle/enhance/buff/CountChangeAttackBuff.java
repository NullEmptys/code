package com.hoolai.sangoh5.bo.battle.enhance.buff;

import com.hoolai.sangoh5.bo.battle.enhance.Buff;
import com.hoolai.sangoh5.bo.battle.skill.AttributeType;
import com.hoolai.sangoh5.bo.battle.skill.ForceType;
import com.hoolai.sangoh5.bo.battle.unit.FightUnit;
import com.hoolai.sangoh5.bo.battle.unit.FightUnitName;
import com.hoolai.sangoh5.bo.battle.unit.TargetCollection;

/**
 * 战火覆盖范围内改变攻击力
 */
public class CountChangeAttackBuff extends Buff {

    private FightUnit actor;

    private ForceType forceType;

    private float percentage;

    private int count;

    private int currCount;

    /*
     * 触发技能后的下一回生效
     */
    @Override
    public void apply(FightUnit target) {
        this.result();

        if (!actor.isDead()) {
            if (currCount < count && count <= 3) {
                genBuff(target);
                currCount++;
                if (currCount != 0) {
                    needRepeatPlay();
                }
            }
        }
    }

    private void clearBuff(FightUnit target) {

        float d = target.baseAttackPoint() * percentage * currCount;
        switch (forceType) {
            case ENEMY:
                target.changeAttackPoint(d);
                target.addBattleLog(actor.name() + "执行" + targetUsedSkillXmlId + "[" + skillName + "]结束," + target.name() + "增加攻击力" + d + ",attackPoint:" + target.attackPoint());
                break;
            case FRIEND:
                target.changeAttackPoint(-d);
                target.addBattleLog(actor.name() + "执行" + targetUsedSkillXmlId + "[" + skillName + "]结束," + target.name() + "减少攻击力" + d + ",attackPoint:" + target.attackPoint());
                break;
            case FRIEND_ENEMY:
            case ALL:
                if (FightUnit.isSameTeam(actor, target)) {
                    target.changeAttackPoint(-d);
                    target.addBattleLog(actor.name() + "执行" + targetUsedSkillXmlId + "[" + skillName + "]结束," + target.name() + "减少攻击力" + d + ",attackPoint:"
                            + target.attackPoint());
                } else {
                    target.changeAttackPoint(d);
                    target.addBattleLog(actor.name() + "执行" + targetUsedSkillXmlId + "[" + skillName + "]结束," + target.name() + "增加攻击力" + d + ",attackPoint:"
                            + target.attackPoint());
                }
                break;
        }
    }

    private void genBuff(FightUnit target) {

        float d = target.baseAttackPoint() * percentage;
        switch (forceType) {
            case ENEMY:
                target.changeAttackPoint(-d);
                target.addBattleLog(actor.name() + "执行" + targetUsedSkillXmlId + "[" + skillName + "]," + target.name() + "减少攻击力" + d + ",attackPoint:" + target.attackPoint());
                break;
            case FRIEND:
                target.changeAttackPoint(d);
                target.addBattleLog(actor.name() + "执行" + targetUsedSkillXmlId + "[" + skillName + "]," + target.name() + "增加攻击力" + d + ",attackPoint:" + target.attackPoint());
                break;
            case FRIEND_ENEMY:
            case ALL:
                if (FightUnit.isSameTeam(actor, target)) {
                    target.changeAttackPoint(d);
                    target.addBattleLog(actor.name() + "执行" + targetUsedSkillXmlId + "[" + skillName + "]," + target.name() + "增加攻击力" + d + ",attackPoint:" + target.attackPoint());
                } else {
                    target.changeAttackPoint(-d);
                    target.addBattleLog(actor.name() + "执行" + targetUsedSkillXmlId + "[" + skillName + "]," + target.name() + "减少攻击力" + d + ",attackPoint:" + target.attackPoint());
                }
                break;
        }
    }

    @Override
    public void clear(TargetCollection tc) {
        FightUnit alive = tc.getAlive(this.targetName);
        if (alive != null) {//如果这回合之前被打死了就会为null这时不再管该单位身上的buff
            doClear(alive);
        }
    }

    /**
     * 此方法必要的时候需要在子类重写，否则会调用alive.unsilence()清除沉默产生负作用
     * 
     * @param alive
     */
    @Override
    protected void doClear(FightUnit alive) {
        clearBuff(alive);
        this.repeatCount = 0;
    }

    @Override
    public void setRepeatCount(int repeatCount) {
        this.repeatCount = repeatCount;
        isForFront = true;
        isNew = true;
        isCanRepeatPlay = true;
        count++;
    }

    @Override
    protected CountChangeAttackBuff clone() {
        CountChangeAttackBuff buff = (CountChangeAttackBuff) super.clone(new CountChangeAttackBuff(this.targetUsedSkillXmlId, this.skillName, executeName, actor, forceType,
                currentLevel, percentage));
        buff.actor = actor;
        return buff;
    }

    public CountChangeAttackBuff(int xmlId, String skillName, FightUnitName name, FightUnit actor, ForceType forceType, int currentLevel, float percentage) {
        super(xmlId, skillName, name, currentLevel);
        this.actor = actor;
        this.forceType = forceType;
        this.percentage = percentage;
        this.attributeType = AttributeType.ATTACK;
        count++;
    }
}
