package com.hoolai.sangoh5.bo.item;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.protobuf.InvalidProtocolBufferException;
import com.hoolai.protobuf.ProtobufSerializable;
import com.hoolai.sangoh5.bo.BoFactory;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.ItemBagProto;
import com.hoolai.sangoh5.bo.ItemProtocolBuffer.ItemBagsProto;
import com.hoolai.sangoh5.bo.battle.skill.data.SkillData;
import com.hoolai.sangoh5.bo.equip.data.EquipData;
import com.hoolai.sangoh5.bo.item.data.ItemData;
import com.hoolai.sangoh5.bo.item.data.MaterialData;
import com.hoolai.sangoh5.util.exception.BusinessException;
import com.hoolai.sangoh5.util.exception.ErrorCode;

public class ItemBags implements ProtobufSerializable<ItemBagsProto>{

	private List<ItemBag> itemBagList = new ArrayList<ItemBag>();
	
	private transient long userId;
	private transient boolean hasChange;
	private transient List<ItemBag> decItemBagList;
	
	transient BoFactory boFactory;

	public ItemBags(){}
	
	public ItemBags(long userId, byte[] bytes) {
		this(userId);
		parseFrom(bytes);
	}

	public ItemBags(long userId) {
		super();
		this.userId = userId;
	}

	public void addOrIncrItemBag(ItemBag... itemBagArray) {
		addOrIncrItemBag(Arrays.asList(itemBagArray));
	}

	/**
	 * 如果已有就改变成现在的
	 * 
	 * @param itemBag
	 */
	public void addOrIncrItemBag(List<? extends ItemBag> itemBagList) {
		for (ItemBag incrItemBag : itemBagList) {
			addOrIncrItemBag(incrItemBag);
		}
	}

	public void addOrIncrItemBag(int xmlId, int num) {
		addOrIncrItemBag(new ItemBag(xmlId, num));
	}

	public void addOrIncrItemBag(ItemBag addItemBag) {
		if (addItemBag.getXmlId() <= 0) {
			return;
		}
		ItemBag itemBag = findItemBag(addItemBag.getXmlId());
		if (itemBag == null) {
			itemBagList.add(addItemBag);
		} else {
			itemBag.incrNum(addItemBag.getNum());
		}

		hasChange = true;
	}
	
	private boolean isSkillBag(int xmlId) {
		SkillData skillData = boFactory.getSkillData();
		return skillData.getProperty(xmlId)!=null;
	}

	private boolean isItemBag(int xmlId) {
		ItemData itemData = boFactory.getItemData();
		return itemData.getProperty(xmlId)!=null;
	}

	public void removeItemBag(int xmlId) {
        if (xmlId < 1) {
            return;
        }
        int len = itemBagList.size();
        for (int i = 0; i < len; i++) {
            if (itemBagList.get(i).getXmlId() == xmlId) {
            	itemBagList.remove(i);
                hasChange = true;
                break;
            }
        }
    }
	
	public ItemBag findItemBag(int xmlId) {
		for (ItemBag itemBag : this.itemBagList) {
			if (itemBag.getXmlId() == xmlId) {
				return itemBag;
			}
		}
		return null;
	}
	
	public void deduct(ItemBag... itemBags) {
        int size = itemBags.length;
        if (size == 0) {
            return;
        }
        if(!checkAndInitDeductList(itemBags)){
            throw new BusinessException(ErrorCode.NOT_ENOUGH_ITEM);
        }
        deductConsumable(itemBags);
        hasChange = true;
    }
	
	 private void deductConsumable(ItemBag... itemBags) {
		 int size = itemBags.length;
	        for (int i = 0; i < size; i++) {
	        	ItemBag materials = itemBags[i];
	            ItemBag itemBag = decItemBagList.get(i);
	            if (itemBag.decNum(materials.getNum())) {
	                removeItemBag(itemBag.getXmlId());
	            }
	        }
	}

	private boolean checkAndInitDeductList(ItemBag... itemBags){
        int size = itemBags.length;
        decItemBagList = new ArrayList<ItemBag>(size);

        for (int i = 0; i < size; i++) {
            ItemBag materials = itemBags[i];
            ItemBag itemBag = findItemBag(materials.getXmlId());
            if (itemBag == null || itemBag.getXmlId() == 0 || itemBag.getNum() < materials.getNum()) {
                return false;
            }
            decItemBagList.add(itemBag);
        }
        return true;
	}

	@Override
	public ItemBagsProto copyTo() {
		ItemBagsProto.Builder builder = ItemBagsProto.newBuilder();
		for(ItemBag itemBag:itemBagList){
			builder.addItemBagList(itemBag.copyTo());
		}
		return builder.build();
	}

	@Override
	public byte[] toByteArray() {
		return copyTo().toByteArray();
	}

	@Override
	public void parseFrom(byte[] bytes) {
		try {
			ItemBagsProto message = ItemBagsProto.parseFrom(bytes);
			copyFrom(message);
		} catch (InvalidProtocolBufferException e) {
			throw new BusinessException(ErrorCode.CAN_NOT_MEM);
		}
	}

	@Override
	public void copyFrom(ItemBagsProto message) {
		int size = message.getItemBagListCount();
		this.itemBagList = new ArrayList<ItemBag>(size + 1);
        for (int i = 0; i < size; i++) {
        	ItemBagProto itemBagProto = message.getItemBagList(i);
            this.itemBagList.add(new ItemBag(itemBagProto));
        }
	}

	public long getUserId() {
		return this.userId;
	}
	
	public boolean hasChange(){
		return hasChange;
	}
	
	/**
	 * 返回所有物品
	 * @return
	 */
	public List<ItemBag> allItemBagList(){
		return itemBagList;
	}
	
	/**
	 * 返回所有道具
	 * @return
	 */
	public List<ItemBag> itemBagList(){
		List<ItemBag> itemBags = new ArrayList<ItemBag>();
		for(ItemBag itemBag:itemBagList){
			if(isItemBag(itemBag.getXmlId())){
				itemBags.add(itemBag);
			}
		}
		return itemBags;
	}
	
	/**
	 * 返回所有技能
	 * @return
	 */
	public List<ItemBag> skillBagList(){
		List<ItemBag> itemBags = new ArrayList<ItemBag>();
		for(ItemBag itemBag:itemBagList){
			if(isSkillBag(itemBag.getXmlId())){
				itemBags.add(itemBag);
			}
		}
		return itemBags;
	}
	
	
	
	
	/**
	 * 返回所有装备
	 * @return
	 */
	public List<ItemBag> equipBagList(){
		List<ItemBag> itemBags = new ArrayList<ItemBag>();
		for(ItemBag itemBag:itemBagList){
			if(isEquipBag(itemBag.getXmlId())){
				itemBags.add(itemBag);
			}
		}
		return itemBags;
	}
	
	private boolean isEquipBag(int xmlId) {
		EquipData equipData = boFactory.getEquipData();
		return equipData.getProperty(xmlId)!=null;
	}

	public void clear(){
		itemBagList.clear();
	}

	public void setBoFactory(BoFactory boFactory) {
		this.boFactory = boFactory;
	}
	
	
}
