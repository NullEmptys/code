package com.gamedo.gameServer.activity;

public interface ActivityServiceMBean {

	public void loadActivities();
	
	public void loadActivityById(int activityId);
	
	public void stopActivityById(int activityId);
}
