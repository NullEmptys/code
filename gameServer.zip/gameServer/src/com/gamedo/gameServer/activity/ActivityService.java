package com.gamedo.gameServer.activity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gamedo.gameServer.activity.loginReward.LoginRewardActivity;
import com.gamedo.gameServer.core.Time;
import com.gamedo.gameServer.core.Updatable;
import com.gamedo.gameServer.core.impl.SimpleUpdater;
import com.gamedo.gameServer.data.activity.loginReward.LoginReward;
import com.gamedo.gameServer.data.activity.loginReward.LoginRewardConfig;
import com.gamedo.gameServer.db.activity.loginReward.LoginRewardConfigDao;
import com.gamedo.gameServer.db.activity.loginReward.LoginRewardDao;
import com.gamedo.gameServer.entity.activity.loginReward.LoginSignRecord;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.message.activity.loginReward.SevenLoginRewardData;
import com.gamedo.gameServer.message.player.ActivityData;
import com.gamedo.gameServer.service.AbstractService;
import com.gamedo.gameServer.util.Const;

/**
 * 活动服务
 * 
 * @author libm
 *
 */
@Service
public class ActivityService extends AbstractService implements ActivityServiceMBean, Updatable {

	private Logger log = LoggerFactory.getLogger(ActivityService.class);

	@Autowired
	private ActivityDao activityDao;
	@Autowired
	private LoginRewardDao loginRewardDao;
	@Autowired
	private LoginRewardConfigDao loginRewardConfigDao;
	@Autowired
	private SimpleUpdater simpleUpdater;

	/** 有效时间内的活动 */
	public ConcurrentHashMap<Integer, Activity> activities = new ConcurrentHashMap<>();

	private long lastCheckTime;

	@Override
	public String getId() {
		return ActivityService.class.getName();
	}

	@PostConstruct
	public void startup() throws Exception {
		loadActivities();
		simpleUpdater.addSyncUpdatable(this);
		super.startup("掌上纵横-IPOC-LOVELIVE:type=服务,name=活动服务");
	}

	@PreDestroy
	@Override
	public void shutdown() throws Exception {
		for (Activity activity : activities.values()) {
			if (activity != null) {
				activity.save();
				if (activity.isActive()) {
					try {
						activity.shutdown();
					} catch (Exception e) {
						log.error(e.toString(), e);
					}
				}
			}
		}
		super.shutdown();
	}

	@Override
	public void loadActivities() {
		ConcurrentHashMap<Integer, Activity> activities = new ConcurrentHashMap<>();
		List<Activity> list = activityDao.loadActivities();
		if (list != null && list.size() > 0) {
			for (Activity activity : list) {
				if (activity != null) {
					activity.load();
					activities.put(activity.getId(), activity);
				}
			}
		}
		this.activities = activities;
	}

	@Override
	public synchronized boolean update() {
		// 每1分钟检查一次所有活动的时间
		if (System.currentTimeMillis() - lastCheckTime > 60000) {
			lastCheckTime = System.currentTimeMillis();
			for (Activity act : activities.values()) {
				boolean in = act.in();

				// 判断正在进行的活动是否到时间关闭了
				if (act.isActive() && !in) {
					try {
						act.shutdown();
					} catch (Exception e) {
						log.error(e.toString(), e);
					}
				}

				// 判断不在进行的活动是否到时间开启了
				if (!act.isActive() && in) {
					try {
						act.startup();
					} catch (Exception e) {
						log.error(e.toString(), e);
					}
				}

				// cycle处理
				if (act.isActive()) {
					act.update();
					act.load();
				}
			}
		}
		return true;
	}

	public Activity getActivity(int activityId) {
		Activity activity = activities.get(activityId);
		return activity;
	}

	public List<ActivityData> getActivityData() {

		return null;
	}

	/**
	 * 获取7日登录活动数据
	 * 
	 * @return
	 */
	public SevenLoginRewardData getSevenLoginRewardData(Player player) {
		int lastSignDay = player.getPool().getInt(Const.PROPERTY_LAST_LOGIN_SIGN_DAY);
		if (lastSignDay != Time.day) {
			for (Activity activity : activities.values()) {
				if (activity != null && activity.getImpl() instanceof LoginRewardActivity && activity.isActive()) {
					
					LoginRewardActivity loginRewardActivity = (LoginRewardActivity) activity.getImpl();
					LoginSignRecord signRecord = loginRewardActivity.getPlayerSignRecord(player.getId(), activity.getId());
					if(signRecord != null && signRecord.getSignCounts() >= 7) {
						return null;
					}
					
					SevenLoginRewardData data = new SevenLoginRewardData();
					data.setActivityId(activity.getId());
					data.setActivityTitle(activity.getTitle());
					data.setSignCounts(loginRewardActivity.getPlayerSignCounts(player.getId(), activity.getId()));
					data.setSignRewards(loginRewardActivity.getPlayerSignRewardData(player.getId(), activity.getId()));
					return data;
				}
			}
		}
		return null;
	}

	/**
	 * 获取活动列表
	 * 
	 * @return
	 */
	public List<Activity> getActivities() {
		List<Activity> list = new ArrayList<>();
		for (Activity act : activities.values()) {
			if (act.getBroadcastStartTime().before(new Date()) && act.getBroadcastEndTime().after(new Date())) {
				list.add(act);
			}
		}
		return list;
	}

	/**
	 * 从数据库中加载一个活动
	 */
	@Override
	public synchronized void loadActivityById(int activityId) {
		Activity act = activityDao.loadActivityById(activityId);
		boolean in = act.in();
		if (!act.isActive() && in) {
			try {
				act.startup();
				activities.put(act.getId(), act);
			} catch (Exception e) {
				log.error(e.toString(), e);
			}
		} else {
			activities.put(act.getId(), act);
		}
	}

	/**
	 * 停止一个活动
	 */
	@Override
	public synchronized void stopActivityById(int activityId) {
		Activity act = activities.get(activityId);
		if (act != null) {
			if (act.isActive()) {
				try {
					act.shutdown();
					act.clear();
				} catch (Exception e) {
					log.error(e.toString(), e);
				}
			}
			activities.remove(activityId);
		}
	}

	public Activity saveActivity(Activity activity) {
		return activityDao.newEntity(activity);
	}

	public Activity updateActivity(Activity activity) {
		return activityDao.updateEntity(activity);
	}

	public void deleteActivity(int activityId) {
		Activity activity = this.getActivity(activityId);
		stopActivityById(activityId);
		if("com.gamedo.gameServer.activity.loginReward.LoginRewardActivity".equals(activity.getImplClass())){
			loginRewardDao.delete("delete LoginReward l where l.activityId = ?0", activityId);
		}
		activityDao.delete("delete Activity a where a.id = ?0", activityId);
		
	}

	public LoginReward saveLoginReward(LoginReward loginReward) {
		return loginRewardDao.newEntity(loginReward);
	}

	public LoginReward updateLoginReward(LoginReward loginReward) {
		return loginRewardDao.updateEntity(loginReward);
	}

	public List<LoginReward> loadLoginRewards(int activityId) {
		return loginRewardDao.loadLoginRewards(activityId);
	}

	public LoginRewardConfig loadLoginRewardConfig(int activityId) {
		return loginRewardConfigDao.findLoginRewardConfig(activityId);
	}

	public LoginRewardConfig updateLoginRewardConfig(LoginRewardConfig loginRewardConfig) {
		return loginRewardConfigDao.updateEntity(loginRewardConfig);
	}

	public LoginRewardConfig createLoginRewardConfig(LoginRewardConfig loginRewardConfig) {
		return loginRewardConfigDao.newEntity(loginRewardConfig);
	}
}
