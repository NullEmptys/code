package com.gamedo.gameServer.activity.exchangeTicket;

import java.io.Serializable;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.gamedo.gameServer.activity.Activity;
import com.gamedo.gameServer.activity.IActivityImpl;
import com.gamedo.gameServer.core.cache.CacheManagerService;
import com.gamedo.gameServer.data.activity.activityExch.ActivityExchData;
import com.gamedo.gameServer.data.activity.activityExch.ExchActivityConfig;
import com.gamedo.gameServer.db.activityExch.ActivityExchConfigDao;
import com.gamedo.gameServer.db.activityExch.ActivityExchDataDao;
import com.gamedo.gameServer.db.activityExch.ExchActivityRecordDao;
import com.gamedo.gameServer.db.activityExch.PlayerActivityExchRecDao;
import com.gamedo.gameServer.entity.activity.exchTicket.ActivityExchRecord;
import com.gamedo.gameServer.entity.activity.exchTicket.PlayerActivityExchRec;
import com.gamedo.gameServer.util.DateUtil;
import com.gamedo.gameServer.util.JsonUtil;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

public class ExchangeActivity implements IActivityImpl, ExchangeActivityMBean, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Logger logger = LoggerFactory.getLogger(ExchangeActivity.class);
	public Activity activity;
	private ObjectName objectName;
	private ActivityExchConfigDao activityExchConfigDao;
	private ActivityExchDataDao exchActivityConfigDao;
	private ExchActivityRecordDao exchActivityRecordDao;
	private PlayerActivityExchRecDao playerActivityExchRecDao;
	/** 当前活动配置 */
	private Map<String, Integer> ticketMap = new ConcurrentHashMap<>();
	private Map<Integer, ActivityExchData> exchMap = new ConcurrentHashMap<>();
	public static final String EXCH_TICKET_RECORD_CACHE = "exchangeTicketActivityCache";
	public static final String PLAYER_EXCHANGE_RECORD_CACHE = "playerExchangeTicketCache";
	public static final String PLAYER_HISTORY_TICKET_CACHE = "playerHistoryTicketCache";

	public ExchangeActivity(Activity activity) {
		this.activity = activity;
		this.activityExchConfigDao = new ActivityExchConfigDao();
		this.exchActivityConfigDao = new ActivityExchDataDao();
		this.exchActivityRecordDao = new ExchActivityRecordDao();
		this.playerActivityExchRecDao = new PlayerActivityExchRecDao();
	}

	@Override
	public void startup() throws Exception {
		loadActivityExchData();
		try {
			MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
			this.objectName = new ObjectName("掌上纵横-IPOC-LOVELIVE:type=活动,name=线下见面会活动" + activity.getId());
			mbs.registerMBean(this, objectName);
		} catch (Exception e) {
			logger.warn("注册MBean异常", e);
		}
	}


	public void loadActivityExchData() {
		if (exchMap != null || exchMap.size() != 0) {
			exchMap.clear();
		}
		Map<Integer, ActivityExchData> tempMap = new HashMap<Integer, ActivityExchData>();
		List<ActivityExchData> activityExch = exchActivityConfigDao.loadActivityExchData();
		if (activityExch != null && activityExch.size() > 0) {
			for (ActivityExchData exchData : activityExch) {
				if (!tempMap.containsKey(exchData.getId())) {
					tempMap.put(exchData.getId(), exchData);
				}
			}
		}
		exchMap = tempMap;
	}

	@Override
	public void shutdown() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public Activity getActivity() {
		// TODO Auto-generated method stub
		return activity;
	}

	@Override
	public void save() {
		// TODO Auto-generated method stub

	}

	@SuppressWarnings("unchecked")
	@Override
	public void load() {
		ExchActivityConfig exchActivityConfig = activityExchConfigDao.loadActivityExchConfig(activity.getId());
		ticketMap = JsonUtil.fromJson(exchActivityConfig.getActivityConfig(), Map.class);
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub

	}

	/**
	 * 活动配置
	 * 
	 * @return
	 */
	public Map<String, Integer> getCurrentActivityConfig() {
		return ticketMap;
	}

	/**
	 * 活动兑换数据配置
	 * 
	 * @return
	 */
	public Map<Integer, ActivityExchData> getActivityExchConfig() {
		return exchMap;
	}

	public Cache getCache(String cacheName) {
		return CacheManagerService.getInstance().getCache(cacheName);
	}

	/**
	 * 活动记录缓存
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public ActivityExchRecord getActivityExchList() {
		Cache cache = getCache(EXCH_TICKET_RECORD_CACHE);
		ActivityExchRecord ActivityExchRecords = new ActivityExchRecord();
		if (cache != null) {
			Element element = cache.get(activity.getId());
			if (element != null) {
				ActivityExchRecords = (ActivityExchRecord) element.getObjectValue();
			} else {
				ActivityExchRecords = (ActivityExchRecord) exchActivityRecordDao
						.loadActivityExchRecord(activity.getId());
				if (ActivityExchRecords == null) {
					ActivityExchRecord ActivityExchRecord = new ActivityExchRecord();
					ActivityExchRecord.setActivityId(activity.getId());
					ActivityExchRecord.setTicketId(getActivityConfig(ticketMap).get(0).toString());
					ActivityExchRecord.setTicketNum(getActivityConfig(ticketMap).get(1).toString());
					exchActivityRecordDao.newEntity(ActivityExchRecord);
					ActivityExchRecords = ActivityExchRecord;
				}
				Element element1 = new Element(activity.getId(), ActivityExchRecords);
				cache.put(element1);
			}
			return ActivityExchRecords;
		}
		return null;
	}

	/**
	 * 缓存key
	 * 
	 * @param activityId
	 * @param playerId
	 * @param ticketId
	 * @return
	 */
	public String getKey(int activityId, int playerId, int ticketId) {
		return activityId + "" + playerId + "" + ticketId;
	}

	/**
	 * 玩家记录缓存
	 * 
	 * @param playerId
	 * @param ticketId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public PlayerActivityExchRec getPlayerExchActivityRec(int playerId, int ticketId) {
		Cache cache = getCache(PLAYER_EXCHANGE_RECORD_CACHE);
		PlayerActivityExchRec playerRec = new PlayerActivityExchRec();
		if (cache != null) {
			Element element = cache.get(getKey(activity.getId(), playerId, ticketId));
			if (element != null) {
				playerRec = (PlayerActivityExchRec) element.getObjectValue();
			} else {
				playerRec = playerActivityExchRecDao.loadPlayerActivityExchRecords(playerId, activity.getId(),
						ticketId);
				if (playerRec != null) {
					element = new Element(getKey(activity.getId(), playerId, ticketId), playerRec);
					cache.put(element);
				}
			}
			return playerRec;
		}
		return null;
	}

	/**
	 * 更新玩家购买活动卷数据
	 * 
	 * @param playerId
	 */
	public String updatePlayerActivityCurrencyRec(int playerId, int ticketId, int ticketNum, String type, int count) {
		Cache cache = getCache(PLAYER_EXCHANGE_RECORD_CACHE);
		if (cache != null) {
			Element element = cache.get(getKey(activity.getId(), playerId, ticketId));
			PlayerActivityExchRec playerRec = new PlayerActivityExchRec();
			if (element != null) {
				playerRec = (PlayerActivityExchRec) element.getObjectValue();
			} else {
				playerRec = playerActivityExchRecDao.loadPlayerActivityExchRecords(playerId, activity.getId(),
						ticketId);
			}
			if (playerRec == null) {
				PlayerActivityExchRec playerExchRec = new PlayerActivityExchRec();
				playerExchRec.setActivityId(activity.getId());
				playerExchRec.setPlayerId(playerId);
				playerExchRec.setTicketId(ticketId);
				if (type.equals("A")) {
					playerExchRec.setTicketNum(ticketNum + "");
				} else {
					String ticketNumber = getQualifyingTicketet(new Date(), type, count + 1);
					playerExchRec.setTicketNum(ticketNumber);
				}
				playerActivityExchRecDao.newEntity(playerExchRec);
				playerRec = playerExchRec;
			} else {
				playerRec.setTicketNum((Integer.parseInt(playerRec.getTicketNum()) + ticketNum) + "");
				playerActivityExchRecDao.updateEntity(playerRec);
			}
			element = new Element(getKey(activity.getId(), playerId, ticketId), playerRec);
			cache.put(element);
			return playerRec.getTicketNum();
		}
		return null;
	}

	public String getQualifyingTicketet(Date time, String type, int count) {
		String[] ticketDate = DateUtil.getShortString(time).split("-");
		int pos = (count + "").length();
		String number = null;
		if (pos == 1) {
			number = "000" + count;
		} else if (pos == 2) {
			number = "00" + count;
		} else if (pos == 3) {
			number = "0" + count;
		} else {
			number = count + "";
		}
		return ticketDate[0].substring(2, 4) + ticketDate[1] + ticketDate[2] + number + type;
	}

	public void updateActivityExchTicketRec(int ticketId, int exchCount) {
		Cache cache = getCache(EXCH_TICKET_RECORD_CACHE);
		ActivityExchRecord ActivityExchRecords = new ActivityExchRecord();
		if (cache != null) {
			Element element = cache.get(activity.getId());
			if (element != null) {
				ActivityExchRecords = (ActivityExchRecord) element.getObjectValue();
			} else {
				ActivityExchRecords = (ActivityExchRecord) exchActivityRecordDao
						.loadActivityExchRecord(activity.getId());
			}
			if (ActivityExchRecords != null) {
				List<Integer> tickekIds = DateUtil.StringToList(ActivityExchRecords.getTicketId());
				List<Integer> ticketNums = DateUtil.StringToList(ActivityExchRecords.getTicketNum());
				if (tickekIds != null && tickekIds.contains(ticketId)) {
					for (int i = 0; i < tickekIds.size(); i++) {
						if (tickekIds.get(i) == ticketId) {
							ticketNums.set(i, ticketNums.get(i) + exchCount);
						}
					}
					ActivityExchRecords.setTicketNum(DateUtil.listToString(ticketNums));
					exchActivityRecordDao.updateEntity(ActivityExchRecords);
				} 
			}
			element = new Element(activity.getId(), ActivityExchRecords);
			cache.put(element);
		}
	}
	
	public List<String> getActivityConfig(Map<String,Integer> configMap){
		List<String> confiList= new ArrayList<>();
		StringBuilder sb1 = new StringBuilder();
		StringBuilder sb2 = new StringBuilder();
		int count = 0;
		for(String ticketIds : configMap.keySet()){
			if(Integer.parseInt(ticketIds) == 1){
				continue;
			}
			if(count == 0){
				sb1.append(ticketIds);
				sb2.append(0);
			}else{
				sb1.append(",");
				sb2.append(",");
				sb1.append(ticketIds);
				sb2.append(0);
			}
			count++;
		}
		confiList.add(sb1.toString());
		confiList.add(sb2.toString());
		return confiList;
	}
	
	/**
	 * 获取活动历史票据
	 * @param playerId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<PlayerActivityExchRec> getPlayerHistoryTicket(int playerId){
		Cache cache = getCache(PLAYER_HISTORY_TICKET_CACHE);
		List<PlayerActivityExchRec> playerHistoryTicket = null;
		if(cache != null){
			Element element = cache.get(playerId);
			if(element != null){
				playerHistoryTicket = (List<PlayerActivityExchRec>) element.getObjectValue();
				return playerHistoryTicket;
			}else{
				playerHistoryTicket = playerActivityExchRecDao.getPlayerActivityExchRec(playerId, activity.getId());
			}
			return playerHistoryTicket;
		}
		return null;
	}
	/**
	 * 获取当前活动票据
	 * @param playerId
	 * @return
	 */
	public List<PlayerActivityExchRec> getCurrentTicket(int playerId){
		List<PlayerActivityExchRec> playerActRecList = new ArrayList<>();
		Cache cache = getCache(EXCH_TICKET_RECORD_CACHE);
		if(cache != null){
			Set<String> tickets = ticketMap.keySet();
			for(String s : tickets){
				Element element = cache.get(getKey(activity.getId(),playerId,Integer.parseInt(s)));
				if(element != null){
					playerActRecList.add((PlayerActivityExchRec) element.getObjectValue());
				}else{
					PlayerActivityExchRec playerRec = null;
					playerRec = playerActivityExchRecDao.loadPlayerActivityExchRecords(playerId, activity.getId(),
							Integer.parseInt(s));
					if(playerRec != null){
						playerActRecList.add(playerRec);
						playerRec = null;
					}
				}
			}
			return playerActRecList;
		}
		return null;
	}
}
