package com.gamedo.gameServer.activity.exchangeTicket;

public interface ExchangeActivityMBean {

	/**
	 * 加载兑换数据配置
	 */
	public void loadActivityExchData();
	
	/**
	 * 活动投放数据配置
	 */
	public void load();
}
