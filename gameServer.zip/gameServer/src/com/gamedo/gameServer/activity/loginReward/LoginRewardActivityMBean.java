package com.gamedo.gameServer.activity.loginReward;

public interface LoginRewardActivityMBean {

	public void loadLoginRewards();
	
	public void loadLoginRewardConfig();
}
