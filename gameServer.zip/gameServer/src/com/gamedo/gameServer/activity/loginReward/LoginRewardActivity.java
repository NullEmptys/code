package com.gamedo.gameServer.activity.loginReward;

import java.io.Serializable;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gamedo.gameServer.activity.Activity;
import com.gamedo.gameServer.activity.IActivityImpl;
import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.core.cache.CacheManagerService;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.activity.loginReward.LoginReward;
import com.gamedo.gameServer.data.activity.loginReward.LoginRewardConfig;
import com.gamedo.gameServer.data.equipment.ClothCdTime;
import com.gamedo.gameServer.db.activity.loginReward.LoginRewardAreaDao;
import com.gamedo.gameServer.db.activity.loginReward.LoginRewardConfigDao;
import com.gamedo.gameServer.db.activity.loginReward.LoginRewardDao;
import com.gamedo.gameServer.db.activity.loginReward.LoginRewardRecordDao;
import com.gamedo.gameServer.db.activity.loginReward.LoginSignRecordDao;
import com.gamedo.gameServer.entity.activity.loginReward.LoginRewardArea;
import com.gamedo.gameServer.entity.activity.loginReward.LoginRewardRecord;
import com.gamedo.gameServer.entity.activity.loginReward.LoginSignRecord;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.message.activity.loginReward.LoginRewardAreaData;
import com.gamedo.gameServer.message.activity.loginReward.SignRewardData;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.util.Const;

import gnu.trove.map.hash.TIntObjectHashMap;
import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

/**
 * 7日登录活动
 * 
 * @author libm
 *
 */
public class LoginRewardActivity implements IActivityImpl, LoginRewardActivityMBean, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8874718139683890567L;

	private Logger logger = LoggerFactory.getLogger(LoginRewardActivity.class);

	public static final int SIGNED = 1;
	public static final int UNLOCKED = 1;

	public Activity activity;

	public LoginRewardDao loginRewardDao;
	public LoginRewardConfigDao loginRewardConfigDao;
	public LoginRewardRecordDao loginRewardRecordDao;
	public LoginSignRecordDao loginSignRecordDao;
	public LoginRewardAreaDao loginRewardAreaDao;

	public static final String LOGIN_SIGN_RECORD_CACHE = "loginSignActivityCache";
	public static final String LOGIN_REWARD_RECORD_CACHE = "loginRewardActivityCache";
	public static final String LOGIN_REWARD_AREA_CACHE = "loginRewardAreaCache";

	public TIntObjectHashMap<LoginReward> loginRewards = new TIntObjectHashMap<>();
	public LoginRewardConfig loginRewardConfig;

	private ObjectName objectName;

	public LoginRewardActivity(Activity owner) {
		this.activity = owner;
		loginRewardDao = new LoginRewardDao();
		loginRewardConfigDao = new LoginRewardConfigDao();
		loginRewardRecordDao = new LoginRewardRecordDao();
		loginSignRecordDao = new LoginSignRecordDao();
		loginRewardAreaDao = new LoginRewardAreaDao();
	}

	@Override
	public void startup() throws Exception {
		loadLoginRewards();
		loadLoginRewardConfig();
		try {
			MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
			this.objectName = new ObjectName("掌上纵横-IPOC-LOVELIVE:type=活动,name=7日登录奖励活动-" + activity.getId());
			mbs.registerMBean(this, objectName);
		} catch (Exception e) {
			logger.warn("注册MBean异常", e);
		}
	}

	@Override
	public void shutdown() throws Exception {
		MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
		try {
			mbs.unregisterMBean(objectName);
		} catch (Exception e) {
			logger.error("注销MBean异常", e);
		}
	}

	@Override
	public Activity getActivity() {
		return activity;
	}

	@Override
	public void save() {

	}

	@Override
	public void load() {

	}

	@Override
	public void clear() {

	}

	@Override
	public void loadLoginRewards() {
		TIntObjectHashMap<LoginReward> loginRewards = new TIntObjectHashMap<>();
		List<LoginReward> list = loginRewardDao.loadLoginRewards(activity.getId());
		if (list != null && list.size() > 0) {
			for (LoginReward lr : list) {
				if (lr != null) {
					loginRewards.put(lr.getSignCounts(), lr);
				}
			}
		}
		this.loginRewards = loginRewards;
	}

	@Override
	public void loadLoginRewardConfig() {
		loginRewardConfig = loginRewardConfigDao.findLoginRewardConfig(activity.getId());
	}

	public List<SignRewardData> getPlayerSignRewardData(int playerId, int activityId) {
		ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardRecord>> records = getPlayerLoginRewardRecords(
				playerId, activityId);
		List<SignRewardData> rewards = new ArrayList<>();
		for (LoginRewardRecord record : records.get(activityId).values()) {
			if (record != null) {
				SignRewardData data = new SignRewardData();
				data.setDay(record.getDay());
				data.setState(record.getState());
				LoginReward loginReward = loginRewards.get(record.getDay());
				if (loginReward != null) {
					data.setRewardType(loginReward.getRewardType());
					data.setRewardId(loginReward.getRewardId());
					data.setRewardCounts(loginReward.getRewardCounts());
					data.setCdTimeType(loginReward.getCdTimeType());
					data.setBackgroundId(loginReward.getBackgroundId());
				}
				rewards.add(data);
			}
		}
		return rewards;
	}

	@SuppressWarnings("unchecked")
	private ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardRecord>> getPlayerLoginRewardRecords(
			int playerId, int activityId) {
		Cache cache = getCache(LOGIN_REWARD_RECORD_CACHE);
		Element element = cache.get(playerId);
		if (element != null) {
			ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardRecord>> map = (ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardRecord>>) element
					.getObjectValue();
			return map;
		} else {
			ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardRecord>> map = new ConcurrentHashMap<>();
			List<LoginRewardRecord> list = loginRewardRecordDao.loadPlayerLoginRewardRecords(playerId, activityId);
			ConcurrentHashMap<Integer, LoginRewardRecord> records = new ConcurrentHashMap<Integer, LoginRewardRecord>();
			if (list == null || list.size() == 0) {
				for (LoginReward lr : loginRewards.valueCollection()) {
					if (lr != null) {
						LoginRewardRecord record = new LoginRewardRecord();
						record.setPlayerId(playerId);
						record.setActivityId(activityId);
						record.setDay(lr.getSignCounts());
						loginRewardRecordDao.newEntity(record);
						records.put(record.getDay(), record);
					}
				}
			} else {
				for (LoginRewardRecord record : list) {
					if (record != null) {
						records.put(record.getDay(), record);
					}
				}
			}
			map.put(activityId, records);
			addPlayerLoginRewardRecordToCache(playerId, map);
			return map;
		}
	}

	public void updatePlayerLoginRewardRecord(LoginRewardRecord record) {
		loginRewardRecordDao.updateEntity(record);
		Cache cache = getCache(LOGIN_REWARD_RECORD_CACHE);
		ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardRecord>> map = getPlayerLoginRewardRecords(
				record.getPlayerId(), record.getActivityId());
		map.get(record.getActivityId()).put(record.getDay(), record);
		Element element = new Element(record.getPlayerId(), map);
		cache.put(element);
	}

	private void addPlayerLoginRewardRecordToCache(int playerId,
			ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardRecord>> map) {
		Cache cache = getCache(LOGIN_REWARD_RECORD_CACHE);
		Element element = new Element(playerId, map);
		cache.put(element);
	}

	/**
	 * 玩家签到天数
	 * 
	 * @param playerId
	 * @return
	 */
	public int getPlayerSignCounts(int playerId, int activityId) {
		LoginSignRecord record = getPlayerSignRecord(playerId, activityId);
		return record.getSignCounts();
	}

	@SuppressWarnings("unchecked")
	public ConcurrentHashMap<Integer, LoginSignRecord> getPlayerLoginSignRecords(int playerId, int activityId) {
		Cache cache = getCache(LOGIN_SIGN_RECORD_CACHE);
		Element element = cache.get(playerId);
		if (element != null) {
			return (ConcurrentHashMap<Integer, LoginSignRecord>) element.getObjectValue();
		} else {
			ConcurrentHashMap<Integer, LoginSignRecord> records = new ConcurrentHashMap<Integer, LoginSignRecord>();
			LoginSignRecord record = loginSignRecordDao.loadPlayerLoginSignRecord(playerId, activityId);
			if (record == null) {
				record = new LoginSignRecord();
				record.setPlayerId(playerId);
				record.setActivityId(activityId);
				loginSignRecordDao.newEntity(record);
			}
			records.put(record.getActivityId(), record);
			addPlayerSignRecordToCache(playerId, records);
			return records;
		}
	}

	public void updateLoginSignRecord(LoginSignRecord record) {
		loginSignRecordDao.updateEntity(record);
		Cache cache = getCache(LOGIN_SIGN_RECORD_CACHE);
		ConcurrentHashMap<Integer, LoginSignRecord> records = getPlayerLoginSignRecords(record.getPlayerId(),
				record.getActivityId());
		records.put(record.getSignCounts(), record);
		Element element = new Element(record.getPlayerId(), records);
		cache.put(element);
	}

	private void addPlayerSignRecordToCache(int playerId, ConcurrentHashMap<Integer, LoginSignRecord> records) {
		Cache cache = getCache(LOGIN_SIGN_RECORD_CACHE);
		Element element = new Element(playerId, records);
		cache.put(element);
	}

	public LoginSignRecord getPlayerSignRecord(int playerId, int activityId) {
		ConcurrentHashMap<Integer, LoginSignRecord> records = getPlayerLoginSignRecords(playerId, activityId);
		return records.get(activityId);
	}

	public Cache getCache(String cacheName) {
		return CacheManagerService.getInstance().getCache(cacheName);
	}

	/**
	 * 获取玩家背景区域状态数据
	 * 
	 * @param playerId
	 * @param activityId
	 * @return
	 */
	public List<LoginRewardAreaData> getPlayerLoginAreaDatas(int playerId, int activityId) {
		List<LoginRewardAreaData> areaDatas = new ArrayList<>();
		ConcurrentHashMap<Integer, LoginRewardArea> areas = getPlayerLoginRewardAreas(playerId, activityId)
				.get(activityId);
		if (areas != null) {
			for (LoginRewardArea area : areas.values()) {
				if (area != null) {
					LoginRewardAreaData data = new LoginRewardAreaData();
					data.setAreaId(area.getAreaId());
					data.setState(area.getState());
					areaDatas.add(data);
				}
			}
		}
		return areaDatas;
	}

	@SuppressWarnings("unchecked")
	public ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardArea>> getPlayerLoginRewardAreas(
			int playerId, int activityId) {
		Cache cache = getCache(LOGIN_REWARD_AREA_CACHE);
		Element element = cache.get(playerId);
		if (element != null) {
			return (ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardArea>>) element.getObjectValue();
		} else {
			ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardArea>> map = new ConcurrentHashMap<>();
			List<LoginRewardArea> list = loginRewardAreaDao.loadPlayerLoginRewardAreas(playerId, activityId);
			ConcurrentHashMap<Integer, LoginRewardArea> records = new ConcurrentHashMap<>();
			if (list == null || list.size() == 0) {
				for (LoginReward lr : loginRewards.valueCollection()) {
					if (lr != null) {
						LoginRewardArea record = new LoginRewardArea();
						record.setPlayerId(playerId);
						record.setActivityId(activityId);
						record.setAreaId(lr.getSignCounts());
						loginRewardAreaDao.newEntity(record);
						records.put(record.getAreaId(), record);
					}
				}
			} else {
				for (LoginRewardArea lr : list) {
					if (lr != null) {
						records.put(lr.getAreaId(), lr);
					}
				}
			}
			map.put(activityId, records);
			element = new Element(playerId, map);
			cache.put(element);
			return map;
		}
	}

	public void updatePlayerLoginArea(LoginRewardArea area) {
		loginRewardAreaDao.updateEntity(area);
		Cache cache = getCache(LOGIN_REWARD_AREA_CACHE);
		ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardArea>> map = getPlayerLoginRewardAreas(
				area.getPlayerId(), area.getActivityId());
		map.get(area.getActivityId()).put(area.getAreaId(), area);
		Element element = new Element(area.getPlayerId(), map);
		cache.put(element);
	}

	public void reward(Player player, int signCounts) {

		LoginReward loginReward = loginRewards.get(signCounts);
		if (loginReward != null) {
			if (loginReward.getRewardType() == AttributeType.MONEY.getAttributeType()
					|| loginReward.getRewardType() == AttributeType.GOLD.getAttributeType()) {
				PlayerTransaction tx = player.newTransaction("loginRewardActivity");
				player.addAttributeByType(AttributeType.getAttrtType(loginReward.getRewardId()),
						loginReward.getRewardCounts(), tx);
				tx.commit();
			} else {
				long cdTime = -1;
				ClothCdTime clothCdTime = ItemService.getInstance().clothCdTimes.get(loginReward.getCdTimeType());
				if (clothCdTime != null) {
					cdTime = clothCdTime.getCdTime();
				}
				player.getBags().addItem(loginReward.getRewardId(), loginReward.getRewardCounts(),
						"loginRewardActivity", cdTime);
			}
		}
		if (signCounts >= 7) {
			player.getBags().addItem(loginRewardConfig.getBackGroundId(), 1, "完成7日登陆", -1);
		}
	}

	public LoginRewardRecord getPlayerLoginRewardRecord(int playerId, int activityId, int signCounts) {
		ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardRecord>> map = getPlayerLoginRewardRecords(
				playerId, activityId);
		return map.get(activityId).get(signCounts);
	}

	public LoginRewardArea getPlayerLoginRewardArea(int playerId, int activityId, int areaId) {
		ConcurrentHashMap<Integer, ConcurrentHashMap<Integer, LoginRewardArea>> map = getPlayerLoginRewardAreas(
				playerId, activityId);
		return map.get(activityId).get(areaId);
	}
}
