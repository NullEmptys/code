package com.gamedo.gameServer.entity.quest;

import java.io.Serializable;
import java.util.Date;

/**
 * 玩家任务
 * @author libm
 *
 */
public class PlayerQuest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2086634928982591866L;
	
	public static final int COMMON = 0;//默认状态
	public static final int FINISHED = 1;//已完成
	public static final int ACCEPTED = 2;//已接受
	public static final int LOCKED = 1;//已锁住
	public static final int NOTIFYED = 1;//已通知成功
	
	private int id;
	private int playerId;
	/**章节子关卡id*/
	private int questId;
	private int category;
	/**任务完成状态 0-未完成   1-已完成   2-已接受*/
	private int state;
	/**任务锁住状态0-默认状态 1-已锁住*/
	private int locked;
	private int value;
	private Date endTime;
	private String msgId;
	private int notifyed;
	
	public int getQuestId() {
		return questId;
	}
	public void setQuestId(int questId) {
		this.questId = questId;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getPrimaryKey() {
		return locked << 24 | state << 16 | questId;
	}
	public int getLocked() {
		return locked;
	}
	public void setLocked(int locked) {
		this.locked = locked;
	}
	public static PlayerQuest getBusinessQuest(int primaryKey){
		PlayerQuest quest = new PlayerQuest();
		quest.locked = primaryKey >> 24;
		quest.state = (primaryKey & 0x00FF0000) >> 16;
		quest.questId = primaryKey & 0x0000FFFF;
		return quest;
	}
	
	public static void main(String[] args) {
		PlayerQuest quest = new PlayerQuest();
		quest.questId = 1;
		quest.state = 2;
		quest.locked = 1;
		int pk = quest.getPrimaryKey();
		System.out.println(pk);
		System.out.println(getBusinessQuest(1001));
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public String getMsgId() {
		return msgId;
	}
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
	public int getNotifyed() {
		return notifyed;
	}
	public void setNotifyed(int notifyed) {
		this.notifyed = notifyed;
	}
	
}
