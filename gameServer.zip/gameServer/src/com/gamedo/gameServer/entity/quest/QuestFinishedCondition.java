package com.gamedo.gameServer.entity.quest;

import java.io.Serializable;
import java.util.Date;

import gnu.trove.map.hash.TIntIntHashMap;

/**
 * 玩家任务达成条件
 * @author libm
 *
 */
public class QuestFinishedCondition implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3353980672919874375L;

	private int id;
	
	private int playerId;
	
	private int questId;
	
	private String finishedConditionStr;
	
	public TIntIntHashMap finishedCondtionIds = new TIntIntHashMap();
	
	private int day;
	
	private Date createTime;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getQuestId() {
		return questId;
	}

	public void setQuestId(int questId) {
		this.questId = questId;
	}

	public String getFinishedConditionStr() {
		this.finishedConditionStr = mapToStr();
		return finishedConditionStr;
	}

	public void setFinishedConditionStr(String finishedConditionStr) {
		this.finishedConditionStr = finishedConditionStr;
		parseConditionStr();
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	public void parseConditionStr() {
		if(finishedConditionStr != null && !finishedConditionStr.equals("")) {
			String[] conditions = finishedConditionStr.split(";");
			if(conditions != null && conditions.length > 0) {
				for(int i = 0; i < conditions.length; i++) {
					if(conditions[i] != null) {
						String conditionStr = conditions[i];
						int condition = Integer.parseInt(conditionStr);
						this.finishedCondtionIds.put(condition, condition);
					}
				}
			}
		}
	}
	
	public String mapToStr() {
		String finishedConditionStr = "";
		if(finishedCondtionIds != null && finishedCondtionIds.size() > 0) {
			for(Integer condtionId : finishedCondtionIds.keys()) {
				if(condtionId != null) {
					finishedConditionStr = finishedConditionStr + condtionId + ";";
				}
			}
		}
		return finishedConditionStr;
	}
}
