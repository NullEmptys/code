package com.gamedo.gameServer.entity.quest;

import java.io.Serializable;

/**
 * 玩家任务章节记录
 * @author libm
 *
 */
public class PlayerQuestChapter implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2795772132719451625L;
	
	private int id;
	/**角色id*/
	private int playerId;
	/**章节id*/
	private int chapterId;
	/**类型 0：普通  1：困难*/
	private int type;
	/**是否领取完章节奖励 0：否   1：是*/
	private int isReward;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getChapterId() {
		return chapterId;
	}

	public void setChapterId(int chapterId) {
		this.chapterId = chapterId;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getIsReward() {
		return isReward;
	}

	public void setIsReward(int isReward) {
		this.isReward = isReward;
	}
	
	
}
