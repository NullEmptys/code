package com.gamedo.gameServer.entity.dailymission;

import java.io.Serializable;
import java.util.Date;
/**
 * 玩家每日任务
 * @author IPOC-HUANGPING
 *
 */
public class PlayerActive implements Serializable{

	public static final int DAILY_REWARD = 1;//领取每日宝箱奖励
	public static final int WEEK_REWARD =2;//领取周宝箱奖励
	public static final int MISSION_REWARD=3;//领取任务奖励
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	/**玩家id*/
	private int playerId;
	/**当前日活跃度值*/
	private int dailyActiveValue;
	/**当前周活跃度值*/
	private int weekActiveValue;
	/**已领取日活动奖励*/
	private String dailyRewards;
	/**已领取周活动奖励*/
	private String weekRewards;
	/**每日刷新时间   */
	private Date dayRefresh;
	/**每周属性时间*/
	private Date weekRefresh;
	/**创建时间*/
	private Date createTime;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getDailyActiveValue() {
		return dailyActiveValue;
	}
	public void setDailyActiveValue(int dailyActiveValue) {
		this.dailyActiveValue = dailyActiveValue;
	}
	public int getWeekActiveValue() {
		return weekActiveValue;
	}
	public void setWeekActiveValue(int weekActiveValue) {
		this.weekActiveValue = weekActiveValue;
	}
	public String getDailyRewards() {
		return dailyRewards;
	}
	public void setDailyRewards(String dailyRewards) {
		this.dailyRewards = dailyRewards;
	}
	public String getWeekRewards() {
		return weekRewards;
	}
	public void setWeekRewards(String weekRewards) {
		this.weekRewards = weekRewards;
	}
	public Date getDayRefresh() {
		return dayRefresh;
	}
	public void setDayRefresh(Date dayRefresh) {
		this.dayRefresh = dayRefresh;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getWeekRefresh() {
		return weekRefresh;
	}
	public void setWeekRefresh(Date weekRefresh) {
		this.weekRefresh = weekRefresh;
	}
}
