package com.gamedo.gameServer.entity.player;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.gamedo.gameServer.constant.PlayType;
import com.gamedo.gameServer.core.BaseUnit;
import com.gamedo.gameServer.core.Updatable;
import com.gamedo.gameServer.core.bag.Bag;
import com.gamedo.gameServer.core.bag.BagGrid;
import com.gamedo.gameServer.core.bag.Bags;
import com.gamedo.gameServer.core.bag.GirlBags;
import com.gamedo.gameServer.core.item.Equipments;
import com.gamedo.gameServer.core.item.EquipmentsEx;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.message.player.BagData;
import com.gamedo.gameServer.message.player.BagInfo;
import com.gamedo.gameServer.message.player.BagItemInfo;
import com.gamedo.gameServer.util.Const;

/**
 * 模特
 * 
 * @author libm
 *
 */
public class PlayerGirl extends BaseUnit implements Updatable, Serializable {
	private static final long serialVersionUID = -5529369192264387491L;
	// 已签约
	public static final int ON_SIGNED = 1;
	// 未签约
	public static final int OFF_SIGNED = 0;
	public Player defaultPlayer = new Player();

	private int id;

	private int playerId;

	private int girlId;
	/**
	 * 当前等级
	 */
	private int level = 0;
	/**
	 * 当前经验值
	 */
	private int exp = 0;
	// 有效时间
	private long cdTime = 0;
	/**
	 * 服装 key:场景id 0：默认 1:核心玩法
	 */
	protected ConcurrentHashMap<Integer, Equipments> equs;

	/** 背包 */
	private GirlBags bags;

	// 状态
	public int status = OFF_SIGNED;

	public PlayerGirl() {
		ConcurrentHashMap<Integer, Equipments> equips = new ConcurrentHashMap<>();
		for (PlayType playType : PlayType.values()) {
			if (playType != null) {
				equips.put(playType.getType(), new EquipmentsEx(this));
			}
		}
		this.setEqus(equips);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public GirlBags getBags() {
		return bags;
	}

	public void setBags(GirlBags bags) {
		this.bags = bags;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int newLevel) {
		if (newLevel != this.level) {
			this.level = newLevel;
		}
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		if (this.exp != exp) {
			this.exp = exp;
		}
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public long getCdTime() {
		return cdTime;
	}

	public void setCdTime(long cdTime) {
		this.cdTime = cdTime;
	}

	/**
	 * 初始化背包
	 * 
	 * @param player
	 * @return
	 */
	public GirlBags initBags(Player player, int girlId) {
		GirlBags bags = new GirlBags(defaultPlayer, 2, 2, girlId);
		Bag equipBag = new Bag(bags, Const.BAG_EQUIP, 500, 0);// 服装类背包
		Bag actionBag = new Bag(bags, Const.BAG_ACTION, 500, 0);// 动作类背包
		bags.addBag(equipBag);
		bags.addBag(actionBag);
		return bags;
	}

	public void setEqus(ConcurrentHashMap<Integer, Equipments> equs) {
		this.equs = equs;
	}

	public ConcurrentHashMap<Integer, Equipments> getEquipments() {
		return equs;
	}

	public void setEquipments(ConcurrentHashMap<Integer, Equipments> equs) {
		this.setEqus(equs);
	}

	public BagData getBagData() {
		BagData bagData = new BagData();

		List<BagInfo> bagInfos = new ArrayList<>();
		Bags bags = this.getBags();
		if (bags != null) {
			List<Bag> list = bags.getBags();
			if (list != null && list.size() > 0) {
				for (Bag bag : list) {
					if (bag != null) {
						BagInfo bagInfo = new BagInfo();
						bagInfo.setBagId(bag.getId());
						bagInfo.setItems(getBagItemsById(bag.getId()));
						bagInfos.add(bagInfo);
					}
				}

			}
		}
		bagData.setBags(bagInfos);
		return bagData;
	}

	/**
	 * 获取指定背包中的所有物品详细信息
	 * 
	 * @param bagId
	 *            背包id 0：消耗品类背包 1：服装类背包
	 * @return
	 */
	private List<BagItemInfo> getBagItemsById(int bagId) {
		Bag bag = this.getBags().getBag(bagId);
		if (bag != null) {
			List<BagItemInfo> items = new ArrayList<>();
			List<BagGrid> grids = bag.getGrids();
			if (grids != null && grids.size() > 0) {
				for (BagGrid grid : grids) {
					if (grid != null && grid.getItem() != null) {
						GameItem gameItem = grid.getItem();
						BagItemInfo bagItemInfo = new BagItemInfo();
						bagItemInfo.setGridId(grid.id);
						bagItemInfo.setCount(grid.getCount());
						bagItemInfo.setInstanceId(gameItem.getInstanceId());
						bagItemInfo.setItemId(gameItem.getTemplate().getId());
						bagItemInfo.setCdTime(gameItem.getObsoleteTime());
						bagItemInfo.setCreateTime(gameItem.getCreateTime());
						items.add(bagItemInfo);
					}
				}
			}
			return items;
		}
		return null;
	}

	@Override
	public boolean update() {
		return false;
	}

}
