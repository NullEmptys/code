package com.gamedo.gameServer.entity.achievement;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.BinaryType;
import org.hibernate.usertype.UserType;

import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

/**
 * 
 * @author libm
 *
 */
public class AchievementUserType implements UserType{

	private static final int[] SQL_TYPES = { BinaryType.INSTANCE.sqlType()};
	
	@Override
	public Object assemble(Serializable cached, Object arg1) throws HibernateException {
		return cached;
	}

	@Override
	public Object deepCopy(Object value) throws HibernateException {
		return value;
	}

	@Override
	public Serializable disassemble(Object value) throws HibernateException {
		return (Serializable) value;
	}

	@Override
	public boolean equals(Object x, Object y) throws HibernateException {
		if (x == y)
			return true;
		if (x == null || y == null)
			return false;
		return x.equals(y);
	}

	@Override
	public int hashCode(Object value) throws HibernateException {
		return value.hashCode();
	}

	@Override
	public boolean isMutable() {
		return true;
	}

	@Override
	public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor arg2, Object owner)
			throws HibernateException, SQLException {
		byte[] bytes = rs.getBytes(names[0]);
        if(bytes==null){
            return new TIntObjectHashMap<PlayerAchievement>();
        }else{
        	return getAchievementsFromDBBytes(bytes);
        }
	}

	@Override
	public void nullSafeSet(PreparedStatement ps, Object value, int index, SessionImplementor arg3)
			throws HibernateException, SQLException {
		if (value != null)
            ps.setBytes(index, getAchievementDBBytes((TIntObjectHashMap<PlayerAchievement>)value));
        else {
            ps.setNull(index, SQL_TYPES[0]);
        }
	}

	@Override
	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return target;
	}

	@Override
	public Class returnedClass() {
		return  TIntObjectHashMap.class;
	}

	@Override
	public int[] sqlTypes() {
		return SQL_TYPES;
	}
	
	public static TIntObjectMap<PlayerAchievement> getAchievementsFromDBBytes(byte[] bytes){
		ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
		DataInputStream dis = new DataInputStream(bais);
		TIntObjectMap<PlayerAchievement> map = new TIntObjectHashMap<PlayerAchievement>();
		try {
			
			int version = dis.read();
			int count = dis.readInt();
			for(int i = 0; i < count; i++){
				PlayerAchievement a = new PlayerAchievement();
				int id = dis.readInt();
				byte finish = dis.readByte();
				int value = dis.readInt();
				byte rewarded = dis.readByte();
				
				a.id = id;
				a.finished = (finish == 1);
				a.value = value;
				a.rewarded = (rewarded == 1);
				map.put(id, a);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map;
	}
	
	public static byte[] getAchievementDBBytes(TIntObjectHashMap<PlayerAchievement> value) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(2000);
		DataOutputStream dos = new DataOutputStream(baos);
		try {
			dos.write(1);
			dos.writeInt(value.size());
			for(int key : value.keys()){
				PlayerAchievement a = value.get(key);
				dos.writeInt(a.id);
				dos.write(a.finished? 1:0);
				dos.writeInt(a.value);
				dos.write(a.rewarded ? 1 : 0);
			}
			return baos.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
