package com.gamedo.gameServer.entity.engagement;

import java.io.Serializable;
import java.util.Date;

/**
 * 约会场景
 * @author libm
 *
 */
public class EngagementScene implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6255540157442798805L;

	private int id;
	
	private Date lastTime;
	
	private int sceneId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getLastTime() {
		return lastTime;
	}

	public void setLastTime(Date lastTime) {
		this.lastTime = lastTime;
	}

	public int getSceneId() {
		return sceneId;
	}

	public void setSceneId(int sceneId) {
		this.sceneId = sceneId;
	}
	
}
