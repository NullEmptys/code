package com.gamedo.gameServer.entity.mail;

import java.io.Serializable;
import java.util.Date;
/**
 * 全服邮件
 * @author IPOC-HUANGPING
 *
 */
public class GmMail implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7871340340954353701L;
	
	private int id;
	/*邮件标题*/
	private String title;
	/*邮件内容*/
	private String content;
	/*邮件附件*/
	private MailAttachments attachments;
	/*全服邮件发送时间*/
	private Date date; 
	/*发件人*/
	private String name;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public MailAttachments getAttachments() {
		return attachments;
	}
	public void setAttachments(MailAttachments attachments) {
		this.attachments = attachments;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
