package com.gamedo.gameServer.entity.mail;

import java.io.Serializable;
import java.util.Date;

/**
 * 邮件
 * @author libm
 *
 */
public class Mail implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7871340340954353701L;
	
	private int id;
	/*玩家id*/
	private int playerId;
	/*发送者id  系统：-1*/
	private int sourceId;
	/*发送邮件人*/
	private String sendName;
	/*邮件标题*/
	private String title;
	/*邮件内容*/
	private String content;
	/*发送时间*/
	private Date postTime;
	/*失效时间*/
	private Date expirationTime;
	/*邮件附件*/
	private MailAttachments attachments;
	/*邮件状态*/
	private int status;
	/*附件状态  0-未领取  1-已领取*/
	private int receivedAttach;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getSourceId() {
		return sourceId;
	}
	public void setSourceId(int sourceId) {
		this.sourceId = sourceId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getPostTime() {
		return postTime;
	}
	public void setPostTime(Date postTime) {
		this.postTime = postTime;
	}
	public Date getExpirationTime() {
		return expirationTime;
	}
	public void setExpirationTime(Date expirationTime) {
		this.expirationTime = expirationTime;
	}
	public MailAttachments getAttachments() {
		return attachments;
	}
	public void setAttachments(MailAttachments attachments) {
		this.attachments = attachments;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getSendName() {
		return sendName;
	}
	public void setSendName(String sendName) {
		this.sendName = sendName;
	}
	public int getReceivedAttach() {
		return receivedAttach;
	}
	public void setReceivedAttach(int receivedAttach) {
		this.receivedAttach = receivedAttach;
	}
	
}
