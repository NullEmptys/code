package com.gamedo.gameServer.entity.mail;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;

/**
 * 附件类型为添加货币
 * @author libm
 *
 */
public class MoneyMailAttachment implements MailAttachment,Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8076423787135877150L;
	
	private int currencyType;
	
	protected int count;
	
	public MoneyMailAttachment(int currencyType,int count){
		this.currencyType = currencyType;
		this.count = count;
	}
	
	public int getCount(){
		return count;
	}
	
	public byte[] toClientBytes() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);
		try{
			dos.write(2); //类型标示，标示金钱
			dos.writeInt(currencyType);
			dos.writeInt(count);
		}catch(IOException ex){
			ex.printStackTrace();
		}
		return baos.toByteArray();
	}
	
	@Override
	public MoneyMailAttachment clone(){
		return new MoneyMailAttachment(currencyType,count);
	}

	public int getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	public void setCount(int count) {
		this.count = count;
	}

}

