package com.gamedo.gameServer.entity.mail;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.hibernate.HibernateException;

import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.util.ItemUtil;

/**
 * 
 * @author libm
 *
 */
public class MailUtil {

	public static MailAttachments getMailAttacmentsFromDB(DataInputStream dis) throws IOException{
		int version = dis.read();
		int len = dis.read();
		MailAttachment[] mas = new MailAttachment[len];
		for(int i=0;i<len;i++){
			mas[i] = getMailAttachmentFromDB(dis);
		}
		return new MailAttachments(mas);
	}
	
	public static MailAttachment getMailAttachmentFromDB(DataInputStream dis){
		try {
			int version = dis.read();//version
			int type = dis.read();
			if(type == 1) {//物品
				int count = dis.readInt();
				long cdTime = dis.readLong();
				GameItem item = ItemUtil.getGameItemFromDB(dis);
				return new ItemMailAttachment(item,count,cdTime);
			}else if(type==2){ //money
				int cuuencyType = dis.readInt();
				int count = dis.readInt();
				return new MoneyMailAttachment(cuuencyType,count);
			}
		} catch (IOException e) {
			throw new HibernateException(e);
		}
		return null;
	}
	
	public static void getAttachmentsDBytes(MailAttachments atts,
			DataOutputStream dos) throws IOException {
		MailAttachment[] mas = atts.getAttachments();
		if (atts != null || mas != null || mas.length > 0) {
			dos.write(1);// version
			dos.write(mas.length);
			for (MailAttachment ma : mas) {
				if (ma instanceof MoneyMailAttachment) {
					getAttachmentDBBytes((MoneyMailAttachment) ma, dos);
				} else if(ma instanceof ItemMailAttachment) {
					getAttachmentDBBytes((ItemMailAttachment) ma, dos);
				}else {
					throw new IllegalArgumentException();
				}
			}
		}
	}
	
	public static void getAttachmentDBBytes(MoneyMailAttachment attachment,
			DataOutputStream dos) throws IOException {
		dos.write(1);// version
		dos.write(2);
		dos.writeInt(attachment.getCurrencyType());
		dos.writeInt(attachment.getCount());
	}
	
	public static byte[] getAttachmentDBBytes(ItemMailAttachment attachment) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);
		try {
			getAttachmentDBBytes(attachment, dos);
		} catch (IOException e) {
			throw new HibernateException(e);
		}
		
		return baos.toByteArray();
	}
	
	public static void getAttachmentDBBytes(ItemMailAttachment attachment,
			DataOutputStream dos) throws IOException {
		dos.write(1);// version
		dos.write(1);
		dos.writeInt(attachment.getCount());
		dos.writeLong(attachment.getCdTime());
		dos.write(ItemUtil.getGameItemDBBytes(attachment.getGameItem()));
	}
}
