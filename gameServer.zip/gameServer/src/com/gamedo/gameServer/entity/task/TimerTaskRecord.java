package com.gamedo.gameServer.entity.task;

import java.util.Calendar;

import com.gamedo.gameServer.service.task.TimerTask;

/**
 * 定时任务记录表
 * @author libm
 *
 */
public class TimerTaskRecord {

	private Calendar nextTime;
	private TimerTask task;
	private String uid;

	/**
	 * @param task
	 */
	public TimerTaskRecord(TimerTask task) {
		this.task = task;
	}

	/**
	 * @return
	 */
	public Calendar getNextTime() {
		return nextTime;
	}

	/**
	 * @return the task
	 */
	public TimerTask getTask() {
		return task;
	}

	/**
	 * @return the uid
	 */
	public String getUid() {
		return uid;
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public boolean invoke() throws Exception {
		return task.invoke();
	}

	/**
	 * @param nextTime the nextTime to set
	 */
	public void setNextTime(Calendar nextTime) {
		this.nextTime = nextTime;
	}

	/**
	 * @param task the task to set
	 */
	public void setTask(TimerTask task) {
		this.task = task;
	}

	/**
	 * @param uid the uid to set
	 */
	public void setUid(String uid) {
		this.uid = uid;
	}
}
