package com.gamedo.gameServer.entity.activity.loginReward;

import java.io.Serializable;

/**
 * 7日登录活动 签到记录
 * @author libm
 *
 */
public class LoginSignRecord implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5010268590959273462L;
	private int id;
	/**
	 * 活动id
	 */
	private int activityId;
	/**
	 * 角色id
	 */
	private int playerId;
	/**
	 * 累计签到次数
	 */
	private int signCounts;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getSignCounts() {
		return signCounts;
	}

	public void setSignCounts(int signCounts) {
		this.signCounts = signCounts;
	}
	
}
