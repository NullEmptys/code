package com.gamedo.gameServer.entity.activity.exchTicket;

import java.io.Serializable;

/**
 * 玩家兑换记录
 * @author IPOC-HUANGPING
 *
 */
public class PlayerActivityExchRec implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private int activityId;
	private int playerId;
	private int ticketId;//兑换的卷id
	private String ticketNum;//兑换卷后生成的编码.若ticketId=1时，则记录该票的兑换数量

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public String getTicketNum() {
		return ticketNum;
	}

	public void setTicketNum(String ticketNum) {
		this.ticketNum = ticketNum;
	}
}
