package com.gamedo.gameServer.entity.activity.exchTicket;

import java.io.Serializable;

/**
 * 活动兑换记录
 * 
 * @author IPOC-HUANGPING
 *
 */
public class ActivityExchRecord implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 自增id
	private int id;
	// 活动id
	private int activityId;
	// 兑换票id
	private String ticketId;
	// 兑换票数量
	private String ticketNum;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}

	public String getTicketId() {
		return ticketId;
	}

	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}

	public String getTicketNum() {
		return ticketNum;
	}

	public void setTicketNum(String ticketNum) {
		this.ticketNum = ticketNum;
	}
}
