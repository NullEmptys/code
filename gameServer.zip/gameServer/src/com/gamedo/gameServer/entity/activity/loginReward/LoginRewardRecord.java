package com.gamedo.gameServer.entity.activity.loginReward;

import java.io.Serializable;

/**
 * 登录奖励记录
 * @author libm
 *
 */
public class LoginRewardRecord implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3626771132381756496L;

	private int id;
	
	/**
	 * 活动id
	 */
	private int activityId;
	
	/**
	 * 角色id
	 */
	private int playerId;
	
	/**
	 * 活动期间内累计登录天数
	 */
	private int day;
	
	/**
	 * 0、未签到
	 * 1、已签到
	 */
	private int state;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}

}
