package com.gamedo.gameServer.entity.girl;

import java.io.Serializable;
import java.util.Date;

/**
 * 每日限免模特记录
 * @author libm
 *
 */
public class FreeGirlRecord implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2549221508317221135L;

	private int id;
	
	private int girlId;
	
	private Date createTime;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
}
