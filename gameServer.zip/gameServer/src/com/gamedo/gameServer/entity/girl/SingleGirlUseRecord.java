package com.gamedo.gameServer.entity.girl;

import java.io.Serializable;

/**
 * 玩家对应模特每周使用记录
 * @author libm
 *
 */
public class SingleGirlUseRecord implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5923837710075440445L;

	private int id;
	
	/**
	 * 角色id
	 */
	private int playerId;
	/**
	 * 模特id
	 */
	private int girlId;
	/**
	 * 
	 */
	private int weekOfYear;
	/**
	 * 每周使用次数
	 */
	private int useCounts;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public int getWeekOfYear() {
		return weekOfYear;
	}

	public void setWeekOfYear(int weekOfYear) {
		this.weekOfYear = weekOfYear;
	}

	public int getUseCounts() {
		return useCounts;
	}

	public void setUseCounts(int useCounts) {
		this.useCounts = useCounts;
	}
	
}
