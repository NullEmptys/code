package com.gamedo.gameServer.entity.monthsign;

import java.io.Serializable;
import java.util.Date;
/**
 * 玩家月签记录
 * @author IPOC-HUANGPING
 *
 */
public class PlayerMonthSignRec implements Serializable{
	
	/**序列化id*/
	private static final long serialVersionUID = 1L;

	private int id;
	/**角色ID*/
	private int playerId;
	/**月登录天数累积*/
	private int loginCnt;
	/**已领取天列表*/
	private String monthSignStr;
	/**刷新时间*/
	private Date dayRefreshTime;
	/**创建时间*/
	private Date createTime;
//	/**更新时间*/
//	private Date updateTime;
	
//	private String signDaysStr;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getLoginCnt() {
		return loginCnt;
	}
	public void setLoginCnt(int loginCnt) {
		this.loginCnt = loginCnt;
	}
	public String getMonthSignStr() {
		return monthSignStr;
	}
	public void setMonthSignStr(String monthSignStr) {
		this.monthSignStr = monthSignStr;
	}
	public Date getDayRefreshTime() {
		return dayRefreshTime;
	}
	public void setDayRefreshTime(Date dayRefreshTime) {
		this.dayRefreshTime = dayRefreshTime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
//	public Date getUpdateTime() {
//		return updateTime;
//	}
//	public void setUpdateTime(Date updateTime) {
//		this.updateTime = updateTime;
//	}
//	public String getSignDaysStr() {
//		return signDaysStr;
//	}
//	public void setSignDaysStr(String signDaysStr) {
//		this.signDaysStr = signDaysStr;
//		parseStr(signDaysStr);
//	}
//	private void parseStr(String signDaysStr2) {
//		monthSignList = new ArrayList<>();
//	}
	
}
