package com.gamedo.gameServer.exception;

public class ValueLimitException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1712371887177454779L;

}
