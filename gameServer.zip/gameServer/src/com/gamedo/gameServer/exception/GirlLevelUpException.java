package com.gamedo.gameServer.exception;

public class GirlLevelUpException extends Exception {
	private static final long serialVersionUID = -4246758403580639315L;

	public GirlLevelUpException(String message) {
		super(message);
	}

	public GirlLevelUpException(Throwable cause) {
		super(cause);
	}

	public GirlLevelUpException(String message, Throwable cause) {
		super(message, cause);
	}
}
