package com.gamedo.gameServer.exception;

/**
 * 
 * @author libm
 *
 */
public class GainException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6704015021386595886L;

	public GainException(String message) {
		super(message);
	}

	public GainException(Throwable cause) {
		super(cause);
	}

	public GainException(String message, Throwable cause) {
		super(message, cause);
	}

}