package com.gamedo.gameServer.exception;

/**
 * 
 * @author libm
 *
 */
public class TransactionException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7205960020334852268L;

	public TransactionException(){
		super();
	}
	
	public TransactionException(String msg){
		super(msg);
	}
}
