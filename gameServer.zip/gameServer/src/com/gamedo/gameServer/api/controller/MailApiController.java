package com.gamedo.gameServer.api.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.item.ItemTemplate;
import com.gamedo.gameServer.data.girl.Girl;
import com.gamedo.gameServer.db.editor.GirlDao;
import com.gamedo.gameServer.entity.mail.GmMail;
import com.gamedo.gameServer.entity.mail.ItemMailAttachment;
import com.gamedo.gameServer.entity.mail.MailAttachment;
import com.gamedo.gameServer.entity.mail.MailAttachments;
import com.gamedo.gameServer.entity.mail.MoneyMailAttachment;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.mail.MailService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 邮件api
 * 
 * @author liuxing
 *
 */
@Controller
@RequestMapping(value = "/api/mail")
public class MailApiController extends BaseApiController {
	@Autowired
	private MailService mailService;
	@Autowired
	private ItemService itemService;
	@Autowired
	private PlayerService playerService;
	@Autowired
	private GirlDao girlDao;
	private final static String SEND_MAIL = "/sendMail";

	@RequestMapping(value = "/sendMail", method = RequestMethod.POST)
	public void sendMail(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(SEND_MAIL, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		int targetPlayerId = (int) json.get("targetPlayerId");
		String title = (String) json.get("title");
		String content = (String) json.get("content");
		// 附件
		List<?> list = (List<?>) json.get("mark");
		MailAttachment[] mailAttachments = null;
		if (!list.isEmpty() && list.size() > 0) {
			mailAttachments = new MailAttachment[list.size()];
			int i = 0;
			for (Object object : list) {
				if (object instanceof Map) {
					String type = (String) ((Map<?, ?>) object).get("type");
					int itemId = (Integer) ((Map<?, ?>) object).get("itemId");
					Long count = 0l;
					Object num = ((Map<?, ?>) object).get("count");
					if (num instanceof Integer) {
						count = Long.parseLong(Integer.toString((int) num));
					} else if (num instanceof Long) {
						count = (Long) num;
					}
					// long count = (Long) ((Map<?, ?>) object).get("count");

					if ("item".equals(type)) {
						String category = (String) ((Map<?, ?>) object).get("category");
						ItemTemplate template = itemService.getItemTemplate(itemId);
						GameItem item = itemService.createGameItem(template);
						if (category.equals("0")) {
							ItemMailAttachment itemAttachment = new ItemMailAttachment(item,
									Integer.parseInt(Long.toString(count)), -1);
							mailAttachments[i] = itemAttachment;
						} else {
							// 时效
							ItemMailAttachment itemAttachment = new ItemMailAttachment(item, 1,
									Long.parseLong(Long.toString(count)));
							mailAttachments[i] = itemAttachment;
						}

					} else if ("money".equals(type)) {
						MoneyMailAttachment moneyAttachment = new MoneyMailAttachment(itemId,
								Integer.parseInt(Long.toString(count)));
						mailAttachments[i] = moneyAttachment;
					} else if ("gold".equals(type)) {
						MoneyMailAttachment goldAttachment = new MoneyMailAttachment(itemId,
								Integer.parseInt(Long.toString(count)));
						mailAttachments[i] = goldAttachment;
					}
				}
				i++;
			}
		}

		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
		// 防止请求超时
		if (targetPlayerId > 0) {
			mailService.sendMail(targetPlayerId, title, content, new MailAttachments(mailAttachments));
		} else if (targetPlayerId == -1) {
			// 全服玩家
			GmMail gmMail = mailService.saveAllServerMail(title, content, new MailAttachments(mailAttachments), "GM");
			Map<Integer, String> mailMap = playerService.getOnlinePlayerIdAndNames();
			if (mailMap != null && gmMail != null) {
				for (int playerId : mailMap.keySet()) {
					mailService.sendMail(playerId, title, content, new MailAttachments(mailAttachments));
					mailService.saveSendMailPlayer(playerId, gmMail.getId());
				}
			}
		} else if (targetPlayerId == -2) {
			// 全部模特
			List<Girl> girlList = girlDao.loadGirls();
			for (Girl girl : girlList) {
				mailService.sendMail(girl.getId(), title, content, new MailAttachments(mailAttachments));
			}
		}

	}
}
