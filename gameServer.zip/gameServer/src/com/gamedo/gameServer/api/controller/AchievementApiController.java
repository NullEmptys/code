package com.gamedo.gameServer.api.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.api.message.AchievementDataListReponseMessage;
import com.gamedo.gameServer.api.message.AchievementInfoDataReponseMessage;
import com.gamedo.gameServer.data.achievement.Achievement;
import com.gamedo.gameServer.entity.achievement.PlayerAchievement;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.achievement.AchieveInfo;
import com.gamedo.gameServer.service.achievement.AchievementService;
import com.gamedo.gameServer.service.player.PlayerService;

@Controller
@RequestMapping(value = "/api/achievement")
public class AchievementApiController extends BaseApiController {
	private final static String ACHIEVEMENT_LIST = "/activityList";
	private final static String ACHIEVEMENT_INFO = "/activityInfo";
	private final static String ACHIEVEMENT_UPDATE = "/activityList";

	@Autowired
	private PlayerService playerService;
	@Autowired
	private AchievementService achieveService;

	/**
	 * 查询成就列表
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/list", method = RequestMethod.POST)
	public void loadAchievementList(@PathVariable("id") int id, HttpServletRequest request,
			HttpServletResponse response) {
		Packet packet = new Packet(ACHIEVEMENT_LIST, request, response);
		AchievementDataListReponseMessage message = new AchievementDataListReponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		Map<String, Object> json = this.getRequestMessage(request);
		Object category = json.get("category");
		if (category == null) {
			message.setCode(CommonResponseMessage.TRUE);
			packet.send(message);
			return;
		}
		int type = 0;
		if (category instanceof Integer) {
			type = (Integer) category;
		} else if (category instanceof String) {
			type = Integer.parseInt((String) category);
		}

		Object searchAchieveId = json.get("achieveId");
		List<Map<String, Object>> achievementList = new ArrayList<Map<String, Object>>();
		List<AchieveInfo> achieves = achieveService.getAchieveInfoList(player, type);
		for (AchieveInfo achieveInfo : achieves) {
			Achievement achievement = achieveService.loadAchievementById(achieveInfo.getAchieveId());
			Map<String, Object> achieve = new HashMap<String, Object>();
			achieve.put("achieveId", achievement.getId());
			achieve.put("name", achievement.getName());
			achieve.put("description", achievement.getDescription());
			achieve.put("finished", achieveInfo.getFinished());
			achieve.put("rewarded", achieveInfo.getRewarded());
			achieve.put("value", achieveInfo.getValue());
			achieve.put("allValue", achievement.getValue());
			if (searchAchieveId != null) {
				int achieveId = 0;
				if (searchAchieveId instanceof Integer) {
					achieveId = (Integer) searchAchieveId;
				} else if (category instanceof String) {
					achieveId = Integer.parseInt((String) searchAchieveId);
				}
				if (achieveId == achieveInfo.getAchieveId()) {
					achievementList.add(achieve);
				}
			} else {
				achievementList.add(achieve);
			}
		}
		message.setAchievementList(achievementList);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	@RequestMapping(value = "/{id}/{achieveId}", method = RequestMethod.GET)
	public void getAchievement(@PathVariable("id") int id, @PathVariable("achieveId") int achieveId,
			HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(ACHIEVEMENT_INFO, request, response);
		AchievementInfoDataReponseMessage message = new AchievementInfoDataReponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		Map<String, Object> achievementInfo = new HashMap<String, Object>();
		Achievement achievement = achieveService.loadAchievementById(id);
		if (achievement == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		achievementInfo.put("allValue", achievement.getValue());
		PlayerAchievement playerAchievement = achieveService.getAchieveInfo(player, achieveId);
		if (playerAchievement == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		achievementInfo.put("value", playerAchievement.value);
		achievementInfo.put("rewarded", playerAchievement.rewarded);
		message.setAchievementInfo(achievementInfo);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 修改成就
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/update", method = RequestMethod.POST)
	public void updateAchievement(@PathVariable("id") int id, HttpServletRequest request,
			HttpServletResponse response) {
		Packet packet = new Packet(ACHIEVEMENT_UPDATE, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		int achieveId = 0;
		Object objAchieveId = json.get("achieveId");
		if (objAchieveId instanceof Integer) {
			achieveId = (Integer) objAchieveId;
		} else if (objAchieveId instanceof String) {
			achieveId = Integer.parseInt((String) objAchieveId);
		}
		int value = 0;
		Object objValue = json.get("value");
		if (objValue instanceof Integer) {
			value = (Integer) objValue;
		} else if (objValue instanceof String) {
			value = Integer.parseInt((String) objValue);
		}
		String rewarded = "false";
		Object objRewarded = json.get("rewarded");
		if (objRewarded instanceof String) {
			rewarded = (String) objRewarded;
		}
		achieveService.updatePlayerAchieve(player, achieveId, value, Boolean.parseBoolean(rewarded));
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}
}
