package com.gamedo.gameServer.api.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.activity.Activity;
import com.gamedo.gameServer.api.message.AnnouncementDataListReponseMessage;
import com.gamedo.gameServer.api.message.AnnouncementDataReponseMessage;
import com.gamedo.gameServer.data.announcement.Announcement;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.service.announcement.AnnouncementService;

@Controller
@RequestMapping(value = "/api/announcement")
public class AnnouncementApiController extends BaseApiController {
	@Autowired
	private AnnouncementService announcementService;
	private final static String ANNOUNCEMENT_LIST = "/announcementList";
	private final static String ANNOUNCEMENT_PUBLISH = "/announcementPublish";
	private final static String ANNOUNCEMENT_UPDATE = "/announcementUpdate";
	private final static String ANNOUNCEMENT_RELOAD_DATA = "/announcementReloadData";

	/**
	 * 获取在线公告列表
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/announcementList", method = RequestMethod.GET)
	public void getValiaAnnouncements(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(ANNOUNCEMENT_LIST, request, response);
		AnnouncementDataListReponseMessage message = new AnnouncementDataListReponseMessage();
		announcementService.loadAnnouncements();
		List<Announcement> list = announcementService.getValiaAnnouncements();
		message.setList(list);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 获取在线公告详情
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public void loadAnnouncementById(@PathVariable("id") int id, HttpServletRequest request,
			HttpServletResponse response) {
		Packet packet = new Packet(ANNOUNCEMENT_LIST, request, response);
		AnnouncementDataReponseMessage message = new AnnouncementDataReponseMessage();
		Announcement announcement = announcementService.loadAnnouncementById(id);
		if (null == announcement) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		message.setAnnouncement(announcement);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 修改在线公告
	 * 
	 * @param request
	 * @param response
	 * @throws ParseException
	 */
	@RequestMapping(value = "/{id}/announcementUpdate", method = RequestMethod.POST)
	public void announcementUpdate(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response)
			throws ParseException {
		Packet packet = new Packet(ANNOUNCEMENT_UPDATE, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		Announcement announcement = announcementService.loadAnnouncementById(id);
		if (announcement == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date broadcastEndTime = sdf.parse((String) json.get("broadcastEndTime"));
		Date broadcastStartTime = sdf.parse((String) json.get("broadcastStartTime"));
		Date startTime = sdf.parse((String) json.get("startTime"));
		Date endTime = sdf.parse((String) json.get("endTime"));
		announcement.setStartTime(startTime);
		announcement.setEndTime(endTime);
		announcement.setBroadcastEndTime(broadcastEndTime);
		announcement.setBroadcastStartTime(broadcastStartTime);
		announcement.setTitle((String) json.get("title"));
		announcement.setBackGroundId((String) json.get("backGroundId"));
		announcement.setContent((String) json.get("content"));
		announcement.setCategory((Integer) json.get("category"));
		announcement.setType((Integer) json.get("type"));
		announcement.setSequence((Integer) json.get("sequence"));
		announcementService.update(announcement);
		announcementService.loadAnnouncements();
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 公告上线
	 * 
	 * @param request
	 * @param response
	 * @throws ParseException
	 */
	@RequestMapping(value = "/announcementPublish", method = RequestMethod.POST)
	public void announcementPublish(HttpServletRequest request, HttpServletResponse response) throws ParseException {
		Packet packet = new Packet(ANNOUNCEMENT_PUBLISH, request, response);
		AnnouncementDataReponseMessage message = new AnnouncementDataReponseMessage();
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		Announcement announcement = new Announcement();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date broadcastEndTime = sdf.parse((String) json.get("broadcastEndTime"));
		Date broadcastStartTime = sdf.parse((String) json.get("broadcastStartTime"));
		Date startTime = sdf.parse((String) json.get("startTime"));
		Date endTime = sdf.parse((String) json.get("endTime"));
		announcement.setStartTime(startTime);
		announcement.setEndTime(endTime);
		announcement.setBroadcastEndTime(broadcastEndTime);
		announcement.setBroadcastStartTime(broadcastStartTime);
		announcement.setTitle((String) json.get("title"));
		announcement.setBackGroundId((String) json.get("backGroundId"));
		announcement.setContent((String) json.get("content"));
		announcement.setCategory((Integer) json.get("category"));
		announcement.setType((Integer) json.get("type"));
		announcement.setSequence((Integer) json.get("sequence"));
		announcementService.save(announcement);
		message.setAnnouncement(announcement);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}
	
	/**
	 * 删除在线公告
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/announcementDelete", method = RequestMethod.GET)
	public void announcementDelete(@PathVariable("id") int id,HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(ANNOUNCEMENT_PUBLISH, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		announcementService.loadAnnouncements();
		Announcement announcement = announcementService.loadAnnouncementById(id);
		if (announcement == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		announcementService.deleteAnnouncement(id);
		announcementService.loadAnnouncements();
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}
	
	/**
	 * 重新加载公告
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/reloadData", method = RequestMethod.GET)
	public void reloadData(HttpServletRequest request, HttpServletResponse response){
		Packet packet = new Packet(ANNOUNCEMENT_RELOAD_DATA, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		announcementService.loadAnnouncements();
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}
}
