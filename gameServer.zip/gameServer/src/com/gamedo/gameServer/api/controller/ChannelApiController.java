package com.gamedo.gameServer.api.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.api.message.ChannelDataReponseMessage;
import com.gamedo.gameServer.api.service.ChannelService;
import com.gamedo.gameServer.data.channel.Channel;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;

@Controller
@RequestMapping(value = "/api/channel")
public class ChannelApiController extends BaseApiController {
	private static final String CHANNEL_DETAIL = "CHANNEL_DETAIL";
	@Autowired
	private ChannelService channelService;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public void findById(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(CHANNEL_DETAIL, request, response);
		ChannelDataReponseMessage message = new ChannelDataReponseMessage();
		Channel channel = channelService.findById(Integer.toString(id));
		message.setChannel(channel);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}
}
