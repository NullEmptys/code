package com.gamedo.gameServer.api.message;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.gamedo.gameServer.message.CommonResponseMessage;

public class AchievementInfoDataReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = -5633561996643498382L;
	private Map<String, Object> achievementInfo = new HashMap();

	public Map<String, Object> getAchievementInfo() {
		return achievementInfo;
	}

	public void setAchievementInfo(Map<String, Object> achievementInfo) {
		this.achievementInfo = achievementInfo;
	}

}
