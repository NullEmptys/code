package com.gamedo.gameServer.api.message;

import java.io.Serializable;
import java.util.List;

import com.gamedo.gameServer.data.activity.loginReward.LoginReward;
import com.gamedo.gameServer.message.CommonResponseMessage;

public class LoginRewardListDataReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = -364980904413470618L;
	private List<LoginReward> loginRewardList;

	public List<LoginReward> getLoginRewardList() {
		return loginRewardList;
	}

	public void setLoginRewardList(List<LoginReward> loginRewardList) {
		this.loginRewardList = loginRewardList;
	}

}
