package com.gamedo.gameServer.api.message;

import java.io.Serializable;

import com.gamedo.gameServer.data.ServerInfoConfig;
import com.gamedo.gameServer.message.CommonResponseMessage;

public class ServerInfoConfigDataReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = -1921951204375306954L;
	private ServerInfoConfig serverInfoConfig;

	public ServerInfoConfig getServerInfoConfig() {
		return serverInfoConfig;
	}

	public void setServerInfoConfig(ServerInfoConfig serverInfoConfig) {
		this.serverInfoConfig = serverInfoConfig;
	}

}
