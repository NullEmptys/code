package com.gamedo.gameServer.api.message;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.gamedo.gameServer.message.CommonResponseMessage;

public class PlayerGirlsDataReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = 1688619474707403321L;

	private List<Map<String, Object>> playerGirlList;

	public List<Map<String, Object>> getPlayerGirlList() {
		return playerGirlList;
	}

	public void setPlayerGirlList(List<Map<String, Object>> playerGirlList) {
		this.playerGirlList = playerGirlList;
	}

}
