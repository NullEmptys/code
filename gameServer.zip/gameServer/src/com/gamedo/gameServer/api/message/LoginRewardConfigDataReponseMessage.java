package com.gamedo.gameServer.api.message;

import java.io.Serializable;

import com.gamedo.gameServer.data.activity.loginReward.LoginRewardConfig;
import com.gamedo.gameServer.message.CommonResponseMessage;

public class LoginRewardConfigDataReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = -3090961230164513053L;
	private LoginRewardConfig loginRewardConfig;

	public LoginRewardConfig getLoginRewardConfig() {
		return loginRewardConfig;
	}

	public void setLoginRewardConfig(LoginRewardConfig loginRewardConfig) {
		this.loginRewardConfig = loginRewardConfig;
	}

}
