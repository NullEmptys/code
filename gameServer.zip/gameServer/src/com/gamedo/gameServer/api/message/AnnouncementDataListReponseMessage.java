package com.gamedo.gameServer.api.message;

import java.io.Serializable;
import java.util.List;

import com.gamedo.gameServer.data.announcement.Announcement;
import com.gamedo.gameServer.message.CommonResponseMessage;

public class AnnouncementDataListReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = -8018399878105851540L;

	private List<Announcement> list;

	public List<Announcement> getList() {
		return list;
	}

	public void setList(List<Announcement> list) {
		this.list = list;
	}

}
