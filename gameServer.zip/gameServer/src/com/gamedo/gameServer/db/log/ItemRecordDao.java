package com.gamedo.gameServer.db.log;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.LogGenericHibernateDAO;
import com.gamedo.gameServer.entity.log.ItemRecord;

/**
 * 
 * @author libm
 *
 */
@Repository
public class ItemRecordDao extends LogGenericHibernateDAO<ItemRecord, Integer> {

}
