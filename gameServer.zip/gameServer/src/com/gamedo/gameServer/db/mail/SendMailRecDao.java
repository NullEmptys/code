package com.gamedo.gameServer.db.mail;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.mail.SendMailRec;
@Repository
public class SendMailRecDao extends PlayerGenericHibernateDAO<SendMailRec, Integer>{
	
	@SuppressWarnings("unchecked")
	public List<SendMailRec> getPlayerSendMailRec(int playerId) {
		String hql = "from SendMailRec s where s.playerId = ?0";
		List<SendMailRec> mails = list(hql, playerId);
		return mails;
	}

}
