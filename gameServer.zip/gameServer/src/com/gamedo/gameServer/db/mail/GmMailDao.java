package com.gamedo.gameServer.db.mail;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.mail.GmMail;
@Repository
public class GmMailDao extends PlayerGenericHibernateDAO<GmMail, Integer>{
	
	@SuppressWarnings("unchecked")
	public List<GmMail> getGmMails() {
		String hql = "from GmMail";
		List<GmMail> gmMailList = list(hql);
		return gmMailList;
	}
}
