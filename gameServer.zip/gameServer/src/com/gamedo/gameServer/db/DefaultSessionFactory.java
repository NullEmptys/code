package com.gamedo.gameServer.db;

import org.hibernate.SessionFactory;

public class DefaultSessionFactory {

	private static SessionFactory playerSessionFactory;
	
	private static SessionFactory dataSessionFactory;
	
	private static SessionFactory logSessionFactory;

	public static SessionFactory getPlayerSessionFactory() {
		return playerSessionFactory;
	}

	public void setPlayerSessionFactory(SessionFactory playerSessionFactory) {
		DefaultSessionFactory.playerSessionFactory = playerSessionFactory;
	}

	public static SessionFactory getDataSessionFactory() {
		return dataSessionFactory;
	}

	public void setDataSessionFactory(SessionFactory dataSessionFactory) {
		DefaultSessionFactory.dataSessionFactory = dataSessionFactory;
	}

	public static SessionFactory getLogSessionFactory() {
		return logSessionFactory;
	}

	public static void setLogSessionFactory(SessionFactory logSessionFactory) {
		DefaultSessionFactory.logSessionFactory = logSessionFactory;
	}
	
}
