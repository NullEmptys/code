package com.gamedo.gameServer.db.player;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.player.PlayerGirl;

/**
 * 
 * @author libm
 *
 */
@Repository
public class PlayerGirlDao extends PlayerGenericHibernateDAO<PlayerGirl, Integer> {

	@SuppressWarnings("unchecked")
	public List<PlayerGirl> loadPlayerGirls(int playerId) {
		String hql = "from PlayerGirl p where p.playerId = ?0";
		return list(hql, playerId);
	}

	public PlayerGirl loadPlayerGirlById(int playerId, int girlId) {
		String hql = "from PlayerGirl p where p.playerId = ?0 and girlId = ?1";
		return (PlayerGirl) uniqueResult(hql, playerId,girlId);
	}
}
