package com.gamedo.gameServer.db.player;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.BinaryType;
import org.hibernate.usertype.UserType;

import com.gamedo.gameServer.core.bag.GirlBags;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.util.ItemUtil;

/**
 * 
 * @author libm
 *
 */
public class PlayerGirlBagsUserType implements UserType{

	public static final int[] SQL_TYPES = { BinaryType.INSTANCE.sqlType()};
	
	@Override
	public Object assemble(Serializable cached, Object owner) throws HibernateException {
		return cached;
	}
	
	@Override
	public Object deepCopy(Object value) throws HibernateException {
		return ((GirlBags) value).clone();
	}
	
	@Override
	public Object nullSafeGet(ResultSet resultSet, String[] names, SessionImplementor arg2, Object owner)
			throws HibernateException, SQLException {
		byte[] bytes = resultSet.getBytes(names[0]);
		if (bytes == null) {
			return ((PlayerGirl) owner).initBags(((PlayerGirl) owner).defaultPlayer,0);
		} else {
			return ItemUtil.getBagsFromDB(bytes, ((PlayerGirl) owner).defaultPlayer);
		}
	}
	
	@Override
	public void nullSafeSet(PreparedStatement statement, Object value, int index, SessionImplementor arg3)
			throws HibernateException, SQLException {
		if (value == null)
			statement.setNull(index, SQL_TYPES[0]);
		else {
			statement.setBytes(index, ItemUtil.getBagsDBBytes((GirlBags) value));
		}
	}
	
	@Override
	public Class returnedClass() {
		return GirlBags.class;
	}
	
	@Override
	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return target;
	}

	@Override
	public Serializable disassemble(Object value) throws HibernateException {
		return (Serializable) value;
	}

	@Override
	public boolean equals(Object x, Object y) throws HibernateException {
		if (x == y)
			return true;
		if (x == null || y == null)
			return false;
		return x.equals(y);
	}

	public int hashCode(Object x) throws HibernateException {
		return x.hashCode();
	}

	@Override
	public boolean isMutable() {
		return true;
	}

	@Override
	public int[] sqlTypes() {
		return SQL_TYPES;
	}
}
