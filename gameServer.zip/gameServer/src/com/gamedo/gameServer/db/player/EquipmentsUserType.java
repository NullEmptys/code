package com.gamedo.gameServer.db.player;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.BinaryType;
import org.hibernate.usertype.UserType;

import com.gamedo.gameServer.constant.PlayType;
import com.gamedo.gameServer.core.item.Equipments;
import com.gamedo.gameServer.core.item.EquipmentsEx;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.util.ItemUtil;

/**
 * 
 * @author libm
 *
 */
public class EquipmentsUserType implements UserType{

	private static final int[] SQL_TYPES = { BinaryType.INSTANCE.sqlType() };
	
	@Override
	public Object assemble(Serializable cached, Object owner) throws HibernateException {
		return cached;
	}

	@Override
	public Object deepCopy(Object value) throws HibernateException {
		return (ConcurrentHashMap<Integer, Equipments>) value;
	}

	@Override
	public Serializable disassemble(Object value) throws HibernateException {
		return (Serializable) value;
	}

	public boolean equals(Object x, Object y) throws HibernateException {
		if (x == y)
			return true;
		if (x == null || y == null)
			return false;
		return x.equals(y);
	}

	public int hashCode(Object x) throws HibernateException {
		return x.hashCode();
	}

	@Override
	public boolean isMutable() {
		return true;
	}

	@Override
	public Object nullSafeGet(ResultSet resultSet, String[] names, SessionImplementor arg2, Object owner)
			throws HibernateException, SQLException {
		byte[] bytes = resultSet.getBytes(names[0]);
		if (bytes == null) {
			if (owner instanceof PlayerGirl) {
				ConcurrentHashMap<Integer, Equipments> equips = new ConcurrentHashMap<>();
				for(PlayType playType : PlayType.values()) {
					if(playType != null) {
						equips.put(playType.getType(), new EquipmentsEx((PlayerGirl) owner));
					}
				}
				return equips;
			}
		} else {
			if (owner instanceof PlayerGirl) {
				return ItemUtil.getEquipmentsFromDB(bytes, (PlayerGirl) owner);
			}
		}
		return null;
	}

	@Override
	public void nullSafeSet(PreparedStatement statement, Object value, int index, SessionImplementor arg3)
			throws HibernateException, SQLException {
		if (value == null)
			statement.setNull(index, SQL_TYPES[0]);
		else {
			statement.setBytes(index, ItemUtil.getEquipmentsDBBytes((ConcurrentHashMap<Integer,Equipments>) value));
		}
	}

	@Override
	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return target;
	}

	@Override
	public Class returnedClass() {
		return Equipments.class;
	}

	@Override
	public int[] sqlTypes() {
		return SQL_TYPES;
	}

}
