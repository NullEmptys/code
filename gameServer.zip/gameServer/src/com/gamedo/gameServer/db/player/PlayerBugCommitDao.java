package com.gamedo.gameServer.db.player;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.LogGenericHibernateDAO;
import com.gamedo.gameServer.entity.commitbug.CommitBug;

@Repository
public class PlayerBugCommitDao extends LogGenericHibernateDAO<CommitBug, Integer>{
	
}
