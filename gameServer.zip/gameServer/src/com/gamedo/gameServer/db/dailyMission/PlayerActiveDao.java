package com.gamedo.gameServer.db.dailyMission;

import java.util.Date;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.dailymission.PlayerActive;
/**
 * 玩家每日活跃度
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class PlayerActiveDao extends PlayerGenericHibernateDAO<PlayerActive, Integer>{
	
	public PlayerActive loadPlayerActiveRecord(int playerId) {
		
		String hql = "from PlayerActive t where t.playerId = ?0";
		return (PlayerActive) uniqueResult(hql, playerId);
	}
	
}
