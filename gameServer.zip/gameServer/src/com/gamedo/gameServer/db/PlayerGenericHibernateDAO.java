package com.gamedo.gameServer.db;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Example;

/**
 * @author libm
 *
 */

public class PlayerGenericHibernateDAO<T, ID extends Serializable> implements GenericDAO<T, ID> {

	private Class<T> persistentClass;

	@SuppressWarnings("unchecked")
	public PlayerGenericHibernateDAO() {
		this.persistentClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass())
				.getActualTypeArguments()[0];
	}

	public Session getSession() {

		return DefaultSessionFactory.getPlayerSessionFactory().getCurrentSession();
	}

	public T makePersistent(T entity) {
		Transaction tx = getSession().beginTransaction();
		try {
			getSession().saveOrUpdate(entity);
			tx.commit();
			return entity;
		} catch (Exception ex) {
			tx.rollback();
			throw new RuntimeException(ex);
		}
	}

	public void makeTransient(T entity) {
		Transaction tx = getSession().beginTransaction();
		try {
			getSession().delete(entity);
			tx.commit();
		} catch (Exception ex) {
			tx.rollback();
			throw new RuntimeException(ex);
		}
	}

	public void flush() {
		getSession().flush();
	}

	public void clear() {
		getSession().clear();
	}

	public T newEntity(T entity) {
		Transaction tx = getSession().beginTransaction();
		try {
			getSession().save(entity);
			tx.commit();
			return entity;
		} catch (Exception ex) {
			tx.rollback();
			throw new RuntimeException(ex);
		}
	}

	public T updateEntity(T entity) {
		Transaction tx = getSession().beginTransaction();
		try {
			getSession().update(entity);
			tx.commit();
			return entity;
		} catch (Exception ex) {
			tx.rollback();
			throw new RuntimeException(ex);
		}
	}

	public Object update(String hql, Object... values) {
		Transaction tx = getSession().beginTransaction();
		try {
			Query query = getSession().createQuery(hql);
			if (values != null) {
				for (int i = 0; i < values.length; i++) {
					query.setParameter(""+i, values[i]);
				}
			}
			Object ret = query.executeUpdate();
			tx.commit();
			return ret;
		} catch (Exception ex) {
			tx.rollback();
			throw new RuntimeException(ex);
		}
	}

	public Object uniqueResult(String hql, Object... values) {
		Transaction tx = getSession().beginTransaction();
		try {
			Query query = getSession().createQuery(hql);
			if (values != null) {
				for (int i = 0; i < values.length; i++) {
					query.setParameter(""+i, values[i]);
				}
			}
			Object ret = query.uniqueResult();
			tx.commit();
			return ret;
		} catch (Exception ex) {
			tx.rollback();
			throw new RuntimeException(ex);
		}
	}

	@SuppressWarnings("rawtypes")
	public List list(String hql, Object... values) {
		Transaction tx = getSession().beginTransaction();
		try {
			Query query = getSession().createQuery(hql);
			if (values != null) {
				for (int i = 0; i < values.length; i++) {
					query.setParameter(""+i, values[i]);
				}
			}
			List ret = query.list();
			tx.commit();
			return ret;
		} catch (Exception ex) {
			tx.rollback();
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}
	}

	@SuppressWarnings("rawtypes")
	public List limitList(String hql, int begin, int count, Object... values) {
		Transaction tx = getSession().beginTransaction();
		try {
			Query query = getSession().createQuery(hql);
			if (values != null) {
				for (int i = 0; i < values.length; i++) {
					query.setParameter(""+i, values[i]);
				}
			}
			query.setFirstResult(begin);
			query.setMaxResults(count);
			List ret = query.list();
			tx.commit();
			return ret;
		} catch (Exception ex) {
			tx.rollback();
			throw new RuntimeException(ex);
		}
	}

	public void delete(String hql, Object... values) {
		Transaction tx = getSession().beginTransaction();
		try {
			Query query = getSession().createQuery(hql);
			if (values != null) {
				for (int i = 0; i < values.length; i++) {
					query.setParameter(""+i, values[i]);
				}
			}
			query.executeUpdate();
			tx.commit();
		} catch (Exception ex) {
			tx.rollback();
			throw new RuntimeException(ex);
		}
	}

	public void bulkUpdate(String hql) {
		Transaction tx = getSession().beginTransaction();
		try {
			Query query = getSession().createQuery(hql);
			query.executeUpdate();
			tx.commit();
		} catch (Exception ex) {
			tx.rollback();
			throw new RuntimeException(ex);
		}
	}

	@Override
	public List<T> findAll() {
		return findByCriteria();
	}

	@SuppressWarnings("unchecked")
	protected List<T> findByCriteria(Criterion... criterion) {
		Transaction tx = getSession().beginTransaction();
		try {
			Criteria crit = getSession().createCriteria(getPersistentClass());
			for (Criterion c : criterion) {
				crit.add(c);
			}
			List<T> list = crit.list();
			tx.commit();
			return list;
		} catch (Exception e) {
			tx.rollback();
			throw new RuntimeException(e);
		}
		
	}

	public Class<T> getPersistentClass() {
		return persistentClass;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> findByExample(T exampleInstance, String... excludeProperty) {
		Transaction tx = getSession().beginTransaction();
		try {
			Criteria crit = getSession().createCriteria(getPersistentClass());
			Example example = Example.create(exampleInstance);
			for (String exclude : excludeProperty) {
				example.excludeProperty(exclude);
			}
			crit.add(example);
			List<T> list = crit.list();
			tx.commit();
			return list;
		} catch (Exception e) {
			tx.rollback();
			throw new RuntimeException(e);
		}
	}

}
