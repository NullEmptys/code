package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.quest.HeartBeat;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class HeartBeatDao extends DataGenericHibernateDAO<HeartBeat, Integer> {

	public List<HeartBeat> loadHeartBeatData() {
		return findAll();
	}
}
