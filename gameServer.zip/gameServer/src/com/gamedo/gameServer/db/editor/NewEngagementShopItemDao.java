package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.engagement.NewEngagementShopItem;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

@Repository
public class NewEngagementShopItemDao extends DataGenericHibernateDAO<NewEngagementShopItem, Integer>{
	public List<NewEngagementShopItem> loadNewEngagementShopItems() {
		return findAll();
	}
}
