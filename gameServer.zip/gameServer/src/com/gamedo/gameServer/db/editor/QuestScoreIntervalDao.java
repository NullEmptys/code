package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.quest.QuestScoreInterval;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class QuestScoreIntervalDao extends DataGenericHibernateDAO<QuestScoreInterval, Integer> {

	public List<QuestScoreInterval> loadQuestScoreIntervals() {
		return findAll();
	}
}
