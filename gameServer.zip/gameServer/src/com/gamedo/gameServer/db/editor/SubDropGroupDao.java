package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.core.fall.SubDropGroup;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class SubDropGroupDao extends DataGenericHibernateDAO<SubDropGroup, Integer> {

	@SuppressWarnings("unchecked")
	public List<SubDropGroup> loadSubDropGroupById(int dropGroupId){
		String hql = "from SubDropGroup s where s.dropGroupId = ?0";
		return list(hql, dropGroupId);
	}
}
