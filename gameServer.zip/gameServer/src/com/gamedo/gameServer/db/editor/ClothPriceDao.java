package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.equipment.ClothPrice;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class ClothPriceDao extends DataGenericHibernateDAO<ClothPrice, Integer> {

	public List<ClothPrice> loadClothPriceDatas() {
		return findAll();
	}
}
