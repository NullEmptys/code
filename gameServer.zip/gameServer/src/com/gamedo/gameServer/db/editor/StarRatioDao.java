package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.quest.StarRatio;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class StarRatioDao extends DataGenericHibernateDAO<StarRatio, Integer> {

	public List<StarRatio> loadStarRatios() {
		return findAll();
	}
}
