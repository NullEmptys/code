package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.quest.QuestRewardGroup;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class QuestRewardGroupDao extends DataGenericHibernateDAO<QuestRewardGroup, Integer> {
	
	public List<QuestRewardGroup> loadQuestRewardGroups() {
		return findAll();
	}
}
