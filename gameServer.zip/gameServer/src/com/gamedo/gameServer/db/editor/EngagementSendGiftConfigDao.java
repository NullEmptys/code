package com.gamedo.gameServer.db.editor;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.gamedo.gameServer.data.engagement.EngagementSendGiftWeightConfig;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;
/**
 * 送礼结束走向
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class EngagementSendGiftConfigDao extends DataGenericHibernateDAO<EngagementSendGiftWeightConfig, Integer>{
	
	public List<EngagementSendGiftWeightConfig> loadEngagementRouteData() {
		return findAll();
	}
}
