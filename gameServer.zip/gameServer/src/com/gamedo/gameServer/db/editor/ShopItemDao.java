package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.shop.ShopItem;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class ShopItemDao extends DataGenericHibernateDAO<ShopItem, Integer> {

	public List<ShopItem> loadShopItems() {
		return findAll();
	}
	
	@SuppressWarnings("unchecked")
	public List<ShopItem> loadShopItemsByShopId(int shopId) {
		String hql = "from ShopItem s where s.shopId = ?0";
		return list(hql, shopId);
	}
}
