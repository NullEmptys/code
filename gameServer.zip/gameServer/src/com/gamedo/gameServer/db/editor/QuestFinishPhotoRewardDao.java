package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.quest.QuestFinishPhotoReward;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

@Repository
public class QuestFinishPhotoRewardDao extends DataGenericHibernateDAO<QuestFinishPhotoReward, Integer>{
	public List<QuestFinishPhotoReward> loadTakePhotoReward() {
		return findAll();
	}
}
