package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.girl.InitGirlCloth;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class InitGirlClothDao extends DataGenericHibernateDAO<InitGirlCloth, Integer> {

	public List<InitGirlCloth> loadInitGirlCloths() {
		return findAll();
	}
}
