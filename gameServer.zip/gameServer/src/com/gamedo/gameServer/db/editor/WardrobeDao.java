package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.wardrobe.Wardrobe;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class WardrobeDao extends DataGenericHibernateDAO<Wardrobe, Integer> {

	/*
	 * 加载衣橱所有服装
	 */
	public List<Wardrobe> loadWardrobeItems() {
		return findAll();
	}
}
