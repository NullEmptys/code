package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.item.Item;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class ItemDao extends DataGenericHibernateDAO<Item,Integer> {

	public List<Item> loadItems() {
		return findAll();
	}
}
