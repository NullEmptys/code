package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.quest.QuestStyle;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class QuestStyleDao extends DataGenericHibernateDAO<QuestStyle, Integer> {

	public List<QuestStyle> loadQuestStyles() {
		return findAll();
	}
}
