package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.equipment.ClothCdTime;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class ClothCdTimeDao extends DataGenericHibernateDAO<ClothCdTime, Integer> {

	public List<ClothCdTime> loadClothCdTimeDatas() {
		return findAll();
	}
}
