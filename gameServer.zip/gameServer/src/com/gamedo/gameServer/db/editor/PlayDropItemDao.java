package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.quest.PlayDropItem;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class PlayDropItemDao extends DataGenericHibernateDAO<PlayDropItem, Integer> {

	@SuppressWarnings("unchecked")
	public List<PlayDropItem> loadPlayDropItems(int playDropType) {
		String hql = "from PlayDropItem t where t.playDropType = ?0";
		return list(hql, playDropType);
	}
}
