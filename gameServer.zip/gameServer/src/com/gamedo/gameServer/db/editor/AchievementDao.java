package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.achievement.Achievement;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class AchievementDao extends DataGenericHibernateDAO<Achievement, Integer> {

	public List<Achievement> loadAchievements(int category) {
		String hql = "from Achievement t where t.category = ?0 order by t.id asc";
		return list(hql, category);
	}
}
