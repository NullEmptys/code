package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.TiLiInfo;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 策划数据
 * @author libm
 *
 */
@Repository
public class TiLiInfoDao extends DataGenericHibernateDAO<TiLiInfo,Integer>{

	@SuppressWarnings("unchecked")
	public List<TiLiInfo> loadTiLiInfos() {
		String hql = "from TiLiInfo order by buyCount asc";
		return list(hql, null);
	}
}
