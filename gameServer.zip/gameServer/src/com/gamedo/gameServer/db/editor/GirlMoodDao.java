package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.girl.GirlMood;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class GirlMoodDao extends DataGenericHibernateDAO<GirlMood, Integer> {

	public List<GirlMood> loadGirlMoodData() {
		return findAll();
	}
}
