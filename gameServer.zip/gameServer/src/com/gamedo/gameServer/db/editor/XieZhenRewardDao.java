package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.quest.XieZhenReward;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class XieZhenRewardDao extends DataGenericHibernateDAO<XieZhenReward, Integer> {

	public List<XieZhenReward> loadXieZhenRewards() {
		return findAll();
	}
}
