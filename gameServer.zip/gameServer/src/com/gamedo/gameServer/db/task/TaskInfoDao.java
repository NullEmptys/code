package com.gamedo.gameServer.db.task;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.task.TaskInfo;

/**
 * 
 * @author libm
 *
 */
@Repository
public class TaskInfoDao extends PlayerGenericHibernateDAO<TaskInfo, Integer> {

	public TaskInfo select(String uid) {
		String hql = "from TimerTaskRecord t where t.uid = ?0";
		return (TaskInfo) uniqueResult(hql, uid);
	}
}
