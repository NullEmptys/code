package com.gamedo.gameServer.db.activityExch;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.activity.exchTicket.ActivityExchRecord;

@Repository
public class ExchActivityRecordDao extends PlayerGenericHibernateDAO<ActivityExchRecord, Integer>{
	@SuppressWarnings("unchecked")
	public ActivityExchRecord loadActivityExchRecord(int activityId){
		String hql = "from ActivityExchRecord t where t.activityId = ?0";
		return (ActivityExchRecord) uniqueResult(hql,activityId);
	}
	
}
