package com.gamedo.gameServer.db.activityExch;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.activity.activityExch.ActivityExchData;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 兑换活动票dao
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class ActivityExchDataDao extends DataGenericHibernateDAO<ActivityExchData, Integer>{
	@SuppressWarnings("unchecked")
	public List<ActivityExchData> loadActivityExchData() {
		String hql = "from ActivityExchData ";
		return list(hql);
	}
}
