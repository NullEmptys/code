package com.gamedo.gameServer.db.activityExch;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.activity.activityExch.ExchActivityConfig;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 线下活动见面会活动配置
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class ActivityExchConfigDao extends DataGenericHibernateDAO<ExchActivityConfig, Integer> {

	public ExchActivityConfig loadActivityExchConfig(int activityId) {
		String hql = "from ExchActivityConfig t where t.activityId = ?0";
		return (ExchActivityConfig) uniqueResult(hql, activityId);
	}
}
