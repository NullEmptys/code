package com.gamedo.gameServer.db.activityExch;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.activity.exchTicket.PlayerActivityExchRec;

@Repository
public class PlayerActivityExchRecDao extends PlayerGenericHibernateDAO<PlayerActivityExchRec, Integer>{
	
	public PlayerActivityExchRec loadPlayerActivityExchRecords(int playerId, int activityId,int ticketId) {
		String hql = "from PlayerActivityExchRec t where t.playerId = ?0 and activityId = ?1 and ticketId = ?2";
		return (PlayerActivityExchRec) uniqueResult(hql, playerId,activityId,ticketId);
	}
	
	@SuppressWarnings("unchecked")
	public List<PlayerActivityExchRec> getPlayerActivityExchRec(int playerId,int activityId){
		String hql = "from PlayerActivityExchRec t where t.playerId = ?0 and activityId < ?1";
		return list(hql,playerId,activityId);
	}
}
