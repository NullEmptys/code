package com.gamedo.gameServer.db.activity.loginReward;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.activity.loginReward.LoginRewardRecord;

/**
 * 
 * @author libm
 *
 */
@Repository
public class LoginRewardRecordDao extends PlayerGenericHibernateDAO<LoginRewardRecord, Integer> {

	public List<LoginRewardRecord> loadPlayerLoginRewardRecords(int playerId, int activityId) {
		String hql = "from LoginRewardRecord t where t.playerId = ?0 and activityId = ?1";
		return list(hql, playerId,activityId);
	}

}
