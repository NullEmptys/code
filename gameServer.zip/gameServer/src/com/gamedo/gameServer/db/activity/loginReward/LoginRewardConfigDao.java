package com.gamedo.gameServer.db.activity.loginReward;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.activity.loginReward.LoginRewardConfig;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class LoginRewardConfigDao extends DataGenericHibernateDAO<LoginRewardConfig, Integer> {

	public LoginRewardConfig findLoginRewardConfig(int activityId) {
		String hql = "from LoginRewardConfig t where t.activityId = ?0";
		return (LoginRewardConfig) uniqueResult(hql, activityId);
	}
}
