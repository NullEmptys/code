package com.gamedo.gameServer.db.activity.loginReward;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.activity.loginReward.LoginRewardArea;

/**
 * 
 * @author libm
 *
 */
@Repository
public class LoginRewardAreaDao extends PlayerGenericHibernateDAO<LoginRewardArea, Integer> {

	public List<LoginRewardArea> loadPlayerLoginRewardAreas(int playerId,int activityId){
		String hql = "from LoginRewardArea t where t.playerId = ?0 and t.activityId = ?1";
		return list(hql, playerId,activityId);
	}
}
