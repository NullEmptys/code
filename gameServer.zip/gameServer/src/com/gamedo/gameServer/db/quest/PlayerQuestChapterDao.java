package com.gamedo.gameServer.db.quest;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.quest.PlayerQuestChapter;

/**
 * 
 * @author libm
 *
 */
@Repository
public class PlayerQuestChapterDao extends PlayerGenericHibernateDAO<PlayerQuestChapter, Integer>{
	
	/**
	 * 从数据库中加载玩家任务章节记录
	 * @param playerId
	 * @return
	 */
	public List<PlayerQuestChapter> loadPlayerQuestChapters(int playerId) {
		String hql = "from PlayerQuestChapter p where p.playerId = ?0";
		return list(hql, playerId);
	}
}
