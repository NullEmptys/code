package com.gamedo.gameServer.db.quest;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.quest.PlayerQuest;

/**
 * 
 * @author libm
 *
 */
@Repository
public class PlayerQuestDao extends PlayerGenericHibernateDAO<PlayerQuest, Integer>{

	/**
	 * 加载玩家所有关卡数据
	 * @param playerId
	 * @return
	 */
	public List<PlayerQuest> loadPlayerQuests(int playerId) {
		String hql = "from PlayerQuest p where p.playerId = ?0";
		return list(hql, playerId);
	}
	
	public void deletePlayerQuest(int playerId,int category) {
		String hql = "delete from PlayerQuest t where t.playerId = ?0 and t.category = ?1";
		delete(hql, playerId,category);
	}

	public void deletePlayerQuest(int playerId, PlayerQuest playerQuest) {
		String hql = "delete from PlayerQuest t where t.id = ?0";
		delete(hql, playerQuest.getId());
	}
	
}
