package com.gamedo.gameServer.db.quest;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.quest.QuestFinishedCondition;

/**
 * QuestFinishedCondition
 * @author libm
 *
 */
@Repository
public class QuestFinishedConditionDao extends PlayerGenericHibernateDAO<QuestFinishedCondition, Integer> {

	@SuppressWarnings("unchecked")
	public List<QuestFinishedCondition> loadPlayerQuestFinishedCondition(int playerId,int day) {
		String hql = "from QuestFinishedCondition t where t.playerId = ?0 and t.day = ?1";
		return list(hql, playerId,day);
	}
	
	public QuestFinishedCondition findPlayerQuestFinishedCondition(int playerId,int questId,int day) {
		String hql = "from QuestFinishedCondition t where t.playerId = ?0 and t.questId = ?1 and t.day = ?2";
		return (QuestFinishedCondition) uniqueResult(hql, playerId,questId,day);
	}

}
