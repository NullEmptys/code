package com.gamedo.gameServer.db.engagement;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.engagement.EngagementScene;

/**
 * 
 * @author libm
 *
 */
@Repository
public class EngagementSceneDao extends PlayerGenericHibernateDAO<EngagementScene, Integer> {

	public EngagementScene loadLastEngagementScene() {
		String hql = "from EngagementScene t where t.id = (select max(id) from EngagementScene)";
		return (EngagementScene) uniqueResult(hql, null);
	}
}
