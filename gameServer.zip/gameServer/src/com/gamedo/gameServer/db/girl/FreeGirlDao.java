package com.gamedo.gameServer.db.girl;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.girl.FreeGirlRecord;

/**
 * 
 * @author libm
 *
 */
@Repository
public class FreeGirlDao extends PlayerGenericHibernateDAO<FreeGirlRecord, Integer> {

	public FreeGirlRecord getLastFreeGirlRecord() {
		String hql = "from FreeGirlRecord t where t.id = (select max(id) from FreeGirlRecord)";
		return (FreeGirlRecord) uniqueResult(hql, null);
	}
}
