package com.gamedo.gameServer.db.girl;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.girl.SingleGirlHistoryUseRecord;

/**
 * 
 * @author libm
 *
 */
@Repository
public class SingleGirlHistoryUseRecordDao extends PlayerGenericHibernateDAO<SingleGirlHistoryUseRecord, Integer> {

	/**
	 * 
	 * @param playerId
	 * @param girlId
	 * @return
	 */
	public SingleGirlHistoryUseRecord loadSingleGirlHistoryUseRecordRank(int playerId, int girlId) {
		String hql = "from SingleGirlHistoryUseRecord t where t.playerId = ?0 and t.girlId = ?1";
		return (SingleGirlHistoryUseRecord) uniqueResult(hql, playerId, girlId);
	}

	/**
	 * 
	 * @param playerId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<SingleGirlHistoryUseRecord> loadPlayerSingleGirlHistoryUseRecord(int playerId) {
		String hql = "from SingleGirlHistoryUseRecord t where t.playerId = ?0";
		return list(hql, playerId);
	}

}
