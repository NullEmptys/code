package com.gamedo.gameServer.controller.charge;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.charge.AppStoreCharge;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.charge.ChargeAddDiamonRequestMessage;
import com.gamedo.gameServer.service.charge.ChargeService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;
import com.gamedo.gameServer.util.DateUtil;

@Controller
@RequestMapping(value = OpCode.CHARGE_ADD_DIAMON)
public class PlayerCharge extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private ChargeService chargeService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.CHARGE_ADD_DIAMON, request, response);
		ChargeAddDiamonRequestMessage requestMessage = (ChargeAddDiamonRequestMessage) packet
				.getRequestMessage(ChargeAddDiamonRequestMessage.class);
		CommonResponseMessage message = new CommonResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		int goodsId = Integer.parseInt(requestMessage.getGoodsId());
		Map<Integer, AppStoreCharge> chargeMap = chargeService.getChargeConfigInfo();
		AppStoreCharge appStoreCharge = chargeMap.get(goodsId);
		if (appStoreCharge == null) {
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		String chargeRecord = player.getPool().getString(Const.CHARGE_RECORD);
		if (chargeRecord == null || chargeRecord.equals("")) {
			PlayerTransaction tx = player.newTransaction("充值获得");
			player.addMoney(appStoreCharge.getDiamondNum() * 2, tx, false);
			// player.addAttributeByType(AttributeType.getAttrtType(AttributeType.GOLD.getAttributeType()),
			// appStoreCharge.getDiamondNum() * 2, tx);
			tx.commit();
			chargeRecord = appStoreCharge.getId() + "";
		} else {
			List<Integer> list = DateUtil.StringToList(chargeRecord);
			if (list.contains(appStoreCharge.getId())) {
				PlayerTransaction tx = player.newTransaction("充值获得");
				player.addMoney(appStoreCharge.getDiamondNum() + appStoreCharge.getBonus(), tx, false);
				// player.addAttributeByType(AttributeType.getAttrtType(AttributeType.GOLD.getAttributeType()),
				// appStoreCharge.getDiamondNum() + appStoreCharge.getBonus(),
				// tx);
				tx.commit();
			} else {
				PlayerTransaction tx = player.newTransaction("充值获得");
				player.addMoney(appStoreCharge.getDiamondNum() * 2, tx, false);
				// player.addAttributeByType(AttributeType.getAttrtType(AttributeType.GOLD.getAttributeType()),
				// appStoreCharge.getDiamondNum() * 2, tx);
				tx.commit();
				chargeRecord = chargeRecord + "," + appStoreCharge.getId();
			}
		}
		player.getPool().setString(Const.CHARGE_RECORD, chargeRecord);
//		playerService.sendAndClean(player.getId());
		playerService.updatePlayer(player);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}
}
