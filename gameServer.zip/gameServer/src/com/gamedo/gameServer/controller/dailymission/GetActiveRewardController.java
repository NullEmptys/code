package com.gamedo.gameServer.controller.dailymission;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.fall.GroupDropService;
import com.gamedo.gameServer.core.gain.CurrencyGainEntry;
import com.gamedo.gameServer.core.gain.Gain;
import com.gamedo.gameServer.core.gain.GainEntry;
import com.gamedo.gameServer.core.gain.GameItemGainEntry;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.dailyMission.DailyMissionActiveReward;
import com.gamedo.gameServer.data.dailyMission.DailyMissionDefine;
import com.gamedo.gameServer.entity.dailymission.PlayerActive;
import com.gamedo.gameServer.entity.dailymission.PlayerDailyMission;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.dailyMission.DailyMissionGetRewardRequestMessage;
import com.gamedo.gameServer.message.dailyMission.DailyMissionRewardItem;
import com.gamedo.gameServer.message.dailyMission.GetRewardResponseMessage;
import com.gamedo.gameServer.service.dailymission.DailyMissionService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.DateUtil;

@Controller
@RequestMapping(value = OpCode.GET_DAILY_MISSION_REWARD)
public class GetActiveRewardController extends AbstractController{

	@Autowired
	private PlayerService playerService;
	@Autowired
	private DailyMissionService dailyMissionService;
	@Autowired
	private GroupDropService groupDropService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.GET_DAILY_MISSION_REWARD,request,response);
		DailyMissionGetRewardRequestMessage requestMessage = (DailyMissionGetRewardRequestMessage) packet.getRequestMessage(DailyMissionGetRewardRequestMessage.class);
		GetRewardResponseMessage responseMessage = new GetRewardResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		int rewardType = requestMessage.getRewardType();
		if (player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		switch(rewardType){
			case PlayerActive.DAILY_REWARD:{
				Map<Integer,DailyMissionActiveReward> dailyActiveMap = dailyMissionService.getDailyActiveMap(PlayerActive.DAILY_REWARD);
				if(dailyActiveMap != null && dailyActiveMap.size() >0 ){
					if(!dailyActiveMap.keySet().contains(requestMessage.getActiveValue())){
						responseMessage.setCode(CommonResponseMessage.FALSE);
						responseMessage.setDesc(I18NMessage.REWARD_TYPE_NOT_FOUNT);
						packet.send(responseMessage);
						return;
					}
				}
				PlayerActive playerActive = dailyMissionService.getPlayerDailyMissionActiveRec(player.getId());
				List<Integer> dailyActiveRewarList = DateUtil.StringToList(playerActive.getDailyRewards());
				if(dailyActiveRewarList != null && dailyActiveRewarList.size() > 0){
					if(dailyActiveRewarList.contains(requestMessage.getActiveValue())){
						responseMessage.setCode(CommonResponseMessage.FALSE);
						responseMessage.setDesc(I18NMessage.GET_REWARD);
						packet.send(responseMessage);
						return;
					}
				}
				if(playerActive.getDailyActiveValue() < requestMessage.getActiveValue()){
					responseMessage.setCode(CommonResponseMessage.FALSE);
					responseMessage.setDesc(I18NMessage.ACTIVE_NOT_HAVE);
					packet.send(responseMessage);
					return;
				}
				DailyMissionActiveReward dailyActiveData = dailyActiveMap.get(requestMessage.getActiveValue());
				//获得奖励
				List<DailyMissionRewardItem> rewardList = getDailyMissionReward(player,dailyActiveData.getRewardIds(),dailyActiveData.getRewardNums(),dailyActiveData.getDropId(),"日活跃度奖励");
				dailyMissionService.updateDailyActiveReward(player,playerActive,requestMessage.getActiveValue());
				responseMessage.setDailyActive(playerActive.getDailyActiveValue());
				responseMessage.setWeekActive(playerActive.getWeekActiveValue());
				responseMessage.setCode(CommonResponseMessage.TRUE);
				responseMessage.setRewardItem(rewardList);
				responseMessage.setRewardType(requestMessage.getRewardType());
				responseMessage.setClentData(dailyActiveData.getId());
				responseMessage.setUpdateObj(playerService.sendAndClean(player.getId()));
				playerService.updatePlayer(player);
				packet.send(responseMessage);
				break;
			}
			case PlayerActive.WEEK_REWARD:{
				Map<Integer,DailyMissionActiveReward> dailyActiveMap = dailyMissionService.getDailyActiveMap(PlayerActive.WEEK_REWARD);
				if(dailyActiveMap != null && dailyActiveMap.size() >0 ){
					if(!dailyActiveMap.keySet().contains(requestMessage.getActiveValue())){
						responseMessage.setCode(CommonResponseMessage.FALSE);
						responseMessage.setDesc(I18NMessage.REWARD_TYPE_NOT_FOUNT);
						packet.send(responseMessage);
						return;
					}
				}
				PlayerActive playerActive = dailyMissionService.getPlayerDailyMissionActiveRec(player.getId());
				List<Integer> dailyActiveRewarList = DateUtil.StringToList(playerActive.getWeekRewards());
				if(dailyActiveRewarList != null && dailyActiveRewarList.size() >0){
					if(dailyActiveRewarList.contains(requestMessage.getActiveValue())){
						responseMessage.setCode(CommonResponseMessage.FALSE);
						responseMessage.setDesc(I18NMessage.GET_REWARD);
						packet.send(responseMessage); 
						return;
					}
				}
				if(playerActive.getWeekActiveValue() < requestMessage.getActiveValue()){
					responseMessage.setCode(CommonResponseMessage.FALSE);
					responseMessage.setDesc(I18NMessage.ACTIVE_NOT_HAVE);
					packet.send(responseMessage);
					return;
				}
				DailyMissionActiveReward weekActiveData = dailyActiveMap.get(requestMessage.getActiveValue());
				List<DailyMissionRewardItem> rewardList = getDailyMissionReward(player, weekActiveData.getRewardIds(),weekActiveData.getRewardNums(),weekActiveData.getDropId(),"周活跃度奖励");
				dailyMissionService.updateWeedActiveReward(player,playerActive,requestMessage.getActiveValue());
				responseMessage.setDailyActive(playerActive.getDailyActiveValue());
				responseMessage.setWeekActive(playerActive.getWeekActiveValue());
				responseMessage.setCode(CommonResponseMessage.TRUE);
				responseMessage.setRewardItem(rewardList);
				responseMessage.setRewardType(requestMessage.getRewardType());
				responseMessage.setClentData(weekActiveData.getId());
				responseMessage.setUpdateObj(playerService.sendAndClean(player.getId()));
				playerService.updatePlayer(player);
				packet.send(responseMessage);
				break;
			}
			case PlayerActive.MISSION_REWARD:{
				int missionId = requestMessage.getMissionId();
				PlayerActive playerActive1 = dailyMissionService.getPlayerDailyMissionActiveRec(player.getId());
				//当前日活可领取的宝箱
				int currentDailyBox = dailyMissionService.getCurrent(playerActive1,PlayerActive.DAILY_REWARD);
				//当前周活宝箱可领取的宝箱
				int currentWeekBox = dailyMissionService.getCurrent(playerActive1,PlayerActive.WEEK_REWARD);
				PlayerDailyMission playerDailyMission = dailyMissionService.getPlayerDailyMission(player.getId(),missionId);
				DailyMissionDefine dailyMission = dailyMissionService.getDailyMissionByDefineId(missionId);
				if(playerDailyMission == null || dailyMission == null){
					responseMessage.setCode(CommonResponseMessage.FALSE);
					responseMessage.setDesc(I18NMessage.DAILY_MISSION_NOT_FOUND);
					packet.send(responseMessage);
					return;
				}
				if(playerDailyMission.getStatus() == PlayerDailyMission.STATUS_STARTED || playerDailyMission.getMissionDetail() < Integer.parseInt(dailyMission.getMissionPrams())){
					responseMessage.setCode(CommonResponseMessage.FALSE);
					responseMessage.setDesc(I18NMessage.DAILY_MISSION_NOT_GET);
					packet.send(responseMessage);
					return;
				}
				if(playerDailyMission.getStatus() == PlayerDailyMission.STATUS_END){
					responseMessage.setCode(CommonResponseMessage.FALSE);
					responseMessage.setDesc(I18NMessage.DAILY_MISSION_GETED);
					packet.send(responseMessage);
					return;
				}
				dailyMissionService.updateDailyMissionReward(player,missionId);
				dailyMissionService.updatePlayerActive(player.getId(), dailyMission.getActiveValue());
				getDailyMissionReward(player,dailyMission.getRewardIds(),dailyMission.getRewardNums(),0,"每日任务奖励");
				PlayerActive playerActive = dailyMissionService.getPlayerDailyMissionActiveRec(player.getId());
				//当前日活可领取的宝箱
				int currentDailyBoxEnd = dailyMissionService.getCurrent(playerActive1,PlayerActive.DAILY_REWARD);
				//当前周活宝箱可领取的宝箱
				int currentWeekBoxEnd = dailyMissionService.getCurrent(playerActive1,PlayerActive.WEEK_REWARD);
				List<Integer> openBoxIds = new ArrayList<>();
				if(currentDailyBox < currentDailyBoxEnd){
					openBoxIds.add(dailyMissionService.getDailyActiveMap(PlayerActive.DAILY_REWARD).get(currentDailyBoxEnd).getId());
				}
				if(currentWeekBox < currentWeekBoxEnd){
					openBoxIds.add(dailyMissionService.getDailyActiveMap(PlayerActive.WEEK_REWARD).get(currentWeekBoxEnd).getId());
				}
				responseMessage.setOpenBoxIds(openBoxIds);
				responseMessage.setDailyActive(playerActive.getDailyActiveValue());
				responseMessage.setWeekActive(playerActive.getWeekActiveValue());
				responseMessage.setCode(CommonResponseMessage.TRUE);
				responseMessage.setRewardType(requestMessage.getRewardType());
				responseMessage.setClentData(requestMessage.getMissionId());
				responseMessage.setDesc(I18NMessage.FINISH_REWARD);
				responseMessage.setUpdateObj(playerService.sendAndClean(player.getId()));
				playerService.updatePlayer(player);
				packet.send(responseMessage);
				break;
			}
		default:
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.REWARD_TYPE_NOT_FOUNT);
			packet.send(responseMessage);
			return;
		}
	}
	
	private List<DailyMissionRewardItem> getDailyMissionReward(Player player,String idStr,String numStr,int dropId,String rewardDesc){
		List<Integer> ids = DateUtil.StringToList(idStr);
		List<Integer> nums = DateUtil.StringToList(numStr);
		for(int i=0;i<ids.size();i++){
			int itemType = ids.get(i);
			if(itemType == AttributeType.GOLD.getAttributeType() || itemType == AttributeType.MONEY.getAttributeType()){
				PlayerTransaction tx = player.newTransaction(rewardDesc);
				player.addAttributeByType(AttributeType.getAttrtType(itemType), nums.get(i), tx);
				tx.commit();
			}else{
				player.getBags().addItem(ids.get(i), nums.get(i), "dailyMissionActiveReward",-1);
			}
		}
		if(dropId != 0){
			List<DailyMissionRewardItem> itemList = new ArrayList<>();
			Gain gain = groupDropService.groupDrop(player, dropId, "dailyMission");
			if(gain != null){
				List<GainEntry> gainEntryList = gain.getGainEntrys();
				for (GainEntry gainEntry : gainEntryList) {
					if (gainEntry != null) {
						if (gainEntry instanceof GameItemGainEntry) {
							DailyMissionRewardItem dailyMissionRewardItem = new DailyMissionRewardItem();
							GameItemGainEntry itenEntry = (GameItemGainEntry) gainEntry;
							dailyMissionRewardItem.setItemId(itenEntry.getItem().getTemplate().getId());
							dailyMissionRewardItem.setItemNum(itenEntry.getCount());
							dailyMissionRewardItem.setItemType(2);//客户端需要类型
							itemList.add(dailyMissionRewardItem);
						}else if(gainEntry instanceof CurrencyGainEntry){
							DailyMissionRewardItem dailyMissionRewardItem = new DailyMissionRewardItem();
							CurrencyGainEntry itenEntry = (CurrencyGainEntry) gainEntry;
							dailyMissionRewardItem.setItemId(itenEntry.getCurrencyType());
							dailyMissionRewardItem.setItemNum(itenEntry.getCounts());
							dailyMissionRewardItem.setItemType(1);//客户端需要数据
							itemList.add(dailyMissionRewardItem);
						}
					}
				}
				return itemList;
			}
		}
		return null;
	}
}
