package com.gamedo.gameServer.controller.dailymission;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.dailyMission.PhotographRequestMessage;
import com.gamedo.gameServer.service.player.PlayerService;

@Controller
@RequestMapping(value = OpCode.PHOTOGRAPH_INFO)
public class PhotographInfoController extends AbstractController{
	
	@Autowired
	private PlayerService playerService;
	@Autowired
	private EventManager eventManager;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.PHOTOGRAPH_INFO,request,response);
		PhotographRequestMessage requestMessage = (PhotographRequestMessage) packet.getRequestMessage(PhotographRequestMessage.class);
		CommonResponseMessage message = new CommonResponseMessage();
		Player player = playerService.getPlayerById(requestMessage.getPlayerID());
		if(player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		if(requestMessage.getPhotographNum() > 0){
			eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_TAKE_PHOTO,player,requestMessage.getPhotographNum()));
		}
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

}
