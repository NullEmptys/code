package com.gamedo.gameServer.controller.activity.exchTicket;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.activity.Activity;
import com.gamedo.gameServer.activity.ActivityService;
import com.gamedo.gameServer.activity.exchangeTicket.ExchangeActivity;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.activity.activityExch.ActivityExchData;
import com.gamedo.gameServer.entity.activity.exchTicket.ActivityExchRecord;
import com.gamedo.gameServer.entity.activity.exchTicket.PlayerActivityExchRec;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.activity.exchTick.ExchActivityRequestMessage;
import com.gamedo.gameServer.message.activity.exchTick.ExchActivityResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.DateUtil;

/**
 * 兑换线下活动卷
 * 
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = OpCode.ACTIVITY_EXCHANGE)
public class ExchangeTicketController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private ActivityService activityService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.ACTIVITY_EXCHANGE, request, response);

		ExchActivityRequestMessage requestMessage = (ExchActivityRequestMessage) packet
				.getRequestMessage(ExchActivityRequestMessage.class);

		ExchActivityResponseMessage message = new ExchActivityResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		Activity activity = activityService.getActivity(requestMessage.getActivityId());
		if (!activity.isActive()) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.ACTIVITY_NOT_ACTIVE);
			packet.send(message);
			return;
		}
		ExchangeActivity exchangeActivity = (ExchangeActivity) activity.getImpl();
		Map<String, Integer> config = exchangeActivity.getCurrentActivityConfig();// 兑换id和数量限制配置
		Map<Integer, ActivityExchData> activityExchDataMap = exchangeActivity.getActivityExchConfig();// 兑换列表
		if (activityExchDataMap == null || config == null || activityExchDataMap.isEmpty() || config.isEmpty()) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		ActivityExchData exchData = activityExchDataMap.get(requestMessage.getTicketId());
		if(exchData == null){
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		PlayerActivityExchRec playerActRec = exchangeActivity.getPlayerExchActivityRec(player.getId(),
				requestMessage.getTicketId());
		if (exchData.getType().equals("A")) {
			if(playerActRec != null){
				if (config.get(requestMessage.getTicketId() + "") - Integer.parseInt(playerActRec.getTicketNum()) == 0) {
					message.setCode(CommonResponseMessage.FALSE);
					message.setDesc(I18NMessage.COUNT_NOT_ENOUGH);
					packet.send(message);
					return;
				}
				if (requestMessage.getExchNum() > config.get(requestMessage.getTicketId() + "")
						- Integer.parseInt(playerActRec.getTicketNum())) {
					message.setCode(CommonResponseMessage.FALSE);
					message.setDesc(I18NMessage.NUM_MAX);
					packet.send(message);
					return;
				}
			}
			
			PlayerTransaction tx = player.newTransaction("buyActivityTicket");
			try {
				player.decMoney(exchData.getConsumeNum() * requestMessage.getExchNum(), tx, true);
			} catch (NoEnoughValueException e) {
				e.printStackTrace();
				tx.rollback();
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.NO_ENOUGH_MONEY);
				packet.send(message);
				return;
			}
			player.addActivityCoin(requestMessage.getExchNum(), tx, true);
			tx.commit();
			exchangeActivity.updatePlayerActivityCurrencyRec(player.getId(), requestMessage.getTicketId(),
					requestMessage.getExchNum(), exchData.getType(), 0);
			message.setCode(CommonResponseMessage.TRUE);
			message.setDesc(I18NMessage.EXCH_SUCCESS);
			packet.send(message);
		} else {
			if(requestMessage.getExchNum() > 1){
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.EXCH_COUNT_LIMIT);
				packet.send(message);
				return;
			}
			String ticketNum = null;
			synchronized(this){
				ActivityExchRecord exchRec = exchangeActivity.getActivityExchList();// 活动兑换记录
				int count = 0;// 已经兑换次数
				List<Integer> ticketIdsList = new ArrayList<>();
				List<Integer> ticketNumsList = new ArrayList<>();
				if (exchRec != null) {
					ticketIdsList = DateUtil.StringToList(exchRec.getTicketId());
					ticketNumsList = DateUtil.StringToList(exchRec.getTicketNum());
				}
				if(ticketIdsList != null && ticketNumsList != null){
					for (int i = 0; i < ticketIdsList.size(); i++) {
						if (ticketIdsList.get(i) == requestMessage.getTicketId()) {
							count = ticketNumsList.get(i);
						}
					}
				}
				if (config.get(requestMessage.getTicketId() + "") - count == 0) {
					message.setCode(CommonResponseMessage.FALSE);
					message.setDesc(I18NMessage.TICKET_IS_OVER);
					packet.send(message);
					return;
				}
				if (playerActRec != null) {
					message.setCode(CommonResponseMessage.FALSE);
					message.setDesc(I18NMessage.HAS_TICKET);
					packet.send(message);
					return;
				}
				PlayerTransaction tx = player.newTransaction("buyTicket");
				try {
					player.decActivityCoin(exchData.getConsumeNum(), tx, true);
				} catch (NoEnoughValueException e) {
					e.printStackTrace();
					tx.rollback();
					message.setCode(CommonResponseMessage.FALSE);
					message.setDesc(I18NMessage.ACTIVITY_TICKET_NOT_ENOUGH);
					packet.send(message);
					return;
				}
				tx.commit();
				exchangeActivity.updateActivityExchTicketRec(requestMessage.getTicketId(),requestMessage.getExchNum());
				ticketNum = exchangeActivity.updatePlayerActivityCurrencyRec(player.getId(), requestMessage.getTicketId(),
						requestMessage.getExchNum(), exchData.getType(), count);
			}
			message.setTicketNum(ticketNum);
			message.setCode(CommonResponseMessage.TRUE);
			message.setDesc(I18NMessage.EXCH_SUCCESS);
			packet.send(message);
			return;
		}
	}
}
