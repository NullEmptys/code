package com.gamedo.gameServer.controller.activity.exchTicket;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.activity.Activity;
import com.gamedo.gameServer.activity.ActivityService;
import com.gamedo.gameServer.activity.exchangeTicket.ExchangeActivity;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.activity.activityExch.ActivityExchData;
import com.gamedo.gameServer.entity.activity.exchTicket.ActivityExchRecord;
import com.gamedo.gameServer.entity.activity.exchTicket.PlayerActivityExchRec;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.activity.exchTick.ExchActivityData;
import com.gamedo.gameServer.message.activity.exchTick.ExchActivityPageRequestMessage;
import com.gamedo.gameServer.message.activity.exchTick.ExchActivityPageResponseMessage;
import com.gamedo.gameServer.message.activity.exchTick.TicketData;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.DateUtil;

/**
 * 线下活动兑换界面
 * 
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = OpCode.ACTIVITY_OFFLINE_MEET)
public class ExchTicketPageController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private ActivityService activityService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		Packet packet = new Packet(OpCode.ACTIVITY_OFFLINE_MEET, request, response);

		ExchActivityPageRequestMessage requestMessage = (ExchActivityPageRequestMessage) packet
				.getRequestMessage(ExchActivityPageRequestMessage.class);

		ExchActivityPageResponseMessage message = new ExchActivityPageResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		Activity activity = activityService.getActivity(requestMessage.getActivityId());
		if (!activity.isActive()) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.ACTIVITY_NOT_ACTIVE);
			packet.send(message);
			return;
		}

		ExchangeActivity exchangeActivity = (ExchangeActivity) activity.getImpl();
		message.setActivityTitle(activity.getTitle());
		Map<Integer, ActivityExchData> activityExchMap = exchangeActivity.getActivityExchConfig();
		Map<String, Integer> itemMap = exchangeActivity.getCurrentActivityConfig();
		List<ExchActivityData> exchActData = getClientPageDate(player, activityExchMap, itemMap, exchangeActivity);
		message.setExchPageData(exchActData);
		List<PlayerActivityExchRec> historyTicket = exchangeActivity.getPlayerHistoryTicket(player.getId());
		List<TicketData> historyTicketList = new ArrayList<TicketData>();
		if(historyTicket != null){
			for(PlayerActivityExchRec plActRec : historyTicket){
				TicketData td = new TicketData();
				td.setTicketId(plActRec.getTicketId());
				td.setTicketNum(plActRec.getTicketNum());
				historyTicketList.add(td);
			}
		}
		message.setHistoryTicket(historyTicketList);
		List<PlayerActivityExchRec> currentTicket = exchangeActivity.getCurrentTicket(player.getId());
		List<TicketData> currentTicketList = new ArrayList<TicketData>();
		if(currentTicket != null){
			for(PlayerActivityExchRec playerRec : currentTicket){
				TicketData ticketData = new TicketData();
				ticketData.setTicketId(playerRec.getTicketId());
				ticketData.setTicketNum(playerRec.getTicketNum());
				currentTicketList.add(ticketData);
			}
		}
		message.setCanUseTicket(currentTicketList);
		message.setActivityCurrency(player.getActivityCoin());
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	private List<ExchActivityData> getClientPageDate(Player player, Map<Integer, ActivityExchData> activityExchMap,
			Map<String, Integer> itemMap, ExchangeActivity exchangeActivity) {
		ActivityExchRecord activityRec = exchangeActivity.getActivityExchList();
		List<Integer> ticketIdsList = new ArrayList<>();
		List<Integer> ticketNumsList = new ArrayList<>();
		if (activityRec != null) {
			ticketIdsList = DateUtil.StringToList(activityRec.getTicketId());
			ticketNumsList = DateUtil.StringToList(activityRec.getTicketNum());
		}
		List<ExchActivityData> exchList = new ArrayList<>();
		if (activityExchMap != null && itemMap != null && activityExchMap.size() > 0 && itemMap.size() > 0) {
			Set<String> ids = itemMap.keySet();
			if (ids != null && ids.size() > 0) {
				for (String id : ids) {
					ActivityExchData aed = activityExchMap.get(Integer.parseInt(id));
					ExchActivityData exchData = new ExchActivityData();
					exchData.setId(aed.getId());
					exchData.setIoc(aed.getIoc());
					exchData.setName(aed.getName());
					exchData.setType(aed.getType());
					exchData.setConsumeType(aed.getConsumeType());
					exchData.setConsumeNum(aed.getConsumeNum());
					if (aed.getType().equals("A")) {
						PlayerActivityExchRec rec = exchangeActivity.getPlayerExchActivityRec(player.getId(),
								Integer.parseInt(id));
						if (rec == null) {
							exchData.setSurplusNum(itemMap.get(id));
						} else {
							int surplusNum = itemMap.get(id) - Integer.parseInt(rec.getTicketNum());
							if (surplusNum < 0) {
								surplusNum = 0;
							}
							exchData.setSurplusNum(surplusNum);
						}
					} else {
						if (ticketIdsList != null && ticketNumsList != null) {
							for (int i = 0; i < ticketIdsList.size(); i++) {
								if (ticketIdsList.get(i) == Integer.parseInt(id)) {
									int surplusNum = itemMap.get(id) - ticketNumsList.get(i);
									if (surplusNum < 0) {
										surplusNum = 0;
									}
									exchData.setSurplusNum(surplusNum);
								}
							}
						} else {
							exchData.setSurplusNum(itemMap.get(id));
						}
					}

					exchList.add(exchData);
				}
				return exchList;
			}
		}
		return null;
	}
}