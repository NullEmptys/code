package com.gamedo.gameServer.controller.activity.loginReward;

import java.text.MessageFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.activity.Activity;
import com.gamedo.gameServer.activity.ActivityService;
import com.gamedo.gameServer.activity.loginReward.LoginRewardActivity;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.Time;
import com.gamedo.gameServer.entity.activity.loginReward.LoginRewardRecord;
import com.gamedo.gameServer.entity.activity.loginReward.LoginSignRecord;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.activity.loginReward.LoginRewardSignRequestMessage;
import com.gamedo.gameServer.message.activity.loginReward.LoginRewardSignResponseMessage;
import com.gamedo.gameServer.message.activity.loginReward.SignRewardData;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

/**
 * 7天登录签到
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.LOGIN_SIGN)
public class LoginSignController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private ActivityService activityService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		Packet packet = new Packet(OpCode.LOGIN_SIGN, request, response);
		LoginRewardSignRequestMessage requestMessage = (LoginRewardSignRequestMessage) packet
				.getRequestMessage(LoginRewardSignRequestMessage.class);
		LoginRewardSignResponseMessage message = new LoginRewardSignResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		Activity activity = activityService.getActivity(requestMessage.getActivityId());
		if (!activity.isActive()) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.ACTIVITY_NOT_ACTIVE);
			packet.send(message);
			return;
		}

		/* 最后签到日期 */
		int lastSignDay = player.getPool().getInt(Const.PROPERTY_LAST_LOGIN_SIGN_DAY);
		if (lastSignDay == Time.day) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.LOGINREWARD_SIGNED);
			packet.send(message);
			return;
		}
		LoginRewardActivity loginRewardActivity = (LoginRewardActivity) activity.getImpl();

		LoginSignRecord signRecord = loginRewardActivity.getPlayerSignRecord(player.getId(), activity.getId());
		if(signRecord.getSignCounts() >= 7) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.LOGINREWARD_DESC_1);
			packet.send(message);
			return;
		}
		
		if(requestMessage.getDay() - signRecord.getSignCounts() > 1) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(MessageFormat.format(I18NMessage.LOGINREWARD_DESC_2, requestMessage.getDay() - signRecord.getSignCounts()));
			packet.send(message);
			return;
		}else if(requestMessage.getDay() - signRecord.getSignCounts() < 0) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.LOGINREWARD_DESC_3);
			packet.send(message);
			return;
		}
		
		player.getPool().setInt(Const.PROPERTY_LAST_LOGIN_SIGN_DAY, Time.day);
		signRecord.setSignCounts(signRecord.getSignCounts() + 1);
		loginRewardActivity.updateLoginSignRecord(signRecord);

		LoginRewardRecord rewardRecord = loginRewardActivity.getPlayerLoginRewardRecord(player.getId(),
				activity.getId(), signRecord.getSignCounts());
		rewardRecord.setState(LoginRewardActivity.SIGNED);
		loginRewardActivity.updatePlayerLoginRewardRecord(rewardRecord);

		loginRewardActivity.reward(player, signRecord.getSignCounts());

		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		message.setRewardData(getRewardData(rewardRecord));
		message.setSignCounts(signRecord.getSignCounts());
		message.setCode(CommonResponseMessage.TRUE);
		playerService.updatePlayer(player);
		packet.send(message);
	}

	private SignRewardData getRewardData(LoginRewardRecord rewardRecord) {
		SignRewardData data = new SignRewardData();
		data.setDay(rewardRecord.getDay());
		data.setState(rewardRecord.getState());
		return data;
	}

}
