package com.gamedo.gameServer.controller.achievement;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.achievement.AchieveInfo;
import com.gamedo.gameServer.message.achievement.AchieveListRequestMessage;
import com.gamedo.gameServer.message.achievement.AchieveListResponseMessage;
import com.gamedo.gameServer.service.achievement.AchievementService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 成就列表
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.ACHIEVEMENT_LIST)
public class AchievementListController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private AchievementService achieveService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.ACHIEVEMENT_LIST, request, response);

		AchieveListRequestMessage requestMessage = (AchieveListRequestMessage) packet
				.getRequestMessage(AchieveListRequestMessage.class);
		
		AchieveListResponseMessage message = new AchieveListResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		List<AchieveInfo> achieves = achieveService.getAchieveInfoList(player,requestMessage.getCategory());
		message.setAchieves(achieves);
		message.setAchieveLevelInfo(achieveService.getAchieveLevelInfo(player));
		message.setCode(CommonResponseMessage.TRUE);
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		playerService.updatePlayer(player);
		
		packet.send(message);
		
	}

}
