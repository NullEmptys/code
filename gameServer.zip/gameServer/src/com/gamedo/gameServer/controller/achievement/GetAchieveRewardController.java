package com.gamedo.gameServer.controller.achievement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.item.ItemTemplate;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.achievement.AchieveLevel;
import com.gamedo.gameServer.data.achievement.Achievement;
import com.gamedo.gameServer.data.equipment.ClothCdTime;
import com.gamedo.gameServer.entity.achievement.PlayerAchievement;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.achievement.GetAchieveRewardRequestMessage;
import com.gamedo.gameServer.message.achievement.GetAchieveRewardResponseMessage;
import com.gamedo.gameServer.service.achievement.AchievementService;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

/**
 * 领取成就奖励
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.GET_ACHIEVE_REWARD)
public class GetAchieveRewardController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private AchievementService achieveService;
	@Autowired
	private ItemService itemService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.GET_ACHIEVE_REWARD, request, response);

		GetAchieveRewardRequestMessage requestMessage = (GetAchieveRewardRequestMessage) packet
				.getRequestMessage(GetAchieveRewardRequestMessage.class);

		GetAchieveRewardResponseMessage message = new GetAchieveRewardResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		Achievement achievement = achieveService.achievementMap.get(requestMessage.getAchieveId());
		if (achievement == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}

		PlayerAchievement playerAchieve = player.achivements.get(requestMessage.getAchieveId());
		if (playerAchieve == null) {
			playerAchieve = new PlayerAchievement();
			playerAchieve.id = requestMessage.getAchieveId();
			player.achivements.put(requestMessage.getAchieveId(), playerAchieve);
		}

		if (!playerAchieve.finished) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}

		if (playerAchieve.rewarded) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.ACHIEVE_REWARDED);
			packet.send(message);
			return;
		}

		PlayerTransaction tx = player.newTransaction("getAchieveReward");
		player.addAttributeByType(AttributeType.getAttrtType(achievement.getCurrencyType()),
				achievement.getCurrencyCounts(), tx);
		tx.commit();

		playerAchieve.rewarded = true;
		player.setAchieveValue(player.getAchieveValue() + achievement.getAchieveValue());

		giveReward(player, message);

		message.setCurrencyType(achievement.getCurrencyType());
		message.setCurrencyCounts(achievement.getCurrencyCounts());
		message.setCode(CommonResponseMessage.TRUE);
		message.setAchieveLevelInfo(achieveService.getAchieveLevelInfo(player));
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		packet.send(message);
		playerService.updatePlayer(player);
	}

	private void giveReward(Player player, GetAchieveRewardResponseMessage message) {
		for (int i = 0; i < achieveService.achieveLevels.size(); i++) {
			AchieveLevel achieveLevel = achieveService.achieveLevels.get(i);
			if (achieveLevel != null) {
				int state = player.getPool()
						.getInt(Const.PROPERTY_PLAYER_ACHIEVE_LEVEL_REWARD + "_" + achieveLevel.getLevel());
				if (player.getAchieveValue() >= achieveLevel.getAchieveValue() && state == 0) {
					ItemTemplate itemTemplate = itemService.getItemTemplate(achieveLevel.getRewardItemId());
					if (itemTemplate != null) {
						ClothCdTime clothCdTime = itemService.clothCdTimes.get(achieveLevel.getCdTimeType());
						long cdTime = -1;
						if (clothCdTime != null) {
							cdTime = clothCdTime.getCdTime();
						}
						player.getBags().addItem(achieveLevel.getRewardItemId(), achieveLevel.getRewardCounts(),
								"achieveLevelReward", cdTime);

						message.setRewardItemId(itemTemplate.getId());
						message.setRewardCounts(achieveLevel.getRewardCounts());
						player.getPool()
								.setInt(Const.PROPERTY_PLAYER_ACHIEVE_LEVEL_REWARD + "_" + achieveLevel.getLevel(), 1);
					}
				}
			}
		}
	}

}
