package com.gamedo.gameServer.controller.dispatch;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.io.OpCode;

/**
 * 客户端请求分发处理
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.DISPATCH)
public class DispatchClientRequestController {

	@RequestMapping(method = RequestMethod.POST)
	public void messageReceived(HttpServletRequest request,HttpServletResponse response) {
		
		
	}
}
