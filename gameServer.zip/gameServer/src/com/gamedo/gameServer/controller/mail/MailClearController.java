package com.gamedo.gameServer.controller.mail;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.mail.MailClearRequestMessage;
import com.gamedo.gameServer.message.mail.MailClearResponseMessage;
import com.gamedo.gameServer.service.mail.MailService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 清理信箱（删除已读且无附件邮件）
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.MAIL_CLEAR)
public class MailClearController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	
	@Autowired
	private MailService mailService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.MAIL_CLEAR, request, response);
		MailClearRequestMessage requestMessage = (MailClearRequestMessage) packet
				.getRequestMessage(MailClearRequestMessage.class);
		MailClearResponseMessage message = new MailClearResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		mailService.clearReadedNoAttachmentMails(requestMessage.getPlayerID());
		
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

}
