package com.gamedo.gameServer.controller.mail;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.mail.Mail;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.mail.MailDeleteRequestMessage;
import com.gamedo.gameServer.message.mail.MailDeleteResponseMessage;
import com.gamedo.gameServer.service.mail.MailService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 删除邮件
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.MAIL_DELETE)
public class MailDeleteController extends AbstractController {

	@Autowired
	private MailService mailService;
	
	@Autowired
	private PlayerService playerService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.MAIL_DELETE, request, response);
		MailDeleteRequestMessage requestMessage = (MailDeleteRequestMessage) packet
				.getRequestMessage(MailDeleteRequestMessage.class);
		MailDeleteResponseMessage message = new MailDeleteResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		Mail mail = mailService.getMail(requestMessage.getPlayerID(), requestMessage.getMailId());
		if(mail == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.CHOOSE_MAIL);
			packet.send(message);
			return;
		}
		mailService.deleteMail(player,mail);
	}

}
