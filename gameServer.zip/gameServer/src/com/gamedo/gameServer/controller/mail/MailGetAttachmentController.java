package com.gamedo.gameServer.controller.mail;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.mail.ItemMailAttachment;
import com.gamedo.gameServer.entity.mail.Mail;
import com.gamedo.gameServer.entity.mail.MailAttachment;
import com.gamedo.gameServer.entity.mail.MoneyMailAttachment;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.mail.MailAttachementItem;
import com.gamedo.gameServer.message.mail.MailGetAttachRequestMessage;
import com.gamedo.gameServer.message.mail.MailGetAttachResponseMessage;
import com.gamedo.gameServer.service.mail.MailService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 领取邮件附件
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.MAIL_GET_ATTACHMENT)
public class MailGetAttachmentController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private MailService mailService;
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		Packet packet = new Packet(OpCode.MAIL_GET_ATTACHMENT, request, response);

		MailGetAttachRequestMessage requestMessage = (MailGetAttachRequestMessage) packet
				.getRequestMessage(MailGetAttachRequestMessage.class);
		
		MailGetAttachResponseMessage message = new MailGetAttachResponseMessage();
		
		Player player = playerService.getPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		Mail mail = mailService.getMail(requestMessage.getPlayerID(), requestMessage.getMailId());
		if(mail == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_MAIL);
			packet.send(message);
			return;
		}
		
		if(mail.getReceivedAttach() == MailService.ATTACH_RECEIVED) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.MAIL_ATTACH_RECEIVED);
			packet.send(message);
			return;
		}
		
		if(mail.getAttachments() == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.MAIL_NOT_HAVE_ATTACH);
			packet.send(message);
			return;
		}
		List<MailAttachementItem> itemsList = new ArrayList<>();
		MailAttachment[] attachs = mail.getAttachments().getAttachments();
		if(attachs != null && attachs.length > 0) {
			for(int i = 0; i < attachs.length; i++) {
				MailAttachment attach = attachs[i];
				if(attach != null) {
					if(attach instanceof ItemMailAttachment) {
						ItemMailAttachment im = (ItemMailAttachment)attach;
						long cdTime = -1;
						if(im.getCdTime() != -1) {
							cdTime = im.getCdTime();
						}
						player.getBags().addItem(im.getGameItem().getTemplate().getId(), im.getCount(), "邮件附件mailId=" + mail.getId(),cdTime);
						MailAttachementItem item = new MailAttachementItem(2,im.getGameItem().getTemplate().getId(),im.getCount());
						itemsList.add(item);
					}else if(attach instanceof MoneyMailAttachment) {
						MoneyMailAttachment mm = (MoneyMailAttachment)attach;
						PlayerTransaction tx = player.newTransaction("邮件附件mailId=" + mail.getId());
						player.addAttributeByType(AttributeType.getAttrtType(mm.getCurrencyType()), mm.getCount(), tx);
						MailAttachementItem item = new MailAttachementItem(1,mm.getCurrencyType(), mm.getCount());
						itemsList.add(item);
						tx.commit();
					}
				}
			}
			
			mail.setReceivedAttach(MailService.ATTACH_RECEIVED);
		}
		mailService.deleteMail(player,mail);
		message.setCode(CommonResponseMessage.TRUE);
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		message.setMailAattachementItem(itemsList);
		packet.send(message);
		
		playerService.updatePlayer(player);
		//mailService.updateMail(mail);
	}

}
