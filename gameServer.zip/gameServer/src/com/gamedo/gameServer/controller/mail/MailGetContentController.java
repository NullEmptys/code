package com.gamedo.gameServer.controller.mail;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.mail.ItemMailAttachment;
import com.gamedo.gameServer.entity.mail.Mail;
import com.gamedo.gameServer.entity.mail.MailAttachment;
import com.gamedo.gameServer.entity.mail.MailAttachments;
import com.gamedo.gameServer.entity.mail.MoneyMailAttachment;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.mail.AttachmentInfo;
import com.gamedo.gameServer.message.mail.MailGetContentRequestMessage;
import com.gamedo.gameServer.message.mail.MailGetContentResponseMessage;
import com.gamedo.gameServer.service.mail.MailService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 阅读邮件
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.MAIL_GET_CONTENT)
public class MailGetContentController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private MailService mailService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.MAIL_GET_CONTENT, request, response);

		MailGetContentRequestMessage requestMessage = (MailGetContentRequestMessage) packet
				.getRequestMessage(MailGetContentRequestMessage.class);
		MailGetContentResponseMessage message = new MailGetContentResponseMessage();
		
		Player player = playerService.getPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		Mail mail = mailService.getMail(requestMessage.getPlayerID(), requestMessage.getMailId());
		if(mail == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_MAIL);
			packet.send(message);
			return;
		}
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setMailId(mail.getId());
		message.setContent(mail.getContent());
		message.setAttachs(getMailAttachmentInfo(mail));
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		packet.send(message);
		
		mail.setStatus(MailService.READED);
		mailService.updateMail(mail);
	}

	private List<AttachmentInfo> getMailAttachmentInfo(Mail mail) {
		List<AttachmentInfo> attachInfos = new ArrayList<>();
		MailAttachments attachments = mail.getAttachments();
		if(attachments != null) {
			MailAttachment[] attachs = attachments.getAttachments();
			if(attachs != null && attachs.length > 0) {
				for(int i=0;i<attachs.length;i++) {
					AttachmentInfo info = new AttachmentInfo();
					if(attachs[i] instanceof ItemMailAttachment){
						ItemMailAttachment im=(ItemMailAttachment)attachs[i];
						info.setAttachType(1);//物品
						info.setRewardId(im.getGameItem().getTemplate().getId());
						info.setRewardCounts(im.getCount());
					}else if(attachs[i] instanceof MoneyMailAttachment){
						MoneyMailAttachment mm=(MoneyMailAttachment)attachs[i];
						info.setAttachType(2);//
						info.setRewardId(mm.getCurrencyType());
						info.setRewardCounts(mm.getCount());
					}
					attachInfos.add(info);
				}
			}
		}
		return attachInfos;
	}

}
