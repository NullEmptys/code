package com.gamedo.gameServer.controller.shop;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.item.ItemTemplate;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.equipment.ClothCdTime;
import com.gamedo.gameServer.data.equipment.ClothPrice;
import com.gamedo.gameServer.data.wardrobe.Wardrobe;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.shop.BuyItemData;
import com.gamedo.gameServer.message.shop.ShopBuyItemRequestMessage;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 购买商品
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.BUY_ITEM)
public class ShopBuyItemController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private ItemService itemService;
	@Autowired
	private EventManager eventManager;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.BUY_ITEM, request, response);

		ShopBuyItemRequestMessage requestMessage = (ShopBuyItemRequestMessage) packet
				.getRequestMessage(ShopBuyItemRequestMessage.class);

		CommonResponseMessage message = new CommonResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		List<BuyItemData> buyItemDatas = requestMessage.getBuyItemData();
		if (buyItemDatas == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_CHOOSE_ITEM);
			packet.send(message);
			return;
		}
		boolean flag = true;
		PlayerTransaction tx = player.newTransaction("buyItem");
		String desc = "";
		int buyCount = 0;
		for (BuyItemData buyItemData : buyItemDatas) {
			if (buyItemData != null) {
				Wardrobe wardrobeItem = itemService.getWardrobeItem(buyItemData.getItemId());
				if (wardrobeItem != null) {
					try {
						ItemTemplate template = itemService.getItemTemplate(wardrobeItem.getItemId());
						if (template == null) {
							flag = false;
							desc = I18NMessage.NOT_FOUND_ITEM;
							break;
						}
						GameItem gameItem = player.getBags().getGameItem(wardrobeItem.getItemId());
						if(gameItem == null) {
							ClothPrice clothPrice = itemService.getClothPrice(wardrobeItem.getItemId(),requestMessage.getCdTimeType());
							if(clothPrice != null) {
								player.decCurrency(AttributeType.getAttrtType(clothPrice.getCurrencyType()),
										clothPrice.getCurrencyCounts(), tx, false);
								ClothCdTime clothCdTime = itemService.clothCdTimes.get(requestMessage.getCdTimeType());
								long cdTime = -1;
								if(clothCdTime != null) {
									cdTime = clothCdTime.getCdTime();
								}
								player.getBags().addItem(wardrobeItem.getItemId(), buyItemData.getCount(), "buyItem", cdTime);
								buyCount += 1;
								player.addBuyClothCounts(template.getType());
							}else {
								flag = false;
								desc = I18NMessage.DATA_EXCEPTION;
							}
						}
					} catch (NoEnoughValueException e) {
						flag = false;
						desc = I18NMessage.NO_ENOUGH_CURRENCY;
						e.printStackTrace();
						break;
					}
				}
			}
		}
		if (flag) {
			tx.commit();
			message.setCode(CommonResponseMessage.TRUE);
			message.setUpdateObj(playerService.sendAndClean(player.getId()));
			packet.send(message);
			if(buyCount > 0) {
				eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_BUY_EQUIP,player,buyCount));
			}
			playerService.updatePlayer(player);
		} else {
			tx.rollback();
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(desc);
			packet.send(message);
		}
	}

}
