package com.gamedo.gameServer.controller.shop;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.shop.Shop;
import com.gamedo.gameServer.data.shop.ShopItem;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.shop.LimitBuyShopItemData;
import com.gamedo.gameServer.message.shop.ShopData;
import com.gamedo.gameServer.message.shop.ShopItemData;
import com.gamedo.gameServer.message.shop.ShopListResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.shop.ShopService;

/**
 * 商城列表
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.SHOP_LIST)
public class ShopListController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private ShopService shopService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.SHOP_LIST, request, response);
		
		CommonRequestMessage requestMessage = (CommonRequestMessage) packet
				.getRequestMessage(CommonRequestMessage.class);
		
		ShopListResponseMessage message =new ShopListResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		Map<Integer,Shop> shops = shopService.getShops();
		if(shops != null && shops.size() > 0) {
			List<ShopData> shopDatas = new ArrayList<>();
			for(Integer shopId : shops.keySet()) {
				if(shopId != null) {
					ShopData shopData = new ShopData();
					shopData.setShopId(shopId);
					Map<Integer,ShopItem> shopItems = shopService.findShopItems(shopId);
					if(shopItems != null && shopItems.size() > 0) {
						List<ShopItemData> shopItemDatas = new ArrayList<>();
						for(ShopItem shopItem : shopItems.values()) {
							if(shopItem != null) {
								ShopItemData shopItemData = new ShopItemData();
								shopItemData.setItemId(shopItem.getItemId());
								shopItemDatas.add(shopItemData);
							}
						}
						shopData.setShopItems(shopItemDatas);
					}
					shopDatas.add(shopData);
				}
			}
			message.setShopData(shopDatas);
		}
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

}
