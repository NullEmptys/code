package com.gamedo.gameServer.controller.engagement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.item.ItemTemplate;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.engagement.EngagementShopItem;
import com.gamedo.gameServer.data.girl.Girl;
import com.gamedo.gameServer.data.item.Item;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.engagement.SendGiftRequestMessage;
import com.gamedo.gameServer.message.engagement.SendGiftResponseMessage;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.engagement.EngagementService;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

/**
 * 约会送礼
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.SEND_GIFT)
public class SendGiftController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private EngagementService engagementService;
	@Autowired
	private GirlService girlService;
	@Autowired
	private ItemService itemService;
	@Autowired
	private EventManager eventManager;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.SEND_GIFT, request, response);

		SendGiftRequestMessage requestMessage = (SendGiftRequestMessage) packet
				.getRequestMessage(SendGiftRequestMessage.class);

		SendGiftResponseMessage message = new SendGiftResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		EngagementShopItem shopItem = engagementService.getEngagementShopItemById(requestMessage.getItemId());
		if (shopItem == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_ENGAGEMENT_SHOP_ITEM);
			packet.send(message);
			return;
		}

		PlayerGirl playerGirl = girlService.getPlayerGirl(player.getId(),
				player.getPool().getInt(Const.PROPERTY_ENGAGEMENT_GIRL_ID));
		if(playerGirl == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.CHOOSE_GIRL);
			packet.send(message);
			return;
		}
		
		int maxLevel = girlService.getMaxLevelByGirlId(playerGirl.getGirlId());
		if(playerGirl.getLevel() >= maxLevel) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.GIRL_MAX_LEVEL);
			packet.send(message);
			return;
		}

		PlayerTransaction tx = player.newTransaction("sendGift");
		GameItem gameItem = player.getBags().removeGameItem(requestMessage.getItemId(), 0, 1, tx, false);
		if (gameItem != null) {
			tx.commit();
		} else {
			tx.rollback();
			PlayerTransaction tx1 = player.newTransaction("sendGift");
			try {
				player.decCurrency(AttributeType.getAttrtType(shopItem.getCurrencyType()), shopItem.getPrice(), tx1,
						false);
				tx1.commit();
			} catch (NoEnoughValueException e) {
				tx1.rollback();
				e.printStackTrace();
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
				packet.send(message);
				return;
			}
		}
		int sendGiftCounts = player.getPool().getInt(Const.PROPERTY_SEND_GIFT_COUNTS);
		player.getPool().setInt(Const.PROPERTY_SEND_GIFT_COUNTS, sendGiftCounts + 1);
		player.addSendGirlGiftCounts(playerGirl.getGirlId(),1);
		
		int oldLevel = playerGirl.getLevel();
		int exp = calcExp(sendGiftCounts, shopItem, playerGirl.getGirlId());
		playerGirl = girlService.updateGirlExp(player.getId(), playerGirl.getGirlId(), exp);
		int newLevel = playerGirl.getLevel();
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setExp(playerGirl.getExp());
		message.setLevel(playerGirl.getLevel());
		message.setSendGiftCounts(player.getPool().getInt(Const.PROPERTY_SEND_GIFT_COUNTS));
		if(newLevel > oldLevel) {
			message.setUpLevel(1);
		}
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_GIFT_GIRL,player));
		packet.send(message);
		playerService.updatePlayer(player);
	}
	
	public int calcExp(int sendGiftCounts,EngagementShopItem shopItem,int girlId) {
		int exp = 0;
		double sceneRatio = 1;
		double attributeRatio = 1;
		Girl girl = girlService.getGirl(girlId);
		if(girl.adaptSceneIds.containsKey(engagementService.getEngagementScene().getSceneId())) {
			sceneRatio = EngagementService.SCENE_RATIO;
		}
		Item item = itemService.getItemById(shopItem.getItemId());
		if(girl.superLoveAttributes.containsKey(item.getAttribute())) {
			attributeRatio = EngagementService.SUPER_LOVE_ATTRIBUTE_RATIO;
		}else if(girl.loveAttributes.containsKey(item.getAttribute())) {
			attributeRatio = 1;
		}else {
			attributeRatio = EngagementService.DISLIKE_ATTRIBUTE_RATIO;
		}
		double sendGiftCountRatio = 1;
		if(sendGiftCounts <= engagementService.maxSendGiftCounts) {
			sendGiftCountRatio = engagementService.engagementRatios.get(sendGiftCounts).getRatio();
		}else {
			sendGiftCountRatio = EngagementService.DEFAULT_SEND_GIFT_RATIO;
		}
		exp = (int) Math.ceil(shopItem.getBaseExpValue() * sceneRatio * attributeRatio * sendGiftCountRatio);
		return exp; 
	}

}
