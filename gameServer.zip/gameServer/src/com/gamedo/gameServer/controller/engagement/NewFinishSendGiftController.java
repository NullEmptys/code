package com.gamedo.gameServer.controller.engagement;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.Constants;
import com.gamedo.gameServer.constant.SendGiftResultType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.engagement.EngagementSendGiftWeightConfig;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.engagement.FinishGiftRequestMessage;
import com.gamedo.gameServer.message.engagement.FinishGiftResponseMessage;
import com.gamedo.gameServer.service.engagement.EngagementService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

import gnu.trove.map.hash.TIntObjectHashMap;

@Controller
@RequestMapping(value = OpCode.NEW_FINISH_SEND_GIFT)
public class NewFinishSendGiftController extends AbstractController{

	@Autowired
	private PlayerService playerService;
//	@Autowired
//	private EngagementService engagementService;
	
	private static Random random = new Random();
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.NEW_FINISH_SEND_GIFT, request, response);

		FinishGiftRequestMessage requestMessage = (FinishGiftRequestMessage) packet
				.getRequestMessage(FinishGiftRequestMessage.class);
		
		FinishGiftResponseMessage message = new FinishGiftResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
//		TIntObjectHashMap<EngagementSendGiftWeightConfig> weightRout = engagementService.getSendGiftFinishRoute();
		int moodValue = player.getPool().getInt(Const.MOOD_VALUE);
		int sendGiftCount = player.getPool().getInt(Const.PROPERTY_SEND_GIFT_COUNTS);//送礼次数
		int route = 0;
		if(sendGiftCount == 0){
//			EngagementSendGiftWeightConfig weightConfig = weightRout.get(SendGiftResultType.NOT_SEND_GIFT.getId());
			route = getRouteByWeight(Constants.NOT_SEND_GIFT,Constants.NOT_SEND_GIFT);
		}else{
			if(moodValue == 0 ){
//				EngagementSendGiftWeightConfig weightConfig = weightRout.get(SendGiftResultType.SEND_GIFT_ZERO.getId());
				route = getRouteByWeight(Constants.GOOD,Constants.BAD);
			}else if(moodValue < 0 ){
//				EngagementSendGiftWeightConfig weightConfig = weightRout.get(SendGiftResultType.MOOD_NEGATIVE.getId());
				route = getRouteByWeight(Constants.GOOD,Constants.BAD);
			}
		}
		player.getPool().setInt(Const.FINISH_SEND_GIFT_STATE, route);
		player.getPool().setInt(Const.ENGAGEMENT_STEP, requestMessage.getDatingStep());
		message.setNewFinishSendGiftstate(route);;
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 根据权重随机路线
	 * @param weightConfig
	 * @return
	 */
	private int getRouteByWeight(int start,int end){
//		int weightSum = weightConfig.getGoodRoute() + weightConfig.getBadRoute();
		int weightSum = start + end;
		int n = random.nextInt(weightSum); // n in [0, weightSum) 
		if(n < start){
			return 1;//相对较好的路线
		}
		return 2;//相对较差的路线
	}
}
