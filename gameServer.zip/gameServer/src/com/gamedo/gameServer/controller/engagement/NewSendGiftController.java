package com.gamedo.gameServer.controller.engagement;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.engagement.NewEngagementShopItem;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.engagement.NewSendGiftRequestMessage;
import com.gamedo.gameServer.message.engagement.NewSendGiftResponseMessage;
import com.gamedo.gameServer.message.engagement.SendGiftData;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.engagement.EngagementService;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;
import com.gamedo.gameServer.util.DateUtil;
/**
 * 新约会送礼
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = OpCode.NEW_SEND_GIFT)
public class NewSendGiftController extends AbstractController {


	@Autowired
	private PlayerService playerService;
	@Autowired
	private EngagementService engagementService;
	@Autowired
	private GirlService girlService;
	@Autowired
	private ItemService itemService;
	@Autowired
	private EventManager eventManager;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.NEW_SEND_GIFT, request, response);

		NewSendGiftRequestMessage requestMessage = (NewSendGiftRequestMessage) packet
				.getRequestMessage(NewSendGiftRequestMessage.class);

		NewSendGiftResponseMessage message = new NewSendGiftResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		NewEngagementShopItem shopItem = engagementService.getNewEngagementShopItemById(requestMessage.getItemId());
		if (shopItem == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc("未找到指定物品");
			packet.send(message);
			return;
		}

		PlayerGirl playerGirl = girlService.getPlayerGirl(player.getId(),
				player.getPool().getInt(Const.PROPERTY_ENGAGEMENT_GIRL_ID));
		if(playerGirl == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc("请选择一个约会对象");
			packet.send(message);
			return;
		}
		
		int maxLevel = girlService.getMaxLevelByGirlId(playerGirl.getGirlId());
		if(playerGirl.getLevel() >= maxLevel) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.GIRL_MAX_LEVEL);
			packet.send(message);
			return;
		}
		
		PlayerTransaction tx = player.newTransaction("sendGift");
		GameItem gameItem = player.getBags().removeGameItem(requestMessage.getItemId(), 0, 1, tx, false);
		if (gameItem != null) {
			tx.commit();
		} else {
			tx.rollback();
			PlayerTransaction tx1 = player.newTransaction("sendGift");
			try {
				player.decCurrency(AttributeType.getAttrtType(shopItem.getCurrencyType()), shopItem.getPrice(), tx1,
						false);
				tx1.commit();
			} catch (NoEnoughValueException e) {
				tx1.rollback();
				e.printStackTrace();
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
				packet.send(message);
				return;
			}
		}
		int sendGiftCounts = player.getPool().getInt(Const.PROPERTY_SEND_GIFT_COUNTS);
		player.getPool().setInt(Const.PROPERTY_SEND_GIFT_COUNTS, sendGiftCounts + 1);
		player.addSendGirlGiftCounts(playerGirl.getGirlId(),1);
		
		int oldLevel = playerGirl.getLevel();
		int exp = shopItem.getBaseExpValue();
		playerGirl = girlService.updateGirlExp(player.getId(), playerGirl.getGirlId(), exp);
		int newLevel = playerGirl.getLevel();
		
		/*计算心情值**/
		List<Integer> likeGirlList = DateUtil.StringToList(shopItem.getLikeGirl());
		if(likeGirlList != null){
			if(likeGirlList.contains(player.getPool().getInt(Const.PROPERTY_ENGAGEMENT_GIRL_ID))){
				player.getPool().setInt(Const.MOOD_VALUE, player.getPool().getInt(Const.MOOD_VALUE) + shopItem.getAddMoodValue());
			}
		}
		List<Integer> hateGirlList = DateUtil.StringToList(shopItem.getHateGirl());
		if(hateGirlList != null){
			if(hateGirlList.contains(player.getPool().getInt(Const.PROPERTY_ENGAGEMENT_GIRL_ID))){
				player.getPool().setInt(Const.MOOD_VALUE, player.getPool().getInt(Const.MOOD_VALUE) - shopItem.getDelMoodValue());
			}
		}
		message.setCode(CommonResponseMessage.TRUE);
		SendGiftData newEngagementSendGift = new SendGiftData();
		newEngagementSendGift.setExp(playerGirl.getExp());
		newEngagementSendGift.setLevel(playerGirl.getLevel());
		newEngagementSendGift.setSendGiftCounts(player.getPool().getInt(Const.PROPERTY_SEND_GIFT_COUNTS));
		if(newLevel > oldLevel) {
			newEngagementSendGift.setUpLevel(1);
		}
		newEngagementSendGift.setMoodValues(player.getPool().getInt(Const.MOOD_VALUE));
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		message.setNewEngagementSendGift(newEngagementSendGift);
		eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_GIFT_GIRL,player));
		packet.send(message);
		player.getPool().setInt(Const.ENGAGEMENT_STEP, requestMessage.getDatingStep());
		playerService.updatePlayer(player);
	}
}
