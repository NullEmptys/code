package com.gamedo.gameServer.controller.engagement;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.engagement.EngagementGuess;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.engagement.BeginGuessResponseMessage;
import com.gamedo.gameServer.message.engagement.GuessReward;
import com.gamedo.gameServer.service.engagement.EngagementService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

/**
 * 开始猜拳
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.BEGIN_GUESS)
public class BeginGuessController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private EngagementService engagementService;
	@Autowired
	private EventManager eventManager;
	
	/* (non-Javadoc)
	 * @see com.gamedo.gameServer.controller.AbstractController#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.BEGIN_GUESS, request, response);

		CommonRequestMessage requestMessage = (CommonRequestMessage) packet
				.getRequestMessage(CommonRequestMessage.class);
		
		BeginGuessResponseMessage message = new BeginGuessResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		int guessCounts = player.getPool().getInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS);
//		if(guessCounts >= EngagementService.MAX_GUESS_COUNTS) {
//			message.setCode(CommonResponseMessage.FALSE);
//			message.setDesc("当前时段猜拳次数已用尽");
//			packet.send(message);
//			return;
//		}
		int round = player.getPool().getInt(Const.PROPERTY_GUESS_ROUND);
		EngagementGuess guess = engagementService.engagementGuesss.get(round);
		if(guess != null) {
			PlayerTransaction tx = player.newTransaction("beginGuess");
			try {
				player.decCurrency(AttributeType.getAttrtType(guess.getConsumeCurrencyType()), guess.getConsumeCurrencyCounts(), tx, false);
				tx.commit();
			} catch (NoEnoughValueException e) {
				e.printStackTrace();
				tx.rollback();
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
				packet.send(message);
				return;
			}
		}
		
		int result = engagementService.calcGuessResult(player);
		if(result == EngagementService.GUESS_FAIL) {
			player.getPool().setInt(Const.PROPERTY_GUESS_ROUND, 0);
			player.getPool().setInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS, guessCounts + 1);
		}else{
			if(round == engagementService.maxRound) {
				player.getPool().setInt(Const.PROPERTY_GUESS_ROUND, 0);
				player.getPool().setInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS, guessCounts + 1);
				
				List<GuessReward> rewards = engagementService.reward(player, round);
				message.setRewards(rewards);
				message.setFinished(1);
			}
		}
		message.setCode(CommonResponseMessage.TRUE);
 		message.setGuessResult(result);
		message.setGuessCounts(player.getPool().getInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS));
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_MORA,player));
		packet.send(message);
		playerService.updatePlayer(player);
	}

	
}
