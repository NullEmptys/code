package com.gamedo.gameServer.controller.engagement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.engagement.GetGuessRoundResponseMessage;
import com.gamedo.gameServer.service.engagement.EngagementService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

/**
 * 获取玩家猜拳回合数
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.GET_GUESS_ROUND)
public class GetGuessRoundController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private EngagementService engagementService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.GET_GUESS_ROUND, request, response);
		CommonRequestMessage requestMessage = (CommonRequestMessage) packet
				.getRequestMessage(CommonRequestMessage.class);

		GetGuessRoundResponseMessage message = new GetGuessRoundResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		int round = player.getPool().getInt(Const.PROPERTY_GUESS_ROUND);
		if (round >= engagementService.maxRound) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.ENGAGEMENT_DESC_4);
			packet.send(message);
			return;
		}

		if(round == 0) {
			player.getPool().setInt(Const.PROPERTY_GUESS_ROUND, round + 1);
		}

		message.setCode(CommonResponseMessage.TRUE);
		message.setRound(player.getPool().getInt(Const.PROPERTY_GUESS_ROUND));
		message.setMaxRound(engagementService.maxRound);
		packet.send(message);
		playerService.updatePlayer(player);
	}

}
