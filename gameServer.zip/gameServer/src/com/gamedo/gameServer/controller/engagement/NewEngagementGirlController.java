package com.gamedo.gameServer.controller.engagement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.engagement.EngagementGirlRequestMessage;
import com.gamedo.gameServer.message.engagement.NewEngagementGirlResponseMessage;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;
/**
 * 新约会模特
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = OpCode.NEW_ENGAGEMENT_GIRL)
public class NewEngagementGirlController extends AbstractController{

	@Autowired
	private PlayerService playerService;
	@Autowired
	private GirlService girlService;
	@Autowired
	private EventManager eventManager;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.NEW_ENGAGEMENT_GIRL, request, response);

		EngagementGirlRequestMessage requestMessage = (EngagementGirlRequestMessage) packet
				.getRequestMessage(EngagementGirlRequestMessage.class);

		NewEngagementGirlResponseMessage message = new NewEngagementGirlResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		int engagementGirlId = player.getEngagementGirlId();
		if(engagementGirlId != 0) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc("请下一时段再选择约会对象！");
			packet.send(message);
			return;
		}
		
		PlayerGirl playerGirl = girlService.getPlayerGirl(player.getId(), requestMessage.getGirlId());
		if(playerGirl == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.GIRL_NOT_FOUND);
			packet.send(message);
			return;
		}
		if(playerGirl.getCdTime() != -1) {
			if (playerGirl.getCdTime() == 0 || System.currentTimeMillis() > playerGirl.getCdTime()) {
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.GIRL_NOT_SIGN);
				packet.send(message);
				return;
			}
		}
		player.setEngagementGirlId(playerGirl.getGirlId());
		message.setCode(CommonResponseMessage.TRUE);
		message.setNewEngagementGirlId(playerGirl.getGirlId());
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_APPOINTMENT,player));
		packet.send(message);
		playerService.updatePlayer(player);
	}
	
}
