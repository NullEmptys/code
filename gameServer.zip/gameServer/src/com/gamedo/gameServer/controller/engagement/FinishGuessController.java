package com.gamedo.gameServer.controller.engagement;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.engagement.FinishGuessRequestMessage;
import com.gamedo.gameServer.message.engagement.FinishGuessResponseMessage;
import com.gamedo.gameServer.message.engagement.GuessReward;
import com.gamedo.gameServer.service.engagement.EngagementService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

/**
 * 结束猜拳
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.FINISH_GUESS)
public class FinishGuessController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private EngagementService engagementService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.FINISH_GUESS, request, response);

		FinishGuessRequestMessage requestMessage = (FinishGuessRequestMessage) packet
				.getRequestMessage(FinishGuessRequestMessage.class);

		FinishGuessResponseMessage message = new FinishGuessResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		int round = player.getPool().getInt(Const.PROPERTY_GUESS_ROUND);
		if(round == 0) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.ENGAGEMENT_DESC_3);
			packet.send(message);
			return;
		}
		
		player.getPool().setInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS,
				player.getPool().getInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS) + 1);
		
		List<GuessReward> rewards = null;
		if(requestMessage.getFinishType() == 1) {
			rewards = engagementService.reward(player, round);
		}else if(requestMessage.getFinishType() == 2) {
			rewards = engagementService.reward(player, round - 1);
		}else {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		
		player.getPool().setInt(Const.PROPERTY_GUESS_ROUND, 0);
		player.getPool().setInt(Const.PROPERTY_ENGAGEMENT_GAME_COUNTS, player.getPool().getInt(Const.PROPERTY_ENGAGEMENT_GAME_COUNTS) + 1);
		
		EventManager.getInstance().addEvent(new ServiceEvent(ServiceEvent.EVENT_FINISHED_GUESS, player));
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setRewards(rewards);
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		message.setGuessCounts(player.getPool().getInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS));
		packet.send(message);
		playerService.updatePlayer(player);
	}

}
