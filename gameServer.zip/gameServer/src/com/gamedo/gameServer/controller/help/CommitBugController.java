package com.gamedo.gameServer.controller.help;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.db.player.PlayerBugCommitDao;
import com.gamedo.gameServer.entity.commitbug.CommitBug;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.help.CommitBugRequestMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

/**
 * 提交bug
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = OpCode.COMMIT_BUG)
public class CommitBugController extends AbstractController{

	@Autowired
	private PlayerService playerService;
	@Autowired
	private PlayerBugCommitDao playerBugCommitDao;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.COMMIT_BUG,request,response);
		CommitBugRequestMessage requestMessage = (CommitBugRequestMessage) packet.getRequestMessage(CommitBugRequestMessage.class);
		CommonResponseMessage message = new CommonResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		if(player.getPool().getInt(Const.COMMIT_BUG) >= 3){
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NEXT_DAY_COMMIT);
			packet.send(message);
			return;
		}
		CommitBug commitBug = new CommitBug();
		commitBug.setName(player.getName());
		commitBug.setPlayerId(player.getId());
		commitBug.setContext(requestMessage.getContext());
		commitBug.setCommitDate(new Date());
		playerBugCommitDao.newEntity(commitBug);
		player.getPool().setInt(Const.COMMIT_BUG, player.getPool().getInt(Const.COMMIT_BUG) + 1);
		playerService.updatePlayer(player);
		message.setDesc(I18NMessage.COMMIT_SUCCESS);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

}
