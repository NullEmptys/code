package com.gamedo.gameServer.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 * @author libm
 *
 */
public abstract class AbstractController {
	
	public abstract void execute(HttpServletRequest request, HttpServletResponse response);

}
