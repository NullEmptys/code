package com.gamedo.gameServer.controller.quest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.quest.Quest;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.quest.PlayerQuest;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.quest.QuestLockRequestMessage;
import com.gamedo.gameServer.message.quest.QuestLockResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;

/**
 * 任务锁住以及解锁
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.QUEST_LOCK)
public class QuestLockController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private QuestService questService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.QUEST_LOCK, request, response);

		QuestLockRequestMessage requestMessage = (QuestLockRequestMessage) packet
				.getRequestMessage(QuestLockRequestMessage.class);
		
		QuestLockResponseMessage responseMessage = new QuestLockResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		
		Quest quest = questService.getQuestById(requestMessage.getQuestId());
		if(quest == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_QUEST);
			packet.send(responseMessage);
			return;
		}
		
		if(requestMessage.getType() == QuestService.LOCK) {//锁任务
			boolean canLock = false;
			if(!canLock) {
				responseMessage.setCode(CommonResponseMessage.FALSE);
				responseMessage.setDesc(I18NMessage.QUEST_CAN_NOT_LOCK);
				packet.send(responseMessage);
				return;
			}
		}else if(requestMessage.getType() == QuestService.UNLOCK) {//解锁任务
			PlayerQuest playerQuest = questService.getPlayerQuestById(player.getId(),requestMessage.getQuestId());
			if(playerQuest == null) {
				responseMessage.setCode(CommonResponseMessage.FALSE);
				responseMessage.setDesc(I18NMessage.NOT_FOUND_QUEST);
				packet.send(responseMessage);
				return;
			}
			if(playerQuest.getLocked() == PlayerQuest.COMMON) {
				responseMessage.setCode(CommonResponseMessage.FALSE);
				responseMessage.setDesc(I18NMessage.QUEST_IS_NOT_LOCKED);
				packet.send(responseMessage);
				return;
			}
		}
//		questService.questLockOrUnlock(player,requestMessage.getQuestId(),requestMessage.getType());
		
		responseMessage.setCode(CommonResponseMessage.TRUE);
		responseMessage.setUpdateObj(playerService.sendAndClean(player.getId()));
		packet.send(responseMessage);
	}

}
