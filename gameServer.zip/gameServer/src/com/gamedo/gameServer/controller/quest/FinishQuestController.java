package com.gamedo.gameServer.controller.quest;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.constant.BubbleType;
import com.gamedo.gameServer.constant.PlayDropType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.fall.GroupDropService;
import com.gamedo.gameServer.core.gain.Gain;
import com.gamedo.gameServer.core.gain.GainEntry;
import com.gamedo.gameServer.core.gain.GameItemGainEntry;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.equipment.ClothCdTime;
import com.gamedo.gameServer.data.quest.Bubble;
import com.gamedo.gameServer.data.quest.DropRate;
import com.gamedo.gameServer.data.quest.HeartBeat;
import com.gamedo.gameServer.data.quest.PlayDropItem;
import com.gamedo.gameServer.data.quest.Quest;
import com.gamedo.gameServer.data.quest.QuestConditionReward;
import com.gamedo.gameServer.data.quest.QuestFinishPhotoReward;
import com.gamedo.gameServer.data.quest.QuestResultCondition;
import com.gamedo.gameServer.data.quest.XieZhenReward;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.quest.PlayerQuest;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.quest.BubbleReward;
import com.gamedo.gameServer.message.quest.BubbleRewardItem;
import com.gamedo.gameServer.message.quest.FinishQuestRequestMessage;
import com.gamedo.gameServer.message.quest.FinishQuestResponseMessage;
import com.gamedo.gameServer.message.quest.GroupReward;
import com.gamedo.gameServer.message.quest.QualityReward;
import com.gamedo.gameServer.message.quest.RewardItem;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;
import com.gamedo.gameServer.util.Const;
import com.gamedo.gameServer.util.DateUtil;

import gnu.trove.map.hash.TIntObjectHashMap;

/**
 * 完成任务
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.QUEST_FINISH)
public class FinishQuestController extends AbstractController {

	@Autowired
	private QuestService questService;
	@Autowired
	private PlayerService playerService;
	@Autowired
	private ItemService itemService;
	@Autowired
	private EventManager eventManager;
	@Autowired
	private GroupDropService grouDropService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.QUEST_FINISH, request, response);

		FinishQuestRequestMessage requestMessage = (FinishQuestRequestMessage) packet
				.getRequestMessage(FinishQuestRequestMessage.class);

		FinishQuestResponseMessage message = new FinishQuestResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		Quest quest = questService.getQuestById(requestMessage.getQuestId());
		if (quest == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}

		PlayerQuest playerQuest = questService.getPlayerQuestById(player.getId(), quest.getId());
		if (playerQuest == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_QUEST);
			packet.send(message);
			return;
		}

		List<GroupReward> groupRewards = new ArrayList<>();
		List<Integer> conditionIds = requestMessage.getFinishConditionIds();
		TIntObjectHashMap<QuestResultCondition> resultConditionMap = questService.resultConditions
				.get(playerQuest.getQuestId());
		if (conditionIds != null && conditionIds.size() > 0) {
			for (Integer groupId : conditionIds) {
				if (groupId != null && resultConditionMap.containsKey(groupId)) {
					if(questService.conditionRewards.get(playerQuest.getQuestId()) != null) {
						GroupReward groupReward = new GroupReward();
						groupReward.setGroupId(groupId);
						List<QuestConditionReward> rewards = questService.conditionRewards.get(playerQuest.getQuestId())
								.get(groupId);
						if (rewards != null && rewards.size() > 0) {
							List<RewardItem> rewardItems = new ArrayList<>();
							for (QuestConditionReward reward : rewards) {
								if (reward != null) {
									if (reward.getRewardType() == Const.REWARD_CURRENCY) {
										PlayerTransaction tx = player.newTransaction("finishQuest");
										player.addAttributeByType(AttributeType.getAttrtType(reward.getRewardId()),
												reward.getRewardCounts(), tx);
										tx.commit();
									} else if (reward.getRewardType() == Const.REWARD_ITEM) {
										ClothCdTime clothCdTime = itemService.getClothCdTime(reward.getCdTimeType());
										long cdTime = -1;
										if (clothCdTime != null) {
											cdTime = clothCdTime.getCdTime();
										}
										player.getBags().addItem(reward.getRewardId(), reward.getRewardCounts(),
												"finishQuest", cdTime);
									}
									RewardItem rewardItem = new RewardItem();
									rewardItem.setRewardType(reward.getRewardType());
									rewardItem.setRewardId(reward.getRewardId());
									rewardItem.setCount(reward.getRewardCounts());
									rewardItems.add(rewardItem);
								}
							}
							groupReward.setRewards(rewardItems);
							groupRewards.add(groupReward);
						}
					}
				}
			}
		}

		boolean flag = true;
		for (Integer groupId : resultConditionMap.keys()) {
			if (groupId != null) {
				if (!conditionIds.contains(groupId)) {
					flag = false;
					break;
				}
			}
		}
		if (conditionIds.size() == 0) {
			flag = false;
		}
		if (flag) {
			questService.finishQuest(player, playerQuest, PlayerQuest.FINISHED,quest.getCategory());
			player.getPool().setInt(Const.PROPERTY_CONTINU_SUCCESS_FINISH_QUEST_COUNTS,
					player.getPool().getInt(Const.PROPERTY_CONTINU_SUCCESS_FINISH_QUEST_COUNTS) + 1);
			player.getPool().setInt(Const.PROPERTY_STAR_QUEST_COUNT + "_" + quest.getHardType(),
					player.getPool().getInt(Const.PROPERTY_STAR_QUEST_COUNT + "_" + quest.getHardType()) + 1);
		}

		if (quest.getHeartReward() == 1) {
			HeartBeat heartBeat = questService.getHeartBeat(requestMessage.getHeartCounts());
			if (heartBeat != null) {
				PlayerTransaction tx = player.newTransaction("finishQuest");
				player.addAttributeByType(AttributeType.getAttrtType(heartBeat.getCurrencyType()),
						heartBeat.getCurrencyCounts(), tx);
				tx.commit();
				message.setHeartGold(heartBeat.getCurrencyCounts());
			}
		}

		if (requestMessage.getClothLevel() == QuestService.CLOTH_MAX_LEVEL) {
			DropRate dropRate = questService.getDropRate(player.getPool().getInt(Const.PROPERTY_GAIN_CLOTH_COUNTS));
			if (dropRate != null) {
				Random rand = new Random();
				int w = rand.nextInt(100);
				int itemId = player.getPool().getInt(Const.PROPERTY_LAST_RANDOM_BIKINI_ID);
				if (w < dropRate.getWeight() && itemId != 0) {
					GameItem gameItem = player.getBags().getBag(Const.BAG_EQUIP).getGameItemById(itemId);
					if (gameItem == null) {
						player.getBags().addItem(itemId, 1, "finishQuest");
						player.getPool().setInt(Const.PROPERTY_GAIN_CLOTH_COUNTS,
								player.getPool().getInt(Const.PROPERTY_GAIN_CLOTH_COUNTS) + 1);
						message.setUnLockCloth(1);
					} else {
						PlayDropItem dropItem = questService.getPlayDropItem(PlayDropType.DROP_ITEM.getType(), itemId);
						if (dropItem != null) {
							PlayerTransaction tx = player.newTransaction("finishQuest");
							player.addAttributeByType(AttributeType.getAttrtType(dropItem.getCurrencyType()),
									dropItem.getCurrencyCounts(), tx);
							tx.commit();
							message.setClothCurrencyType(dropItem.getCurrencyType());
							message.setClothCurrencyCounts(dropItem.getCurrencyCounts());
						}
					}
					message.setClothId(itemId);
				}
			}
		}

		if (requestMessage.getActionLevel() == QuestService.ACTION_MAX_LEVEL) {
			DropRate dropRate = questService.getDropRate(player.getPool().getInt(Const.PROPERTY_GAIN_ACTION_COUNTS));
			if (dropRate != null) {
				Random rand = new Random();
				int w = rand.nextInt(100);
				int itemId = questService.randomBiKiNiOrActionId(PlayDropType.DROP_ACTION.getType());
				if (w < dropRate.getWeight() && itemId != 0) {
					GameItem gameItem = player.getBags().getBag(Const.BAG_ACTION).getGameItemById(itemId);
					if (gameItem == null) {
						player.getBags().addItem(itemId, 1, "finishQuest");
						player.getPool().setInt(Const.PROPERTY_GAIN_ACTION_COUNTS,
								player.getPool().getInt(Const.PROPERTY_GAIN_ACTION_COUNTS) + 1);
						message.setUnLockAction(1);
					} else {
						PlayDropItem dropItem = questService.getPlayDropItem(PlayDropType.DROP_ACTION.getType(),
								itemId);
						if (dropItem != null) {
							PlayerTransaction tx = player.newTransaction("finishQuest");
							player.addAttributeByType(AttributeType.getAttrtType(dropItem.getCurrencyType()),
									dropItem.getCurrencyCounts(), tx);
							tx.commit();
							message.setEffectCurrencyType(dropItem.getCurrencyType());
							message.setEffectCurrencyCounts(dropItem.getCurrencyCounts());
						}
					}
					message.setActionId(itemId);
				}
			}
		}

		if (requestMessage.getMoodLevel() == QuestService.MOOD_MAX_LEVEL) {
			DropRate dropRate = questService.getDropRate(player.getPool().getInt(Const.PROPERTY_GAIN_EFFECT_COUNTS));
			if (dropRate != null) {
				Random rand = new Random();
				int w = rand.nextInt(100);
				int itemId = questService.randomBiKiNiOrActionId(PlayDropType.DROP_EFFECT.getType());
				if (w < dropRate.getWeight() && itemId != 0) {
					GameItem gameItem = player.getBags().getBag(Const.BAG_EFFECT).getGameItemById(itemId);
					if (gameItem == null) {
						player.getBags().addItem(itemId, 1, "finishQuest");
						player.getPool().setInt(Const.PROPERTY_GAIN_EFFECT_COUNTS,
								player.getPool().getInt(Const.PROPERTY_GAIN_EFFECT_COUNTS) + 1);
						message.setUnLockEffect(1);
					} else {
						PlayDropItem dropItem = questService.getPlayDropItem(PlayDropType.DROP_EFFECT.getType(),
								itemId);
						if (dropItem != null) {
							PlayerTransaction tx = player.newTransaction("finishQuest");
							player.addAttributeByType(AttributeType.getAttrtType(dropItem.getCurrencyType()),
									dropItem.getCurrencyCounts(), tx);
							tx.commit();
							message.setEffectCurrencyType(dropItem.getCurrencyType());
							message.setEffectCurrencyCounts(dropItem.getCurrencyCounts());
						}
					}
					message.setEffectId(itemId);
				}
			}
		}

		if (requestMessage.getXieZhenType() != 0) {
			Random rand = new Random();
			int weight = rand.nextInt(100);
			if (weight < 50) {
				XieZhenReward reward = questService.xieZhenRewards.get(requestMessage.getXieZhenType());
				if (reward != null) {
					Gain gain = grouDropService.groupDrop(player, reward.getDropGroupId(), "finishQuest");
					if (gain != null) {
						List<GainEntry> gainEntryList = gain.getGainEntrys();
						for (GainEntry gainEntry : gainEntryList) {
							if (gainEntry != null) {
								if (gainEntry instanceof GameItemGainEntry) {
									GameItemGainEntry itenEntry = (GameItemGainEntry) gainEntry;
									message.setXieZhenId(itenEntry.getItem().getTemplate().getId());
									eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_GAIN_ITEM, player,
											itenEntry.getItem().getTemplate().getId()));
									break;
								}
							}
						}
					}
				} else {
					// 被篡改消息了
				}
			}
		}
		/** 结算拍照奖励 */
		TIntObjectHashMap<QuestFinishPhotoReward> reward = questService.getPhotoReward();
		List<QualityReward> qualityList = requestMessage.getQualityType();
		int totalReward = 0;
		for (QualityReward quality : qualityList) {
			if (quality.getCount() != 0) {
				QuestFinishPhotoReward photoReward = reward.get(quality.getQuality());
				totalReward += getReward(photoReward, player, quality.getCount());
			}
		}
		message.setTotalPhotoReward(totalReward);
		List<BubbleRewardItem> bubbleRewardItems = bubbleReward(player, requestMessage.getBubbleRewards());
		message.setBubbleRewards(bubbleRewardItems);
		message.setGroupReward(groupRewards);
		if(flag) {
			message.setQuestState(PlayerQuest.FINISHED);
		}
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
		playerService.updatePlayer(player);
		if (requestMessage.getTakePhotoCount() > 0) {
			eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_USE_GIRL_TAKE_PHOTE, player,
					requestMessage.getTakePhotoCount()));
		}
		eventManager
				.addEvent(new ServiceEvent(ServiceEvent.EVENT_FINISH_QUEST, player, requestMessage.getHeartCounts()));
	}

	/**
	 * 发放汽泡奖励
	 * 
	 * @return
	 */
	public List<BubbleRewardItem> bubbleReward(Player player, List<BubbleReward> rewards) {
		if (rewards != null && rewards.size() > 0) {
			TIntObjectHashMap<TIntObjectHashMap<BubbleRewardItem>> bubbles = new TIntObjectHashMap<>();
			for (BubbleReward bubbleReward : rewards) {
				if (bubbleReward != null) {
					Bubble bubble = questService.bubbles.get(bubbleReward.getBubbleId());
					if (bubble != null && bubble.getBubbleType() != BubbleType.BOMB.getBubbleType()) {
						TIntObjectHashMap<BubbleRewardItem> map = bubbles.get(Const.REWARD_CURRENCY);
						if (bubble.getBubbleType() == BubbleType.CURRENCY.getBubbleType()) {
							PlayerTransaction tx = player.newTransaction("bubbleReward");
							player.addAttributeByType(AttributeType.getAttrtType(bubble.getRewardId()),
									bubble.getValue(), tx);
							tx.commit();
							if(map == null) {
								map = new TIntObjectHashMap<>();
								bubbles.put(Const.REWARD_CURRENCY, map);
							}
							BubbleRewardItem rewardItem = map.get(bubble.getRewardId());
							if (rewardItem == null) {
								rewardItem = new BubbleRewardItem();
								rewardItem.setRewardType(Const.REWARD_CURRENCY);
								rewardItem.setRewardId(bubble.getRewardId());
								map.put(bubble.getRewardId(), rewardItem);
							}
							rewardItem.setCounts(rewardItem.getCounts() + bubble.getValue());
						} else if (bubble.getBubbleType() == BubbleType.GIFT.getBubbleType()) {

						}
					}
				}
			}
			return getBubbleRewardItems(bubbles);
		}
		return null;
	}

	private List<BubbleRewardItem> getBubbleRewardItems(
			TIntObjectHashMap<TIntObjectHashMap<BubbleRewardItem>> bubbles) {
		List<BubbleRewardItem> list = new ArrayList<>();
		for (TIntObjectHashMap<BubbleRewardItem> map : bubbles.valueCollection()) {
			if (map != null && map.size() > 0) {
				for (BubbleRewardItem reward : map.valueCollection()) {
					if (reward != null) {
						list.add(reward);
					}
				}
			}
		}
		return list;
	}

	/**
	 * 结算拍照奖励
	 * 
	 * @param reward
	 * @param player
	 */
	private int getReward(QuestFinishPhotoReward reward, Player player, int count) {
		List<Integer> rewardIds = DateUtil.StringToList(reward.getRewardId());
		List<Integer> rewardNum = DateUtil.StringToList(reward.getRewardNum());
		int totalReward = 0;
		do {
			for (int i = 0; i < rewardIds.size(); i++) {
				int itemType = rewardIds.get(i);
				if (itemType == AttributeType.GOLD.getAttributeType()
						|| itemType == AttributeType.MONEY.getAttributeType()) {
					PlayerTransaction tx = player.newTransaction("任务结束后拍摄照片奖励");
					player.addAttributeByType(AttributeType.getAttrtType(itemType), rewardNum.get(i), tx);
					tx.commit();
					totalReward += rewardNum.get(i);
				} else {
					player.getBags().addItem(rewardIds.get(i), rewardNum.get(i), "任务结束后拍摄照片奖励", -1);
				}
			}
			count--;
		} while (count > 0);
		return totalReward;
	}
}
