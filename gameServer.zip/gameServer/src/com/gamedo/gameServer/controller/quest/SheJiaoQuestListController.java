package com.gamedo.gameServer.controller.quest;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.PlayerQuestData;
import com.gamedo.gameServer.message.quest.QuestListResponseMessage;
import com.gamedo.gameServer.message.quest.SheJiaoQuestData;
import com.gamedo.gameServer.message.quest.SheJiaoQuestListResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;

/**
 * 获取社交任务列表
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.SHE_JIAO_QUEST_LIST)
public class SheJiaoQuestListController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private QuestService questService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		Packet packet = new Packet(OpCode.SHE_JIAO_QUEST_LIST, request, response);

		CommonRequestMessage requestMessage = (CommonRequestMessage) packet
				.getRequestMessage(CommonRequestMessage.class);

		SheJiaoQuestListResponseMessage responseMessage = new SheJiaoQuestListResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		
		List<SheJiaoQuestData> questDatas = questService.getPlayerSheJiaoQuestDatas(player);
		responseMessage.setCode(CommonResponseMessage.TRUE);
		responseMessage.setQuestDatas(questDatas);
		packet.send(responseMessage);
	}

}
