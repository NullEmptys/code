package com.gamedo.gameServer.controller.quest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.constant.PlayDropType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.quest.Quest;
import com.gamedo.gameServer.data.scene.Scene;
import com.gamedo.gameServer.entity.girl.FreeGirlRecord;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.entity.quest.PlayerQuest;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.quest.QuestStartRequestMessage;
import com.gamedo.gameServer.message.quest.QuestStartResponseMessage;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;
import com.gamedo.gameServer.service.scene.SceneService;
import com.gamedo.gameServer.util.Const;

/**
 * 任务开始
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.QUEST_START)
public class QuestStartController extends AbstractController {

	@Autowired
	private QuestService questService;
	@Autowired
	private PlayerService playerService;
	@Autowired
	private GirlService girlService;
	@Autowired
	private SceneService sceneService;
	@Autowired
	private EventManager eventManager;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.QUEST_START, request, response);

		QuestStartRequestMessage requestMessage = (QuestStartRequestMessage) packet
				.getRequestMessage(QuestStartRequestMessage.class);

		QuestStartResponseMessage message = new QuestStartResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		Quest quest = questService.getQuestById(requestMessage.getQuestId());
		if (quest == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}

		PlayerQuest playerQuest = questService.getPlayerQuestById(player.getId(), requestMessage.getQuestId());
		if (playerQuest == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_QUEST);
			packet.send(message);
			return;
		}

		if(quest.getCanRepeat() == 0) {
			if (playerQuest.getState() == PlayerQuest.FINISHED) {
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.QUEST_IS_FINISHED);
				packet.send(message);
				return;
			}
		}

		PlayerGirl playerGirl = girlService.getPlayerGirl(player.getId(), requestMessage.getGirlId());
		if (playerGirl == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.QUEST_IS_FINISHED);
			packet.send(message);
			return;
		}
		FreeGirlRecord freeGirl = girlService.getFreeGirlRecord();
		if(freeGirl.getGirlId() != playerGirl.getGirlId()) {
			if (playerGirl.getCdTime() != -1) {
				if (playerGirl.getCdTime() == 0 || System.currentTimeMillis() > playerGirl.getCdTime()) {
					message.setCode(CommonResponseMessage.FALSE);
					message.setDesc(I18NMessage.GIRL_SIGN_OUT_OF_TIME);
					packet.send(message);
					return;
				}
			}
		}

		PlayerTransaction tx = player.newTransaction("questStart");
		try {
			player.decTiLi(quest.getConsumeTili(), tx, false);
			message.setCode(CommonResponseMessage.TRUE);
		} catch (NoEnoughValueException e) {
			e.printStackTrace();
			tx.rollback();
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_ENOUGH_TILI);
			packet.send(message);
			return;
		}
		Scene scene = sceneService.getSceneById(requestMessage.getSceneId());
		if (scene == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.SCENE_NOT_FOUND);
			packet.send(message);
			return;
		}
		if(requestMessage.getReShot() == 0) {
			PlayerTransaction currencytx = player.newTransaction("questStart");
			if (scene.getIsFree() == 0) {
				try {
					player.decCurrency(AttributeType.getAttrtType(scene.getCurrencyType()), scene.getCurrencuCounts(),
							currencytx, false);
					currencytx.commit();
				} catch (NoEnoughValueException e) {
					e.printStackTrace();
					currencytx.rollback();
					tx.rollback();
					message.setCode(CommonResponseMessage.FALSE);
					message.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
					packet.send(message);
					return;
				}
			}
		}
		
		tx.commit();
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		int biKiNiId = questService.randomBiKiNiOrActionId(PlayDropType.DROP_ITEM.getType());
		if (biKiNiId != 0) {
			player.getPool().setInt(Const.PROPERTY_LAST_RANDOM_BIKINI_ID, biKiNiId);
			message.setBikiniId(biKiNiId);
		}
		message.setBikiniId(biKiNiId);

		player.getPool().setInt(Const.PROPERTY_START_QUEST_COUNTS,
				player.getPool().getInt(Const.PROPERTY_START_QUEST_COUNTS) + 1);
		player.getPool().setInt(Const.PROPERTY_USE_GIRL_COUNTS + "_" + requestMessage.getGirlId(),
				player.getPool().getInt(Const.PROPERTY_USE_GIRL_COUNTS + "_" + requestMessage.getGirlId()) + 1);
		player.getPool().setInt(Const.PROPERTY_USE_SCENE_COUNT + "_" + scene.getAttribute(),
				player.getPool().getInt(Const.PROPERTY_USE_SCENE_COUNT + "_" + scene.getAttribute()) + 1);
		
		playerService.updatePlayer(player);

		eventManager
				.addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_START_QUEST,player, requestMessage.getGirlId()));
		packet.send(message);
	}

}
