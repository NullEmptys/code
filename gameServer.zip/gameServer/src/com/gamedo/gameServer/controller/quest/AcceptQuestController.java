package com.gamedo.gameServer.controller.quest;

import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.data.quest.Quest;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.quest.PlayerQuest;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.quest.AcceptQuestRequestMessage;
import com.gamedo.gameServer.message.quest.AcceptQuestResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;

/**
 * 领取任务
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.ACCEPT_QUEST)
public class AcceptQuestController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private QuestService questService;
	@Autowired
	private EventManager eventManager;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.ACCEPT_QUEST, request, response);

		AcceptQuestRequestMessage requestMessage = (AcceptQuestRequestMessage) packet
				.getRequestMessage(AcceptQuestRequestMessage.class);
		
		AcceptQuestResponseMessage message = new AcceptQuestResponseMessage();
		
		Player player = playerService.getPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		Quest quest = questService.getQuestById(requestMessage.getQuestId());
		if (quest == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		
//		PlayerQuest playerQuest = questService.getPlayerQuestById(player.getId(), requestMessage.getQuestId());
//		if (playerQuest != null) {
//			message.setCode(CommonResponseMessage.FALSE);
//			message.setDesc(I18NMessage.QUEST_ACCEPTED);
//			packet.send(message);
//			return;
//		}
		
		PlayerQuest playerQuest = new PlayerQuest();
		playerQuest.setQuestId(quest.getId());
		playerQuest.setPlayerId(player.getId());
		playerQuest.setCategory(quest.getCategory());
		if(quest.getEndTime() != null) {
			playerQuest.setEndTime(quest.getEndTime());
		}
		playerQuest.setMsgId(requestMessage.getMsgId());
		questService.insertPlayerQuest(playerQuest);
		
		ConcurrentHashMap<Integer, ConcurrentHashMap<Integer,PlayerQuest>> playerQuests = questService.getPlayerQuests(player.getId());
		ConcurrentHashMap<Integer,PlayerQuest> map = playerQuests.get(quest.getCategory());
		if(map == null) {
			map = new ConcurrentHashMap<>();
			playerQuests.put(quest.getCategory(), map);
		}
		map.put(playerQuest.getQuestId(), playerQuest);
		questService.addPlayerQuestToCache(player.getId(), playerQuests);
		
		eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_INVOLEVMENT_SOCIAL_MISSION, player));
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setState(playerQuest.getState());
		message.setQuestId(playerQuest.getQuestId());
		packet.send(message);
	}

}
