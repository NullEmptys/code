package com.gamedo.gameServer.controller.quest;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.quest.QuestFinishPhotoReward;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.quest.PlayerQuest;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.quest.QualityReward;
import com.gamedo.gameServer.message.quest.QuestFinishTakePhotoRequestMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;
import com.gamedo.gameServer.util.DateUtil;

import gnu.trove.map.hash.TIntObjectHashMap;
/**
 * 任务结束结算拍照兑换的货币数
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = OpCode.QUEST_FINISH_PHOTO_REWARD)
public class QuestFinishQuestPhotoRewardController extends AbstractController{

	@Autowired
	private PlayerService playerService;
	@Autowired
	private QuestService questService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		Packet packet = new Packet(OpCode.QUEST_FINISH_PHOTO_REWARD, request, response);
		QuestFinishTakePhotoRequestMessage requestMessage = (QuestFinishTakePhotoRequestMessage) packet
				.getRequestMessage(QuestFinishTakePhotoRequestMessage.class);
		
		CommonResponseMessage responseMessage = new CommonResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		PlayerQuest playerQuest = questService.getPlayerQuestById(player.getId(), requestMessage.getQuestId());
		if(playerQuest == null || playerQuest.getState() == PlayerQuest.FINISHED){
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.DAILY_MISSION_NOT_GET);
			packet.send(responseMessage);
			return;
		}
		TIntObjectHashMap<QuestFinishPhotoReward> reward = questService.getPhotoReward();
		List<QualityReward> qualityList = requestMessage.getQualityType();
		for(QualityReward quality : qualityList){
			QuestFinishPhotoReward photoReward = reward.get(quality.getQuality());
			getReward(photoReward,player);
		}
		responseMessage.setCode(CommonResponseMessage.TRUE);
		packet.send(responseMessage);
	}
	
	private void getReward(QuestFinishPhotoReward reward,Player player){
//		List<Integer> rewardType = DateUtil.StringToList(reward.getRewardType());
		List<Integer> rewardIds = DateUtil.StringToList(reward.getRewardId());
		List<Integer> rewardNum = DateUtil.StringToList(reward.getRewardNum());
		for(int i=0;i<rewardIds.size();i++){
			int itemType = rewardIds.get(i);
			if(itemType == AttributeType.GOLD.getAttributeType() || itemType == AttributeType.MONEY.getAttributeType()){
				PlayerTransaction tx = player.newTransaction("任务结束后拍摄照片奖励");
				player.addAttributeByType(AttributeType.getAttrtType(itemType), rewardNum.get(i), tx);
				tx.commit();
			}else{
				player.getBags().addItem(rewardIds.get(i), rewardNum.get(i), "任务结束后拍摄照片奖励",-1);
			}
		}
	}
}
