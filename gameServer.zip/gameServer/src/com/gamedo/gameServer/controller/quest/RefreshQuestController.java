package com.gamedo.gameServer.controller.quest;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.quest.QuestRefreshRequestMessage;
import com.gamedo.gameServer.message.quest.QuestRefreshResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;

/**
 * 刷新任务列表
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.QUEST_REFRESH)
public class RefreshQuestController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private QuestService questService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		Packet packet = new Packet(OpCode.QUEST_REFRESH, request, response);

		QuestRefreshRequestMessage requestMessage = (QuestRefreshRequestMessage) packet
				.getRequestMessage(QuestRefreshRequestMessage.class);
		
		QuestRefreshResponseMessage responseMessage = new QuestRefreshResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		
		int refreshCounts = questService.getRefreshCount(player);//玩家当日已刷新任务次数
		
		if(refreshCounts >= QuestService.maxRefreshCounts) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.QUEST_REFRESH_COUNT_NOT_EHOUGH);
			packet.send(responseMessage);
			return;
		}
		
		boolean canRefresh = false;
		if(!canRefresh) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.QUEST_NOT_ALLOWED_TO_REFRESH);
			packet.send(responseMessage);
			return;
		}
		
		questService.refreshGameQuest(player);
		
		questService.setRefreshCount(player, questService.getRefreshCount(player) + 1);
		
		responseMessage.setCode(CommonResponseMessage.TRUE);
		responseMessage.setRefreshCounts(questService.getRefreshCount(player));
		responseMessage.setQuests(null);
		responseMessage.setUpdateObj(playerService.sendAndClean(player.getId()));
		packet.send(responseMessage);
	}

}
