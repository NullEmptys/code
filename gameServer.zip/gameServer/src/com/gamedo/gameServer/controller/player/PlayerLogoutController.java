package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.PlayerLogoutRequestMessage;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 角色登出
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.PLAYER_LOGOUT)
public class PlayerLogoutController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.PLAYER_LOGOUT, request, response);
		
		CommonResponseMessage responseMessage = new CommonResponseMessage();
		
		PlayerLogoutRequestMessage requestMessage = (PlayerLogoutRequestMessage) packet
				.getRequestMessage(PlayerLogoutRequestMessage.class);
		int playerId = requestMessage.getPlayerID();
		Player player = playerService.getPlayerById(playerId);
		if(player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		
		playerService.playerLogout(player);
		responseMessage.setCode(CommonResponseMessage.TRUE);
		packet.send(responseMessage);
	}

	@RequestMapping(method = RequestMethod.GET)
	public void execute1(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.PLAYER_LOGOUT, request, response);
		
		CommonResponseMessage responseMessage = new CommonResponseMessage();
		
		int playerId = Integer.parseInt(request.getParameter("playerId"));
		Player player = playerService.getPlayerById(playerId);
		if(player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		playerService.playerLogout(player);
	}
}
