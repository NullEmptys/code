package com.gamedo.gameServer.controller.player;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.ChargeResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.update.UpdateObject;
import com.gamedo.gameServer.util.Const;

/**
 * 充值
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.CHARGE)
public class ChargeController extends AbstractController{

	@Autowired
	private PlayerService playerService;
	@Autowired
	private EventManager eventManager;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.CHARGE,request,response);
		CommonRequestMessage requestMessage = (CommonRequestMessage) packet.getRequestMessage(CommonRequestMessage.class);
		ChargeResponseMessage message = new ChargeResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		PlayerTransaction tx = player.newTransaction("charge");
		player.addMoney(1000, tx, false);
		if(player.getGold() < 100000000) {
			player.addGold(1000, tx, false);
		}
		tx.commit();
		
		eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_CHARGE, player,1000));
		
		List<UpdateObject> updates = playerService.sendAndClean(player.getId());
		playerService.updatePlayer(player);
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setUpdateObj(updates);
		
		packet.send(message);
	}

	@RequestMapping(method = RequestMethod.GET)
	public void execute1(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.CHARGE,request,response);
		String playerID = request.getParameter("playerID");
		ChargeResponseMessage message = new ChargeResponseMessage();
		Player player = playerService.loadPlayerById(Integer.parseInt(playerID));
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		PlayerTransaction tx = player.newTransaction("charge");
		player.addMoney(1000, tx, true);
		player.addGold(1000, tx, true);
		tx.commit();
		
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setUpdateObj(player.changed.sendAndClean());
		
		packet.send(message);
	}
}
