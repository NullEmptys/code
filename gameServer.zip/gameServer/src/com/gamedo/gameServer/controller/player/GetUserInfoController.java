package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.GetUserInfoResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 获取用户基本信息
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.GET_USER_INFO)
public class GetUserInfoController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.GET_USER_INFO,request,response);
		CommonRequestMessage requestMessage = (CommonRequestMessage) packet.getRequestMessage(CommonRequestMessage.class);
		
		GetUserInfoResponseMessage message = new GetUserInfoResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setPlayerId(player.getId());
		message.setPlayerName(player.getName());
		message.setMoney(player.getMoney());
		message.setAvatarUrl("");
		message.setPhotoFrameId("0");
		message.setPlayerType(player.getPlayerType());
		message.setGirlId(player.getGirlId());
		packet.send(message);
	}

}
