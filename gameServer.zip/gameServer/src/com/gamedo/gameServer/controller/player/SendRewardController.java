package com.gamedo.gameServer.controller.player;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.DefaultThreadPool;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.player.MailReward;
import com.gamedo.gameServer.message.player.SendRewardRequestMessage;

/**
 * 已邮件附件方式发放奖励
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.SEND_REWARD)
public class SendRewardController extends AbstractController {

	@Autowired
	private DefaultThreadPool threadPool;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.SEND_REWARD, request, response);
		SendRewardRequestMessage requestMessage = (SendRewardRequestMessage) packet
				.getRequestMessage(SendRewardRequestMessage.class);
		CommonResponseMessage message = new CommonResponseMessage();

		List<MailReward> rewards = requestMessage.getRewards();
		if(rewards != null && rewards.size() > 0) {
			SendRewardCall rewardCall = new SendRewardCall(rewards);
			threadPool.execute(rewardCall);
		}
		
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

}
