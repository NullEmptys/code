package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.girl.GirlMood;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.ResetPlayerGirlMoodRequestMessage;
import com.gamedo.gameServer.message.player.ResetPlayerGirlMoodResponseMessage;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 重置模特心情
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.RESET_PLAYERGIRL_MOOD)
public class ResetPlayerGirlMoodController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private GirlService girlService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.RESET_PLAYERGIRL_MOOD, request, response);
		ResetPlayerGirlMoodRequestMessage requestMessage = (ResetPlayerGirlMoodRequestMessage) packet
				.getRequestMessage(ResetPlayerGirlMoodRequestMessage.class);
		
		ResetPlayerGirlMoodResponseMessage message = new ResetPlayerGirlMoodResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		PlayerGirl playerGirl = girlService.getPlayerGirl(requestMessage.getPlayerID(), requestMessage.getGirlId());
		if(playerGirl == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.GIRL_NOT_FOUND);
			packet.send(message);
			return;
		}
		
		int resetCount = girlService.getPlayerResetGirlMoodCounts(player, requestMessage.getGirlId());
		if(resetCount >= GirlService.MAX_RESET_MOOD_COUNTS) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.RESET_GIRL_MOOD_MAXCOUNT);
			packet.send(message);
			return;
		}
		
		GirlMood girlMood = girlService.getGirlMood(requestMessage.getGirlId(), resetCount + 1);
		if(girlMood == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		PlayerTransaction tx = player.newTransaction("resetPlayerGirlMood");
		try {
			player.decCurrency(AttributeType.getAttrtType(girlMood.getCurrencyType()), girlMood.getCurrencyCounts(), tx, false);
			girlService.setPlayerGirlMoodCounts(player, requestMessage.getGirlId());
			tx.commit();
		} catch (NoEnoughValueException e) {
			e.printStackTrace();
			tx.rollback();
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
			packet.send(message);
			return;
		}
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setGirlId(playerGirl.getGirlId());
		message.setResetCount(girlService.getPlayerResetGirlMoodCounts(player, requestMessage.getGirlId()));
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		packet.send(message);
		
		playerService.updatePlayer(player);
	}

}
