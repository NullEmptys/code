package com.gamedo.gameServer.controller.player;

import java.util.List;

import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.item.ItemTemplate;
import com.gamedo.gameServer.entity.mail.ItemMailAttachment;
import com.gamedo.gameServer.entity.mail.MailAttachment;
import com.gamedo.gameServer.entity.mail.MoneyMailAttachment;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.message.player.AttachData;
import com.gamedo.gameServer.message.player.MailReward;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.mail.MailService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 
 * @author libm
 *
 */
public class SendRewardCall implements Runnable {

	private List<MailReward> rewards;
	
	public SendRewardCall(List<MailReward> rewards) {
		this.rewards = rewards;
	}
	
	@Override
	public void run() {
		if(rewards != null && rewards.size() > 0) {
			for(MailReward reward : rewards) {
				if(reward != null) {
					List<Integer> playerIds = reward.getPlayerIds();
					if(playerIds != null && playerIds.size() > 0) {
						for(Integer playerId : playerIds) {
							Player player = PlayerService.getInstance().getPlayerById(playerId);
							if(player != null) {
								List<AttachData> attachDatas = reward.getAttachDatas();
								if (attachDatas != null && attachDatas.size() > 0) {
									MailAttachment[] attachments = new MailAttachment[attachDatas.size()];
									for (int i = 0; i < attachDatas.size(); i++) {
										AttachData attachData = attachDatas.get(i);
										if (attachData != null) {
											if (attachData.getRewardType() == 1) {// 物品
												ItemTemplate template = ItemService.getInstance()
														.getItemTemplate(attachData.getRewardId());
												if (template != null) {
													GameItem item = ItemService.getInstance().createGameItem(template);
													ItemMailAttachment attach = new ItemMailAttachment(item,
															attachData.getRewardCounts(),attachData.getCdTime());
													attachments[i] = attach;
												}
											} else if (attachData.getRewardType() == 2) {// 货币
												MoneyMailAttachment attach = new MoneyMailAttachment(
														attachData.getRewardId(), attachData.getRewardCounts());
												attachments[i] = attach;
											}
										}
									}
									MailService.getInstance().sendSystemMail(player.getId(),reward.getSendName(), reward.getTitle(), reward.getContent(), attachments);
								}else {
									MailService.getInstance().sendSystemMail(reward.getSendName(),player.getId(), reward.getTitle(), reward.getContent());
								}
								PlayerService.getInstance().updatePlayer(player);
							}
						}
					}
				}
			}
		}
	}

}
