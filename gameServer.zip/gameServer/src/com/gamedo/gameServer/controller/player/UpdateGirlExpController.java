package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.UpdateGirlExpRequestMessage;
import com.gamedo.gameServer.message.player.UpdateGirlExpResponseMessage;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 模特升级
 * 
 * @author liuxing
 *
 */
@Controller
@RequestMapping(value = OpCode.UPDATE_GIRL_EXP)
public class UpdateGirlExpController extends AbstractController {
	@Autowired
	private GirlService girlService;
	@Autowired
	private PlayerService playerService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		this.updateGirlExp(request, response);
	}

	private void updateGirlExp(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.UPDATE_GIRL_EXP, request, response);
		UpdateGirlExpRequestMessage requestMessage = (UpdateGirlExpRequestMessage) packet
				.getRequestMessage(UpdateGirlExpRequestMessage.class);
		UpdateGirlExpResponseMessage message = new UpdateGirlExpResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		PlayerGirl playerGirl;
		playerGirl = girlService.updateGirlExp(requestMessage.getPlayerID(), requestMessage.getGirlId(),
				requestMessage.getExp());
		message.setCode(CommonResponseMessage.TRUE);
		message.setGirlData(girlService.getPlayerGirlData(player, playerGirl));
		message.setUpdateObj(playerService.sendAndClean(requestMessage.getPlayerID()));// 返回玩家变化数据
		packet.send(message);
	}

}
