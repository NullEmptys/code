package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.PayRequestMessage;
import com.gamedo.gameServer.message.player.PayResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 消费接口
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.PAY)
public class PayController extends AbstractController {

	@Autowired
	private PlayerService playerService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		Packet packet = new Packet(OpCode.PAY, request, response);

		PayRequestMessage requestMessage = (PayRequestMessage) packet.getRequestMessage(PayRequestMessage.class);
	
		PayResponseMessage message = new PayResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		PlayerTransaction tx = player.newTransaction("后援团投票");
		try {
			player.decCurrency(AttributeType.getAttrtType(requestMessage.getCurrencyType()), requestMessage.getCount(), tx, false);
			tx.commit();
			message.setCode(CommonResponseMessage.TRUE);
			message.setCurrencyType(requestMessage.getCurrencyType());
			message.setCount(player.getAttributeByType(requestMessage.getCurrencyType()));
			packet.send(message);
		} catch (NoEnoughValueException e) {
			e.printStackTrace();
			tx.rollback();
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
			packet.send(message);
			return;
		}
	}

}
