package com.gamedo.gameServer.controller.player;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.EquipType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.item.Equipment;
import com.gamedo.gameServer.core.item.EquipmentsEx;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.girl.GirlPartCloth;
import com.gamedo.gameServer.message.girl.PlayTypeClothData;
import com.gamedo.gameServer.message.girl.SaveGirlEquipsRequestMessage;
import com.gamedo.gameServer.message.girl.TypeClothData;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

/**
 * 保存玩家指定模特当前所穿服装
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.SAVE_GIRL_CLOTH)
public class SaveGirlEquipsControler extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private GirlService girlService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.SAVE_GIRL_CLOTH, request, response);
		
		SaveGirlEquipsRequestMessage requestMessage = (SaveGirlEquipsRequestMessage) packet
				.getRequestMessage(SaveGirlEquipsRequestMessage.class);
		
		CommonResponseMessage message = new CommonResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		PlayerGirl playerGirl = girlService.getPlayerGirl(requestMessage.getPlayerID(), requestMessage.getGirlId());
		if(playerGirl == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.GIRL_NOT_FOUND);
			packet.send(message);
			return;
		}
		
		List<PlayTypeClothData> playTypeCloths = requestMessage.getPlayTypeClothData();
		if(playTypeCloths != null && playTypeCloths.size() > 0) {
			for(PlayTypeClothData playTypeClothData : playTypeCloths) {
				List<TypeClothData> typeCloths = playTypeClothData.getTypeClothData();
				if(typeCloths != null && typeCloths.size() > 0) {
					for(TypeClothData typeClothData : typeCloths) {
						List<GirlPartCloth> partCloths = typeClothData.getGirlPartCloth();
						if(partCloths != null && partCloths.size() > 0) {
							EquipmentsEx equipmentEx = (EquipmentsEx) playerGirl.getEquipments().get(playTypeClothData.getPlayType());
							for(EquipType equipType : EquipType.values()) {
								if(equipType != null) {
									boolean flag = false;
									Equipment unEquipment = equipmentEx.getEquipment(typeClothData.getType(), equipType.getClothType());
									for(GirlPartCloth partCloth : partCloths) {
										if(partCloth != null && equipType.getClothType() == partCloth.getPart()) {
//											BagGrid bagGrid = playerGirl.getBags().getBag(Const.BAG_EQUIP).getGameItem(partCloth.getClothId());
//											if(bagGrid != null) {
												Equipment eqiup = (Equipment) playerGirl.getBags().getBag(Const.BAG_EQUIP).getGameItemById(partCloth.getClothId());
												if(eqiup != null) {
													flag = true;
													if(unEquipment != null && eqiup.getTemplate().getId() != unEquipment.getTemplate().getId()) {
														equipmentEx.equ(typeClothData.getType(), partCloth.getPart(), eqiup, unEquipment);
													}else {
														equipmentEx.equ(typeClothData.getType(), partCloth.getPart(), eqiup, null);
													}
												}
												break;
//											}
										}
									}
									if(!flag && unEquipment != null) {
										equipmentEx.unEqu(typeClothData.getType(),equipType.getClothType());
									}
								}
							}
						}
					}
				}
			}
		}
		girlService.updatePlayerGirl(playerGirl);
		message.setCode(CommonResponseMessage.TRUE);
		message.setUpdateObj(playerService.sendAndClean(player.getId()));
		packet.send(message);
		playerService.updatePlayer(player);
		
	}

}
