package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.GirlSignType;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.exception.GirlSignedException;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.GirlSignedRequestMessage;
import com.gamedo.gameServer.message.player.GirlSignedResponseMessage;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 模特续签
 * 
 * @author liuxing
 *
 */
@Controller
@RequestMapping(value = OpCode.GIRL_SIGNED)
public class GirlSignedController extends AbstractController {
	@Autowired
	private GirlService girlService;
	@Autowired
	private PlayerService playerService;
	@Autowired
	private EventManager eventManager;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		this.girlSigned(request, response);
	}

	private void girlSigned(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.GIRL_SIGNED, request, response);
		GirlSignedRequestMessage requestMessage = (GirlSignedRequestMessage) packet
				.getRequestMessage(GirlSignedRequestMessage.class);
		GirlSignedResponseMessage message = new GirlSignedResponseMessage();
		PlayerGirl playerGirl;
		
		Player player = playerService.getPlayerById(requestMessage.getPlayerID());
		if(player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		PlayerTransaction tx = player.newTransaction("playerGirlSign");
		try {
			
			playerGirl = girlService.getPlayerGirl(requestMessage.getPlayerID(), requestMessage.getGirlId());
			if(playerGirl == null) {
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.GIRL_NOT_FOUND);
				packet.send(message);
				return;
			}
			
			if(playerGirl.getCdTime() == -1) {
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.GIRL_IS_PERMANET);
				packet.send(message);
				return;
			}
			
			GirlSignType girlSignType = girlService.getGirlSignType(requestMessage.getGirlId(), requestMessage.getType());
			if(girlSignType == null) {
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.DATA_EXCEPTION);
				packet.send(message);
				return;
			}
			
			player.decCurrency(AttributeType.getAttrtType(girlSignType.getCurrencyType()), girlSignType.getCurrencyCounts(), tx, false);
			tx.commit();
			playerGirl = girlService.girlSigned(requestMessage.getPlayerID(), requestMessage.getGirlId(),
					requestMessage.getType());
			message.setCode(CommonResponseMessage.TRUE);
			message.setGirlData(girlService.getPlayerGirlData(player,playerGirl));
			message.setUpdateObj(playerService.sendAndClean(player.getId()));
			playerService.updatePlayer(player);
			
			int signGirlCounts = girlService.getplayerSignGirlCounts(player);
			int signForeverGirlCounts = girlService.getPlayerSignForeverGirlCounts(player);
			eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_SIGN_GIRL,player, signGirlCounts,signForeverGirlCounts));
			
		} catch (GirlSignedException e) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.GIRL_SIGNED_FAILED);
		} catch (NoEnoughValueException e) {
			tx.rollback();
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
		}
		packet.send(message);
	}

}
