package com.gamedo.gameServer.controller.player;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.DateUtil;

@Controller
@RequestMapping(value = OpCode.UPLOAD_CHECK)
public class UploadAvatarCheckController extends AbstractController{

	@Autowired
	private PlayerService playerService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.UPLOAD_AVATAR, request, response);
		CommonRequestMessage requestMessage = (CommonRequestMessage) packet
				.getRequestMessage(CommonRequestMessage.class);
		CommonResponseMessage message = new CommonResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		if (player.getAvatarUrl() == null) {
			message.setCode(CommonResponseMessage.TRUE);
			packet.send(message);
			return;
		}
		String[] loadInfo = player.getAvatarUrl().split(";");
		if (!DateUtil.isSameDay(DateUtil.getDateTimeByString(loadInfo[1]), new Date())) {
			message.setCode(CommonResponseMessage.TRUE);
			packet.send(message);
			return;
		}
		message.setCode(CommonResponseMessage.FALSE);
		message.setDesc(I18NMessage.NEXT_DAY_AGAIN);
		packet.send(message);
	}
	
}
