package com.gamedo.gameServer.controller.player;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.activity.ActivityService;
import com.gamedo.gameServer.constant.AccountStatus;
import com.gamedo.gameServer.constant.ChannelType;
import com.gamedo.gameServer.constant.Constants;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.Time;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.data.AppOpenConfig;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.PlayerLoginRequestMessage;
import com.gamedo.gameServer.message.player.PlayerLoginResponseMessage;
import com.gamedo.gameServer.service.achievement.AchievementService;
import com.gamedo.gameServer.service.announcement.AnnouncementService;
import com.gamedo.gameServer.service.dailymission.DailyMissionService;
import com.gamedo.gameServer.service.data.DataService;
import com.gamedo.gameServer.service.mail.MailService;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.serverinfo.ServerInfoConfigService;
import com.gamedo.gameServer.util.Const;

/**
 * 角色登陆
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.PLAYER_LOGIN)
public class PlayerLoginController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private GirlService girlService;
	@Autowired
	private EventManager eventManager;
	@Autowired
	private ActivityService activityService;
	@Autowired
	private AnnouncementService announcementService;
	@Autowired
	private DailyMissionService dailyMissionService;
	@Autowired
	private MailService mailService;
	@Autowired
	private AchievementService achievementService;
	@Autowired
	private ServerInfoConfigService serverInfoConfigService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		Packet packet = new Packet(OpCode.PLAYER_LOGIN, request, response);

		PlayerLoginResponseMessage resMessage = new PlayerLoginResponseMessage();

		PlayerLoginRequestMessage requestMessage = (PlayerLoginRequestMessage) packet
				.getRequestMessage(PlayerLoginRequestMessage.class);

		String username = requestMessage.getUserName();
		//String passward = requestMessage.getPassward();
		
		ChannelType channelType = ChannelType.getChannelType(requestMessage.getChannelId());
		if(channelType == null) {
			resMessage.setCode(CommonResponseMessage.FALSE);
			resMessage.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(resMessage);
			return;
		}
		
		Map<String,Integer> redPointDataMap = new HashMap<String,Integer>();
		List<Integer> mainPageList = new ArrayList<>();

		if (username != null && !"".equals(username)) {
			// TODO 认证账号

			Player player = playerService.getPlayerByAccountName(username,requestMessage.getChannelId());
			if(player == null) {
				String playerName = playerService.randPlayerName();
				player = playerService.createPlayer(username, playerName, 0, requestMessage.getChannelId(),requestMessage.getSubChannelId());
				player.setRegistIp(packet.getIpAddr());
			}
			if (player != null) {
				if(player.getState() == AccountStatus.FORBIT_LOGIN.getId()){
					if(player.getStateCdTime() != null){
						if((new Date()).before(player.getStateCdTime())){
							resMessage.setCode(CommonResponseMessage.FALSE);
							resMessage.setDesc(I18NMessage.PLAYER_FORBIT_LOGIN);
							packet.send(resMessage);
							return;
						}
					}else {
						resMessage.setCode(CommonResponseMessage.FALSE);
						resMessage.setDesc(I18NMessage.PLAYER_FORBIT_LOGIN);
						packet.send(resMessage);
						return;
					}
				}
				player.setLastOperateTime(System.currentTimeMillis());
				player.resetValueOnday();
				player.setLastLoginDay(Time.day);
				player.setLastLoginTime(new Date());
				player.setLastLoginIp(packet.getIpAddr());
				player.setTotalLoginCounts(player.getTotalLoginCounts() + 1);
				player.getPool().setString(Const.PROPERTY_LAST_LOGIN_TOKEN, playerService.randToken());
				playerService.playerLogin(player);
				playerService.updatePlayer(player);
				dailyMissionService.resetDailyMissions(player);
				
				eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_LOGINED, player));
				
				resMessage.setCode(CommonResponseMessage.TRUE);
				resMessage.setCurrentTime(System.currentTimeMillis());// 当前服务器时间
				resMessage.setBaseData(player.getPlayerBaseData());// 角色基础数据
				resMessage.setBagData(player.getPlayerBagData()); // 角色背包数据
				resMessage.setGirlData(girlService.getPlayerGirlDatas(player));// 模特数据
				resMessage.setEngagementData(player.getEngagementData());//约会数据
				resMessage.setNewEngagementData(player.getNewEngagementData());//新约会数据
				resMessage.setSevenLoginRewardData(activityService.getSevenLoginRewardData(player));//7日签到活动
				resMessage.setAnnouncements(announcementService.getAnnouncementData());//公告数据
				redPointDataMap.put("dailyMission", dailyMissionService.redPointView(player));//每日任务红点数据
				redPointDataMap.put("mail", mailService.getMailRed(player));//邮件红点
				resMessage.setCookie(serverInfoConfigService.getRouteId());
				redPointDataMap.put("engagement", player.getPool().getInt(Const.PROPERTY_ENGAGEMENT_GIRL_ID)==0?1:0);//约会红点
				resMessage.setRedPointData(redPointDataMap);
				resMessage.setAchievementMap(achievementService.getAchievementRedPoint(player));//成就红点数据
				if(player.getAvatarUrl() == null) {
					resMessage.setAvrtarUrl("");
				}else {
					String avatarUrl = DataService.getInstance().uploadConfig.getAvatarUrl() + (player.getAvatarUrl().split(";")[0]);
					resMessage.setAvrtarUrl(avatarUrl);
				}
				resMessage.setToken(player.getPool().getString(Const.PROPERTY_LAST_LOGIN_TOKEN));
				resMessage.setSubmitBugOrder( Constants.COMMITBUGCOUNT - player.getPool().getInt(Const.COMMIT_BUG));
				Map<Integer,AppOpenConfig> appConfig = serverInfoConfigService.getAppOpenMap();
				for(AppOpenConfig appOpen : appConfig.values()){
					mainPageList.add(appOpen.getFlag());
				}
				if(appConfig != null){
					AppOpenConfig openData = appConfig.get(9);//新手引导
					if(openData.getFlag() != 1){
						resMessage.setGuideStep(openData.getFlag());
					}else{
						resMessage.setGuideStep(player.getGuideStep());
					}
				}
				resMessage.setMainPageFunOpenData(mainPageList);
				resMessage.setBuyTiLiCount(player.getPool().getInt(Const.PROPERTY_PLAYER_BUY_TILI_COUNT, 0));
				//resMessage.setQuestData(questService.getPlayerQuestDatas(player.getId()));// 任务数据
				// playerService.addPlayer(player);
			}
		} else {
			resMessage.setCode(CommonResponseMessage.FALSE);
			resMessage.setDesc(I18NMessage.LOGIN_PLAYER_DESC);
		}
		packet.send(resMessage);
	}

	@RequestMapping(method = RequestMethod.GET)
	public void test(HttpServletRequest request, HttpServletResponse response,
			PlayerLoginRequestMessage requestMessage) {
		Packet packet = new Packet(OpCode.PLAYER_LOGIN, request, response);

		PlayerLoginResponseMessage resMessage = new PlayerLoginResponseMessage();

		// requestMessage = (PlayerLoginRequestMessage)
		// packet.getRequestMessage(requestMessage);

		String username = request.getParameter("userName");
		String passward = request.getParameter("passward");

		if (username != null && !"".equals(username)) {
			// TODO 认证账号

			Player player = playerService.getPlayerByAccountName(username,requestMessage.getChannelId());
			if (player != null) {

				// TODO 登录操作
				player.setGold(100);
				player.setExp(100);
				player.setLastLoginDay(Time.day);
				player.setLastLoginTime(new Date());
				playerService.updatePlayer(player);
				resMessage.setCode(CommonResponseMessage.TRUE);
				resMessage.setBaseData(player.getPlayerBaseData());
				
				resMessage.setUpdateObj(playerService.sendAndClean(player.getId()));
				
			} else {
				resMessage.setCode(CommonResponseMessage.TRUE);
				resMessage.setOperteState(1);// 创建角色
			}
		} else {
			resMessage.setCode(CommonResponseMessage.FALSE);
			resMessage.setDesc(I18NMessage.LOGIN_PLAYER_DESC);
		}
		packet.send(resMessage);
	}

}
