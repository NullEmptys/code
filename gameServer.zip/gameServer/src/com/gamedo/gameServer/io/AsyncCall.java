package com.gamedo.gameServer.io;

/**
 * 
 * @author libm
 *
 */
public interface AsyncCall extends Runnable{

	public void callFinish() throws Exception;
}
