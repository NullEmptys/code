package com.gamedo.gameServer.io;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gamedo.gameServer.util.JsonUtil;

/**
 * 协议包
 * 
 * @author libm
 *
 * @param <T>
 * @param <R>
 */
public class Packet {

	/* 协议号 */
	private String opCode;

	private Logger logger = LoggerFactory.getLogger(Packet.class);

	private HttpServletRequest request;

	private HttpServletResponse response;

	/* 客户端请求服务器消息内容 */
	private Object requestMessage;

	public Packet(String opCode, HttpServletRequest request, HttpServletResponse response) {
		this.opCode = opCode;
		this.request = request;
		this.response = response;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public Object getRequestMessage(Class object) {
		String content = "";
		java.io.BufferedReader reader = null;
		try {
			reader = request.getReader();// 获得字符流
			StringBuffer sb = new StringBuffer();
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\r\n");
			}
			content = sb.toString();
			int beginIndex = content.indexOf("{");
			int endIndex = content.lastIndexOf("}");
			content = content.substring(beginIndex, endIndex + 1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
				reader = null;
			} catch (Exception e) {
			}
		}

		try {
			requestMessage = JsonUtil.decodeJson(content, object);
			logger.info("receiveMessage = " + content);
			return requestMessage;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void setRequestMessage(Object requestMessage) {
		this.requestMessage = requestMessage;
	}

	public void send(Object responseMessage) {
		try {
			String message = JsonUtil.encodeJson(responseMessage);
			response.setHeader("Content-type", "text/html;charset=UTF-8");
			response.getOutputStream().write(message.getBytes("utf-8"));
			logger.info("sendClientMessage=" + message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getOpCode() {
		return opCode;
	}

	public String getIpAddr() {
		String ip = request.getHeader("X-Real-IP");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("x-forwarded-for");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}

//	public static void main(String args[]) {
//		String str = "dfaasdfasdc{zsdfadfadf{asdfawesd}asdfafad}";
//		int beginIndex = str.indexOf("{");
//		int endIndex = str.lastIndexOf("}");
//		
//		System.out.println(str.substring(beginIndex, endIndex + 1));
//	}
}
