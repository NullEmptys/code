package com.gamedo.gameServer.data.channel;

/**
 * 渠道
 * @author libm
 *
 */
public class Channel {

	private int id;
	
	private String channelId;
	
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
