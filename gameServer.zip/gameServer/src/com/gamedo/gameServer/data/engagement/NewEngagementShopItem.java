package com.gamedo.gameServer.data.engagement;

public class NewEngagementShopItem {
	private int id;

	/**
	 * 场景id
	 */
	private int sceneId;
	/**
	 * 商品id
	 */
	private int itemId;
	/**
	 * 货币类型
	 */
	private int currencyType;
	/**
	 * 出售价格
	 */
	private int price;
	/**
	 * 基础经验值
	 */
	private int baseExpValue;
	/**
	 * 喜欢的模特id
	 */
	private String likeGirl;
	/**
	 * 讨厌的模特id
	 */
	private String hateGirl;
	/**
	 * 增加的心情值
	 */
	private int addMoodValue;
	/**
	 * 减少的心情值
	 */
	private int delMoodValue;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSceneId() {
		return sceneId;
	}

	public void setSceneId(int sceneId) {
		this.sceneId = sceneId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getBaseExpValue() {
		return baseExpValue;
	}

	public void setBaseExpValue(int baseExpValue) {
		this.baseExpValue = baseExpValue;
	}

	public String getLikeGirl() {
		return likeGirl;
	}

	public void setLikeGirl(String likeGirl) {
		this.likeGirl = likeGirl;
	}

	public String getHateGirl() {
		return hateGirl;
	}

	public void setHateGirl(String hateGirl) {
		this.hateGirl = hateGirl;
	}

	public int getAddMoodValue() {
		return addMoodValue;
	}

	public void setAddMoodValue(int addMoodValue) {
		this.addMoodValue = addMoodValue;
	}

	public int getDelMoodValue() {
		return delMoodValue;
	}

	public void setDelMoodValue(int delMoodValue) {
		this.delMoodValue = delMoodValue;
	}
}
