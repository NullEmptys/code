package com.gamedo.gameServer.data.engagement;

/**
 * 约会送礼商城
 * @author libm
 *
 */
public class EngagementShopItem {

	private int id;
	
	/**
	 * 场景id
	 */
	private int sceneId;
	/**
	 * 商品id
	 */
	private int itemId;
	/**
	 * 货币类型
	 */
	private int currencyType;
	/**
	 * 出售价格
	 */
	private int price;
	/**
	 * 基础经验值
	 */
	private int baseExpValue;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSceneId() {
		return sceneId;
	}

	public void setSceneId(int sceneId) {
		this.sceneId = sceneId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getBaseExpValue() {
		return baseExpValue;
	}

	public void setBaseExpValue(int baseExpValue) {
		this.baseExpValue = baseExpValue;
	}
	
}
