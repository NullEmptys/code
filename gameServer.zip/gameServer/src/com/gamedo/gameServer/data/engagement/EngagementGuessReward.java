package com.gamedo.gameServer.data.engagement;

/**
 * 猜拳奖励
 * @author libm
 *
 */
public class EngagementGuessReward {

	private int id;
	
	private int round;
	
	private int rewardType;
	
	private int rewardId;
	
	private int rewardCounts;
	
	private int cdTimeType;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRound() {
		return round;
	}

	public void setRound(int round) {
		this.round = round;
	}

	public int getRewardType() {
		return rewardType;
	}

	public void setRewardType(int rewardType) {
		this.rewardType = rewardType;
	}

	public int getRewardId() {
		return rewardId;
	}

	public void setRewardId(int rewardId) {
		this.rewardId = rewardId;
	}

	public int getRewardCounts() {
		return rewardCounts;
	}

	public void setRewardCounts(int rewardCounts) {
		this.rewardCounts = rewardCounts;
	}

	public int getCdTimeType() {
		return cdTimeType;
	}

	public void setCdTimeType(int cdTimeType) {
		this.cdTimeType = cdTimeType;
	}
	
}
