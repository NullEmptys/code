package com.gamedo.gameServer.data.engagement;

/**
 * 约会送礼结束走向配置表
 * 
 * @author IPOC-HUANGPING
 *
 */
public class EngagementSendGiftWeightConfig {
	private int id;
	private int goodRoute;// 好路线权重
	private int badRoute;// 差路线权重

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGoodRoute() {
		return goodRoute;
	}

	public void setGoodRoute(int goodRoute) {
		this.goodRoute = goodRoute;
	}

	public int getBadRoute() {
		return badRoute;
	}

	public void setBadRoute(int badRoute) {
		this.badRoute = badRoute;
	}
}
