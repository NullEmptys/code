package com.gamedo.gameServer.data.engagement;

/**
 * 猜拳
 * @author libm
 *
 */
public class EngagementGuess {

	private int id;
	/**
	 * 回合数
	 */
	private int round;
	/**
	 * 赌资货币类型
	 */
	private int consumeCurrencyType;
	/**
	 * 赌资货币数量
	 */
	private int consumeCurrencyCounts;
	/**
	 * 获胜概率
	 */
	private int winPercent;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRound() {
		return round;
	}

	public void setRound(int round) {
		this.round = round;
	}

	public int getConsumeCurrencyType() {
		return consumeCurrencyType;
	}

	public void setConsumeCurrencyType(int consumeCurrencyType) {
		this.consumeCurrencyType = consumeCurrencyType;
	}

	public int getConsumeCurrencyCounts() {
		return consumeCurrencyCounts;
	}

	public void setConsumeCurrencyCounts(int consumeCurrencyCounts) {
		this.consumeCurrencyCounts = consumeCurrencyCounts;
	}

	public int getWinPercent() {
		return winPercent;
	}

	public void setWinPercent(int winPercent) {
		this.winPercent = winPercent;
	}
	
}
