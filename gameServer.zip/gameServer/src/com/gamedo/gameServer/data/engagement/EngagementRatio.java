package com.gamedo.gameServer.data.engagement;

/**
 * 约会送礼次数对应系数
 * @author libm
 *
 */
public class EngagementRatio {

	private int id;
	
	/**
	 * 赠送道具次数
	 */
	private int sendGiftCounts;
	/**
	 * 系数
	 */
	private double ratio;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSendGiftCounts() {
		return sendGiftCounts;
	}
	public void setSendGiftCounts(int sendGiftCounts) {
		this.sendGiftCounts = sendGiftCounts;
	}
	public double getRatio() {
		return ratio;
	}
	public void setRatio(double ratio) {
		this.ratio = ratio;
	}
	
	
}
