package com.gamedo.gameServer.data;

/**
 * 角色等级对应经验值数据
 * @author libm
 *
 */
public class PlayerLevelInfo {

	private int id;
	/*等级*/
	private int level;
	/*所需经验值*/
	private int exp;
	/*当前角色等级对应最高体力值上限*/
	private int maxTiLi;
	/*金币加成比率*/
	private double goldRatio;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}

	public int getMaxTiLi() {
		return maxTiLi;
	}

	public void setMaxTiLi(int maxTiLi) {
		this.maxTiLi = maxTiLi;
	}

	public double getGoldRatio() {
		return goldRatio;
	}

	public void setGoldRatio(double goldRatio) {
		this.goldRatio = goldRatio;
	}

}
