package com.gamedo.gameServer.data.achievement;

/**
 * 成就等级
 * @author libm
 *
 */
public class AchieveLevel {

	private int id;
	/**
	 * 成就等级
	 */
	private int level;
	/**
	 * 成就点
	 */
	private int achieveValue;
	/**
	 * 奖励服装id
	 */
	private int rewardItemId;
	/**
	 * 奖励数量
	 */
	private int rewardCounts;
	/**
	 * 服装时效类型
	 */
	private int cdTimeType;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getAchieveValue() {
		return achieveValue;
	}
	public void setAchieveValue(int achieveValue) {
		this.achieveValue = achieveValue;
	}
	public int getRewardItemId() {
		return rewardItemId;
	}
	public void setRewardItemId(int rewardItemId) {
		this.rewardItemId = rewardItemId;
	}
	public int getRewardCounts() {
		return rewardCounts;
	}
	public void setRewardCounts(int rewardCounts) {
		this.rewardCounts = rewardCounts;
	}
	public int getCdTimeType() {
		return cdTimeType;
	}
	public void setCdTimeType(int cdTimeType) {
		this.cdTimeType = cdTimeType;
	}
	
}
