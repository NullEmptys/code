package com.gamedo.gameServer.data.achievement;

/**
 * 成就
 * @author libm
 *
 */
public class Achievement {

	/**
	 * 成就id
	 */
	private int id;
	/**
	 * 成就标题
	 */
	private String name;
	/**
	 * 成就描述
	 */
	private String description;
	/**
	 * 成就打分类
	 */
	private int category;
	/**
	 * 小分类
	 */
	private int type;
	/**
	 * 模特id
	 */
	private int girlId;
	/**
	 * 场景类型
	 */
	private int sceneType;
	/**
	 * 任务星级
	 */
	private int questStar;
	/**
	 * 成就达成条件值
	 */
	private int value;
	/**
	 * 成就点
	 */
	private int achieveValue;
	/**
	 * 是否隐藏
	 * 1、是
	 * 0、否
	 */
	private int hidden;
	/**
	 * 是否继承
	 * 1、是
	 * 0、否
	 */
	private int extend;
	/**
	 * 完成成就奖励货币类型
	 */
	private int currencyType;
	/**
	 * 完成成就奖励货币数
	 */
	private int currencyCounts;
	
	/**
	 * 成就弹出类型
	 * 0、立即弹出
	 * 1、结算界面弹出
	 * 2、主界面弹出
	 */
	private int popupType;
	
	/**
	 * 物品大分类
	 */
	private int itemCategory;
	
	/**
	 * 物品小分类
	 */
	private int itemType;
	
	/**
	 * 是否默认开启
	 */
	private int isDefault;
	
	/**
	 * 下一个成就id
	 */
	private int nextAchieveId;
	
	/**
	 * 任务id
	 */
	private int questId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getHidden() {
		return hidden;
	}

	public void setHidden(int hidden) {
		this.hidden = hidden;
	}

	public int getExtend() {
		return extend;
	}

	public void setExtend(int extend) {
		this.extend = extend;
	}

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getAchieveValue() {
		return achieveValue;
	}

	public void setAchieveValue(int achieveValue) {
		this.achieveValue = achieveValue;
	}

	public int getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	public int getCurrencyCounts() {
		return currencyCounts;
	}

	public void setCurrencyCounts(int currencyCounts) {
		this.currencyCounts = currencyCounts;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public int getSceneType() {
		return sceneType;
	}

	public void setSceneType(int sceneType) {
		this.sceneType = sceneType;
	}

	public int getQuestStar() {
		return questStar;
	}

	public void setQuestStar(int questStar) {
		this.questStar = questStar;
	}

	public int getPopupType() {
		return popupType;
	}

	public void setPopupType(int popupType) {
		this.popupType = popupType;
	}

	public int getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(int isDefault) {
		this.isDefault = isDefault;
	}

	public int getNextAchieveId() {
		return nextAchieveId;
	}

	public void setNextAchieveId(int nextAchieveId) {
		this.nextAchieveId = nextAchieveId;
	}

	public int getItemCategory() {
		return itemCategory;
	}

	public void setItemCategory(int itemCategory) {
		this.itemCategory = itemCategory;
	}

	public int getItemType() {
		return itemType;
	}

	public void setItemType(int itemType) {
		this.itemType = itemType;
	}

	public int getQuestId() {
		return questId;
	}

	public void setQuestId(int questId) {
		this.questId = questId;
	}
	
}
