package com.gamedo.gameServer.data.equipment;

/**
 * 服装时效
 * @author libm
 *
 */
public class ClothCdTime {

	private int id;
	/**标题名称*/
	private String title;
	/**时效时间  单位：秒*/
	private long cdTime;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public long getCdTime() {
		return cdTime;
	}

	public void setCdTime(long cdTime) {
		this.cdTime = cdTime;
	}

}
