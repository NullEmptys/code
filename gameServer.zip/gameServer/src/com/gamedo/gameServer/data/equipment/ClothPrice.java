package com.gamedo.gameServer.data.equipment;

/**
 * 服装租用价格
 * @author libm
 *
 */
public class ClothPrice {

	private int id;
	/**服装id*/
	private int clothId;
	/**时效类型*/
	private int cdTimeType;
	/**货币类型*/
	private int currencyType;
	/**货币数量*/
	private int currencyCounts;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getClothId() {
		return clothId;
	}

	public void setClothId(int clothId) {
		this.clothId = clothId;
	}

	public int getCdTimeType() {
		return cdTimeType;
	}

	public void setCdTimeType(int cdTimeType) {
		this.cdTimeType = cdTimeType;
	}

	public int getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	public int getCurrencyCounts() {
		return currencyCounts;
	}

	public void setCurrencyCounts(int currencyCounts) {
		this.currencyCounts = currencyCounts;
	}
	
	
}
