package com.gamedo.gameServer.data;

/**
 * 模特签约类型
 * 
 * @author liuxing
 *
 */
public class GirlSignType {
	private int id;
	private int girlId;
	private int type;
	private String title;
	/**
	 * 时效时间
	 * 单位：秒
	 */
	private long cdTime;
	private int currencyType;
	private int currencyCounts;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getGirlId() {
		return girlId;
	}
	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public long getCdTime() {
		return cdTime;
	}
	public void setCdTime(long cdTime) {
		this.cdTime = cdTime;
	}
	public int getCurrencyType() {
		return currencyType;
	}
	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}
	public int getCurrencyCounts() {
		return currencyCounts;
	}
	public void setCurrencyCounts(int currencyCounts) {
		this.currencyCounts = currencyCounts;
	}

	
}
