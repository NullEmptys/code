package com.gamedo.gameServer.data.shop;

import java.util.Date;

/**
 * 
 * @author libm
 *
 */
public class Shop {

	/**
	 * 商城id
	 */
	private int id;
	/**
	 * 商城标题
	 */
	private String title;
	/**
	 * 商城描述
	 */
	private String description;
	/**
	 * 商城起始时间
	 */
	private Date startTime;
	/**
	 * 商城结束时间
	 */
	private Date endTime;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

}
