package com.gamedo.gameServer.data.shop;

/**
 * 商城物品
 * @author libm
 *
 */
public class ShopItem {

	private int id;
	/**
	 * 商城id
	 */
	private int shopId;
	/**
	 * 物品id
	 */
	private int itemId;
	/**
	 * 标签icon
	 */
	private String labelIcon;
	/**
	 * 商城活动期间内限购次数
	 * 0:不限次数
	 */
	private int limitBuyCount;
	/**
	 * 购买该商品需货币类型
	 */
	private int currencyType;
	/**
	 * 购买该商品需货币数量
	 */
	private int currencyCount;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getLabelIcon() {
		return labelIcon;
	}

	public void setLabelIcon(String labelIcon) {
		this.labelIcon = labelIcon;
	}

	public int getLimitBuyCount() {
		return limitBuyCount;
	}

	public void setLimitBuyCount(int limitBuyCount) {
		this.limitBuyCount = limitBuyCount;
	}

	public int getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	public int getCurrencyCount() {
		return currencyCount;
	}

	public void setCurrencyCount(int currencyCount) {
		this.currencyCount = currencyCount;
	}
	
}
