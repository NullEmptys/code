package com.gamedo.gameServer.data.activity.activityExch;

import java.util.Date;

/**
 * 活动配置表（当前活动所投放的道具配置信息）
 * @author IPOC-HUANGPING
 *
 */
public class ExchActivityConfig {
	private int id;
	private int activityId;
	private String activityConfig;//{"1":12,"2":34,"3":23};
	private Date firstEndTime;//第一阶段时间
	private Date secondEndTime;//第二阶段时间

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}

	public String getActivityConfig() {
		return activityConfig;
	}

	public void setActivityConfig(String activityConfig) {
		this.activityConfig = activityConfig;
	}

	public Date getFirstEndTime() {
		return firstEndTime;
	}

	public void setFirstEndTime(Date firstEndTime) {
		this.firstEndTime = firstEndTime;
	}

	public Date getSecondEndTime() {
		return secondEndTime;
	}

	public void setSecondEndTime(Date secondEndTime) {
		this.secondEndTime = secondEndTime;
	}
}
