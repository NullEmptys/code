package com.gamedo.gameServer.data.activity.activityExch;

import java.io.Serializable;

/**
 * 兑换活动配置表
 * 
 * @author IPOC-HUANGPING
 *
 */
public class ActivityExchData implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 自增id
	private int id;
	// 票据名称
	private String name;
	// 票据ioc
	private String ioc;
	// 票的种类
	private String type;
	// 票据消耗的道具
	private int consumeType;
	// 消耗道具的数量
	private int consumeNum;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIoc() {
		return ioc;
	}

	public void setIoc(String ioc) {
		this.ioc = ioc;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getConsumeType() {
		return consumeType;
	}

	public void setConsumeType(int consumeType) {
		this.consumeType = consumeType;
	}

	public int getConsumeNum() {
		return consumeNum;
	}

	public void setConsumeNum(int consumeNum) {
		this.consumeNum = consumeNum;
	}

}
