package com.gamedo.gameServer.data;

public class XieZhenGroupReward {

	private int id;
	
	private int xieZhenGroupId;
	
	private int xieZhenId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getXieZhenGroupId() {
		return xieZhenGroupId;
	}

	public void setXieZhenGroupId(int xieZhenGroupId) {
		this.xieZhenGroupId = xieZhenGroupId;
	}

	public int getXieZhenId() {
		return xieZhenId;
	}

	public void setXieZhenId(int xieZhenId) {
		this.xieZhenId = xieZhenId;
	}
	
}
