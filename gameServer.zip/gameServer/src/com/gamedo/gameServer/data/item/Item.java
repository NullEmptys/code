package com.gamedo.gameServer.data.item;

/**
 * 
 * @author libm
 *
 */
public class Item {
	
	 /**
     * 物品不可使用 
     */
    public static final int AVAILABLE_NO = 0;
    /**
     * 物品只有战斗中可使用 
     */
    public static final int AVAILABLE_BATTLE = 1;
    /**
     * 物品只有非战斗中可使用 
     */
    public static final int AVAILABLE_UN_BATTLE = 2;    
    /**
     * 物品任何时候都可使用 
     */
    public static final int AVAILABLE_EVER = 3;

	private int id;
	
	/**
	 * 物品名称
	 */
	private String name;
	/**
	 * 描述
	 */
	private String description;
	/**
	 * 物品大分类 
	 * 0. 消耗类
	 * 1. 服装类
	 * 2. 动作类
	 */
	private int category;
	/**
	 * 物品类型
	 */
	private int type;
	/**
	 * 是否可以堆叠
	 * 0：否
	 * 1：是
	 */
	private int canAddition;
	/**
	 * 物品堆叠数量，必须大于0
	 */
	private int addition = 1;
	/**
	 * 是否是任务物品 
	 * 0-否
	 * 1-是
	 */
	private int questFlag;
	/**
	 * 物品是否可用
	 * 0. 否：不可直接使用的物品
     * 1. 战斗中可用 
     * 2. 非战斗中可用 
     * 3. 任何时候可用
	 */
	private int available; 
	/**
	 * 物品品质
	 */
	private int quality;
	/**
	 * 使用后是否消失
	 * 0. 不消失
	 * 1. 消失
	 */
	private int consume = 1;
	 /**
     * 自动使用 
     * -1. 不可以自动使用 
     *  0. 默认自动：得到物品后，将给出系统默认是否使用的选择提示，玩家可以选择使用或则不使用； 
     *  1. 定义自动：可针对此物品单独定义提示是否使用的描述和选项文字；
     *  2. 后台自动：不做任何提示，得到物品后系统自动将其使用
     */
	private int autoUse;
    /**
     * 物品级别
     */
	private int level = 1;
    /**
     * 使用该物品的玩家等级下限
     *  -1：没有限制
     *  >0: 实际等级
     */
	private int playerLevel = 1;
    /**
     * 使用该物品的玩家等级上限
     */
	private int playerMaxLevel = 100;
    
	/**
	 * 是否可以出售
	 * 0：否
	 * 1：是
	 */
    private int canSale;
    
    /**
     * 出售后获得货币类型
     */
    private int currencyType;
    
    /**
     * 出售后获得货币数量
     */
    private int price;
    
    /**
     * 图标id
     */
    private String iconId;
    
    /**
     * 是否允许丢弃
     * 0：否
     * 1：是
     */
    private int canDelete;
    
    /**
     * 使用次数
     */
    private int useCount;
    /**
     * 最多拥有数量,0不限制
     */
    private int maxOwnCount;
    
    /**
     * 是否实例类型，如果是实例的话，堆叠数量必须为1；
     */
    public int instance;
    
    /**服装颜色*/
    private int color;
    
    /**服装风格*/
    private int style;
    
    /**服装款式*/
    private String cloth;
    
    /**特效id*/
    private int effectId;
    
    private int windId;
    
    private int attribute;
    
    private String url;
    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getCanAddition() {
		return canAddition;
	}
	public void setCanAddition(int canAddition) {
		this.canAddition = canAddition;
	}
	public int getAddition() {
		return addition;
	}
	public void setAddition(int addition) {
		this.addition = addition;
	}
	public int getQuestFlag() {
		return questFlag;
	}
	public void setQuestFlag(int questFlag) {
		this.questFlag = questFlag;
	}
	public int getAvailable() {
		return available;
	}
	public void setAvailable(int available) {
		this.available = available;
	}
	public int getQuality() {
		return quality;
	}
	public void setQuality(int quality) {
		this.quality = quality;
	}
	public int getConsume() {
		return consume;
	}
	public void setConsume(int consume) {
		this.consume = consume;
	}
	public int getAutoUse() {
		return autoUse;
	}
	public void setAutoUse(int autoUse) {
		this.autoUse = autoUse;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getPlayerLevel() {
		return playerLevel;
	}
	public void setPlayerLevel(int playerLevel) {
		this.playerLevel = playerLevel;
	}
	public int getPlayerMaxLevel() {
		return playerMaxLevel;
	}
	public void setPlayerMaxLevel(int playerMaxLevel) {
		this.playerMaxLevel = playerMaxLevel;
	}
	public int getCanSale() {
		return canSale;
	}
	public void setCanSale(int canSale) {
		this.canSale = canSale;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getIconId() {
		return iconId;
	}
	public void setIconId(String iconId) {
		this.iconId = iconId;
	}
	public int getCanDelete() {
		return canDelete;
	}
	public void setCanDelete(int canDelete) {
		this.canDelete = canDelete;
	}
	public int getUseCount() {
		return useCount;
	}
	public void setUseCount(int useCount) {
		this.useCount = useCount;
	}
	public int getMaxOwnCount() {
		return maxOwnCount;
	}
	public void setMaxOwnCount(int maxOwnCount) {
		this.maxOwnCount = maxOwnCount;
	}
	public int getInstance() {
		return instance;
	}
	public void setInstance(int instance) {
		this.instance = instance;
	}
	public int getCurrencyType() {
		return currencyType;
	}
	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}
	public int getColor() {
		return color;
	}
	public void setColor(int color) {
		this.color = color;
	}
	public int getStyle() {
		return style;
	}
	public void setStyle(int style) {
		this.style = style;
	}
	public String getCloth() {
		return cloth;
	}
	public void setCloth(String cloth) {
		this.cloth = cloth;
	}
	public int getEffectId() {
		return effectId;
	}
	public void setEffectId(int effectId) {
		this.effectId = effectId;
	}
	public int getWindId() {
		return windId;
	}
	public void setWindId(int windId) {
		this.windId = windId;
	}
	public int getAttribute() {
		return attribute;
	}
	public void setAttribute(int attribute) {
		this.attribute = attribute;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
}
