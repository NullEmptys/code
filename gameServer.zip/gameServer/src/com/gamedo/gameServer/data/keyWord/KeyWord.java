package com.gamedo.gameServer.data.keyWord;

/**
 * 敏感字对象
 * @author libm
 *
 */
public class KeyWord {

	private int id;
	
	/*关键字名称*/
	private String keyName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getKeyName() {
		return keyName;
	}

	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}
	
}
