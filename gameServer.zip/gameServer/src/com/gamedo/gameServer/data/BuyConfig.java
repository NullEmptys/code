package com.gamedo.gameServer.data;

/**
 * 购买体力或金币配置表
 * 
 * @author IPOC-HUANGPING
 *
 */
public class BuyConfig {
	private int id;// 自增id
	private int buyType;// 购买类型1,购买体力2，购买金币
	private int consumeItemId;// 消耗的物品id
	private int consumeItemNum;// 消耗钻石数
	private int baseValue;// 基础体力值
	private int extraValue;// 额外增加体力值

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getBuyType() {
		return buyType;
	}

	public void setBuyType(int buyType) {
		this.buyType = buyType;
	}

	public int getConsumeItemId() {
		return consumeItemId;
	}

	public void setConsumeItemId(int consumeItemId) {
		this.consumeItemId = consumeItemId;
	}

	public int getConsumeItemNum() {
		return consumeItemNum;
	}

	public void setConsumeItemNum(int consumeItemNum) {
		this.consumeItemNum = consumeItemNum;
	}

	public int getBaseValue() {
		return baseValue;
	}

	public void setBaseValue(int baseValue) {
		this.baseValue = baseValue;
	}

	public int getExtraValue() {
		return extraValue;
	}

	public void setExtraValue(int extraValue) {
		this.extraValue = extraValue;
	}

}
