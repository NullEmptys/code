package com.gamedo.gameServer.data.wardrobe;

/**
 * 衣橱
 * @author libm
 *
 */
public class Wardrobe {

	private int id;
	
	private int itemId;
	
	private int exclusiveModels;
	
	private int sequence;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getExclusiveModels() {
		return exclusiveModels;
	}

	public void setExclusiveModels(int exclusiveModels) {
		this.exclusiveModels = exclusiveModels;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	
}
