package com.gamedo.gameServer.data.dailyMission;

/**
 * 每日任务配置表
 * @author IPOC-HUANGPING
 *
 */
public class DailyMissionDefine	{
	
	public static final int DAILYMISSION = 1;//每日任务category
	public static final int DAILY_FLUSH = 1;//每日刷新
	public static final int WEEK_FLUSH=2;//每周属性
	//自增id
	private int id;
	//任务名字
	private String name;
	//任务描述
	private String description;
	//分类id
	private int category;
	//任务属性
	private int property;
	//任务导航
	private String navigation;
	//任务活跃度
	private int activeValue;
	//奖励道具id
	private String rewardIds;
	//奖励道具类型
	private String rewardTypes;
	//奖励道具数量
	private String rewardNums;
	//任务参数
	private String missionPrams;
	//任务排序
	private int missionSort;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public int getProperty() {
		return property;
	}
	public void setProperty(int property) {
		this.property = property;
	}
	public int getActiveValue() {
		return activeValue;
	}
	public void setActiveValue(int activeValue) {
		this.activeValue = activeValue;
	}
	public String getRewardIds() {
		return rewardIds;
	}
	public void setRewardIds(String rewardIds) {
		this.rewardIds = rewardIds;
	}
	public String getRewardTypes() {
		return rewardTypes;
	}
	public void setRewardTypes(String rewardTypes) {
		this.rewardTypes = rewardTypes;
	}
	public String getRewardNums() {
		return rewardNums;
	}
	public void setRewardNums(String rewardNums) {
		this.rewardNums = rewardNums;
	}
	public String getMissionPrams() {
		return missionPrams;
	}
	public void setMissionPrams(String missionPrams) {
		this.missionPrams = missionPrams;
	}
	public String getNavigation() {
		return navigation;
	}
	public void setNavigation(String navigation) {
		this.navigation = navigation;
	}
	public int getMissionSort() {
		return missionSort;
	}
	public void setMissionSort(int missionSort) {
		this.missionSort = missionSort;
	}
}
