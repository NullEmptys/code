package com.gamedo.gameServer.data.dailyMission;

/**
 * 每日任务奖励配置表
 * @author IPOC-HUANGPING
 *
 */
public class DailyMissionActiveReward {
	
	public static final int DAILY_ACTIVE = 1;
	public static final int WEEK_ACTIVE = 2;
	//自增id
	private int id;
	//1--日活跃度2--周活跃度
	private int activeType;
	//所需活跃度
	private int needActive;
	//奖励id
	private String rewardIds;
	//奖励类型
	private String rewardTypes;
	//奖励的数量
	private String rewardNums;
	//掉落组id
	private int dropId;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNeedActive() {
		return needActive;
	}
	public void setNeedActive(int needActive) {
		this.needActive = needActive;
	}
	public int getActiveType() {
		return activeType;
	}
	public void setActiveType(int activeType) {
		this.activeType = activeType;
	}
	public String getRewardIds() {
		return rewardIds;
	}
	public void setRewardIds(String rewardIds) {
		this.rewardIds = rewardIds;
	}
	public String getRewardTypes() {
		return rewardTypes;
	}
	public void setRewardTypes(String rewardTypes) {
		this.rewardTypes = rewardTypes;
	}
	public String getRewardNums() {
		return rewardNums;
	}
	public void setRewardNums(String rewardNums) {
		this.rewardNums = rewardNums;
	}
	public int getDropId() {
		return dropId;
	}
	public void setDropId(int dropId) {
		this.dropId = dropId;
	}
}
