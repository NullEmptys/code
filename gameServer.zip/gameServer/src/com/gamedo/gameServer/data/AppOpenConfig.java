package com.gamedo.gameServer.data;

/**
 * 系统开关配置表
 * 
 * @author IPOC-HUANGPING
 *
 */
public class AppOpenConfig {
	private int id;// id
	private String functionType;// 功能关键词
	private String description;// 功能描述
	private int flag;// 0关闭 1开启

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFunctionType() {
		return functionType;
	}

	public void setFunctionType(String functionType) {
		this.functionType = functionType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}
}
