package com.gamedo.gameServer.data.mothsign;

import java.io.Serializable;

/**
 * 月签
 * @author IPOC-HUANGPING
 *
 */
public class MonthSignData implements Serializable{
	/**
	 * 序列号
	 */
	private static final long serialVersionUID = 1L;
	/**id*/
	private int id;
	/**月份*/
	private int month;
	/**次数*/
	private int time;
	/**奖励物品类型*/
	private int type;
	/**奖励物品id*/
	private int itemid;
	/**奖励物品数量*/
	private int num;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	
}
