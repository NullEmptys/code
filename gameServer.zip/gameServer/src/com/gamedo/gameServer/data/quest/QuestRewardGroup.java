package com.gamedo.gameServer.data.quest;

/**
 * 
 * @author libm
 *
 */
public class QuestRewardGroup {

	public static final int REWARD_ITEM = 1;
	public static final int REWARD_CURRENCY = 2;
	
	private int id;
	
	private int rewardGroupId;
	/**
	 * 奖励类型
	 * 1、物品
	 * 2、货币
	 */
	private int rewardType;
	
	private int rewardId;
	
	private int rewardCounts;
	
	private int cdTimeType;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRewardGroupId() {
		return rewardGroupId;
	}

	public void setRewardGroupId(int rewardGroupId) {
		this.rewardGroupId = rewardGroupId;
	}

	public int getRewardType() {
		return rewardType;
	}

	public void setRewardType(int rewardType) {
		this.rewardType = rewardType;
	}

	public int getRewardId() {
		return rewardId;
	}

	public void setRewardId(int rewardId) {
		this.rewardId = rewardId;
	}

	public int getRewardCounts() {
		return rewardCounts;
	}

	public void setRewardCounts(int rewardCounts) {
		this.rewardCounts = rewardCounts;
	}

	public int getCdTimeType() {
		return cdTimeType;
	}

	public void setCdTimeType(int cdTimeType) {
		this.cdTimeType = cdTimeType;
	}
	
	
}
