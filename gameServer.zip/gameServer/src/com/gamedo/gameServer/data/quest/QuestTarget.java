package com.gamedo.gameServer.data.quest;

/**
 * 任务目标
 * @author libm
 *
 */
public class QuestTarget {

}
