package com.gamedo.gameServer.data.quest;

/**
 * 气泡
 * @author libm
 *
 */
public class Bubble {

	private int id;
	/*气泡描述*/
	private String description;
	/*权重*/
	private int weight;
	/*气泡类型
	 * 1、货币
	 * 2、炸弹
	 * 3、礼包
	 **/
	private int bubbleType;
	/**
	 * 根据气泡类型而定
	 */
	private int rewardId;
	/*数值*/
	private int value;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getBubbleType() {
		return bubbleType;
	}

	public void setBubbleType(int bubbleType) {
		this.bubbleType = bubbleType;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getRewardId() {
		return rewardId;
	}

	public void setRewardId(int rewardId) {
		this.rewardId = rewardId;
	}
	
}
