package com.gamedo.gameServer.data.quest;

/**
 * 关卡星级比率
 * @author libm
 *
 */
public class StarRatio {

	private int id;
	
	/**星级*/
	private int star;
	/**比率*/
	private double starRatio;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getStar() {
		return star;
	}
	public void setStar(int star) {
		this.star = star;
	}
	public double getStarRatio() {
		return starRatio;
	}
	public void setStarRatio(double starRatio) {
		this.starRatio = starRatio;
	}
	
	
}
