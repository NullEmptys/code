package com.gamedo.gameServer.data.quest;

public class TargetCondition {

	private int conditionId;

	private int type;

	private String text;

	private int color;

	private int style;

	private int cloth;

	private int special;

	private String scene;

	private int mote;

	private int shoottype;

	private int shootnum;

	private int value;

	private int textType;
	
	private int girlId;

	public int getConditionId() {
		return conditionId;
	}

	public void setConditionId(int conditionId) {
		this.conditionId = conditionId;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}

	public int getStyle() {
		return style;
	}

	public void setStyle(int style) {
		this.style = style;
	}

	public int getCloth() {
		return cloth;
	}

	public void setCloth(int cloth) {
		this.cloth = cloth;
	}

	public int getSpecial() {
		return special;
	}

	public void setSpecial(int special) {
		this.special = special;
	}

	public String getScene() {
		return scene;
	}

	public void setScene(String scene) {
		this.scene = scene;
	}

	public int getMote() {
		return mote;
	}

	public void setMote(int mote) {
		this.mote = mote;
	}

	public int getShoottype() {
		return shoottype;
	}

	public void setShoottype(int shoottype) {
		this.shoottype = shoottype;
	}

	public int getShootnum() {
		return shootnum;
	}

	public void setShootnum(int shootnum) {
		this.shootnum = shootnum;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getTextType() {
		return textType;
	}

	public void setTextType(int textType) {
		this.textType = textType;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}
	
}
