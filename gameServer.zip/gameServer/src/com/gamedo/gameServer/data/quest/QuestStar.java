package com.gamedo.gameServer.data.quest;

/**
 * 任务星级数据
 * @author libm
 *
 */
public class QuestStar {

	private int id;
	
	/**任务难度类型  普通以及困难*/
	private int type;
	/**星级*/
	private int star;
	/**最低分数*/
	private int minScore;
	/**最高分数*/
	private int maxScore;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getStar() {
		return star;
	}
	public void setStar(int star) {
		this.star = star;
	}
	public int getMinScore() {
		return minScore;
	}
	public void setMinScore(int minScore) {
		this.minScore = minScore;
	}
	public int getMaxScore() {
		return maxScore;
	}
	public void setMaxScore(int maxScore) {
		this.maxScore = maxScore;
	}
	
	
}
