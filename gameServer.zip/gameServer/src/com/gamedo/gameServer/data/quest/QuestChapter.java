package com.gamedo.gameServer.data.quest;

/**
 * 任务大章
 * @author libm
 *
 */
public class QuestChapter {

	/**章节id*/
	private int id;
	/**章节名称*/
	private String name;
	/**章节图标id*/
	private String iconId;
	/**章节描述*/
	private String description;
	/**下一章节id*/
	private int nextChapterId;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIconId() {
		return iconId;
	}
	public void setIconId(String iconId) {
		this.iconId = iconId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getNextChapterId() {
		return nextChapterId;
	}
	public void setNextChapterId(int nextChapterId) {
		this.nextChapterId = nextChapterId;
	}
	
}
