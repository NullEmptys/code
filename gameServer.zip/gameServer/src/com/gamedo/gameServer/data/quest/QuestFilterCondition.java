package com.gamedo.gameServer.data.quest;

/**
 * 任务筛选条件
 * @author libm
 *
 */
public class QuestFilterCondition {

	private int id;
	
	/**
	 * 任务条件名称
	 */
	private String conditionTitle;
	
	/**
	 * 条件分类
	 * 1、模特类条件
	 * 2、场景类条件
	 * 3、服装类条件
	 * 4、玩法类条件
	 */
	private int conditionCategory;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getConditionTitle() {
		return conditionTitle;
	}

	public void setConditionTitle(String conditionTitle) {
		this.conditionTitle = conditionTitle;
	}

	public int getConditionCategory() {
		return conditionCategory;
	}

	public void setConditionCategory(int conditionCategory) {
		this.conditionCategory = conditionCategory;
	}

}
