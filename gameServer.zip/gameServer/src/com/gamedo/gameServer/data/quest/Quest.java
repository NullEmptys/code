package com.gamedo.gameServer.data.quest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import gnu.trove.map.hash.TIntIntHashMap;

/**
 * 任务
 * @author libm
 *
 */
public class Quest {

	/**
	 * 任务id
	 */
	private int id;
	/**
     * 任务类型：0 - 日常，1 - 特殊，2 - 社交。
     */
	private int category;
	
	private int subType;
	
	/**
	 * 任务难度
	 * 0、简单
	 * 1、普通
	 * 2、困难
	 */
	private int hardType;
	/**
	 * 任务名称
	 */
	private String name;
	/**
	 * 任务描述
	 */
	private String description;
	
	private TIntIntHashMap filterConditions = new TIntIntHashMap();
	
	/**
	 * 任务满足条件
	 */
	private String filterConditionsStr;
	
    /**
     * 任务级别。
     */
	private int level;
	/**
	 * 消耗体力数 
	 */
	private int consumeTili;
    /**
     * 是否有效。
     */
	private int valid = 0;
	
	/**
	 * 掉落组id
	 */
	private int dropGroupId;
	
	/**
	 * 场景限制
	 */
	private String scene;
	
	/**
	 * 每日可完成次数
	 */
	private int finishCounts;
	
	/**
	 * vip额外可完成次数
	 */
	private int vipFinishCounts;
	
	/**
	 * 是否可以锁住
	 */
	private int canLock;
	
	private int gamePlayId;
	
	private int heartReward;
	
	/**
	 * 下一领取任务
	 */
	private String nextQuestIdStr;
	
	public List<Integer> nextQuestIds = new ArrayList<>();
	
	/**
	 * 是否可以重复做任务
	 */
	private int canRepeat;
	
	/**
	 * 是否默认接受
	 */
	private int isDefault;
	
	/**
	 * 任务生命周期
	 * 开始时间
	 */
	private Date startTime;
	
	/**
	 * 任务生命周期
	 * 结束时间
	 */
	private Date endTime;
	
	private String iconId;
	
	private String backGroundId;
	
	private int girlId;
	/**
	 * 是否显示
	 */
	private int display;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public int getHardType() {
		return hardType;
	}

	public void setHardType(int hardType) {
		this.hardType = hardType;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getValid() {
		return valid;
	}

	public void setValid(int valid) {
		this.valid = valid;
	}

	public int getDropGroupId() {
		return dropGroupId;
	}

	public void setDropGroupId(int dropGroupId) {
		this.dropGroupId = dropGroupId;
	}

	public int getConsumeTili() {
		return consumeTili;
	}

	public void setConsumeTili(int consumeTili) {
		this.consumeTili = consumeTili;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getScene() {
		return scene;
	}

	public void setScene(String scene) {
		this.scene = scene;
	}

	public int getVipFinishCounts() {
		return vipFinishCounts;
	}

	public void setVipFinishCounts(int vipFinishCounts) {
		this.vipFinishCounts = vipFinishCounts;
	}

	public int getFinishCounts() {
		return finishCounts;
	}

	public void setFinishCounts(int finishCounts) {
		this.finishCounts = finishCounts;
	}

	public int getCanLock() {
		return canLock;
	}

	public void setCanLock(int canLock) {
		this.canLock = canLock;
	}

	public String getFilterConditionsStr() {
		return filterConditionsStr;
	}

	public void setFilterConditionsStr(String filterConditionsStr) {
		this.filterConditionsStr = filterConditionsStr;
		parseConditionStr();
	}

	public void parseConditionStr() {
		if(filterConditionsStr != null && !filterConditionsStr.equals("")) {
			String[] conditions = filterConditionsStr.split(";");
			if(conditions != null && conditions.length > 0) {
				for(int i = 0; i < conditions.length; i++) {
					if(conditions[i] != null) {
						String conditionStr = conditions[i];
						int condition = Integer.parseInt(conditionStr);
						this.filterConditions.put(condition, condition);
					}
				}
			}
		}
	}

	public TIntIntHashMap getConditions() {
		return filterConditions;
	}

	public int getGamePlayId() {
		return gamePlayId;
	}

	public void setGamePlayId(int gamePlayId) {
		this.gamePlayId = gamePlayId;
	}

	public int getHeartReward() {
		return heartReward;
	}

	public void setHeartReward(int heartReward) {
		this.heartReward = heartReward;
	}

	public int getCanRepeat() {
		return canRepeat;
	}

	public void setCanRepeat(int canRepeat) {
		this.canRepeat = canRepeat;
	}

	public String getNextQuestIdStr() {
		return nextQuestIdStr;
	}

	public void setNextQuestIdStr(String nextQuestIdStr) {
		this.nextQuestIdStr = nextQuestIdStr;
		if(this.nextQuestIdStr != null && this.nextQuestIdStr.length() > 0) {
			String[] questIds = this.nextQuestIdStr.split(";");
			if(questIds != null && questIds.length > 0) {
				for(int i = 0; i < questIds.length; i++) {
					if(questIds[i] != null) {
						String questIdStr = questIds[i];
						int questId = Integer.parseInt(questIdStr);
						this.nextQuestIds.add(questId);
					}
				}
			}
		}
	}

	public int getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(int isDefault) {
		this.isDefault = isDefault;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getIconId() {
		return iconId;
	}

	public void setIconId(String iconId) {
		this.iconId = iconId;
	}

	public String getBackGroundId() {
		return backGroundId;
	}

	public void setBackGroundId(String backGroundId) {
		this.backGroundId = backGroundId;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public int getSubType() {
		return subType;
	}

	public void setSubType(int subType) {
		this.subType = subType;
	}

	public int getDisplay() {
		return display;
	}

	public void setDisplay(int display) {
		this.display = display;
	}
	
}
