package com.gamedo.gameServer.data.quest;

/**
 * 掉落服装、动作概率
 * @author libm
 *
 */
public class DropRate {

	private int id;
	
	/**
	 * 已从玩法内活动服装或者动作数量
	 */
	private int counts;
	
	/**
	 * 权重
	 */
	private int weight;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCounts() {
		return counts;
	}

	public void setCounts(int counts) {
		this.counts = counts;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	
}
