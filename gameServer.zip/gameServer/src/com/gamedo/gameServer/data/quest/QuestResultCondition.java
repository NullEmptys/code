package com.gamedo.gameServer.data.quest;

import java.util.ArrayList;
import java.util.List;

/**
 * 任务结果条件
 * @author libm
 *
 */
public class QuestResultCondition {

	private int id;
	/**
	 * 任务id
	 */
	private int questId;
	/**
	 * 奖励组id 
	 */
	private int groupId;
	/**
	 * 条件描述
	 */
	private String contionName;
	/**
	 * 结果条件
	 */
	private String resultConditions;
	
	public List<Integer> conditionIds;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getQuestId() {
		return questId;
	}

	public void setQuestId(int questId) {
		this.questId = questId;
	}

	public String getContionName() {
		return contionName;
	}

	public void setContionName(String contionName) {
		this.contionName = contionName;
	}

	public String getResultConditions() {
		return resultConditions;
	}

	public void setResultConditions(String resultConditions) {
		this.resultConditions = resultConditions;
		if(resultConditions != null && resultConditions.length() > 0) {
			conditionIds = new ArrayList<>();
			String[] conditionStrs = resultConditions.split(";");
			if(conditionStrs != null) {
				for(String conditionStr : conditionStrs) {
					if(conditionStr != null) {
						conditionIds.add(Integer.parseInt(conditionStr));
					}
				}
			}
		}
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	
}
