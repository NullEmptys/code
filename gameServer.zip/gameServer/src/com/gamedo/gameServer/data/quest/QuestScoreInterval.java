package com.gamedo.gameServer.data.quest;

/**
 * 任务完成度 分数区间
 * @author libm
 *
 */
public class QuestScoreInterval {

	private int id;
	/**区间ID*/
	private int scoreInterval;
	/**最低分数*/
	private int minScore;
	/**最高分数*/
	private int maxScore;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getScoreInterval() {
		return scoreInterval;
	}

	public void setScoreInterval(int scoreInterval) {
		this.scoreInterval = scoreInterval;
	}

	public int getMinScore() {
		return minScore;
	}

	public void setMinScore(int minScore) {
		this.minScore = minScore;
	}

	public int getMaxScore() {
		return maxScore;
	}

	public void setMaxScore(int maxScore) {
		this.maxScore = maxScore;
	}
	
}
