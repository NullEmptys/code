package com.gamedo.gameServer.data.quest;

/**
 * 任务条件奖励
 * @author libm
 *
 */
public class QuestConditionReward {

	private int id;
	/**
	 * 任务id
	 */
	private int questId;
	/**
	 * 条件组id
	 */
	private int groupId;
	/**
	 * 奖励类型
	 */
	private int rewardType;
	/**
	 * 奖励id
	 */
	private int rewardId;
	/**
	 * 奖励数量
	 */
	private int rewardCounts;
	
	private int cdTimeType;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getQuestId() {
		return questId;
	}

	public void setQuestId(int questId) {
		this.questId = questId;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public int getRewardType() {
		return rewardType;
	}

	public void setRewardType(int rewardType) {
		this.rewardType = rewardType;
	}

	public int getRewardId() {
		return rewardId;
	}

	public void setRewardId(int rewardId) {
		this.rewardId = rewardId;
	}

	public int getRewardCounts() {
		return rewardCounts;
	}

	public void setRewardCounts(int rewardCounts) {
		this.rewardCounts = rewardCounts;
	}

	public int getCdTimeType() {
		return cdTimeType;
	}

	public void setCdTimeType(int cdTimeType) {
		this.cdTimeType = cdTimeType;
	}
	
}
