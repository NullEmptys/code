package com.gamedo.gameServer.data.quest;

/**
 * 任务奖励
 * @author libm
 *
 */
public class QuestReward {

	private int id;
	
	/**任务ID*/
	private int questId;
	/**区间ID*/
	private int scoreInterval;
	/**奖励组ID*/
	private int rewardGroupId;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getQuestId() {
		return questId;
	}
	public void setQuestId(int questId) {
		this.questId = questId;
	}
	public int getScoreInterval() {
		return scoreInterval;
	}
	public void setScoreInterval(int scoreInterval) {
		this.scoreInterval = scoreInterval;
	}
	public int getRewardGroupId() {
		return rewardGroupId;
	}
	public void setRewardGroupId(int rewardGroupId) {
		this.rewardGroupId = rewardGroupId;
	}
}
