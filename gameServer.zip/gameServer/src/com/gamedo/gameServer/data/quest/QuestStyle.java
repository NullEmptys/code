package com.gamedo.gameServer.data.quest;

/**
 * 任务适合风格
 * 任务于风格是一对多的关系
 * @author libm
 *
 */
public class QuestStyle {

	private int id;
	/**任务id*/
	private int questId;
	/**风格id*/
	private int styleId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getQuestId() {
		return questId;
	}

	public void setQuestId(int questId) {
		this.questId = questId;
	}

	public int getStyleId() {
		return styleId;
	}

	public void setStyleId(int styleId) {
		this.styleId = styleId;
	}
	
}
