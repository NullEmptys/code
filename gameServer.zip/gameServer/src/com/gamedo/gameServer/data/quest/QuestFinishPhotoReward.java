package com.gamedo.gameServer.data.quest;

import java.io.Serializable;

public class QuestFinishPhotoReward implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int id;
	private int quality;// 照片的品质4,Profect 3,Good,2 Ok 1,Bad
	private String rewardId;// 奖励id
	private String rewardType;// 奖励类型
	private String rewardNum;// 奖励数量

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getQuality() {
		return quality;
	}

	public void setQuality(int quality) {
		this.quality = quality;
	}

	public String getRewardId() {
		return rewardId;
	}

	public void setRewardId(String rewardId) {
		this.rewardId = rewardId;
	}

	public String getRewardType() {
		return rewardType;
	}

	public void setRewardType(String rewardType) {
		this.rewardType = rewardType;
	}

	public String getRewardNum() {
		return rewardNum;
	}

	public void setRewardNum(String rewardNum) {
		this.rewardNum = rewardNum;
	}
}
