package com.gamedo.gameServer.data.quest;

/**
 * 玩法内心跳值对应奖励数据
 * @author libm
 *
 */
public class HeartBeat {

	private int id;
	
	/**
	 * 心跳数量
	 */
	private int heartCounts;
	
	/**
	 * 货币类型
	 */
	private int currencyType;
	
	/**
	 * 货币数量
	 */
	private int currencyCounts;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getHeartCounts() {
		return heartCounts;
	}

	public void setHeartCounts(int heartCounts) {
		this.heartCounts = heartCounts;
	}

	public int getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	public int getCurrencyCounts() {
		return currencyCounts;
	}

	public void setCurrencyCounts(int currencyCounts) {
		this.currencyCounts = currencyCounts;
	}
	
}
