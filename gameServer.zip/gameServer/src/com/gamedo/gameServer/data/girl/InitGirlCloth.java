package com.gamedo.gameServer.data.girl;

/**
 * 模特初始服装
 * @author libm
 *
 */
public class InitGirlCloth {

	private int id;
	
	private int girlId;
	
	private int clothId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public int getClothId() {
		return clothId;
	}

	public void setClothId(int clothId) {
		this.clothId = clothId;
	}
	
}
