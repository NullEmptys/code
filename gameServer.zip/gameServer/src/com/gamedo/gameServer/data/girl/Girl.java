package com.gamedo.gameServer.data.girl;

import gnu.trove.map.hash.TIntObjectHashMap;

/**
 * 模特数据结构
 * 
 * @author libm
 *
 */
public class Girl {

	private int id;
	/** 名字 */
	private String name;
	/** 头 */
	private String head;
	private String icon;
	/** 描述 */
	private String description;
	/** 脸 */
	private int faceId;
	/** 性格 */
	private String disposition;
	/** 星座 */
	private String constellation;
	/** 血型 */
	private String blood;
	/** 生日 */
	private String birthday;
	/** 三围 */
	private String measurements;
	/** 身高 */
	private String height;
	/** 职业 */
	private String job;
	/** 默认时效时间 */
	private long defaultCdTime;
	private int style;
	/** 最高等级 */
	private int maxLv = 1;
	/** 适应场景*/
	private String adaptSceneStr;
	private String superLoveAttributeStr;
	private String loveAttributeStr;
	private int valid;
	
	public TIntObjectHashMap<Integer> adaptSceneIds = new TIntObjectHashMap<>();
	public TIntObjectHashMap<Integer> superLoveAttributes = new TIntObjectHashMap<>();
	public TIntObjectHashMap<Integer> loveAttributes = new TIntObjectHashMap<>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDisposition() {
		return disposition;
	}

	public void setDisposition(String disposition) {
		this.disposition = disposition;
	}

	public String getConstellation() {
		return constellation;
	}

	public void setConstellation(String constellation) {
		this.constellation = constellation;
	}

	public String getBlood() {
		return blood;
	}

	public void setBlood(String blood) {
		this.blood = blood;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getMeasurements() {
		return measurements;
	}

	public void setMeasurements(String measurements) {
		this.measurements = measurements;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getFaceId() {
		return faceId;
	}

	public void setFaceId(int faceId) {
		this.faceId = faceId;
	}

	public long getDefaultCdTime() {
		return defaultCdTime;
	}

	public void setDefaultCdTime(long defaultCdTime) {
		this.defaultCdTime = defaultCdTime;
	}

	public String getHead() {
		return head;
	}

	public void setHead(String head) {
		this.head = head;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public int getMaxLv() {
		return maxLv;
	}

	public void setMaxLv(int maxLv) {
		this.maxLv = maxLv;
	}

	public int getStyle() {
		return style;
	}

	public void setStyle(int style) {
		this.style = style;
	}

	public String getAdaptSceneStr() {
		return adaptSceneStr;
	}

	public void setAdaptSceneStr(String adaptSceneStr) {
		this.adaptSceneStr = adaptSceneStr;
		parseAdaptSceneStr();
	}

	public String getSuperLoveAttributeStr() {
		return superLoveAttributeStr;
	}

	public void setSuperLoveAttributeStr(String superLoveAttributeStr) {
		this.superLoveAttributeStr = superLoveAttributeStr;
		parseSuperLoveAttributeStr();
	}

	public String getLoveAttributeStr() {
		return loveAttributeStr;
	}

	public void setLoveAttributeStr(String loveAttributeStr) {
		this.loveAttributeStr = loveAttributeStr;
		parseLoveAttributeStr();
	}
	
	public void parseAdaptSceneStr() {
		if(adaptSceneStr != null && !adaptSceneStr.equals("")) {
			String[] sceneIds = adaptSceneStr.split(";");
			if(sceneIds != null && sceneIds.length > 0) {
				for(int i = 0; i < sceneIds.length; i++) {
					if(sceneIds[i] != null) {
						String sceneIdStr = sceneIds[i];
						int sceneId = Integer.parseInt(sceneIdStr);
						this.adaptSceneIds.put(sceneId, sceneId);
					}
				}
			}
		}
	}
	
	public void parseSuperLoveAttributeStr() {
		if(superLoveAttributeStr != null && !superLoveAttributeStr.equals("")) {
			String[] superLoveAttributes = superLoveAttributeStr.split(";");
			if(superLoveAttributes != null && superLoveAttributes.length > 0) {
				for(int i = 0; i < superLoveAttributes.length; i++) {
					if(superLoveAttributes[i] != null) {
						String superAttributeStr = superLoveAttributes[i];
						int superLoveAttributeId = Integer.parseInt(superAttributeStr);
						this.superLoveAttributes.put(superLoveAttributeId, superLoveAttributeId);
					}
				}
			}
		}
	}
	
	public void parseLoveAttributeStr() {
		if(loveAttributeStr != null && !loveAttributeStr.equals("")) {
			String[] loveAttributes = loveAttributeStr.split(";");
			if(loveAttributes != null && loveAttributes.length > 0) {
				for(int i = 0; i < loveAttributes.length; i++) {
					if(loveAttributes[i] != null) {
						String loveAttributeStr = loveAttributes[i];
						int loveAttributeId = Integer.parseInt(loveAttributeStr);
						this.loveAttributes.put(loveAttributeId, loveAttributeId);
					}
				}
			}
		}
	}

	public int getValid() {
		return valid;
	}

	public void setValid(int valid) {
		this.valid = valid;
	}
	
}
