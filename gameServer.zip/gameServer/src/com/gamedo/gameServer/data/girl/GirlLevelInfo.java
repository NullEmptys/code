package com.gamedo.gameServer.data.girl;

/**
 * 模特详细数据表
 * @author liuxing
 *
 */
public class GirlLevelInfo {
	private int id;
	// 模特id
	private int gridId;
	// 模特等级
	private int level;
	// 模特升级所需经验
	private int exp;
	// 货币类型 钻石 金币
	private int currencyType;
	// 消耗货币数量
	private int count;
	//动作组IDs
	private String actionGroupIds;
	//语音组IDs
	private String voiceGroupIds;
	//解锁的服装IDs
	private String equipIds;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGridId() {
		return gridId;
	}

	public void setGridId(int gridId) {
		this.gridId = gridId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}

	public int getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getActionGroupIds() {
		return actionGroupIds;
	}

	public void setActionGroupIds(String actionGroupIds) {
		this.actionGroupIds = actionGroupIds;
	}

	public String getVoiceGroupIds() {
		return voiceGroupIds;
	}

	public void setVoiceGroupIds(String voiceGroupIds) {
		this.voiceGroupIds = voiceGroupIds;
	}

	public String getEquipIds() {
		return equipIds;
	}

	public void setEquipIds(String equipIds) {
		this.equipIds = equipIds;
	}

}
