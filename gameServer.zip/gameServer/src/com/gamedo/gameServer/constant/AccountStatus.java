package com.gamedo.gameServer.constant;

public enum AccountStatus {
	NORMAL(1, "正常"), FORBIT_LOGIN(2, "即将面临封号"), FORBIT_CHAT(3, "角色被禁言");

	private int id;
	private String description;

	private AccountStatus(int id, String description) {
		this.id = id;
		this.description = description;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
