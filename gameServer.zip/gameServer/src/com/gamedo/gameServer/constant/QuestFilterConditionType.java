package com.gamedo.gameServer.constant;

public enum QuestFilterConditionType {

	QUEST_FINISH_COUNT_XIAOYU1(1,"任务完成次数小于1次"),
	QUEST_FINISH_COUNT_XIAOYU10(2,"任务完成次数小于10次"),
	QUEST_FINISH_COUNT_DAYU10_XIAOYU100(3,"任务完成次数大于10次小于100次"),
	QUEST_FINISH_COUNT_DAYU100_XIAOYU200(4,"任务完成次数大于100次小于200次"),
	QUEST_FINISH_COUNT_DAYU200_XIAOYU500(5,"任务完成次数大于200次小于500次"),
	QUEST_FINISH_COUNT_DAYU500(6,"任务完成次数大于500次"),
	HAVE_VIP(7,"有vip"),
	MONGY_DAYU_500(8,"付费货币持有量大于500"),
	MONGY_DAYU_5000(9,"付费货币持有量大于5000"),
	MONGY_XIAOYU_200(10,"付费货币持有量小于200"),
	GIRL_NOT_SIGN_DAYU_3(11,"大于3个模特没在签约状态"),
	QUEST_FINISH_COUNT_1(12,"任务完成次数为1次"),
	QUEST_FINISH_COUNT_2(13,"任务完成次数为2次"),
	QUEST_FINISH_COUNT_3(14,"任务完成次数为3次"),
	QUEST_FINISH_COUNT_4(15,"任务完成次数为4次"),
	QUEST_FINISH_COUNT_DAYU_3_XIAOYU_10(16,"任务完成次数大于3次小于10次"),
	QUEST_FINISH_COUNT_DAYU_DENGYU_10_XIAOYU_20(17,"任务完成次数大于等于10次,小于20次"),
	QUEST_FINISH_COUNT_DAYU_DENGYU_20_XIAOYU_30(18,"任务完成次数大于等于20次，小于30次"),
	QUEST_FINISH_COUNT_DAYU_DENGYU_30_XIAOYU_40(19,"任务完成次数大于等于30次，小于40次"),
	QUEST_FINISH_COUNT_DAYU_DENGYU_40_XIAOYU_50(20,"任务完成次数大于等于40次，小于50次"),
	QUEST_FINISH_COUNT_DAYU_DENGYU_50(21,"任务完成次数大于等于50次");
	
	final int type;
	final String name;

	private QuestFilterConditionType(int type, String name) {
		this.type = type;
		this.name = name;
	}

	public int getType() {
		return type;
	}

	public String getName() {
		return name;
	}

	public static QuestFilterConditionType getCondition(int type) {
		for(QuestFilterConditionType conditionType : QuestFilterConditionType.values()) {
			if(conditionType != null && conditionType.getType() == type) {
				return conditionType;
			}
		}
		return null;
	}
	
}
