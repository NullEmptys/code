package com.gamedo.gameServer.constant;

/**
 * 常量池
 * @author IPOC-HUANGPING
 *
 */
public class Constants {
	public static final int COMMITBUGCOUNT = 3;//最多提交bug次数
	
	public static final int SENDGIFTCOUNT = 6;//最多送礼次数
	
	public static final int NOT_SEND_GIFT = 50;//不送礼权重:策划需求
	
	public static final int GOOD = 70;//送礼好结局权重:策划需求
	
	public static final int BAD = 30;//送礼不好结局权重:策划需求
	
	public static final int RECORD = 1;//记录数据正常
	
	public static final int BUY_TILI_COUNT = 5;//购买体力次数
}
