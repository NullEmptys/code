package com.gamedo.gameServer.constant;

/**
 * 成就类别
 * @author libm
 *
 */
public enum AchieveType {
	
	START_QUEST_COUNTS_ACHIEVE(1,"累计完成摄影玩法次数成就"),
	LOGIN_COUNTS_ACHIEVE(2,"连续登陆天数成就"),
	CONTINU_LOGIN_COUNTS_ACHIEVE(3,"累计登陆天数成就"),
	BUY_TILI_ACHIEVE(4,"累计购买体力次数"),
	BUY_GOLD_COUNTS_ACHIEVE(5,"累计购买金币次数"),
	GAIN_GOLD_COUNTS_ACHIEVE(6,"累计获得金币数量"),
	HEART_BEAT_COUNT_ACHIEVE(7,"累计获得心跳个数"),
	CONTINU_SUCCESS_FINISH_QUEST_ACHIEVE(8,"连续成功完成任务数"),
	USE_GIRL_COUNTS_ACHIEVE(9,"累计使用指定模特摄影次数"),
	USE_SCENE_COUNTS_ACHIEVE(10,"累计使用指定类型场景次数"),
	FAIL_QUEST_COUNTS_ACHIEVE(11,"累计任务失败N次"),
	SIGN_GIRL_COUNTS_ACHIEVE(12,"同时签约模特N个"),
	FINISH_STAR_QUEST_COUNTS_ACHIEVE(13,"累计完成N个指定星级任务"),
	SIGN_FOREVER_GIRL_COUNTS_ACHIEVE(14,"累计签约N个永久时效的模特"),
	CONSUME_MONEY_COUNTS_ACHIEVE(15,"累计消耗钻石数量成就"),
	SEND_GIFT_COUNT_ACHIECE(16,"累计赠送模特X个礼物"),
	ENGAGEMENT_GIRL_ACHIEVE(17,"累计与模特约会X次"),
	ENGAGEMENT_GAME_ACHIEVE(18,"累计完成X约会小游戏"),
	GIRL_XIEZHEN_COUNT_ACHIEVE(19,"累计获得特定模特X个写真or视频or动作"),
	GAIN_CLOTH_ACHIEVE(20,"累计获得X件特定永久服装"),
	BUY_CLOTH_ACHIEVE(21,"累计购买过X件特定服装"),
	CONTINU_BUY_CLOTH_ACHIEVE(22,"连续X天购买服装"),
	COMMENT_DYNAMIC_ACHIEVE(23,"累计评论X条动态"),
	SUPPORT_DYNCMIC_ACHIEVE(24,"累计点赞X次动态"),
	CONTINU_SIGN_COUNTS_ACHIEVE(25,"社交内连续X天签到"),
	CONTINU_COMMENT_DYNAMIC_ACHIEVE(26,"连续X天评论动态"),
	CONTINU_SHARE_DYNAMIC_ACHIEVE(27,"社交内连续X天分享动态"),
	SUPPORT_OTHER_DYNAIC_ACHIEVE(28,"累计点赞X次其他玩家评论"),
	FINISH_QUEST(29,"完成特定任务");
	
	final int type;
	final String desc;
	
	private AchieveType(int type,String desc) {
		this.type = type;
		this.desc = desc;
	}

	public int getType() {
		return type;
	}

	public String getDesc() {
		return desc;
	}
	
}
