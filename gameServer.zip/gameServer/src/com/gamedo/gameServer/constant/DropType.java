package com.gamedo.gameServer.constant;

/**
 * 掉落类型
 * @author libm
 *
 */
public enum DropType {

	DROP_TYPE_ITEM(1, "掉落物品"),

	DROP_TYPE_EQUI(2, "掉落装备"),

	DROP_TYPE_DROPGROUP(3, "掉落一个掉落组"),

	DROP_TYPE_CURRENCY(4, "掉落货币"),

	DROP_TYPE_EXP(5, "掉落经验");

	final int type;

	final String desc;

	private DropType(int type, String desc) {
		this.type = type;
		this.desc = desc;
	}

	public int getType() {
		return type;
	}

	public String getDesc() {
		return desc;
	}

	public static DropType getDropType(int type) {
		for (DropType dropType : DropType.values()) {
			if (dropType != null && dropType.getType() == type) {
				return dropType;
			}
		}
		return null;
	}
}
