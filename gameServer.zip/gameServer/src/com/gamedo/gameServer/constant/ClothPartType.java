package com.gamedo.gameServer.constant;

/**
 * 内外装类型
 * @author libm
 *
 */
public enum ClothPartType {

	DEFAULT(0,"默认穿着"),
	OUT_CLOTH(1,"外装"),
	INSIDE_CLOTH(2,"内装");
	
	final int type;

	final String name;

	private ClothPartType(int type, String name) {
		this.type = type;
		this.name = name;
	}

	public int getType() {
		return type;
	}

	public String getName() {
		return name;
	}
}
