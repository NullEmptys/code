package com.gamedo.gameServer.constant;

/**
 * 属性类型
 * @author libm
 *
 */
public enum AttributeType {

	MONEY(101,"钻石"),
	GOLD(102,"金币"),
	ACTIVITY_COIN(103,"活动币");
	
	final int attributeType;

	final String name;

	private AttributeType(int attributeType, String name) {
		this.attributeType = attributeType;
		this.name = name;
	}

	public int getAttributeType() {
		return attributeType;
	}

	public String getName() {
		return name;
	}

	public static AttributeType getAttrtType(int attributeType) {
		for(AttributeType attriType : AttributeType.values()) {
			if(attriType != null && attriType.getAttributeType() == attributeType) {
				return attriType;
			}
		}
		return null;
	}
	
}
