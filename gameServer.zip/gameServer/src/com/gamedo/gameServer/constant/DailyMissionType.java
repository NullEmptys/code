package com.gamedo.gameServer.constant;
/**
 * 每日任务
 * @author IPOC-HUANGPING
 *
 */
public enum DailyMissionType {
	FINISH_GAME(1,"完成N次游戏"),
	GILD_GIFT(2,"送模特N次礼物"),
	DAILY_GUESS(3,"参与一次猜拳"),
	TAKE_PHOTO(4,"在自由拍摄里拍摄1张照片"),
	GET_TOGETHER(5,"约会1次"),
	GET_GIRL(6,"签约/续约1次模特"),
	BUG_EQUIP(7,"购买2件服装"),
	FINISH_MISSION(8,"完成1个任务"),
	CONSUME_DIAMOND(9,"消耗钻石"),
	CONSUME_GOLE(10,"消耗金币"),
	LOGIN_GAME(11,"登陆游戏"),
	BUY_GOLD(12,"购买金币"),
	BUY_TILI(13,"购买体力"),
	GIRL_TAKE_PHOTO(14,"使用任意模特在任务中拍摄一张照片"),
	ENTER_SOCIAL(15,"进入社交"),
	SEND_DYNAMIC(16,"回复3条动态"),
	SUPPORT(17,"点赞5次"),
	SHARE(18,"分享1次"),
	INVOLMENT_SOCIAL_MISSION(19,"参与一次社交任务"),
	SIGN(20,"签到一次");
	
	private int id;
	private String name;
	
	private DailyMissionType(int id,String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
