package com.gamedo.gameServer.constant;

/**
 * 新手引导
 * @author IPOC-HUANGPING
 *
 */
public enum GuideType {
	GUIDE_ZERO(1000,"入会考核第一关"),
	GUIDE_ONE(1001,"入会考核第二关"),
	GUIDE_TWO(1002,"入会考核第三关"),
	GUIDE_THREE(1003,"入会考核最终关"),
	GUIDE_FOUR(1004,"入会奖励委托");
	
	private int id;
	private String dec;
	
	private GuideType(int id,String dec){
		this.id = id;
		this.dec = dec;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDec() {
		return dec;
	}
	public void setDec(String dec) {
		this.dec = dec;
	}
}
