package com.gamedo.gameServer.constant;

/**
 * 任务分类
 * @author libm
 *
 */
public enum QuestCategory {

	COMMON(1,"日常"),
	
	CHANG_SHANG(3,"厂商"),
	
	SHE_JIAO(2,"社交"),
	
	ZHU_XIAN(0,"主线任务");
	
	final int category;//类型
	final String name;//场景名称
	
	private QuestCategory(int category,String name) {
		this.category = category;
		this.name = name;
	}

	public int getCategory() {
		return category;
	}

	public String getName() {
		return name;
	}
	
	public static QuestCategory getQuestCategory(int category) {
		for(QuestCategory cate : QuestCategory.values()) {
			if(cate != null && cate.getCategory() == category) {
				return cate;
			}
		}
		return null;
	}
}
