package com.gamedo.gameServer.constant;

/**
 * 服装类型
 * @author IPOC-HUANGPING
 *
 */
public enum CloseStyle {
	PURE(0,"清纯"),
	LOLITA(1,"萝莉"),
	WHITE_COLLAR(2,"白领"),
	SPORT(3,"运动"),
	BIG_HONEY(4,"大蜜"),
	HIGHT_COLD(5,"高冷");
	
	private int id;
	private String style;
	
	private CloseStyle(int id,String style){
		this.id = id;
		this.style = style;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
}
