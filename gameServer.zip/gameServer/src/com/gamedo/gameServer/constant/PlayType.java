package com.gamedo.gameServer.constant;

/**
 * 玩法类型
 * @author libm
 *
 */
public enum PlayType {

	CORE_PLAY(1,"核心玩法"),
	
	RFEE_PHOTO(2,"自由摄影");
	
	final int type;
	final String playerName;
	
	private PlayType(int type,String playerName) {
		this.type = type;
		this.playerName = playerName;
	}

	public int getType() {
		return type;
	}

	public String getPlayerName() {
		return playerName;
	}
}
