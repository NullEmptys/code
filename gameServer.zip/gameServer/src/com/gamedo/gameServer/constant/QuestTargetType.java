package com.gamedo.gameServer.constant;

public enum QuestTargetType {

	CHANGE_GIRL(1,"换人"),
	CHANGE_CLOTH(2,"换装"),
	CHANGE_SCENE(3,"换场景"),
	SHOOT(4,"拍摄"),
	SHARE_DYNAMIC(5,"分享动态"),
	COMMENT_DYNAMIC(6,"评论动态"),
	SUPPORT_DYNAMIC(7,"点赞动态"),
	SEND_GIFT(8,"赠送礼物"),
	SHOOT_GIRL(9,"拍摄模特"),
	PLAY_GAME(10,"玩小游戏");
	
	final int type;
	final String name;
	
	private QuestTargetType (int type,String name) {
		this.type = type;
		this.name = name;
	}

	public int getType() {
		return type;
	}

	public String getName() {
		return name;
	}
	
	public static QuestTargetType getQuestTargetType(int targetType) {
		for(QuestTargetType questTargetType : QuestTargetType.values()) {
			if(questTargetType != null && questTargetType.getType() == targetType) {
				return questTargetType;
			}
		}
		return null;
	}
}
