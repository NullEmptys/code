package com.gamedo.gameServer.constant;

public enum BuyType {
	BUY_TILI(1,"购买体力"),
	BUY_GOLD(2,"购买金币");
	
	private int id;
	private String desc;
	
	private BuyType(int id,String desc){
		this.id = id;
		this.desc = desc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
}
