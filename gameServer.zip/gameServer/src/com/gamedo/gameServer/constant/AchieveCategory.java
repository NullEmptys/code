package com.gamedo.gameServer.constant;

/**
 * 成就大分类
 * @author libm
 *
 */
public enum AchieveCategory {

	PHOTOGRAPH(1,"我的摄影"),
	GROW_UP(2,"我的成长"),
	COLLECT(3,"我的收藏"),
	SOCIALITY(4,"我的社交"),
	OHTER(5,"其他");
	
	final int category;
	final String name;
	
	private AchieveCategory(int category,String name) {
		this.category = category;
		this.name = name;
	}

	public int getCategory() {
		return category;
	}

	public String getName() {
		return name;
	}
	
}
