package com.gamedo.gameServer.constant;

/**
 * 任务难度类型
 * @author libm
 *
 */
public enum QuestType {

	SIMPLE(0,"简单"),
	COMMON(1,"普通"),
	HARD(2,"困难");
	
	final int type;//类型
	final String name;//场景名称
	
	private QuestType(int type,String name) {
		this.type = type;
		this.name = name;
	}

	public int getType() {
		return type;
	}

	public String getName() {
		return name;
	}
	
}
