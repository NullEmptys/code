package com.gamedo.gameServer.core.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import com.gamedo.gameServer.core.Time;
import com.gamedo.gameServer.core.Updatable;
import com.gamedo.gameServer.core.Updater;

/**
 * 
 * @author libm
 *
 */
@Component
public class SimpleUpdater implements Updater,Runnable {

	protected static final Logger log = LoggerFactory.getLogger(SimpleUpdater.class);

	protected List<Updatable> asyncUpdatables = new ArrayList<Updatable>();
	protected CopyOnWriteArrayList<Updatable> syncUpdatables = new CopyOnWriteArrayList<Updatable>();
	protected ArrayBlockingQueue<Runnable> syncRunnables = new ArrayBlockingQueue<Runnable>(2048);
	
	protected int lastAsyncSize = 0;

	protected volatile SimpleCountDownLatch latch = null;
	
	boolean running = true;
	int currentTime;
	public static int CYCLE_TIME = 80;
	
	@Autowired
	private Time time;
	private static int serverId;//服务器id
	private static SimpleUpdater instance;
	
	private SimpleUpdater() {
		
	}

	@PostConstruct
	public void start() {
		WebApplicationContext webApplicationContext = ContextLoader.getCurrentWebApplicationContext();  
        ServletContext servletContext = webApplicationContext.getServletContext();  
        serverId = Integer.parseInt(servletContext.getInitParameter("serverId"));
        new Thread(this,"Updater-Sync").start();
        instance = this;
	}
	
	public static SimpleUpdater getInstance() {
		return instance;
	}
	
	public int getServerId(){
		return serverId;
	}
	@Override
	public void addAsyncUpdatable(Updatable updatable) {
		AsyncRunner au = new AsyncRunner(updatable);
		Thread t = new Thread(au, "Updater-Async-" + asyncUpdatables.size());
		t.setPriority(Thread.NORM_PRIORITY + 3);
		t.start();
		asyncUpdatables.add(au);
	}

	@Override
	public synchronized void addSyncUpdatable(Updatable updatable) {
		syncUpdatables.add(updatable);
	}

	/**
	 * 加入一个Runnable对象在主线程队列中，此方法是 线程安全的，可以在任意线程添加
	 * 
	 * @param runnable
	 */
	public void addTempSyncRunnable(Runnable runnable) {
		syncRunnables.offer(runnable);
	}

	@Override
	public void update() {
		int size = asyncUpdatables.size();
		if (size > 0) {
			latch = new SimpleCountDownLatch(size);
			for (int i = 0; i < size; i++) {
				asyncUpdatables.get(i).update();
			}
			try {
				latch.await(10000);
			} catch (InterruptedException e1) {
				log.error(e1.toString(), e1);
				return;
			}
		}
		try {
			Iterator<Updatable> iterator = syncUpdatables.iterator();
			while(iterator.hasNext()) {
				Updatable u = iterator.next();
				if(u != null) {
					u.update();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Runnable runnable = null;
		while ((runnable = syncRunnables.poll()) != null) {
			try {
				runnable.run();
			} catch (Exception e) {
				log.error(e.toString(), e);
			}
		}
	}

	class AsyncRunner implements Runnable, Updatable {

		protected Updatable updatable;

		public AsyncRunner(Updatable updatable) {
			this.updatable = updatable;

		}

		public boolean update() {
			synchronized (this) {
				notify();
				return true;
			}
		}

		@Override
		public void run() {
			while (true) {
				synchronized (this) {
					try {
						wait();
					} catch (InterruptedException e) {
						log.error(e.toString(), e);
						break;
					}
				}
				try {
					// long t1 = System.nanoTime();
					updatable.update();
					// long t2 = System.nanoTime();
					// long el3 = (t2 - t1) / 1000000;

					// if( el3 > 50){
					// log.info("Updater too
					// long["+el3+"]["+updatable.getClass()+"]");
					// }
				} catch (Throwable e) {
					log.error(e.toString(), e);
				} finally {
					latch.countDown();
				}
			}
		}
	}

	/**
	 * 替代J2SE的CountDownLatch实现，避免出现扣不正确的情况。
	 * 
	 */
	class SimpleCountDownLatch {
		private int remain;

		public SimpleCountDownLatch(int count) {
			remain = count;
		}

		public synchronized void await(long timeout) throws InterruptedException {
			if (remain > 0) {
				wait(timeout);
			}
		}

		public synchronized void countDown() {
			remain--;
			if (remain <= 0) {
				notifyAll();
			}
		}
	}

	@Override
	public void run() {
		long preTime = Time.currTime;
		while (running) {
			time.update();
			currentTime = Time.currTime;
			int diff = (int) (currentTime - preTime);
			if (diff > 100) {
//				log.info("Cycle too long:" + diff);
			}
			try {
				update();
			} catch (Throwable e1) {
				log.error(e1.toString(), e1);
			}
			preTime = currentTime;
			long t = time.update();
			if (t < CYCLE_TIME) {
				try {
					Thread.sleep(CYCLE_TIME - t);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
