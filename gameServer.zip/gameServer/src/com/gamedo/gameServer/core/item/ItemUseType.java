package com.gamedo.gameServer.core.item;

import java.io.Serializable;

import com.gamedo.gameServer.core.ItemEffect;

/**
 * 
 * @author libm
 *
 */
public class ItemUseType implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2632897083952975246L;
	
	public static final int OCCASION_NOBATTLE = 1;
	public static final int OCCASION_BATTLE = 2;
	public static final int OCCASION_ALL = 3;
	
	public static final int TARGET_NOTARGET = 0;
	public static final int TARGET_SELF = 1;
	public static final int TARGET_PARTY = 2;
	public static final int TARGET_ENEMY = 4;
	public static final int TARGET_ALL = 7;
	
	public boolean canUse;
	public boolean autoUse;
	public int clazz;

	/**
	 * 使用环境
	 */
	public int occasion;
	public int targetType;
	/**
	 * 使用后是否消失
	 */
	public boolean consume;
	/**
	 * 施法时间
	 */
	public int spellTime;
	public int[] coolDownId;
	public int coolDownTime;
	public int distance;
	public ItemEffect itemEffect;
	/**
	 * 確認字符串
	 */
	public String confirmString;
	
	public static final ItemUseType NOUSETYPE = new ItemUseType(false);
	
	protected ItemUseType(boolean canUse){
		this.canUse = canUse;
	}
	
	public ItemUseType(){
		canUse = true;
	}
}
