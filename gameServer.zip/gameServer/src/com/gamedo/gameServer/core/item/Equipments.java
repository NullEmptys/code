package com.gamedo.gameServer.core.item;

/**
 * 
 * @author libm
 *
 */
public interface Equipments {

	public void equ(int type,int index,Equipment item, Equipment unEqu);
	
	public Equipment unEqu(int type,int index);
	
	public Equipment getEquipment(int type,int index);
	
	public int getSize();
}
