package com.gamedo.gameServer.core.item;

/**
 * 
 * @author libm
 *
 */
public class DefaultEquipTemplate extends DefaultItemTemplate implements EquipmentTemplate{

	int mapperEquipId;
	
	public DefaultEquipTemplate(int id) {
		super(id);
	}

	public void setMapperEquipId(int mapperEquipId) {
		this.mapperEquipId = mapperEquipId;
	}

	@Override
	public int getMapperEquipId() {
		return mapperEquipId;
	}

	
}
