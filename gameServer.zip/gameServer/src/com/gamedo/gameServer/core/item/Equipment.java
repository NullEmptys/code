package com.gamedo.gameServer.core.item;

/**
 * 
 * @author libm
 *
 */
public class Equipment extends BaseItem{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7866147819965647245L;

	/**
	 * 是否使用套装的头发
	 */
	private boolean isUseThisHair;
	
	public Equipment(ItemTemplate template, long id, int instanceId, long createTimeStamp) {
		super(template, id, instanceId, createTimeStamp);
	}

	public EquipmentTemplate getTemplate(){
		return (EquipmentTemplate)super.getTemplate();
	}

	public boolean getIsUseThisHair() {
		return isUseThisHair;
	}

	public void setIsUseThisHair(boolean isUseThisHair) {
		this.isUseThisHair = isUseThisHair;
	}
	
	
}
