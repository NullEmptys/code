package com.gamedo.gameServer.core.item;

import java.io.Serializable;

/**
 * 
 * @author libm
 *
 */
public class DefaultItemTemplate implements ItemTemplate,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8803128818550931442L;
	
	String desc;
	int category;
	int type;
	String icon;
	int id;
	int level;
	int addition;
	String name;
	int currencyType;
	int price;
	int quality;
	int useLevel;
	ItemUseType useType;
	boolean isQuestItem;
	boolean newInstance;
	boolean canDelete;//是否可丢弃
	boolean canSell;//是否可出售
	boolean canAddition;
	
	public DefaultItemTemplate(int id){
		this.id = id;
	}
	
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int cate) {
		category = cate;
	}
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public int getId() {
		return id;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getAddition() {
		return addition;
	}
	public void setAddition(int addition) {
		this.addition = addition;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuality() {
		return quality;
	}
	public void setQuality(int quality) {
		this.quality = quality;
	}
	public int getUseLevel() {
		return useLevel;
	}
	public void setUseLevel(int useLevel) {
		this.useLevel = useLevel;
	}
	public ItemUseType getUseType() {
		return useType;
	}
	public void setUseType(ItemUseType useType) {
		this.useType = useType;
	}
	public boolean isQuestItem() {
		return isQuestItem;
	}
	public void setQuestItem(boolean isQuestItem) {
		this.isQuestItem = isQuestItem;
	}
	public boolean isNewInstance() {
		return newInstance;
	}
	public void setNewInstance(boolean newInstance) {
		this.newInstance = newInstance;
	}
	
	@Override
	public boolean hasEffect() {
		return false;
	}

	public boolean isCanDelete() {
		return canDelete;
	}

	public void setCanDelete(boolean canDelete) {
		this.canDelete = canDelete;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	@Override
	public int currencyType() {
		return currencyType;
	}

	public void setCanSell(boolean canSell) {
		this.canSell = canSell;
	}

	@Override
	public boolean canDelete() {
		return canDelete;
	}

	@Override
	public boolean canSell() {
		return canSell;
	}

	@Override
	public boolean canAddition() {
		return canAddition;
	}

	public void setCanAddition(boolean canAddition) {
		this.canAddition = canAddition;
	}
	
}
