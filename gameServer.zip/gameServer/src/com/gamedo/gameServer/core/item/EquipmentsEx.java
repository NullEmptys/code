package com.gamedo.gameServer.core.item;

import java.io.Serializable;
import java.util.concurrent.ConcurrentHashMap;

import com.gamedo.gameServer.constant.ClothPartType;
import com.gamedo.gameServer.entity.player.PlayerGirl;

/**
 * 
 * @author libm
 *
 */
public class EquipmentsEx implements Equipments,Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5900818595038913008L;
	
	public static final int MAX_EQU      = 15;
	/**
	 * 模特各玩法对应所穿服装数据
	 */
	protected ConcurrentHashMap<Integer, Equipment[]> equs;
	protected PlayerGirl owner;
	
	@Override
	public void equ(int type,int index, Equipment equ, Equipment unEqu) {
		if(equ==null)
			throw new IllegalArgumentException();
		equs.get(type)[index] = equ;
	}

	@Override
	public Equipment unEqu(int type,int index) {
		Equipment equ = equs.get(type)[index];
		if(equ != null) {
			equs.get(type)[index] = null;
		}
		return equ;
	}

	public EquipmentsEx(PlayerGirl owner) {
		this.owner = owner;
		ConcurrentHashMap<Integer, Equipment[]> maps = new ConcurrentHashMap<>();
		for(ClothPartType type : ClothPartType.values()) {
			if(type != null) {
				Equipment[] equipment = new Equipment[MAX_EQU];
				maps.put(type.getType(), equipment);
			}
		}
		this.equs = maps;
	}

	@Override
	public Equipment getEquipment(int type,int index) {
		return equs.get(type)[index];
	}
	
	public EquipmentsEx clone(){
		EquipmentsEx c = new EquipmentsEx(owner);
		c.equs = equs;
		return c;
	}

	@Override
	public int getSize() {
		return equs.size();
	}
	
	public Equipment[] getEquipsByType(int type){
		return equs.get(type);
	}

	public ConcurrentHashMap<Integer, Equipment[]> getEquips() {
		return equs;
	}
}
