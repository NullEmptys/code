package com.gamedo.gameServer.core.item;

import java.io.Serializable;

import com.gamedo.gameServer.core.GameObject;
import com.gamedo.gameServer.core.GameObjectRef;

/**
 * 
 * @author libm
 *
 */
public class BaseItem implements GameItem,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7355801496693066179L;
	
	protected ItemTemplate template;
	protected long id;
	protected int instanceId;
	protected long createTimeStamp;
	protected GameItemObject object;
	protected long obsoleteTime = -1;
	
	public BaseItem(ItemTemplate template, long id, int instanceId,long createTimeStamp){
		this.template = template;
		this.id = id;
		this.instanceId = instanceId;
		this.createTimeStamp = createTimeStamp;
	}
	
	public long getId() {
		return this.id;
	}	
	

	public int getInstanceId() {
		return instanceId;
	}

	public String getName() {
		return template.getName();
	}

	public GameObjectRef ref() {
		return null;
	}
	
	@Override
	public long getCreateTime() {
		return createTimeStamp;
	}

	@Override
	public String getDesc() {
		if(null != object){
			String desc = object.getDesc();
			if(null != desc){
				return desc;
			}
		}
		return template.getDesc();
	}

	@Override
	public ItemTemplate getTemplate() {
		return template;
	}

	@Override
	public int getPrice() {
		return template.getPrice();
	}

	@Override
	public int getQuality() {
		return template.getQuality();
	}

	public boolean equals(Object obj) {
		BaseItem bi = (BaseItem)obj;
		if(bi.instanceId == this.instanceId &&
				bi.getTemplate() == this.getTemplate()) {
			return true;
		}
			
		return false;
	}
	
	@Override
	public GameItemObject getGameItemObject(){
		return object;
	}
	
	public int getType(){
		return GameObject.TYPE_ITEM;
	}
	
	@Override
	public BaseItem clone(){
		BaseItem ret = new BaseItem(template,id,instanceId,createTimeStamp);
		if(object!=null){
			ret.object = object.clone();
		}
		ret.obsoleteTime = obsoleteTime;
		return ret;
	}

	public void setGameItemObject(GameItemObject object) {
		this.object = object;
	}
	
	public long getObsoleteTime(){
		return this.obsoleteTime;
	}
	
	public void setObsoleteTime(long obsoleteTime){
		this.obsoleteTime = obsoleteTime;
	}
}
