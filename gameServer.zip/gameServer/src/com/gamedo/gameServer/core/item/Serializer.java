package com.gamedo.gameServer.core.item;

import com.gamedo.gameServer.exception.PersistenceException;

/**
 * 
 * @author libm
 *
 */
public interface Serializer {

	public int getId();

	public byte[] serialize(GameItemObject o) throws PersistenceException;
}
