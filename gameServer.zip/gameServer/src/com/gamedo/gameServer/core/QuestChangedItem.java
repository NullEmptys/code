package com.gamedo.gameServer.core;

import java.io.Serializable;

import com.gamedo.gameServer.entity.quest.PlayerQuest;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.QuestUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

/**
 * 
 * @author libm
 *
 */
public class QuestChangedItem extends ChangedItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9122357823753092400L;

	protected PlayerQuest playerQuest;
	
	public QuestChangedItem(PlayerQuest playerQuest) {
		super(TYPE_QUEST,0,false);
		this.playerQuest = playerQuest;
	}
	
	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		
	}

	@Override
	public UpdateObject pack() {
		QuestUpdateObject updateObject = new QuestUpdateObject();
		updateObject.setType(ChangedItem.TYPE_QUEST);
		updateObject.setQuestId(playerQuest.getQuestId());
		updateObject.setId(super.getId());
		updateObject.setState(playerQuest.getState());
		return updateObject;
	}

}
