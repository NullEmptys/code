package com.gamedo.gameServer.core.dailymission;

import java.io.Serializable;

import com.gamedo.gameServer.core.ChangedItem;
import com.gamedo.gameServer.entity.dailymission.PlayerDailyMission;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.DailyMissionUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;
/**
 * 每日任务变化数据
 * @author IPOC-HUANGPING
 *
 */
public class DailyMissionChanged extends ChangedItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5778196651565361283L;
	private int missionDefineId;//任务id
	private int missionDetail;//任务完成次数
	private int status;//任务状态
	
	public DailyMissionChanged(int missId,int detail,int status){
		this.type = TUPE_DAILY_MISSION;
		this.missionDefineId = missId;
		this.missionDetail = detail;
		this.status = status;
	}
	public DailyMissionChanged(PlayerDailyMission playerDailyMission){
		this.type = TUPE_DAILY_MISSION;
		this.missionDefineId = playerDailyMission.getMissionDefineId();
		this.missionDetail = playerDailyMission.getMissionDetail();
		this.status = playerDailyMission.getStatus();
	}
	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public UpdateObject pack() {
		DailyMissionUpdateObject dailyUpdate = new DailyMissionUpdateObject();
		dailyUpdate.setType(this.type);
		dailyUpdate.setMissionDefineId(missionDefineId);
		dailyUpdate.setMissionDetail(missionDetail);
		dailyUpdate.setStatus(status);
		return dailyUpdate;
	}
}
