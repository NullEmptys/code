package com.gamedo.gameServer.core;

/**
 * 
 * @author libm
 *
 */
public interface ThreadPool {

	public void execute(Runnable call);
}
