package com.gamedo.gameServer.core;


/**
 * 基本游戏单位类
 * @author libm
 *
 */
public class BaseUnit {

}
