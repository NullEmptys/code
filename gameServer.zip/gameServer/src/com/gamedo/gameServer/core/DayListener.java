package com.gamedo.gameServer.core;

/**
 * 
 * @author libm
 *
 */
public interface DayListener {

	public void dayChanged();
	
}
