package com.gamedo.gameServer.core;

import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.core.transaction.Transaction;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.exception.ValueLimitException;

/**
 * 
 * @author libm
 *
 */
public abstract class TransactionIntProperty {

	protected int wantAddValue;
	protected int wantDecValue;

	public abstract int getValue();
	
	public abstract int getMaxValue();
	
	public synchronized void addWithoutLimit(int value, PlayerTransaction tx, boolean notify){
		if (value < 0)
			throw new IllegalArgumentException();
		if (getValue() + wantAddValue + value < 0)
			throw new IllegalArgumentException();
		this.wantAddValue += value;
		IntPropertyTransactionEntity entity = new IntPropertyTransactionEntity(
				tx, this, value, notify);
		tx.addEntity(entity);
	}
	
	/**
	 * 尽量加，超过上限的那部分忽略
	 * @param value
	 * @param tx
	 * @param notify
	 */
	public synchronized void addWithoutException(int value, PlayerTransaction tx, boolean notify) {
		if (value < 0)
			throw new IllegalArgumentException();
		if(getValue() + wantAddValue + value < 0)
			throw new IllegalArgumentException();
		value  = Math.min(getMaxValue() - getValue() - this.wantAddValue, value);
		this.wantAddValue += value;
		IntPropertyTransactionEntity entity = new IntPropertyTransactionEntity(
				tx, this, value, notify);
		tx.addEntity(entity);
	}
	
	public synchronized void add(int value, PlayerTransaction tx, boolean notify) throws ValueLimitException{
		if (value < 0)
			throw new IllegalArgumentException();
		if(getValue() + wantAddValue + value < 0)
			throw new IllegalArgumentException();
		if(getValue() + this.wantAddValue +  value > getMaxValue())
			throw new ValueLimitException();
		this.wantAddValue += value;
		IntPropertyTransactionEntity entity = new IntPropertyTransactionEntity(
				tx, this, value, notify);
		tx.addEntity(entity);
	}
	
	
	
	/**
	 * 尽量扣除剩余值，如果剩余值不够扣就扣到0，返回扣除的值
	 * @param value
	 * @param tx
	 * @param notify
	 * @return
	 */
	public synchronized int decWithoutException(int value, PlayerTransaction  tx, boolean notify){
		if(value < 0)
			throw new IllegalArgumentException();
		int leftValue  = getValue() - wantDecValue;
		int decValue = leftValue > value ? value : leftValue;
		this.wantDecValue += decValue;
		IntPropertyTransactionEntity entity = new IntPropertyTransactionEntity(
				tx, this, -decValue, notify);
		tx.addEntity(entity);
		return decValue;
	}
	

	public synchronized void dec(int value, PlayerTransaction tx, boolean notify)
			throws NoEnoughValueException {
		if (value < 0)
			throw new IllegalArgumentException();
		if ((getValue() - wantDecValue) < value) {
			throw new NoEnoughValueException();
		}
		this.wantDecValue += value;
		IntPropertyTransactionEntity entity = new IntPropertyTransactionEntity(
				tx, this, -value, notify);
		tx.addEntity(entity);
	}

	public synchronized void release(Transaction tx, IntPropertyTransactionEntity entity, boolean commit) {
		if(commit){
			if (entity.value > 0) {
				modifyValue(entity.value,entity.notify,tx.getCause());
				wantAddValue -= entity.value;
			} else {
				modifyValue(entity.value,entity.notify,tx.getCause());
				wantDecValue += entity.value;
			}
		}else{
			if (entity.value > 0) {
				wantAddValue -= entity.value;
			} else {
				wantDecValue += entity.value;
			}
		}
	}
	
	/**
	 * 修改真实值 
	 * @param value 如果大于0是添加，否则是减少
	 */
	protected abstract void modifyValue(int value,boolean notify,String cause);
}
