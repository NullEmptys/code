package com.gamedo.gameServer.core;

/**
 * 游戏对象类
 * 只要在游戏中，有Id，Name的对象都可以认为是一个游戏对象，包括npc，人物，物品，装备等等\n
 * @author libm
 *
 */
public interface GameObject {

	public static final int TYPE_PLAYER = 1; //玩家
	public static final int TYPE_CREATURE = 2; //npc
	public static final int TYPE_ITEM = 3;//物品包括装备

	/** 
	 * @brief 获取ID 
	 * @param null
	 * @return 返回GameObject Id ,类型long
	 */
	public int getId();
	
	/** 
	 * @brief 获取名字 
	 * @param null
	 * @return 返回名字 ,类型String
	 */
	public String getName();
	
	/** 
	 * @brief  获取对象引用
	 * @param  null
	 * @return 返回GameObjectRef
	 */
	public GameObjectRef ref();
	
	/** 
	 * @brief  获取GameObject类型
	 * @param  null
	 * @return 返回GameObject类型类型 , 类型int
	 * @note   GameObject 的类型，服务器保留0~32,扩展系统请从33以后定义
	 */
	public int getType();
}
