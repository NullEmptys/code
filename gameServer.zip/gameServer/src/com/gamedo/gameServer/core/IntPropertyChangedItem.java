package com.gamedo.gameServer.core;

import java.io.Serializable;

import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.IntPropertyUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

/**
 * 
 * @author libm
 *
 */
public class IntPropertyChangedItem extends ChangedItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3199757030646602435L;
	protected int value;
	protected boolean overwrite;
	protected boolean broadcast;
	
	public IntPropertyChangedItem(int id,int value,boolean notify){
		this(id,value,notify,false);
	}
	
	/**
	 * 
	 * @param id
	 * @param value 
	 * @param notify
	 * @param overwrite merge策略是覆盖还是添加
	 */
	public IntPropertyChangedItem(int id,int value,boolean notify,boolean overwrite){
		this(id,value,notify,overwrite,false);
	}
	
	public IntPropertyChangedItem(int id,int value,boolean notify,boolean overwrite,boolean broadcast){
		super(TYPE_INT,id,notify);
		this.value = value;
		this.overwrite = overwrite;
		this.broadcast = broadcast;
	}
	
	@Override
	public boolean merge(ChangedItem other){
		if(other instanceof IntPropertyChangedItem){
			if(notify==other.notify&&id==other.id){
				if(overwrite){
					value = ((IntPropertyChangedItem)other).value;
				}else{
					value += ((IntPropertyChangedItem)other).value;
				}
				return true;
			}else{
				return false;
			}
		}else
			return false;
	}
	
	@Override
	public UpdateObject pack() {
		IntPropertyUpdateObject obj = new IntPropertyUpdateObject();
		obj.setId(id);
		obj.setType(type);
		obj.setValue(value);
		return obj;
	}
	
	public boolean isBroadcast(){
		return broadcast;
	}
	
	public void makeBroadcastPacket(Packet pt){
		
	}

}
