package com.gamedo.gameServer.core;

import java.io.Serializable;

import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.player.NewEngagementData;
import com.gamedo.gameServer.update.NewEngagementUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

public class NewEngagementChangedItem extends ChangedItem implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5557139418602681648L;

	public NewEngagementData newEngagementData;
	
	public NewEngagementChangedItem(NewEngagementData newEngagementData) {
		this.newEngagementData = newEngagementData;
	}
	
	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		
	}

	@Override
	public UpdateObject pack() {
		NewEngagementUpdateObject object = new NewEngagementUpdateObject();
		object.setType(TYPE_NEW_ENGAGEMENT);
		object.setSceneId(newEngagementData.getSceneId());
		object.setEngagementGirlId(newEngagementData.getEngagementGirlId());
		object.setDatingStep(newEngagementData.getDatingStep());
		object.setDatingPlotId(newEngagementData.getDatingPlotId());
		object.setCurGameId(newEngagementData.getCurGameId());
		object.setSendGiftCounts(newEngagementData.getSendGiftCounts());
		object.setMaxGiftCounts(newEngagementData.getMaxGiftCounts());
		object.setGuessCounts(newEngagementData.getMoodValues());
		object.setMaxGuessCounts(newEngagementData.getNewFinishSendGiftstate());
		return object;
	}

}
