package com.gamedo.gameServer.core.bag;

import java.io.Serializable;

import com.gamedo.gameServer.core.ChangedItem;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.PlayerGirlBagItemUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

/**
 * 模特背包改变
 * @author libm
 *
 */
public class GirlBagChangedItem extends BagChangedItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1748735804805285109L;

	protected int girlId;
	protected int itemId;
	protected int instanceId;
	protected GameItem item;
	protected int count;
	protected BagGrid grid;
	
	public GirlBagChangedItem(BagGrid grid,int girlId) {
		this.type = ChangedItem.TYPE_PLAYERGIRL_BAG;
		this.id = ChangedItem.PLAYER_GIRL_BAG_CDTIME;
		this.grid = grid;
		if(this.grid.item != null) {
			this.item = this.grid.item;
			this.itemId = this.grid.item.getTemplate().getId();
			this.instanceId = this.grid.item.getInstanceId();
			this.count = grid.count;
		}
		this.girlId = girlId;
	}
	
	@Override
	public boolean merge(ChangedItem other) {
		if(other instanceof GirlBagChangedItem){
			if(notify==other.notify){
				GirlBagChangedItem o = (GirlBagChangedItem)other;
				if(notify){
					if(item.equals(o.item)){
						item.setObsoleteTime(o.item.getObsoleteTime());
						return true;
					}
					return false;
				}else{
					if(grid.bag.getClass() == o.grid.bag.getClass() && grid.id==o.grid.id && grid.bag.id==o.grid.bag.id){
						grid = o.grid;
						return true;
					}
					return false;
				}
			}else{
				return false;
			}
		}else
			return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		
	}
	
	public BagGrid getGrid() {
		return grid;
	}

	@Override
	public UpdateObject pack() {
		PlayerGirlBagItemUpdateObject object = new PlayerGirlBagItemUpdateObject();
		object.setType(ChangedItem.TYPE_PLAYERGIRL_BAG);
		object.setBagId(grid.bag.id);
		object.setId(this.id);
		object.setGirlId(girlId);
		object.setGridId(grid.id);
		object.setItemId(itemId);
		object.setInstanceId(instanceId);
		if(item != null) {
			object.setCdTime(item.getObsoleteTime());
		}
		object.setCount(count);
		return object;
	}
	
}
