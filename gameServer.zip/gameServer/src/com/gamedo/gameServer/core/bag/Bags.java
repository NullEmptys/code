package com.gamedo.gameServer.core.bag;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.gamedo.gameServer.constant.ItemCategory;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.item.DefaultItemTemplate;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.item.ItemTemplate;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.NoEnoughSpaceException;
import com.gamedo.gameServer.log.Log;
import com.gamedo.gameServer.service.data.ItemService;

/**
 * lovelive背包类
 * @author libm
 *
 */
public class Bags implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6371622287926209435L;
	
	List<Bag> bags;
	Player owner;
	int type;
	
	public Bags(Player owner,int size,int type){
		this.owner = owner;
		this.type = type;
		bags = new ArrayList<Bag>(size);
	}
	
	public Bag getBag(int id){
		for(Bag bag : bags) {
			if(bag!= null && bag.id == id) {
				return bag;
			}
		}
		return null;
	}
	
	public int getSize(){
		return bags.size();
	}
	
	public void addBag(Bag bag){
		bags.add(bag);
	}
	
	public Player getOwner(){
		return owner;
	}
	
	public int getType() {
		return type;
	}

	/**
	 * 添加可叠加的道具
	 * @param itemId
	 * @param count
	 * @param cause
	 */
	public void addItem(int itemId, int count,String cause){
		ItemService itemService = ItemService.getInstance();
		ItemTemplate temp1 = itemService.getItemTemplate(itemId);
		GameItem gi1 = itemService.createGameItem(temp1);
		gi1.setObsoleteTime(-1);
		PlayerTransaction transaction = owner.newTransaction("addItem: "+cause);
		addGameItem(gi1, count, transaction, false);
		transaction.commit();
		EventManager.getInstance().addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_GAIN_ITEM, owner,itemId,temp1.getName(),count,cause));
	}
	
	/**
	 * 添加带时效的服装 
	 * 叠加时效
	 * @param itemId 物品id
	 * @param count  数量
	 * @param cause  原因
	 * @param cdTime 失效截止时间  -1、永久     0、失效      >0有效时间
	 */
	public void addItem(int itemId, int count,String cause,long cdTime) {
		ItemService itemService = ItemService.getInstance();
		ItemTemplate temp1 = itemService.getItemTemplate(itemId);
		if(temp1.getCategory() != ItemCategory.CONSUME.getItemCategory()) {
			GameItem gi = owner.getBags().getGameItem(itemId);
			if(gi == null) {
				gi = itemService.createGameItem(temp1);
				if(cdTime != -1) {
					gi.setObsoleteTime(System.currentTimeMillis() + cdTime * count);
				}else {
					gi.setObsoleteTime(cdTime);
				}
				PlayerTransaction transaction = owner.newTransaction("addItem: "+cause);
				addGameItem(gi, count, transaction, false);
				transaction.commit();
				EventManager.getInstance().addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_GAIN_ITEM, owner,itemId,gi.getTemplate().getName(),count,cause + ",cdTime = " + cdTime));
			}else {
				if(gi.getObsoleteTime() != -1) {
					if(cdTime != -1) {
						gi.setObsoleteTime(gi.getObsoleteTime() + cdTime * count);
					}else {
						gi.setObsoleteTime(cdTime);
					}
					BagGrid bagGrid = owner.getBags().getGameItemBagGrid(itemId);
					if(bagGrid != null) {
						BagChangedItem changedItem = new BagChangedItem(bagGrid);
						owner.changed.addChangedItem(changedItem);
					}
					EventManager.getInstance().addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_GAIN_ITEM, owner,itemId,gi.getTemplate().getName(),count,cause + ",cdTime = " + cdTime));
				}
			}
		}else {
			GameItem gi1 = itemService.createGameItem(temp1);
			PlayerTransaction transaction = owner.newTransaction("addItem: "+cause);
			addGameItem(gi1, count, transaction, false);
			transaction.commit();
			EventManager.getInstance().addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_GAIN_ITEM, owner,itemId,gi1.getName(),count,cause));
		}
	}
	
	/**
	 * GM后台专用
	 * 添加带时效的服装 
	 * 叠加时效
	 * @param itemId 物品id
	 * @param count  数量
	 * @param cause  原因
	 * @param cdTime 失效截止时间  -1、永久     0、失效      >0有效时间
	 */
	public void gmAddItem(int itemId, int count,String cause,long cdTime) {
		ItemService itemService = ItemService.getInstance();
		ItemTemplate temp1 = itemService.getItemTemplate(itemId);
		if(temp1.getCategory() != ItemCategory.CONSUME.getItemCategory()) {
			GameItem gi = owner.getBags().getGameItem(itemId);
			if(gi == null) {
				gi = itemService.createGameItem(temp1);
				gi.setObsoleteTime(cdTime);
				PlayerTransaction transaction = owner.newTransaction("addItem: "+cause);
				addGameItem(gi, count, transaction, false);
				transaction.commit();
				EventManager.getInstance().addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_GAIN_ITEM, owner,itemId,gi.getTemplate().getName(),count,cause + ",cdTime = " + cdTime));
			}
		}else {
			GameItem gi1 = itemService.createGameItem(temp1);
			PlayerTransaction transaction = owner.newTransaction("addItem: "+cause);
			addGameItem(gi1, count, transaction, false);
			transaction.commit();
			EventManager.getInstance().addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_GAIN_ITEM, owner,itemId,gi1.getName(),count,cause));
		}
	}
	
	/**
	 * 修改物品时效(修改服装使用)
	 * @param itemId  物品id
	 * @param cause   原因
	 * @param cdTime  失效截止时间  -1、永久     0、失效      >0有效时间
	 */
	public GameItem updateGameItem(int itemId,String cause,long cdTime) {
		GameItem gi = getGameItem(itemId);
		if(gi != null) {
			gi.setObsoleteTime(cdTime);
			return gi;
		}
		return null;
	}
	
	/**
	 * 删除物品，不能删除有InstanceId的物品。
	 * @param itemId
	 * @param count
	 * @param cause
	 */
	public void removeItem(int itemId, int count,String cause){
		PlayerTransaction transaction = owner.newTransaction("removeItem:" + cause);
		removeGameItem(itemId, GameItem.GENERAL_INSTANCEID ,count ,transaction, false);
		transaction.commit();
	}
	
	/**
	 * 删除物品，但是忽略InstanceId
	 * @param itemId
	 * @param count
	 * @param cause
	 */
	public void removeItemIngoreInstanceId(int itemId, int count, String cause) {
		PlayerTransaction transaction = owner.newTransaction("removeItem:" + cause);
		removeGameItemIngoreInstanceId(itemId, count, transaction, false);
		transaction.commit();
	}
	
	public void addGameItemComplete(GameItem item, int count,
		PlayerTransaction tx, boolean notify) throws NoEnoughSpaceException {
		int[] indexes = getBagIndexes(item.getTemplate().getId());
		int leave = count;
		for(int index:indexes){
			Bag bag = getBag(index);
			leave = bag.addGameItem1(item,leave,tx,notify);
			if(leave == 0)
				return;
		}
		throw new NoEnoughSpaceException();
	}
	
	/**
	 * 加入指定数量的物品，有可能不是完全数量，如果全部加入，那么返回true；否则返回false
	 * @param item
	 * @param count
	 * @param tx
	 * @param notify
	 * @return
	 */
	public boolean addGameItem(GameItem item, int count, PlayerTransaction tx,
			boolean notify) {
		if(item == null){
			return false;
		}
		if(item.getTemplate() == null){
			return false;
		}
		int[] indexes = getBagIndexes(item.getTemplate().getId());
		int leave = count;
		for(int index:indexes){
			Bag bag = getBag(index);
			leave = bag.addGameItem1(item,leave,tx,notify);
			if(leave == 0)
				return true;
		}
		return false;
	}
	
	/**
	 * 
	 * @param itemId
	 * @param instanceId
	 * @param count
	 * @param tx
	 * @param notify
	 * @return  只有当全部数量的GameItem被移除的时候才会返回，否则为空
	 */
	public GameItem removeGameItem(int itemId,int instanceId,int count,PlayerTransaction tx,boolean notify){
		int[] indexes = getBagIndexes(itemId);
		Integer c = count;
		for(int index:indexes){
			Bag bag = getBag(index);
			GameItem item = bag.removeGameItem0(itemId, instanceId, c, tx, notify);
			if(item!=null)
				return item;
		}
		return null;
	}
	
	public GameItem removeGameItemIngoreInstanceId(int itemId,int count,PlayerTransaction tx, boolean notify){
		int[] indexes = getBagIndexes(itemId);
		Integer c = count;
		for(int index:indexes){
			Bag bag = getBag(index);
			GameItem item = bag.removeGameItemIngoreInstanceId0(itemId, c, tx, notify);
			if(item!=null)
				return item;
		}
		return null;
	}
	
	/**
	 * 用来实现分包放物品，传入一个itemid，返回哪些包可以用来装此物品
	 * @param itemId
	 * @return
	 */
	protected int[] getBagIndexes(int itemId){
		//游戏中目前只有3个背包 消耗品背包0      服装类包1    动作类背包2
		DefaultItemTemplate template = (DefaultItemTemplate) ItemService.getInstance().getItemTemplate(itemId);
		if(null == template){
			Log.getInstance().logItemError(itemId);
			return new int[0];
		}
		int category = template.getCategory();
		return new int[]{category};
	}
	
	public Bags clone(){
		Bags bags = new Bags(owner, this.bags.size(),this.type);
		bags.bags = this.bags;
		return bags;
	}
	
	/**
	 * 移除到时效物品
	 */
	public void removeObsoleteGameItems(){
		for(Bag bag : bags){
			bag.removeObsoleteGameItems();
		}
	}

	public List<Bag> getBags() {
		return bags;
	}

	public GameItem getGameItem(int itemId) {
		for(Bag bag : bags) {
			if(bag != null) {
				GameItem gameItem = bag.getGameItemById(itemId);
				if(gameItem != null) {
					return gameItem;
				}
			}
		}
		return null;
	}
	
	public BagGrid getGameItemBagGrid(int itemId) {
		for(Bag bag : bags) {
			if(bag != null) {
				for (BagGrid g : bag.grids) {
					if (g.item != null && g.item.getTemplate().getId() == itemId){
						return g;
					}
				}
			}
		}
		return null;
	}
}
