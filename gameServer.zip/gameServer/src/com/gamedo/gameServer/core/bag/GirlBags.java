package com.gamedo.gameServer.core.bag;

import com.gamedo.gameServer.entity.player.Player;

/**
 * 模特背包
 * @author libm
 *
 */
public class GirlBags extends Bags{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7376054181664648645L;

	protected int girlId;
	
	public GirlBags(Player owner, int size, int type,int girlId) {
		super(owner, size, type);
		this.girlId = girlId;
	}

	public int getGirlId() {
		return girlId;
	}

	public Bags clone(){
		GirlBags bags = new GirlBags(owner, this.bags.size(),this.type,this.girlId);
		bags.bags = this.bags;
		return bags;
	}
}
