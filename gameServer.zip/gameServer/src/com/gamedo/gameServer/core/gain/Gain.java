package com.gamedo.gameServer.core.gain;

import java.util.ArrayList;
import java.util.List;

import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.GainException;

/**
 * 
 * @author libm
 *
 */
public class Gain {

	protected List<GainEntry> entrys = new ArrayList<GainEntry>();

	protected Player player;

	public Gain() {
		this(null);
	}

	public Gain(Player player) {
		this.player = player;
	}

	public Player getPlayer() {
		return player;
	}

	public List<GainEntry> getGainEntrys() {
		return entrys;
	}

	public void addGainEntry(GainEntry entry) {
		entrys.add(entry);
	}

	public void addGain(Gain gain) {
		for (int i = 0; i < gain.entrys.size(); i++) {
			entrys.add(gain.entrys.get(i));
		}
	}

	public void gainComplete(String cause) throws GainException {
		int i = 0;
		GainException exception = null;
		for (; i < entrys.size(); i++) {
			GainEntry entry = entrys.get(i);
			try {
				entry.apply(player, cause, true,false);
			} catch (GainException ex) {
				exception = ex;
				break;
			}
		}
		if (exception != null) {
			for (int j = 0; j < i + 1; j++) {
				GainEntry entry = entrys.get(j);
				entry.rollback(player);
			}
			throw exception;
		}
	}

	/**
	 * 
	 * @param cause
	 * @param check 检测背包用已经拥有该物品后是否再次添加
	 */
	public void gain(String cause,boolean check) {
		for (GainEntry entry : entrys) {
			try {
				entry.apply(player, "cause", false,check);
			} catch (GainException ex) {
				// 这里没必要做处理，因为设计认为就是可以不处理抛出的异常的
			}
		}
	}

	public GameItem[] getGameItems() {
		List<GameItem> list = new ArrayList<GameItem>();
		for (GainEntry ge : entrys) {
			if (ge instanceof GameItemGainEntry) {
				list.add(((GameItemGainEntry) ge).item);
			}
		}
		GameItem[] gis = new GameItem[list.size()];
		gis = list.toArray(gis);
		return gis;
	}
	
	public void log(StringBuilder sb) {
		for (GainEntry entry : entrys) {
			entry.log(sb);
		}
	}
}
