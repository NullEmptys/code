package com.gamedo.gameServer.core.gain;

import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.GainException;
import com.gamedo.gameServer.message.I18NMessage;

/**
 * 
 * @author libm
 *
 */
public class GameItemGainEntry implements GainEntry {

	protected GameItem item;
	protected int count;
	protected long cdTime;

	public GameItemGainEntry(GameItem item, int count,long cdTime) {
		this.item = item;
		this.count = count;
		this.cdTime = cdTime;
	}

	@Override
	public void apply(Player player, String cause, boolean complete, boolean check) throws GainException {
		player.getBags().addItem(item.getTemplate().getId(), count, cause, cdTime);
	}

	@Override
	public void rollback(Player player) {

	}

	public GameItem getItem() {
		return item;
	}

	public int getCount() {
		return count;
	}

	public long getCdTime() {
		return cdTime;
	}

	public void log(StringBuilder sb) {
		// Platform.getLog(Log.class).getGameItemString(sb, item, count);
	}
}
