package com.gamedo.gameServer.core.transaction;

import com.gamedo.gameServer.core.ChangedItem;

/**
 * 
 * @author libm
 *
 */
public interface TransactionEntity {

	public void commit();

	public void rollback();
	
	public ChangedItem[] sync();
	
	public Transaction getTransaction();
}
