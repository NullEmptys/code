package com.gamedo.gameServer.core.event;

/**
 * 
 * @author libm
 *
 */
public class ServiceEvent {

	/*角色登陆*/
	public static final int EVENT_PLAYER_LOGINED = 1;
	/*角色登出*/
	public static final int EVENT_PLAYER_LOGOUT = 2;
	/*开始任务*/
	public static final int EVENT_PLAYER_START_QUEST = 3;
	/*购买体力*/
	public static final int EVENT_PLAYER_BUY_TILI = 4;
	/*结束任务*/
	public static final int EVENT_FINISH_QUEST = 5;
	/*充值*/
	public static final int EVENT_PLAYER_CHARGE = 6;
	/*签约模特*/
	public static final int EVENT_SIGN_GIRL = 7;
	/*消耗钻石*/
	public static final int EVENT_PLAYER_DEC_MONEY = 8;
	/* 获得钻石*/
	public static final int EVENT_PLAYER_GAIN_MONEY = 9;
	/* 扣体力*/
	public static final int EVENT_PLAYER_DEC_TILI = 10;
	/* 获得物品*/
	public static final int EVENT_PLAYER_GAIN_ITEM = 11;
	/* 扣除物品*/
	public static final int EVENT_PLAYER_REMOVE_ITEM = 12;
	/* 获得金币*/
	public static final int EVENT_PLAYER_GAIN_GOLD = 13;
	/* 消耗金币*/
	public static final int EVENT_PLAYER_DEC_GOLD = 14;
	/*给模特送礼*/
	public static final int EVENT_GIFT_GIRL = 15;
	/*参与猜拳*/
	public static final int EVENT_MORA=16;
	/*在自由拍摄里拍摄1张照片*/
	public static final int EVENT_TAKE_PHOTO=17;
	/*约会1次*/
	public static final int EVENT_APPOINTMENT=18;
	/*完成一次社交任务*/
	public static final int EVENT_FINISH_SOCIAL_MISSION=19;
	/*购买2件服装*/
	public static final int EVENT_BUY_EQUIP=20;
	/*使用任意模特在任务中拍摄一张照片*/
	public static final int EVENT_USE_GIRL_TAKE_PHOTE=21;
	/*进入社交*/
	public static final int EVENT_ENTER_SOCIAL=22;
	/*回复X条动态*/
	public static final int EVENT_RESPONE_DYNAMIC=23;
	/*点赞X次*/
	public static final int EVENT_THUMB_UP=24;
	/*分享X次*/
	public static final int EVENT_SHARE_TIMES=25;
	/*签到一次*/
	public static final int EVENT_SIGN_TIMES=26;
	/*结束猜拳*/
	public static final int EVENT_FINISHED_GUESS = 27;
	/*点赞其他玩家评论*/
	public static final int EVENT_SUPPORT_OTHER_PLAYER_DYNAMIC = 28;
	/*购买金币*/
	public static final int EVENT_BUY_GOLD = 29;
	/*成功完成任务*/
	public static final int EVENT_FINISHED_QUEST = 30;
	/*参与社交每日任务*/
	public static final int EVENT_INVOLEVMENT_SOCIAL_MISSION=31;
	
	public int type;
	public Object param1;
	public Object param2;
	public Object param3;
	public Object param4;
	public Object param5;
	public Object param6;
	
	public ServiceEvent(int type) {
		this.type = type;
	}
	
	public ServiceEvent(int type, Object param1) {
		this.type = type;
		this.param1 = param1;
	}

	public ServiceEvent(int type, Object param1, Object param2) {
		this.type = type;
		this.param1 = param1;
		this.param2 = param2;
	}

	public ServiceEvent(int type, Object param1, Object param2, Object param3) {
		this.type = type;
		this.param1 = param1;
		this.param2 = param2;
		this.param3 = param3;
	}
	
	public ServiceEvent(int type, Object param1, Object param2, Object param3, Object param4){
		this.type = type;
		this.param1 = param1;
		this.param2 = param2;
		this.param3 = param3;
		this.param4 = param4;
	}
	
	public ServiceEvent(int type, Object param1, Object param2, Object param3, Object param4, Object param5){
		this.type = type;
		this.param1 = param1;
		this.param2 = param2;
		this.param3 = param3;
		this.param4 = param4;
		this.param5 = param5;
	}
	
	public ServiceEvent(int type, Object param1, Object param2, Object param3, Object param4, Object param5 ,Object param6){
		this.type = type;
		this.param1 = param1;
		this.param2 = param2;
		this.param3 = param3;
		this.param4 = param4;
		this.param5 = param5;
		this.param6 = param6;
	}
}
