package com.gamedo.gameServer.core.id;

/**
 * 
 * @author libm
 *
 */
public interface IntIdGenerator {

	public int next();
}
