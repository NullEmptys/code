package com.gamedo.gameServer.core.id;

import com.gamedo.gameServer.core.sleepycat.SleepyCat;

/**
 * 
 * @author libm
 *
 */
public class ServerPersistLongIdGenerator implements LongIdGenerator {

	protected int serverId;
	protected int type;
	protected String seqName;
	protected long head;
	
	public ServerPersistLongIdGenerator(int serverId,int type,String seqName){
		this.serverId = serverId;
		this.type  =  type;
		this.seqName = seqName;
		int tmp = serverId<<24;
		tmp |= type<<16;
		head = (0xFFFFFFFFFFFFFFFFL&tmp)<<32;
	}
	
	@Override
	public long next() {
		return head|SleepyCat.nextSequence(seqName);
	}

}
