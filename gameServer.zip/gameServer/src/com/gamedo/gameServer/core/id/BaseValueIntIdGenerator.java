package com.gamedo.gameServer.core.id;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * 
 * @author libm
 *
 */
public class BaseValueIntIdGenerator implements IntIdGenerator {

	protected AtomicInteger id;

	public BaseValueIntIdGenerator(int initValue) {
		this.id = new AtomicInteger(initValue);
	}

	@Override
	public int next() {
		return id.incrementAndGet();
	}
}
