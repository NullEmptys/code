package com.gamedo.gameServer.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.gamedo.gameServer.update.UpdateObject;

import gnu.trove.map.hash.TIntObjectHashMap;
import gnu.trove.procedure.TObjectProcedure;

/**
 * 用于计算玩家的属性，背包以及其他的改变量，这些改变量分为需要客户端提醒用户的部分以及不需要客户端提醒用户的部分
 * 此类是单线程类，不能用于多线程操作
 * 
 * @author libm
 *
 */
public class Changed implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4616430451775936576L;

	protected boolean isChanged;

	protected TIntObjectHashMap<List<ChangedItem>> noNotifies = new TIntObjectHashMap<List<ChangedItem>>();
	protected TIntObjectHashMap<List<ChangedItem>> notifies = new TIntObjectHashMap<List<ChangedItem>>();
	protected List<ChangedItem> broadcasts = new ArrayList<ChangedItem>(5);

	protected static final ClearProcedure CLEANER = new ClearProcedure();

	protected int noNotifyCount; // 所有加入的ChangedItem的数量，如果加入的ChangedItem被merge掉，那么不算数量
	protected int notifyCount;

	public Changed() {
		
	}

	public synchronized void addChangedItem(ChangedItem changedItem) {
		isChanged = true;
		List<ChangedItem> l = null;
		if (changedItem.isNotif()) {
			l = notifies.get(changedItem.getType());
			if (l == null) {
				l = new LinkedList<ChangedItem>();
				notifies.put(changedItem.getType(), l);
			}
		} else {
			l = noNotifies.get(changedItem.getType());
			if (l == null) {
				l = new LinkedList<ChangedItem>();
				noNotifies.put(changedItem.getType(), l);
			}
		}
		boolean merge = false;
		for (ChangedItem ci : l) {
			if (ci.merge(changedItem)) {
				merge = true;
				break;
			}
		}
		if (!merge) {
			l.add(changedItem);
			if (changedItem.isNotif()) {
				notifyCount++;
			} else {
				noNotifyCount++;
			}
		}

	}

	public synchronized boolean isChanged() {
		return isChanged;
	}

	public synchronized void clean() {
		isChanged = false;
		noNotifies.forEachValue(CLEANER);
		notifies.forEachValue(CLEANER);
		broadcasts.clear();
		notifyCount = 0;
		noNotifyCount = 0;
	}

	public synchronized List<UpdateObject> sendAndClean() {
		if (isChanged) {
			List<UpdateObject> list = new ArrayList<>();
			for(List<ChangedItem> l:noNotifies.valueCollection()){
				for(ChangedItem changedItem:l){
					UpdateObject up = changedItem.pack();
					list.add(up);
					
				}
				l.clear();
			}
			broadcast(broadcasts);
			clean();
			return list;
		}
		return null;
	}

	protected void broadcast(List<ChangedItem> cs) {
		if (cs.size() > 0) {
			
		}
	}

	protected int getCount(List<ChangedItem>[] cs) {
		int ret = 0;
		for (List<ChangedItem> l : cs) {
			ret += l.size();
		}
		return ret;
	}
}

class ClearProcedure implements TObjectProcedure<List<ChangedItem>> {
	public boolean execute(List<ChangedItem> l) {
		if (l.size() > 0)
			l.clear();
		return true;
	}
}
