package com.gamedo.gameServer.core;

import java.io.Serializable;

import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.player.EngagementData;
import com.gamedo.gameServer.update.EngagementUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

/**
 * 
 * @author libm
 *
 */
public class EngagementChangedItem extends ChangedItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5557139418602681648L;

	public EngagementData engagementData;
	
	public EngagementChangedItem(EngagementData engagementData) {
		this.engagementData = engagementData;
	}
	
	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		
	}

	@Override
	public UpdateObject pack() {
		EngagementUpdateObject object = new EngagementUpdateObject();
		object.setType(TYPE_ENGAGEMENT);
		object.sceneId = engagementData.getSceneId();
		object.engagementGirlId = engagementData.getEngagementGirlId();
		object.guessCounts = engagementData.getGuessCounts();
		object.maxGiftCounts = engagementData.getMaxGiftCounts();
		object.maxGuessCounts = engagementData.getMaxGuessCounts();
		object.sendGiftCounts = engagementData.getSendGiftCounts();
		object.sendGiftState = engagementData.getSendGiftState();
		return object;
	}

}
