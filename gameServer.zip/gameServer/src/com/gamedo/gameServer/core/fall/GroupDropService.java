package com.gamedo.gameServer.core.fall;

import java.util.List;
import java.util.Random;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gamedo.gameServer.constant.DropType;
import com.gamedo.gameServer.core.gain.Gain;
import com.gamedo.gameServer.core.item.ItemTemplate;
import com.gamedo.gameServer.db.editor.DropGroupDao;
import com.gamedo.gameServer.db.editor.DropItemDao;
import com.gamedo.gameServer.db.editor.SubDropGroupDao;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.service.AbstractService;
import com.gamedo.gameServer.service.data.ItemService;

import gnu.trove.map.hash.TIntObjectHashMap;

/**
 * 掉落组服务
 * 
 * @author libm
 *
 */
@Service
public class GroupDropService extends AbstractService implements GroupDropServiceMBean {

	@Autowired
	private ItemService itemService;
	@Autowired
	private DropGroupDao dropGroupDao;
	@Autowired
	private SubDropGroupDao subDropGroupDao;
	@Autowired
	private DropItemDao dropItemDao;

	TIntObjectHashMap<GroupDrop> groupDrops = new TIntObjectHashMap<GroupDrop>();

	@Override
	public String getId() {
		return GroupDropService.class.getName();
	}

	@PostConstruct
	public void startup() throws Exception {
		initGroupDrops();
		super.startup("掌上纵横-IPOC-LOVELIVE:type=策划,name=掉落组服务");
	}

	public void initGroupDrops() {
		List<DropGroup> dropGroups = dropGroupDao.loadDropGroups();
		if (dropGroups != null && dropGroups.size() > 0) {
			for (DropGroup dropGroup : dropGroups) {
				if (dropGroup != null) {
					List<SubDropGroup> subDropGroups = subDropGroupDao.loadSubDropGroupById(dropGroup.getId());
					if(subDropGroups != null && subDropGroups.size() > 0) {
						for(SubDropGroup subDropGroup : subDropGroups) {
							if(subDropGroup != null) {
								List<DropItem> dropItems = dropItemDao.loadDropItems(subDropGroup.getSubGroupId(),subDropGroup.dropGroupId);
								subDropGroup.setDropGroup(dropItems);
							}
						}
					}
					dropGroup.setSubGroup(subDropGroups);
					GroupDrop drop = getGroupDrop(dropGroup.id, true);
					translateDropGroup(dropGroup, drop);
				}
			}
		}
	}

	private void translateDropGroup(DropGroup dropGroup, GroupDrop drop) {
		drop.setValid(dropGroup.valid == 1 ? true : false);
		List<SubDropGroup> subs = dropGroup.getSubGroup();
		if(subs != null && subs.size() > 0) {
			for(SubDropGroup sub : subs) {
				if(sub != null) {
					LeveledGroupDrop lgd = new LeveledGroupDrop(dropGroup.quantityMin, dropGroup.quantityMax);
					for (DropItem dropItem : sub.getDropGroup()) {
						if (dropItem.dropType == DropType.DROP_TYPE_ITEM.getType()
								|| dropItem.dropType == DropType.DROP_TYPE_EQUI.getType()) {
							ItemTemplate template = itemService.getItemTemplate(dropItem.dropID);
							ItemDrop d = new ItemDrop(template, dropItem.quantityMin, dropItem.quantityMax,dropItem.cdTimeType);
							WeightGroupDrop wd = new WeightGroupDrop(dropItem.dropWeight, d);
							lgd.addGroupDrop(wd);
						}else if(dropItem.dropType == DropType.DROP_TYPE_CURRENCY.getType()) {
							CurrencyDrop d = new CurrencyDrop(dropItem.getDropID(),dropItem.quantityMin, dropItem.quantityMax);
							WeightGroupDrop wd = new WeightGroupDrop(dropItem.dropWeight, d);
							lgd.addGroupDrop(wd);
						}else {
							throw new IllegalArgumentException();
						}
					}
					drop.addDrop(lgd);
				}
			}
		}
	}

	@PreDestroy
	@Override
	public void shutdown() throws Exception {
		super.shutdown();
	}

	public GroupDrop getGroupDrop(int id, boolean needNew) {
		GroupDrop drop = groupDrops.get(id);
		if (drop == null && needNew) {
			drop = new GroupDrop(id);
			groupDrops.put(id, drop);
		}
		return drop;
	}
	
	public GroupDrop getGroupDrop(int id){
		return getGroupDrop(id,false);
	}

	/**
	 * 
	 * @param player
	 * @param dropGroupId 掉落组ID
	 * @param cause 掉落原因
	 * @return
	 */
	public Gain groupDrop(Player player,int dropGroupId,String cause) {
		GroupDrop groupDrop = getGroupDrop(dropGroupId);
		if(groupDrop == null) {
			return null;
		}
		Gain gain = new Gain(player);
		Random rnd = new Random();
		groupDrop.calc(rnd, gain);
		gain.gain(cause, true);
		return gain;
	}
	
}
