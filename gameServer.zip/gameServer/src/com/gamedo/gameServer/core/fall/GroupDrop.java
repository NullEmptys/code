package com.gamedo.gameServer.core.fall;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import com.gamedo.gameServer.core.gain.Gain;
import com.gamedo.gameServer.entity.player.Player;

/**
 * 
 * @author libm
 *
 */
public class GroupDrop {

	protected int id;
	protected boolean valid;
	protected List<LeveledGroupDrop> drops = new LinkedList<LeveledGroupDrop>();
	
	public GroupDrop(int id){
		this.id = id;
	}
	
	public int getId(){
		return id;
	}
	
	public boolean isValid() {
		return valid;
	}
	
	public void setValid(boolean value) {
		valid = value;
	}
	
	/**
	 * 在计算掉落的时候先确定是那个级别的掉落
	 */
	public void calc(Random rnd,Gain gain) {
		Player player = gain.getPlayer();
		if (!valid) {
			return;
		}
		if (player != null) {
			for (LeveledGroupDrop drop : drops) {
				drop.calc(rnd, gain);
			}
		}
	}
	
	public void addDrop(LeveledGroupDrop drop){
		drops.add(drop);
	}

	public List<LeveledGroupDrop> getDrops() {
		return drops;
	}

	public void setDrops(List<LeveledGroupDrop> drops) {
		this.drops = drops;
	}

	public void setId(int id) {
		this.id = id;
	}

}
