package com.gamedo.gameServer.core.fall;

import java.util.ArrayList;
import java.util.List;

/**
 * 掉落组
 * @author libm
 *
 */
public class DropGroup {

	/**
     * 对象ID。
     */
    public int id;
    
    /**
     * 标题/名字。
     */
    public String title = "";
    
    /**
     * 描述。
     */
    public String description = "";
    
    /**
     * 掉落数量上限
     */
    public int quantityMax = 1;
    
    /**
     * 掉落数量下限
     */
    public int quantityMin = 1;
    
    /**
     * 是否有效。
     * 0:否
     * 1：有效
     */
    public int valid;
    
    /**
     * 子掉落组
     */
    public List<SubDropGroup> subGroup = new ArrayList<SubDropGroup>();
    
	public int getQuantityMax() {
		return quantityMax;
	}

	public void setQuantityMax(int quantityMax) {
		this.quantityMax = quantityMax;
	}

	public int getQuantityMin() {
		return quantityMin;
	}

	public void setQuantityMin(int quantityMin) {
		this.quantityMin = quantityMin;
	}

	public int getValid() {
		return valid;
	}

	public void setValid(int valid) {
		this.valid = valid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<SubDropGroup> getSubGroup() {
		return subGroup;
	}

	public void setSubGroup(List<SubDropGroup> subGroup) {
		this.subGroup = subGroup;
	}
	
}
