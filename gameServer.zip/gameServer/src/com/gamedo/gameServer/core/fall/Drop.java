package com.gamedo.gameServer.core.fall;

import java.util.Random;

import com.gamedo.gameServer.core.gain.Gain;

/**
 * 
 * @author libm
 *
 */
public interface Drop {

	public void calc(Random rnd,Gain gain);
	
}
