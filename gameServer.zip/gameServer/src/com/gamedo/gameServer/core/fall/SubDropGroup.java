package com.gamedo.gameServer.core.fall;

import java.util.ArrayList;
import java.util.List;

/**
 * 子掉落组数据结构，子掉落组中可以包含一个物品，也可以包含一个掉落组
 * 
 * @author libm
 *
 */
public class SubDropGroup {

	public int id;
	
	public int subGroupId;

	/**
	 * 掉落组id
	 */
	public int dropGroupId;

	/**
	 * 子掉落组的等级上限
	 */
	public int levelMax;

	/**
	 * 子掉落组的等级下限
	 */
	public int levelMin;

	/**
	 * 掉落物品，掉落物品中可以是物品、装备或者一个掉落组
	 */
	public List<DropItem> dropGroup = new ArrayList<DropItem>();

	public int getLevelMax() {
		return levelMax;
	}

	public void setLevelMax(int levelMax) {
		this.levelMax = levelMax;
	}

	public int getLevelMin() {
		return levelMin;
	}

	public void setLevelMin(int levelMin) {
		this.levelMin = levelMin;
	}

	public List<DropItem> getDropGroup() {
		return dropGroup;
	}

	public void setDropGroup(List<DropItem> dropGroup) {
		this.dropGroup = dropGroup;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getDropGroupId() {
		return dropGroupId;
	}

	public void setDropGroupId(int dropGroupId) {
		this.dropGroupId = dropGroupId;
	}

	public int getSubGroupId() {
		return subGroupId;
	}

	public void setSubGroupId(int subGroupId) {
		this.subGroupId = subGroupId;
	}
	
}
