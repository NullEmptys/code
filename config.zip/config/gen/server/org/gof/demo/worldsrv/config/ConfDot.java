package org.gof.demo.worldsrv.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.gof.core.db.OrderBy;
import org.gof.core.support.ConfigJSON;
import org.gof.core.support.SysException;
import org.gof.core.support.Utils;

/**
 * 范围持续伤害|Dot 
 * DotConfig.xlsx
 * @author System
 * 此类是系统自动生成类 不要直接修改，修改后也会被覆盖
 */
@ConfigJSON
public class ConfDot {
	public final int sn;			//ID
	public final boolean targetSelf;			//目标是否是自己
	public final boolean visible;			//是否显示
	public final int moveType;			//dot移动类型（0:中心点坐标型，不移动，1：中心点人物型，跟随人移动）
	public final int scopeType;			//目标范围类型(全图1， 圆形2)
	public final float scopeParam1;			//范围参数1(半径)
	public final int scopeParam2;			//范围参数2（角度）
	public final int targetNum;			//范围搜索的目标个数
	public final int timeDelay;			// 延迟时间，毫秒(ms)
	public final int totalTime;			//持续时间（ms）
	public final String interval;			//间隔的时间
	public final int addCommon;			//普通纯数值
	public final double procCommon;			//伤害百分比

	public ConfDot(int sn, boolean targetSelf, boolean visible, int moveType, int scopeType, float scopeParam1, int scopeParam2, int targetNum, int timeDelay, int totalTime, String interval, int addCommon, double procCommon) {
		this.sn = sn;			
		this.targetSelf = targetSelf;			
		this.visible = visible;			
		this.moveType = moveType;			
		this.scopeType = scopeType;			
		this.scopeParam1 = scopeParam1;			
		this.scopeParam2 = scopeParam2;			
		this.targetNum = targetNum;			
		this.timeDelay = timeDelay;			
		this.totalTime = totalTime;			
		this.interval = interval;			
		this.addCommon = addCommon;			
		this.procCommon = procCommon;			
	}

	public static void reLoad() {
		DATA._init();
	}
	
	/**
	 * 获取全部数据
	 * @return
	 */
	public static Collection<ConfDot> findAll() {
		return DATA.getList();
	}

	/**
	 * 通过SN获取数据
	 * @param sn
	 * @return
	 */
	public static ConfDot get(Integer sn) {
		return DATA.getMap().get(sn);
	}

	/**
	 * 通过属性获取单条数据
	 * @param params
	 * @return
	 */
	public static ConfDot getBy(Object...params) {
		List<ConfDot> list = utilBase(params);
		
		if(list.isEmpty()) return null;
		else return list.get(0);
	}
	
	/**
	 * 通过属性获取数据集合
	 * @param params
	 * @return
	 */
	public static List<ConfDot> findBy(Object...params) {
		return utilBase(params);
	}
	
	/**
	 * 通过属性获取数据集合 支持排序
	 * @param params
	 * @return
	 */
	public static List<ConfDot> utilBase(Object...params) {
		List<Object> settings = Utils.ofList(params);
		
		//查询参数
		final Map<String, Object> paramsFilter = new LinkedHashMap<>();		//过滤条件
		final Map<String, OrderBy> paramsOrder = new LinkedHashMap<>();		//排序规则
				
		//参数数量
		int len = settings.size();
		
		//参数必须成对出现
		if(len % 2 != 0) {
			throw new SysException("查询参数必须成对出现:query={}", settings);
		}
		
		//处理成对参数
		for(int i = 0; i < len; i += 2) {
			String key = (String)settings.get(i);
			Object val = settings.get(i + 1);
			
			//参数 排序规则
			if(val instanceof OrderBy) {
				paramsOrder.put(key, (OrderBy) val);
			} else {	//参数 过滤条件
				paramsFilter.put(key, val);
			}
		}
		
		//返回结果
		List<ConfDot> result = new ArrayList<>();
		
		try {
			//通过条件获取结果
			for(ConfDot c : DATA.getList()) {
				//本行数据是否符合过滤条件
				boolean bingo = true;
				
				//判断过滤条件
				for(Entry<String, Object> p : paramsFilter.entrySet()) {
					Field field = c.getClass().getField(p.getKey());
					
					//实际结果
					Object valTrue = field.get(c);
					//期望结果
					Object valWish = p.getValue();
					
					//有不符合过滤条件的
					if(!valWish.equals(valTrue)) {
						bingo = false;
						break;
					}
				}
				
				//记录符合结果
				if(bingo) {
					result.add(c);
				}
			}
		} catch (Exception e) {
			throw new SysException(e);
		}
		
		//对结果进行排序
		Collections.sort(result, new Comparator<ConfDot>() {
			@Override
			@SuppressWarnings({ "rawtypes", "unchecked" })
			public int compare(ConfDot a, ConfDot b) {
				try {
					for(Entry<String, OrderBy> e : paramsOrder.entrySet()) {
						//两方字段
						Field fa = a.getClass().getField(e.getKey());
						Field fb = b.getClass().getField(e.getKey());
						//两方字段值
						Comparable va = (Comparable) fa.get(a);
						Comparable vb = (Comparable) fb.get(b);
						
						//值排序结果
						int compareResult = va.compareTo(vb);
						
						//相等时 根据下一个值进行排序
						if(va.compareTo(vb) == 0) continue;
						
						//配置排序规则
						OrderBy order = e.getValue();
						if(order == OrderBy.ASC) return compareResult;		//正序
						else return -1 * compareResult;					//倒序
					}
				} catch (Exception e) {
					throw new SysException(e);
				}

				return 0;
			}
		});
		
		return result;
	}

	/**
	 * 属性关键字
	 */
	public static final class K {
		public static final String sn = "sn";	//ID
		public static final String targetSelf = "targetSelf";	//目标是否是自己
		public static final String visible = "visible";	//是否显示
		public static final String moveType = "moveType";	//dot移动类型（0:中心点坐标型，不移动，1：中心点人物型，跟随人移动）
		public static final String scopeType = "scopeType";	//目标范围类型(全图1， 圆形2)
		public static final String scopeParam1 = "scopeParam1";	//范围参数1(半径)
		public static final String scopeParam2 = "scopeParam2";	//范围参数2（角度）
		public static final String targetNum = "targetNum";	//范围搜索的目标个数
		public static final String timeDelay = "timeDelay";	// 延迟时间，毫秒(ms)
		public static final String totalTime = "totalTime";	//持续时间（ms）
		public static final String interval = "interval";	//间隔的时间
		public static final String addCommon = "addCommon";	//普通纯数值
		public static final String procCommon = "procCommon";	//伤害百分比
	}

	/**
	 * 数据集
	 * 单独提出来也是为了做数据延迟初始化
	 * 避免启动遍历类时，触发了static静态块
	 */
	private static final class DATA {
		//全部数据
		private static volatile Map<Integer, ConfDot> _map;
		
		/**
		 * 获取数据的值集合
		 * @return
		 */
		public static Collection<ConfDot> getList() {
			return getMap().values();
		}
		
		/**
		 * 获取Map类型数据集合
		 * @return
		 */
		public static Map<Integer, ConfDot> getMap() {
			//延迟初始化
			if(_map == null) {
				synchronized (DATA.class) {
					if(_map == null) {
						_init();
					}
				}
			}
			
			return _map;
		}


		/**
		 * 初始化数据
		 */
		private static void _init() {
			Map<Integer, ConfDot> dataMap = new HashMap<>();
			
			//JSON数据
			String confJSON = _readConfFile();
			if(StringUtils.isBlank(confJSON)) return;
			
			//填充实体数据
			JSONArray confs = (JSONArray)JSONArray.parse(confJSON);
			for(int i = 0 ; i < confs.size() ; i++){
				JSONObject conf = confs.getJSONObject(i);
				ConfDot object = new ConfDot(conf.getIntValue("sn"), conf.getBooleanValue("targetSelf"), conf.getBooleanValue("visible"), conf.getIntValue("moveType"), 
				conf.getIntValue("scopeType"), conf.getFloatValue("scopeParam1"), conf.getIntValue("scopeParam2"), conf.getIntValue("targetNum"), 
				conf.getIntValue("timeDelay"), conf.getIntValue("totalTime"), conf.getString("interval"), conf.getIntValue("addCommon"), 
				conf.getDoubleValue("procCommon"));
				dataMap.put(conf.getInteger("sn"), object);
			}

			//保存数据
			_map = Collections.unmodifiableMap(dataMap);
		}
		
		/**
		 * 读取游戏配置
		 */
		private static String _readConfFile() {
			String baseBath = ConfDot.class.getResource("").getPath();
			File file = new File(baseBath + "json/ConfDot.json");
			//文件不存在 忽略
			if(!file.exists()) return null;

			String result = "";

			try ( BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"))){
			    String tempString = "";
			    while ((tempString = reader.readLine()) != null) {
				result += tempString;
			    }
			} catch (IOException e) {
			    throw new RuntimeException(e);
			} 

			return result;
		}
	}
    
}