(function($) {
	Array.prototype.contains = function(obj) { 
			var i = this.length; 
			while (i-->=0) { 
				if (this[i] === obj) { 
					return true; 
				} 
			} 
			return false; 
		} 
	var styleList=['color','background'];
	var jtypeList=['text','href'];
	var attrList=['href','target'];
  	$.extend({
		styleList:['color','background'],
		jtypeList:['text','href'],
		attrList:['href','target'],
	  	decodeJsonTemplate:function(data){
			var re=$("<div></div>");
					for(var key in data){
						var node=$("<div></div>");
						var value = data[key];
						node.append("<span class='key'>"+key+"</span>:");
						if($.isJson(value)){
							var newNode;
							if(value.jtype===undefined || !$.jtypeList.contains(value.jtype)){
								newNode = $.decodeJsonTemplate(value);
								newNode.addClass("childNode");
								node.append(newNode);
							}
							else { 
								if(value.jtype==='text'){
									newNode = $('<span></span>');								
								}
								else if(value.jtype==='href'){
									newNode = $('<a></a>');								
								}
								newNode.html(value.text);
								for(var i=0;i<styleList.length;i++){
									var style=styleList[i];
									if(value[style]!==undefined){
										newNode.css(style,value[style]);
										}
								}
								for(var i=0;i<attrList.length;i++){
									var attr=attrList[i];
									if(value[attr]!==undefined){
										newNode.attr(attr,value[attr]);
									}
								}
								node.append(newNode);
							}
						}
						else{							
								node.append( "<span class='value'>"+value+"</span>");
						}
						$(re).append(node);
					}	
					return re;
			},
			 isJson :function(obj){
					var isjson = typeof(obj) == "object" && Object.prototype.toString.call(obj).toLowerCase() == "[object object]" && !obj.length;    
				return isjson;
				}
	  });
})(jQuery);