(function($) {
	$.fn.AsynClick = function() {
		var items = $(this);
		items.click(function() {
			// alert();
			var link = $(this).attr("link");
			$.get(link, function(data) {
				var dialog = $("#dialogBox");

				if (dialog.length == 0) {
					dialog = $("<div>SUCC</div>").attr("id", "dialogBox");

				}
				dialog.html( data );
				//console.log(data);
				// alert(dialog);
				dialog.appendTo($('body')).fadeIn(1, function() {
					setTimeout(hide, 2000, $(this));
				});
			});
		});
	}
	function hide(div) {
		$(div).fadeOut(2000);
	}

})(jQuery);