﻿/* ===========================================================================
 *
 * JQuery Quick Pagination
 * Version 1.0.1
 * Quick and dirty pagination for pretty much any set of elements on the page.
 *
 * Author: Mark Perkins
 * Author email: mark@allmarkedup.com
 * For full documentation and more go to http://projects.allmarkedup.com/jquery_quick_paginate/
 *
 * ---------------------------------------------------------------------------
 *
 * LICENCE:
 *
 * Released under a MIT Licence. See licence.txt that should have been supplied with this file,
 * or visit http://projects.allmarkedup.com/jquery_quick_paginate/licence.txt
 *
 * ---------------------------------------------------------------------------
 * 
 * EXAMPLES OF USE:
 *
 * jQuery('.news_item').quickpaginate(); // would paginate all items on the page with the class of 'news_item'
 * 
 * jQuery('div#quick_slideshow img').quickpaginate(); // would paginate all img elements within the div with an id of 'quick_slideshow'
 *
 * // Paginate everything with the class of "news_item",
 * // 5 per 'page' and without the page counter.
 * jQuery('.news_item').quickpaginate( { perpage: 5, showcounter: false } ); 
 *
 * // Paginate all img elements and the element with the id of "info",
 * // with the prev/next/counter element appended to the element with the id of "pager_here"
 * jQuery('img, #info').quickpaginate({ pager : $("#pager_here") });
 *
 */

jQuery.fn.quickpaginate = function( settings ) {

	settings = jQuery.extend({
   
		perpage: 6,
		
		pager : null,
		
		showcounter : true,
		
		prev : "qp_next",

		next : "qp_prev",
		
		prveText:"上一页",
		
		nextText:"下一页",
		
		pagenumber : "qp_pagenumber",
		
		totalnumber : "qp_totalnumber",
		
		counter : "qp_counter",
		
		showContent:null

	}, settings);

	var cm;
	
	var total;
	
	var last = false;
	
	var first = true;
	
	var items = jQuery(this);
	
	var nextbut;
	
	var prevbut;
	
	var parent=jQuery(this).parent();
	
	var init = function()
	{
		items.parent().addClass("list");
		items.show().addClass("item");
		
		items.css("cursor","pointer");
		if(settings.pager==null || settings.pager.length==0 ||settings.pager===undefined ){
			settings.pager=jQuery("<div></div>");
			parent.after(settings.pager);
		}
		if(settings.showContent==null ||settings.showContent.length==0 ||settings.showContent===undefined ){
			settings.showContent=jQuery("<div></div>");
			settings.showContent.addClass("box_content");
			
			parent.after(settings.showContent);
			settings.showContent.after(jQuery("<div></div>").addClass("clean"));
		}
		items.click(function(){
			setContent($(this));
			});
		var  item =getDisplayItem()[0];
		setContent($(item));
		total = items.size();
				
		if ( items.size() > settings.perpage )
		{
			items.filter(":gt("+(settings.perpage-1)+")").hide();
			
			cm = settings.perpage;
			
			setNav();
		}
	};
	
	var goNext = function()
	{
		if ( !last )
		{
			var nm = cm + settings.perpage;
			items.hide();
			
			items.slice( cm, nm ).show();
			
			cm = nm;
			var item=getDisplayItem()[0];
			setContent($(item));
			if ( cm >= total  )
			{
				last = true;
				nextbut.addClass("qp_disabled");
			}
			
			if ( settings.showcounter ) settings.pager.find("."+settings.pagenumber).text(cm/settings.perpage);
			
			prevbut.removeClass("qp_disabled");
			
			first = false;
		}
	};
	
	var goPrev = function()
	{
		if ( !first )
		{
			var nm = cm-settings.perpage;
			items.hide();
			
			items.slice( (nm - settings.perpage), nm ).show();
			
			cm = nm;
			var item=getDisplayItem()[0];
			setContent($(item));
			if ( cm == settings.perpage  )
			{
				first = true;
				prevbut.addClass("qp_disabled");
			}
			
			if ( settings.showcounter ) settings.pager.find("."+settings.pagenumber).text(cm/settings.perpage);
			
			nextbut.removeClass("qp_disabled");
			last = false;
		}
	};
	
	var setNav = function()
	{
		if ( settings.pager === null )
		{	
			settings.pager = jQuery('<div class="qc_pager"></div>');
			items.eq( items.size() -1 ).after(settings.pager);
		}
		
		var pagerNav = $('<a class="'+settings.prev+'" href="#">'+settings.prveText+'</a><a class="'+settings.next+'" href="#">'+settings.nextText+'</a>');
		
		jQuery(settings.pager).append( pagerNav );
		
		if ( settings.showcounter )
		{
			var counter = '<span class="'+settings.counter+'"><span class="'+settings.pagenumber+'"></span> / <span class="'+settings.totalnumber+'"></span></span>';
			
			settings.pager.find("."+settings.prev).after( counter );
			
			settings.pager.find("."+settings.pagenumber).text( 1 );
			settings.pager.find("."+settings.totalnumber).text( Math.ceil(total / settings.perpage) );
		}

		nextbut = settings.pager.find("."+settings.next);
			
		prevbut = settings.pager.find("."+settings.prev);
		
		prevbut.addClass("qp_disabled");
		
		nextbut.click(function(){
			goNext();
			return false;
		});
		
		prevbut.click(function(){
			goPrev();
			return false;
		});
		
	};
	
	var setContent=function(item){
				items.removeClass("selected");
				item.addClass("selected");
				settings.showContent.hide();
				settings.showContent.css("position","");
				jQuery(item).find("div").hide();		
				var bottom=jQuery(item).offset().top+jQuery(item).height();			
				var right=jQuery(item).offset().left+jQuery(item).innerWidth();
				var json_str= jQuery(item).attr("json");
				var json=eval("("+json_str+")");
				if(json!==undefined ){
					settings.showContent.show().html("");
					/*
					var content="";
					for(var key in json){
						var content=jQuery("<div></div>");
						var value=json[key];
						if(isJson(value)){
							content.html("属性:<div class='showContent_attr'><div>");
							for(var i in value){								
								var attr=jQuery("<div></div>");
								attr.html(i+":"+value[i]);
								attr.appendTo(content.find(".showContent_attr"));
							}
						}
						else{
							content.html(key+":"+value);						
						}
						content.appendTo(settings.showContent);
						
					}
					*/
					var content=jQuery.decodeJsonTemplate(json);	
					content.appendTo(settings.showContent);
					var itemBottom=settings.showContent.height()+settings.showContent.offset().top+5;				
					settings.showContent.css("left",right);
					if(itemBottom<bottom){					
						settings.showContent.css("top",settings.showContent.offset().top+bottom-itemBottom);						
						settings.showContent.css("position","fixed");						
					}
				}
				else{
						settings.showContent.hide();
				}			
			
		};
		
		/***** 判断是否为json对象 *******
	* @param obj: 对象（可以是jq取到对象）
	* @return isjson: 是否是json对象 true/false
	*/
	var isJson = function(obj){
	var isjson = typeof(obj) == "object" && Object.prototype.toString.call(obj).toLowerCase() == "[object object]" && !obj.length;    
	return isjson;
	}
	
	jQuery(document).keydown(function(e) {
		var  item =	getDisplayItem().filter(".selected").get(0);	
		if(e.keyCode==40){
			item=jQuery(item).next().get(0);		
			if(item===undefined || !isShow(item)){
				goNext();
				return;
			}
		}
		else if(e.keyCode==38){
			item=jQuery(item).prev().get(0);
			if(item===undefined || !isShow(item)){
				goPrev();
				return;
			}
		}
		else if(e.keyCode==39){
			goNext();
				return;
			}
		else if(e.keyCode==37){
			goPrev();
			return;
		}
		else{
			return;
		}
		if(item!==undefined && isShow(item)){		
			setContent(jQuery(item));
		}
		
    });
	
	var getDisplayItem=function(){
		return items.filter(function(index) {
			return isShow($(this));
             
            });
	}
	
	var isShow=function(item){	
	
		return $(item).css("display")!=="none";			
	}
	
	init(); // run the function
};
