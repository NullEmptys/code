package com.hoolai.jdbc.parser;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.jdbc.analyzer.FColumn;

public class ParseRet {
    public final String sql;
    public int condCount;
    public List<FColumn> getColumns = new ArrayList<FColumn>();
    public List<FColumn> setColumns = new ArrayList<FColumn>();
	public ParseRet(String sql) {
		this.sql = sql;
	}
	public void incrCondCount() {
	    ++ this.condCount;
	}
	public int placeHolderCount() {
	    return setColumns.size();
	}
}