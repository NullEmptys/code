package com.hoolai.jdbc.compiler;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Time;
import java.sql.Timestamp;

import com.hoolai.jdbc.analyzer.FCodecs;
import com.hoolai.jdbc.analyzer.FColumn;
import com.hoolai.jdbc.analyzer.JColumn;
import com.hoolai.jdbc.analyzer.JTable;

/**
 * getter setter 解析
 * @author luzj
 */
class TypeCodec {
	
	//parser
	static <T> String makeParserBodyElement(FCodecs codecs, JTable jTable, FColumn fColumn, String type, String rs, int index) {
		return new StringBuilder()
		.append(type).append(".").append(parserSet(jTable, fColumn.jColumn))
		.append(fColumn.jColumn.isPrivate ? "(" : "=")
		.append(parserGet(codecs, rs, fColumn.jColumn, index))
		.append(fColumn.jColumn.isPrivate ? ");" : ";").toString();
	}
	//setter
	static <T> String makeSetterBodyElement(FCodecs codecs, JTable jTable, FColumn fColumn, String type, String rs, int index) {
		return new StringBuilder()
		.append(rs).append(".").append(setterSet(codecs, fColumn.jColumn)).append("(")
		.append(index).append(", ")
		.append(setterGet(codecs, jTable, type, fColumn.jColumn))
		.append(");").toString();
	}
	
	static String firstUpperCase(String x) {
    	return x.substring(0, 1).toUpperCase() + x.substring(1);
	}
	
	/**
	 * enum --> int
	 * array --> string
	 * @param jColumn
	 * @return
	 */
	static <T> String setterSet(FCodecs codecs, JColumn jColumn) {
		Class<?> c = codecs.hasCodec(jColumn.name) ? codecs.findDBJavaTypeFromCodec(jColumn.name) : jColumn.type;
        if(Boolean.class.equals(c) || boolean.class.equals(c)) {
            return "setBoolean";
        } else if(Byte.class.equals(c) || byte.class.equals(c)) {
            return "setByte";
        } else if(Character.class.equals(c) || char.class.equals(c)) {
            return "setShort";
        } else if(Short.class.equals(c) || short.class.equals(c)) {
            return "setShort";
        } else if(c.isEnum() || Integer.class.equals(c) || int.class.equals(c)) {
            return "setInt";
        } else if(Long.class.equals(c) || long.class.equals(c)) {
            return "setLong";
        } else if(Float.class.equals(c) || float.class.equals(c)) {
            return "setFloat";
        } else if(Double.class.equals(c) || double.class.equals(c)) {
            return "setDouble";
        } else if(Byte[].class.equals(c) || byte[].class.equals(c)) {
            return "setBytes";
        } else if(BigDecimal.class.equals(c)) {
            return "setBigDecimal";
        } else if(Reader.class.equals(c)) {
            return "setCharacterStream";
        } else if(InputStream.class.equals(c)) {
            return "setBinaryStream";
        } else if(java.sql.Date.class.equals(c)) {
            return "setDate";
        } else if(Time.class.equals(c)) {
            return "setTime";
        } else if(java.util.Date.class.equals(c) || Timestamp.class.equals(c)) {
            return "setTimestamp";
        } else if(Clob.class.equals(c)) {
            return "setClob";
        } else if(Blob.class.equals(c)) {
            return "setBlob";
        } else if(Character[].class.equals(c) || String.class.equals(c) || char[].class.equals(c)) {
            return "setString";
        }
        return null;
	}
	static <T> String setterGet(FCodecs codecs, JTable jTable, String type, JColumn jColumn) {
	    String getVal;
	    if(jColumn.isPrivate) {
	        String name = jTable.getter.get("get" + jColumn.name.toLowerCase());
	        if(name == null) {
	            name = jTable.getter.get("is" + jColumn.name.toLowerCase());
	        }
	        if(name == null && jColumn.name.startsWith("is")) {
	            name = jTable.getter.get(jColumn.name.toLowerCase());
	        }
	        if(name == null) {
	            name = "get" + firstUpperCase(jColumn.name);
	        }
	        getVal = type + "." + name + "()";
	    } else {
	        getVal = type + "." + jColumn.name;
	    }
	    if(codecs.hasCodec(jColumn.name)) {
	        getVal = primitiveSetterSetCasting(codecs.findDBJavaTypeFromCodec(jColumn.name), new StringBuilder().append("this.").append(CodeGenerator.codecFieldName(jColumn.name)).append(".encode(").append(getVal).append(")").toString());
	    }
	    return getVal;
	}
	static String primitiveSetterSetCasting(Class<?> c, String expr) {
	    expr = "((" + castingName(c) + ")" + expr + ")";
	    if(Boolean.class.equals(c)) {
	        return expr + ".booleanValue()";
	    } else if(Byte.class.equals(c)) {
	        return expr + ".byteValue()";
	    } else if(Short.class.equals(c)) {
	        return expr + ".shortValue()";
	    } else if(Integer.class.equals(c)) {
	        return expr + ".intValue()";
	    } else if(Long.class.equals(c)) {
	        return expr + ".longValue()";
	    } else if(Float.class.equals(c)) {
	        return expr + ".floatValue()";
	    } else if(Double.class.equals(c)) {
	        return expr + ".doubleValue()";
	    }
	    return expr;
	}
	static String parserSet(JTable jTable, JColumn jColumn) {
		if(jColumn.isPrivate) {
			return "set" + firstUpperCase(jColumn.name);
		}
		return jColumn.name;
	}
	
	static <T> String parserGet0(FCodecs codecs, JColumn jColumn) {
	    Class<?> c = codecs.hasCodec(jColumn.name) ? codecs.findDBJavaTypeFromCodec(jColumn.name) : jColumn.type;
        if(Boolean.class.equals(c) || boolean.class.equals(c)) {
            return "getBoolean";
        } else if(Byte.class.equals(c) || byte.class.equals(c)) {
            return "getByte";
        } else if(Character.class.equals(c) || char.class.equals(c)) {
            return "getShort";
        } else if(Short.class.equals(c) || short.class.equals(c)) {
            return "getShort";
        } else if(Integer.class.equals(c) || int.class.equals(c)) {
            return "getInt";
        } else if(Long.class.equals(c) || long.class.equals(c)) {
            return "getLong";
        } else if(Float.class.equals(c) || float.class.equals(c)) {
            return "getFloat";
        } else if(Double.class.equals(c) || double.class.equals(c)) {
            return "getDouble";
        } else if(Byte[].class.equals(c) || byte[].class.equals(c)) {
            return "getBytes";
        } else if(BigDecimal.class.equals(c)) {
            return "getBigDecimal";
        } else if(Reader.class.equals(c)) {
            return "getCharacterStream";
        } else if(InputStream.class.equals(c)) {
            return "getBinaryStream";
        } else if(java.sql.Date.class.equals(c)) {
            return "getDate";
        } else if(Time.class.equals(c)) {
            return "getTime";
        } else if(java.util.Date.class.equals(c) || Timestamp.class.equals(c)) {
            return "getTimestamp";
        } else if(Clob.class.equals(c)) {
            return "getClob";
        } else if(Blob.class.equals(c)) {
            return "getBlob";
        } else if(Character[].class.equals(c) || String.class.equals(c) || char[].class.equals(c)) {
            return "getString";
        }
        return null;
	}
	
	static String primitiveParserGetCasting(Class<?> c, String expr) {
	    if(Boolean.class.equals(c)) {
            return "Boolean.valueOf(" + expr + ")";
        } else if(Byte.class.equals(c)) {
            return "Byte.valueOf(" + expr + ")";
        } else if(Short.class.equals(c)) {
            return "Short.valueOf(" + expr + ")";
        } else if(Integer.class.equals(c)) {
            return "Integer.valueOf(" + expr + ")";
        } else if(Long.class.equals(c)) {
            return "Long.valueOf(" + expr + ")";
        } else if(Float.class.equals(c)) {
            return "Float.valueOf(" + expr + ")";
        } else if(Double.class.equals(c)) {
            return "Double.valueOf(" + expr + ")";
        }
	    return expr;
	}
	
    static <T> String parserGet(FCodecs codecs, String rs, JColumn jColumn, int index) {
		String rsget = new StringBuilder().append(rs).append(".").append(parserGet0(codecs, jColumn)).append("(").append(index).append(")").toString();
		Class<?> c = jColumn.type;
		if(codecs.hasCodec(jColumn.name)) {
		    return new StringBuilder().append("(").append(castingName(c)).append(")")//强制类型转换
		            .append("this.").append(CodeGenerator.codecFieldName(jColumn.name)).append(".decode(").append(primitiveParserGetCasting(codecs.findDBJavaTypeFromCodec(jColumn.name), rsget)).append(")").toString();
		}
		return rsget;
	}
    
    static String castingName(Class<?> c) {
        if(c.isArray()) {
            String end = "[]";
            Class<?> t = c.getComponentType();
            while(t.isArray()) {
                end += "[]";
                t = t.getComponentType();
            }
            return t.getName() + end;
        }
        return c.getName();
    }
	
}
