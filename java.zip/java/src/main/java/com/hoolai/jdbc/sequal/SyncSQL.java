package com.hoolai.jdbc.sequal;

import java.util.Collection;
import java.util.List;

import com.hoolai.jdbc.JDBCTemplate;
import com.hoolai.jdbc.PSSetter;
import com.hoolai.jdbc.compiler.AbtSQL;

public class SyncSQL<T> extends AbtSQL<T> {
    
    public SyncSQL(String sql, JDBCTemplate jdbcTemplate, int condCout, int batchLimit) {
        super(sql, jdbcTemplate, condCout, batchLimit);
    }
    
    //fetch
    public T fetchOne(PSSetter setter) {
        return jdbcTemplate.fetchOne(sql, setter, parser);
    }
    public List<T> fetchMany(PSSetter setter) {
        return (List<T>) jdbcTemplate.fetchMany(sql, setter, parser);
    }
    public List<T> fetchManyByIndex(Object idx) {
        return (List<T>) jdbcTemplate.fetchManyByOneCond(sql, idx, parser);
    }
    
    //update(also insert,delete)
    public boolean update(T value) {
       return UpdateUtil.update(jdbcTemplate, sql, setter, value);
    }
    public boolean update(PSSetter setter) {
        return jdbcTemplate.update(sql, setter);
    }
    
    
    public boolean updateBatch(T[] values) {
        return UpdateUtil.updateBatch(jdbcTemplate, batchLimit, sql, setter, values);
    }
    public boolean updateBatch(Collection<T> values) {
        return UpdateUtil.updateBatch(jdbcTemplate, batchLimit, sql, setter, values);
    }
    
    
    /*-------------不推荐使用-------------*/
    public boolean updateBatchWithSetter(PSSetter... setters) {
        return UpdateUtil.updateBatch(jdbcTemplate, batchLimit, sql, setters);
    }
    public boolean updateBatchWithSetter(Collection<PSSetter> setters) {
        return UpdateUtil.updateBatch(jdbcTemplate, batchLimit, sql, setters);
    }
    
    public boolean updateByKey(Object key) {
        if(!isPureCond) {
            throw new IllegalArgumentException("None pure condition for [" + sql + "] to use SQL.updateByOneCond");
        }
        return jdbcTemplate.updateByOneCond(sql, key);
    }
    public T fetchOneByKey(Object key) {
        if(!isPureCond) {
            throw new IllegalArgumentException("None pure condition for [" + sql + "] to use SQL.fetchOneByOneCond");
        }
        return jdbcTemplate.fetchOneByOneCond(sql, key, parser);
    }
    
}
