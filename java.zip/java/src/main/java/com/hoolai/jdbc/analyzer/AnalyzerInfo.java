package com.hoolai.jdbc.analyzer;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.hoolai.jdbc.Configuration;
import com.hoolai.jdbc.Customizer.Pending;
import com.hoolai.jdbc.JDBCTemplate;
import com.hoolai.jdbc.codec.FieldCodec;
import com.hoolai.jdbc.compiler.AbtSQL;
import com.hoolai.jdbc.sequal.AsyncSQL;
import com.hoolai.jdbc.sequal.SyncSQL;

public class AnalyzerInfo<T> {
    
    private transient String tableName;
    private transient Class<T> clazz;
    private transient Map<String, String> mappings;
    private transient Pending[] pendings = new Pending[0];
    private transient Enum<?> dbType;
    private transient JDBCTemplate jdbcTemplate;
    private transient int asyncModel = -1;
    private transient Map<String, FieldCodec<?, ?>> fieldCodeces;
    private transient Map<Class<?>, FieldCodec<?, ?>> fieldTypeCodeces;
    
    public AnalyzerInfo(Class<T> clazz) {
        this.clazz = clazz;
        this.mappings = new HashMap<String, String>();
        this.fieldCodeces = new HashMap<String, FieldCodec<?,?>>();
        this.fieldTypeCodeces = new HashMap<Class<?>, FieldCodec<?, ?>>();
    }
    
    public void configureAsyncModel(boolean asyncModel) {
        this.asyncModel = (asyncModel ? 1 : 0);
    }

    public void binding(Enum<?> type) {
        this.dbType = type;
    }
    
    public void binding(Enum<?> type, String tableName){
        this.dbType = type;
        this.tableName = tableName;
    }
    
    public void binding(JDBCTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    
    public void binding(JDBCTemplate jdbcTemplate, String tableName) {
        this.jdbcTemplate = jdbcTemplate;
        this.tableName = tableName;
    }
    
    public void binding(int idx, Pending pending) {
        int nl = Math.max(idx, pendings.length) + 1;
        pendings = Arrays.copyOf(pendings, nl);
        pendings[idx] = pending;
    }
    
    public void binding(String fieldName, FieldCodec<?, ?> codec) {
        this.fieldCodeces.put(fieldName, codec);
    }
    
    public void binding(Class<?> fieldType, FieldCodec<?, ?> codec) {
        this.fieldTypeCodeces.put(fieldType, codec);
    }
    
    public boolean hasCodec(String fieldName) {
        return fieldCodeces.containsKey(fieldName);
    }
    
    public boolean hasCodec(Class<?> fieldType) {
        return fieldTypeCodeces.containsKey(fieldType) || Configuration.hasFieldCodec(fieldType);
    }
    
    public FieldCodec<?, ?> getCodec(String fieldName) {
    	return fieldCodeces.get(fieldName);
    }
    public FieldCodec<?, ?> getCodec(Field field) {
        return fieldTypeCodeces.containsKey(field.getType()) ? fieldTypeCodeces.get(field.getType()) : Configuration.getFieldCodec(field);
    }
    
    public void mapping(String fieldName, String columnName) {
        this.mappings.put(fieldName, columnName);
    }
    
    public Map<String, String> mappings() {
        return mappings;
    }
    
    public Pending[] pendings() {
        return this.pendings;
    }
    
    public JDBCTemplate jdbcTemplate() {
        if(jdbcTemplate == null)
            jdbcTemplate = Configuration.getJDBCTemplate(dbType);
        return jdbcTemplate;
    }
    
    public boolean hasBindingTable() {
        return this.tableName != null;
    }
    
    public Class<T> clazz() {
        return this.clazz;
    }
    
    public Map<String, FieldCodec<?, ?>> fieldCodeces() {
        return this.fieldCodeces;
    }
    
    public AbtSQL<T> buildSQL(String sql, int condCout, int batchLimit) {
        return asyncModel == 1 || (asyncModel == -1 && Configuration.isAsyncModule()) ? 
                new AsyncSQL<T>(sql, this.jdbcTemplate(), condCout, batchLimit) :
                new SyncSQL<T>(sql, this.jdbcTemplate(), condCout, batchLimit);
    }

    public String tableName() {
        return tableName;
    }
    
    public Map<Class<?>, FieldCodec<?, ?>> typeCodeces() {
        return fieldTypeCodeces;
    }

}
