package com.hoolai.jdbc.compiler;

import com.hoolai.jdbc.JDBCTemplate;
import com.hoolai.jdbc.RSParser;
import com.hoolai.jdbc.SQL;
import com.hoolai.jdbc.TypePSSetter;

public abstract class AbtSQL<T> implements SQL<T> {

    protected final String sql;
    protected final boolean isPureCond;
    protected final JDBCTemplate jdbcTemplate;
    
    protected TypePSSetter<T> setter;
    protected RSParser<T> parser;
    
    protected final int batchLimit;

    public AbtSQL(String sql, JDBCTemplate jdbcTemplate, int condCout, int batchLimit) {
        this.sql = sql;
        this.jdbcTemplate = jdbcTemplate;
        this.isPureCond = (condCout == 1);//是否where子句中只有一个参数 非单一参数不支持byOneCond方法
        this.batchLimit = batchLimit;
    }

    @Override
    public String toString() {
        return sql;
    }
    
}