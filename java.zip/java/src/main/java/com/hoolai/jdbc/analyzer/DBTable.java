package com.hoolai.jdbc.analyzer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * db table
 * @author luzj
 *
 */
public class DBTable {
	String tableName;
	List<DBColumn> primaryKeys;
	List<DBIndex> uniqueIndexs;
	
	Map<String, DBColumn> columns;
	
	public DBTable(String name) {
		this.tableName = name;
		this.primaryKeys = new ArrayList<DBColumn>();
		this.uniqueIndexs = new ArrayList<DBIndex>();
		this.columns = new HashMap<String, DBColumn>();
	}
	public void addDBIndex(String keyName, boolean nonUnique, DBColumn column) {
	    DBIndex idx = null;
	    for (DBIndex dbIndex : uniqueIndexs) {
            if(dbIndex.keyNmae.equals(keyName)) {
                idx = dbIndex;
                break;
            }
        }
	    if(idx == null) {
	        idx = new DBIndex(keyName, nonUnique);
	        uniqueIndexs.add(idx);
	    }

	    idx.columns.add(column);
	}
	
	public DBColumn getDBColumn(String columnName) {
	    return columns.get(columnName.toLowerCase());
	}
	
	public void addDBColumn(DBColumn dbColumn) {
	    this.columns.put(dbColumn.name.toLowerCase(), dbColumn);
	}
	
}