package com.hoolai.jdbc.sequal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutorService;

import com.hoolai.jdbc.Configuration;
import com.hoolai.jdbc.JDBCTemplate;
import com.hoolai.jdbc.PSSetter;
import com.hoolai.jdbc.compiler.AbtSQL;

/**
 * 查询还是同步
 * 异步保存
 * @author luzj
 * @param <T>
 */
public class AsyncSQL<T> extends AbtSQL<T> {
    
    private final ExecutorService executor;
    
    public AsyncSQL(String sql, JDBCTemplate jdbcTemplate, int condCout, int batchLimit) {
        super(sql, jdbcTemplate, condCout, batchLimit);
        this.executor = Configuration.getExecutor();
    }
    
    //fetch
    public T fetchOne(PSSetter setter) {
        return jdbcTemplate.fetchOne(sql, setter, parser);
    }
    public List<T> fetchMany(PSSetter setter) {
        return (List<T>) jdbcTemplate.fetchMany(sql, setter, parser);
    }
    public List<T> fetchManyByIndex(Object idx) {
        return (List<T>) jdbcTemplate.fetchManyByOneCond(sql, idx, parser);
    }
    
    //update(also insert,delete)
    public boolean update(final T value) {
        if(UpdateUtil.updatable(value)) {
            execute(()->UpdateUtil.update(jdbcTemplate, sql, setter, value));
            return true;
        }
        return false;
    }
    public boolean update(final PSSetter setter) {
        execute(()->jdbcTemplate.update(sql, setter));
        return true;
    }
    
    
    public boolean updateBatch(final T[] values) {
        execute(()->UpdateUtil.updateBatch(jdbcTemplate, batchLimit, sql, setter, values));
        return true;
    }
    public boolean updateBatch(final Collection<T> values) {
        List<T> vs = new ArrayList<>(values);
        execute(()->UpdateUtil.updateBatch(jdbcTemplate, batchLimit, sql, setter, vs));
        return true;
    }
    
    
    /*-------------不推荐使用-------------*/
    public boolean updateBatchWithSetter(final PSSetter... setters) {
        execute(()->UpdateUtil.updateBatch(jdbcTemplate, batchLimit, sql, setters));
        return true;
    }
    public boolean updateBatchWithSetter(final Collection<PSSetter> setters) {
        execute(()->UpdateUtil.updateBatch(jdbcTemplate, batchLimit, sql, setters));
        return true;
    }
    
    public boolean updateByKey(final Object key) {
        if(!isPureCond) {
            throw new IllegalArgumentException("None pure condition for [" + sql + "] to use SQL.updateByOneCond");
        }
        
        execute(()->jdbcTemplate.updateByOneCond(sql, key));
        return true;
    }
    
    private void execute(SQLTask task) {
        if(executor.isShutdown()) {
            task.run();
        } else {
            executor.execute(task);
        }
    }

    public T fetchOneByKey(Object key) {
        if(!isPureCond) {
            throw new IllegalArgumentException("None pure condition for [" + sql + "] to use SQL.fetchOneByOneCond");
        }
        return jdbcTemplate.fetchOneByOneCond(sql, key, parser);
    }
    
}
