package com.hoolai.jdbc;

import java.util.Collection;
import java.util.List;

import com.hoolai.jdbc.Customizer.Pending;
import com.hoolai.jdbc.analyzer.Analyzer;
import com.hoolai.jdbc.analyzer.AnalyzerInfo;
import com.hoolai.jdbc.analyzer.FTable;
import com.hoolai.jdbc.codec.FieldCodec;
import com.hoolai.jdbc.compiler.SQLCompiler;
import com.hoolai.jdbc.compiler.SQLGenerator;


/**
 * 一一对应一张数据库表与一个java实体类(Entity)
 * 绑定一个数据库类型(每个类型对应一个连接池)
 * 
 * Java Entity
 * 对应Field为private时 使用Setter/Getter方法, 其他情况直接访问属性
 * 
 * @author luzj
 */
public class TypeQuery<T> {
	
    private transient AnalyzerInfo<T> info;
    
    private String tableName;
    //final compiled sqls
	private SQL<T>[] sqls;

	public static final int    ALL = 127;
	public static final int  QUERY = 1;
	public static final int INSERT = 2;
	public static final int DELETE = 4;
	public static final int UPDATE = 8;
	public static final int INSTUP = 16;//insert update
	
	private int without;
	
	public TypeQuery(Class<T> clazz) {
		this.info = new AnalyzerInfo<T>(clazz);
	}
	
	public TypeQuery<T> configureAsyncModel(boolean asyncModel) {
	    info.configureAsyncModel(asyncModel);
	    return this;
	}
	
	/**
	 * 不自动生成哪些类型的SQL
	 * Demo:
	 *     query.without(TypeQuery.QUERY | TypeQuery.INSERT | TypeQuery.DELETE | TypeQuery.UPDATE)
	 * @param without
	 * @return
	 */
	public TypeQuery<T> without(int without) {
	    this.without = without;
	    return this;
	}
	
	
	/**
	 * 映射Java实体字段与数据库字段
	 * @param fieldName Java实体字段
	 * @param columnName 数据库字段
	 * @return
	 */
	public TypeQuery<T> mapping(String fieldName, String columnName) {
	    info.mapping(fieldName, columnName);
		return this;
	}
	
	/**
	 * 绑定datasource类型
	 * @param type
	 * @return
	 */
	public TypeQuery<T> binding(Enum<?> type) {
	    info.binding(type);
		return this;
	}
	
	public TypeQuery<T> binding(Enum<?> type, String tableName) {
	    this.tableName = tableName;
	    
	    info.binding(type, tableName);
		return this;
	}
	
	public TypeQuery<T> binding(JDBCTemplate jdbcTemplate, String tableName) {
        this.tableName = tableName;
        
        info.binding(jdbcTemplate, tableName);
        return this;
    }
	
	public TypeQuery<T> binding(JDBCTemplate jdbcTemplate) {
	    info.binding(jdbcTemplate);
        return this;
    }
    
	public TypeQuery<T> binding(int idx, String sql) {
	    return binding(idx, Customizer.customWith(sql));
	}
	
	public TypeQuery<T> binding(int idx, Pending pending) {
	    info.binding(idx, pending);
	    return this;
	}
	
	public TypeQuery<T> binding(String fieldName, FieldCodec<?, ?> codec) {
	    info.binding(fieldName, codec);
	    return this;
	}
	
	public TypeQuery<T> binding(Class<?> fieldType, FieldCodec<?, ?> codec) {
        info.binding(fieldType, codec);
        return this;
    }
	
	public SQL<T> load(int idx) {
	    compile();
		return sqls[idx];
	}
	
	private SQL<T> qryall;
	public List<T> fetchall() {
	    compile();
	    checkSQL(qryall);
		return qryall.fetchMany(PSSetter.NONE);
	}
	
	private SQL<T> qrykey;
	public T fetchoneByKey(Object key) {
	    compile();
		checkSQL(qrykey);
		return qrykey.fetchOneByKey(key);
	}
	public T fetchoneByKey(PSSetter key) {
	    compile();
	    checkSQL(qrykey);
	    return qrykey.fetchOneByKey(key);
	}
	
	private SQL<T> insert;
	public boolean insert(T obj) {
	    compile();
	    checkSQL(insert);
		return insert.update(obj);
	}
	public boolean insertBatch(Collection<T> objs) {
	    compile();
	    checkSQL(insert);
        return insert.updateBatch(objs);
    }
	public boolean insertBatch(T[] objs) {
	    compile();
	    checkSQL(insert);
	    return insert.updateBatch(objs);
	}
	
	private SQL<T> instup;
    public boolean instup(T obj) {
        compile();
        checkSQL(instup);
        return instup.update(obj);
    }
    public boolean instupBatch(T[] objs) {
        compile();
        checkSQL(instup);
        return instup.updateBatch(objs);
    }
    public boolean instupBatch(Collection<T> objs) {
        compile();
        checkSQL(instup);
        return instup.updateBatch(objs);
    }
	
	private SQL<T> update;
	public boolean updateByKey(T obj) {
	    compile();
		checkSQL(update);
		return update.update(obj);
	}
	public boolean updateBatchByKey(T[] objs) {
	    compile();
	    SQL<T> sql = instup == null ? update : instup;
	    checkSQL(sql);
	    return sql.updateBatch(objs);
	}
	public boolean updateBatchByKey(Collection<T> objs) {
	    compile();
	    SQL<T> sql = instup == null ? update : instup;
	    checkSQL(sql);
	    return sql.updateBatch(objs);
	}
	
	private SQL<T> delete;
	public boolean deleteByKey(Object key) {
	    compile();
		checkSQL(delete);
		return delete.updateByKey(key);
	}
	public boolean deleteByKey(PSSetter setter) {
	    compile();
	    checkSQL(delete);
	    return delete.update(setter);
	}
	
    private void checkSQL(SQL<T> sql) {
        if(tableName == null) {
            throw new IllegalArgumentException("None binding table");
        }
        if(sql == null) {
            throw new IllegalArgumentException("Current SQL is None, Make sure the table:[" + tableName + "] has primary key and SQL not int the 'without' settings");
        }
    }
	
    public TypeQuery<T> compile() {
        if(this.info == null) return this;
        synchronized(this.info) {
            if(this.info == null) return this;//double check
            
            try {
                FTable ftable = Analyzer.analyze(info);

                if((without & QUERY) == 0) {
                    this.qryall = SQLGenerator.genQuerySQL(info, ftable);
                    this.qrykey = SQLGenerator.genQryKeySQL(info, ftable, qryall);
                }

                if((without & INSERT) == 0)
                    this.insert = SQLGenerator.genInsertSQL(info, ftable);

                if((without & INSTUP) == 0)
                    this.instup = SQLGenerator.genInstupSQL(info, ftable, insert);

                if((without & DELETE) == 0)
                    this.delete = SQLGenerator.genDeleteSQL(info, ftable);

                if((without & UPDATE) == 0)
                    this.update = SQLGenerator.genUpdateSQL(info, ftable);

                this.sqls = SQLCompiler.compile(info, ftable);

                this.info = null;
            } catch (Exception e) {
                throw new IllegalArgumentException(e);
            }
        }
        return this;
    }
    
    public static void shutdown() {
        Configuration.shutdown();
    }
    
}
