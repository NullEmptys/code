package com.hoolai.jdbc.compiler;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import com.hoolai.jdbc.RSParser;
import com.hoolai.jdbc.TypePSSetter;
import com.hoolai.jdbc.analyzer.FCodecs;
import com.hoolai.jdbc.analyzer.FColumn;
import com.hoolai.jdbc.analyzer.FTable;
import com.hoolai.jdbc.codec.FieldCodec;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.CtField;
import javassist.CtMethod;
import javassist.CtNewMethod;

public class CodeGenerator {
	
	private transient final static AtomicInteger ai = new AtomicInteger(0);
    private static int complieIndex() {
        return ai.incrementAndGet();
    }

    @SuppressWarnings("unchecked")
    static <T> RSParser<T> makeParser(FTable ftable, List<FColumn> columns) throws Exception {
        String clazzName = ftable.clazz.getName();
        ClassPool pool = ClassPool.getDefault();
        CtClass clazz = pool.makeClass(clazzName + "$RSParser_" + (complieIndex()));
        clazz.addInterface(pool.getCtClass(RSParser.class.getName()));
        
        StringBuilder body = new StringBuilder("{");
        body.append(clazzName).append(" _tmp_ = new ").append(clazzName).append("();");
        int index = 1;
        for (FColumn fColumn : columns) {
            body.append(TypeCodec.makeParserBodyElement(ftable.codecs, ftable.jTable, fColumn, "_tmp_", "$1", index));
            ++index;
        }
        body.append("return _tmp_;").append("}");
        
        makeCodecFieldsAndConstructor(ftable.codecs, pool, clazz);//先解析columns才有codecFields, 先添加codecFields才能生成body
        
        CtMethod parser = CtNewMethod.copy(pool.getMethod(RSParser.class.getName(), "parse"), clazz, null);
        parser.setBody(body.toString());
        clazz.addMethod(parser);
        
        return (RSParser<T>) newInstance(ftable.codecs, clazz);
    }
    
    @SuppressWarnings("unchecked")
    static <T> Object newInstance(FCodecs codecs, CtClass clazz) throws Exception {
        return clazz.toClass().getConstructor(Map.class).newInstance(codecs.get());
    }
    
    static <T> void makeCodecFieldsAndConstructor(FCodecs codecs, ClassPool pool, CtClass clazz) throws Exception {
        Map<String, FieldCodec<?, ?>> codeces = codecs.get();
        StringBuilder body = new StringBuilder("{");
        Set<String> keys = codeces.keySet();
        for (String key : keys) {
            CtField cf = CtField.make(makeCodecFieldBody(key), clazz);
            clazz.addField(cf);
            body.append(makeCodecAssignmentBody(key));
        }
        
        CtClass[] paramters = new CtClass[]{pool.get(Map.class.getName())};
        CtConstructor ctConstructor = new CtConstructor(paramters, clazz);
        ctConstructor.setBody(body.append("}").toString());
        clazz.addConstructor(ctConstructor);
    }
    
    static String makeCodecFieldBody(String jfieldName) {
        return new StringBuilder().append("private ").append(FieldCodec.class.getName()).append(" ").append(codecFieldName(jfieldName)).append(";").toString();
    }
    
    static String makeCodecAssignmentBody(String jfieldName) {
        return new StringBuilder().append("this.").append(codecFieldName(jfieldName)).append(" = (").append(FieldCodec.class.getName()).append(")$1.get(\"").append(jfieldName).append("\");").toString();
    }
    
    @SuppressWarnings("unchecked")
    static <T> TypePSSetter<T> makeSetter(FTable ftable, List<FColumn> columns) throws Exception {
        String clazzName = ftable.clazz.getName();
        ClassPool pool = ClassPool.getDefault();
        CtClass clazz = pool.makeClass(clazzName + "$TypePSSetter_" + (complieIndex()));
        clazz.addInterface(pool.getCtClass(TypePSSetter.class.getName()));
        
        
        StringBuilder body = new StringBuilder("{");
        body.append(clazzName).append(" _tmp_ = (").append(clazzName).append(") $2;");
        int index = 1;
        for (FColumn fColumn : columns) {
            body.append(TypeCodec.makeSetterBodyElement(ftable.codecs, ftable.jTable, fColumn, "_tmp_", "$1", index));
            ++index;
        }
        body.append("}");
        
        makeCodecFieldsAndConstructor(ftable.codecs, pool, clazz);//先解析columns才有codecFields, 先添加codecFields才能生成body
        
        CtMethod setter = CtNewMethod.copy(pool.getMethod(TypePSSetter.class.getName(), "set"), clazz, null);
        setter.setBody(body.toString());
        clazz.addMethod(setter);
        
        return (TypePSSetter<T>) newInstance(ftable.codecs, clazz);   
    }

    public static String codecFieldName(String jfieldName) {
        return jfieldName + "_codec";
    }
    
}
