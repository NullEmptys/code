package com.hoolai.jdbc.codec;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CodecUtil {
    
    public static final ElementEncoder<Object> SIMPLE_VALUE_ENCODER = new ElementEncoder<Object>() {
        @Override
        public String encode(Object v) {
            return String.valueOf(v);
        }
    };
    
    private static final Map<Class<?>, ElementDecoder<?>> ELEMENT_DECODERS = new HashMap<Class<?>, ElementDecoder<?>>();
    
    private static final Map<Class<?>, PrimitiveDecoder<?>> PRIMITIVE_DECODERS = new HashMap<Class<?>, PrimitiveDecoder<?>>();
    
    private static final Map<Class<?>, CollectionFactory<?>> COLLECTION_FACTORIES = new HashMap<Class<?>, CollectionFactory<?>>();
    
    public static int pack(int typeOrDelemiter, char delimiter) {
        return (typeOrDelemiter & 0xFF) | (delimiter << 8);
    }
    
    public static int unpack1(int val) {
        return val & 0xFF;
    }
    
    public static int unpack1(int val, int defaultVal) {
        int r = unpack1(val);
        return r == 0 ? unpack1(defaultVal) : r;
    }
    
    public static int unpack2(int val) {
        return (val >> 8) & 0xFF;
    }
    
    public static int unpack2(int val, int defaultVal) {
        int r = unpack2(val);
        return r == 0 ? unpack2(defaultVal) : r;
    }
    
    @SuppressWarnings("unchecked")
    public static FieldCodec<?, ?> fetchCodec(Field field) {//array or list/set
        Class<?> type = field.getType();
        return type.isEnum() ? EnumCodec.fetchCodec((Class<? extends Enum<?>>) type) : (type.isArray() ? ArrayCodec.fetchCodec(field) : ListSetCodec.fetchCodec(field));
    }
    
    @SuppressWarnings("unchecked")
    public static <T> ElementDecoder<T> getElementDecoder(Class<T> clazz) {
        return (ElementDecoder<T>) ELEMENT_DECODERS.get(clazz);
    }
    
    @SuppressWarnings("unchecked")
    public static <T> PrimitiveDecoder<T> getPrimitiveDecoder(Class<T> clazz) {
        return (PrimitiveDecoder<T>) PRIMITIVE_DECODERS.get(clazz);
    }
    
    @SuppressWarnings("unchecked")
    public static <T> CollectionFactory<T> getCollectionFactory(Class<T> clazz) {
        CollectionFactory<T> factory = (CollectionFactory<T>) COLLECTION_FACTORIES.get(clazz);
        if(factory == null && clazz.isArray()) {//Array factory 自动创建
            final Class<?> component = clazz.getComponentType();
            factory = new CollectionFactory<T>() {
                @Override
                public T newCollection(int size) {
                    return (T) Array.newInstance(component, size);
                }
            };
            COLLECTION_FACTORIES.put(clazz, factory);
        }
        return factory;
    }
    
    static {
        PRIMITIVE_DECODERS.put(int[].class, new PrimitiveDecoder<int[]>() {
            @Override
            public void decode(int[] f, int index, String val) {
                f[index] = Integer.parseInt(val);
            }
        });
        PRIMITIVE_DECODERS.put(long[].class, new PrimitiveDecoder<long[]>() {
            @Override
            public void decode(long[] f, int index, String val) {
                f[index] = Long.parseLong(val);
            }
        });
        PRIMITIVE_DECODERS.put(float[].class, new PrimitiveDecoder<float[]>() {
            @Override
            public void decode(float[] f, int index, String val) {
                f[index] = Float.parseFloat(val);
            }
        });
        PRIMITIVE_DECODERS.put(double[].class, new PrimitiveDecoder<double[]>() {
            @Override
            public void decode(double[] f, int index, String val) {
                f[index] = Double.parseDouble(val);
            }
        });
        
        
        ELEMENT_DECODERS.put(Integer.class, new ElementDecoder<Integer>() {
            @Override
            public Integer decode(String va) {
                return Integer.parseInt(va);
            }
        });
        ELEMENT_DECODERS.put(Long.class, new ElementDecoder<Long>() {
            @Override
            public Long decode(String va) {
                return Long.parseLong(va);
            }
        });
        ELEMENT_DECODERS.put(Float.class, new ElementDecoder<Float>() {
            @Override
            public Float decode(String va) {
                return Float.parseFloat(va);
            }
        });
        ELEMENT_DECODERS.put(Double.class, new ElementDecoder<Double>() {
            @Override
            public Double decode(String va) {
                return Double.parseDouble(va);
            }
        });
        
        
        ELEMENT_DECODERS.put(String.class, new ElementDecoder<String>() {
            @Override
            public String decode(String va) {
                return va;
            }
        });
        
        
        COLLECTION_FACTORIES.put(List.class, new CollectionFactory<List<?>>() {
            @Override @SuppressWarnings("rawtypes")
            public List<?> newCollection(int size) {
                return new ArrayList();
            }
        });
        COLLECTION_FACTORIES.put(Set.class, new CollectionFactory<Set<?>>() {
            @Override @SuppressWarnings("rawtypes")
            public Set<?> newCollection(int size) {
                return new HashSet();
            }
        });
    }
}

interface PrimitiveDecoder<F> {
    public void decode(F f, int index, String val);
}

interface ElementDecoder<V> {
    public V decode(String va);
}

interface ElementEncoder<V> {
    public String encode(V v);
}

interface CollectionFactory<T> {
    public T newCollection(int size);
}
