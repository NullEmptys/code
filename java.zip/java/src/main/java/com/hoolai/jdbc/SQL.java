package com.hoolai.jdbc;

import java.util.Collection;
import java.util.List;

/**
 * 对应一个SQL
 * @author luzj
 * @param <T>
 */
public interface SQL<T> {
	
	//fetch
	public T fetchOne(PSSetter setter);
	
	public List<T> fetchMany(PSSetter setter);
	public List<T> fetchManyByIndex(Object idx);
	
	//update(also insert,delete)
	public boolean update(T value);
	public boolean update(PSSetter setter);
	
	public boolean updateBatch(T[] values);
	public boolean updateBatch(Collection<T> values);
	
	/*-------------不推荐使用-------------*/
	public boolean updateBatchWithSetter(PSSetter... setters);
	public boolean updateBatchWithSetter(Collection<PSSetter> setters);
	
	public boolean updateByKey(Object key);
	public T fetchOneByKey(Object key);
}
