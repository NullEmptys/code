package com.hoolai.jdbc;

public class Customizer {

    public static Pending customWith(String sql) {
        return new Pending(sql);
    }
    
    public static Pending queryWith(String... whereColumns) {
        return new Pending(TypeQuery.QUERY, whereColumns);
    }
    
    public static Pending deleteWith(String... whereColumns) {
        return new Pending(TypeQuery.DELETE, whereColumns);
    }
    
    public static Pending updateWith(String... whereColumns) {
        return new Pending(TypeQuery.UPDATE, whereColumns);
    }
    
    public static class Pending {
        public final int option;
        public final String[] columnNames;
        public final String sql;
        
        private Pending(int option, String... columnNames) {
            this.option = option;
            this.columnNames = columnNames;
            this.sql = null;
        }
        
        private Pending(String sql) {
            this.sql = sql;
            this.option = 0;
            this.columnNames = null;
        }
        
        public boolean isCustom() {
            return sql != null;
        }

        public boolean isQuery() {
            return option == TypeQuery.QUERY;
        }
        
        public boolean isUpdate() {
            return option == TypeQuery.UPDATE;
        }
        
        public boolean isDelete() {
            return option == TypeQuery.DELETE;
        }
    }
}
