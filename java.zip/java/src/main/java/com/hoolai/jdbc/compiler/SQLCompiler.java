package com.hoolai.jdbc.compiler;

import java.util.ArrayList;
import java.util.List;

import com.hoolai.jdbc.Customizer.Pending;
import com.hoolai.jdbc.SQL;
import com.hoolai.jdbc.analyzer.AnalyzerInfo;
import com.hoolai.jdbc.analyzer.FColumn;
import com.hoolai.jdbc.analyzer.FTable;
import com.hoolai.jdbc.parser.ParseRet;
import com.hoolai.jdbc.parser.SQLParser;


/**
 * 
 * compile binding sqls
 * @author luzj
 *
 */
public class SQLCompiler {
    
    @SuppressWarnings("unchecked")
    public static <T> SQL<T>[] compile(AnalyzerInfo<T> info, FTable ftable) throws Exception {
        SQL<T>[] csqls = new SQL[info.pendings().length];
        for (int i = 0; i < info.pendings().length; i++) {
            Pending pending = info.pendings()[i];
            if(pending == null) continue;
            csqls[i] = compile(info, ftable, pending);
        }
        return csqls;
    }

    //自定义sql 先生成对应的sql
    static <T> SQL<T> compile(AnalyzerInfo<T> info, FTable ftable, Pending pending) throws Exception {
        if(pending.isCustom())
            return compile(info, ftable, pending.sql);
        
        List<FColumn> whereColumns = new ArrayList<FColumn>();
        for (String columnName : pending.columnNames) {
            //如果where column使用的是java field name, 先转换成columnName;
            String name = ((info.mappings().containsKey(columnName)) ? info.mappings().get(columnName) : columnName).toLowerCase();
            
            FColumn fColumn = ftable.mappings.get(name);
            
            if(fColumn == null) throw new IllegalArgumentException(columnName + " not exists in the table " + ftable.tableName);
            
            whereColumns.add(fColumn);
        }
        
        if(pending.isQuery() && avaliable(info, ftable, whereColumns, false))
            return SQLGenerator.genQuerySQL(info, ftable, whereColumns);
        
        if(pending.isDelete() && avaliable(info, ftable, whereColumns, true))
            return SQLGenerator.genDeleteSQL(info, ftable, whereColumns);
        
        if(pending.isUpdate() && avaliable(info, ftable, whereColumns, true))
            return SQLGenerator.genUpdateSQL(info, ftable, whereColumns);
        
        throw new IllegalArgumentException("None supported optaion [" + pending.option + "]");
    }
    
    //check where columns is index or unique key
    static <T> boolean avaliable(AnalyzerInfo<T> info, FTable ftable, List<FColumn> whereColumns, boolean onlyUnique) {
        // TODO Auto-generated method stub
        return true;
    }

    static <T> SQL<T> compile(AnalyzerInfo<T> info, FTable ftable, String sql) throws Exception {
        ParseRet pr = new SQLParser(ftable, sql).parse();
        
        AbtSQL<T> r = info.buildSQL(pr.sql, pr.condCount, ftable.batchLimit(pr.setColumns.size()));
        
        if(!pr.setColumns.isEmpty()) {
            r.setter = CodeGenerator.makeSetter(ftable, pr.setColumns);
        }
        if(!pr.getColumns.isEmpty()) {
            r.parser = CodeGenerator.makeParser(ftable, pr.getColumns);
        }
        return r;
    }

}
