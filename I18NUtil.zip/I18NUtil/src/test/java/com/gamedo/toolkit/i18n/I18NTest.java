package com.gamedo.toolkit.i18n;

import java.util.Date;
import java.util.Locale;

import com.gamedo.toolkit.i18n.I18NUtil;

public class I18NTest {
	public static String I18N_TEST;
	static {
		//Locale locale = new Locale("汉语", "中国", "北京话");
		Locale.setDefault(Locale.CHINESE);
		System.out.println(Locale.getDefault().toString() + "-" + Locale.getDefault().getLanguage());
		//Locale.setDefault(Locale.ENGLISH);
		I18NUtil.initClass(I18NTest.class);
	}

	public static void main(String[] args) {
		System.out.println(I18NUtil.format(I18NTest.class, "testResource",
				"这里有数字和日期", 1500000, new Date()));
		System.out.println(I18N_TEST);
	}
}
