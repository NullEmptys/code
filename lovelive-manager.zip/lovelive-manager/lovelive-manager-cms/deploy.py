#!/usr/bin/python

import sys
import requests
import json
import subprocess
import time

json = {
	  "id": "critz-cms",
	  "container": {
	    "docker": {
	      "image": "192.168.1.130:5000/gamedo/critz-cms:latest",
	      "network": "BRIDGE",
	      "portMappings": [
	        {"containerPort": 8980, "servicePort": 8000}
	      ]
	    }
	  },
	  "cpus": 0.2,
	  "mem": 1024.0,
	  "instances": 1
	}

def restart_apps(marathon_host,app_id):
	host = 'http://' + marathon_host + '/v2/apps/'+app_id + '/restart'
	response = requests.post(host).json()

def deploy_apps(marathon_host):
	host = 'http://' + marathon_host + '/v2/apps/'
	requests.post(host,data=json)

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print('ERROR: Usage:', sys.argv[0], '<marathon_host> <app_id>')
        sys.exit(1)

    marathon_host = sys.argv[1]
    app_id = sys.argv[2]

    host = 'http://' + marathon_host + '/v2/apps/'+app_id
    response = requests.get(host).json()
    if response['app']:
    	restart_apps(marathon_host,app_id)
    else:
    	deploy_apps(marathon_host)

    sys.exit(0)