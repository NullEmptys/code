package net.gamedo.server.paradise.service.statistics;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import net.gamedo.server.paradise.cms.Constants;
import net.gamedo.server.paradise.cms.service.statistics.BusscheduleService;
import net.gamedo.server.paradise.model.primary.Busschedule;
import net.gamedo.server.paradise.model.primary.player.Email;
import net.gamedo.server.paradise.model.primary.player.EmailAttach;
import net.gamedo.server.paradise.model.thirdary.player.Item;
import net.gamedo.server.paradise.repository.primary.EmailRepository;
import net.gamedo.server.paradise.repository.thirdary.ItemRepository;
import net.gamedo.server.paradise.utils.NetWorkUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by TruthBean on 2016/4/11 0011.
 */
@Service
public class EmailService {

    private Logger logger = Logger.getLogger(getClass().getName());

    @Autowired
    private EmailRepository mailRepository;
    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private PlayerService playerService;

    @Autowired
    private BusscheduleService bs;


    public Email save(Email mail, boolean isSendNow) {
        if (mail.getId() == 0) {
            int playerId = mail.getPlayerId();
            if (playerId == -1) {
                mail.setPlayerName("全服玩家");
            } else if (playerId == -2) {
                mail.setPlayerName("全体模特");
            } else if (playerId == -3) {
                mail.setPlayerName("全服玩家和全体模特");
            } else if (playerId > 0 && ("".equals(mail.getPlayerName()) || mail.getPlayerName() == null)) {
                String player = playerService.searchOne(mail.getPlayerId());
                if (player != null) {
                    JSONObject object = JSON.parseObject(player);
                    if (object.containsKey("name")) {
                        String name = object.getString("name");
                        mail.setPlayerName(name);
                    }
                }else{
                    return null;
                }
            }
            
            List<EmailAttach> attachList_Num = new ArrayList<EmailAttach>();
            // 保存mail
            List<EmailAttach> attachList = mail.getAttach();
            mail.setAttach(null);
            mail = mailRepository.save(mail);
            
            if(null != attachList){
            	for(EmailAttach attach : attachList){
            		attach.setEmailId(mail.getId());
            		if(null != attach.getItemNum() && 0 != attach.getItemNum()){
            			attachList_Num.add(attach);
            		}
            	}
            }
            // 保存EmailAttach
            mail.setAttach(attachList_Num);
            mail = mailRepository.save(mail);


            if (isSendNow) {
                if (!sendEmail(mail)) {
                    throw new RuntimeException("邮件发送失败");
                } else {
                    updateStatus(mail.getId());
                }
            } else {
                /**
                 * 将定时发送邮件的时间等信息保存到bus_schedule表中
                 */
                Busschedule busschedule = new Busschedule();
                busschedule.setTable_name("Email");
                busschedule.setTable_id((long) mail.getId());
                busschedule.setColume_name("status");
                busschedule.setColume_value("1");
                Date date = mail.getPostTime();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String scheduleTime = dateFormat.format(date);
                DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
                DateTime dt = DateTime.parse(scheduleTime,formatter);
                String year = Integer.toString(dt.getYear());
                busschedule.setYear(year);
                String month = Integer.toString(dt.getMonthOfYear());
                busschedule.setMonth(month);
                String day = Integer.toString(dt.getDayOfMonth());
                busschedule.setDay(day);
                String hour = Integer.toString(dt.getHourOfDay());
                busschedule.setHour(hour);
                String minutes = Integer.toString(dt.getMinuteOfHour());
                busschedule.setMinute(minutes);
                String deadline = mail.getExpirationTime().toString();
                busschedule.setDeadline(mail.getExpirationTime());
                busschedule.setFlag(1);
                busschedule.setFailed(1);
                bs.create(busschedule);
                logger.info("create result is: " + mail);
            }
            return mail;
        }
        return null;
    }

    /**
     * 通过Id向游戏服务器发送邮件
     * @param id
     * @return
     */
    public boolean send(int id) {
        Email email = getOne(id);
        if (email.getStatus() == 0)
            if (sendEmail(email)) {
                return updateStatus(id);
            }
        return false;
    }

    /**
     * 保存本地邮件
     * @param mail
     * @return
     */
    public Email update(Email mail) {
        if (mail.getId() != 0) {
            mail = mailRepository.save(mail);
            logger.info("update result is: " + mail);
            return mail;
        }
        return null;
    }

    public boolean updateStatus(int id) {
        return  mailRepository.updateStatus(id) == 1;
    }

    /**
     * 删除本地邮件
     * @param id
     * @return
     */
    //@Transactional(noRollbackFor = EmptyResultDataAccessException.class)
    public boolean delete(int id) {
        try {
            mailRepository.delete(id);
            bs.deleteByTableId(id);
            return true;
        } catch (Exception e) {
            logger.error(e);
        }
        return false;
    }

    /**
     * 获取一个邮件
     * @param id
     * @return
     */
    @Transactional(readOnly = true)
    public Email getOne(int id) {
        return mailRepository.findOne(id);
    }

    @Transactional(readOnly = true)
    public Page<Email> getPaged(int current, int size) {
        Sort sort = new Sort(Sort.Direction.DESC, "postTime");
        PageRequest page = new PageRequest(current, size, sort);
        return mailRepository.findAll(page);
    }

    /**
     * 向远程服务器发送邮件
     * @param mail
     * @return
     */
    private boolean sendEmail(Email mail) {
        StringBuilder url = new StringBuilder(Constants.remoteUrl);
        url.append("api/mail/sendMail");
        JSONObject params = new JSONObject();
        params.put("targetPlayerId", mail.getPlayerId());
        params.put("title", mail.getTitle());
        params.put("content", mail.getMailContent());

        if (mail.getAttachGold() != 0 || mail.getAttach() != null || mail.getAttachMoney() != 0) {
            List<Map<String, Object>> mark = new ArrayList<>();
            if (mail.getAttachMoney() > 0) {
                Map<String, Object> items = new HashMap<>();
                items.put("type", "money");
                items.put("itemId", 101);
                items.put("count", mail.getAttachMoney());
                mark.add(items);
            }
            if (mail.getAttachGold() > 0) {
                Map<String, Object> items = new HashMap<>();
                items.put("type", "gold");
                items.put("itemId", 102);
                items.put("count", mail.getAttachGold());
                mark.add(items);
            }
            if (mail.getAttach() != null) {
                for (EmailAttach ea : mail.getAttach()) {
                    Map<String, Object> items = new HashMap<>();
                    items.put("type", "item");
                    items.put("itemId", ea.getItemId());
                    items.put("count", ea.getItemNum());
                    if(null != ea.getItemCategory() && !"".equals(ea.getItemCategory())){
                    	items.put("category", ea.getItemCategory());
                    } else {
                    	Item item = itemRepository.getItemByItemId(ea.getItemId());
                    	items.put("category", item.getCategory()+"");
                    }
                    mark.add(items);
                }
            }
            params.put("mark", mark);
        }

        JSONObject result = NetWorkUtils.netPost(url.toString(), params.toJSONString());

        return result != null;
    }

}
