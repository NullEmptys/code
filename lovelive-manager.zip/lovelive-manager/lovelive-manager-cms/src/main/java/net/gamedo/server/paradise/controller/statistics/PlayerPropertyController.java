package net.gamedo.server.paradise.controller.statistics;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.thirdary.player.Item;
import net.gamedo.server.paradise.service.statistics.PlayerPropertyService;

@Controller
@RequestMapping("/statistics/playerproperty")
public class PlayerPropertyController extends BaseController {
    @Autowired
    private PlayerPropertyService playerPropertyService;

    @RequestMapping
    public String list(HttpServletRequest request, Model model) {
        initModel(request, model);
        return "statistics/playerproperty/playerproperty_index";
    }
    
    @SuppressWarnings("rawtypes")
    @RequestMapping(value = "/listForPage", method = RequestMethod.POST)
    public
    @ResponseBody
    List<Map<String, Object>> listForPage(String id, int category) {
        List<Map<String, Object>> list = playerPropertyService.getPage(id, category);
        return list;
    }
    
    // 获取全部道具数据
    @RequestMapping(value = "/getAllItem", method = RequestMethod.POST)
    @ResponseBody
    public List<Item> getAllItem() {
        return playerPropertyService.getAllItem();
    }
    
    // 根据道具类型获取道具数据
    @RequestMapping(value = "/getItems", method = RequestMethod.POST)
    @ResponseBody
    public List<Item> getItems(int category) {
        if (category == 102) {
            List<Item> list = new ArrayList<>();
            Item item = new Item();
            item.setName("金币");
            item.setId(102);
            list.add(item);
            return list;
        } else if (category == 101) {
            List<Item> list = new ArrayList<>();
            Item item = new Item();
            item.setName("钻石");
            item.setId(101);
            list.add(item);
            return list;
        } else {
            return playerPropertyService.getItemByCategoryType(category);
        }
    }
    
    // 删除
    @RequestMapping(value = "/del", method = RequestMethod.POST)
    public
    @ResponseBody
    boolean get(int playerId, int bagId, int gridId, int itemId, int count, int category) {
        return playerPropertyService.del(playerId, bagId, gridId, itemId, count, category);
    }
    
    // 保存新增或修改
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    @ResponseBody
    public int save(HttpServletRequest request, String operType, int userId, String data) {
        int code = -1;
        if (operType.endsWith("edit")) {
            code = playerPropertyService.update(userId, data);
        } else {
            code = playerPropertyService.create(userId, data);
        }
        return code;
    }
    
    // 由类型获取道具列表
    @RequestMapping(value = "/getItemByCategoryType", method = RequestMethod.POST)
    @ResponseBody
    public List<Item> getItemByCategoryType(int categoryType) {
        List<Item> list = playerPropertyService.getItemByCategoryType(categoryType);
        return list;
    }

}
