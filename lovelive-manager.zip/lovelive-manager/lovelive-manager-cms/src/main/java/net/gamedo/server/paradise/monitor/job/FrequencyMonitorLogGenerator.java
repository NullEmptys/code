package net.gamedo.server.paradise.monitor.job;

import net.gamedo.server.paradise.model.primary.monitor.ApplicationInstance;
import net.gamedo.server.paradise.model.primary.monitor.FrequencyMonitorLog;
import net.gamedo.server.paradise.monitor.utils.HttpClientHandler;
import net.gamedo.server.paradise.monitor.utils.HttpClientPostHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by liuxing on 2016/4/9 0009.
 */
public class FrequencyMonitorLogGenerator {
    private static final Logger LOGGER = LoggerFactory.getLogger(FrequencyMonitorLogGenerator.class);
    private ApplicationInstance instance;

    public FrequencyMonitorLogGenerator(ApplicationInstance instance) {
        this.instance = instance;
    }

    public FrequencyMonitorLog generate() {
        HttpClientHandler httpClientHandler = createHttpClientHandler();
        LOGGER.debug("Send Request to URL: {} use HttpClientHandler: {}", monitorUrl(), httpClientHandler);

        final FrequencyMonitorLog monitorLog = httpClientHandler.handleAndGenerateFrequencyMonitorLog();
        monitorLog.setInstanceId(instance.getId());
//        monitorLog.setInstance(instance);
        return monitorLog;
    }

    private HttpClientHandler createHttpClientHandler() {
        HttpClientHandler clientHandler = instance.getRequestMethod().equals("POST") ?
                new HttpClientPostHandler(monitorUrl())
                : new HttpClientHandler(monitorUrl());

        return clientHandler.maxConnectionSeconds(maxConnectionSeconds())
                .contentType(instance.getContentType());
    }

    private int maxConnectionSeconds() {
        return instance.getMaxConnectionSeconds();
    }

    private String monitorUrl() {
        return "http://" + instance.getIpAddress() + ":" + instance.getPort() + "/gameServer/app/api/monitor/ping";
    }
}
