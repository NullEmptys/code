package net.gamedo.server.paradise.service.statistics;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;

import net.gamedo.server.paradise.cms.Constants;
import net.gamedo.server.paradise.model.provilage.Account;
import net.gamedo.server.paradise.repository.primary.provilage.AccountRepository;
import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.primary.player.Activity;
import net.gamedo.server.paradise.model.primary.player.Announcement;
import net.gamedo.server.paradise.repository.primary.AnnouncementRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;
import net.gamedo.server.paradise.utils.NetWorkUtils;

/**
 * 公告 Created by liuxing on 2016/4/22 0022.
 */
@Service
public class AnnouncementService extends BaseService {
	@Autowired
	private AnnouncementRepository announcementRepository;
	@Autowired
	private AccountRepository accountRepository;

	// 线下——获取全部公告列表
	@Transactional(readOnly = true)
	public List<Announcement> getAll() {
		return announcementRepository.findAll();
	}

	// 线下——根据Id获取公告
	@Transactional(readOnly = true)
	public Announcement getById(Long id) {
		if (logger.isDebugEnabled()) {
			logger.debug("Returning announcement with id: " + id);
		}
		Announcement announcement = announcementRepository.findOneById(id);
		return announcement;
	}

	// 线下——新建公告
	public void create(String data, Long userid) throws java.text.ParseException {
		announcementRepository.saveAndFlush(getAnnouncement("create", data, userid));

	}

	// 线下——修改公告
	public void update(String data, Long userid) throws java.text.ParseException {
		announcementRepository.save(getAnnouncement("update", data, userid));
	}

	// 线下——线下分页查询
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional(readOnly = true)
	public CurrentPage getPage(int currPage, int pageSize) {
		int total = (int) announcementRepository.count();
		CurrentPage page = getCurrentPage(total, currPage, pageSize, new CurrentPage<Activity>());
		List<Account> list = accountRepository.findAll();
		List<Announcement> pageItems = announcementRepository.getPage(currPage * pageSize, pageSize);
		if (null != list) {
			for (Announcement announcement : pageItems) {
				for (Account account : list) {
					if (account.getId() == announcement.getPublisher()) {
						announcement.setAccountName(null == account.getEmail() ? "" : account.getEmail());
					}
					if (account.getId() == announcement.getLastEditor()) {
						announcement.setLastAccountName(null == account.getEmail() ? "" : account.getEmail());
					}
				}

			}
		}
		page.setPageItems(pageItems);
		return page;
	}

	// 线下——根据Id删除公告
	public int delete(String id) {
		int code = 0;
		try {
			announcementRepository.delete(Long.valueOf(id));
		} catch (Exception e) {
			code = 1;
			e.printStackTrace();
		}
		return code;
	}

	// 线下——发送公告
	public int send(String data) {
		String postUrl = Constants.remoteUrl + "/api/announcement/announcementPublish";
		Map<String, Object> mapObj = NetWorkUtils.doPost(postUrl, getMap(data));
		reloadData();
		return null == mapObj?1 : Integer.parseInt(mapObj.get("code") + "");
	}

	// 线上——分页查询
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional(readOnly = true)
	public CurrentPage getPage_server(int currPage, int pageSize) {
		String postUrl = Constants.remoteUrl + "/api/announcement/announcementList";
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> mapObj = NetWorkUtils.doGet(postUrl);
		CurrentPage page = new CurrentPage();
		if (mapObj != null) {
			if ("0".equals(mapObj.get("code") + "")) {
				List<Announcement> list = (List<Announcement>) mapObj.get("list");
				int total = list.size();
				page = getCurrentPage(total, currPage, pageSize, new CurrentPage<Account>());
				page.setPageItems(list);
			}
		}
		return page;
	}

	// 线上——根据Id删除线上公告
	public int del_server(int id) {
		String postUrl = Constants.remoteUrl + "/api/announcement/" + id + "/announcementDelete";
		Map<String, Object> mapObj = NetWorkUtils.doGet(postUrl);
		reloadData();
		return null == mapObj ? 1 : Integer.parseInt(mapObj.get("code") + "");
	}

	// 线上——根据Id获取线上公告
	public Announcement getById_server(Long id) throws ParseException {
		String postUrl = Constants.remoteUrl + "/api/announcement/" + id;
		Map<String, Object> mapObj = NetWorkUtils.doGet(postUrl);
		Announcement announcement = new Announcement();
		if (null != mapObj) {
			if ("0".equals(mapObj.get("code") + "")) {
				Map<String, Object> map = (Map<String, Object>) mapObj.get("announcement");
				if (null != map) {
					announcement.setId(new Long(map.get("id") + ""));
					announcement.setType(Integer.parseInt(map.get("type") + ""));
					announcement.setCategory(map.get("category") + "");
					announcement.setSequence(Integer.parseInt(map.get("sequence") + ""));
					announcement.setBroadcastStartTime(getDate(map.get("broadcastStartTime") + ""));
					announcement.setBroadcastEndTime(getDate(map.get("broadcastEndTime") + ""));
					announcement.setStartTime(getDate(map.get("startTime") + ""));
					announcement.setEndTime(getDate(map.get("endTime") + ""));
					announcement.setTitle(null == map.get("title") ? "" : map.get("title") + "");
					announcement.setContent(null == map.get("content") ? "" : map.get("content") + "");
					announcement.setBackGroundId(null == map.get("backGroundId") ? "" : map.get("backGroundId") + "");
				}
			}
		}
		return announcement;
	}

	// 线上——修改线上公告
	public int save_server(String data) {
		JSONObject o = JSONObject.parseObject(data);
		String postUrl = Constants.remoteUrl + "/api/announcement/" + o.get("id") + "/announcementUpdate";
		Map<String, Object> mapObj = NetWorkUtils.doPost(postUrl, getMap(data));
		reloadData();
		return null == mapObj ? 1 : Integer.parseInt(mapObj.get("code") + "");
	}

	// 线上——导出历史公告
	public Workbook down() {
		// 第一步，创建一个webbook，对应一个Excel文件
		HSSFWorkbook wb = new HSSFWorkbook();
		// 第二步，在webbook中添加一个sheet,对应Excel文件中的sheet
		HSSFSheet sheet = wb.createSheet("公告表一");
		// 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制short
		HSSFRow row = sheet.createRow((int) 0);
		// 第四步，创建单元格，并设置值表头 设置表头居中
		HSSFCellStyle style = wb.createCellStyle();
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 创建一个居中格式
		HSSFCell cell = row.createCell(0);
		String[] cellArray = new String[]{"ID", "创建时间", "标题", "公告类型", "优先级", "图片ID", "弹板类型", "广播开始时间", "广播结束时间",
				"内容", "公告开始时间", "公告结束时间", "发送状态", "最后修改人", "发布人"};
		for(int i=0; i<cellArray.length; i++){
			cell = row.createCell(i);
			cell.setCellValue(cellArray[i]);
			cell.setCellStyle(style);
		}

		long count = announcementRepository.count();
		System.out.println(count);
		for (int i = 0, begin = 0; i < count; i += 20, begin++) {
			Sort sort = new Sort(Sort.Direction.ASC, "id");
			PageRequest page = new PageRequest(begin, 20, sort);
			Page<Announcement> list = announcementRepository.findAll(page);
			for (int j = 0; j < list.getNumberOfElements(); j++) {
				row = sheet.createRow(i + j + 1);
				Announcement an = list.getContent().get(j);
				// 第四步，创建单元格，并设置值
				row.createCell(0).setCellValue((double) an.getId());
				row.createCell(1).setCellValue(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(an.getCreateTime()));
				row.createCell(2).setCellValue(null == an.getTitle() ? "" : an.getTitle());
				row.createCell(3).setCellValue(1 == an.getType() ? "文字" : "图片");
				row.createCell(4).setCellValue(an.getSequence());
				row.createCell(5).setCellValue(null == an.getBackGroundId() ? "" : an.getBackGroundId());
				row.createCell(6)
						.setCellValue("1".equals(null == an.getCategory() ? "" : an.getCategory()) ? "外部弹板" : "内部弹板");
				row.createCell(7)
						.setCellValue(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(an.getBroadcastStartTime()));
				row.createCell(8)
						.setCellValue(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(an.getBroadcastEndTime()));
				row.createCell(9).setCellValue(null == an.getContent() ? "" : an.getContent());
				row.createCell(10).setCellValue(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(an.getStartTime()));
				row.createCell(11).setCellValue(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(an.getEndTime()));
				row.createCell(12).setCellValue(1 == an.getIsSend() ? "未发送" : "已发送");
				row.createCell(13).setCellValue(
						null == an.getLastEditor() ? "" : accountRepository.findOneById(an.getLastEditor()).getEmail());
				row.createCell(14).setCellValue(
						null == an.getPublisher() ? "" : accountRepository.findOne(an.getPublisher()).getEmail());
			}
		}
		return wb;
	}

	// 时间格式的转换
	private Date getDate(String time) throws java.text.ParseException {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date data = null;
		data = format.parse(time);
		return data;
	}

	// 将data数据转为对象
	private Announcement getAnnouncement(String type, String data, Long userid) throws java.text.ParseException {
		Announcement announcement = new Announcement();
		JSONObject o = JSONObject.parseObject(data);
		announcement.setType(Integer.parseInt(o.getString("type")));
		announcement.setTitle(o.getString("title"));
		announcement.setBroadcastStartTime(getDate(o.getString("broadcastStartTime")));
		announcement.setBroadcastEndTime(getDate(o.getString("broadcastEndTime")));
		announcement.setStartTime(getDate(o.getString("startTime")));
		announcement.setEndTime(getDate(o.getString("endTime")));
		announcement.setContent(o.getString("content"));
		announcement.setBackGroundId(o.getString("backGroundId"));
		announcement.setCategory(o.getString("category"));
		if (!"".equals(o.getString("sequence"))) {
			announcement.setSequence(Integer.parseInt(o.getString("sequence")));
		} else {
			announcement.setSequence(0);
		}
		if (type.equals("create")) {
			Date createTime = new Date();
			announcement.setCreateTime(createTime);
			announcement.setIsSend(1);
			announcement.setPublisher(userid);
		} else if (type.equals("update")) {
			announcement.setId(new Long(o.getString("id")));
			announcement.setCreateTime(getDate(o.getString("createTime")));
			announcement.setIsSend(Integer.parseInt(o.getString("isSend")));
			announcement.setPublisher(new Long(o.getString("publisher")));
			announcement.setLastEditor(userid);
		}
		return announcement;
	}

	// 将data数据转为Map
	private Map<String, Object> getMap(String data) {
		JSONObject o = JSONObject.parseObject(data);
		Map<String, Object> map = new HashMap<>();
		map.put("id", new Long(o.getString("id")));
		map.put("backGroundId", o.getString("backGroundId"));
		map.put("broadcastEndTime", o.get("broadcastEndTime"));
		map.put("broadcastStartTime", o.get("broadcastStartTime"));
		map.put("category", Integer.parseInt(o.getString("category")));
		map.put("content", o.getString("content"));
		map.put("createTime", o.get("createTime"));
		map.put("endTime", o.get("endTime"));
		map.put("sequence", Integer.parseInt("" == o.getString("sequence") ? "0" : o.getString("sequence")));
		map.put("startTime", o.get("startTime"));
		map.put("title", o.getString("title"));
		map.put("type", Integer.parseInt(o.getString("type")));
		map.put("isSend", Integer.parseInt(
				null == o.getString("isSend") || "".equals(o.getString("isSend")) ? "1" : o.getString("isSend")));
		map.put("lastEditor", new Long(null == o.getString("lastEditor") || "".equals(o.getString("lastEditor")) ? "1"
				: o.getString("lastEditor")));
		map.put("publisher", new Long(null == o.getString("publisher") || "".equals(o.getString("publisher")) ? "1"
				: o.getString("publisher")));
		return map;
	}

	/**
	 * 通知所有游戏服务器重新加载活动配置
	 */
	private void reloadData() {
		String getUrl = Constants.remoteUrl + "/api/serverinfo/serverInfoList";
		Map<String, Object> mapObj = NetWorkUtils.doGet(getUrl);
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		if (null != mapObj) {
			if ("0".equals(mapObj.get("code") + "")) {
				if (null != mapObj.get("serverInfoList")) {
					list = (List<Map<String, Object>>) mapObj.get("serverInfoList");
					for (Map<String, Object> map : list) {
						StringBuilder sb = new StringBuilder();
						sb.append("http://").append(map.get("ip")).append(":").append(map.get("port"))
								.append("/gameServer/app/api/announcement/reloadData");
						NetWorkUtils.doGet(sb.toString());
					}
				}
			}
		}
	}
}
