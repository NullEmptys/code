/* Copyright 2004, 2005, 2006 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.gamedo.server.paradise.acl;

import org.springframework.security.acls.domain.BasePermission;

import net.gamedo.server.paradise.model.provilage.Sysmenu;
import net.gamedo.server.paradise.model.provilage.Syspage;

/**
 * Model object for add permission use case.
 *
 * @author Ben Alex
 */
public class AddPermission {
	// ~ Instance fields
	// ================================================================================================
	public Sysmenu sysmenu;
	public Syspage syspage;
	public Integer permission = BasePermission.READ.getMask();
	public String recipient;

	// ~ Methods
	// ========================================================================================================

	public Integer getPermission() {
		return permission;
	}

	public String getRecipient() {
		return recipient;
	}

	public Sysmenu getSysmenu() {
		return sysmenu;
	}

	public void setSysmenu(Sysmenu sysmenu) {
		this.sysmenu = sysmenu;
	}

	public Syspage getSyspage() {
		return syspage;
	}

	public void setSyspage(Syspage syspage) {
		this.syspage = syspage;
	}

	public void setPermission(Integer permission) {
		this.permission = permission;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}
}
