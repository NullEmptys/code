package net.gamedo.server.paradise.monitor.job;

import net.gamedo.server.paradise.service.statistics.ApplicationInstanceService;
import net.gamedo.server.paradise.utils.BeanProvider;
import org.quartz.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by liuxing on 2016/4/12 0012.
 */
@DisallowConcurrentExecution
public class MonitoringInstanceJob implements Job {
    private static final Logger LOGGER = LoggerFactory.getLogger(MonitoringInstanceJob.class);
    public static final String APPLICATION_INSTANCE_GUID = "instanceGuid";

    private transient ApplicationInstanceService instanceService = BeanProvider.getBean(ApplicationInstanceService.class);

    public MonitoringInstanceJob() {
    }

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        final JobKey key = context.getJobDetail().getKey();
        LOGGER.debug("*****  Start execute Job [{}]", key);

        final String guid = context.getMergedJobDataMap().getString(APPLICATION_INSTANCE_GUID);
        if (instanceService != null){
            instanceService.executePerHeartBeatByInstance(guid);
        }
        LOGGER.debug("&&&&&  End execute Job [{}]", key);
    }
}
