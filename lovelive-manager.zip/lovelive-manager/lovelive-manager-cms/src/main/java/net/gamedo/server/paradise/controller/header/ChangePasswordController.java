package net.gamedo.server.paradise.controller.header;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import net.gamedo.server.paradise.cms.model.ChangePasswordForm;
import net.gamedo.server.paradise.cms.service.SecurityUser;
import net.gamedo.server.paradise.cms.service.UserService;
import net.gamedo.server.paradise.cms.support.AjaxUtils;
import net.gamedo.server.paradise.cms.support.MessageHelper;

@Controller
public class ChangePasswordController {

	private static final String CHANGEPASSWORD_VIEW_NAME = "systems/changePassword";

	@Autowired
	private UserService userService;

	@RequestMapping(value = "changePassword")
	public String changePassword(Model model,
			@RequestHeader(value = "X-Requested-With", required = false) String requestedWith) {
		model.addAttribute(new ChangePasswordForm());
		if (AjaxUtils.isAjaxRequest(requestedWith)) {
			return CHANGEPASSWORD_VIEW_NAME.concat(" :: changePasswordForm");
		}
		return CHANGEPASSWORD_VIEW_NAME;
	}

	@RequestMapping(value = "changePassword", method = RequestMethod.POST)
	// SpringSecurity 将会使用运行时来对方法执行before advice， 并在安全要求未满足的情况下抛出AccessDeniedException异常。
	// @PreAuthorize("hasRole('ROLE_USER')||hasRole('ROLE_ADMIN')")
	public String changePassword(@Valid @ModelAttribute ChangePasswordForm changePasswordForm, Errors errors,
			RedirectAttributes ra) {
		if (errors.hasErrors()) {
			return CHANGEPASSWORD_VIEW_NAME;
		}
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = principal.toString();
		if (principal instanceof SecurityUser) {
			username = ((SecurityUser) principal).getUsername();
		}
		if (userService.changePassword(username, changePasswordForm.getPassword(),
				changePasswordForm.getOldpassword())) {
			MessageHelper.addSuccessAttribute(ra, "修改成功！");
			// TODO:后期改为跳转到之前页面
			return "redirect:/";
		} else {
			errors.rejectValue("oldpassword", "oldpassword.error", "原密码不正确");
			return CHANGEPASSWORD_VIEW_NAME;
		}

	}
}
