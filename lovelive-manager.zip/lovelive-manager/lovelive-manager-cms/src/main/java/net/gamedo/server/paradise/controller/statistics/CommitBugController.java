package net.gamedo.server.paradise.controller.statistics;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.secondary.CommitBug;
import net.gamedo.server.paradise.service.statistics.CommitBugService;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

/**
 * Created by TruthBean on 2016-05-12 14:57.
 */
@Controller
@RequestMapping("/statistics/commitbug")
public class CommitBugController extends BaseController {
    private Logger logger = Logger.getLogger(getClass().getName());

    @Autowired
    private CommitBugService commitBugService;

    @RequestMapping
    public String list(HttpServletRequest request, Model model) {
        initModel(request, model);
        return "statistics/commitbug/commitbug_index";
    }

    @RequestMapping(value = "/listForPage", method = RequestMethod.POST)
    public @ResponseBody
    Page<CommitBug> listForPage(@RequestParam(value = "playerId", defaultValue = "0") long playerId,
                                String name, String context, String beginTime, String endTime,
                                int begin, int size) {
        return commitBugService.search(playerId, name, context, beginTime, endTime, begin, size);
    }

    @RequestMapping(value = "/download", method = RequestMethod.GET)
    public void download(HttpServletResponse response, String name, String context, String beginTime, String endTime,
                         @RequestParam(value = "playerId", defaultValue = "0")long playerId){
        Workbook workbook = commitBugService.download(playerId, name, context, beginTime, endTime);
        response.setContentType("application/x-msdownload");
        response.setHeader("Content-Disposition", "attachment;filename=commitbug.xls");
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        ServletOutputStream out = null;
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            workbook.write(os);
            byte[] content = os.toByteArray();
            InputStream is = new ByteArrayInputStream(content);
            out = response.getOutputStream();
            bis = new BufferedInputStream(is);
            bos = new BufferedOutputStream(out);
            byte[] buff = new byte[2048];
            int bytesRead;
            // Simple read/write loop.
            while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                bos.write(buff, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (bis != null)
                try {
                    bis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            if (bos != null)
                try {
                    bos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
    }


}
