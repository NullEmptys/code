package net.gamedo.server.paradise.service.provilage;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.gamedo.server.paradise.model.provilage.Sysmenu;
import net.gamedo.server.paradise.repository.primary.provilage.SysmenuRepository;
import net.gamedo.server.paradise.model.provilage.Sysmodel;
import net.gamedo.server.paradise.repository.primary.provilage.SysmodelRepository;
import net.gamedo.server.paradise.model.provilage.Syspage;
import net.gamedo.server.paradise.repository.primary.provilage.SyspageRepository;

@Service
public class JurisdictionService {

	private static Log log = LogFactory.getLog(JurisdictionService.class);

	@Autowired
	private SysmenuRepository sysmenuRepository;

	@Autowired
	private SyspageRepository syspageRepository;

	@Autowired
	private SysmodelRepository sysmodelRepository;

	private Map<Long, String> sysmenuNameMap = new ConcurrentHashMap<Long, String>();

	private Map<Long, String> syspageNameMap = new ConcurrentHashMap<Long, String>();

	public Sysmenu saveSysmenu(Sysmenu sysmenu) throws Exception {
		if (null == sysmenu) {
			log.error("Sysmenu is null");
			return null;
		}
		if (null != sysmenu.getId())
			sysmenuNameMap.put(sysmenu.getId(), sysmenu.getName());
		return sysmenuRepository.save(sysmenu);
	}

	public void removeSysmenu(Long id) throws Exception {
		if (null == id) {
			log.error("id is null");
		}
		sysmenuRepository.delete(id);
	}

	public Sysmenu getSysmenu(Long id) throws Exception {
		if (null == id) {
			log.error("id is null");
			return null;
		}
		return sysmenuRepository.findOne(id);
	}

	public List<Sysmenu> getAllSysmenu() throws Exception {
		return sysmenuRepository.findAll();
	}

	// public Page<Sysmenu> getAllSysmenuByPage(Integer pagenum, Integer rows,
	// String name, String orderby)
	// throws Exception {
	// return jurisdictionRepository.getAllSysmenuByPage(pagenum, rows, name,
	// orderby);
	// }

	public Syspage saveSyspage(Syspage syspage) throws Exception {
		if (null == syspage) {
			log.error("syspage is null");
			return null;
		}
		if (null != syspage.getId())
			syspageNameMap.put(syspage.getId(), syspage.getName());
		return syspageRepository.save(syspage);
	}

	public void removeSyspage(Long id) throws Exception {
		if (null == id) {
			log.error("id is null");
		}
		syspageRepository.delete(id);
	}

	public Syspage getSyspage(Long id) throws Exception {
		if (null == id) {
			log.error("id is null");
			return null;
		}
		return syspageRepository.findOne(id);
	}

	public List<Syspage> getAllSyspage() throws Exception {
		return syspageRepository.findAll();
	}

	// public Page<Syspage> getAllSyspageByPage(Integer pagenum, Integer rows,
	// String name, Long sysmenu_id,
	// Long parent_id, Integer ifshow, Integer ifleaf, String orderby) throws
	// Exception {
	// Page<Syspage> page = jurisdictionRepository.getAllSyspageByPage(pagenum,
	// rows, name, sysmenu_id, parent_id,
	// ifshow, ifleaf, orderby);
	// if (null != page) {
	// List<Syspage> objlist = page.getList();
	// if (null != objlist) {
	// for (Syspage obj : objlist) {
	// obj.setSysmenu_name(getSysmenuName(obj.getSysmenu_id()));
	// obj.setParent_name(getSyspageName(obj.getParent_id()));
	// }
	// }
	// }
	// return page;
	// }

	public Sysmodel saveSysmodel(Sysmodel sysmodel) throws Exception {
		if (null == sysmodel) {
			log.error("Sysmodel is null");
			return null;
		}
		return sysmodelRepository.save(sysmodel);
	}

	public void removeSysmodel(Long id) throws Exception {
		if (null == id) {
			log.error("id is null");
		}
		sysmodelRepository.delete(id);
	}

	public Sysmodel getSysmodel(Long id) throws Exception {
		if (null == id) {
			log.error("id is null");
			return null;
		}
		return sysmodelRepository.findOne(id);
	}

	public List<Sysmodel> getAllSysmodel() throws Exception {
		return sysmodelRepository.findAll();
	}

	// public Page<Sysmodel> getAllSysmodelByPage(Integer pagenum, Integer rows,
	// String name, Long syspage_id,
	// Integer ifshow, String orderby) throws Exception {
	// Page<Sysmodel> page =
	// jurisdictionRepository.getAllSysmodelByPage(pagenum, rows, name,
	// syspage_id, ifshow,
	// orderby);
	// if (null != page) {
	// List<Sysmodel> objlist = page.getList();
	// if (null != objlist) {
	// for (Sysmodel obj : objlist) {
	// obj.setSyspage_name(getSyspageName(obj.getSyspage_id()));
	// }
	// }
	// }
	// return page;
	// }

	// private String getSysmenuName(Long id) throws Exception {
	// if (null == id)
	// return null;
	// String name = sysmenuNameMap.get(id);
	// if (null == name) {
	// Sysmenu obj = jurisdictionRepository.getSysmenu(id);
	// name = obj.getName();
	// sysmenuNameMap.put(id, name);
	// }
	// return name;
	// }
	//
	// private String getSyspageName(Long id) throws Exception {
	// if (null == id)
	// return null;
	// String name = syspageNameMap.get(id);
	// if (null == name) {
	// Syspage obj = jurisdictionRepository.getSyspage(id);
	// name = obj.getName();
	// syspageNameMap.put(id, name);
	// }
	// return name;
	// }
	//
	// public List<Sysmenu> getAllSysmenuWithSubByMaster(Integer master, Long
	// master_id) throws Exception {
	// return jurisdictionRepository.getAllSysmenuWithSubByMaster(master,
	// master_id);
	// }
	//
	// public boolean saveJurisdictionByModel(Integer master, Long master_id,
	// JurisdictionModel jurisdictionModel)
	// throws Exception {
	// return jurisdictionRepository.saveJurisdictionByModel(master, master_id,
	// jurisdictionModel);
	// }
	//
	// public List<Sysmenu> getAllSysmenuWithSubByJustOneUser(Long user_id)
	// throws Exception {
	// return jurisdictionRepository.getAllSysmenuWithSubByJustOneUser(user_id);
	// }

}
