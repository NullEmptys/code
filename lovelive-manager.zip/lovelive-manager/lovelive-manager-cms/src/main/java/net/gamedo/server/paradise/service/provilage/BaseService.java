/* Copyright 2004, 2005, 2006 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.gamedo.server.paradise.service.provilage;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ApplicationObjectSupport;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.model.AccessControlEntry;
import org.springframework.security.acls.model.MutableAcl;
import org.springframework.security.acls.model.MutableAclService;
import org.springframework.security.acls.model.NotFoundException;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.security.acls.model.Permission;
import org.springframework.security.acls.model.Sid;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.transaction.annotation.Transactional;

import net.gamedo.server.paradise.model.primary.CurrentPage;

@Transactional
public class BaseService extends ApplicationObjectSupport {

	@Autowired
	MutableAclService mutableAclService;

	@SuppressWarnings("rawtypes")
	public CurrentPage getCurrentPage(int total, int currPage, int pageSize, CurrentPage page) {
		int pageCount = total / pageSize;
		if (total > pageSize * pageCount) {
			pageCount++;
		}

		page.setCurrPage(currPage);
		page.setPageCount(pageCount);
		page.setTotal(total);

		return page;
	}

	public void addPermission(Class<?> javaType, Long id, Sid recipient, Permission permission) {
		if (null == id || null == recipient || null == permission)
			return;
		MutableAcl acl;
		ObjectIdentity oid = new ObjectIdentityImpl(javaType, id);

		try {
			acl = (MutableAcl) mutableAclService.readAclById(oid);
		} catch (NotFoundException nfe) {
			acl = mutableAclService.createAcl(oid);
		}

		List<AccessControlEntry> entries = acl.getEntries();

		boolean alreadyHave = false;
		for (int i = 0; i < entries.size(); i++) {
			if (entries.get(i).getSid().equals(recipient)) {
				if (entries.get(i).getPermission().getMask() < permission.getMask())
					acl.deleteAce(i);
				else if (entries.get(i).getPermission().getMask() >= permission.getMask())
					alreadyHave = true;
			}
		}
		if (!alreadyHave) {
			acl.insertAce(acl.getEntries().size(), permission, recipient, true);
			mutableAclService.updateAcl(acl);
		}

		logger.debug("Added permission " + permission + " for Sid " + recipient + " class " + javaType + " id " + id);
	}

	public void deletePermission(Class<?> javaType, Long id, Sid recipient, Permission permission) {
		ObjectIdentity oid = new ObjectIdentityImpl(javaType, id);
		MutableAcl acl = (MutableAcl) mutableAclService.readAclById(oid);

		// Remove all permissions associated with this particular recipient
		// (string
		// equality to KISS)
		List<AccessControlEntry> entries = acl.getEntries();

		for (int i = 0; i < entries.size(); i++) {
			if (entries.get(i).getSid().equals(recipient) && entries.get(i).getPermission().equals(permission)) {
				acl.deleteAce(i);
			}
		}

		mutableAclService.updateAcl(acl);

		if (logger.isDebugEnabled()) {
			logger.debug("Deleted class " + javaType + " id " + id + " ACL permissions for recipient " + recipient);
		}
	}

	protected String getUsername() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		if (auth.getPrincipal() instanceof UserDetails) {
			return ((UserDetails) auth.getPrincipal()).getUsername();
		} else {
			return auth.getPrincipal().toString();
		}
	}
}
