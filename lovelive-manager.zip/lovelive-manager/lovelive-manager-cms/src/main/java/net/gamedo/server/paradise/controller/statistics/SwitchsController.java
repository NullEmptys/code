package net.gamedo.server.paradise.controller.statistics;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import net.gamedo.server.paradise.cms.service.statistics.SwitchsService;
import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.primary.Switchs;

@Controller
@RequestMapping("/statistics/switchs")
public final class SwitchsController extends BaseController {

	@Autowired
	private SwitchsService switchsService;

	@RequestMapping
	public String list(HttpServletRequest request, Model model) {
		initModel(request, model);

		return "statistics/switchs/switchs_index";
	}

	/**
	 * 分页查询
	 * 
	 * @param request
	 * @param currPage
	 *            当前页
	 * @param perPage
	 * @param search
	 *            查询参数
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody Page listForPage(int currPage, int pageSize, String search, Long channel_id) {
		return switchsService.getPage(currPage, pageSize, search, channel_id);
	}

	/**
	 * 保存 修改菜单
	 *
	 * @param request
	 * @param data
	 * @return @
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Switchs save(HttpServletRequest request, String data) {
		try {
			Switchs obj = mapper.readValue(data, Switchs.class);

			if (null == obj.getId()) { // 新增
				switchsService.create(obj);
			} else { // 修改更新
				switchsService.update(obj);
			}

			return obj;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据ids删除菜单
	 *
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/del", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> del(String ids) {
		return switchsService.delete(ids);
	}

	/**
	 * 根据id获取菜单
	 *
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/get", method = RequestMethod.POST)
	public @ResponseBody Switchs get(Long id) {
		return switchsService.getById(id);
	}

}
