package net.gamedo.server.paradise.controller.statistics;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import net.gamedo.server.paradise.dto.PlayerDTO;
import net.gamedo.server.paradise.service.statistics.PlayerService;
import net.gamedo.server.paradise.controller.BaseController;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Created by qushibin on 2016/03/30.
 */
@Controller
@RequestMapping("/statistics/player")
public final class PlayerController extends BaseController {

    private Logger logger = Logger.getLogger(getClass().getName());

    @Autowired
    private PlayerService playerService;

    @RequestMapping
    public String show(HttpServletRequest request, Model model) {
        initModel(request, model);
        return "statistics/player/player_index";
    }

    @RequestMapping(value = "/get", method = RequestMethod.POST)
    public
    @ResponseBody
    String get(@RequestParam(defaultValue = "0") int id) {
        return playerService.searchOne(id);
    }

    @RequestMapping(value = "/search", method = {RequestMethod.POST})
    public
    @ResponseBody
    String search(int searchType, String query) {
        String type = null;
        if (searchType == 1) {
            type = "id";
        } else if (searchType == 2) {
            type = "name";
        }
        return playerService.search(query, type);
    }

    @RequestMapping(value = "/update", method = {RequestMethod.POST})
    public
    @ResponseBody
    String update(String data) {
        try {
            PlayerDTO mode = mapper.readValue(data, PlayerDTO.class);
            return playerService.update(mode);
        } catch (IOException e) {
            logger.error(e);
        }
        return null;
    }

    @RequestMapping(value = "/offline", method = RequestMethod.POST)
    public
    @ResponseBody
    boolean offline(@RequestParam(defaultValue = "0") int id) {
        return playerService.offline(id);
    }

}
