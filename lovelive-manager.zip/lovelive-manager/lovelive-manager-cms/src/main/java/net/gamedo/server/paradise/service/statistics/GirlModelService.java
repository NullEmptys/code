package net.gamedo.server.paradise.service.statistics;

import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.thirdary.GirlModel;
import net.gamedo.server.paradise.repository.thirdary.GirlModelRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 16/7/1 0001.
 */
@Service
public class GirlModelService extends BaseService {
    @Autowired
    private GirlModelRepository girlModelRepository;

    // 模特全部列表
    @Transactional(readOnly = true)
    public List<GirlModel> getAll() {
        return girlModelRepository.findAll();
    }

    // 根据Id获取模特信息
    @Transactional(readOnly = true)
    public GirlModel getById(Long id) {
        if (logger.isDebugEnabled()) {
            logger.debug("Returning announcement with id: " + id);
        }
        GirlModel girlModel = girlModelRepository.findOne(id);
        return girlModel;
    }

    // 新建模特
    public void create(GirlModel girlModel) {
        girlModelRepository.save(girlModel);
    }

    // 修改模特信息
    public void update(GirlModel girlModel) throws java.text.ParseException {
        girlModelRepository.save(girlModel);
    }

    // 分页查询
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Transactional(readOnly = true)
    public CurrentPage getPage(int currPage, int pageSize) {
        int total = (int) girlModelRepository.count();
        CurrentPage page = getCurrentPage(total, currPage, pageSize, new CurrentPage<GirlModel>());
        List<GirlModel> girlModels = girlModelRepository.getPage(currPage * pageSize, pageSize);
        page.setPageItems(girlModels);
        return page;
    }

    // 删除模特
    public Map<String, Object> delete(String ids) {
        String[] tmp = ids.split("\\,");
        int i = 0;
        for (String id : tmp) {
            try {
                girlModelRepository.delete(Long.valueOf(id));
                i++;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("num", Integer.valueOf(i));
        return map;
    }
}