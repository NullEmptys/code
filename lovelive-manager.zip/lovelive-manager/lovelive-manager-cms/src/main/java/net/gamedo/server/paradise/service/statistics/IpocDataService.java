package net.gamedo.server.paradise.service.statistics;

import net.gamedo.server.paradise.model.thirdary.ClothCdTime;
import net.gamedo.server.paradise.repository.thirdary.ClothCdTimeRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Administrator on 2016/4/23 0023.
 */
@Service
public class IpocDataService extends BaseService {
    @Autowired
    private ClothCdTimeRepository clothCdTimeRepository;

    //@TargetDataSource(name = "ds2")
    public List<ClothCdTime> findAllColthCdTime() {
        return clothCdTimeRepository.findAll();
    }
}
