package net.gamedo.server.paradise;

import net.gamedo.server.paradise.utils.BeanProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

@EnableTransactionManagement
@SpringBootApplication
@EnableScheduling
//@Import({DynamicDataSourceRegister.class})
public class Application {

    public static void main(String[] args) {
        final ApplicationContext applicationContext = SpringApplication.run(Application.class, args);
        BeanProvider.initialize(applicationContext);
    }

}
