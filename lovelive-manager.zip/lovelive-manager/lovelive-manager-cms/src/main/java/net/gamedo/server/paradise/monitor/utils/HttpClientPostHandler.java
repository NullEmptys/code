package net.gamedo.server.paradise.monitor.utils;

import org.apache.http.client.methods.RequestBuilder;

/**
 * Created by liuxing on 2016/4/9 0009.
 */
public class HttpClientPostHandler extends HttpClientHandler {
    public HttpClientPostHandler(String url) {
        super(url);
    }

    protected RequestBuilder createRequestBuilder() {
        return RequestBuilder.post();
    }
}
