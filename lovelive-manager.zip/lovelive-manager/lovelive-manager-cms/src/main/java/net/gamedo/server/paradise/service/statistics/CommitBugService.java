package net.gamedo.server.paradise.service.statistics;

import net.gamedo.server.paradise.model.secondary.CommitBug;
import net.gamedo.server.paradise.repository.secondary.CommitBugRepository;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;

/**
 * Created by TruthBean on 2016-05-12 14:52.
 */
@Service
public class CommitBugService {

    @Autowired
    private CommitBugRepository commitBugRepository;

    /**
     * 搜索
     *
     * @param playerId
     * @param name
     * @param context
     * @param beginTime
     * @param endTime
     * @param begin
     * @param size
     * @return
     */
   //@TargetDataSource(name = "ds1")
    public Page<CommitBug> search(long playerId, String name, String context, String beginTime, String endTime,
                                  int begin, int size) {
        return commitBugRepository.findSomePaged(playerId, name, context, beginTime, endTime, begin, size);
    }

    /**
     * 下载
     *
     * @param playerId
     * @param name
     * @param context
     * @param beginTime
     * @param endTime
     * @return
     */
    //@TargetDataSource(name = "ds1")
    public Workbook download(long playerId, String name, String context, String beginTime, String endTime) {
        // 第一步，创建一个webbook，对应一个Excel文件
        HSSFWorkbook wb = new HSSFWorkbook();
        // 第二步，在webbook中添加一个sheet,对应Excel文件中的sheet
        HSSFSheet sheet = wb.createSheet("bug数据表一");
        // 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制short
        HSSFRow row = sheet.createRow(0);
        // 第四步，创建单元格，并设置值表头 设置表头居中
        CellRangeAddress cra = new CellRangeAddress(3, 3, 4, 7); //合并单元格
        sheet.addMergedRegion(cra);
        HSSFCellStyle style = wb.createCellStyle();
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 创建一个居中格式

//        String[] cellValues1 = new String[]{"玩家Id", "开始时间", "结束时间", "内容（关键字）"};
//        String[] cellValues2 = new String[]{playerId ==0 ? "" : String.valueOf(playerId), beginTime, endTime, context};
        HSSFCell cell = null;
//        for (int i = 0; i < cellValues1.length*2; i+=2) {
//            cell = row.createCell(i);
//            cell.setCellValue(cellValues1[i/2]);
//            cell.setCellStyle(style);
//            cell = row.createCell(i+1);
//            cell.setCellValue(cellValues2[i/2]);
//            cell.setCellStyle(style);
//        }
        //表头
//        row = sheet.createRow(2);

        String[] cellValues1 = new String[]{"id", "玩家Id", "昵称", "提交时间", "内容详情"};
        String[] cellValues2 = new String[]{String.valueOf(playerId), beginTime, endTime, context};
        for (int i = 0; i < cellValues1.length; i++) {
            cell = row.createCell(i);
            cell.setCellValue(cellValues1[i]);
            cell.setCellStyle(style);
        }

        Page<CommitBug> list = commitBugRepository.findSomePaged(playerId, name, context, beginTime, endTime, 0, 20);
        long count = list.getTotalElements();
        for (int i = 0, n = 0; i < count; i += 20) {
            list = commitBugRepository.findSomePaged(playerId, name, context, beginTime, endTime, n++, 20);
            for (int j = 0; j < list.getNumberOfElements(); j++) {
                cra = new CellRangeAddress(i + j + 4, i + j + 4, 4, 7);
                sheet.addMergedRegion(cra);
                row = sheet.createRow(i + j + 3);
                CommitBug an = list.getContent().get(j);
                // 第四步，创建单元格，并设置值
                row.createCell(0).setCellValue(an.getId());
                row.createCell(1).setCellValue(an.getPlayerId());
                row.createCell(2).setCellValue(an.getName());
                row.createCell(3).setCellValue(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(an.getCommitDate()));
                row.createCell(4).setCellValue(an.getContext());
            }
        }
        return wb;
    }
}
