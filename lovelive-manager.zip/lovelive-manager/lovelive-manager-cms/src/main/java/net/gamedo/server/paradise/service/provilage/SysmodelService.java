/* Copyright 2004, 2005, 2006 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.gamedo.server.paradise.service.provilage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.mysql.jdbc.StringUtils;

import net.gamedo.server.paradise.model.provilage.Sysmodel;
import net.gamedo.server.paradise.repository.primary.provilage.SysmodelRepository;

@Service
@Transactional
public class SysmodelService extends BaseService implements InitializingBean {

	@Autowired
	private SysmodelRepository sysmodelRepository;

	public void afterPropertiesSet() throws Exception {
		Assert.notNull(sysmodelRepository, "sysmodelRepository required");
		Assert.notNull(mutableAclService, "mutableAclService required");
	}

	public void create(Sysmodel sysmodel) {
		// Create the Sysmodel itself
		sysmodelRepository.saveAndFlush(sysmodel);

		// Grant the current principal administrative permission to the sysmodel
		// addPermission(sysmodel, new PrincipalSid(getUsername()),
		// BasePermission.ADMINISTRATION);

		if (logger.isDebugEnabled()) {
			// logger.debug("Created sysmodel " + sysmodel + " and granted admin
			// permission to recipient " + getUsername());
		}
	}

	// @PreAuthorize("hasRole('ROLE_USER')")
	// @PostFilter("hasPermission(filterObject, 'read') or
	// hasPermission(filterObject, admin)")
	@Transactional(readOnly = true)
	public List<Sysmodel> getAll() {
		logger.debug("Returning all Sysmodel");

		return sysmodelRepository.findAll();
	}

	@Transactional(readOnly = true)
	public Sysmodel getById(Long id) {
		if (logger.isDebugEnabled()) {
			logger.debug("Returning sysmodel with id: " + id);
		}

		return sysmodelRepository.findOne(id);
	}

	public void update(Sysmodel sysmodel) {
		sysmodelRepository.saveAndFlush(sysmodel);

		logger.debug("Updated sysmodel " + sysmodel);
	}

	@SuppressWarnings({ "rawtypes" })
	@Transactional(readOnly = true)
	public Page getPage(int currPage, int pageSize, String search) {
		PageRequest pageRequest = new PageRequest(currPage, pageSize);
		Page<Sysmodel> page = null;

		if (StringUtils.isNullOrEmpty(search))
			page = sysmodelRepository.getPage(pageRequest);
		else
			page = sysmodelRepository.getPage(search, pageRequest);
		return page;
	}

	public Map<String, Object> delete(String ids) {
		String[] tmp = ids.split("\\,");
		int i = 0;
		for (String id : tmp) {
			try {
				sysmodelRepository.delete(Long.valueOf(id));
				i++;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("num", Integer.valueOf(i));
		return map;
	}
}
