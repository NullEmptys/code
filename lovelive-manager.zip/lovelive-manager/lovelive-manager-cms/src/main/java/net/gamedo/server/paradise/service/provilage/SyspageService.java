/* Copyright 2004, 2005, 2006 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.gamedo.server.paradise.service.provilage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.mysql.jdbc.StringUtils;

import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.provilage.Syspage;
import net.gamedo.server.paradise.repository.primary.provilage.SyspageRepository;

@Service
@Transactional
public class SyspageService extends BaseService implements InitializingBean {

	@Autowired
	private SyspageRepository syspageRepository;

	public void afterPropertiesSet() throws Exception {
		Assert.notNull(syspageRepository, "syspageRepository required");
		Assert.notNull(mutableAclService, "mutableAclService required");
	}

	public void create(Syspage syspage) {
		// Create the Syspage itself
		syspageRepository.saveAndFlush(syspage);

		// Grant the current principal administrative permission to the syspage
		// addPermission(syspage, new PrincipalSid(getUsername()),
		// BasePermission.ADMINISTRATION);

		if (logger.isDebugEnabled()) {
			// logger.debug("Created syspage " + syspage + " and granted admin
			// permission to recipient " + getUsername());
		}
	}

	// @PreAuthorize("hasRole('ROLE_USER')")
	// @PostFilter("hasPermission(filterObject, 'read') or
	// hasPermission(filterObject, admin)")
	@Transactional(readOnly = true)
	public List<Syspage> getAll() {
		logger.debug("Returning all Syspage");

		return syspageRepository.findAll();
	}

	@Transactional(readOnly = true)
	public Syspage getById(Long id) {
		if (logger.isDebugEnabled()) {
			logger.debug("Returning syspage with id: " + id);
		}

		return syspageRepository.findOne(id);
	}

	public void update(Syspage syspage) {
		// Sysmenu sysmenu =
		// sysmenuRepository.getOne(syspage.getSysmenu().getId());
		// syspage.setSysmenu(sysmenu);
		syspageRepository.saveAndFlush(syspage);

		logger.debug("Updated syspage " + syspage);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public CurrentPage getPage(int currPage, int pageSize, String search) {

		int total = (int) syspageRepository.count();
		CurrentPage page = getCurrentPage(total, currPage, pageSize, new CurrentPage<Syspage>());

		if (StringUtils.isNullOrEmpty(search))
			page.setPageItems(syspageRepository.getPage((currPage - 1) * pageSize, pageSize));
		else
			page.setPageItems(syspageRepository.getPage((currPage - 1) * pageSize, pageSize, search));
		return page;
	}

	public Map<String, Object> delete(String ids) {
		String[] tmp = ids.split("\\,");
		int i = 0;
		for (String id : tmp) {
			try {
				syspageRepository.delete(Long.valueOf(id));
				i++;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("num", Integer.valueOf(i));
		return map;
	}
}
