package net.gamedo.server.paradise.service.statistics;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mysql.jdbc.StringUtils;
import net.gamedo.server.paradise.model.thirdary.ChannelInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.gamedo.server.paradise.repository.thirdary.ChannelInfoRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;

/**
 * Created by liuxing on 2016/04/11.
 */
@Service
public class ChannelInfoService extends BaseService {
    @Autowired
    private ChannelInfoRepository channelinfoRepository;

    public void create(ChannelInfo channelinfo) {
        channelinfoRepository.saveAndFlush(channelinfo);
    }

    @Transactional(readOnly = true)
    //@TargetDataSource(name = "ds2")
    public List<ChannelInfo> getAll() {
        return channelinfoRepository.findAll();
    }

    @Transactional(readOnly = true)
    //@TargetDataSource(name = "ds2")
    public ChannelInfo getById(Long id) {
        if (logger.isDebugEnabled()) {
            logger.debug("Returning channelinfo with id: " + id);
        }

        return channelinfoRepository.findOne(id);
    }

    @Transactional(readOnly = false)
    //@TargetDataSource(name = "ds2")
    public void update(ChannelInfo channelinfo) {
        channelinfoRepository.save(channelinfo);

        logger.debug("Updated channelinfo " + channelinfo);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Transactional(readOnly = true)
    //@TargetDataSource(name = "ds2")
    public Page getPage(int currPage, int pageSize, String search) {
        PageRequest pageRequest = new PageRequest(currPage, pageSize);
        Page<ChannelInfo> page = null;
        if (StringUtils.isNullOrEmpty(search)) {
            page = channelinfoRepository.getPage(pageRequest);
        } else {
            page = channelinfoRepository.getPage(pageRequest, search);
        }
        return page;
    }

    //@TargetDataSource(name = "ds2")
    public Map<String, Object> delete(String ids) {
        String[] tmp = ids.split("\\,");
        int i = 0;
        for (String id : tmp) {
            try {
                channelinfoRepository.delete(Long.valueOf(id));
                i++;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("num", Integer.valueOf(i));
        return map;
    }
}
