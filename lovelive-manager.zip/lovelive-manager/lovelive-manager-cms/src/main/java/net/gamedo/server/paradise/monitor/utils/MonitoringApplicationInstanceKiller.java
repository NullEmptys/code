package net.gamedo.server.paradise.monitor.utils;

import net.gamedo.server.paradise.model.primary.monitor.ApplicationInstance;
import net.gamedo.server.paradise.monitor.scheduler.DynamicJob;
import net.gamedo.server.paradise.monitor.scheduler.DynamicSchedulerFactory;
import net.gamedo.server.paradise.repository.primary.ApplicationInstanceRepository;
import net.gamedo.server.paradise.utils.BeanProvider;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by liuxing on 2016/4/12 0012.
 */
public class MonitoringApplicationInstanceKiller {

    private static final Logger LOGGER = LoggerFactory.getLogger(MonitoringApplicationInstanceKiller.class);
    private transient ApplicationInstanceRepository instanceRepository = BeanProvider.getBean(ApplicationInstanceRepository.class);
    private Long intanceId;

    public MonitoringApplicationInstanceKiller(Long intanceId) {
        this.intanceId = intanceId;
    }

    public boolean kill() {
        final ApplicationInstance instance = instanceRepository.findOne(intanceId);
//        if (instance.getEnabled() == 1) {
//            LOGGER.debug("Expect ApplicationInstance[guid={}] enabled=true,but it is false, illegal status", instance.getGuid());
//            return false;
//        }

        if (!pauseJob(instance)) {
            LOGGER.debug("Pause Job[name={}] failed", instance.getJobName());
            return false;
        }

        //update
        instance.setEnabled(0);
//        instanceRepository.save(instance);
        LOGGER.debug("Update ApplicationInstance[guid={}] enabled=false", instance.getGuid());
        return true;
    }

    private boolean pauseJob(ApplicationInstance instance) {
        DynamicJob job = new DynamicJob(instance.getJobName());
        try {
            return DynamicSchedulerFactory.pauseJob(job);
        } catch (SchedulerException e) {
            LOGGER.error("<{}> Pause [" + job + "] failed", e);
            return false;
        }
    }
}
