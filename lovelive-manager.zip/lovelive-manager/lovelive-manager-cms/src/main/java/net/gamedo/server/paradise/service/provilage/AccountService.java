/* Copyright 2004, 2005, 2006 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.gamedo.server.paradise.service.provilage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.domain.DefaultPermissionFactory;
import org.springframework.security.acls.domain.PermissionFactory;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.model.Permission;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysql.jdbc.StringUtils;

import net.gamedo.server.paradise.model.provilage.Account;
import net.gamedo.server.paradise.repository.primary.provilage.AccountSecureRepository;
import net.gamedo.server.paradise.cms.service.UserService;
import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.provilage.Sysmenu;
import net.gamedo.server.paradise.model.provilage.Sysmodel;
import net.gamedo.server.paradise.model.provilage.Syspage;

@Service
@Transactional
public class AccountService extends BaseService {
	private final static Permission[] HAS_READ = new Permission[] { BasePermission.READ, BasePermission.DELETE,
			BasePermission.CREATE, BasePermission.WRITE, BasePermission.ADMINISTRATION };

	@Autowired
	private AccountSecureRepository accountSecureRepository;

	@Autowired
	private SyspageService syspageService;

	@Autowired
	private SysmodelService sysmodelService;

	@Autowired
	private PermissionEvaluator permissionEvaluator;

	@Autowired
	private UserService userService;

	private final PermissionFactory permissionFactory = new DefaultPermissionFactory();

	// @PreAuthorize("hasRole('ROLE_USER')")
	public void create(Account account) {
		accountSecureRepository.save(account);

		// Grant the current principal administrative permission to the contact
		// addPermission(Account.class, account.getId(), new
		// PrincipalSid(getUsername()), BasePermission.ADMINISTRATION);

	}

	// @PreAuthorize("hasPermission(#id, 'sample.account.Syspage', read) or "
	// + "hasPermission(#id, 'sample.account.Syspage', admin)")
	@Transactional(readOnly = true)
	public Account getById(Long id) {
		if (logger.isDebugEnabled()) {
			logger.debug("Returning account with id: " + id);
		}

		return accountSecureRepository.findById(id);
	}

	public void update(Account account) {
		Account accountOld = accountSecureRepository.findById(account.getId());
		if (accountOld == null) {
			throw new UsernameNotFoundException("user not found");
		}
		boolean changePwd = !StringUtils.isNullOrEmpty(accountOld.getPassword());
		if (changePwd)
			accountOld.setPassword(account.getPassword());
		accountOld.setEmail(account.getEmail());
		accountOld.setRole(account.getRole());
		accountSecureRepository.update(accountOld, changePwd);

		logger.debug("Updated account " + account);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public CurrentPage getPage(int currPage, int pageSize, String search) {

		int total = (int) accountSecureRepository.count();
		CurrentPage page = getCurrentPage(total, currPage, pageSize, new CurrentPage<Account>());

		if (StringUtils.isNullOrEmpty(search))
			page.setPageItems(accountSecureRepository.getPage((currPage - 1) * pageSize, pageSize));
		else
			page.setPageItems(accountSecureRepository.getPage((currPage - 1) * pageSize, pageSize, search));
		return page;
	}

	public Map<String, Object> delete(String ids) {
		String[] tmp = ids.split("\\,");
		int i = 0;
		for (String id : tmp) {
			try {
				accountSecureRepository.delete(Long.valueOf(id));
				// Delete the ACL information as well
				// ObjectIdentity oid = new ObjectIdentityImpl(Account.class,
				// Long.valueOf(id));
				// mutableAclService.deleteAcl(oid, false);
				i++;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("num", Integer.valueOf(i));
		return map;
	}

	@Transactional(readOnly = true)
	public List<String> getAllRecipients() {
		logger.debug("Returning all recipients");

		return accountSecureRepository.findAllPrincipals();
	}

	public Map<String, Object> auth(String ids, Long accountId, String recipient, String mask) {
		String[] tmp = ids.split("\\,");
		int i = 0;
		Account account = this.getById(accountId);
		Authentication authentication = userService.authenticate(account);
		PrincipalSid sid = new PrincipalSid(recipient);
		Permission permission = permissionFactory.buildFromMask(Integer.valueOf(mask));
		List<Syspage> syspages = syspageService.getAll();
		for (Syspage syspage : syspages) {
			if (permissionEvaluator.hasPermission(authentication, syspage, HAS_READ)) {
				syspageService.deletePermission(Syspage.class, syspage.getId(), sid, permission);
			}
		}
		List<Sysmodel> sysmodels = sysmodelService.getAll();
		for (Sysmodel sysmodel : sysmodels) {
			if (permissionEvaluator.hasPermission(authentication, sysmodel, HAS_READ)) {
				syspageService.deletePermission(Sysmodel.class, sysmodel.getId(), sid, permission);
			}
		}

		for (String id : tmp) {
			if (id.length() == 0 || id.equalsIgnoreCase("null"))
				continue;
			// 大于1000为model
			Long idL = Long.parseLong(id);
			if (idL > 1000 && idL < 10000)
				syspageService.addPermission(Sysmodel.class, idL - 1000, sid, permission);
			else if (idL > 10000)
				syspageService.addPermission(Sysmenu.class, idL - 10000, sid, permission);
			else
				syspageService.addPermission(Syspage.class, idL, sid, permission);
			i++;
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("num", Integer.valueOf(i));
		return map;
	}

	public List<Syspage> getAuths(Long accountId) {
		Account account = this.getById(accountId);
		List<Syspage> syspages = syspageService.getAll();
		for (Syspage syspage : syspages) {
			if (!permissionEvaluator.hasPermission(userService.authenticate(account), syspage, HAS_READ)) {
				syspage.setChecked("false");
			} else {
				syspage.setChecked("true");
			}
			// 去掉没权限的sysmodel
			List<Sysmodel> sysmodels = syspage.getSysmodels();
			if (null != sysmodels) {
				for (Sysmodel sysmodel : sysmodels) {
					if (!permissionEvaluator.hasPermission(userService.authenticate(account), sysmodel, HAS_READ)) {
						sysmodel.setDescr("false");
					} else {
						sysmodel.setDescr("true");
					}
				}
			}
		}
		Syspage.sortSyspages(syspages);
		return syspages;
	}

	public List<Syspage> getAuthsForTree(Long accountId) {
		Account account = this.getById(accountId);
		List<Syspage> syspages = syspageService.getAll();
		for (Syspage syspage : syspages) {
			if (!permissionEvaluator.hasPermission(userService.authenticate(account), syspage, HAS_READ)) {
				syspage.setChecked("false");
			} else {
				syspage.setChecked("true");
			}
			// 去掉没权限的sysmodel
			List<Sysmodel> sysmodels = syspage.getSysmodels();
			if (null != sysmodels) {
				for (Sysmodel sysmodel : sysmodels) {
					if (!permissionEvaluator.hasPermission(userService.authenticate(account), sysmodel, HAS_READ)) {
						sysmodel.setDescr("false");
					} else {
						sysmodel.setDescr("true");
					}
				}
			}
			// 去掉没权限的sysmenu
			Sysmenu sysmenu = syspage.getSysmenu();
			if (null != sysmenu) {
				if (!permissionEvaluator.hasPermission(userService.authenticate(account), sysmenu, HAS_READ)) {
					sysmenu.setDescr("false");
				} else {
					sysmenu.setDescr("true");
				}
			}
		}
		Syspage.sortSyspagesForTree(syspages);
		return syspages;
	}

}
