package net.gamedo.server.paradise.controller.statistics;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.thirdary.ClothCdTime;
import net.gamedo.server.paradise.service.statistics.IpocDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * Created by Administrator on 2016/4/23 0023.
 */
@Controller
@RequestMapping("/statistics/ipocdata")
public class IpocDataController extends BaseController {
    @Autowired
    private IpocDataService ipocDataService;

    @RequestMapping(value = "/getClothCdTime", method = RequestMethod.POST)
    @ResponseBody
    public List<ClothCdTime> getClothCdTime() {
        return ipocDataService.findAllColthCdTime();
    }
}
