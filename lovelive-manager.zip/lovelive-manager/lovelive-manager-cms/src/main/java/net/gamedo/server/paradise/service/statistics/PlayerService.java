package net.gamedo.server.paradise.service.statistics;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.sd4324530.fastweixin.util.JSONUtil;

import net.gamedo.server.paradise.cms.Constants;
import net.gamedo.server.paradise.dto.PlayerDTO;
import net.gamedo.server.paradise.service.provilage.BaseService;
import net.gamedo.server.paradise.utils.NetWorkUtils;

/**
 * Created by qushibin on 2016/03/30.
 */
@Service
public class PlayerService extends BaseService {

    private Logger logger = Logger.getLogger(getClass().getName());

    public String search(String search, String type) {
        try {
            search = URLEncoder.encode(search, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        JSONObject result = NetWorkUtils.netGet(Constants.remoteUrl + "api/player/list?search=" + search + "&type=" + type);
        if (result != null) {
            if (result.containsKey("playerBaseList")) {
                JSONArray playerBaseList = result.getJSONArray("playerBaseList");
                logger.info("searchOne result: " + playerBaseList);
                return playerBaseList.toJSONString();
            }
        }
        return null;
    }

    public String searchOne(int playerId) {
        JSONObject result = NetWorkUtils.netGet(Constants.remoteUrl + "api/player/" + playerId + "/detail");
        if (result != null) {
            if (result.containsKey("playerInfo")) {
                JSONObject playerInfo = result.getJSONObject("playerInfo");
                logger.info("searchOne result: " + playerInfo);
                return playerInfo.toJSONString();
            }
        }
        return null;
    }

    public String update(PlayerDTO mode) {
        System.out.println("update mode:" + mode.toString());
        boolean gold = false, money = false;
        if (mode.getChangeGold() == 1 || mode.getChangeGold() == 2) {
            gold = this.updateGold(mode);
            if (mode.getChangeMoney() == 0) {
                money = true;
            }
        }
        if (mode.getChangeMoney() == 1 || mode.getChangeMoney() == 2) {
            gold = true;
            money = this.updateMoney(mode);
        }
        int info = this.updateInfo(mode);
        if (gold || money || info != 0) {
            if (info == 1)
                return searchOne(mode.getPlayerId());
            else if (info == 3)
                return "模特ID 重复";
            else if (info == 4)
                return "模特不存在";
        }

        return null;
    }

    private boolean updateGold(PlayerDTO mode) {
        Map<String, Object> params = new HashMap<>();
        params.put("number", mode.getChangeGoldVal());
        params.put("type", mode.getChangeGold());
        JSONObject result = NetWorkUtils.netPost(Constants.remoteUrl + "api/player/" + mode.getPlayerId() + "/updateGold", JSONUtil.toJson(params));//params.toJSONString());
        return result != null;
    }

    private boolean updateMoney(PlayerDTO mode) {
        JSONObject params = new JSONObject();
        params.put("number", mode.getChangeMoneyVal());
        params.put("type", mode.getChangeMoney());
        JSONObject result = NetWorkUtils.netPost(Constants.remoteUrl + "api/player/" + mode.getPlayerId() + "/updateMoney", params.toString());
        return result != null;
    }

    private int updateInfo(PlayerDTO mode) {
        JSONObject params = new JSONObject();
        params.put("name", mode.getName());
        params.put("state", mode.getState());
        params.put("playerType", mode.getPlayerType());
        int tili = mode.getTili();
        if (mode.getChangeTili() == 1) {
            tili += mode.getChangeTiliVal();
        } else if (mode.getChangeTili() == 2) {
            tili -= mode.getChangeTiliVal();
        }
        params.put("girlId", String.valueOf(mode.getGirlId()));
        params.put("tili", tili);
        JSONObject result = NetWorkUtils.netPost2(Constants.remoteUrl + "api/player/" + mode.getPlayerId() + "/updatePlayer", params.toString());
        if (result != null) {
            logger.info("result is: " + result.toJSONString());
            if (result.containsKey("code")) {
                Object code = result.get("code");
                logger.info(code);
                if (code instanceof String) {
                    logger.info("code is:" + code);
                    if ("3".equals(code)) {
                        return 3;//girlId重复
                    } else if("4".equals(code)){
                        return 4; //girlId不存在
                    } else if("0".equals(code)){
                        return 1; //成功
                    }
                }
            }
        }
        return 0;//失败
    }

    public boolean offline(int id) {
        JSONObject result = NetWorkUtils.netGet(Constants.remoteUrl + "api/player/" + id + "/playerLogout");
        return result != null;
    }
}
