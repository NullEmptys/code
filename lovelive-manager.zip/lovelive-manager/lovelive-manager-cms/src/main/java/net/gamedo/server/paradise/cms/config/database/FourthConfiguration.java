package net.gamedo.server.paradise.cms.config.database;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

/**
 * Created by TruthBean on 2016/3/12 0012.
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef="fourthEntityManagerFactory",
        transactionManagerRef="fourthTransactionManager",
        basePackages= { "net.gamedo.server.paradise.repository.fourth" })//设置dao（repo）所在位置
public class FourthConfiguration {

    @Autowired
    @Qualifier("fourthDataSource")
    private DataSource fourthDataSource;

    @Bean
    public EntityManager fourthEntityManager(EntityManagerFactoryBuilder builder) {
        return fourthEntityManagerFactory(builder).getObject().createEntityManager();
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean fourthEntityManagerFactory(
            EntityManagerFactoryBuilder builder) {
        return builder
                .dataSource(fourthDataSource)
                .packages("net.gamedo.server.paradise.model.fourth")
                .persistenceUnit("fourth-unit")
                .build();
    }

    @Bean
    PlatformTransactionManager fourthTransactionManager(EntityManagerFactoryBuilder builder) {
        return new JpaTransactionManager(fourthEntityManagerFactory(builder).getObject());
    }

}
