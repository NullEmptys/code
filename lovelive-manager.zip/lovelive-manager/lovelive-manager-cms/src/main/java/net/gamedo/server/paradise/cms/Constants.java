package net.gamedo.server.paradise.cms;

public class Constants {
//	public final static String remoteUrl = "http://114.55.74.44:888/gameServer/app/";
	public final static String remoteUrl = "http://localhost:8088/gameServer/app/";
//	public final static String remoteUrl = "http://101.200.231.42:8181/gameServer/app/";
//	public final static String remoteUrl = "http://101.200.231.42:8082/gameServer/app/";
//	public final static String remoteUrl = "http://fz.xdsyh.gamedo.com.cn/gameServer/app/";
	
	public final static int categoryGift = 0;         // 礼物类型
	public final static int categoryClothing = 1;     // 服装类型
	public final static int categorySpecial = 3;      // 特效类型
	public final static int categoryRahmen = 4;       // 相框类型
	public final static int categoryAction = 2;       // 动作类型
	public final static int categoryMirror = 5;       // 写真类型
	
	
	
}
