package net.gamedo.server.paradise.monitor.utils;

import com.mysql.jdbc.StringUtils;
import net.gamedo.server.paradise.model.primary.monitor.ApplicationInstance;
import net.gamedo.server.paradise.monitor.job.MonitoringInstanceJob;
import net.gamedo.server.paradise.monitor.scheduler.DynamicJob;
import net.gamedo.server.paradise.monitor.scheduler.DynamicSchedulerFactory;
import net.gamedo.server.paradise.monitor.scheduler.JobParamManager;
import net.gamedo.server.paradise.service.statistics.ApplicationInstanceService;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by liuxing on 2016/4/12 0012.
 */
@Component
public class ApplicationInstanceEnabler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationInstanceEnabler.class);
    @Autowired
    private ApplicationInstanceService instanceService;
    private Long intanceId;

    public ApplicationInstanceEnabler() {
    }

    public void setIntanceId(Long intanceId) {
        this.intanceId = intanceId;
    }

    public ApplicationInstanceEnabler(Long intanceId) {
        this.intanceId = intanceId;
    }

    public boolean enable() {
        final ApplicationInstance instance = instanceService.getById(intanceId);
//        if (instance.getEnabled() == 1) {
//            LOGGER.info("Instance[guid={}] already enabled, ignore it", instance.getGuid());
//            return false;
//        }

        final boolean addSuccessful = startupMonitoringJob(instance);
        if (!addSuccessful) {
            LOGGER.info("NOTE: Add MonitoringJob[jobName={}] failed", instance.getJobName());
            return false;
        }

        //update
        instance.setEnabled(1);
//        instanceService.create(instance);
        LOGGER.info("Update ApplicationInstance[guid={}] enabled=true,jobName={}", instance.getGuid(), instance.getJobName());

        return true;
    }

    private boolean startupMonitoringJob(ApplicationInstance instance) {
        final String jobName = getAndSetJobName(instance);

        DynamicJob job = new DynamicJob(jobName)
                .cronExpression(instance.getFrequency().getCronExpression())
                .target(MonitoringInstanceJob.class)
                .addJobData(MonitoringInstanceJob.APPLICATION_INSTANCE_GUID, instance.getGuid());

        return executeStartup(instance, job);
    }

    private boolean executeStartup(ApplicationInstance instance, DynamicJob job) {
        boolean result = false;
        try {
            if (DynamicSchedulerFactory.existJob(job)) {
                result = DynamicSchedulerFactory.resumeJob(job);
                LOGGER.info("Resume  [{}] by ApplicationInstance[guid={},instanceName={}] result: {}", job, instance.getGuid(), instance.getInstanceName(), result);
            } else {

                result = DynamicSchedulerFactory.registerJob(job);
                LOGGER.info("Register  [{}] by ApplicationInstance[guid={},instanceName={}] result: {}", job, instance.getGuid(), instance.getInstanceName(), result);
            }
        } catch (SchedulerException e) {
            LOGGER.error("Register [" + job.jobName() + "] failed", instance.getInstanceName(), e);
        }
        return result;
    }

    private String getAndSetJobName(ApplicationInstance instance) {
        String jobName = instance.getJobName();
        if (StringUtils.isNullOrEmpty(jobName)) {
            jobName = JobParamManager.generateMonitoringInstanceJobName(instance.getGuid());
            instance.setJobName(jobName);
        }
        return jobName;
    }
}
