package net.gamedo.server.paradise.controller.systems;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.data.domain.Page;
import org.springframework.security.acls.domain.DefaultPermissionFactory;
import org.springframework.security.acls.domain.PermissionFactory;
import org.springframework.security.acls.model.AclService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import net.gamedo.server.paradise.acl.AddPermissionValidator;
import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.core.ModelBase;
import net.gamedo.server.paradise.model.provilage.Sysmodel;
import net.gamedo.server.paradise.service.provilage.SysmodelService;

@Controller
@RequestMapping("/systems/model")
@SessionAttributes("addPermission")
public final class SysmodelController extends BaseController {
	@Autowired
	private AclService aclService;
	@Autowired
	private SysmodelService sysmodelService;
	private MessageSourceAccessor messages;
	private final Validator addPermissionValidator = new AddPermissionValidator();
	private final PermissionFactory permissionFactory = new DefaultPermissionFactory();

	@RequestMapping
	public String list(HttpServletRequest request, Model model) {
		initModel(request, model);

		return "systems/model/model_index";
	}

	/**
	 * 分页查询
	 * 
	 * @param request
	 * @param currPage
	 *            当前页
	 * @param perPage
	 * @param search
	 *            查询参数
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody Page listForPage(int currPage, int pageSize, String search) {
		return sysmodelService.getPage(currPage, pageSize, search);
	}

	/**
	 * 保存 修改菜单
	 *
	 * @param request
	 * @param data
	 * @return @
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody Sysmodel save(HttpServletRequest request, String data) {
		try {
			Sysmodel model = ModelBase.deSerialize(data, Sysmodel.class);
			if (null == model.getId()) { // 新增
				sysmodelService.create(model);
			} else { // 修改更新
				sysmodelService.update(model);
			}
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据ids删除菜单
	 *
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/del", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> del(String ids) {
		return sysmodelService.delete(ids);
	}

	/**
	 * 根据id获取菜单
	 *
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/get", method = RequestMethod.POST)
	public @ResponseBody Sysmodel get(Long id) {
		return sysmodelService.getById(id);
	}

}
