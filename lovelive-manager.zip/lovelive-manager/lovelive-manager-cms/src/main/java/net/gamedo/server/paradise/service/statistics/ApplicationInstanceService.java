package net.gamedo.server.paradise.service.statistics;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mysql.jdbc.StringUtils;
import net.gamedo.server.paradise.model.primary.monitor.ApplicationInstance;
import net.gamedo.server.paradise.monitor.job.PerHeartBeatExecutor;
import net.gamedo.server.paradise.monitor.utils.ApplicationInstanceDeleter;
import net.gamedo.server.paradise.monitor.utils.ApplicationInstanceEnabler;
import net.gamedo.server.paradise.monitor.utils.MonitoringApplicationInstanceKiller;
import net.gamedo.server.paradise.repository.primary.ApplicationInstanceRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.gamedo.server.paradise.service.provilage.BaseService;

/**
 * Created by liuxing on 2016/04/11.
 */
@Service
public class ApplicationInstanceService extends BaseService {
    private static Logger log = Logger.getLogger("ApplicationInstanceService");
    @Autowired
    private ApplicationInstanceRepository applicationinstanceRepository;
    @Autowired
    private ApplicationInstanceEnabler applicationInstanceEnabler;
    @Autowired
    private PerHeartBeatExecutor perHeartBeatExecutor;

    public void create(ApplicationInstance applicationinstance) {
        applicationinstanceRepository.saveAndFlush(applicationinstance);
    }

    @Transactional(readOnly = true)
    public List<ApplicationInstance> getAll() {
        return applicationinstanceRepository.findAll();
    }

    @Transactional(readOnly = true)
    public ApplicationInstance getById(Long id) {
        if (logger.isDebugEnabled()) {
            logger.debug("Returning applicationinstance with id: " + id);
        }

        return applicationinstanceRepository.findOne(id);
    }

    public void update(ApplicationInstance applicationinstance) {
        applicationinstanceRepository.save(applicationinstance);

        logger.debug("Updated applicationinstance " + applicationinstance);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Transactional(readOnly = true)
    public Page getPage(int currPage, int pageSize, String search) {

//        int total = (int) applicationinstanceRepository.count();
        Page<ApplicationInstance> page = null;
        PageRequest pageRequest = new PageRequest(currPage, pageSize);
        if (StringUtils.isNullOrEmpty(search)) {
            page = applicationinstanceRepository.findAll(pageRequest);
        } else {
            page = applicationinstanceRepository.findAllByChannelId(search, pageRequest);
        }

        return page;
    }

    public Map<String, Object> delete(String ids) {
        String[] tmp = ids.split("\\,");
        int i = 0;
        for (String id : tmp) {
            try {
                ApplicationInstance instance = applicationinstanceRepository.findOne(Long.valueOf(id));
                applicationinstanceRepository.delete(Long.valueOf(id));
                this.deleteApplicationInstance(instance);

                i++;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("num", Integer.valueOf(i));
        return map;
    }

    /**
     * 开始监控
     *
     * @param instanceId
     * @return
     */
    public boolean enableApplicationInstance(Long instanceId) {
        applicationInstanceEnabler.setIntanceId(instanceId);
        return applicationInstanceEnabler.enable();
    }

    /**
     * 启动执行监控
     *
     * @param guid
     */
    public void executePerHeartBeatByInstance(String guid) {
        perHeartBeatExecutor.setGuid(guid);
        perHeartBeatExecutor.execute();
    }

    /**
     * 停止监控
     *
     * @param instanceId
     * @return
     */
    public boolean stopMonitoringApplicationInstance(Long instanceId) {
        MonitoringApplicationInstanceKiller instanceKiller = new MonitoringApplicationInstanceKiller(instanceId);
        return instanceKiller.kill();
    }

    /**
     * 删除监控
     *
     * @param instance
     * @return
     */
    public boolean deleteApplicationInstance(ApplicationInstance instance) {
        ApplicationInstanceDeleter instanceDeleter = new ApplicationInstanceDeleter(instance);
        return instanceDeleter.delete();
    }

//    public InstanceStatisticsDto loadInstanceStatisticsDto(Long instanceId) {
//        InstanceStatisticsDtoLoader statisticsDtoLoader = new InstanceStatisticsDtoLoader(guid);
//        return statisticsDtoLoader.load();
//    }


}
