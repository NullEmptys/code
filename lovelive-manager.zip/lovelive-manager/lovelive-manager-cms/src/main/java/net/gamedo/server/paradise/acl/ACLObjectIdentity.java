package net.gamedo.server.paradise.acl;

public class ACLObjectIdentity {

	/**
	 * 进行 ACL 授权的对象需要有 getId 这个方法
	 */
	Integer id;

	String startDate;
	String endDate;

	public ACLObjectIdentity(Integer id, String startDate, String endDate) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

}
