package net.gamedo.server.paradise.monitor.scheduler;

/**
 * Created by Administrator on 2016/4/12 0012.
 */
public abstract class JobParamManager {
    private static final String MONITORING_INSTANCE_JOB_NAME_PREFIX = "monitoring-instance-";


    protected JobParamManager() {
    }

    public static String generateMonitoringInstanceJobName(String key) {
        return MONITORING_INSTANCE_JOB_NAME_PREFIX + key;
    }
}
