package net.gamedo.server.paradise.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.sd4324530.fastweixin.api.response.BaseResponse;
import com.github.sd4324530.fastweixin.util.JSONUtil;
import com.github.sd4324530.fastweixin.util.NetWorkCenter;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Created by TruthBean on 2016/4/8 0008.
 */
public class NetWorkUtils {

    private static Logger logger = Logger.getLogger(NetWorkUtils.class.getName());

    public static JSONObject netGet(String url) {
        logger.info("netGet url: " + url);
        try {
            BaseResponse response = NetWorkCenter.get(url);
            if (Objects.equals(response.getErrcode(), "0")) {
                JSONObject object = JSON.parseObject(response.getErrmsg());
                logger.info("response result: " + object.toJSONString());
                if (object.containsKey("code")) {
                    Object code = object.get("code");
                    if (code instanceof String && code.equals("0")) {
                        return object;
                    }
                }
            }
        } catch (Exception ex) {
            logger.error(ex);
            return null;
        }

        return null;
    }

    public static JSONObject netPost(String url, String paramData) {
        logger.info("netPost url: " + url);
        try {
            BaseResponse response = NetWorkCenter.post(url, paramData);
            if (response.getErrcode() == null || "0".equals(response.getErrcode())) {
                JSONObject object = JSON.parseObject(response.getErrmsg());
                logger.info("response result: " + object.toJSONString());
                if (object.containsKey("code")) {
                    Object code = object.get("code");
                    if (code instanceof String && code.equals("0")) {
                        return object;
                    }
                }
            }
        } catch (Exception ex) {
            logger.error(ex);
            return null;
        }
        return null;
    }

    public static JSONObject netPost2(String url, String paramData) {
        logger.info("netPost url: " + url);
        try {
            BaseResponse response = NetWorkCenter.post(url, paramData);
            if (response.getErrcode() == null || "0".equals(response.getErrcode())) {
                JSONObject object = JSON.parseObject(response.getErrmsg());
                logger.info("response result: " + object.toJSONString());
                return object;
            }
        } catch (Exception ex) {
            logger.error(ex);
            return null;
        }
        return null;
    }

    public static Map<String, Object> doGet(String url) {
        try {
            BaseResponse response = NetWorkCenter.get(url);
            return JSONUtil.toMap(response.getErrmsg());
        } catch (Exception ex) {
            logger.error(ex);
            return null;
        }

    }

    public static Map<String, Object> doPost(String url, Map<String, Object> params) {
        try {
            String json = JSONUtil.toJson(params);
            BaseResponse response = NetWorkCenter.post(url, json);
            return JSONUtil.toMap(response.getErrmsg());
        } catch (Exception ex) {
            logger.error(ex);
            return null;
        }

    }

}
