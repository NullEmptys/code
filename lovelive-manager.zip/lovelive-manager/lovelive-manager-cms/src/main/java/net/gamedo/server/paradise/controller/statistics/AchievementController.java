package net.gamedo.server.paradise.controller.statistics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.mysql.jdbc.StringUtils;

import net.gamedo.server.paradise.cms.Constants;
import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.utils.NetWorkUtils;

@Controller
@RequestMapping("/statistics/achievement")
public class AchievementController extends BaseController {

	@RequestMapping
	public String list(HttpServletRequest request, Model model) {
		initModel(request, model);
		return "statistics/achievement/achievement_index";
	}

	// 成就查询列表
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> listForPage(String playerId, 
			String achievement_id, String achievement_type) {
		List<Map<String, Object>> achievementList = new ArrayList<Map<String, Object>>();
		String getUrl = Constants.remoteUrl + "/api/achievement/" + playerId + "/list";
		Map<String, Object> map = new HashMap<>();
		if(null != achievement_type && !"".equals(achievement_type)){
			map.put("category", achievement_type);
		}
		if(null != achievement_id && !"".equals(achievement_id)){
			map.put("achieveId", achievement_id);
		}
		Map<String, Object> mapObj = NetWorkUtils.doPost(getUrl, map);
		if(null != mapObj){
			if("0".equals(mapObj.get("code"))){
				List<Map<String, Object>> list = (List<Map<String, Object>>) mapObj.get("achievementList");
				if (list.size() > 0) {
					achievementList.addAll(list);
				}
			}
		}
		return achievementList;
	}

	// 修改
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody int save(HttpServletRequest request, String playerId, String data) {
		JSONObject o = JSONObject.parseObject(data);
		if (!StringUtils.isNullOrEmpty(playerId)) {
			String getUrl = Constants.remoteUrl + "/api/achievement/" + playerId + "/update";
			Map<String, Object> map = new HashMap<>();
			if(null != o.get("value") && !"".equals(o.get("value"))){
				map.put("value", o.get("value"));
			}
			if(null != o.get("rewarded") && !"".equals(o.get("rewarded"))){
				map.put("rewarded", o.get("rewarded"));
			}
			if(null != o.get("achieveId") && !"".equals(o.get("achieveId"))){
				map.put("achieveId", o.get("achieveId"));
			}
			Map<String, Object> mapObj = NetWorkUtils.doPost(getUrl, map);
			return null == mapObj.get("code")? 1 : Integer.parseInt(mapObj.get("code")+"");
		}
		return 1;
	}
}
