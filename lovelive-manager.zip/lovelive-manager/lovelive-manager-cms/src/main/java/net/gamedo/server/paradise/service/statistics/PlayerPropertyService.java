package net.gamedo.server.paradise.service.statistics;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;

import net.gamedo.server.paradise.cms.Constants;
import net.gamedo.server.paradise.model.thirdary.player.Item;
import net.gamedo.server.paradise.repository.thirdary.ItemRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;
import net.gamedo.server.paradise.utils.NetWorkUtils;

/**
 * Created by Administrator on 2016.3.22
 */
@Service
public class PlayerPropertyService extends BaseService {
	@Autowired
	private ItemRepository itemRepository;

	// 由itemId道具Id查询道具
	//@TargetDataSource(name = "ds2")
	public Item getItem(int itemId) {
		return itemRepository.getItemByItemId(itemId);
	}

	// 由category类型来查询道具
	//@TargetDataSource(name = "ds2")
	public List<Item> getItemByCategoryType(int categoryType) {
		return itemRepository.getItemByCategoryType(categoryType);
	}

	// 获取全部道具信息(道具ID、道具名)
	//@TargetDataSource(name = "ds2")
	public List<Item> getAllItem() {
		List<Item> list = itemRepository.findAll();
		return list;
	}

	//获取String类型Json数据中的对应值
	public static String getValueToJson(String key, String json) {
		JSONObject o = JSONObject.parseObject(json);
		return o.get(key) == null ? null : o.get(key).toString();
	}

	// 玩家持有道具列表
	//@TargetDataSource(name = "ds2")
	public List<Map<String, Object>> getPage(String id, int category) {
		List<Map<String, Object>> playerPropertyAllLists = new ArrayList<Map<String, Object>>();
		if (null != id && !id.equals("")) {
			String getUrl = Constants.remoteUrl + "api/player/" + id + "/bags";
			Map<Integer, Integer> itemMap = new HashMap<>();
			Map<String, Object> objectMap = NetWorkUtils.doGet(getUrl);
			if (null != objectMap) {
				Map<String, Object> bagData = (Map<String, Object>) objectMap.get("bagData");
				List<Map<String, Object>> bags = (List<Map<String, Object>>) bagData.get("bags");
				for (Map<String, Object> m : bags) {
					List<Map<String, Object>> m1 = (List<Map<String, Object>>) m.get("items");
					if (m1.size() > 0) {
						for (Map<String, Object> map : m1) {
							Map<String, Object> papMap = new HashMap<String, Object>();
							Item item = getItem((int) (map.get("itemId")));
							papMap.put("count", map.get("count"));
							papMap.put("cdTime", map.get("cdTime"));
							papMap.put("gridId", map.get("gridId"));
							papMap.put("itemId", map.get("itemId"));
							papMap.put("name", item.getName());
							papMap.put("category", item.getCategory());
							papMap.put("bagId", m.get("bagId"));
							// 由类型查找数据
							if (item.getCategory() == (category)) {
								playerPropertyAllLists.add(papMap);
							}
						}
					}
				}
			}
		}
		return playerPropertyAllLists;
	}

	// 新增道具
	public int create(int userId, String data) {
		Long num = null;
		JSONObject o = JSONObject.parseObject(data);
		Map<String, Object> map = new HashMap<>();
		map.put("category", Integer.parseInt(o.getString("category")));
		map.put("itemId", Integer.parseInt(o.getString("item_id_item")));
		if (Constants.categoryGift == Integer.parseInt(o.getString("category"))) {
			num = Long.parseLong(o.getString("num"));
			map.put("num", num);
		} else {
			if (null != o.getString("cdTimes") && !"".equals(o.getString("cdTimes"))) {
				num = Long.parseLong(o.getString("cdTimes"));
			} else {
				num = getDate(o.getString("cdTime"));
			}
			map.put("num", num);
		}
		String postUrl = Constants.remoteUrl + "api/player/" + userId + "/addItem";
		Map<String, Object> mapObj = NetWorkUtils.doPost(postUrl, map);
		return null == mapObj ? 1 : Integer.parseInt(mapObj.get("code") + "");
	}

	// 修改道具
	public int update(int userId, String data) {
		Long num;
		JSONObject o = JSONObject.parseObject(data);
		String postUrl = Constants.remoteUrl + "api/player/" + userId + "/";
		Map<String, Object> map = new HashMap<>();
		map.put("category", Integer.parseInt(o.getString("category")));
		map.put("itemId", Integer.parseInt(o.getString("modal_itemId")));
		// num(服装——cdTime/cdTimes)/(礼物——num add/remote)
		if (Constants.categoryGift == Integer.parseInt(o.getString("category"))) {
			Long updateCount = Long.parseLong(o.getString("num"));
			String getUrl = Constants.remoteUrl + "api/player/" + userId + "/bags";
			Map<Integer, Integer> itemMap = new HashMap<>();
			Map<String, Object> objectMap = NetWorkUtils.doGet(getUrl);
			if (null != objectMap) {
				Map<String, Object> bagData = (Map<String, Object>) objectMap.get("bagData");
				if (null != bagData) {
					List<Map<String, Object>> bags = (List<Map<String, Object>>) bagData.get("bags");
					if (null != bags && bags.size() > 0) {
						for (Map<String, Object> m : bags) {
							if ((m.get("bagId") + "").equals(o.getString("modal_bagId"))) {
								List<Map<String, Object>> m1 = (List<Map<String, Object>>) m.get("items");
								if (null != m1 && m1.size() > 0) {
									for (Map<String, Object> parpMap : m1) {
										if ((parpMap.get("gridId") + "").equals(o.getString("modal_gridId"))) {
											int count = (int) parpMap.get("count");
											if (count > 0) {
												if (count > updateCount) {
													map.put("num", count - updateCount);
													map.put("bagId", Integer.parseInt(o.getString("modal_bagId")));
													map.put("gridId", Integer.parseInt(o.getString("modal_gridId")));
													postUrl += "removeItem";
												} else {
													map.put("num", updateCount - count);
													postUrl += "addItem";
												}
											} else {
												map.put("num", updateCount);
												postUrl += "addItem";
											}
										}
									}
								}
							}
						}
					}
				}
			}
		} else {
			// num(服装——cdTimes/cdTime)
			if (null != o.getString("cdTimes") && !"".equals(o.getString("cdTimes"))) {
				num = Long.parseLong(o.getString("cdTimes"));
			} else {
				num = getDate(o.getString("cdTime"));
			}
			map.put("num", num);
			map.put("bagId", Integer.parseInt(o.getString("modal_bagId")));
			map.put("gridId", Integer.parseInt(o.getString("modal_gridId")));
			postUrl += "updateItem";
		}
		Map<String, Object> mapObj = NetWorkUtils.doPost(postUrl, map);
		return null == mapObj ? 1 : Integer.parseInt(mapObj.get("code") + "");
	}

	// 删除道具
	public boolean del(int playerId, int bagId, int gridId, int itemId, int count, int category) {
		Map<String, Object> map = new HashMap<>();
		map.put("bagId", bagId);
		map.put("gridId", gridId);
		map.put("itemId", itemId);
		map.put("category", category);
		map.put("num", new Long(count));
		String postUrl = Constants.remoteUrl + "api/player/" + playerId + "/removeItem";
		Map<String, Object> mapObj = NetWorkUtils.doPost(postUrl, map);
		return null != mapObj;
	}

	// String类型的时间格式转时间戳
	private Long getDate(String time) {
		Date date = new Date();
		try {
			date = (new SimpleDateFormat("yyyy/MM/dd HH:mm:ss")).parse(time);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date.getTime();
	}

}
