package net.gamedo.server.paradise.controller.statistics;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.primary.player.Email;
import net.gamedo.server.paradise.service.statistics.EmailService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Created by TruthBean on 2016/4/7 0007.
 */
@Controller
@RequestMapping("/statistics/email")
public class EmailController extends BaseController {

    private Logger logger = Logger.getLogger(getClass().getName());

    @Autowired
    private EmailService mailService;

    @RequestMapping
    public String list(HttpServletRequest request, Model model) {
        initModel(request, model);
        return "statistics/email/email_index";
    }

    @RequestMapping(value = "/listForPage", method = RequestMethod.POST)
    public @ResponseBody Page<Email> listForPage(int currPage, int pageSize) {
        return mailService.getPaged(currPage, pageSize);
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public @ResponseBody
    Email save(String data, boolean isSendNow){
        try {
            Email mail = mapper.readValue(data, Email.class);
            return mailService.save(mail, isSendNow);
        } catch (IOException e) {
            logger.error(e);
        }
        return null;
    }

    /**
     * 通过Id获取邮件信息
     * @param id
     * @return
     */
    @RequestMapping(value = "/get", method = RequestMethod.POST)
    public @ResponseBody Email getOne(int id){
        return mailService.getOne(id);
    }

    @RequestMapping(value = "/del", method = RequestMethod.POST)
    public @ResponseBody boolean delete(int id){
        return mailService.delete(id);
    }

    /**
     * 发送邮件
     * @param id
     * @return
     */
    @RequestMapping(value = "/send", method = RequestMethod.POST)
    public @ResponseBody boolean send(int id){
        return mailService.send(id);
    }
}
