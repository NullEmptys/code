package net.gamedo.server.paradise.core;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;

public class ModelBase{
	
	public String serialize() {
//		Field[] fields = this.getClass().getDeclaredFields();
//		for (Field field : fields) {
//			Annotation ano = field.getAnnotation(Convert.class);
//			if (ano != null) {
//				Convert convert = (Convert) ano;
//				try {
//					Field target = this.getClass().getDeclaredField(
//							convert.targetName());
//					target.setAccessible(true);
//					List list = (List) target.get(this);
//					Object array = Array.newInstance(field.getType()
//							.getComponentType(), list.size());
//					for (int i = 0; i < list.size(); i++) {
//						Field targetField = list.get(i).getClass()
//								.getDeclaredField(convert.targetFieldName());
//						targetField.setAccessible(true);
//						Object value = targetField.get(list.get(i));
//						Array.set(array, i, value);
//					}
//
//					field.setAccessible(true);
//					field.set(this, array);
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		}

		return JSON.toJSONString(this,SerializerFeature.DisableCircularReferenceDetect);
	}
	
	public String serialize(SimplePropertyPreFilter filter) {
		return JSON.toJSONString(this,filter,SerializerFeature.DisableCircularReferenceDetect);
	}

	public static <T> T deSerialize(String str,Class<T> clazz) {
		T t = JSON.parseObject(str, clazz);
//		Field[] fields = clazz.getDeclaredFields();
//		for (Field field : fields) {
//			Annotation ano = field.getAnnotation(Convert.class);
//			if (ano != null) {
//				Convert convert = (Convert) ano;
//				try {
//					Field target = clazz.getDeclaredField(
//							convert.targetName());
//					target.setAccessible(true);
//					List list = (List) target.get(t);
//
//					Class genericClazz;
//					Type fc = target.getGenericType();
//					if (fc instanceof ParameterizedType) { // ��3������Ƿ��Ͳ���������
//						ParameterizedType pt = (ParameterizedType) fc;
//						genericClazz = (Class) pt
//								.getActualTypeArguments()[0]; // ��4��
//																// �õ��������class���Ͷ���
//					}else{
//						throw new Exception("ת��json�����ʹ���");
//					}
//					field.setAccessible(true);
//					Object array = field.get(t);
//					for (int i = 0; i < Array.getLength(array); i++) {
//						Object object;
//						if(list.size()>=i || list.get(i)==null){
//							object = genericClazz.newInstance();
//							list.add(object);
//						}else{
//							object = list.get(i);
//						}
//						Field targetField = genericClazz
//								.getDeclaredField(convert.targetFieldName());
//						targetField.setAccessible(true);
//						targetField.set(object, Array.get(array, i));
//						
//					}
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		}
		return t;
	}
	
	/*public static <T extends ModelBase> ArrayBaseNet<T> deSerializeArray(String str,Class<ArrayBaseNet<T>> clazz) {
		return JSON.parseObject(str, clazz);
	}*/
	
	/**
	 * 反序列化数组对象
	 * @param str
	 * @param clazz
	 * @return
	 */
	public static <T> List<T> deSerializeAry(String str,Class<T> clazz) {
		return JSON.parseArray(str, clazz);
	}
	
}
