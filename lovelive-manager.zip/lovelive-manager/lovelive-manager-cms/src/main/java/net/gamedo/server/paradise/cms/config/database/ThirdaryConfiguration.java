package net.gamedo.server.paradise.cms.config.database;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

/**
 * Created by TruthBean on 2016/3/12 0012.
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef="thirdaryEntityManagerFactory",
        transactionManagerRef="thirdaryTransactionManager",
        basePackages= { "net.gamedo.server.paradise.repository.thirdary" })//设置dao（repo）所在位置
public class ThirdaryConfiguration {

    @Autowired
    @Qualifier("thirdaryDataSource")
    private DataSource thirdaryDataSource;

    @Bean
    public EntityManager thirdaryEntityManager(EntityManagerFactoryBuilder builder) {
        return thirdaryEntityManagerFactory(builder).getObject().createEntityManager();
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean thirdaryEntityManagerFactory(
            EntityManagerFactoryBuilder builder) {
        return builder
                .dataSource(thirdaryDataSource)
                .packages("net.gamedo.server.paradise.model.thirdary")
                .persistenceUnit("thirdary-unit")
                .build();
    }

    @Bean
    PlatformTransactionManager thirdaryTransactionManager(EntityManagerFactoryBuilder builder) {
        return new JpaTransactionManager(thirdaryEntityManagerFactory(builder).getObject());
    }

}
