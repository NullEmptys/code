package net.gamedo.server.paradise.controller.statistics;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.primary.monitor.FrequencyMonitorLog;
import net.gamedo.server.paradise.service.statistics.FrequencyMonitorLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by Administrator on 2016/4/12 0012.
 */
@Controller
@RequestMapping("/statistics/monitorLog")
public class FrequencyMonitorLogController extends BaseController {
    @Autowired
    private FrequencyMonitorLogService frequencyMonitorLogService;

    @RequestMapping(value = "/", method = RequestMethod.POST)
    @ResponseBody
    public FrequencyMonitorLog queryMonitorLog(long instanceId) {
        return frequencyMonitorLogService.findTopMonitorLog(instanceId);
    }


}
