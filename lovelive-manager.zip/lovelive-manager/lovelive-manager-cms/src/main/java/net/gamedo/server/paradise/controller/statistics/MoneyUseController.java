package net.gamedo.server.paradise.controller.statistics;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.secondary.player.CurrencyRecord;
import net.gamedo.server.paradise.service.statistics.MoneyUseService;

@Controller
@RequestMapping("/statistics/moneyuse")
public class MoneyUseController extends BaseController {
	@Autowired
	MoneyUseService moneyUseService;

	@RequestMapping
	public String list(HttpServletRequest request, Model model) {
		initModel(request, model);
		return "statistics/moneyuse/moneyuse_index";
	}
	
	// 货币流通列表
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody Page listForPage(String playerId, String type, String currencyType, 
			String startTime, String endTime, int currPage, int pageSize) {
		Map<String, Object> map = moneyUseService.getMoneyUseList(
				playerId, type, currencyType, startTime, endTime, currPage, pageSize);
		Long total = new Long(map.get("total")+"");
		List<CurrencyRecord> content = (List<CurrencyRecord>)map.get("content");
		Page page = new PageImpl<CurrencyRecord>(content, new PageRequest(currPage, pageSize), total);
		return page;
	}
	
	// 货币流通统计
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/statistics", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> statistics(String playerId, String type, String currencyType, 
			String startTime, String endTime, int currPage, int pageSize) {
		Map<String, Object> parpMap = moneyUseService.getMoneyUseListAll(playerId, type, currencyType, startTime, endTime, currPage, pageSize);
		Map<String, Object> map = new HashMap<String, Object>();
		int gold_get_statistics = 0, gold_use_statistics = 0,diamond_get_statistics = 0,  diamond_use_statistics = 0;
		List<CurrencyRecord> list = (List<CurrencyRecord>)parpMap.get("content");
		if(null != list){
			for(CurrencyRecord moneyUse : list){
				// 钻石
				if(moneyUse.getCurrencyType() == 101){
					if(moneyUse.getType() == 1){
						diamond_get_statistics += moneyUse.getCounts();
					} else if(moneyUse.getType() == 2){
						diamond_use_statistics += moneyUse.getCounts();
					}
				} else if(moneyUse.getCurrencyType() == 102){
					if(moneyUse.getType() == 1){
						gold_get_statistics += moneyUse.getCounts();
					} else if(moneyUse.getType() == 2){
						gold_use_statistics += moneyUse.getCounts();
					}
				}
			}
		}
		map.put("gold_get_statistics", gold_get_statistics);
		map.put("gold_use_statistics", gold_use_statistics);
		map.put("diamond_get_statistics", diamond_get_statistics);
		map.put("diamond_use_statistics", diamond_use_statistics);
		return map;
	}
}
