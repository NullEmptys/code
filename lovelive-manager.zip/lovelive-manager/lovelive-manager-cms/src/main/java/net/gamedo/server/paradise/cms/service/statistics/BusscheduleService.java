package net.gamedo.server.paradise.cms.service.statistics;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysql.jdbc.StringUtils;

import net.gamedo.server.paradise.model.primary.Busschedule;
import net.gamedo.server.paradise.repository.primary.BusscheduleRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;

@Service
public class BusscheduleService extends BaseService {
	@Autowired
	private BusscheduleRepository busscheduleRepository;

	public void create(Busschedule busschedule) {
		// Create the Busschedule itself
		busschedule.setSchedule();
		busscheduleRepository.save(busschedule);
	}

	@Transactional(readOnly = true)
	public Busschedule getById(Long id) {
		if (logger.isDebugEnabled()) {
			logger.debug("Returning busschedule with id: " + id);
		}

		return busscheduleRepository.findOne(id);
	}

	public void update(Busschedule busschedule) {
		busschedule.setSchedule();
		busscheduleRepository.save(busschedule);

		logger.debug("Updated busschedule " + busschedule);
	}

	@SuppressWarnings({ "rawtypes" })
	@Transactional(readOnly = true)
	public Page getPage(int currPage, int pageSize, String search, Long channel_id) {

		PageRequest pageRequest = new PageRequest(currPage, pageSize);
		Page<Busschedule> page = null;
		if (StringUtils.isNullOrEmpty(search)) {
			page = busscheduleRepository.getPage(pageRequest);
		} else {
			page = busscheduleRepository.getPage(search, pageRequest);
		}
		return page;
	}

	//@Transactional
	public boolean deleteByTableId(int tableId){
		return busscheduleRepository.deleteByTableId(tableId) > 0;
	}

	public Map<String, Object> delete(String ids) {
		String[] tmp = ids.split("\\,");
		int i = 0;
		for (String id : tmp) {
			try {
				busscheduleRepository.delete(Long.valueOf(id));
				i++;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("num", Integer.valueOf(i));
		return map;
	}
}
