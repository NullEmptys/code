package net.gamedo.server.paradise.controller.statistics;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.thirdary.GirlModel;
import net.gamedo.server.paradise.service.statistics.GirlModelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by Administrator on 16/7/1 0001.
 */
@Controller
@RequestMapping("/statistics/girlModel")
public final class GirlModelController extends BaseController {

    @Autowired
    private GirlModelService girlModelService;

    @RequestMapping
    public String list(HttpServletRequest request, Model model) {
        initModel(request, model);
        return "statistics/girlmodel/girlmodel_index";
    }

    /**
     * 分页查询
     *
     * @param currPage 当前页
     * @return
     */
    @SuppressWarnings("rawtypes")
    @RequestMapping(value = "/listForPage", method = RequestMethod.POST)
    public
    @ResponseBody
    CurrentPage listForPage(int currPage, int pageSize) {
        CurrentPage page = girlModelService.getPage(currPage, pageSize);
        return page;
    }

    /**
     * 保存 修改菜单
     *
     * @param request
     * @param data
     * @return @
     */
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public
    @ResponseBody
    GirlModel save(HttpServletRequest request, String data) {
        try {
            GirlModel obj = mapper.readValue(data, GirlModel.class);
            if (null == obj.getId()) { // 新增
                girlModelService.create(obj);
            } else { // 修改更新
                girlModelService.update(obj);
            }

            return obj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 根据ids删除菜单
     *
     * @param ids
     * @return
     */
    @RequestMapping(value = "/del", method = RequestMethod.POST)
    public
    @ResponseBody
    Map<String, Object> del(String ids) {
        return girlModelService.delete(ids);
    }

    /**
     * 根据id获取菜单
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/get", method = RequestMethod.POST)
    public
    @ResponseBody
    GirlModel get(Long id) {
        return girlModelService.getById(id);
    }

}