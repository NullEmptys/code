package net.gamedo.server.paradise.controller.statistics;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import net.gamedo.server.paradise.cms.Constants;
import net.gamedo.server.paradise.model.provilage.Account;
import net.gamedo.server.paradise.model.primary.player.LoginReward;
import net.gamedo.server.paradise.service.statistics.LoginRewardService;
import net.gamedo.server.paradise.utils.NetWorkUtils;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.primary.player.Activity;
import net.gamedo.server.paradise.service.statistics.ActivityService;

/**
 * Created by liuxing on 2016/04/20.
 * 活动管理controller
 */
@Controller
@RequestMapping("/statistics/activity")
public class ActivityController extends BaseController {

    @Autowired
    private ActivityService activityService;

    @Autowired
    private LoginRewardService loginRewardService;

    private final static String LOGIN_SIGN = "com.gamedo.gameServer.activity.loginReward.LoginRewardActivity";

    @RequestMapping
    public String list(HttpServletRequest request, Model model) {
        initModel(request, model);
        return "statistics/activity/activity_index";
    }

    /**
     * 分页查询
     *
     * @param currPage 当前页
     * @return
     */
    @SuppressWarnings("rawtypes")
    @RequestMapping(value = "/listForPage", method = RequestMethod.POST)
    public
    @ResponseBody
    CurrentPage listForPage(int currPage, int pageSize) {
        return activityService.getPage(currPage, pageSize);
    }

    //获取在线活动列表
    @RequestMapping(value = "/remoteList", method = RequestMethod.POST)
    @ResponseBody
    public List<Map<String, Object>> remoteList() throws ParseException {
        JSONObject jsonObject = NetWorkUtils.netGet(Constants.remoteUrl + "api/activity/activityList");
        List<Map<String, Object>> list = new ArrayList<>();
        List<Map<String, Object>> dataList = new ArrayList<>();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (jsonObject != null) {
            list.addAll((Collection<? extends Map<String, Object>>) jsonObject.get("activityList"));
            for (Map<String, Object> map : list) {
                Date broadcastEndTime = dateFormat.parse((String) map.get("broadcastEndTime"));
                Date broadcastStartTime = dateFormat.parse((String) map.get("broadcastStartTime"));
                Date startTime = dateFormat.parse((String) map.get("startTime"));
                Date endTime = dateFormat.parse((String) map.get("endTime"));
                map.put("broadcastEndTime", dateFormat.format(broadcastEndTime));
                map.put("broadcastStartTime", dateFormat.format(broadcastStartTime));
                map.put("startTime", dateFormat.format(startTime));
                map.put("endTime", dateFormat.format(endTime));
                jsonObject = NetWorkUtils.netGet(Constants.remoteUrl + "api/activity/" + map.get("id") + "/loadLoginRewardConfig");
                if (jsonObject != null) {
                    map.put("backGroundId", ((Map<String, Object>) jsonObject.get("loginRewardConfig")).get("backGroundId"));
                }
                dataList.add(map);
            }
        }
        return dataList;
    }

    /**
     * 保存 修改活动
     *
     * @param request
     * @param data
     * @return @
     */
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public
    @ResponseBody
    Activity save(HttpServletRequest request, String data) {
        Account account = this.getCurrentUser().getAccount();
        try {
            Activity obj = mapper.readValue(data, Activity.class);
            if (obj.getId() == null) { // 新增
                obj.setPublisher(account.getId());
                obj.setPublishName(account.getEmail());
                activityService.create(obj);
            } else { // 修改更新
                obj.setLastEditor(account.getId());
                obj.setLastEditorName(account.getEmail());
                activityService.update(obj);
            }
            return obj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 根据id删除活动
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/historyDelete", method = RequestMethod.POST)
    public
    @ResponseBody
    String historyDelete(String id) {
        return activityService.delete(id);
    }

    @RequestMapping(value = "/remoteDelete", method = RequestMethod.POST)
    public
    @ResponseBody
    String remoteDelete(String id) {
        NetWorkUtils.netGet(Constants.remoteUrl + "api/activity/" + id + "/activityDelete");
        reloadData(id);
        return id;
    }

    /**
     * 根据id获取活动
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/get", method = RequestMethod.POST)
    public
    @ResponseBody
    Activity get(Long id) {
        return activityService.getById(id);
    }

    @RequestMapping(value = "/getRemoteActivity", method = RequestMethod.POST)
    @ResponseBody
    public Activity getRemoteActivity(Long id) {
        DateTimeFormatter format = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss SSS Z");
        JSONObject jsonObject = NetWorkUtils.netGet(Constants.remoteUrl + "api/activity/" + id);
        Activity activity = new Activity();
        if (jsonObject != null) {
            Map<String, Object> map = (Map<String, Object>) jsonObject.get("activity");
            DateTime broadcastStartTime = DateTime.parse((String) map.get("broadcastStartTime"), format);
            activity.setBroadcastStartTime(broadcastStartTime.toDate());
            DateTime broadcastEndTime = DateTime.parse((String) map.get("broadcastEndTime"), format);
            activity.setBroadcastEndTime(broadcastEndTime.toDate());
            DateTime startTime = DateTime.parse((String) map.get("startTime"), format);
            activity.setStartTime(startTime.toDate());
            DateTime endTime = DateTime.parse((String) map.get("endTime"), format);
            activity.setEndTime(endTime.toDate());
            activity.setImplClass((String) map.get("implClass"));
            activity.setDescription((String) map.get("description"));
            activity.setTitle((String) map.get("title"));
            activity.setBackGroundId((String) map.get("backGroundId"));
            activity.setId(Long.parseLong(String.valueOf(map.get("id"))));
            jsonObject = NetWorkUtils.netGet(Constants.remoteUrl + "api/activity/" + map.get("id") + "/loadLoginRewardConfig");
            if (jsonObject != null) {
                Integer backGroundId = (Integer) ((Map<String, Object>) jsonObject.get("loginRewardConfig")).get("backgroundId");
                activity.setBackGroundId(backGroundId.toString());
            }

        }
        return activity;
    }

    /**
     * 获取活动奖励列表
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/getReward", method = RequestMethod.POST)
    @ResponseBody
    public List<LoginReward> getReward(Long id) {
        Activity activity = activityService.getById(id);
        if (activity.getImplClass().equals(LOGIN_SIGN)) {
            return loginRewardService.findByActivityId(id);
        }
        return null;
    }

    @RequestMapping(value = "/getRemoteReward", method = RequestMethod.POST)
    @ResponseBody
    public List<Map<String, Object>> getRemoteReward(Long id) {
        JSONObject jsonObject = NetWorkUtils.netGet(Constants.remoteUrl + "api/activity/" + id);
        if (jsonObject != null) {
            Map<String, Object> map = (Map<String, Object>) jsonObject.get("activity");
            if (map.get("implClass").equals(LOGIN_SIGN)) {
                jsonObject = NetWorkUtils.netGet(Constants.remoteUrl + "api/activity/" + id + "/loadLoginRewards");
                List<Map<String, Object>> mapList = new ArrayList<>();
                if (null != jsonObject) {
                    mapList = (List<Map<String, Object>>) jsonObject.get("loginRewardList");
                    if (null != mapList) {
                        return mapList;
                    }
                }
                return mapList;
            }
        }

        return null;
    }

    //保存活动奖励
    @RequestMapping(value = "/saveReward", method = RequestMethod.POST)
    @ResponseBody
    public List<LoginReward> saveReward(HttpServletRequest request, String data) {
        List<LoginReward> list = new ArrayList<>();
        Account account = this.getCurrentUser().getAccount();
        try {
            Map obj = mapper.readValue(data, Map.class);
            Long activityId = Long.parseLong((String) obj.get("activityId"));
            loginRewardService.deleteByActivityId(activityId);
            Activity activity = activityService.getById(activityId);
            if (activity.getImplClass().equals(LOGIN_SIGN)) {
                //持续登录
                List<String> rewardTypes = (List<String>) obj.get("rewardType");
                List<String> itemIds = (List<String>) obj.get("itemId");
                List<String> nums = (List<String>) obj.get("num");
                List<String> cdTimes = (List<String>) obj.get("cdTimes");
                List<String> backGroundIds = (List<String>)obj.get("backGroundId");
                int count = 0;
                int i = 0;
                int j = 0;
                for (String str : rewardTypes) {
                    LoginReward loginReward = new LoginReward();
                    int rewardType = Integer.parseInt(str);
                    loginReward.setActivityId(activityId);
                    loginReward.setSignCounts(count + 1);
                    loginReward.setRewardType(rewardType);
                    loginReward.setRewardId(Integer.parseInt(itemIds.get(count)));
                    String rewardCount = nums.get(count);
                    if (StringUtils.isEmpty(rewardCount)) {
                        loginReward.setRewardCounts(1);
                    } else {
                        loginReward.setRewardCounts(Integer.parseInt(rewardCount));
                    }
                    if (rewardType != 101 && rewardType != 102 && rewardType != 0) {
                        loginReward.setCdTimeType(Integer.parseInt(cdTimes.get(j)));
                        j++;
                    }
                    loginReward.setBackgroundId(backGroundIds.get(i));
                    loginRewardService.save(loginReward);
                    list.add(loginReward);
                    count++;
                    i++;
                }
                activity.setLastEditor(account.getId());
            }
            System.out.println(list);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    @RequestMapping(value = "/sendActivity", method = RequestMethod.POST)
    @ResponseBody
    public boolean sendActivity(Long id) {
        Activity activity = activityService.getById(id);
        List<LoginReward> loginRewardList = loginRewardService.findByActivityId(id);
        if (activity == null || loginRewardList == null) {
            return false;
        } else {
            List<Map<String, Object>> list = new ArrayList<>();
            for (LoginReward loginReward : loginRewardList) {
                list.add(loginReward.toMap());
            }
            activity.setObjList(list);
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject = NetWorkUtils.netPost(Constants.remoteUrl + "api/activity/activityPublish", JSON.toJSONString(activity));
            } catch (Exception ex) {
                return false;
            }

            if (jsonObject == null) {
                return false;
            } else {
                activity.setStatus(1);
                activityService.update(activity);
                Map<String, Object> map = (Map<String, Object>) jsonObject.get("activity");
                reloadData(map.get("id") + "");
            }

            return true;
        }
    }

    @RequestMapping(value = "/updateRemoteActivity", method = RequestMethod.POST)
    @ResponseBody
    public boolean updateRemoteActivity(HttpServletRequest request, String data) {
        try {
            Map obj = mapper.readValue(data, Map.class);
            int id = Integer.parseInt((String) obj.get("id"));
            NetWorkUtils.netPost(Constants.remoteUrl + "api/activity/" + id + "/activityUpdate", data);
            reloadData(id + "");
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * 通知所有游戏服务器重新加载活动配置
     */
    private void reloadData(String id) {
        String getUrl = Constants.remoteUrl + "/api/serverinfo/serverInfoList";
        Map<String, Object> mapObj = NetWorkUtils.doGet(getUrl);
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        if (null != mapObj) {
            if ("0".equals(mapObj.get("code") + "")) {
                if (null != mapObj.get("serverInfoList")) {
                    list = (List<Map<String, Object>>) mapObj.get("serverInfoList");
                    for (Map<String, Object> map : list) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("http://").append(map.get("ip")).append(":").append(map.get("port")).append("/gameServer/app/api/activity/").append(id).append("/reloadData");
                        NetWorkUtils.doGet(sb.toString());
                    }
                }
            }
        }
    }
}
