package net.gamedo.server.paradise.cms.echarts;

import java.util.List;

public class Axis {
	/**
	 * 坐标轴名称，默认为空
	 */
	public String name;
	/**
	 * 坐标轴类型，横轴默认为类目型'category'，纵轴默认为数值型'value'
	 */
	public String type;

	/**
	 * 显示策略，可选为：true（显示） | false（隐藏）
	 */
	public Boolean show = true;
	/**
	 * 类目型坐标轴文本标签数组，指定label内容。 数组项通常为文本，'\n'指定换行
	 * 当需要对个别标签进行个性化定义时，数组项可用对象，接受textStyle设置个性化标签
	 * 
	 */
	public List<Object> data;

	public Axis(String name, String type, List<Object> data) {
		this.name = name;
		this.type = type;
		this.data = data;
	}
}
