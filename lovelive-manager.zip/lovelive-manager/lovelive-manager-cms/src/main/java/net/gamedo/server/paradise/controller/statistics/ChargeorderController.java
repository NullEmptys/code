package net.gamedo.server.paradise.controller.statistics;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mysql.jdbc.StringUtils;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.thirdary.ChannelInfo;
import net.gamedo.server.paradise.model.fourth.player.Chargeorder;
import net.gamedo.server.paradise.model.thirdary.player.Item;
import net.gamedo.server.paradise.service.statistics.ChannelInfoService;
import net.gamedo.server.paradise.service.statistics.ChargeorderService;
import net.gamedo.server.paradise.service.statistics.PlayerPropertyService;

@Controller
@RequestMapping("/statistics/chargeorder")
public class ChargeorderController extends BaseController {
	@Autowired
	ChargeorderService chargeorderService;
	@Autowired
	private ChannelInfoService channelInfoService;
	@Autowired
	private PlayerPropertyService playerPropertyService;
	
	Map<String,String> channelInfoMap = null;
	Map<String,String> itemMap = null;
	
	@RequestMapping
	public String list(HttpServletRequest request, Model model) {
		initModel(request, model);
		// 全部渠道
		if(null==channelInfoMap){
			channelInfoMap = new HashMap<String,String>();
			List<ChannelInfo> channelInfoList = channelInfoService.getAll();
			for(ChannelInfo channelInfo : channelInfoList){
				channelInfoMap.put(channelInfo.getChannel_id()+"", channelInfo.getName());
			}
		}
		// 全部道具
		if(null==itemMap){
			itemMap = new HashMap<String,String>();
			List<Item> itemList = playerPropertyService.getAllItem();
			for(Item item : itemList){
				itemMap.put(item.getId()+"", item.getName());
			}
		}
		return "statistics/chargeorder/chargeorder_index";
	}
	
	// 充值记录列表
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody Page listForPage(String playerId, String channelId, String orderType, 
			String orderState, String startTime, String endTime, int currPage, int pageSize) {
		if(!StringUtils.isNullOrEmpty(playerId)){
			Map<String, Object> map = chargeorderService.getChargeorderList(playerId, channelId, orderType, orderState, startTime, endTime, currPage, pageSize);
			Long total = new Long(map.get("total")+"");
			List<Chargeorder> content = (List<Chargeorder>)map.get("content");
			for(Chargeorder chargeorder : content){
				chargeorder.setChannelName(channelInfoMap.get(chargeorder.getChannelId()));
				chargeorder.setGoodsName(itemMap.get(chargeorder.getGoodsId()+""));
			}
			Page page = new PageImpl<Chargeorder>(content, new PageRequest(currPage, pageSize), total);
//			Page page = chargeorderService.getPage(playerId, channelId, orderType, orderState, startTime, endTime,  currPage, pageSize);
			return page;
		} else {
			return null;
		}
	}
	
	// 统计充值金额
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/statistics", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> statistics(String playerId, String channelId, String orderType, 
			String orderState, String startTime, String endTime, int currPage, int pageSize) {
		Map<String, Object> papMap = new HashMap<String, Object>();
		double total = 0;
		if(!StringUtils.isNullOrEmpty(playerId)){
			Map<String, Object> map = chargeorderService.getChargeorderAllList(playerId, channelId, orderType, orderState, startTime, endTime);
			List<Chargeorder> content = (List<Chargeorder>)map.get("content");
			for(Chargeorder chargeorder : content){
				total += chargeorder.getPayPrice();
			}
			papMap.put("payPriceAll", (int)total);
		}
		return papMap;
	}
}
