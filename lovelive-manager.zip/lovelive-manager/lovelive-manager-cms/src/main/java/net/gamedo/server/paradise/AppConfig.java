package net.gamedo.server.paradise;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource(value = "classpath:scheduler.xml")
public class AppConfig {

}
