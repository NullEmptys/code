package net.gamedo.server.paradise.service.statistics;

import java.util.List;

import net.gamedo.server.paradise.model.provilage.Account;
import net.gamedo.server.paradise.repository.primary.provilage.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.primary.player.Activity;
import net.gamedo.server.paradise.repository.primary.ActivityRepository;
import net.gamedo.server.paradise.repository.primary.LoginRewardRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;

/**
 * Created by liuxing on 2016/04/20.
 */
@Service
public class ActivityService extends BaseService {
	@Autowired
	private ActivityRepository activityRepository;
	@Autowired
	private LoginRewardRepository loginRewardRepository;
	@Autowired
	private AccountRepository accountRepository;
	
	// 获取全部活动列表
	@Transactional(readOnly = true)
	public List<Activity> getAll() {
		return activityRepository.findAll();
	}
	
	// 根据Id获取活动
	@Transactional(readOnly = true)
	public Activity getById(Long id) {
		if (logger.isDebugEnabled()) {
			logger.debug("Returning activity with id: " + id);
		}
		Activity activity = activityRepository.findOneById(id);
		return activity;
	}
	
	// 新建活动
	public void create(Activity activity) {
		activityRepository.saveAndFlush(activity);
	}
	
	// 修改活动
	public void update(Activity activity) {
		activityRepository.save(activity);

		logger.debug("Updated activity " + activity);
	}
	
	// 分页查询
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional(readOnly = true)
	public CurrentPage getPage(int currPage, int pageSize) {
		int total = (int) activityRepository.count();
		CurrentPage page = getCurrentPage(total, currPage, pageSize, new CurrentPage<Activity>());
		List<Activity> pageItems = activityRepository.getPage(currPage* pageSize, pageSize);
		for (Activity activity:pageItems){
			if (activity.getPublisher() != null){
				Account account = accountRepository.findOneById(activity.getPublisher());
				if (account != null){
					activity.setPublishName(account.getEmail());
				}
			}
			if (activity.getLastEditor() != null){
				Account account = accountRepository.findOneById(activity.getLastEditor());
				if (account != null){
					activity.setLastEditorName(account.getEmail());
				}
			}
		}
		page.setPageItems(pageItems);
		return page;
	}
	
	// 根据Id删除活动
	public String delete(String id) {
		activityRepository.deleteById(Long.parseLong(id));
		loginRewardRepository.deleteByActivityId(Long.parseLong(id));
		return id;
	}
}
