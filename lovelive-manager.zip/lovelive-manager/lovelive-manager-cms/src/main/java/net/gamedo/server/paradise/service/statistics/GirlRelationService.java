package net.gamedo.server.paradise.service.statistics;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.github.sd4324530.fastweixin.api.enums.ResultType;
import com.github.sd4324530.fastweixin.api.response.BaseResponse;
import com.github.sd4324530.fastweixin.util.JSONUtil;
import com.github.sd4324530.fastweixin.util.NetWorkCenter;

import net.gamedo.server.paradise.cms.Constants;
import net.gamedo.server.paradise.service.provilage.BaseService;
import net.gamedo.server.paradise.utils.NetWorkUtils;

/**
 * Created by Administrator on 2016.3.22
 */
@Service
public class GirlRelationService extends BaseService {

	// 模特关系列表
	@SuppressWarnings({ "rawtypes" })
	@Transactional(readOnly = true)
	public List<Map<String, Object>> getPage(String id) {
		List<Map<String, Object>> girlRelationLists = new ArrayList<Map<String, Object>>();
		if (null != id && !id.equals("")) {
			String url = Constants.remoteUrl + "api/playerGirl/" + id;
			Map<String, Object> girlItem = NetWorkUtils.doGet(url);
			if (null != girlItem) {
				List<Map<String, Object>> playerGirlList = (List<Map<String, Object>>) girlItem.get("playerGirlList");
				if (playerGirlList.size() > 0) {
					for (Map<String, Object> map : playerGirlList) {
						girlRelationLists.add(map);
					}
				}
			}
		}
		return girlRelationLists;
	}

	// 模特关系修改
	public String update(String playerId, String data) {
		JSONObject o = JSONObject.parseObject(data);
		Date date = new Date();
		String time;
		if (null != o.get("cdTimes") && !o.get("cdTimes").toString().equals("")) {
			time = o.get("cdTimes").toString();
		} else {
			try {
				date = (new SimpleDateFormat("yyyy/MM/dd HH:mm:ss")).parse(o.get("cdTime") + "");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			time = date.getTime() + "";
		}
		String postUrl = Constants.remoteUrl + "api/playerGirl/update";
		Map<String, Object> map = new HashMap<>();
		map.put("playerId", Long.parseLong(playerId));
		map.put("girlId", Long.parseLong(o.get("girlId").toString()));
		map.put("cdTime", time);
		map.put("level", Long.parseLong(o.get("level").toString()));
		Map<String, Object> mapObj = NetWorkUtils.doPost(postUrl, map);
		return null == mapObj ? "1" : mapObj.get("code").toString();
	}
	
	// 从String类型的Json数据中获取对应key的值
	private static String getValueToJson(String key, String json) {
		JSONObject o = JSONObject.parseObject(json);
		return o.get(key) == null ? null : o.get(key).toString();
	}

}
