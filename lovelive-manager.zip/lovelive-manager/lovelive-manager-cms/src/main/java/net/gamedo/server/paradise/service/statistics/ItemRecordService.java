package net.gamedo.server.paradise.service.statistics;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import net.gamedo.server.paradise.model.secondary.ItemRecord;
import net.gamedo.server.paradise.repository.secondary.ItemRecordRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;

@Service
public class ItemRecordService extends BaseService {
	@Autowired
	private ItemRecordRepository itemRecordRepository;

	// 获取道具获取及消耗的列表
	//@TargetDataSource(name = "ds1")
	public Page getItemRecordList(String id, String type, String startDate, String endDate, int currPage,
			int pageSize) {
		List<ItemRecord> pageItems = new ArrayList<ItemRecord>();
		Map<String, Object>	papMap = itemRecordRepository.getItemRecords(id, type, startDate, endDate, currPage, pageSize);
		Long total = new Long(papMap.get("total")+"");
		List<ItemRecord> content = (List<ItemRecord>)papMap.get("content");
		Page page = new PageImpl<ItemRecord>(content, new PageRequest(currPage, pageSize), total);
//		Page page = chargeorderService.getPage(playerId, channelId, orderType, orderState, startTime, endTime,  currPage, pageSize);
		return page;
	}

}
