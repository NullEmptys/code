package net.gamedo.server.paradise.controller.auth;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.acls.domain.DefaultPermissionFactory;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.domain.PermissionFactory;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.model.AccessControlEntry;
import org.springframework.security.acls.model.Acl;
import org.springframework.security.acls.model.AclService;
import org.springframework.security.acls.model.Permission;
import org.springframework.security.acls.model.Sid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.provilage.Sysmenu;
import net.gamedo.server.paradise.model.provilage.Sysmodel;
import net.gamedo.server.paradise.model.provilage.Syspage;
import net.gamedo.server.paradise.service.provilage.AccountService;
import net.gamedo.server.paradise.service.provilage.SysmenuService;
import net.gamedo.server.paradise.service.provilage.SysmodelService;
import net.gamedo.server.paradise.service.provilage.SyspageService;

@Controller
@RequestMapping("/auth/page")
@SessionAttributes("addPermission")
public final class AuthSyspageController extends BaseController {
	@Autowired
	private AclService aclService;
	@Autowired
	private AccountService accountService;
	@Autowired
	private SyspageService syspageService;
	@Autowired
	private SysmodelService sysmodelService;
	@Autowired
	private SysmenuService sysmenuService;

	private final PermissionFactory permissionFactory = new DefaultPermissionFactory();

	@RequestMapping
	public String list(HttpServletRequest request, Model model) {
		initModel(request, model);
		model.addAttribute("recipients", listRecipients());
		model.addAttribute("permissions", listPermissions());
		return "auth/page/page_index";
	}

	/**
	 * 分页查询
	 * 
	 * @param request
	 * @param currPage
	 *            当前页
	 * @param perPage
	 * @param search
	 *            查询参数
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody CurrentPage listForPage(Long currId, int currPage, int pageSize, String search) {
		if (null == currId)
			return null;
		try {
			ObjectIdentityImpl objectIdentity = null;
			// 大于1000为model按钮权限
			if (currId > 1000 && currId < 10000) {
				Sysmodel sysmodel = sysmodelService.getById(currId - 1000);
				objectIdentity = new ObjectIdentityImpl(sysmodel);
			} else if (currId > 10000) {
				Sysmenu sysmenu = sysmenuService.getById(currId - 10000);
				objectIdentity = new ObjectIdentityImpl(sysmenu);
			} else {
				Syspage syspage = syspageService.getById(currId);
				objectIdentity = new ObjectIdentityImpl(syspage);
			}

			Acl acl = aclService.readAclById(objectIdentity);
			List<AccessControlEntry> aces = acl.getEntries();
			CurrentPage<Map<String, Object>> page = new CurrentPage<Map<String, Object>>();
			if (null != aces && aces.size() >= 1) {
				int total = aces.size();
				int pageCount = total / pageSize;
				if (total > pageSize * pageCount) {
					pageCount++;
				}
				page.setCurrPage(currPage);
				page.setPageCount(pageCount);
				page.setTotal(total);

				List<Map<String, Object>> pageItems = new ArrayList<Map<String, Object>>();
				for (int i = (currPage - 1) * pageSize; i < Math.min(currPage * pageSize, total); i++) {
					AccessControlEntry ace = aces.get(i);
					if (null != ace) {
						Map<String, Object> pageItem = new HashMap<String, Object>();
						pageItem.put("id", ace.getId());
						pageItem.put("name", ((PrincipalSid) ace.getSid()).getPrincipal());
						pageItem.put("mask", ace.getPermission().getMask());
						pageItems.add(pageItem);
					}
				}
				page.setPageItems(pageItems);
			}
			return page;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 处理获取子节点的请求:for tree
	 * 
	 * @param request
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/getForTree", method = RequestMethod.POST)
	public @ResponseBody List<Syspage> getForTree(HttpServletRequest request, Long id) {
		if (null == id || id == 0L) {
			id = -1L;
		}
		List<Syspage> syspages = syspageService.getAll();
		Syspage.sortSyspagesForTree(syspages);
		return syspages;
	}

	/**
	 * 保存 修改
	 *
	 * @param request
	 * @param data
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody void save(Long id, String recipient, String mask) {
		try {
			PrincipalSid sid = new PrincipalSid(recipient);
			Permission permission = permissionFactory.buildFromMask(Integer.valueOf(mask));

			// 大于1000为model按钮权限
			if (id > 1000 && id < 10000) {
				syspageService.addPermission(Sysmodel.class, id - 1000, sid, permission);
			} else if (id > 10000) {
				// 大于10000为菜单权限
				syspageService.addPermission(Sysmenu.class, id - 10000, sid, permission);
			} else {
				syspageService.addPermission(Syspage.class, id, sid, permission);
			}

		} catch (DataAccessException existingPermission) {
			existingPermission.printStackTrace();
		}
	}

	/**
	 * 根据ids删除
	 *
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/del", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> del(Long id, String recipient, Integer mask) {
		Sid sidObject = new PrincipalSid(recipient);
		Permission permission = permissionFactory.buildFromMask(mask);
		// 大于1000为model按钮权限
		if (id > 1000 && id < 10000) {
			syspageService.deletePermission(Sysmodel.class, id - 1000, sidObject, permission);
		} else if (id > 10000) {
			// 大于10000为菜单权限
			syspageService.deletePermission(Sysmenu.class, id - 10000, sidObject, permission);
		} else {
			syspageService.deletePermission(Syspage.class, id, sidObject, permission);
		}
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("num", 1);
		return map;
	}

	private Map<String, String> listRecipients() {
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("", "-- 请选择 --");
		List<String> recipients = accountService.getAllRecipients();
		for (String recipient : recipients) {
			map.put(recipient, recipient);
		}

		return map;
	}

}
