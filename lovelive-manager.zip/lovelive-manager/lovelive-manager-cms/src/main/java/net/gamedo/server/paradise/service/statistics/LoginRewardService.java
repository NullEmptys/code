package net.gamedo.server.paradise.service.statistics;

import net.gamedo.server.paradise.model.primary.player.LoginReward;
import net.gamedo.server.paradise.repository.primary.LoginRewardRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Administrator on 2016/4/22 0022.
 */
@Service
public class LoginRewardService extends BaseService {
    @Autowired
    private LoginRewardRepository loginRewardRepository;

    public List<LoginReward> findByActivityId(Long activityId) {
        return loginRewardRepository.findByActivityId(activityId);
    }

    public void deleteByActivityId(Long activityId) {
        loginRewardRepository.deleteByActivityId(activityId);
    }

    public LoginReward save(LoginReward loginReward) {
        return loginRewardRepository.save(loginReward);
    }
}
