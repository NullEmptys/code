package net.gamedo.server.paradise.service.statistics;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.gamedo.server.paradise.repository.secondary.MoneyUseRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;

@Service
public class MoneyUseService extends BaseService {
	@Autowired
	private MoneyUseRepository moneyUseRepository;

	// 分页数据
	//@TargetDataSource(name = "ds1")
	public Map<String, Object> getMoneyUseList(String playerId, String type, String currencyType, 
			String startTime, String endTime, int currPage, int pageSize) {
		Map<String, Object> map = moneyUseRepository.getMoneyUses(playerId, type, currencyType, startTime, endTime, currPage, pageSize);
		return map;
	}
	
	// 全部数据
	//@TargetDataSource(name = "ds1")
	public Map<String, Object> getMoneyUseListAll(String playerId, String type, String currencyType, 
			String startTime, String endTime, int currPage, int pageSize) {
		Map<String, Object> map = moneyUseRepository.getMoneyUsesAll(playerId, type, currencyType, startTime, endTime, currPage, pageSize);
		return map;
	}
	
}
