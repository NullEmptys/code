package net.gamedo.server.paradise.controller.statistics;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.service.statistics.GirlRelationService;

@Controller
@RequestMapping("/statistics/girlrelation")
public class GirlRelationController extends BaseController {
	@Autowired
	private GirlRelationService girlRelationService;

	@RequestMapping
	public String list(HttpServletRequest request, Model model) {
		initModel(request, model);
		return "statistics/girlrelation/girlrelation_index";
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> listForPage(String id) {
		List<Map<String, Object>> list = girlRelationService.getPage(id);
		return list;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	@ResponseBody
	public String save(HttpServletRequest request, String playerId, String data) {
		return girlRelationService.update(playerId, data);
	}

}
