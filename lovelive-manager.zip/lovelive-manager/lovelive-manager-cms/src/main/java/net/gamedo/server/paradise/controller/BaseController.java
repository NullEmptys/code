package net.gamedo.server.paradise.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.model.AclService;
import org.springframework.security.acls.model.Permission;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.fasterxml.jackson.databind.ObjectMapper;

import net.gamedo.server.paradise.cms.service.SecurityUser;
import net.gamedo.server.paradise.model.provilage.Sysmenu;
import net.gamedo.server.paradise.model.provilage.Sysmodel;
import net.gamedo.server.paradise.model.provilage.Syspage;
import net.gamedo.server.paradise.service.provilage.SysmenuService;

public class BaseController {

	private final static Permission[] HAS_READ = new Permission[] { BasePermission.READ, BasePermission.DELETE,
			BasePermission.CREATE, BasePermission.WRITE, BasePermission.ADMINISTRATION };
	private final static Permission[] HAS_DELETE = new Permission[] { BasePermission.DELETE,
			BasePermission.ADMINISTRATION };
	private final static Permission[] HAS_ADMIN = new Permission[] { BasePermission.ADMINISTRATION };

	@Autowired
	SessionRegistry sessionRegistry;

	@Autowired
	AclService aclService;

	@Autowired
	PermissionEvaluator permissionEvaluator;

	@Autowired
	SysmenuService sysmenuService;

	protected ObjectMapper mapper = new ObjectMapper().setDateFormat(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"));;

	/**
	 * jsVersion
	 * 
	 * @return
	 */
	@ModelAttribute("jsVersion")
	public String getJsVersion() {
		return "1.0";
	}

	/**
	 * 在线用户数
	 * 
	 * @return
	 */
	@ModelAttribute("currentUser")
	public SecurityUser getCurrentUser() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof SecurityUser) {
			SecurityUser securityUser = (SecurityUser) principal;
			Authentication user = SecurityContextHolder.getContext().getAuthentication();

			// TODO: 改成根据权限获取对应的menu
			// email只有是admin的时候才能是systems的page
			String email = securityUser.getAccount().getEmail();
			if (null == securityUser.getSysmenus()) {
				List<Sysmenu> sysmenus = sysmenuService.getAll();
				if (null != sysmenus) {
					Map<String, Syspage> uris = new HashMap<String, Syspage>();
					List<Sysmenu> sysmenusDel = new ArrayList<Sysmenu>();
					for (Sysmenu sysmenu : sysmenus) {
						Syspage.sortSyspages(sysmenu.getSyspages());
						// 去掉没权限的
						if (!permissionEvaluator.hasPermission(user, sysmenu, HAS_READ)||(!email.equalsIgnoreCase("admin")&&sysmenu.getPage().equalsIgnoreCase("systems")))
							sysmenusDel.add(sysmenu);
						else {
							List<Syspage> syspages = sysmenu.getSyspages();
							if (null != syspages) {
								List<Syspage> syspagesDel = new ArrayList<Syspage>();
								for (Syspage syspage : syspages) {
									if (!permissionEvaluator.hasPermission(user, syspage, HAS_READ)||(!email.equalsIgnoreCase("admin")&&syspage.getPage().equalsIgnoreCase("systems")))
										syspagesDel.add(syspage);
									else {
										List<Syspage> subsyspages = syspage.getSubsyspages();
										if (null != subsyspages) {
											List<Syspage> subsyspagesDel = new ArrayList<Syspage>();
											for (Syspage subsyspage : subsyspages) {
												if (!permissionEvaluator.hasPermission(user, subsyspage, HAS_READ))
													subsyspagesDel.add(subsyspage);
												else {
													if (permissionEvaluator.hasPermission(user, subsyspage,
															BasePermission.ADMINISTRATION))
														subsyspage.setMask(BasePermission.ADMINISTRATION.getMask());
													else if (permissionEvaluator.hasPermission(user, subsyspage,
															BasePermission.DELETE))
														subsyspage.setMask(BasePermission.DELETE.getMask());
													else if (permissionEvaluator.hasPermission(user, subsyspage,
															BasePermission.CREATE))
														subsyspage.setMask(BasePermission.CREATE.getMask());
													else if (permissionEvaluator.hasPermission(user, subsyspage,
															BasePermission.WRITE))
														subsyspage.setMask(BasePermission.WRITE.getMask());
													else
														subsyspage.setMask(BasePermission.READ.getMask());
													subsyspage.setParent_syspage(syspage);
													uris.put(subsyspage.getUrl(), subsyspage);
													// model按钮权限
													List<Sysmodel> sysmodelsDel = new ArrayList<Sysmodel>();
													List<Sysmodel> sysmodels = subsyspage.getSysmodels();
													if (null != sysmodels && sysmodels.size() >= 1) {
														for (Sysmodel sysmodel : sysmodels) {
															if (!permissionEvaluator.hasPermission(user, sysmodel,
																	HAS_READ)) {
																sysmodelsDel.add(sysmodel);
															}
														}
													}
													sysmodels.removeAll(sysmodelsDel);
												}
											}
											subsyspages.removeAll(subsyspagesDel);
										}
									}
								}
								syspages.removeAll(syspagesDel);
							}
						}
					}
					sysmenus.removeAll(sysmenusDel);
					securityUser.setSysmenus(sysmenus);
					securityUser.setUris(uris);
				}
			}
			return securityUser;
		}
		return null;
	}

	/**
	 * 在线用户数
	 * 
	 * @return
	 */
	@ModelAttribute("numUsers")
	public int getNumberOfUsers() {
		return sessionRegistry.getAllPrincipals().size();
	}

	/**
	 * 在线用户列表
	 * 
	 * @return
	 */
	@ModelAttribute("activeUsers")
	public Map<Object, Date> getActiveUsers() {
		Map<Object, Date> lastActivityDates = new HashMap<Object, Date>();
		for (Object principal : sessionRegistry.getAllPrincipals()) {
			// a principal may have multiple active sessions
			for (SessionInformation session : sessionRegistry.getAllSessions(principal, false)) {
				// no last activity stored
				if (lastActivityDates.get(principal) == null) {
					lastActivityDates.put(principal, session.getLastRequest());
				} else {
					// check to see if this session is newer than the last
					// stored
					Date prevLastRequest = lastActivityDates.get(principal);
					if (session.getLastRequest().after(prevLastRequest)) {
						// update if so
						lastActivityDates.put(principal, session.getLastRequest());
					}
				}
			}
		}
		return lastActivityDates;
	}

	protected Map<Integer, String> listPermissions() {
		Map<Integer, String> map = new LinkedHashMap<Integer, String>();
		map.put(Integer.valueOf(BasePermission.ADMINISTRATION.getMask()), "Administer");
		map.put(Integer.valueOf(BasePermission.DELETE.getMask()), "Delete");
		map.put(Integer.valueOf(BasePermission.CREATE.getMask()), "Create");
		map.put(Integer.valueOf(BasePermission.WRITE.getMask()), "Write");
		map.put(Integer.valueOf(BasePermission.READ.getMask()), "Read");

		return map;
	}

	protected void initModel(HttpServletRequest request, Model model) {
		SecurityUser currentUser = (SecurityUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String uri = request.getRequestURI();
		Syspage syspage = currentUser.getSyspage(uri);

		model.addAttribute("page", syspage.getSysmenu().getPage());
		model.addAttribute("ppage", syspage.getParent_syspage().getPage());
		model.addAttribute("subpage", syspage.getPage());

		model.addAttribute("syspage", syspage);

		model.addAttribute("pageName", syspage.getSysmenu().getName());
		model.addAttribute("ppageName", syspage.getParent_syspage().getName());
		model.addAttribute("subpageName", syspage.getName());
	}

}
