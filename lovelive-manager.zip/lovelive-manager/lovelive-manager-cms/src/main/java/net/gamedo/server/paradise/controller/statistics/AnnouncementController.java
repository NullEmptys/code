package net.gamedo.server.paradise.controller.statistics;

import java.io.*;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.sun.el.parser.ParseException;

import net.gamedo.server.paradise.repository.primary.provilage.AccountRepository;
import net.gamedo.server.paradise.cms.service.SecurityUser;
import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.primary.player.Announcement;
import net.gamedo.server.paradise.service.statistics.AnnouncementService;

/**
 * Created by Administrator on 2016/4/22 0022.
 */
@Controller
@RequestMapping("/statistics/announcement")
public class AnnouncementController extends BaseController {
	@Autowired
	private AnnouncementService announcementService;

	@Autowired
	private AccountRepository accountRepository;

	@RequestMapping
	public String index(HttpServletRequest request, Model model) {
		initModel(request, model);
		return "statistics/announcement/announcement_index";
	}

	/**
	 * 分页查询
	 *
	 * @param request
	 * @param currPage
	 *            当前页
	 * @param perPage
	 * @param search
	 *            查询参数
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody CurrentPage listForPage(int currPage, int pageSize) {
		return announcementService.getPage(currPage, pageSize);
	}

	/**
	 * 保存 修改公告
	 *
	 * @param request
	 * @param data
	 * @return @
	 * @throws ParseException
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody void save(HttpServletRequest request, String data){
		try {
			SecurityUser securityUser = getCurrentUser();
			Long userId = securityUser.getAccount().getId();
			JSONObject o = JSONObject.parseObject(data);
			if ("".equals(o.get("id"))) { // 新增
				announcementService.create(data, userId);
			} else { // 修改更新
				announcementService.update(data, userId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 根据id删除公告
	 *
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/del", method = RequestMethod.POST)
	public @ResponseBody int del(String id) {
		return announcementService.delete(id);
	}

	/**
	 * 根据id获取公告
	 *
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/get", method = RequestMethod.POST)
	public @ResponseBody Announcement get(Long id) {
		Announcement announcement = announcementService.getById(id);
		return announcement;
	}
	
	/**
	 * 获取全部数据
	 *
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/getAll", method = RequestMethod.POST)
	public @ResponseBody List<Announcement> getAll() {
		List<Announcement> announcementList = announcementService.getAll();
		return announcementList;
	}

	/**
	 * 发送公告到线上
	 *
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/send", method = RequestMethod.POST)
	public @ResponseBody int send(String data) {
		return announcementService.send(data);
	}
	
	
	/**
	 * 线下公告历史导出
	 */
	@RequestMapping(value = "/down", method = RequestMethod.GET)
	public void down(HttpServletResponse response) {
		Workbook workbook = announcementService.down();
		response.setContentType("application/x-msdownload");
		response.setHeader("Content-Disposition", "attachment;filename=announce.xls");
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		ServletOutputStream out = null;
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		try {
			workbook.write(os);
			byte[] content = os.toByteArray();
			InputStream is = new ByteArrayInputStream(content);
			out = response.getOutputStream();
			bis = new BufferedInputStream(is);
			bos = new BufferedOutputStream(out);
			byte[] buff = new byte[2048];
			int bytesRead;
			// Simple read/write loop.
			while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
				bos.write(buff, 0, bytesRead);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if (bis != null)
				try {
					bis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			if (bos != null)
				try {
					bos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}

	// 线上数据的分页显示
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage_server", method = RequestMethod.POST)
	public @ResponseBody CurrentPage listForPage_server(int currPage, int pageSize) {
		return announcementService.getPage_server(currPage, pageSize);
	}

	// 线上数据的删除
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/del_server", method = RequestMethod.POST)
	public @ResponseBody int del_server(int id) {
		return announcementService.del_server(id);
	}
	
	// 获取单个线上公告
	@RequestMapping(value = "/get_server", method = RequestMethod.POST)
	public @ResponseBody Announcement get_server(Long id) {
		Announcement announcement = new Announcement();
		try {
			announcement = announcementService.getById_server(id);
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return announcement;
	}
	
	// 修改线上公告
	@RequestMapping(value = "/save_server", method = RequestMethod.POST)
	public @ResponseBody int save_server(String data) {
		return announcementService.save_server(data);
	}


}
