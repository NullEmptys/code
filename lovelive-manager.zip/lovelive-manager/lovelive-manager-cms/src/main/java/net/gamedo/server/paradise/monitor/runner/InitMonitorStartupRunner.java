package net.gamedo.server.paradise.monitor.runner;

import net.gamedo.server.paradise.model.primary.monitor.ApplicationInstance;
import net.gamedo.server.paradise.service.statistics.ApplicationInstanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by Administrator on 2016/4/14 0014.
 */
@Component
@Order(value = 2)
public class InitMonitorStartupRunner implements CommandLineRunner {
    @Autowired
    private ApplicationInstanceService applicationinstanceService;

    @Override
    public void run(String... args) throws Exception {
        this.startMonitor();
    }

    private void startMonitor() {
        List<ApplicationInstance> list = applicationinstanceService.getAll();
        for (ApplicationInstance applicationInstance : list) {
            if (applicationInstance.getEnabled() == 1){
                applicationinstanceService.enableApplicationInstance(applicationInstance.getId());
            }
        }
    }
}
