package net.gamedo.server.paradise.controller.statistics;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import net.gamedo.server.paradise.service.statistics.ChannelInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.thirdary.ChannelInfo;

/**
 * Created by liuxing on 2016/04/11.
 */
@Controller
@RequestMapping("/statistics/channelInfo")
public final class ChannelInfoController extends BaseController {

    @Autowired
    private ChannelInfoService channelinfoService;

    @RequestMapping
    public String list(HttpServletRequest request, Model model) {
        initModel(request, model);

        return "statistics/channelinfo/channelinfo_index";
    }

    /**
     * 分页查询
     *
     * @param currPage 当前页
     * @param pageSize
     * @param search   查询参数
     * @return
     */
    @SuppressWarnings("rawtypes")
    @RequestMapping(value = "/listForPage", method = RequestMethod.POST)
    public
    @ResponseBody
    Page listForPage(int currPage, int pageSize, String search) {
        return channelinfoService.getPage(currPage, pageSize, search);
    }

    /**
     * 保存 修改菜单
     *
     * @param request
     * @param data
     * @return @
     */
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public
    @ResponseBody
    ChannelInfo save(HttpServletRequest request, String data) {
        try {
            ChannelInfo obj = mapper.readValue(data, ChannelInfo.class);
            if (null == obj.getId()) { // 新增
                channelinfoService.create(obj);
            } else { // 修改更新
                channelinfoService.update(obj);
            }

            return obj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 根据ids删除菜单
     *
     * @param ids
     * @return
     */
    @RequestMapping(value = "/del", method = RequestMethod.POST)
    public
    @ResponseBody
    Map<String, Object> del(String ids) {
        return channelinfoService.delete(ids);
    }

    /**
     * 根据id获取菜单
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/get", method = RequestMethod.POST)
    public
    @ResponseBody
    ChannelInfo get(Long id) {
        return channelinfoService.getById(id);
    }

    @RequestMapping(value = "/getAll", method = RequestMethod.POST)
    public @ResponseBody
    List<ChannelInfo> getAll() {
        return channelinfoService.getAll();
    }

}
