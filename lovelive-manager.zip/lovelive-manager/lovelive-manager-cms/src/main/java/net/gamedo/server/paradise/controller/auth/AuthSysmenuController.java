package net.gamedo.server.paradise.controller.auth;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.dao.DataAccessException;
import org.springframework.security.acls.domain.DefaultPermissionFactory;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.domain.PermissionFactory;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.model.AccessControlEntry;
import org.springframework.security.acls.model.Acl;
import org.springframework.security.acls.model.AclService;
import org.springframework.security.acls.model.Permission;
import org.springframework.security.acls.model.Sid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import net.gamedo.server.paradise.acl.AddPermissionValidator;
import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.provilage.Sysmenu;
import net.gamedo.server.paradise.service.provilage.AccountService;
import net.gamedo.server.paradise.service.provilage.SysmenuService;

@Controller
@RequestMapping("/auth/menu")
@SessionAttributes("addPermission")
public final class AuthSysmenuController extends BaseController {
	@Autowired
	private AclService aclService;
	@Autowired
	private AccountService accountService;
	@Autowired
	private SysmenuService sysmenuService;

	private MessageSourceAccessor messages;
	private final Validator addPermissionValidator = new AddPermissionValidator();
	private final PermissionFactory permissionFactory = new DefaultPermissionFactory();

	@RequestMapping
	public String list(HttpServletRequest request, Model model) {
		initModel(request, model);

		model.addAttribute("recipients", listRecipients());
		model.addAttribute("permissions", listPermissions());

		return "auth/menu/menu_index";
	}

	/**
	 * 分页查询
	 * 
	 * @param request
	 * @param currPage
	 *            当前页
	 * @param perPage
	 * @param search
	 *            查询参数
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody CurrentPage listForPage(Long currId, int currPage, int pageSize, String search) {
		if (null == currId)
			return null;
		try {
			Sysmenu sysmenu = sysmenuService.getById(currId);
			Acl acl = aclService.readAclById(new ObjectIdentityImpl(sysmenu));
			List<AccessControlEntry> aces = acl.getEntries();
			CurrentPage<Map<String, Object>> page = new CurrentPage<Map<String, Object>>();
			if (null != aces && aces.size() >= 1) {
				int total = aces.size();
				int pageCount = total / pageSize;
				if (total > pageSize * pageCount) {
					pageCount++;
				}
				page.setCurrPage(currPage);
				page.setPageCount(pageCount);
				page.setTotal(total);

				List<Map<String, Object>> pageItems = new ArrayList<Map<String, Object>>();
				for (int i = (currPage - 1) * pageSize; i < Math.min(currPage * pageSize, total); i++) {
					AccessControlEntry ace = aces.get(i);
					if (null != ace) {
						Map<String, Object> pageItem = new HashMap<String, Object>();
						pageItem.put("id", ace.getId());
						pageItem.put("name", ((PrincipalSid) ace.getSid()).getPrincipal());
						pageItem.put("mask", ace.getPermission().getMask());
						pageItems.add(pageItem);
					}
				}
				page.setPageItems(pageItems);
			}
			return page;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		// return accountService.getPage(currPage, pageSize, search);
	}

	/**
	 * 处理获取子节点的请求:for tree
	 * 
	 * @param request
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/getForTree", method = RequestMethod.POST)
	public @ResponseBody List<Sysmenu> getForTree(HttpServletRequest request, Long id) {
		if (null == id || id == 0L) {
			id = -1L;
		}
		return sysmenuService.getAll();
	}

	/**
	 * 保存 修改菜单
	 *
	 * @param request
	 * @param data
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody void save(Long id, String recipient, String mask) {
		try {
			PrincipalSid sid = new PrincipalSid(recipient);
			Permission permission = permissionFactory.buildFromMask(Integer.valueOf(mask));

			sysmenuService.addPermission(Sysmenu.class, id, sid, permission);
		} catch (DataAccessException existingPermission) {
			existingPermission.printStackTrace();
		}
	}

	/**
	 * 根据ids删除菜单
	 *
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/del", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> del(Long id, String recipient, Integer mask) {
		Sid sidObject = new PrincipalSid(recipient);
		Permission permission = permissionFactory.buildFromMask(mask);

		sysmenuService.deletePermission(Sysmenu.class, id, sidObject, permission);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("num", 1);
		return map;
	}

	private Map<String, String> listRecipients() {
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("", "-- 请选择 --");
		List<String> recipients = accountService.getAllRecipients();
		for (String recipient : recipients) {
			map.put(recipient, recipient);
		}

		return map;
	}

}
