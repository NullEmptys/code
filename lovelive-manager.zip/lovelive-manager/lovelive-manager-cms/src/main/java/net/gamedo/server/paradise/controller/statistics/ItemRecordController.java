package net.gamedo.server.paradise.controller.statistics;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.service.statistics.ItemRecordService;

@Controller
@RequestMapping("/statistics/itemRecord")
public class ItemRecordController extends BaseController {
	@Autowired
	ItemRecordService itemRecordService;
	
	@RequestMapping
	public String list(HttpServletRequest request, Model model) {
		initModel(request, model);
		return "statistics/itemRecord/itemRecord_index";
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody Page listForPage(String id, String type, String startDate, String endDate,  int currPage, int pageSize) {
		if(null != id && !"".equals(id)){
			Page page = itemRecordService.getItemRecordList(id, type, startDate, endDate,  currPage, pageSize);
			return page;
		} else {
			return null;
		}
		
	}
	
}
