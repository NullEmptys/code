package net.gamedo.server.paradise.cms.echarts;

import java.util.ArrayList;
import java.util.List;

public class Echarts {
	public List<String> legend = new ArrayList<String>();// 数据分组
	public Axis xAxis = new Axis("", "category", null);// 横坐标
	public Axis yAxis = new Axis("", "value", null);// 纵坐标
	public List<Series> series = new ArrayList<Series>();

	public Echarts(List<String> legendList, List<Object> xAxisData, List<Series> seriesList) {
		super();
		this.legend = legendList;
		this.xAxis.data = xAxisData;
		this.series = seriesList;
	}
}
