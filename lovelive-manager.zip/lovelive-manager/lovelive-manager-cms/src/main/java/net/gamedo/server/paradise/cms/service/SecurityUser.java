package net.gamedo.server.paradise.cms.service;

import java.util.List;
import java.util.Map;

import net.gamedo.server.paradise.model.provilage.Account;
import net.gamedo.server.paradise.model.provilage.Sysmenu;
import net.gamedo.server.paradise.model.provilage.Syspage;

public class SecurityUser extends org.springframework.security.core.userdetails.User {

	/**
	 * 
	 */
	private static final long serialVersionUID = -787243548359384608L;

	private final Account account;

	private List<Sysmenu> sysmenus = null;

	private Map<String, Syspage> uris = null;

	public SecurityUser(Account account) {
		super(account.getEmail(), account.getPassword(), account.getAuthorities());
		this.account = account;
	}

	public Account getAccount() {
		return account;
	}

	public List<Sysmenu> getSysmenus() {
		return sysmenus;
	}

	public void setSysmenus(List<Sysmenu> sysmenus) {
		this.sysmenus = sysmenus;
	}

	public boolean isAdmin() {
		return getAccount().isAdmin();
	}

	public Map<String, Syspage> getUris() {
		return uris;
	}

	public void setUris(Map<String, Syspage> uris) {
		this.uris = uris;
	}

	public boolean checkUri(String uri) {
		if (null == uris)
			return false;
		return null != uris.get(uri);
	}

	public Syspage getSyspage(String uri) {
		return uris.get(uri);
	}

}
