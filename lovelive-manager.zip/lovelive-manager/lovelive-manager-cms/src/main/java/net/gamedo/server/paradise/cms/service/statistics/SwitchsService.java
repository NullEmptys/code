package net.gamedo.server.paradise.cms.service.statistics;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysql.jdbc.StringUtils;

import net.gamedo.server.paradise.model.thirdary.ChannelInfo;
import net.gamedo.server.paradise.model.primary.Switchs;
import net.gamedo.server.paradise.repository.thirdary.ChannelInfoRepository;
import net.gamedo.server.paradise.repository.primary.SwitchsRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;

@Service
public class SwitchsService extends BaseService {
	@Autowired
	private SwitchsRepository switchsRepository;

	@Autowired
	private ChannelInfoRepository channelInfoRepository;

	public void create(Switchs switchs) {
		// Create the Switchs itself
		switchsRepository.save(switchs);
	}

	@Transactional(readOnly = true)
	public Switchs getById(Long id) {
		if (logger.isDebugEnabled()) {
			logger.debug("Returning switchs with id: " + id);
		}

		return switchsRepository.findOne(id);
	}

	public void update(Switchs switchs) {
		switchsRepository.save(switchs);

		logger.debug("Updated switchs " + switchs);
	}

	@SuppressWarnings({ "rawtypes" })
	@Transactional(readOnly = true)
	public Page getPage(int currPage, int pageSize, String search, Long channel_id) {

		PageRequest pageRequest = new PageRequest(currPage, pageSize);
		Page<Switchs> page = null;
		if (StringUtils.isNullOrEmpty(search)) {
			if (null == channel_id)
				page = switchsRepository.getPage(pageRequest);
			else
				page = switchsRepository.getPage(channel_id, pageRequest);
		} else {
			if (null == channel_id)
				page = switchsRepository.getPage(search, pageRequest);
			else
				page = switchsRepository.getPage(search, channel_id, pageRequest);
		}
		if (null != page) {
			List<Switchs> pageItems = page.getContent();
			if (null != pageItems && pageItems.size() >= 1) {
				List<ChannelInfo> channelInfos = channelInfoRepository.findAll();

				Map<Long, String> channelsMap = new HashMap<Long, String>();

				if (null != channelInfos && channelInfos.size() >= 1) {
					for (ChannelInfo obj : channelInfos) {
						channelsMap.put(obj.getId(), obj.getName());
					}
				}

				for (Switchs pageItem : pageItems) {
					pageItem.setChannel_name(channelsMap.get(pageItem.getChannel_id()));
				}
			}
		}
		return page;
	}

	public Map<String, Object> delete(String ids) {
		String[] tmp = ids.split("\\,");
		int i = 0;
		for (String id : tmp) {
			try {
				switchsRepository.delete(Long.valueOf(id));
				i++;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("num", Integer.valueOf(i));
		return map;
	}
}
