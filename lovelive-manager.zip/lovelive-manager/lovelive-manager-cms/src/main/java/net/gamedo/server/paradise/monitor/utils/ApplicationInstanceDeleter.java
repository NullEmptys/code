package net.gamedo.server.paradise.monitor.utils;

import net.gamedo.server.paradise.model.primary.monitor.ApplicationInstance;
import net.gamedo.server.paradise.monitor.scheduler.DynamicJob;
import net.gamedo.server.paradise.monitor.scheduler.DynamicSchedulerFactory;
import net.gamedo.server.paradise.repository.primary.ApplicationInstanceRepository;
import net.gamedo.server.paradise.repository.primary.FrequencyMonitorLogRepository;
import net.gamedo.server.paradise.utils.BeanProvider;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by liuxing on 2016/4/12 0012.
 */
public class ApplicationInstanceDeleter {

    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationInstanceDeleter.class);
    private transient ApplicationInstanceRepository instanceRepository = BeanProvider.getBean(ApplicationInstanceRepository.class);
    private transient FrequencyMonitorLogRepository frequencyMonitorLogRepository = BeanProvider.getBean(FrequencyMonitorLogRepository.class);
    private ApplicationInstance instance;

    public ApplicationInstanceDeleter(ApplicationInstance instance) {
        this.instance = instance;
    }

    public boolean delete() {
//        final ApplicationInstance instance = instanceRepository.findOne(intanceId);
//        if (instance.getEnabled() == 0) {
//            LOGGER.debug("Forbid delete enabled ApplicationInstance[guid={}]", instance.getGuid());
//            return false;
//        }
        checkAndRemoveJob(instance);
        frequencyMonitorLogRepository.deleteByInstanceId(instance.getId());
        instance.setEnabled(0);
//        instanceRepository.save(instance);
        LOGGER.debug("Archive ApplicationInstance[guid={}] and FrequencyMonitorLogs,MonitoringReminderLogs", instance.getGuid());
        return true;
    }

    private void checkAndRemoveJob(ApplicationInstance instance) {
        DynamicJob job = new DynamicJob(instance.getJobName());
        try {
            if (DynamicSchedulerFactory.existJob(job)) {
                final boolean result = DynamicSchedulerFactory.removeJob(job);
                LOGGER.debug("Remove DynamicJob[{}] result [{}]", job, result);
            }
        } catch (SchedulerException e) {
            LOGGER.error("Remove [" + job + "] failed", e);
        }
    }
}
