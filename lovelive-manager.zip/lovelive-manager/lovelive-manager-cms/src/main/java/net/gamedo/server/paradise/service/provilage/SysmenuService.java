/* Copyright 2004, 2005, 2006 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.gamedo.server.paradise.service.provilage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.mysql.jdbc.StringUtils;

import net.gamedo.server.paradise.model.primary.CurrentPage;
import net.gamedo.server.paradise.model.provilage.Sysmenu;
import net.gamedo.server.paradise.repository.primary.provilage.SysmenuRepository;

@Service
@Transactional
public class SysmenuService extends BaseService {

	@Autowired
	private PermissionEvaluator permissionEvaluator;

	@Autowired
	private SysmenuRepository sysmenuRepository;

	public void afterPropertiesSet() throws Exception {
		Assert.notNull(sysmenuRepository, "sysmenuRepository required");
		Assert.notNull(mutableAclService, "mutableAclService required");
	}

	// @PreAuthorize("hasRole('ROLE_USER')")
	public void create(Sysmenu sysmenu) {
		// Create the Sysmenu itself
		sysmenuRepository.saveAndFlush(sysmenu);

		// Grant the current principal administrative permission to the sysmenu
		addPermission(Sysmenu.class, sysmenu.getId(), new PrincipalSid(getUsername()), BasePermission.ADMINISTRATION);

		if (logger.isDebugEnabled()) {
			logger.debug("Created sysmenu " + sysmenu + " and granted admin permission to recipient " + getUsername());
		}
	}

	// @PreAuthorize("hasRole('ROLE_USER')")
	// @PostFilter("hasPermission(filterObject, 'read') or
	// hasPermission(filterObject, admin)")
	@Transactional(readOnly = true)
	public List<Sysmenu> getAll() {
		logger.debug("Returning all sysmenus");

		return sysmenuRepository.findAll();
	}

	// @PreAuthorize("hasRole('ROLE_USER')")
	@Transactional(readOnly = true)
	public List<String> getAllRecipients() {
		logger.debug("Returning all recipients");

		return sysmenuRepository.findAllPrincipals();
	}

	// @PreAuthorize("hasPermission(#id, 'sample.sysmenu.Syspage', read) or "
	// + "hasPermission(#id, 'sample.sysmenu.Syspage', admin)")
	@Transactional(readOnly = true)
	public Sysmenu getById(Long id) {
		if (logger.isDebugEnabled()) {
			logger.debug("Returning sysmenu with id: " + id);
		}

		return sysmenuRepository.findOne(id);
	}

	public void update(Sysmenu sysmenu) {
		sysmenuRepository.save(sysmenu);

		logger.debug("Updated sysmenu " + sysmenu);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional(readOnly = true)
	public CurrentPage getPage(int currPage, int pageSize, String search) {

		int total = (int) sysmenuRepository.count();
		CurrentPage page = getCurrentPage(total, currPage, pageSize, new CurrentPage<Sysmenu>());

		List<Sysmenu> pageItems = null;
		if (StringUtils.isNullOrEmpty(search))
			pageItems = sysmenuRepository.getPage((currPage - 1) * pageSize, pageSize);
		else
			pageItems = sysmenuRepository.getPage((currPage - 1) * pageSize, pageSize, search);

		// 设置权限
		Authentication user = SecurityContextHolder.getContext().getAuthentication();
		if (null != pageItems) {
			for (Sysmenu sysmenu : pageItems) {
				if (permissionEvaluator.hasPermission(user, sysmenu, BasePermission.READ)) {
					sysmenu.setIfenabled(1);
				} else if (permissionEvaluator.hasPermission(user, sysmenu, BasePermission.ADMINISTRATION)) {
					sysmenu.setIfenabled(2);
				}
			}
		}
		page.setPageItems(pageItems);
		return page;
	}

	public Map<String, Object> delete(String ids) {
		String[] tmp = ids.split("\\,");
		int i = 0;
		for (String id : tmp) {
			try {
				sysmenuRepository.delete(Long.valueOf(id));
				// Delete the ACL information as well
				ObjectIdentity oid = new ObjectIdentityImpl(Sysmenu.class, Long.valueOf(id));
				mutableAclService.deleteAcl(oid, false);
				i++;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("num", Integer.valueOf(i));
		return map;
	}

	public Boolean idValidName(String name) {
		if (sysmenuRepository.findValidName(name) == 0)
			return true;
		else
			return false;
	}
}
