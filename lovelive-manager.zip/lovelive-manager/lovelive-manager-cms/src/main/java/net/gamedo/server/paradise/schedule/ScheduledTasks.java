package net.gamedo.server.paradise.schedule;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import com.alibaba.fastjson.JSON;
import net.gamedo.server.paradise.service.statistics.EmailService;
import net.gamedo.server.paradise.service.statistics.FrequencyMonitorLogService;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import net.gamedo.server.paradise.model.primary.Busschedule;
import net.gamedo.server.paradise.repository.primary.BusscheduleRepository;
import net.gamedo.server.paradise.repository.primary.CommonRepository;

@Component
public class ScheduledTasks {

    private static Logger log = Logger.getLogger("ScheduledTasks");

    @Autowired
    private BusscheduleRepository busscheduleRepository;

    @Autowired
    private CommonRepository commonRepository;

    @Autowired
    private EmailService mailService;

    @Autowired
    private FrequencyMonitorLogService frequencyMonitorLogService;

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * 每秒钟检查Busschedule，并执行相应功能性
     */
    @Scheduled(cron = "0 * * * * *")
    public void runBusschedule() {
        try {
            List<Busschedule> list = busscheduleRepository.getValid();
            if (null == list || list.size() == 0)
                return;
            for (Busschedule busschedule : list) {
                if (checkSchedule(busschedule)) {
                    int failed = 1;
                    log.info("runBusschedule before:" + busschedule.toString());
                    long id = busschedule.getTable_id();
                    String table = busschedule.getTable_name();
                    int num = 0;
                    System.out.println(JSON.toJSON(busschedule));
                    if (table.equals("Email")) {
                        if (mailService.send((int) id)) {
                            failed = 0;
                        }else{
                            continue;
                        }
                        if (failed != busschedule.getFailed()) {
                            busschedule.setFailed(failed);
                            busscheduleRepository.saveAndFlush(busschedule);
                            num++;
                        }
                    } else {
                        /*num = commonRepository.updateBySchedule(busschedule);
                        if (num > 0) {
                            failed = 0;
                        }*/
                    }

                    log.info("runBusschedule after: num " + num + " " + busschedule.toString());
                }
            }
        } catch (Exception e) {
            log.error("runBusschedule", e);
        }
    }

    private boolean checkSchedule(Busschedule busschedule) throws Exception {
        Calendar calendar = Calendar.getInstance();
        DateTime today = DateTime.now();
        StringBuilder sch = new StringBuilder()
                .append(StringUtils.isBlank(busschedule.getYear()) ? calendar.get(Calendar.YEAR) : busschedule.getYear())
                .append("-")
                .append(StringUtils.isBlank(busschedule.getMonth()) ? (calendar.get(Calendar.MONTH) + 1 >= 10
                        ? calendar.get(Calendar.MONTH) + 1 : "0" + (calendar.get(Calendar.MONTH) + 1))
                        : busschedule.getMonth())
                .append("-")
                .append(StringUtils.isBlank(busschedule.getDay()) ? (calendar.get(Calendar.DATE) >= 10
                        ? calendar.get(Calendar.DATE) : "0" + calendar.get(Calendar.DATE)) : busschedule.getDay())
                .append(" ")
                .append(StringUtils.isBlank(busschedule.getHour()) ? (calendar.get(Calendar.HOUR_OF_DAY) >= 10
                        ? calendar.get(Calendar.HOUR_OF_DAY) : "0" + calendar.get(Calendar.HOUR_OF_DAY))
                        : busschedule.getHour())
                .append(":")
                .append(StringUtils.isBlank(busschedule.getMinute()) ? (calendar.get(Calendar.MINUTE) >= 10
                        ? calendar.get(Calendar.MINUTE) : "0" + calendar.get(Calendar.MINUTE))
                        : busschedule.getMinute())
                .append(":00");
        if (today.getMillis() == dateFormat.parse(sch.toString()).getTime())
            return true;
        else if (null != busschedule.getFailed() && busschedule.getFailed() == 1  && today.isAfter(dateFormat.parse(sch.toString()).getTime())) {
            return busschedule.getDeadline() == null || today.isBefore(dateFormat.parse(String.valueOf(busschedule.getDeadline())).getTime());
        }
        return false;
    }

    //    @Scheduled(cron = "0 0 23 ? * *")
    @Scheduled(cron = "0 0/5 * * * ?")
    public void runMonitorClearschedule() {
        DateTime dt = new DateTime();
        DateTime yesterday = dt.minusHours(1);
        Timestamp ts;
        ts = Timestamp.valueOf(dateFormat.format(yesterday.toDate()));
        frequencyMonitorLogService.deleteByCreateTimeBefore(ts);
    }
}
