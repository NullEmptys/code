package net.gamedo.server.paradise.controller.statistics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.sun.el.parser.ParseException;

import net.gamedo.server.paradise.cms.Constants;
import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.service.statistics.ItemRecordService;
import net.gamedo.server.paradise.utils.NetWorkUtils;

@Controller
@RequestMapping("/statistics/serverinfoconfig")
public class ServerinfoconfigController extends BaseController {
	@Autowired
	ItemRecordService logService;

	@RequestMapping
	public String list(HttpServletRequest request, Model model) {
		initModel(request, model);
		return "statistics/serverinfoconfig/serverinfoconfig_index";
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/listForPage", method = RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> listForPage() {
		String getUrl = Constants.remoteUrl + "/api/serverinfo/serverInfoList";
		Map<String, Object> mapObj = NetWorkUtils.doGet(getUrl);
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		if(null != mapObj){
			if("0".equals(mapObj.get("code")+"")){
				if(null != mapObj.get("serverInfoList")){
					list = (List<Map<String, Object>>)mapObj.get("serverInfoList");
				}
			}
		}
		return list;
	}
	
	/**
	 * 鏍规嵁id鑾峰彇鏈嶅姟淇℃伅
	 *
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/get", method = RequestMethod.POST)
	public @ResponseBody Object get(Long id) {
		String getUrl = Constants.remoteUrl + "api/serverinfo/" + id;
		Map<String, Object> mapObj = NetWorkUtils.doGet(getUrl);
		Map<String, Object> map = new HashMap<String, Object>();
		if(null != mapObj){
			if(null != mapObj.get("serverInfoConfig")){
				map = (Map<String, Object>)mapObj.get("serverInfoConfig");
			}
		}
		return map;
	}
	
	/**
	 * 淇敼鏈嶅姟鍣ㄤ俊鎭�
	 *
	 * @param request
	 * @param data
	 * @return @
	 * @throws ParseException
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody int save(HttpServletRequest request, String data){
		JSONObject o = JSONObject.parseObject(data);
		Map<String, Object> papMap = new HashMap<String, Object>();
		papMap.put("id", Integer.parseInt(o.getString("id")));
//		papMap.put("serverId", Integer.parseInt(o.getString("serverId")));
//		papMap.put("serverName", o.getString("serverName"));
//		papMap.put("ip", o.getString("ip"));
//		papMap.put("port", Integer.parseInt(o.getString("port")));
//		papMap.put("discription", o.getString("discription"));
//		papMap.put("executeUpdate", Integer.parseInt(o.getString("executeUpdate")));
		if(null != o.getString("safetyIpStr")){
			papMap.put("safetyIpStr", o.getString("safetyIpStr"));
		}
		if(null != o.getString("openTime") && !"".equals(o.getString("openTime"))){
			papMap.put("openTime", o.getString("openTime"));
		}
		if(null != o.getString("closeTime") && !"".equals(o.getString("closeTime"))){
			papMap.put("closeTime", o.getString("closeTime"));
		}
		String getUrl = Constants.remoteUrl + "/api/serverinfo/" + o.get("id") +"/serverInfoUpdate";
		Map<String, Object> mapObj = NetWorkUtils.doPost(getUrl, papMap);
		return null == mapObj?1 : Integer.parseInt(mapObj.get("code")+"");
	}
	
}
