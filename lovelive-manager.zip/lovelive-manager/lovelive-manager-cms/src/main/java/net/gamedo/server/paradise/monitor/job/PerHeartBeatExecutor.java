package net.gamedo.server.paradise.monitor.job;

import net.gamedo.server.paradise.model.primary.monitor.ApplicationInstance;
import net.gamedo.server.paradise.model.primary.monitor.FrequencyMonitorLog;
import net.gamedo.server.paradise.repository.primary.ApplicationInstanceRepository;
import net.gamedo.server.paradise.repository.primary.FrequencyMonitorLogRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2016/4/12 0012.
 */
@Service
public class PerHeartBeatExecutor {

    private static final Logger LOGGER = LoggerFactory.getLogger(PerHeartBeatExecutor.class);

    @Autowired
    private ApplicationInstanceRepository instanceRepository;
    @Autowired
    private FrequencyMonitorLogRepository frequencyMonitorLogRepository;

    private String guid;

    public PerHeartBeatExecutor() {
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public void execute() {
        final ApplicationInstance instance = instanceRepository.findByGuid(guid);
        if (instance != null) {
            if (instance.getEnabled() == 1) {
                final FrequencyMonitorLog monitorLog = generateMonitorLog(instance);
                frequencyMonitorLogRepository.save(monitorLog);
                LOGGER.debug("Generate and persist FrequencyMonitorLog[{}]", monitorLog);
            }
        }
    }

    private FrequencyMonitorLog generateMonitorLog(ApplicationInstance instance) {
        FrequencyMonitorLogGenerator monitorLogGenerator = new FrequencyMonitorLogGenerator(instance);
        return monitorLogGenerator.generate();
    }
}
