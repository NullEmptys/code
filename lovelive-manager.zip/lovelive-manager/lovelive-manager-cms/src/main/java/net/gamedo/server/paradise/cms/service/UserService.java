package net.gamedo.server.paradise.cms.service;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import net.gamedo.server.paradise.model.provilage.Account;
import net.gamedo.server.paradise.repository.primary.provilage.AccountSecureRepository;

public class UserService implements UserDetailsService {

	@Autowired
	private AccountSecureRepository accountSecureRepository;

	@PostConstruct
	protected void initialize() {
		// accountSecureRepository.save(new Account("user", "demo",
		// "ROLE_USER"));
		// accountSecureRepository.save(new Account("admin", "admin",
		// "ROLE_ADMIN"));
	}

	// /j_spring_security_check提交后，spring-security-core-3.0.5.jar的类DaoAuthenticationProvider.java源码中
	// 进行了密码校验，userDetails.getPassword()是数据库中的密码，presentedPassword是你输入的密码
	// spring security
	// 会调用指定的实现UserDetailService的类中的loadUserByUsername方法取得用户所拥有的权限
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Account account = accountSecureRepository.findByEmail(username);
		if (account == null) {
			throw new UsernameNotFoundException("user not found");
		}
		return createUser(account);
	}

	public void signin(Account account) {
		SecurityContextHolder.getContext().setAuthentication(authenticate(account));
	}

	public boolean changePassword(String username, String password, String oldpassword) {
		// get the UserDetails
		Account account = accountSecureRepository.findByEmail(username);
		if (account == null) {
			throw new UsernameNotFoundException("user not found");
		}
		if (accountSecureRepository.matches(account, oldpassword)) {
			account.setPassword(password);
			accountSecureRepository.save(account);
			return true;
		}
		return false;
	}

	/**
	 * Authentication存储安全实体的标识、密码以及认证请求 的上下文信息。它还包含用户认证后的信息 （可能会包含一个 UserDetails
	 * 的实例） 。 通常 不会被扩展，除非是为了支持某种特定类型 的认证。
	 * 
	 * @param account
	 * @return
	 */
	public Authentication authenticate(Account account) {
		return new UsernamePasswordAuthenticationToken(createUser(account), null, account.getAuthorities());
	}

	private SecurityUser createUser(Account account) {
		return new SecurityUser(account);
	}

}
