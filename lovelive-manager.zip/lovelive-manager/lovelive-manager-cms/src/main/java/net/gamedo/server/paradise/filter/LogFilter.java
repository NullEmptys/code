package net.gamedo.server.paradise.filter;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import net.gamedo.server.paradise.cms.service.SecurityUser;

@Component
public class LogFilter implements Filter {

	private static Logger logger = Logger.getLogger("cmsapi");

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		long before = System.currentTimeMillis();

		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;

		response.setHeader("Pragma", "no-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expires", 0);

		StringBuffer debugLog = new StringBuffer();
		if (logger.isDebugEnabled()) {
			try {
				Map<String, String[]> parameters = request.getParameterMap();
				if (null != parameters) {
					debugLog.append(" Parameter:");
					for (String key : parameters.keySet()) {
						String[] values = parameters.get(key);
						if (null == values || values.length == 0)
							continue;
						debugLog.append(key).append("=");
						for (String value : values) {
							debugLog.append(value).append(",");
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Object currentUser = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String uri = request.getRequestURI();

		if (null != currentUser && currentUser instanceof SecurityUser && !uri.equals("/")
				&& request.getMethod().equalsIgnoreCase("GET")
				&& !(uri.endsWith(".js") || uri.endsWith(".css") || uri.endsWith(".png") || uri.endsWith(".jpg")
						|| uri.endsWith(".gif") || uri.endsWith(".jpeg") || uri.endsWith(".mp4") || uri.endsWith(".mp4")
						|| uri.endsWith(".woff2") || uri.endsWith(".woff") || uri.endsWith(".ttf")
						|| uri.endsWith(".eot") || uri.endsWith(".svg") || uri.endsWith(".otf"))
				&& !((SecurityUser) currentUser).checkUri(uri) && !uri.equals("/statistics/announcement/down")
				&& !uri.equals("/statistics/commitbug/download")) {
			// 检验当前页面的权限，如果没有权限，直接踢出登录/logout
			// 防止用户在url里直接输入地址
			response.sendRedirect(request.getContextPath() + "/");
			// String referer = request.getHeader("Referer");
			// String uri = request.getServletPath()
			// + (request.getPathInfo() == null ? "" : request.getPathInfo());
			// if (!referer.equals("/signin"))
			// response.sendRedirect(referer);
			// else
			// response.sendRedirect(request.getContextPath() + "/logout");
		} else {
			chain.doFilter(req, res);
		}
		long after = System.currentTimeMillis();
		// 记录日志
		logger.info("URI:" + request.getRequestURI() + " Time Cost:" + (after - before) + debugLog.toString());
	}

	@Override
	public void destroy() {
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}

}