package net.gamedo.server.paradise.cms.model;

import org.hibernate.validator.constraints.NotBlank;

public class ChangePasswordForm {

	private static final String NOT_BLANK_MESSAGE = "不能为空";

	@NotBlank(message = ChangePasswordForm.NOT_BLANK_MESSAGE)
	private String oldpassword;

	@NotBlank(message = ChangePasswordForm.NOT_BLANK_MESSAGE)
	private String password;

	public String getOldpassword() {
		return oldpassword;
	}

	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
