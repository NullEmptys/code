package net.gamedo.server.paradise.service.statistics;

import net.gamedo.server.paradise.model.primary.monitor.FrequencyMonitorLog;
import net.gamedo.server.paradise.repository.primary.ApplicationInstanceRepository;
import net.gamedo.server.paradise.repository.primary.FrequencyMonitorLogRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;

/**
 * Created by Administrator on 2016/4/12 0012.
 */
@Service
public class FrequencyMonitorLogService extends BaseService {
    @Autowired
    private FrequencyMonitorLogRepository frequencyMonitorLogRepository;
    @Autowired
    private ApplicationInstanceRepository applicationinstanceRepository;

    public void save(FrequencyMonitorLog frequencyMonitorLog) {
        frequencyMonitorLogRepository.saveAndFlush(frequencyMonitorLog);
    }

    public FrequencyMonitorLog findTopMonitorLog(Long instanceId) {
        FrequencyMonitorLog frequencyMonitorLog = frequencyMonitorLogRepository.findFirstByInstanceIdOrderByCreateTimeDesc(instanceId);
        if (frequencyMonitorLog != null) {
            frequencyMonitorLog.setInstance(applicationinstanceRepository.findOne(frequencyMonitorLog.getInstanceId()));
        } else {
            frequencyMonitorLog = new FrequencyMonitorLog();
        }

        return frequencyMonitorLog;
    }

    public void deleteByCreateTimeBefore(Timestamp searchTime){
        frequencyMonitorLogRepository.deleteByCreateTimeBefore(searchTime);
    }
}
