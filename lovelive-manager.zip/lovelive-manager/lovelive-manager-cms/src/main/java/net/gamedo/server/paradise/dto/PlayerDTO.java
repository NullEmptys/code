package net.gamedo.server.paradise.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerDTO {
    private int changeGold;
    private int playerId;
    private int changeGoldVal;
    private int changeMoney;
    private int changeMoneyVal;
    private int state;
    private int playerType;
    private int changeTili;
    private int changeTiliVal;
    private int tili;
    private int girlId;

    public int getChangeTili() {
        return changeTili;
    }

    public void setChangeTili(int changeTili) {
        this.changeTili = changeTili;
    }

    public int getChangeTiliVal() {
        return changeTiliVal;
    }

    public void setChangeTiliVal(int changeTiliVal) {
        this.changeTiliVal = changeTiliVal;
    }

    public int getPlayerType() {
        return playerType;
    }

    public void setPlayerType(int playerType) {
        this.playerType = playerType;
    }

    private String name;

    public int getChangeGold() {
        return changeGold;
    }

    public void setChangeGold(int changeGold) {
        this.changeGold = changeGold;
    }

    public int getPlayerId() {
        return playerId;
    }

    public void setPlayerId(int playerId) {
        this.playerId = playerId;
    }

    public int getChangeGoldVal() {
        return changeGoldVal;
    }

    public void setChangeGoldVal(int changeGoldVal) {
        this.changeGoldVal = changeGoldVal;
    }

    public int getChangeMoney() {
        return changeMoney;
    }

    public void setChangeMoney(int changeMoney) {
        this.changeMoney = changeMoney;
    }

    public int getChangeMoneyVal() {
        return changeMoneyVal;
    }

    public void setChangeMoneyVal(int changeMoneyVal) {
        this.changeMoneyVal = changeMoneyVal;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTili() {
        return tili;
    }

    public void setTili(int tili) {
        this.tili = tili;
    }

    public int getGirlId() {
        return girlId;
    }

    public void setGirlId(int girlId) {
        this.girlId = girlId;
    }

    @Override
    public String toString() {
        return "PlayerDTO{" +
                "changeGold=" + changeGold +
                ", playerId=" + playerId +
                ", changeGoldVal=" + changeGoldVal +
                ", changeMoney=" + changeMoney +
                ", changeMoneyVal=" + changeMoneyVal +
                ", state=" + state +
                ", playerType=" + playerType +
                ", changeTili=" + changeTili +
                ", changeTiliVal=" + changeTiliVal +
                ", tili=" + tili +
                ", girlId='" + girlId + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}