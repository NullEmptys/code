package net.gamedo.server.paradise.controller.statistics;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.alibaba.fastjson.JSONObject;
import net.gamedo.server.paradise.cms.Constants;
import net.gamedo.server.paradise.service.statistics.ApplicationInstanceService;
import net.gamedo.server.paradise.service.statistics.ChannelInfoService;
import net.gamedo.server.paradise.utils.NetWorkUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import net.gamedo.server.paradise.controller.BaseController;
import net.gamedo.server.paradise.model.primary.monitor.ApplicationInstance;

/**
 * Created by liuxing on 2016/04/11.
 */
@Controller
@RequestMapping("/statistics/applicationInstance")
public final class ApplicationInstanceController extends BaseController {

    @Autowired
    private ApplicationInstanceService applicationinstanceService;
    @Autowired
    private ChannelInfoService channelInfoService;

    @RequestMapping
    public String list(HttpServletRequest request, Model model) {
        initModel(request, model);

        return "statistics/applicationinstance/applicationinstance_index";
    }

    /**
     * 分页查询
     *
     * @param currPage 当前页
     * @param pageSize
     * @param search   查询参数
     * @return
     */
    @SuppressWarnings("rawtypes")
    @RequestMapping(value = "/listForPage", method = RequestMethod.POST)
    public
    @ResponseBody
    Page listForPage(int currPage, int pageSize, String search) {
        return applicationinstanceService.getPage(currPage, pageSize, search);
    }

    /**
     * 保存 修改菜单
     *
     * @param request
     * @param data
     * @return @
     */
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public
    @ResponseBody
    ApplicationInstance save(HttpServletRequest request, String data) {
        try {
            ApplicationInstance obj = mapper.readValue(data, ApplicationInstance.class);
            StringBuilder url = new StringBuilder(Constants.remoteUrl);
            url.append("api/channel/").append(obj.getChannelId());
            JSONObject result = NetWorkUtils.netGet(url.toString());
//            ChannelInfo channelInfo =
            assert result != null;
            Map<String,Object> channel = result.getJSONObject("channel");
            obj.setChannelName((String) channel.get("name"));
            if (null == obj.getId()) { // 新增
                obj.setEnabled(1);
                applicationinstanceService.create(obj);
                applicationinstanceService.enableApplicationInstance(obj.getId());
            } else { // 修改更新
                applicationinstanceService.update(obj);
                applicationinstanceService.enableApplicationInstance(obj.getId());
            }

            return obj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 根据ids删除菜单
     *
     * @param ids
     * @return
     */
    @RequestMapping(value = "/del", method = RequestMethod.POST)
    public
    @ResponseBody
    Map<String, Object> del(String ids) {
        return applicationinstanceService.delete(ids);
    }

    /**
     * 根据id获取菜单
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/get", method = RequestMethod.POST)
    public
    @ResponseBody
    ApplicationInstance get(Long id) {
        return applicationinstanceService.getById(id);
    }

    /**
     * 启动监控
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/startMonitor", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> startMonitor(Long id) {
        boolean flag = applicationinstanceService.enableApplicationInstance(id);
        Map<String, Object> result = new HashMap<>();
        result.put("success", flag);
        return result;
    }

    /**
     * 停止监控
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/stopMonitor", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> stopMonitor(Long id) {
        boolean flag = applicationinstanceService.stopMonitoringApplicationInstance(id);
        Map<String, Object> result = new HashMap<>();
        result.put("success", flag);
        return result;
    }

    /**
     * 删除监控
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/deleteMonitor", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> deleteMonitor(Long id) {
        ApplicationInstance instance = applicationinstanceService.getById(id);
        boolean flag = applicationinstanceService.deleteApplicationInstance(instance);
        Map<String, Object> result = new HashMap<>();
        result.put("success", flag);
        return result;
    }

}
