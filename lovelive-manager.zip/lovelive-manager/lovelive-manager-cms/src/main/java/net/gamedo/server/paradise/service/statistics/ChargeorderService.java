package net.gamedo.server.paradise.service.statistics;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.gamedo.server.paradise.repository.fourth.ChargeorderRepository;
import net.gamedo.server.paradise.service.provilage.BaseService;

@Service
public class ChargeorderService extends BaseService {
	@Autowired
	private ChargeorderRepository chargeorderRepository;

	// 充值记录分页查询
	//@TargetDataSource(name = "ds3")
	public Map<String, Object> getChargeorderList(String playerId, String channelId, String orderType,
			String orderState, String startTime, String endTime, int currPage, int pageSize) {
		Map<String, Object> map = chargeorderRepository.getChargeorders(playerId, channelId, orderType, orderState,
				startTime, endTime, currPage, pageSize);
		return map;
	}

	// 充值记录全部数据
	//@TargetDataSource(name = "ds3")
	public Map<String, Object> getChargeorderAllList(String playerId, String channelId, String orderType,
			String orderState, String startTime, String endTime) {
		Map<String, Object> map = chargeorderRepository.getChargeorderAll(playerId, channelId, orderType, orderState,
				startTime, endTime);
		return map;
	}

}
