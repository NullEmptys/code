/**
 *初始化组件
 */
initComponents=function(){
	var group;
	sysComponents.getItemByCategoryType('item_id_item', 1);
	$('#btn_add').click(function () {
		showEdit('add');
    });
	
	$('#btn_clothingShow').click(function () {
		change('1','clothing');
    });
	$('#btn_giftShow').click(function () {
		change('0','gift');
    });
	$('#btn_specialShow').click(function () {
		change('3','clothing');
    });
	$('#btn_rahmenShow').click(function () {
		change('4','clothing');
    });
	$('#btn_actionShow').click(function () {
		change('2','clothing');
    });
	
	$('#btn_save').click(function () {
		if ($('#form_playerProperty').valid()) {
			saveEdit();
		}
    });
	
	$('#btn_del').click(function () {
		showDels();
    });
	
	$('#btn_remove').click(function () {
		doDel();
    });
	
//	$('#btn_search').click(function () {
//        showList($('#input_search').val(), 1, $('#perPage').val());
//    });
	
	$('#input_search').bind('keypress', function (event) {
        if (event.keyCode == "13") {
           showList($('#input_search').val(), 1, $('#perPage').val());
        }
    });
	
	$('#perPage').change(function () {
        showList($('#_userId').val(), 1, $('#perPage').val());
    });
	
	$('#category').change(function () {
        editChange();
    });
	
	 $('#cdTimes').change(function () {
	    	if("" == $('#cdTimes option:selected').val()){
	    		$("#cdTime_NtoB").show();
	    	} else if(-1 == $('#cdTimes option:selected').val()){
	    		$("#cdTime_NtoB").hide();
	    	}
	 });
	
	$('#checkAll').click(function () {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });
	
	$('#_userId').val('');
	$('#_count').val('');
	$('#_category').val('1');
	$('#_gridId').val('');
	$('#_bagId').val('');
	$('#_currPage').val('1');
	$('#_itemId').val('');
	$('#_oldId').val('-1');
	$('#_blockToNone').val('clothing');
    //ViewValidator.init();
}