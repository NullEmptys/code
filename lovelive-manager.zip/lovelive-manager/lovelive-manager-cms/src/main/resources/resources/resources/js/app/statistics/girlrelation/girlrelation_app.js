/**
 *初始化组件
 */
initComponents=function(){
	var group;
	$('#btn_add').click(function () {
        showEdit('add');
    });
	
	$('#btn_save').click(function () {
		if ($('#form_girlrelation').valid()) {
			saveEdit();
		}
    });
	
	$('#btn_del').click(function () {
		showDels();
    });
	
	$('#btn_remove').click(function () {
		doDel();
    });
	
	$('#btn_search').click(function () {
        showList($('#searchContent').val(), 1, $('#perPage').val());
    });
	
	$('#perPage').change(function () {
        showList($('#userId').val(), 1, $('#perPage').val());
    });
	
	$('#checkAll').click(function () {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });
	
	$('#_userId').val('');
	$('#_userName').val('');
	$('#_oldId').val('-1');
    //ViewValidator.init();
}