var daterangepicker_startDate = null;
var daterangepicker_endDate = null;

daterangepicker_initComponents = function() {
	// 改变日期后自动刷新
	$('#daterangepicker_startDate').datepicker().on('changeDate', function(e) {
		daterangepicker_doDropDownSelect();

	});
	$('#daterangepicker_endDate').datepicker().on('changeDate', function(e) {
		daterangepicker_doDropDownSelect();
	});

	// 默认今天
	var today = new Date();
	$('#daterangepicker_endDate').datepicker('setDate',
			today.Format('yyyy-MM-dd'));
	$('#daterangepicker_startDate').datepicker('setDate',
			today.Format('yyyy-MM-dd'));

	doRefresh();
}

daterangepicker_doDropDownSelect = function(dateType, dropValue) {
	if (dateType) {
		var today = new Date();
		$('#daterangepicker_endDate').datepicker('setDate',
				today.Format('yyyy-MM-dd'));
		$('#daterangepicker_startDate').datepicker('setDate',
				today.DateAdd('d', -dateType + 1).Format('yyyy-MM-dd'));

		$('#daterangepicker_rangeDrapdown').text(dropValue);
	} else {
		$('#daterangepicker_rangeDrapdown').text('请选择');
	}
	var start = $('#daterangepicker_startDate').val().trim();
	var end = $('#daterangepicker_endDate').val().trim();
	if ((daterangepicker_startDate == start && daterangepicker_endDate == end)
			|| start == '' || end == '')
		return;
	daterangepicker_startDate = start;
	daterangepicker_endDate = end;
	doRefresh();
}
