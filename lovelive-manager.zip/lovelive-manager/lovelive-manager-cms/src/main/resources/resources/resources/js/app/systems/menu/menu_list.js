var delIds;

sysPage = new SysPage();
/**
 * 分页查询
 *
 * @param {}
 *          search
 * @param {}
 *          currPage
 * @param {}
 *          perPage
 */
showList = function (search, currPage, pageSize) {
    $.post(REPORT_ROOT + "/systems/menu/listForPage", {
        search: search,
        currPage: currPage,
        pageSize: pageSize
    }, function (data) {
        var _tpl = '<tr><th><input value="{id}" type="checkbox" name="check"></th><td><a href="javascript:showEdit(\'view\',{id});">{name}</a></td><td>{page}</td><td><pre>{url}</pre></td><td>{icons}</td><td>{seq}</td>'
            + '<td class="text-center"><span class="btn-group">'
            + '<a title="'+viewLocale.form.title.edit+'" class="btn bs-tooltip" href="javascript:showEdit(\'edit\',{id});" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
            + '<a title="'+viewLocale.form.title.del+'" class="btn bs-tooltip" href="javascript:showDel({id});" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></a>'
            + '</span></td></tr>';
        var _html = '';
        $(data.pageItems).each(function (index, element) {
        	//element.url = element.url.replace("&","&amp;");
            _html = _html+nano(_tpl, element);
        })
        $('#menu_list').html(_html);
        
        // 显示分页
        sysPage.showPage('nav_page', data.pageCount, data.currPage, data.total);
        $('.bs-tooltip').tooltip();
        
        showAuth();
    });
}

goPage = function (currPage) {
    var _search = $('#input_search').val();
    var _perPage = $('#perPage').val();
    showList(_search, currPage, _perPage);
}

showDel = function (ids) {
	$('.ui-dialog-title').html(viewLocale.prompt)
    delIds = ids;
    $('#dialog_message').modal('show');
}

showDels = function () {
	$('.ui-dialog-title').html(viewLocale.prompt)
    delIds = '';
    var _checks = $("input[name='check']");
    $(_checks).each(function (index, element) {
        if ($(element).prop('checked')) {
            delIds = delIds + $(element).prop('value') + ',';
        }
    });

    if (delIds.length == 0) {
        sysComponents.showHelpMessage(viewLocale.form.del.sel);
        return;
    } else {
        $('#dialog_message').modal('show');
    }
}

/**
 * 确定是否删除动作
 *
 * @param {}
 *          id
 */
doDel = function () {
    //$('#dialog_message').dialog('close');
    sysComponents.showHelpMessage(viewLocale.form.del.loading);
    var _l = (delIds + '').split(',').length;
    _l = (_l > 1) ? (_l - 1) : _l;
    $.post(REPORT_ROOT + "/systems/menu/del", {
        ids: delIds
    }, function (data) {
        if (data.num == _l) {
            sysComponents.showHelpMessage(viewLocale.form.del.success);
        } else if (data.num == 0) {
            sysComponents.showHelpMessage(viewLocale.form.del.fail, 'error');
        }else {
            sysComponents.showHelpMessage(viewLocale.form.del.subSuccess + data.num);
        }
        goPage(sysPage.currPage);
    });
    $('#dialog_message').modal('hide');
}