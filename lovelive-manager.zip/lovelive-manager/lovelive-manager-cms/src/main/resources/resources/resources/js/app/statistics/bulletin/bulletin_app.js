
/**
 *初始化组件
 */
initComponents = function () {
    var group;

    //sysComponents.getAllItem('attachId1');
    //sysComponents.getAllItem('attachId2');

    $('#btn_new').click(function () {
        bulletin_form.showEdit('add');
    });

    $('#btn_save').click(function () {
        if ($('#form_menu').valid()) {
            bulletin_form.saveEdit($('#operType').val());
        }
    });

    // if ($('#isSendNow').is(':checked')) {
    //     $("#sendNow").show();
    // } else {
    //     $("#endTime").attr('value', new Date().Format('yyyy-MM-dd HH:mm:ss'));
    //     $("#startTime").attr('value', new Date().Format('yyyy-MM-dd HH:mm:ss'));
    //     $("#sendNow").hide();
    // }

    $('#isSendNow').click(function () {
        if ($('#isSendNow').is(':checked')) {
            $("#endTime").attr('value', '');
            $("#startTime").attr('value', '');
            $("#sendNow").show();
        } else {
            $("#endTime").attr('value', new Date().Format('yyyy-MM-dd HH:mm:ss'));
            $("#startTime").attr('value', new Date().Format('yyyy-MM-dd HH:mm:ss'));
            $("#sendNow").hide();
        }
    });

    $("#endTime").click(function () {
        if ($("#startTime").val() === '') {
            $("#endTime").datetimepicker('setStartDate', new Date());
        } else {
            $("#endTime").datetimepicker('setStartDate', $("#startTime").val());
        }
    });

    $("#startTime").click(function () {
        if ($("#endTime").val() !== '') {
            $("#startTime").datetimepicker('setEndDate', $("#endTime").val());
        }
    });

    $("#broadcastEndTime").click(function () {
        if ($("#broadcastStartTime").val() === '') {
            $("#broadcastEndTime").datetimepicker('setStartDate', new Date());
        } else {
            $("#broadcastEndTime").datetimepicker('setStartDate', $("#broadcastStartTime").val());
        }
    });

    $("#broadcastStartTime").click(function () {
        if ($("#broadcastEndTime").val() !== '') {
            $("#broadcastStartTime").datetimepicker('setEndDate', $("#broadcastEndTime").val());
        }
    });

    if ($('#attachments').is(':checked')) {
        $("#attachs").show();
    } else {
        $("#attachs").hide();
    }

    $('#btn_del').click(function () {
        bulletin_list.showDels();
    });

    $('#btn_remove').click(function () {
        bulletin_list.doDel();
    });

    // $('#btn_search').click(function() {
    //     bulletin_list.showserverList(1, $('#perPage').val());
    // });

    // $('#input_search').bind('keypress', function(event) {
    //     if (event.keyCode == "13") {
    //         bulletin_list.showserverList(1, $('#perPage').val());
    //     }
    // });

    $("#isSend").click(function () {
        if ($('#isSend').is(':checked')) {
            //bulletin_form.send();
            $("#dialog_message_for_send").modal('show');
        } else {
            $("#dialog_message_for_send").modal('hide');
        }
    });

    $("#btn_cls").click(function () {
        bulletin_form.cancle();
    });

    $("#btn_close").click(function () {
        bulletin_form.resetForm();
        $('#menuEdit').hide();
        $('#show_all_list').show();
    });

    $('#server_perPage').change(function () {
        bulletin_list.showserverList(1, $('#server_perPage').val());
    });

    $('#local_perPage').change(function () {
        bulletin_list.showLocalList(1, $('#local_perPage').val());
    });

    $("#menuEdit").hide();

    bulletin_list.showserverList(1, 10);

    bulletin_list.showLocalList(1, 10);

    $("#marquee").hide();

    $("#type").change(function () {
        if (this.value == 2) {
            $("#marquee").show();
        } else {
            $("#marquee").hide();
        }
    });

    var checkeContent = function () {
        if ($("#image").is(":checked")) {
            $("#picture").show();
            $("#bulletinContent").hide();
            $("#cke_bulletinContent").hide();
        } else if ($("#text").is(":checked")) {
            $("#picture").hide();
            $("#bulletinContent").show();
            $("#cke_bulletinContent").show();
        } else {
            $("#picture").hide();
            $("#bulletinContent").show();
            $("#cke_bulletinContent").show();
        }
    };

    checkeContent();

    $("#image").click(function () {
        $("#picture").show();
        $("#bulletinContent").hide();
        $("#cke_bulletinContent").hide();
    });

    $("#text").click(function () {
        $("#picture").hide();
        $("#bulletinContent").show();
        $("#cke_bulletinContent").show();
    });

    ViewValidator.init();
};