sysPage = new SysPage();

var mail_list = function() {
    var delId;
    return {
        /**
         * 分页查询
        * 
        * @param {}
        *            search
        * @param {}
        *            currPage
        * @param {}
        *            perPage
        */
        showList: function(currPage, pageSize) {
            $.post(REPORT_ROOT + "/statistics/email/listForPage",
                {
                    currPage: currPage - 1,
                    pageSize: pageSize
                }, function(data) {
                    console.info(data);
                    var _tpl = '<tr><td class="text-center">{postTime}</td><td class="text-center">{status}</td><td class="text-center">{playerName}</td><td class="text-center">{sendName}</td><td class="text-center">{title}</td><td class="text-center">{hasAttachs}</td><td class="text-center">{hasContent}</td>'
                        + '<td class="text-center"><span class="btn-group">'
                        + '<a title="' + viewLocale.form.title.del + '" class="btn bs-tooltip" href="javascript:mail_list.showDel({id});" data-original-title="Del"><i class="glyphicon glyphicon-remove"></i></a>'
                        + '{sendEmail}'
                        + '</span></td>'
                        + '</tr>';
                    var _html = '';
                    $(data.content).each(function(index, element) {
                        if (element.postTime) {
                            //var newDate = new Date(element.postTime);
                            //element.postTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
                            //console.info(new Date());
                            //console.info(element.postTime);
                        }

                        if (element.status === 0) {
                            element.sendEmail = '<a title="发送" class="btn bs-tooltip" href="javascript:mailForm.send('+ element.id +');" data-original-title="Send"><i class="glyphicon glyphicon-send"></i></a>';
                            element.status = "未发送";
                        } else {
                            element.status = "已发送";
                        }

                        if (element.mailContent) {
                            element.hasContent = "<a title='查看' href='javascript:mail_list.showDetail(" + element.id + ")'>查看</a>";
                        } else {
                            element.hasContent = '';
                        }

                        if (element.attachGold !== 0 || element.attachMoney !== 0 || element.attach.length !== 0) {
                            element.hasAttachs = '√';
                        } else {
                            element.hasAttachs = 'x';
                        }

                        _html = _html + nano(_tpl, element);
                    });
                    $('#menu_list').html(_html);
                    // 显示分页
                    sysPage.showPage('nav_page', data.totalPages, currPage, data.totalElements);
                    $('.bs-tooltip').tooltip();
                    showAuth();
                });
        },

        showDetail: function(id) {
            $("#mail_detail").modal("show");
            $.post(REPORT_ROOT + '/statistics/email/get', {
                id: id
            }, function(data) {
                console.info(data);
                $("#detail_playerId").html(data.playerName);
                $("#detail_title").html(data.title);
                $("#detail_content").html(data.mailContent);
                $("#detail_all_attach").html('');
                if (data.attachGold !== 0 || data.attachMoney !== 0 || data.attach.length > 0) {
                    $("#detail_attach").show();
                    if(data.attach.length > 0){
                        $(data.attach).each(function(index, element) {
                        	if(element.itemNum > 100000000000){
                        		var newDate = new Date();
                				newDate.setTime(new Number(element.itemNum));
                				element.itemNum = newDate.Format('yyyy-MM-dd HH:mm:ss');
                        	} else if(element.itemNum == -1){
                        		element.itemNum = '永久';
                        	}
                            var attach_div = "<label class=\"col-sm-3 control-label\">"+element.itemName+"</label><span class=\"col-sm-3\">"+element.itemNum+"</span>";
                            $("#detail_all_attach").append(attach_div);
                        });
                    }
                    //$("#detail_all_attach")
                    if(data.attachGold > 0){
                    	$("#detail_attachGold_Nob").show();
                    	$("#detail_attachGold").html(data.attachGold);
                    } else {
                    	$("#detail_attachGold_Nob").hide();
                    }
                    if(data.attachMoney > 0){
                    	$("#detail_attachMoney_Nob").show();
                    	$("#detail_attachMoney").html(data.attachMoney);
                    } else {
                    	$("#detail_attachMoney_Nob").hide();
                    }
                } else {
                    $("#detail_attach").hide();
                }
            });
        },

        showDel: function(id) {
            $('.ui-dialog-title').html(viewLocale.prompt)
            delId = id;
            $('#dialog_message_for_delete').modal('show');
        },

        /**
         * 执行删除动作
         * 
         * @param {}
         *            id
         */
        doDel: function() {
            sysComponents.showHelpMessage(viewLocale.form.del.loading);
            $.post(REPORT_ROOT + "/statistics/email/del", {
                id: delId
            }, function(data) {
                if(data){
                    sysComponents.showHelpMessage(viewLocale.form.del.success);
                }else{
                    sysComponents.showHelpMessage(viewLocale.form.del.fail, 'error');
                }
                goPage(sysPage.currPage);
            });
            $('#dialog_message_for_delete').modal('hide');
        }
    }
} ();

goPage = function(currPage) {
    //	var _search = $('#input_search').val();
    var _perPage = $('#perPage').val();
    //	showList(_search, currPage, _perPage);
    mail_list.showList(currPage, _perPage);
};