var currentmask = null;

$(function() {
	$("[id^='sysmodel_']").each(function(){ 
		$(this).hide();
	});
	$('input[name="sysmodel_code"]').each(function(){ 
		$("#"+$(this).val()).show();
	}); 
	currentmask = $("#currentmask").val();
	switch (currentmask) {
	case '16':
	case '8':
		$("#btn_del").show();
	case '4':
		$("#btn_add").show();
		$("#btn_download").show();
	}
	switch (currentmask) {
	case '1':
	case '2':
		$("#btn_download").remove();
		$("#btn_add").remove();
	case '4':
		$("#btn_del").remove();
	}
});

showAuth = function() {
//	$("[name^='btn_']").each(function(){ 
//		$(this).hide();
//	});
//	$('input[name="sysmodel_code"]').each(function(){ 
//		$("a[name='"+$(this).val()+"']").each(function(){ 
//			$(this).show();
//		});
//	}); 
//	return;
	switch (currentmask) {
	case '1':
		$('[data-original-title="修改"]').remove();
	case '2':
		$("#btn_download").remove();
		$("#btn_add").remove();
	case '4':
		$("#btn_del").remove();
		$('[data-original-title="删除"]').remove();
	}

}