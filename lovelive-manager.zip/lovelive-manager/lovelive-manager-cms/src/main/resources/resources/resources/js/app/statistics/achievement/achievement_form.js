/**
 * 定义一个验证对象
 */
var ViewValidator = function() {
	var handleSubmit = function() {
		$('#form_menu').validate({
			errorElement : 'span',
			errorClass : 'help-block',
			focusInvalid : false,
			highlight : function(element) {
				$(element).closest('.form-group').addClass('has-error');
			},
			success : function(label) {
				label.closest('.form-group').removeClass('has-error');
				label.remove();
			},
			errorPlacement : function(error, element) {
				element.parent('div').append(error);
			},
			rules : {
				table_id : {
					required : true,
					digits : true,
					maxlength : 11
				},
				colume_value : {
					required : true,
					maxlength : 100
				}

			},
			messages : {

			}
		});

	}
	return {
		init : function() {
			handleSubmit();
		}
	};

}();

/**
 * 重置form
 */
resetForm = function() {
	$('#form_achievement')[0].reset();
	$('#id').val('');
}

/**
 * 执行保存动作
 */
saveEdit = function() {
	var json = JSON.stringify($('#form_achievement').serializeJSON());
	sysComponents.showHelpMessage(viewLocale.form.save.loading);
	if($('#_maximum').val() >= $('#value').val()){
		$.post(REPORT_ROOT + '/statistics/achievement/save', {
			playerId : $('#_userId').val(),
			data : json
		}, function(data, status) {
			goPage(sysPage.currPage);
			if(data == 0){
				goPage(sysPage.currPage);
				if ($('#_operType').val() == 'edit') {
				sysComponents.showHelpMessage(viewLocale.form.save.success);
				} else if ($('#_operType').val() == 'add') {
					resetForm();
					$('.ui-dialog-title').html(viewLocale.form.title.add);
				}
			} else {
				resetForm();
				sysComponents.showHelpMessage(viewLocale.form.server.error, 'error');
			}
		});
	} else {
		// 输入数据超出范围时,显示提示
		sysComponents.showHelpMessage(viewLocale.form.text.error);
	}
	$('#achievementEdit').modal('hide');
}

/*
 * 显示编辑窗口
 */
showEdit = function(type, value, allValue, rewarded, achieveId) {
	if(rewarded == '已领取'){
		$("#rewarded0").removeAttr('checked');
		$("#rewarded1").attr('checked','checked');
	} else {
		$("#rewarded1").removeAttr('checked');
		$("#rewarded0").attr('checked','checked');
	}
	var playerId = $('#_userId').val();
	resetForm();
	$('#form_achievement').validate().form();
	$('#_operType').val(type);
	if ($('#_operType').val() == 'add') {
		$('.modal-title').html(viewLocale.form.title.add);
		$('#btn_save').show();
	} else {
		if ($('#_operType').val() == 'view') {
			$('.modal-title').html(viewLocale.form.title.view);
			$('#btn_save').hide();
		} else if ($('#_operType').val() == 'edit') {
			$('.modal-title').html(viewLocale.form.title.edit);
			$('#btn_save').show();
		}
		$('#_operType').val('edit');
		$('#id').val(playerId);
		$('#achieveId').val(achieveId);
		$('#value').val(value);
		$("#allValue").text('/' + allValue);
		$('#_maximum').val(allValue);
	}
	$('#achievementEdit').modal('show');
}

/*
 * 获取地址栏后的参数
 */
$(document).ready(function() {
	var url = window.location.search;
	if (url.indexOf("?") != -1) {
		var str = url.substr(1)
		strs = str.split("=");
		if(strs[1].length==0)
			return;
		$('#_userId').val(strs[1]);
		var achievement_id = $('#achievement_id').val();
		var achievement_type = $('#achievement_type').val();
		var perPage = $('#perPage').val();
		showList(strs[1], achievement_id, achievement_type, 1, perPage);
	}
});

// 模糊查询后赋值
callback = function(item) {
	$('#_userId').val(item.playerId);
	$('#_userName').val(item.name);
	var perPage = $('#perPage').val();
	showList(item.playerId,'', '1', 1, perPage);
}

$('#searching').searchPlayerInfo({
    complete: function (playerInfo) {
        callback(playerInfo);
    }
});