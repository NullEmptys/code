sysPage = new SysPage();
var _data;
/**
 * 分页查询
 * 
 * @param {}
 *            search
 * @param {}
 *            currPage
 * @param {}
 *            perPage
 */
showList = function(playerId, type, currencyType, startTime, endTime, currPage, pageSize) {
    $.post(REPORT_ROOT + "/statistics/moneyuse/listForPage",
        {
	    	playerId : playerId,
			type : type,
			currencyType : currencyType,
			startTime : startTime,
			endTime : endTime,
			currPage : currPage - 1,
			pageSize : pageSize
        }, function(data) {
            console.info(data);
            var _tpl = '<tr><td align=\'center\'>{playerId}</td><td align=\'center\'>{playerName}</td><td align=\'center\'>{createTime}</td><td align=\'center\'>{currencyType}</td><td align=\'center\'>{type}</td><td align=\'center\'>{counts}</td><td align=\'center\'>{cause}</td>'
                + '</tr>';
            var _html = '';
            $(data.content).each(function(index, element) {
            	if(element.createTime){
            		var newDate = new Date();
            		newDate.setTime(new Number(element.createTime));
            		element.createTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
            	}
            	if(element.currencyType == 101){
            		element.currencyType = '钻石';
            	} else if(element.currencyType == 102){
            		element.currencyType = '金币';
            	}
            	if(element.type == 1){
            		element.type = '获取';
            	} else if(element.type == 2){
            		element.type = '消耗';
            	}
                _html = _html+nano(_tpl, element);
            });
            $('#moneyuse_list').html(_html);
            // 显示分页
            sysPage.showPage('nav_page', data.totalPages, currPage, data.totalElements);
            $('.bs-tooltip').tooltip();
            showAuth();
        });
}

showList_statistics = function(playerId, type, currencyType, startTime, endTime, currPage, pageSize) {
	$.post(REPORT_ROOT + "/statistics/moneyuse/statistics",
		{	playerId : playerId,
			type : type,
			currencyType : currencyType,
			startTime : startTime,
			endTime : endTime,
			currPage : currPage - 1,
			pageSize : pageSize
		},function(data) {
			var _tpl = '<tr><td align=\'center\'>{gold_get_statistics}</td><td align=\'center\'>{gold_use_statistics}</td><td align=\'center\'>{diamond_get_statistics}</td><td align=\'center\'>{diamond_use_statistics}</td>'
		        + '</tr>';
			var _html = '';
			 $(data).each(function (index, element) {
		            _html = _html+nano(_tpl, element);
		        })
			$('#statistics_list').html(_html);
		});
}

goPage = function(currPage) {
	var _perPage = $('#perPage').val();
	showList($('#_userId').val(), $('#searchType_use').val(), $('#currencyType').val(), $('#startDate').val(), $('#endDate').val(), currPage, $('#perPage').val());
}

showDel = function(ids) {
	$('.ui-dialog-title').html(viewLocale.prompt)
	delIds = ids;
	$('#dialog_message').modal('show');
}

showDels = function() {
	$('.ui-dialog-title').html(viewLocale.prompt)
	delIds = '';
	var _checks = $("input[name='check']");
	$(_checks).each(function(index, element) {
		if ($(element).prop('checked')) {
			delIds = delIds + $(element).prop('value') + ',';
		}
	});

	if (delIds.length == 0) {
		sysComponents.showHelpMessage(viewLocale.form.del.sel);
		return;
	} else {
		$('#dialog_message').modal('show');
	}
}

/**
 * 执行删除动作
 * 
 * @param {}
 *            id
 */
doDel = function() {
	// $('#dialog_message').dialog('close');
	sysComponents.showHelpMessage(viewLocale.form.del.loading);
	var _l = (delIds + '').split(',').length;
	_l = (_l > 1) ? (_l - 1) : _l;
	$.post(REPORT_ROOT + "/statistics/moneyuse/del", {
		ids : delIds
	}, function(data) {
		if (data.num == _l) {
			sysComponents.showHelpMessage(viewLocale.form.del.success);
		} else if (data.num == 0) {
			sysComponents.showHelpMessage(viewLocale.form.del.fail, 'error');
		} else {
			sysComponents.showHelpMessage(viewLocale.form.del.subSuccess
					+ data.num);
		}
		goPage(sysPage.currPage);
	});
	$('#dialog_message').modal('hide');
}