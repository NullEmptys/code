
/**
 *初始化组件
 */
initComponents = function() {
    var group;

    sysComponents.getAllItem('attachId1');
    sysComponents.getAllItem('attachId2');

    $('#btn_new').click(function() {
        mailForm.showEdit('add');
    });

    $('#btn_save').click(function() {
        if ($('#form_menu').valid()) {
            mailForm.saveEdit();
        }
    });

    if ($('#delaySend').is(':checked')) {
        $("#sendNow").show();
    } else {
        $("#expirationTime").attr('value', new Date().Format('yyyy-MM-dd HH:mm:ss'));
        $("#postTime").attr('value', new Date().Format('yyyy-MM-dd HH:mm:ss'));
        $("#sendNow").hide();
    }

    $('#delaySend').click(function() {
        if ($('#delaySend').is(':checked')) {
            $("#expirationTime").attr('value', '');
            $("#postTime").attr('value', '');
            $("#sendNow").show();
        } else {
            $("#expirationTime").attr('value', new Date().Format('yyyy-MM-dd HH:mm:ss'));
            $("#postTime").attr('value', new Date().Format('yyyy-MM-dd HH:mm:ss'));
            $("#sendNow").hide();
        }
    });

    $("#expirationTime").click(function() {
        if ($("#postTime").val() === '') {
            $("#expirationTime").datetimepicker('setStartDate', new Date());
        } else {
            $("#expirationTime").datetimepicker('setStartDate', $("#postTime").val());
        }
    });

    $("#postTime").click(function() {
        if ($("#expirationTime").val() !== '') {
            $("#postTime").datetimepicker('setEndDate', $("#expirationTime").val());
        }
    });

    if ($('#attachments').is(':checked')) {
        $("#attachs").show();
    } else {
        $("#attachs").hide();
    }

    $('#attachments').click(function() {
        if ($('#attachments').is(':checked')) {
            $("#attachs").show();
        } else {
            $("#attachs").hide();
        }
    });

    $('#btn_del').click(function() {
        mail_list.showDels();
    });

    $('#btn_remove').click(function() {
        mail_list.doDel();
    });

    $('#btn_search').click(function() {
        mail_list.showList(1, $('#perPage').val());
    });

    $('#input_search').bind('keypress', function(event) {
        if (event.keyCode == "13") {
            mail_list.showList(1, $('#perPage').val());
        }
    });

    mailForm.checkValue();

    $("#send").click(function() {
        if ($('#send').is(':checked')) {
            //mailForm.send();
            $("#dialog_message_for_send").modal('show');
        } else {
            $("#dialog_message_for_send").modal('hide');
        }
    });

    $("#btn_cls").click(function() {
        mailForm.cancle();
    });

    $("#btn_close").click(function() {
        mailForm.resetForm();
        $('#menuEdit').hide();
        $('#mail_list').show();
    });

    $('#perPage').change(function() {
        mail_list.showList(1, $('#perPage').val());
    });
    
    $('#category_1').change(function () {
        editChange("category_1");
    });
    $('#category_2').change(function () {
        editChange("category_2");
    });
    $('#category_3').change(function () {
        editChange("category_3");
    });
    $('#category_4').change(function () {
        editChange("category_4");
    });
    
    $('#cdTimes_1').change(function () {
    	if("" == $('#cdTimes_1 option:selected').val()){
    		$("#cdTime_NtoB_1").show();
    	} else if(-1 == $('#cdTimes_1 option:selected').val()){
    		$("#cdTime_NtoB_1").hide();
    	}
    });
    
    $('#cdTimes_2').change(function () {
    	if("" == $('#cdTimes_2 option:selected').val()){
    		$("#cdTime_NtoB_2").show();
    	} else if(-1 == $('#cdTimes_2 option:selected').val()){
    		$("#cdTime_NtoB_2").hide();
    	}
    });

    $('#checkAll').click(function() {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });

    $("#menuEdit").hide();
    sysComponents.getItemByCategoryType('item_id_item_1', 1);
    sysComponents.getItemByCategoryType('item_id_item_2', 1);

    mail_list.showList(1, 20);

    ViewValidator.init();
};