var operType = "";
/**
 * 定义一个验证对象
 */
var ViewValidator = function () {
    var handleSubmit = function () {
        $('#form_menu').validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            highlight: function (element) {
                $(element).closest('.form-group').addClass('has-error');
            },
            success: function (label) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();
            },
            errorPlacement: function (error, element) {
                element.parent('div').append(error);
            },
            rules: {
                contentDetail: {
                    maxlength: 255
                },
                replyContent: {
                    maxlength: 255
                }

            },
            messages: {}
        });

    }
    return {
        init: function () {
            handleSubmit();
        }
    };

}();

/**
 * 重置form
 */
resetForm = function () {
    $('#form_menu')[0].reset();
    $('#id').val('');
}

/**
 * 执行保存动作
 */
saveEdit = function () {
    var json = JSON.stringify($('#form_menu').serializeJSON());
    sysComponents.showHelpMessage(viewLocale.form.save.loading);
    $.post(REPORT_ROOT + '/statistics/girlModel/save', {
        data: json
    }, function (data, status) {
        goPage(sysPage.currPage);
        if (operType == 'edit') {
            sysComponents.showHelpMessage(viewLocale.form.save.success);
        } else if (operType == 'add') {
            resetForm();
            $('.ui-dialog-title').html(viewLocale.form.title.add);
        }
    });
    $('#menuEdit').modal('hide');
}

/**
 * 显示编辑窗口
 *
 * @@param {} type：add,edit,view
 * @param {}
 *            id
 * @param {}
 *            pid
 */
showEdit = function (type, id) {
    resetForm();
    $('#form_menu').validate().form();
    operType = type;
    if (operType == 'add') {
        $('.modal-title').html('新增');
        $('#btn_save').show();
    } else {
        if (operType == 'view') {
            $('.modal-title').html(viewLocale.form.title.view);
            $('#btn_save').hide();
        } else if (operType == 'edit') {
            $('.modal-title').html('修改');
            $('#btn_save').show();
        }
        operType = 'edit';
        $.post(REPORT_ROOT + '/statistics/girlModel/get', {
            id: id
        }, function (data) {
            sysComponents.setValues(data);
        });
        $('#id').val(id);
    }
    $('#menuEdit').modal('show');
}
