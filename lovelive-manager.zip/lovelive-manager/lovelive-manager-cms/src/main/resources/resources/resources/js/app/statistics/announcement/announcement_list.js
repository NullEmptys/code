/**
 * Created by Administrator on 2016/4/22 0022.
 */
var _data;
var _text = 'ID,公告标题,创建时间,公告内容,挡板类型,公告类型,发布人,最后修改人,公告背景图片,发布状态,公告开始时间,公告结束时间,广播开始时间,广播结束时间,优先级';
sysPage = new SysPage();

var announcement_list = function() {
	return {

		// 线下分页查询
		showList : function(currPage, pageSize) {
			$
					.post(
							REPORT_ROOT + "/statistics/announcement/listForPage",
							{
								currPage : currPage - 1,
								pageSize : pageSize
							},
							function(data) {
								var _tpl = '<tr><td style="text-align:center; width: 160px;">{createTime}</td><td style="text-align:center; width: 80px;">{type}</td><td style="text-align:center; width: 90px;">{category}</td><td style="text-align:center; width: 60px;">{sequence}</td><td style="text-align:center; width: 80px;">{title}</td><td style="text-align:center; width: 80px;">{backGroundId}</td><td style="text-align:center; width: 50px;"><a title="查看" href="javascript:announcement_list.showDetail(\'{title}\',\'{content}\')">查看</a></td><td style="text-align:left; width: 190px;">{startTime}&nbsp;\~<br/>\&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{endTime}</td><td style="text-align:left;  width: 190px;">{broadcastStartTime}&nbsp;\~<br/>\&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\&nbsp;{broadcastEndTime}</td><td style="text-align:center; width: 90px;">{lastAccountName}</td><td style="text-align:center; width: 70px;">{accountName}</td><td style="text-align:center; width: 70px;">\{isSend}\</td>'
										+ '<td style="text-align:center; width: 120px;"><span class="btn-group">'
										+ '<a title="'
										+ viewLocale.form.title.edit
										+ '" class="btn bs-tooltip" href="javascript:announcement_form.showEdit(\'edit\',\'local\',{id});" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
										+ '<a title="'
										+ viewLocale.form.title.del
										+ '" class="btn bs-tooltip" href="javascript:announcement_list.showDel({id},\'local\');" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></a>'
										+ '</span></td></tr>';
								var _html = '';
								$(data.pageItems)
										.each(
												function(index, element) {
													// 时间格式的转换
													element = announcement_list.time(element);
													if (element.type) {
														if (element.type == '1') {
															element.type = '文字';
														} else if (element.type == '2') {
															element.type = '图片';
														}
													}
													if (element.category) {
														if (element.category == '1') {
															element.category = '外部挡板';
															element.sequence = '';
														} else if (element.category == '2') {
															element.category = '内部挡板';
														}
													}
													if (element.isSend) {
														if (element.isSend == 1) {
															element.isSend = '<a title="发送" class="btn bs-tooltip" href="javascript:announcement_list.showSend('+ element.id +');" data-original-title="Send">未发送</a>';
														} else if (element.isSend == 2) {
															element.isSend = '已发送';
														}
													}
													_html = _html + nano(_tpl, element);
												})
								$('#local_menu_list').html(_html);
								// 显示分页
								sysPage.showPage('local_nav_page', data.pageCount, currPage, data.total, '', 'local_nav_page');
								$('.bs-tooltip').tooltip();
							});
		},

		// 线上分页查询
		showList_server : function(currPage, pageSize) {
			$
					.post(
							REPORT_ROOT + "/statistics/announcement/listForPage_server",
							{
								currPage : currPage - 1,
								pageSize : pageSize
							},
							function(data) {
								var _tpl = '<tr><td style="text-align:center; width: 70px;">{type}</td><td style="text-align:center; width: 70px;">{category}</td><td style="text-align:center; width: 60px;">{sequence}</td><td style="text-align:center; width: 180px;">{title}</td><td style="text-align:center; width: 60px;">{backGroundId}</td><td style="text-align:center; "><a title="查看" href="javascript:announcement_list.showDetail(\'{title}\',\'{content}\')">查看</a></td><td style="text-align:left; width: 270px;">{startTime}&nbsp;\~\{endTime}</td><td style="text-align:left; width: 270px;">{broadcastStartTime}&nbsp;\~\&nbsp;{broadcastEndTime}</td>'
										+ '<td style="text-align:center; width: 100px;"><span class="btn-group">'
										+ '<a title="'
										+ viewLocale.form.title.edit
										+ '" class="btn bs-tooltip" href="javascript:announcement_form.showEdit(\'edit\',\'server\',{id});" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
										+ '<a title="'
										+ viewLocale.form.title.del
										+ '" class="btn bs-tooltip" href="javascript:announcement_list.showDel({id},\'server\');" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></a>'
										+ '</span></td></tr>';
								var _html = '';
								$(data.pageItems)
										.each(
												function(index, element) {
													// 时间格式的转换
													element = announcement_list.time_server(element);
													if (element.type) {
														if (element.type == '1') {
															element.type = '文字';
														} else if (element.type == '2') {
															element.type = '图片';
														}
													}
													if (element.category) {
														if (element.category == '1') {
															element.category = '外部挡板';
															element.sequence = '';
														} else if (element.category == '2') {
															element.category = '内部挡板';
														}
													}
													_html = _html + nano(_tpl, element);
												})
								$('#server_menu_list').html(_html);
								// 显示分页
								sysPage.showPage('server_nav_page', data.pageCount, currPage, data.total, '', 'server_nav_page');
								$('.bs-tooltip').tooltip();
							});
		},

		// 确认发送
		showSend : function(id) {
			$('.ui-dialog-title').html(viewLocale.prompt)
			$('#_oldId').val(id);
			$('#dialog_message_for_send').modal('show');
		},

		// 执行发送
		doSend : function(){
			$.post(REPORT_ROOT + '/statistics/announcement/get', {
				id : $('#_oldId').val()
			}, function(data) {
				_data = data;
				// 时间格式的转换
				_data = announcement_list.time(_data);
				// 发送公告
				announcement_list.doSend_send();
			});
			$('#dialog_message_for_send').modal('hide');
		},

		// 发送公告
		doSend_send : function(){
			var json = JSON.stringify(_data);
			$.post(REPORT_ROOT + '/statistics/announcement/send', {
				data : json
			}, function(data) {
				if(data == 0){
					sysComponents.showHelpMessage(viewLocale.form.send.success);
					// 修改发送状态
					_data.isSend = '2';
					announcement_list.doSend_isSend();
				} else {
					sysComponents.showHelpMessage(viewLocale.form.send.fail);
				}
			});
		},

		// 修改发送状态
		doSend_isSend : function(){
			var json = JSON.stringify(_data);
			$.post(REPORT_ROOT + '/statistics/announcement/save', {
				data : json
			}, function(data, status) {
				goPage(sysPage.currPage, "server_nav_page");
				goPage(sysPage.currPage, "local_nav_page");
				if ($('#operType').val() == 'edit') {
					sysComponents.showHelpMessage(viewLocale.form.save.success);
				} else if ($('#operType').val() == 'add') {
					announcement_form.resetForm();
					$('.ui-dialog-title').html(viewLocale.form.title.add);
				}
			});
		},

		// 时间格式的转换
		time : function(data){
			if (data.broadcastStartTime) {
				var newDate = new Date(data.broadcastStartTime);
				data.broadcastStartTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
			}
			if (data.broadcastEndTime) {
				var newDate = new Date(data.broadcastEndTime);
				data.broadcastEndTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
			}
			if (data.startTime) {
				var newDate = new Date(data.startTime);
				data.startTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
			}
			if (data.endTime) {
				var newDate = new Date(data.endTime);
				data.endTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
			}
			if (data.createTime) {
				var newDate = new Date(data.createTime);
				data.createTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
			}
			return data;
		},

		// 时间格式的转换
		time_server : function(data){
			if (data.broadcastStartTime) {
				data.broadcastStartTime = data.broadcastStartTime.substring(0,19);
			}
			if (data.broadcastEndTime) {
				data.broadcastEndTime = data.broadcastEndTime.substring(0,19);
			}
			if (data.startTime) {
				data.startTime = data.startTime.substring(0,19);
			}
			if (data.endTime) {
				data.endTime = data.endTime.substring(0,19);
			}
			return data;
		},

		// 点击“查看”，显示公告详情
		showDetail : function(title, content) {
			$('#detail_title').html(title);
			$('#detail_content').html(content);
			$('#announcement_detail').modal('show');
		},

		// 显示确认删除框
		showDel : function(id, form) {
			$('#_form').val(form);
			$('.ui-dialog-title').html(viewLocale.prompt);
			$('#delId').val(id);
			$('#dialog_announcement_delete').modal('show');
		},

		// 线下执行删除操作
		doDel : function() {
			sysComponents.showHelpMessage(viewLocale.form.del.loading);
			$.post(REPORT_ROOT + "/statistics/announcement/del", {
				id : $('#delId').val()
			}, function(data) {
				if (data == 0) {
					sysComponents.showHelpMessage(viewLocale.form.del.success);
				} else if (data == 1) {
					sysComponents.showHelpMessage(viewLocale.form.del.fail, 'error');
				}
				goPage(sysPage.currPage, "local_nav_page");
			});
			$('#dialog_announcement_delete').modal('hide');
		},

		// 执行删除操作
		doDel_server : function() {
			sysComponents.showHelpMessage(viewLocale.form.del.loading);
			$.post(REPORT_ROOT + "/statistics/announcement/del_server", {
				id : $('#delId').val()
			}, function(data) {
				if (data == 0) {
					sysComponents.showHelpMessage(viewLocale.form.del.success);
				} else if (data == 1) {
					sysComponents.showHelpMessage(viewLocale.form.del.fail, 'error');
				}
				goPage(sysPage.currPage, "server_nav_page");
			});
			$('#dialog_announcement_delete').modal('hide');
		},

		//历史导出
		doDown : function() {
			sysComponents.showHelpMessage(viewLocale.download);
			window.location.href = "/statistics/announcement/down";
			// $.post(REPORT_ROOT + "/statistics/announcement/down", function(data){
			// 	window.location.href = ""
			// });
			$('#down_show').modal('hide');
		},

		doDown2 : function() {
			$
			.post(
					REPORT_ROOT + "/statistics/announcement/getAll",
					function(data) {
						$(data)
						.each(
								function(index, element) {
									_text = _text + '\n' + element.id +","+element.title  +","+ element.createTime +","+ element.content +","+ element.category  +","+element.type +","+ element.publisher+","+  element.lastEditor +","+ element.backGroundId +","+ element.isSend +","+ element.startTime +","+ element.endTime +","+ element.broadcast_startTime +","+ element.broadcastEndTime +","+ element.sequence;
								})
					});
			announcement_list.Down();
			$('#down_show').modal('hide');
		},

		Down : function() {
			document.getElementById("btn_download").onclick = function(event) {
				event.preventDefault();
				var BB = self.Blob;
				saveAs(new BB([ "\ufeff"
						+ _text ] //\ufeff防止utf8 bom防止中文乱码
				, {
					type : "text/plain;charset=utf8"
				}), "announcements.xlsx");
			};
		},

	}
} ();


// 下页动作
goPage = function(currPage, pageName) {
	if(pageName == 'local_nav_page'){
		var _local_perPage = $('#local_perPage').val();
		announcement_list.showList(currPage, _local_perPage);
	} else {
		var _server_perPage = $('#server_perPage').val();
		announcement_list.showList_server(currPage, _server_perPage);
	}
}