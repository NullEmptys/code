var operType = "";
/**
 * 定义一个验证对象
 */
var ViewValidator = function() {
	var handleSubmit = function() {
		// $.validator.addMethod("isUrl",function(value,element){
		// var pattern =
		// /(\/\w+.htm?(([a-zA-Z0-9\&%_\.-~-]*)|(?=[^a-zA-Z0-9\.])))+$/;
		// return this.optional(element)||(pattern.test(value));
		// },"请输入合法Url");

		$('#form_menu').validate({
			errorElement : 'span',
			errorClass : 'help-block',
			focusInvalid : false,
			highlight : function(element) {
				$(element).closest('.form-group').addClass('has-error');
			},
			success : function(label) {
				label.closest('.form-group').removeClass('has-error');
				label.remove();
			},
			errorPlacement : function(error, element) {
				element.parent('div').append(error);
			},
			rules : {
				name : {
					required : true,
					maxlength : 100,
					remote : {
						url : REPORT_ROOT + '/systems/menu/validName',
						type : "post",
						dataType : "json",
						data : {
							name : function() {
								return $("#name").val();
							},
							id : function() {
								return $("#id").val();
							}
						}
					}
				},
				page : {
					required : true,
					maxlength : 45
				},
				url : {
					required : true,
					maxlength : 150
				},
				icons : {
					maxlength : 45
				},
				seq : {
					digits : true,
					maxlength : 11
				},
				descr : {
					maxlength : 256
				}

			},
			messages : {
				name : {
					remote : viewLocale.form.menu.message.name
				}
			}
		});

	}
	return {
		init : function() {
			handleSubmit();
		}
	};

}();

/**
 * 重置form
 */
resetForm = function() {
	$('#form_menu')[0].reset();
	$('#descr').val('');
	$('#id').val('');
}

/**
 * 执行保存动作
 */
saveEdit = function() {
	// $('#name').prop("disabled", false);
	var json = JSON.stringify($('#form_menu').serializeJSON());
	sysComponents.showHelpMessage(viewLocale.form.save.loading);
	$.post(REPORT_ROOT + '/systems/menu/save', {
		data : json
	}, function(data, status) {
		goPage(sysPage.currPage);
		if (operType == 'edit') {
			sysComponents.showHelpMessage(viewLocale.form.save.success);
		} else if (operType == 'add') {
			resetForm();
			$('.ui-dialog-title').html(viewLocale.form.title.add);
		}
	});
	$('#menuEdit').modal('hide');
}

/**
 * 显示编辑窗口
 * 
 * @@param {} type：add,edit,view
 * @param {}
 *            id
 * @param {}
 *            pid
 */
showEdit = function(type, id) {
	resetForm();
	$('#form_menu').validate().form();
	operType = type;
	if (operType == 'add') {
		$('.modal-title').html(viewLocale.form.title.add);
		$('#btn_save').show();
	} else {
		if (operType == 'view') {
			$('.modal-title').html(viewLocale.form.title.view);
			$('#btn_save').hide();
		} else if (operType == 'edit') {
			$('.modal-title').html(viewLocale.form.title.edit);
			$('#btn_save').show();
		}
		operType = 'edit';
		$.post(REPORT_ROOT + '/systems/menu/get', {
			id : id
		}, function(data) {
			sysComponents.setValues(data);
		});
		$('#id').val(id);
	}
	$('#menuEdit').modal('show');
}
