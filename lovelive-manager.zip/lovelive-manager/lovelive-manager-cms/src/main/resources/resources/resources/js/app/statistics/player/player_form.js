var operType = "";
/**
 * 定义一个验证对象
 */
var ViewValidator = function () {
    var handleSubmit = function () {
        $.validator.addMethod("chgold", function (value, element) {
            var returnVal = false;
            var changeGold = $('input[name="changeGold"]:checked').attr("value");
            var changeGoldVal = $('#changeGoldVal').attr("value");
            var gold = $("#glod").text();

            if (((changeGoldVal !== '0' || changeGoldVal !== '') && (changeGold != '' || changeGold !== undefined)
                && ((Number(gold) > Number(changeGoldVal) && changeGold === '2') || changeGold === '1') && Number(changeGoldVal) >= 0)
                || (changeGold === undefined && (changeGoldVal === '0' || changeGoldVal === '' || changeGoldVal === undefined))) {
                returnVal = true;
            }
            return returnVal;
        }, "请选择增加或减少金币后，填入更改的金币数");

        $.validator.addMethod("chmoney", function (value, element) {
            var returnVal = false;
            var changeMoney = $('input[name="changeMoney"]:checked').val();
            var changeMoneyVal = $('#changeMoneyVal').val();
            var money = $("#money").text();

            if (((changeMoneyVal !== '' || changeMoneyVal !== '0') && (changeMoney != '' || changeMoney !== undefined)
                && ((Number(money) > Number(changeMoneyVal) && changeMoney === '2') || changeMoney === '1') && Number(changeMoneyVal) >= 0)
                || (changeMoney === undefined && (changeMoneyVal === '' || changeMoneyVal === '0' || changeMoneyVal === undefined))) {
                returnVal = true;
            }
            return returnVal;
        }, "请选择增加或减少钻石后，填入更改的钻石数");

        $.validator.addMethod("chtili", function (value, element) {
            var returnVal = false;
            var changeTili = $('input[name="changeTili"]:checked').val();
            var changeTiliVal = $('#changeTiliVal').val();
            var tili = $("#tili").text();

            if (((changeTiliVal !== '' || changeTiliVal !== '0') && (changeTili != '' || changeTili !== undefined)
                && ((Number(tili) > Number(changeTiliVal) && changeTili === '2') || changeTili === '1') && Number(changeTiliVal) >= 0)
                || (changeTili === undefined && (changeTiliVal === '' || changeTiliVal === '0' || changeMoneyVal === undefined))) {
                returnVal = true;
            }
            return returnVal;
        }, "请选择增加或减少体力后，填入更改的体力值");

        $.validator.addMethod("chtp", function (value, element) {
            var playerType = $("#playerType").val();
            var girlId = $("#girlId").val();
            console.info(girlId);
            if(playerType == "2"){
                return !!(girlId !== undefined && girlId !== '')
            }else{
                return true;
            }

        }, "请输入模特ID");

        $('#player_form').validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: true,
            highlight: function (element) {
                $(element).closest('.form-group').addClass('has-error');
            },
            success: function (label) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();
            },
            errorPlacement: function (error, element) {
                element.parent('div').append(error);
            },
            rules: {
                changeGoldVal: {
                    chgold: true,
                    min: 0
                },
                changeMoneyVal: {
                    chmoney: true,
                    min: 0
                },
                changeTiliVal: {
                    chtili: true,
                    min: 0
                },
                name: {
                    required: true
                },
                girlId: {
                    chtp: true
                }
            },
            messages: {
                name: {
                    required: "请输入用户名"
                }
            }
        });
    };
    return {
        init: function () {
            handleSubmit();
        }
    };
}();

if (!PlayerForm) {
    var PlayerForm = function () {};
    PlayerForm.prototype = {
        resetForm: function () {
            $('#player_form')[0].reset();
            $('#id').val('');
        },

        callback: function (item) {
            player_form.resetForm();
            console.info(item);
            if(item){
                $("#playerId").attr("value", item.playerId);
                $("#createTime").attr("value", item.createTime);
                $("#name").attr("value", item.name);
                $("#registIp").attr("value", item.registIp);
                $("#glod").html(item.glod);
                $("#lastLoginTime").attr("value", item.lastLoginTime);
                $("#money").html(item.money);
                $("#lastLoginIp").attr("value", item.lastLoginIp);
                $("#level").attr("value", item.level);
                $("#lastLogoutTime").attr("value", item.lastLogoutTime);
                $("#achieveValue").attr("value", item.achieveValue);
                $("#totalLoginCounts").attr("value", item.totalLoginCounts);
                $("#state").val(item.state);
                $("#totalLoginTimeCounts").attr("value", item.totalLoginTimeCounts);
                $("#stateCdTime").attr("value", item.stateCdTime);
                $("#channelId").attr("value", item.channelName);
                if(item.playerType == "2"){
                    $("#girl").show();
                    $("#girlId").val(item.girlId);
                }else{
                    $("#girl").hide();
                }
                $("#playerType").val(item.playerType);
                $("#tili").text(item.tili);
                $("input[name='tili']").val(item.tili);
                //$("#tili").text(11);
                //$("input[name='tili']").val(11);
            }
        },

        update: function () {
            if ($('#player_form').validate().form()) {
                var json = JSON.stringify($('#player_form').serializeJSON());
                sysComponents.showHelpMessage(viewLocale.form.save.loading);
                $.post(REPORT_ROOT + '/statistics/player/update', {
                    data: json
                }, function (data) {
                    if (typeof (data) === 'string' && data === '') {
                        sysComponents.showHelpMessage(viewLocale.form.save.fail);
                    } else {
                        try {
                            data = JSON.parse(data);
                            sysComponents.showHelpMessage(viewLocale.form.save.success);
                            player_form.callback(data);
                        } catch (error) {
                            //console.error(error);
                            if(data !== null){
                                sysComponents.showHelpMessage(data, "error");
                            }else{
                                data = null;
                                sysComponents.showHelpMessage(viewLocale.form.save.fail);
                            }
                        }
                    }
                });
            } else {
                console.info("something wrong!");
            }
            $('#alter_message').modal('hide');
        }
    };
}


if (!player_form) {
    var player_form = new PlayerForm();
}

$('#searchId').searchPlayerInfo({
    complete: function (playerInfo) {
        player_form.callback(playerInfo);
    }
});
