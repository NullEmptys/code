var operType = "";
/**
 * 定义一个验证对象
 */
var ViewValidator = function () {
    var handleSubmit = function () {
        $('#form_menu').validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            highlight: function (element) {
                $(element).closest('.form-group').addClass('has-error');
            },
            success: function (label) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();
            },
            errorPlacement: function (error, element) {
                element.parent('div').append(error);
            },
            rules: {
                contentDetail: {
                    maxlength: 255
                },
                replyContent: {
                    maxlength: 255
                }

            },
            messages: {}
        });

    }
    return {
        init: function () {
            handleSubmit();
        }
    };

}();

/**
 * 重置form
 */
resetForm = function () {
    $('#form_menu')[0].reset();
    $('#status').val('');
    $('#lastEditor').val('');
    $('#publisher').val('');
    $('#description').val('');
    $('#id').val('');
};

resetRemoteForm = function () {
    $('#form_remote_edit')[0].reset();
    $('#remoteActivity_id').val('');
};

/**
 * 执行保存动作
 */
saveEdit = function () {
    var json = JSON.stringify($('#form_menu').serializeJSON());
    sysComponents.showHelpMessage(viewLocale.form.save.loading);
    $.post(REPORT_ROOT + '/statistics/activity/save', {
        data: json
    }, function (data, status) {
        activity_list.showHistoryList(1, 20);
        if (operType == 'edit') {
            sysComponents.showHelpMessage(viewLocale.form.save.success);
        } else if (operType == 'add') {
            resetForm();
            $('.ui-dialog-title').html(viewLocale.form.title.add);
        }
    });
    $('#menuEdit').modal('hide');
};

/**
 * 显示编辑窗口
 *
 * @@param {} type：add,edit,view
 * @param {}
 *            id
 * @param {}
 *            pid
 */
showEdit = function (type, id) {
    resetForm();
    $('#form_menu').validate().form();
    operType = type;
    if (operType == 'add') {
        $('.modal-title').html('新增');
        $('#btn_save').show();
    } else {
        if (operType == 'view') {
            $('.modal-title').html(viewLocale.form.title.view);
            $('#btn_save').hide();
        } else if (operType == 'edit') {
            $('.modal-title').html('修改');
            $('#btn_save').show();
        }
        operType = 'edit';
        $.post(REPORT_ROOT + '/statistics/activity/get', {
            id: id
        }, function (data) {
            if (data.broadcastStartTime) {
                var newDate = new Date(
                    data.broadcastStartTime);
                data.broadcastStartTime = newDate
                    .Format('yyyy/MM/dd HH:mm:ss');
            }
            if (data.broadcastEndTime) {
                var newDate = new Date(
                    data.broadcastEndTime);
                data.broadcastEndTime = newDate
                    .Format('yyyy/MM/dd HH:mm:ss');
            }
            if (data.startTime) {
                var newDate = new Date(
                    data.startTime);
                data.startTime = newDate
                    .Format('yyyy/MM/dd HH:mm:ss');
            }
            if (data.endTime) {
                var newDate = new Date(
                    data.endTime);
                data.endTime = newDate
                    .Format('yyyy/MM/dd HH:mm:ss');
            }
            sysComponents.setValues(data);
        });
        $('#id').val(id);
    }
    $('#menuEdit').modal('show');
};

showRemoteEdit = function (id) {
    resetRemoteForm();
    $('#form_remote_edit').validate().form();

    $('.modal-title').html('修改');
    $('#btn_remote_save').show();
    operType = 'edit';
    $.post(REPORT_ROOT + '/statistics/activity/getRemoteActivity', {
        id: id
    }, function (data) {
        for (var key in data) {
            var _obj = $('#remoteActivity_' + key);
            if (_obj.attr('type') == 'checkbox') {
                if (data[key] == 1) {
                    _obj.prop("checked", "checked");
                }
            } else {
                if (_obj.is('input') || _obj.is('select')) {
                    _obj.val(data[key]);
                } else if (_obj.is('textarea')) {
                    _obj.text((data[key] == null) ? '' : data[key]);
                    _obj.val((data[key] == null) ? '' : data[key]);
                }
            }
        }
    });
    $('#remoteActivity_id').val(id);
    $('#remoteActivityEdit').modal('show');
};

saveRemoteEdit = function () {
    var json = JSON.stringify($('#form_remote_edit').serializeJSON());
    sysComponents.showHelpMessage(viewLocale.form.save.loading);
    $.post(REPORT_ROOT + '/statistics/activity/updateRemoteActivity', {
        data: json
    }, function (data, status) {
        activity_list.showRemoteList();
        sysComponents.showHelpMessage(viewLocale.form.save.success);
    });
    $('#remoteActivityEdit').modal('hide');
};

saveReward = function () {
    var json = JSON.stringify($('#form_reward').serializeJSON());
    console.log(json);
    sysComponents.showHelpMessage(viewLocale.form.save.loading);
    $.post(REPORT_ROOT + '/statistics/activity/saveReward', {
        data: json
    }, function (data, status) {
        sysComponents.showHelpMessage(viewLocale.form.save.success);
    });
    $('#rewardEdit').modal('hide');
};

//编辑项下拉框的的变换
editChange = function () {
    if ($('#rewardType option:selected').val() != 11 && $('#rewardType option:selected').val() != 11) {
        $('#item_id').html('');
        sysComponents.getItemByCategoryType('item_id', $('#rewardType option:selected').val());
//		$('#_category').val('0');
//		$("#item_id_NtoB").show();
//		$("#num_NtoB").show();
//		$("#cdTimes_NtoB").hide();
//		$("#cdTime_NtoB").hide();
    } else {
        $('#item_id').html('');
    }
};



