var download = function () {
    var playerId = 0;
    var name = "";
    if($("#playerValueType").val() == 1){
        playerId = $("#playerValue").val();
    }else{
        name = $("#playerValue").val();
    }
    window.location.href = "/statistics/commitbug/download?playerId="+playerId+"&name="+name+
            "&context="+$("#context").val()+"&beginTime="+$("#beginTime").val()+"&endTime="+$("#endTime").val();
};