//var operType = "";
//var _userId = "";
//var _userName = "";

/**
 * 重置form
 */
resetForm = function() {
	$('#form_propertygetanduse')[0].reset();
	$('#id').val('');
}

/*
 * 获取地址栏后的参数
 */
$(document).ready(function() {
	var url = window.location.search;
	if (url.indexOf("?") != -1) {
		var str = url.substr(1)
		strs = str.split("=");
		if(strs[1].length==0)
			return;
		$('#_userId').val(strs[1]);
		showList(strs[1], $('#searchType_use').val(), $('#startDate').val(), $('#endDate').val(), 1, $('#perPage').val());
	}
});

//模糊查询后赋值
callback = function(item) {
	$('#_userId').val(item.playerId);
	$('#_userName').val(item.name);
	showList($('#_userId').val(),'', '', '', 1, $('#perPage').val());
}

$('#searching').searchPlayerInfo({
    complete: function (playerInfo) {
        callback(playerInfo);
    }
});
