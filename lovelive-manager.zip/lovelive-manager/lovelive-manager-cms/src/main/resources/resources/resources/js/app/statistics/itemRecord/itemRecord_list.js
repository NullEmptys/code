sysPage = new SysPage();
/**
 * 分页查询
 * 
 * @param {}
 *            search
 * @param {}
 *            currPage
 * @param {}
 *            perPage
 */
showList = function(id, type, startDate, endDate, currPage, pageSize) {
	$.post(REPORT_ROOT + "/statistics/itemRecord/listForPage",
		{	id : id,
			type : type,
			startDate : startDate,
			endDate : endDate,
			currPage : currPage - 1,
			pageSize : pageSize
        }, function(data) {
            console.info(data);
        	var _tpl = '<tr><td align=\'center\'>{playerId}</td><td align=\'center\'>{playerName}</td><td align=\'center\'>{createTime}</td><td align=\'center\'>{itemId}</td><td align=\'center\'>{itemName}</td><td align=\'center\'>{type}</td><td align=\'center\'>{counts}</td><td align=\'center\'>{cause}</td>'
        		+ '</tr>';
            var _html = '';
            $(data.content).each(function(index, element) {
            	if (element.createTime) {
    				var newDate = new Date();
    				newDate.setTime(new Number(
    						element.createTime));
    				element.createTime = newDate
    						.Format('yyyy-MM-dd HH:mm:ss');
    			}
    			if (element.type == 1) {
    				element.type = '获得';
    			} else if (element.type == 2) {
    				element.type = '消耗';
    			}
                _html = _html+nano(_tpl, element);
            });
            $('#menu_list').html(_html);
            // 显示分页
            sysPage.showPage('nav_page', data.totalPages, currPage, data.totalElements);
            $('.bs-tooltip').tooltip();
            showAuth();
        });
}

goPage = function(currPage) {
	var _perPage = $('#perPage').val();
	showList($('#_userId').val(), $('#searchType_use').val(), $('#startDate').val(), $('#endDate').val(), currPage, _perPage);
}
