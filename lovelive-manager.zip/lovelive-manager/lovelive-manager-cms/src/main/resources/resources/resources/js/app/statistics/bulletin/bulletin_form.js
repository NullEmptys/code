// var item_playerId;
// if (!playerInfo_search) {
//     var playerInfo_search = new PlayerInfo.Search();
// }
// if (playerInfo_search.beSearch) {
//     playerInfo_search.beSearch("#playerId", function(item) {
//         item_playerId = item.playerId;
//         $("#playerName").attr("value", item.name);
//     });
// }

/**
 * 定义一个验证对象
 */
var ViewValidator = function () {

    var handleSubmit = function () {
        $.validator.addMethod("toTime", function (value, element) {
            if ($('#isSendNow').is(':checked') && $("#startTime").val() !== '' && $("#endTime").val() !== '') {
                return true;
            }
            return false;
        }, "请选择发布时间和结束时间");
        $('#form_menu').validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            highlight: function (element) {
                $(element).closest('.form-group').addClass('has-error');
            },
            success: function (label) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();
            },
            errorPlacement: function (error, element) {
                element.parent('div').append(error);
            },
            rules: {
                time: {
                    toTime: true
                },
                title: {
                    required: true
                }
            },
            messages: {

            }
        });

    };
    return {
        init: function () {
            handleSubmit();
        }
    };

} ();

var bulletin_form = function () {
    var operType = "";
    var i = 2;
    function save(oper, tableValue, isSendNow) {
        var json = JSON.stringify(tableValue);
        if (isSendNow === undefined) {
            if ($('#send').is(':checked') || !$('#isSendNow').is(':checked')) {
                isSendNow = true;
            }
        } else {
            isSendNow === false;
        }
        sysComponents.showHelpMessage(viewLocale.form.save.loading);
        if (oper == 'edit') {
            $.post(REPORT_ROOT + '/statistics/bulletin/server/edit', {
                data: json,
                isSendNow: isSendNow
            }, function (data, status) {
                goPage(sysPage.currPage, 'server');
                sysComponents.showHelpMessage(viewLocale.form.save.success);
                if (data !== null && data == true) {
                    sysComponents.showHelpMessage(viewLocale.form.save.success);
                    bulletin_form.resetForm();
                } else {
                    sysComponents.showHelpMessage(viewLocale.form.save.fail, 'error');
                }
            });
        } else if (oper == 'add') {
            $.post(REPORT_ROOT + '/statistics/bulletin/local/save', {
                data: json,
                isSendNow: isSendNow
            }, function (data, status) {
                goPage(sysPage.currPage, 'local');
                if (operType == 'edit') {
                    sysComponents.showHelpMessage(viewLocale.form.save.success);
                } else if (operType == 'add') {
                    bulletin_form.resetForm();
                    $('.ui-dialog-title').html(viewLocale.form.title.add);
                }
                if (data !== null) {
                    sysComponents.showHelpMessage(viewLocale.form.save.success);
                    bulletin_form.resetForm();
                } else {
                    sysComponents.showHelpMessage(viewLocale.form.save.fail, 'error');
                }
            });
        }

        $('#menuEdit').hide();
        $("#show_all_list").show();
    };
    return {
        /**
         * 重置form
         */
        resetForm: function () {
            $('#form_menu')[0].reset();
            $('#id').val('');
            $('#playerId').val('');
        },

        /**
         * 执行保存动作
         */
        saveEdit: function (oper, isSendNow) {
            editor.updateElement();
            var tableValue = $('#form_menu').serializeJSON();
            console.info(tableValue);
            if ($("#image").is(":checked")) {
                $("#picture").show();
                $("#bulletinContent").hide();
            } else if ($("#text").is(":checked")) {
                $("#picture").hide();
                $("#bulletinContent").show();
            } else {
                $("#picture").hide();
                $("#bulletinContent").show();
            }
            delete tableValue.contentType;
            if ($("#image").is(":checked") && tableValue.picture != '') {
                delete tableValue.bulletinContent;
                save(oper, tableValue, isSendNow);
            } else if ($("#text").is(":checked") && bulletinContent != '') {
                save(oper, tableValue, isSendNow);
                delete tableValue.picture;
            } else {
                $("#bulletinContent").closest('.form-group').addClass('has-error');
            }
        },

        /**
         * 显示编辑窗口
         * 
         * @@param {} type：add,edit,view
         * @param {}
         *            id
         * @param {}
         *            pid
         */
        showEdit: function (type, id) {
            $("#show_all_list").hide();
            bulletin_form.resetForm();
            $('#menuEdit').validate().form();
            operType = type;
            $('#operType').val(operType);
            if (operType == 'add') {
                $('.modal-title').html(viewLocale.form.title.add);
                $('#btn_save').show();
            } else {
                if (operType == 'view') {
                    $('.modal-title').html(viewLocale.form.title.view);
                    $('#btn_save').hide();
                } else if (operType == 'edit') {
                    $('.modal-title').html(viewLocale.form.title.edit);
                    $('#btn_save').show();
                }
                operType = 'edit';
                $.post(REPORT_ROOT + '/statistics/bulletin/server/get', {
                    id: id
                }, function (data) {
                    sysComponents.setValues(data);
                });
                $('#id').val(id);
            }
            //$("h4#menuEditLabel").html("新建邮件");
            $('#menuEdit').show();
        },

        /**
         * send
         */
        send: function (id) {
            $.post(REPORT_ROOT + '/statistics/bulletin/send', {
                id: id
            }, function (data, status) {
                if (data) {
                    sysComponents.showHelpMessage('公告上传成功');
                    bulletin_form.resetForm();
                    goPage(sysPage.currPage, 'server');
                    //goPage(sysPage.currPage);
                } else {
                    sysComponents.showHelpMessage('公告上传失败', 'error');
                }
            });
            $('#menuEdit').hide();
            $("#mail_list").show();
        },

        cancle: function () {
            $("#isSend").attr("checked", false);
            $("#dialog_message_for_send").modal('hide');
        },


    };
} ();


