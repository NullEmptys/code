sysPage = new SysPage();
var _data;
/**
 * 分页查询
 * 
 * @param {}
 *            search
 * @param {}
 *            currPage
 * @param {}
 *            perPage
 */
showList = function(currPage, pageSize) {
	$.post(REPORT_ROOT + "/statistics/serverinfoconfig/listForPage",
	function(data) {
		_data = data;
		page(data, currPage, pageSize);
	});
}

// 分页操作
page = function(data, currPage, pageSize) {
	var data1;
	if (data.length > (currPage - 1) * pageSize
			&& data.length <= currPage * pageSize) {
		data1 = data.slice((currPage - 1) * pageSize, data.length);
	} else if (data.length > currPage * pageSize) {
		data1 = data.slice((currPage - 1) * pageSize, currPage * pageSize);
	}
	var totalPages = Math.ceil(data.length / pageSize); // 向上取余
	show(data1, totalPages, currPage, data.length);
}

// 显示列表
show = function(data, totalPages, currPage, total) {
	var _tpl = '<tr><td align=\'center\'>{id}</td><td align=\'center\'>{serverId}</td><td align=\'center\'>{serverName}</td><td align=\'center\'>{ip}</td><td align=\'center\'>{port}</td><td align=\'center\'>{discription}</td><td align=\'center\'>{executeUpdate}</td><td align=\'center\'>{safetyIpStr}</td><td align=\'center\'>{openTime}</td><td align=\'center\'>{closeTime}</td>'
		+ '<td style="text-align:center; width: 100px;"><span class="btn-group">'
		+ '<a title="'
		+ viewLocale.form.title.edit
		+ '" class="btn bs-tooltip" href="javascript:showEdit(\'edit\',{id});" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
		+ '</span></td></tr>';
	var _html = '';
	$(data).each(function(index, element) {
		if (element.closeTime) {
//			var newDate = new Date();
//			newDate.setTime(new Number(element.closeTime));
//			element.closeTime = newDate.Format('yyyy-MM-dd HH:mm:ss SSS Z');
			element.closeTime = element.closeTime.substring(0,19);
		}
		if (element.openTime) {
//			var newDate = new Date();
//			newDate.setTime(new Number(element.openTime));
//			element.openTime = newDate.Format('yyyy-MM-dd HH:mm:ss SSS Z');
			element.openTime = element.openTime.substring(0,19);
		}
		if (element.executeUpdate == 0) {
			element.executeUpdate = '执行更新';
		} else if (element.executeUpdate == 1) {
			element.executeUpdate = '不执行更新';
		}
		_html = _html + nano(_tpl, element);
	})
	$('#menu_list').html(_html);
	// 显示分页
	sysPage.showPage('nav_page', totalPages, currPage, total);
	$('.bs-tooltip').tooltip();
	showAuth();
}

goPage = function(currPage) {
	var _perPage = $('#perPage').val();
	showList(currPage, _perPage);
}
