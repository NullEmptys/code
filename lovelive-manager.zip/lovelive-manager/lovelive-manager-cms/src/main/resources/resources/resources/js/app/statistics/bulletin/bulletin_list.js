sysPage = new SysPage();

var listFromServer = {
    totalPages: 0,
    totalElements: 0,
    content: new Array(),
    showElements: new Array()
};
var pageUtils = {
    hasNext: function (current, size) {
        if (listFromServer.totalPages > current) {
            return true;
        } else {
            return false;
        }
    },
    hasBefore: function (current, size) {
        if (current >= 1) {
            return true;
        } else {
            return false;
        }
    },
    pager: function (current, size) {
        listFromServer.totalElements = listFromServer.content.length;
        listFromServer.totalPages = listFromServer.content.length / size > 1 ? Math.ceil(listFromServer.content.length / size) : 1;
        if (listFromServer.content.length < size) {
            listFromServer.showElements = listFromServer.content;
        } else {
            listFromServer.showElements = new Array();
            for (var index = 0; index < size; index++) {
                var element = listFromServer.content[index + (current - 1) * size];
                if (element) {
                    listFromServer.showElements.push(element);
                } else {
                    break;
                }
            }
        }
    }
};

var bulletin_list = function () {
    var delId;
    var delType;
    var showSever = function (params, currPage, pageSize) {
        listFromServer = params;
        var _tpl = '<tr><td class="text-center">{createTime}</td><td class="text-center">{type}</td><td class="text-center">{title}</td><td class="text-center">{hasContent}</td><td class="text-center">{bulletin_time}</td><td class="text-center">{status}</td><td class="text-center">{publisher}</td><td class="text-center">{lastEditor}</td>'
            + '<td class="text-center"><span class="btn-group">'
            + '<a title="' + viewLocale.form.title.del + '" class="btn bs-tooltip" href="javascript:bulletin_list.showDel({id},1);" data-original-title="Del"><i class="glyphicon glyphicon-remove"></i></a>'
            + '{editbulletin}'
            + '</span></td>'
            + '</tr>';
        var _html = '';
        //js 分頁
        pageUtils.pager(currPage, pageSize);
        $(listFromServer.showElements).each(function (index, element) {
            if (element.createTime) {
                var newDate = new Date(element.createTime);
                element.createTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
            }

            if (element.type == 1) {
                element.type = '内部弹板';
            } else if (element.type == 2) {
                element.type = '外部弹板';
            }

            if (element.status === 0) {
                element.editbulletin = '<a title="编辑" class="btn bs-tooltip" href="javascript:bulletin_form.showEdit(\'edit\',' + element.id + ');" data-original-title="Send"><i class="glyphicon glyphicon-edit"></i></a>';
                element.status = "显示";
            } else {
                element.status = '未显示';
            }

            if (element.bulletinContent) {
                element.hasContent = "<a title='查看文字内容' href='javascript:bulletin_list.showDetail(" + element.id + ",1)'>查看文字内容</a>";
            } else if (element.picture) {
                element.hasContent = element.picture;
            }

            if (element.startTime) {
                var newDate = new Date(element.startTime);
                element.startTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
            }

            if (element.endTime) {
                var newDate = new Date(element.endTime);
                element.endTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
            }

            element.bulletin_time = element.startTime + "~" + element.endTime;

            _html = _html + nano(_tpl, element);
        });

        $('#server_menu_list').html(_html);
        // 显示分页
        sysPage.showPage('server_nav_page', listFromServer.totalPages, currPage, listFromServer.totalElements, null, "server");
        $('.bs-tooltip').tooltip();
        //showAuth();
    };
    return {
        /**
         * 分页查询
        * 
        * @param {}
        *            search
        * @param {}
        *            currPage
        * @param {}
        *            perPage
        */
        showserverList: function (currPage, pageSize) {
            if (listFromServer.totalPages == 0) {
                $.post(REPORT_ROOT + "/statistics/bulletin/server/list", { date: new Date() }, function (data) {
                    if (data != null && typeof (data) == 'string') {
                        listFromServer.content = JSON.parse(data);
                        showSever(listFromServer, currPage, pageSize);
                    }
                });
            } else {
                showSever(listFromServer, currPage, pageSize);
            }
        },

        showLocalList: function (currPage, pageSize) {
            $.post(REPORT_ROOT + "/statistics/bulletin/local/listForPage",
                {
                    currPage: currPage - 1,
                    pageSize: pageSize
                }, function (data) {
                    var _tpl = '<tr><td class="text-center">{createTime}</td><td class="text-center">{type}</td><td class="text-center">{title}</td><td class="text-center">{hasContent}</td><td class="text-center">{bulletin_time}</td><td class="text-center">{broadcast_time}</td><td class="text-center">{publisher}</td><td class="text-center">{isSend}</td>'
                        + '<td class="text-center"><span class="btn-group">'
                        + '<a title="' + viewLocale.form.title.del + '" class="btn bs-tooltip" href="javascript:bulletin_list.showDel({id},2);" data-original-title="Del"><i class="glyphicon glyphicon-remove"></i></a>'
                        + '{sendbulletin}'
                        + '</span></td>'
                        + '</tr>';
                    var _html = '';
                    $(data.content).each(function (index, element) {
                        if (element.createTime) {
                            var newDate = new Date(element.createTime);
                            element.createTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
                            //console.info(new Date());
                            //console.info(element.createTime);
                        }

                        if (element.type == 1) {
                            element.type = '内部弹板';
                        } else if (element.type == 2) {
                            element.type = '外部弹板';
                        }

                        if (element.status == 0) {
                            element.sendbulletin = '<a title="发送" class="btn bs-tooltip" href="javascript:bulletin_form.send(' + element.id + ');" data-original-title="Send"><i class="glyphicon glyphicon-send"></i></a>';
                            element.status = "显示";
                        } else {
                            element.status = '未显示';
                        }

                        if (element.bulletinContent) {
                            element.hasContent = "<a title='查看文字内容' href='javascript:bulletin_list.showDetail(" + element.id + ",1)'>查看文字内容</a>";
                        } else if (element.picture) {
                            element.hasContent = element.picture;
                        }

                        if (element.startTime && element.endTime) {
                            if (element.startTime) {
                                var newDate = new Date(element.startTime);
                                element.startTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
                            }

                            if (element.endTime) {
                                var newDate = new Date(element.endTime);
                                element.endTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
                            }

                            element.bulletin_time = element.startTime + "~" + element.endTime;
                        } else {
                            element.bulletin_time = '';
                        }

                        if (element.broadcastStartTime && element.broadcastEndTime) {
                            if (element.broadcastStartTime) {
                                var newDate = new Date(element.broadcastStartTime);
                                element.broadcastStartTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
                            }

                            if (element.broadcastEndTime) {
                                var newDate = new Date(element.broadcastEndTime);
                                element.broadcastEndTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
                            }

                            element.broadcast_time = element.broadcastStartTime + '~' + element.broadcastEndTime;
                        } else {
                            element.broadcast_time = '';
                        }



                        if (element.isSend == 1) {
                            element.isSend = '已发送';
                        } else if (element.isSend == 0) {
                            element.isSend = '未发送';
                        } else {
                            element.isSend = '';
                        }

                        _html = _html + nano(_tpl, element);
                    });
                    $('#local_menu_list').html(_html);
                    // 显示分页
                    sysPage.showPage('local_nav_page', data.totalPages, currPage, data.totalElements, null, "local");
                    $('.bs-tooltip').tooltip();
                    showAuth();
                });
        },

        showDetail: function (id, type) {
            var url = REPORT_ROOT + '/statistics/bulletin/';
            if (type == 1) {
                url += 'server/get';
            } else {
                url += 'local/get';
            }
            $("#bulletin_detail").modal("show");
            $.post(url, {
                id: id
            }, function (data) {
                console.info(data);
                $("#detail_title").html(data.title);
                $("#detail_content").html(data.bulletinContent);
            });
        },

        showDel: function (id, type) {
            $('.ui-dialog-title').html(viewLocale.prompt)
            delId = id;
            delType = type;
            $('#dialog_message_for_delete').modal('show');
        },

        /**
         * 执行删除动作
         * 
         * @param {}
         *            id
         */
        doDel: function () {
            sysComponents.showHelpMessage(viewLocale.form.del.loading);
            if (delType == 1) {
                $.post(REPORT_ROOT + "/statistics/bulletin/server/del", {
                    id: delId
                }, function (data) {
                    if (data) {
                        sysComponents.showHelpMessage(viewLocale.form.del.success);
                    } else {
                        sysComponents.showHelpMessage(viewLocale.form.del.fail, 'error');
                    }
                    //goPage(sysPage.currPage);
                    goPage(sysPage.currPage, 'server');
                });
            } else if (delType == 2) {
                $.post(REPORT_ROOT + "/statistics/bulletin/local/del", {
                    id: delId
                }, function (data) {
                    if (data) {
                        sysComponents.showHelpMessage(viewLocale.form.del.success);
                    } else {
                        sysComponents.showHelpMessage(viewLocale.form.del.fail, 'error');
                    }
                    //goPage(sysPage.currPage);
                    goPage(sysPage.currPage, 'local');
                });
            }

            $('#dialog_message_for_delete').modal('hide');
        }
    }
} ();

goPage = function (currPage, where) {
    if (where == 'local') {
        var localPage = $("#local_perPage").val();
        bulletin_list.showLocalList(currPage, localPage);
    } else if (where == 'server') {
        var serverPage = $('#server_perPage').val();
        bulletin_list.showserverList(currPage, serverPage);
    }

    //	showList(_search, currPage, _perPage);

};