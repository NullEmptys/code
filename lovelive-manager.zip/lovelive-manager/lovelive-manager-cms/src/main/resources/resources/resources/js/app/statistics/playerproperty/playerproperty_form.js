/**
 * 重置form
 */
resetForm = function () {
    $('#form_playerProperty')[0].reset();
    $('#id').val('');
}
/**
 * 执行保存动作
 */
saveEdit = function () {
    var json = JSON.stringify($('#form_playerProperty').serializeJSON());
    sysComponents.showHelpMessage(viewLocale.form.save.loading);
    $.post(REPORT_ROOT + '/statistics/playerproperty/save', {
        operType: $('#operType').val(),
        userId: $('#_userId').val(),
        data: json
    }, function (data, status) {
        if (data == 0) {
            if ($('#operType').val() == 'edit') {
                resetForm();
                sysComponents.showHelpMessage(viewLocale.form.save.success);
            } else if ($('#operType').val() == 'add') {
                resetForm();
                $('.ui-dialog-title').html(viewLocale.form.title.add);
            }
            goData($('#_userId').val(), $('#_currPage').val(), $('#perPage').val());
        } else {
            resetForm();
            sysComponents.showHelpMessage(viewLocale.form.server.error, 'error');
        }
    });
    $('#playerPropertyEdit').modal('hide');
}

/**
 * 显示编辑窗口
 *
 * @@param {} type：add,edit,view
 * @param {}
 *            id
 * @param {}
 *            pid
 */
showEdit = function (type, bagId, gridId, itemId, ct) {
    var id = $('#_userId').val();
    if (!id || id.length == 0) {
        alert('请先选择用户！');
        return;
    }
    resetForm();
    $('#form_playerProperty').validate().form();
    $('#operType').val(type);
    if ($('#operType').val() == 'add') {
    	$('#item_id_item').html('');
    	sysComponents.getItemByCategoryType('item_id_item', 1);
        $("#category_NtoB").show();
        $("#item_id_NtoB").show();
        $("#cdTimes_NtoB").show();
        $("#cdTime_NtoB").show();
        $("#num_NtoB").hide();
        $('#operType').val('add');
        $('.modal-title').html(viewLocale.form.title.add);
        $('#btn_save').show();
    } else {
        $('#_bagId').val(bagId);
        $('#_gridId').val(gridId);
        if ($('#operType').val() == 'view') {
            $('.modal-title').html(viewLocale.form.title.view);
            $('#btn_save').hide();
        } else if ($('#operType').val() == 'edit') {
            $('#operType').val('edit');
            $('.modal-title').html(viewLocale.form.title.edit);
            $('#btn_save').show();
        }
        if ($('#_category').val() == 0) {
            $('#num').val(ct);
            $("#num_NtoB").show();
            $("#category_NtoB").hide();
            $("#item_id_NtoB").hide();
            $("#cdTimes_NtoB").hide();
            $("#cdTime_NtoB").hide();
        } else {
            if (ct.length > 2) {
                $('#cdTime').val(ct);
            } else {
                $('#cdTimes').val(-1);
            }
            $("#cdTimes_NtoB").show();
            $("#cdTime_NtoB").show();
            $("#num_NtoB").hide();
            $("#category_NtoB").hide();
            $("#item_id_NtoB").hide();
        }
        $('#modal_bagId').val(bagId);
        $('#modal_gridId').val(gridId);
        $('#modal_itemId').val(itemId);
        $('#category').val($('#_category').val());
    }
    $('#playerPropertyEdit').modal('show');
}

// 编辑项下拉框的的变换
editChange = function () {
	for(var i=0; i<5; i++){
		if(0==i){
			if ($('#category option:selected').val() == 0) {
		        $('#item_id_item').html('');
		        sysComponents.getItemByCategoryType('item_id_item', 0);
		        $('#_category').val('0');
		        $("#item_id_NtoB").show();
		        $("#num_NtoB").show();
		        $("#cdTimes_NtoB").hide();
		        $("#cdTime_NtoB").hide();
		    }
		} else {
			if ($('#category option:selected').val() == i) {
		        $('#item_id_item').html('');
		        sysComponents.getItemByCategoryType('item_id_item', i);
		        $('#_category').val(''+i);
		        $("#item_id_NtoB").show();
		        $("#cdTimes_NtoB").show();
		        $("#cdTime_NtoB").show();
		        $("#num_NtoB").hide();
		    }
		}
	}
}

/*
 * 获取地址栏后的参数
 */
$(document).ready(function () {
    change('1', 'clothing');
    var url = window.location.search;
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("=");
        if (strs[1].length == 0)
            return;
        $('#_userId').val(strs[1]);
        showList(strs[1], 1, $('#perPage').val());
    }
});

/*
 * 模糊查询
 */

callback = function(item){
	$('#_currPage').val(1);
	if($('#_userId').val() !== item.playerId){
		$('#_userId').val(item.playerId);
		$('#_userName').val(item.name);
		showList($('#_userId').val(), 1, $('#perPage').val());
	}
}

$('#searching').searchPlayerInfo({
    complete: function (playerInfo) {
        callback(playerInfo);
    }
});
