/**
 * 重置form
 */
resetForm = function() {
	$('#form_menu')[0].reset();
	$('#id').val('');
}

/**
 * 显示编辑窗口
 * 
 * @@param {} type：add,edit,view
 * @param {}
 *            id
 * @param {}
 *            pid
 */
showEdit = function(type, id) {
	resetForm();
	$('#form_menu').validate().form();
	if (type == 'add') {
		$('#_operType').val('add');
		$('.modal-title').html(viewLocale.form.title.add);
		$('#btn_save').show();
	} else {
		if (type == 'view') {
			$('.modal-title').html(viewLocale.form.title.view);
			$('#btn_save').hide();
		} else if (type == 'edit') {
			$('.modal-title').html(viewLocale.form.title.edit);
			$('#btn_save').show();
		}
		$('#_operType').val('edit');
		$.post(REPORT_ROOT + '/statistics/serverinfoconfig/get', {
			id : id
		}, function(data) {
			sysComponents.setValues(data);
			if(data.openTime){
				$('#openTime').val(data.openTime.substring(0,19));
			}
			if(data.closeTime){
				$('#closeTime').val(data.closeTime.substring(0,19));
			}
		});
		$('#id').val(id);
	}
	$('#menuEdit').modal('show');
}

/**
 * 执行保存动作
 */
saveEdit = function() {
	var json = JSON.stringify($('#form_menu').serializeJSON());
	sysComponents.showHelpMessage(viewLocale.form.save.loading);
	$.post(REPORT_ROOT + '/statistics/serverinfoconfig/save', {
		data : json
	}, function(data, status) {
		if(data == 0){
			goPage(sysPage.currPage);
			if ($('#_operType').val() == 'edit') {
			sysComponents.showHelpMessage(viewLocale.form.save.success);
			} else if ($('#_operType').val() == 'add') {
				resetForm();
				$('.ui-dialog-title').html(viewLocale.form.title.add);
			}
		} else {
			resetForm();
			sysComponents.showHelpMessage(viewLocale.form.server.error, 'error');
		}
	});
	$('#menuEdit').modal('hide');
}
