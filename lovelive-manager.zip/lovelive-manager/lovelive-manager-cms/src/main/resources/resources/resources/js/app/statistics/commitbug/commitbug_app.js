/**
 *初始化组件
 */
initComponents=function(){

    $('#btn_search').click(function () {
        showList(1);
    });

    $('#perPage').change(function () {
        showList($('#perPage').val());
    });

    $('#download').click(function () {
        download();
    });
};