var _data;
sysPage = new SysPage();
/**
 * 分页查询
 * 
 * @param {}
 *            search
 * @param {}
 *            currPage
 * @param {}
 *            perPage
 */
showList = function(id, currPage, pageSize) {
	if(id == $('#_oldId').val()){
		var data = _data;
		page(data, currPage, pageSize);
	} else {
		goData(id, currPage, pageSize);
	}	
}

//直接查询数据库
goData = function(id, currPage, pageSize) {
	$.post(REPORT_ROOT + "/statistics/playerproperty/listForPage", {
		id : id, 
		category : $('#_category').val()
	}, function(data) {
		$('#_oldId').val(id);
		_data = data;
		page(data, currPage, pageSize);
	});
}

// 分页操作
page = function(data, currPage, pageSize){
	var data1;
	if(data.length>(currPage-1)*pageSize && data.length<=currPage*pageSize){
		data1 = data.slice((currPage-1)*pageSize,data.length);
	} else if(data.length>currPage*pageSize){
		data1 = data.slice((currPage-1)*pageSize,currPage*pageSize);
	}
	var totalPages = Math.ceil(data.length/pageSize);  //向上取余
	if($('#_category').val() == 0){
		giftShow(data1, totalPages, currPage, data.length);
	} else if($('#_category').val() == 1 || $('#_category').val() == 2 || 
			$('#_category').val() == 3 || $('#_category').val() == 4){
		clothingShow(data1, totalPages, currPage, data.length);
	} 
//	else if($('#_category').val() == 2 || $('#_category').val() == 3 || $('#_category').val() == 4){
//		otherShow(data1, totalPages, currPage, data.length);
//	} 	
}

// 服装、动作、特效和相框列表的显示
clothingShow = function(data, totalPages, currPage, total) {
	var _tpl = '<tr><td align=\'center\'>{bagId}</td><td align=\'center\'>{gridId}</td><td align=\'center\'>{itemId}</td><td align=\'center\'>{name}</td><td align=\'center\'>{cdTime}</td>'
		+ '<td class="text-center"><span class="btn-group">'
		+ '<a title="'+viewLocale.form.title.edit+'" class="btn bs-tooltip" href="javascript:showEdit(\'edit\',{bagId},{gridId},{itemId},\'{cdTime}\');" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
        + '<a title="'+viewLocale.form.title.del+'" class="btn bs-tooltip" href="javascript:showDel({bagId},{gridId},{itemId},{count},{category});" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></a>'
        + '</span></td></tr>';
	var _html = '';
	$(data).each(
		function(index, element) {
			if (element.cdTime > 1) {
				var newDate = new Date();
				newDate.setTime(new Number(element.cdTime));
				element.cdTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
			} else if(element.cdTime == -1){
				element.cdTime = '永久';
			} else if(element.cdTime == 0){
				element.cdTime = '已失效';
			}
			_html = _html + nano(_tpl, element);
		})
	$('#playerproperty_clothing_list').html(_html);
	// 显示分页
sysPage.showPage('nav_page', totalPages, currPage, total);
$('.bs-tooltip').tooltip();
showAuth();
}

// 礼物列表显示
giftShow = function(data, totalPages, currPage, total) {
	var _tpl = '<tr><td align=\'center\'>{bagId}</td><td align=\'center\'>{gridId}</td><td align=\'center\'>{itemId}</td><td align=\'center\'>{name}</td><td align=\'center\'>{count}</td>'
		+ '<td class="text-center"><span class="btn-group">'
        + '<a title="'+viewLocale.form.title.edit+'" class="btn bs-tooltip" href="javascript:showEdit(\'edit\',{bagId},{gridId},{itemId},{count});" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
        + '<a title="'+viewLocale.form.title.del+'" class="btn bs-tooltip" href="javascript:showDel({bagId},{gridId},{itemId},{count},{category});" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></a>'
        + '</span></td></tr>';
	var _html = '';
	$(data).each(
		function(index, element) {
			_html = _html + nano(_tpl, element);
		})
	$('#playerproperty_gift_list').html(_html);
	// 显示分页
sysPage.showPage('nav_page', totalPages, currPage, total);
$('.bs-tooltip').tooltip();
showAuth();
}

goPage = function(currPage) {
	$('#_currPage').val(currPage);
	var id = $('#_userId').val();
	var _perPage = $('#perPage').val();
	showList(id, currPage, _perPage);
}

showDel = function(bagId, gridId, itemId, count, category) {
	$('.ui-dialog-title').html(viewLocale.prompt);
	$('#_bagId').val(bagId);
	$('#_gridId').val(gridId);
	$('#_itemId').val(itemId);
	$('#_count').val(count);
	$('#_category').val(category);
	$('#dialog_message').modal('show');
}

/**
 * 执行删除动作
 * 
 * @param {}
 *            id
 */
doDel = function() {
	sysComponents.showHelpMessage(viewLocale.form.del.loading);
	$.post(REPORT_ROOT + "/statistics/playerproperty/del", {
		playerId : $('#_userId').val(),
		bagId : $('#_bagId').val(),
		gridId : $('#_gridId').val(),
		itemId : $('#_itemId').val(),
		count : $('#_count').val(),
		category : $('#_category').val()
	}, function(data) {
		goData($('#_userId').val(), $('#_currPage').val(), $('#perPage').val());
		if(data == true){
			sysComponents.showHelpMessage(viewLocale.form.del.success);
		} else {
			sysComponents.showHelpMessage(viewLocale.form.server.error, 'error');
		}
	});
	$('#dialog_message').modal('hide');
}

// 道具按钮切换表格
change = function(category, name) {
	$('#_oldId').val(-1);
	$('#_category').val(category);
	// 每次切换都会清空之前的数据，防止误操作
	$('#playerproperty_'+$('#_blockToNone').val()+'_list').html('');
	$('#'+$('#_blockToNone').val()).hide();
	$('#'+name).show();
	showList($('#_userId').val(), 1, $('#perPage').val());
	$('#_blockToNone').val(name);
}