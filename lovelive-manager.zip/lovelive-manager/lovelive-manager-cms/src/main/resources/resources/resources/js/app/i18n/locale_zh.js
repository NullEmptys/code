var viewLocale = {};

viewLocale.close = '关闭';
viewLocale.sure = '确定';
viewLocale.cancel = '取消';
viewLocale.fail = '操作失败,请重试或联系系统管理员！';
viewLocale.unknown='未知';
viewLocale.loading = "正在加载...";
viewLocale.success = "加载完毕！";
viewLocale.download = "正在下载！";
viewLocale.prompt = "提示";
viewLocale.copy ='复制';
viewLocale.browser ='浏览';
viewLocale.searchkey="请输入查询关键字";

viewLocale.login = {};
viewLocale.login.validate = "请输入用户名和密码！";
viewLocale.login.loading = "正在登录中...";
viewLocale.login.error = "账户或密码错误，请重新登录!";
viewLocale.login.retry = "登录失败，请重试!";
viewLocale.login.success = "登录成功，请稍等，将转入系统...";
viewLocale.login.browser = "尊敬的用户，您的浏览器可能无法正常使用DXP系统。目前本系统支持的浏览器为IE9及以上、Firefox、Chrome。建议使用以上浏览器，谢谢配合!";
viewLocale.login.noauth = "对不起，您没有权限，请联系系统管理员!";

viewLocale.form = {};
viewLocale.form.title = {};
viewLocale.form.title.add = '新建'
viewLocale.form.title.view = '查看'
viewLocale.form.title.change = '变化趋势'
viewLocale.form.title.analysis = '受众分析'
viewLocale.form.title.edit = '修改'
viewLocale.form.title.compaign = '关联订单'
viewLocale.form.title.del = '删除'
viewLocale.form.title.delComplete = '彻底删除'
viewLocale.form.title.first = '新建一级标签'
viewLocale.form.title.sub = '新建子标签'
viewLocale.form.title.parentPre = '&nbsp;&nbsp;(上一级标签:'
viewLocale.form.title.parentSuf = ')'
viewLocale.form.title.start = '马上启动'
viewLocale.form.title.stop = '停止'
viewLocale.form.title.remove = '从scheduler中移除该trigger'
viewLocale.form.title.refresh='更新数据'
viewLocale.form.title.refreloading='提示：正在更新数据'
viewLocale.form.title.refrefinish='提示：更新数据完成'
viewLocale.form.title.customShell='表达式有误:表达式不正确或为空.'
viewLocale.form.title.lookin = '人群透视'  
	
viewLocale.form.save = {};
viewLocale.form.save.success = '提示：保存成功！'
viewLocale.form.save.fail = '提示：保存失败！'
viewLocale.form.save.loading = '提示：正在保存...'

viewLocale.form.text = {};
viewLocale.form.text.error = '提示：输入数据超出范围！'
	
viewLocale.form.server = {};
viewLocale.form.server.error = '提示：服务器访问异常！'
	
viewLocale.form.send = {}
viewLocale.form.send.success = '发送成功！'
viewLocale.form.send.fail = '发送失败！'
	
viewLocale.form.del = {};
viewLocale.form.del.loading = '提示：正在删除...'
viewLocale.form.del.success = '提示：删除成功！'
viewLocale.form.del.subSuccess = '提示：部分删除成功！已删除：'
viewLocale.form.del.fail = '提示：删除失败，请重试或联系系统管理员！'
viewLocale.form.del.sel = '提示：请先选择一个或多个项！'

viewLocale.form.compain = {}
viewLocale.form.compain.title = '编辑标签关联订单'

viewLocale.form.provider = {}
viewLocale.form.provider.del = {};
viewLocale.form.provider.del.fail = '提示：删除失败，该提供商还有子标签！'
viewLocale.form.provider.tag='人群标签'


viewLocale.form.message = {};
viewLocale.form.message.tree = '提示：请先左侧选中一个标签！'

viewLocale.form.group = {}
viewLocale.form.group.del = {};
viewLocale.form.group.del.fail = '提示：部分删除失败，用户组还有其他关联数据！'
viewLocale.form.group.tag = '授权标签'

viewLocale.form.user = {}
viewLocale.form.user.message = {}
viewLocale.form.user.message.loginName = '系统已存在此登录用户名，请换一个登录名!'
viewLocale.form.user.message.passwordEqual='两次输入密码不一致!'
viewLocale.form.user.message.nowpass='现在的密码输入不正确!'
viewLocale.form.user.modifyPassword="修改密码"
viewLocale.form.user.modifyPasswordSucess="修改密码成功！"

viewLocale.form.role = {}
viewLocale.form.role.menu = '授权菜单'

viewLocale.crowd = {};
viewLocale.crowd.title = {};
viewLocale.crowd.title.self='自:'
viewLocale.crowd.title.children='子:'
viewLocale.crowd.title.total='总:'

viewLocale.task = {};
viewLocale.task.start = "正在启动....";
viewLocale.task.startFinish = "已启动.";
viewLocale.task.stop = "正在停止....";
viewLocale.task.stopFinish = "已停止.";

viewLocale.form.event = {}
viewLocale.form.event.code='获取代码'
viewLocale.form.event.copy='代码已经复制到你的剪贴板。'

viewLocale.form.portrait={}
viewLocale.form.portrait.notexsit='在dxpmedia域中无该cookie！'

viewLocale.form.download = {};
viewLocale.form.download.cookie="下载cookie";
viewLocale.form.download.nocookie="暂时无cookie可下载！";
viewLocale.form.download.report="透视下载";
viewLocale.form.title.auth = '授权'

viewLocale.form.upload = {};
viewLocale.form.upload.cookie='上传cookie文件';


viewLocale.form.para = {};
viewLocale.form.para.message = {};
viewLocale.form.para.message.paramKey="系统已存在相同的参数键值";

viewLocale.form.dsp = {};
viewLocale.form.dsp.message={};
viewLocale.form.dsp.message.name="系统已存在相同Dsp名称";

viewLocale.page ={
				pageSize : 10,// 每页显示的记录条数，默认为10
				pageList : [10, 20, 30],// 可以设置每页记录条数的列表
				beforePageText : '第',// 页数文本框前显示的汉字
				afterPageText : '页    共 {pages} 页',
				displayMsg : '当前显示 {from} - {to} 条记录   共 {total} 条记录'
			};
			
viewLocale.tag = {};
viewLocale.tag.name="名称";
viewLocale.tag.groupname="所属用户组";
viewLocale.tag.total="访客数量";
viewLocale.tag.unionset="并集集合";
viewLocale.tag.message = {};
viewLocale.tag.message.hasexist = "此并集集合已存在相同的标签，不能再次加入！";
viewLocale.tag.message.firstempty = "并集集合1不能为空!";
viewLocale.tag.message.empty = "交集集合不能为空，请至少包含一个并集集合!";
viewLocale.tag.message.emptycheck = "请勾选第一方人群或监测事件人群!";

viewLocale.form.menu = {};
viewLocale.form.menu.message={};
viewLocale.form.menu.message.name="系统已存在相同菜单名";
