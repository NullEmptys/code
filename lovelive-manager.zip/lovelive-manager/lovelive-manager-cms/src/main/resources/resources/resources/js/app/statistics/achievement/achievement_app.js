/**
 *初始化组件
 */
initComponents=function(){
	var group;
	
	// 按条件点击查询
	$('#btn_search_type').click(function () {
		if($('#_userId').val()){
			var userId = $('#_userId').val();
			var achievement_id = $('#achievement_id').val();
			var achievement_type = $('#achievement_type').val();
			var perPage = $('#perPage').val();
			showList(userId, achievement_id, achievement_type, 1, perPage);
		}
    });
	
	$('#perPage').change(function () {
		if($('#_userId').val()){
			var userId = $('#_userId').val();
			var achievement_id = $('#achievement_id').val();
			var achievement_type = $('#achievement_type').val();
			var perPage = $('#perPage').val();
			showList(userId, achievement_id, achievement_type, 1, perPage);
		}
    });
	
	$('#btn_save').click(function () {
		saveEdit();
    });
	
	
	$('#checkAll').click(function () {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });
	$('#_userId').val('');
	$('#_userName').val('');
    ViewValidator.init();
}