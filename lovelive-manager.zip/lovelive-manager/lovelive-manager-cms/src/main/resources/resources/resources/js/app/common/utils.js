function serAryToStr(obj) {
	var str = '';
	$.each( obj, function(i, n){
		var idx = n.name.indexOf('.id'); 
		if(idx > 0) {
			str += '"' + n.name.substring(0, idx) + '":{' + '"id":' + n.value + '},';			
		} else {
	 		str += '"' + n.name + '":"' + n.value + '",';
		}
	});
	return '{' + str.substring(0,str.length-1) + '}';
}