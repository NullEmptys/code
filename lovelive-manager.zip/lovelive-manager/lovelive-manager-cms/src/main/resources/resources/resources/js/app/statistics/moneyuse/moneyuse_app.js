/**
 *初始化组件
 */
initComponents=function(){
	var group;
	$('#btn_add').click(function () {
        showEdit('add');
    });
	
	$('#btn_save').click(function () {
		if ($('#form_page').valid()) {
			saveEdit();
		}
    });
    
	$('#btn_del').click(function () {
		showDels();
    });
	
	$('#btn_remove').click(function () {
		doDel();
    });
	
	$('#btn_search_type').click(function () {
		if($('#_userId').val()){
			var userId = $('#_userId').val();
			var searchType_use = $('#searchType_use').val();
			var currencyType = $('#currencyType').val();
			var startDate = $('#startDate').val();
			var endDate = $('#endDate').val();
			var perPage = $('#perPage').val();
			showList(userId, searchType_use, currencyType, startDate, endDate, 1, perPage);
			showList_statistics(userId, searchType_use, currencyType, startDate, endDate, 1, perPage);
		}
    });
	
	$('#perPage').change(function () {
		if($('#_userId').val()){
			var userId = $('#_userId').val();
			var searchType_use = $('#searchType_use').val();
			var currencyType = $('#currencyType').val();
			var startDate = $('#startDate').val();
			var endDate = $('#endDate').val();
			var perPage = $('#perPage').val();
			showList(userId, searchType_use, currencyType, startDate, endDate, 1, perPage);
			showList_statistics(userId, searchType_use, currencyType, startDate, endDate, 1, perPage);
		}
    });
	
	$('#checkAll').click(function () {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });
	$('#_userId').val('')
	$('#_userName').val('')
    ViewValidator.init();
}