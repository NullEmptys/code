//var operType = "";
//var _userId;
//var _userName = "";

/**
 * 重置form
 */
resetForm = function() {
	$('#form_girlrelation')[0].reset();
	$('#id').val('');
}

/**
 * 执行保存动作
 */
saveEdit = function() {
	var json = JSON.stringify($('#form_girlrelation').serializeJSON());
	sysComponents.showHelpMessage(viewLocale.form.save.loading);
	$.post(REPORT_ROOT + '/statistics/girlrelation/save', {
		playerId : $('#_userId').val(),
		data : json
	}, function(data, status) {
		goPage(sysPage.currPage);
		if(data == 0){
			if ($('#_operType').val() == 'edit') {
			sysComponents.showHelpMessage(viewLocale.form.save.success);
			} else if ($('#_operType').val() == 'add') {
				resetForm();
				$('.ui-dialog-title').html(viewLocale.form.title.add);
			}
		} else {
			resetForm();
			sysComponents.showHelpMessage(viewLocale.form.server.error, 'error');
		}
		goData($('#_userId').val(), 1, $('#perPage').val());
	});
	$('#girlrelationEdit').modal('hide');
}

/*
 * 显示编辑窗口
 */
showEdit = function(type, girlId, cdTime, level) {
	resetForm();
	$('#form_girlrelation').validate().form();
	$('#_operType').val(type);
	if ($('#_operType').val() == 'add') {
		$('.modal-title').html(viewLocale.form.title.add);
		$('#btn_save').show();
	} else {
		if ($('#_operType').val() == 'view') {
			$('.modal-title').html(viewLocale.form.title.view);
			$('#btn_save').hide();
		} else if ($('#_operType').val() == 'edit') {
			$('.modal-title').html(viewLocale.form.title.edit);
			$('#btn_save').show();
		}
		$('#_operType').val('edit');
		$('#id').val(id);
		$('#girlId').val(girlId);
		if(cdTime.length>3){
			$('#cdTime').val(cdTime);
		} else {
			if(cdTime.length==3){
				$('#cdTimes').val(0);
			} else if(cdTime.length==2){
				$('#cdTimes').val(-1);
			}
		}
		$('#level').val(level);
	}
	$('#girlrelationEdit').modal('show');
}

/*
 * 获取地址栏后的参数
 */
$(document).ready(function() {
	var url = window.location.search;
	if (url.indexOf("?") != -1) {
		var str = url.substr(1)
		strs = str.split("=");
		if(strs[1].length==0)
			return;
		$('#_userId').val(strs[1]);
		showList(strs[1], 1, $('#perPage').val());
	}
});

//模糊查询后赋值
callback = function(item) {
	if(item.playerId !== $('#_userId').val()){
		$('#_userId').val(item.playerId);
		$('#_userName').val(item.name);
		var _perPage = $('#perPage').val();
		showList(item.playerId, 1, _perPage);
	}
}

$('#searching').searchPlayerInfo({
    complete: function (playerInfo) {
        callback(playerInfo);
    }
});

