var operType = "";
/**
 * 定义一个验证对象
 */
var ViewValidator = function() {
	var handleSubmit = function() {
		$('#form_account').validate({
			errorElement : 'span',
			errorClass : 'help-block',
			focusInvalid : false,
			highlight : function(element) {
				$(element).closest('.form-group').addClass('has-error');
			},
			success : function(label) {
				label.closest('.form-group').removeClass('has-error');
				label.remove();
			},
			errorPlacement : function(error, element) {
				element.parent('div').append(error);
			},
			rules : {
				email : {
					required : true,
					maxlength : 100
				},
				role : {
					required : true,
					maxlength : 100
				},
				password : {
					required : true,
					maxlength : 100
				}

			}
		});

	}
	return {
		init : function() {
			handleSubmit();
		}
	};

}();

/**
 * 重置form
 */
resetForm = function() {
	$('#form_account')[0].reset();
	$('#id').val('');
}

/**
 * 执行保存动作
 */
saveEdit = function() {
	var json = serAryToStr($( '#form_account' ).serializeArray());
	sysComponents.showHelpMessage(viewLocale.form.save.loading);
	$.post(REPORT_ROOT + '/auth/account/save', {
		data : json
	}, function(data, status) {
		goPage(sysPage.currPage);
		if (operType == 'edit') {
			sysComponents.showHelpMessage(viewLocale.form.save.success);
		} else if (operType == 'add') {
			resetForm();
			$('.ui-dialog-title').html(viewLocale.form.title.add);
		}
	});
	$('#accountEdit').modal('hide');
}

/**
 * 显示编辑窗口
 * 
 * @@param {} type：add,edit,view
 * @param {}
 *            id
 * @param {}
 *            pid
 */
showEdit = function(type, id) {
	resetForm();
	$('#form_account').validate().form();
	operType = type;
	if (operType == 'add') {
		$('.modal-title').html(viewLocale.form.title.add);
		$('#email').removeAttr("readonly");
		$('#btn_save').show();
	} else {
		if (operType == 'view') {
			$('.modal-title').html(viewLocale.form.title.view);
			$('#btn_save').hide();
		} else if (operType == 'edit') {
			$('.modal-title').html(viewLocale.form.title.edit);
			$('#email').attr("readonly","readonly");
			$('#btn_save').show();
		}
		operType = 'edit';
		$.post(REPORT_ROOT + '/auth/account/get', {
			id : id
		}, function(data) {
			sysComponents.setValues(data);
		});
		$('#id').val(id);
		$('#password').val('');
	}
	$('#accountEdit').modal('show');
}

var accountId = 0;

showAuthTree = function(type,id,email){
	$('#authRecipient').val(email);
	$('#accountId').val(id);
	accountId = id;
	initTree();
	setCleck();
	$('#authTree').modal('show');
};

setCleck = function () {

};

var clkTreeNode = '';
// 叶子节点
var leafs;
onAsyncSuccess = function(event, treeId, treeNode, msg) {
	var _level = 0;

	var _nodes;
	var _childern;
	if (typeof treeNode == 'undefined') {
		var zTree = $.fn.zTree.getZTreeObj(treeId);
		_nodes = zTree.getNodes();
	} else {
		_level = treeNode.level;
		_nodes = [ treeNode ];
		_children = treeNode.children;
		if (_children.length == 0) {
			console.log(treeNode);
			treeNode.isParent = false;
		}
	}

	if (_level == 0) {
		expandNodes(_nodes);
	}
};

expandNodes = function(nodes) {
	if (!nodes)
		return;
	var zTree = $.fn.zTree.getZTreeObj("auth_tree");
	for (var i = 0, l = nodes.length; i < l; i++) {
		zTree.expandNode(nodes[i], true, false, false);
	}
};

//onClick = function(event, treeId, treeNode) {
//	clkTreeNode = treeNode;
//	showListByTree(clkTreeNode.id);
//};

beforeExpand = function(treeId, treeNode) {
	return true;
};


/**
 * 初始化树
 */
initTree = function() {
	var setting = {
		async : {
			enable : true,
			url : REPORT_ROOT + "/auth/account/getAuths?accountId="+accountId,
			autoParam : [ "id", "pid" ]
		},
		check: {
			chkboxType: { "Y" : "ps", "N" : "ps" },
			enable: true
		},
		data : {
			simpleData : {
				enable : false
			},
			key : {
				//title : "name",
				children: "subsyspages",
				url: "none"
			}
		},
		view : {
			//expandSpeed : "slow"
		},
		callback : {
			//onClick : onClick,
			onAsyncSuccess : onAsyncSuccess,
			beforeExpand : beforeExpand
		}
	};
	$.fn.zTree.init($("#auth_tree"), setting);
};



saveAuthTree = function (accountId) {
	var zTree = $.fn.zTree.getZTreeObj("auth_tree");
	var nodes = zTree.transformToArray(zTree.getNodes());//zTree.getCheckedNodes(true);
	var authRecipient = $('#authRecipient').val();
	var accountId = $('#accountId').val();
	var mask = "16";
	var ids = '';
	for(var i=0;i<nodes.length;i++){
		if(nodes[i].checked||nodes[i].getCheckStatus().checked||nodes[i].getCheckStatus().half)
			ids = ids + nodes[i].id + ',';
	}
	console.log(nodes);
	console.log(ids);
	console.log(authRecipient);
	console.log(mask);
	$.post(REPORT_ROOT + '/auth/account/auth', {
		ids : ids,
		accountId:accountId,
		recipient:authRecipient,
		mask:mask
	}, function(data) {
		sysComponents.showHelpMessage(viewLocale.form.save.success);
	});
	$('#authTree').modal('hide');
};
