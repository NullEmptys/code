/**
 * 初始化组件
 */
initComponents = function () {
    var group;
    $('#btn_add').click(function () {
        showEdit('add');
    });

    $('#btn_save').click(function () {
        if ($('#form_menu').valid()) {
            saveEdit();
        }
    });

    $('#btn_remote_save').click(function () {
        if ($('#form_remote_edit').valid()) {
            saveRemoteEdit();
        }
    });

    $('#btn_detail_close').click(function () {
        $("#activity_detail").modal("hide");
    });

    $('#btn_history_remove').click(function () {
        activity_list.doHistoryDel();
    });

    $('#btn_remote_remove').click(function () {
        activity_list.doRemoteDel();
    });

    $('#btn_search').click(function () {
        activity_list.showHistoryList($('#input_search').val(), 1, $('#perPage').val());
    });

    $('#input_search').bind('keypress', function (event) {
        if (event.keyCode == "13") {
            activity_list.showHistoryList($('#input_search').val(), 1, $('#perPage').val());
        }
    });

    $('#perPage').change(function () {
        activity_list.showHistoryList($('#input_search').val(), 1, $('#perPage').val());
    });

    $('#checkAll').click(function () {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });

    $('#btn_auth_save').click(function () {
        saveAuthTree();
    });

    $('#rewardType').change(function () {
        editChange();
    });

    $('#addRewardBtn').click(function () {
        var id = new Date().getTime();
        activity_list.createRewardDetail({id: id});
    });

    $('#btn_award_save').click(function () {
        saveReward();
    });
    $('#btn_remote_publish').click(function () {
        activity_list.doSend();
    });

    activity_list.showHistoryList(1, 20);
    activity_list.showRemoteList();

    ViewValidator.init();
};