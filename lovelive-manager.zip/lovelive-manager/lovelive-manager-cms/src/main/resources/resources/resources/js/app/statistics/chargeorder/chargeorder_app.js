/**
 *初始化组件
 */
initComponents=function(){
	var group;
	sysComponents.getChannelInfos('channelId');
	
	// 按条件点击查询
	$('#btn_search_type').click(function () {
		if($('#_userId').val()){
			var userId = $('#_userId').val();
			var channelId = $('#channelId').val();
			var orderType = $('#orderType').val();
			var orderState = $('#orderState').val();
			var startTime = $('#startTime').val();
			var endTime = $('#endTime').val();
			var perPage = $('#perPage').val();
			showList(userId, channelId, orderType, orderState, startTime, endTime, 1, perPage);
			showList_statistics(userId, channelId, orderType, orderState, startTime, endTime, 1, perPage);
		}
    });
	
	$('#perPage').change(function () {
		if($('#_userId').val()){
			var userId = $('#_userId').val();
			var channelId = $('#channelId').val();
			var orderType = $('#orderType').val();
			var orderState = $('#orderState').val();
			var startTime = $('#startTime').val();
			var endTime = $('#endTime').val();
			var perPage = $('#perPage').val();
			showList(userId, channelId, orderType, orderState, startTime, endTime, 1, perPage);
			showList_statistics(userId, channelId, orderType, orderState, startTime, endTime, 1, perPage);
		}
    });
	
	$('#checkAll').click(function () {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });
	$('#_userId').val('');
	$('#_userName').val('');
    ViewValidator.init();
}