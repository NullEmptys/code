var sysPage = new SysPage();
/**
 * 分页查询
 *
 * @param {}
 *            search
 * @param {}
 *            currPage
 * @param {}
 *            perPage
 */
var showList = function (currPage) {
    var playerId = 0;
    var name = "";
    if($("#playerValueType").val() == 1){
        playerId = $("#playerValue").val();
    }else{
        name = $("#playerValue").val();
    }
    $.post(REPORT_ROOT + "/statistics/commitbug/listForPage",
        {
            playerId: playerId,
            name: name,
            context: $("#context").val(),
            beginTime: $("#beginTime").val(),
            endTime: $("#endTime").val(),
            begin: currPage - 1,
            size: $("#perPage").val()
        }, function (data) {
            console.info(data);
            var _tpl = '<tr><td align=\'center\'>{playerId}</td><td align=\'center\'>{name}</td><td align=\'center\'>{commitDate}</td><td align=\'center\'>{context}</td><!--<td align=\'center\'>{info}</td>--></tr>';
            var _html = '';
            $(data.content).each(function (index, element) {

                if(element.context.length > 10){
                    //element.content = element.context.substring(0, 34);
                    element.context = "<a href='#' onclick = 'showDetail(\"" + element.context + "\")' title='查看详情'>"+element.context.substring(0, 10)+"......</a>";
                }

                /*if (element.createTime) {
                    var newDate = new Date();
                    newDate.setTime(new Number(
                        element.createTime));
                    element.createTime = newDate
                        .Format('yyyy-MM-dd HH:mm:ss');
                }
                if (element.type == 1) {
                    element.type = '获得';
                } else if (element.type == 2) {
                    element.type = '消耗';
                }*/
                _html = _html + nano(_tpl, element);
            });
            $('#menu_list').html(_html);
            // 显示分页
            sysPage.showPage('nav_page', data.totalPages, currPage, data.totalElements);
            $('.bs-tooltip').tooltip();
            showAuth();
        });
};

showDetail = function (context) {
    console.info(context);
    $("#detail").modal("show");
    $("#detail_content").html(context);
};

goPage = function (currPage) {
    showList(currPage);
}
