var operType = "";
/**
 * 定义一个验证对象
 */
var ViewValidator = function() {
	var handleSubmit = function() {
		$('#form_account').validate({
			errorElement : 'span',
			errorClass : 'help-block',
			focusInvalid : false,
			highlight : function(element) {
				$(element).closest('.form-group').addClass('has-error');
			},
			success : function(label) {
				label.closest('.form-group').removeClass('has-error');
				label.remove();
			},
			errorPlacement : function(error, element) {
				element.parent('div').append(error);
			},
			rules : {
				recipient : {
					required : true
				}

			}
		});

	}
	return {
		init : function() {
			handleSubmit();
		}
	};

}();


/**
 * 执行保存动作
 */
saveEdit = function() {
	sysComponents.showHelpMessage(viewLocale.form.save.loading);
	$.post(REPORT_ROOT + '/auth/page/save', {
		id : $('#id').val(),
		recipient : $('#recipient').val(),
		mask : $('#mask').val()
	}, function(data, status) {
		goPage(sysPage.currPage);
		if (operType == 'edit') {
			sysComponents.showHelpMessage(viewLocale.form.save.success);
		} else if (operType == 'add') {
			$('.ui-dialog-title').html(viewLocale.form.title.add);
		}
	});
	$('#accountEdit').modal('hide');
}

/**
 * 显示编辑窗口
 * 
 * @@param {} type：add,edit,view
 * @param {}
 *            id
 * @param {}
 *            pid
 */
showEdit = function(type, id) {
	$('#form_account').validate().form();
	operType = type;
	if (operType == 'add') {
		$('.modal-title').html(viewLocale.form.title.add);
		$('#btn_save').show();
	}

	$('#accountEdit').modal('show');
}
