/**
 * 定义一个验证对象
 */
var ViewValidator = function () {

    var handleSubmit = function () {
        $('#form_menu').validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            highlight: function (element) {
                $(element).closest('.form-group').addClass('has-error');
            },
            success: function (label) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();
            },
            errorPlacement: function (error, element) {
                element.parent('div').append(error);
            },
            rules: {
                playerId: {
                    required: true,
                    number: true
                },
                expirationTime: {
                    required: true
                },
                postTime: {
                    required: true
                },
                time: {
                    //toTime: true
                },
                attachGold: {
                    number: true
                },
                attachMoney: {
                    number: true
                }
            },
            messages: {}
        });

    };
    return {
        init: function () {
            handleSubmit();
        }
    };

}();

var mailForm = function () {
    var operType = "";
    var i = 2;
    return {
        /**
         * 重置form
         */
        resetForm: function () {
            $('#form_menu')[0].reset();
            $('#id').val('');
            $('#playerId').val('');
//            editor.setData('');
            if ($('#delaySend').is(':checked')) {
                $("#sendNow").show();
            } else {
                $("#expirationTime").attr('value', new Date().Format('yyyy-MM-dd HH:mm:ss'));
                $("#postTime").attr('value', new Date().Format('yyyy-MM-dd HH:mm:ss'));
                $("#sendNow").hide();
            }
            if ($('#attachments').is(':checked')) {
                $("#attachs").show();
            } else {
                $("#attachs").hide();
            }
        },

        /**
         * 执行保存动作
         */
        saveEdit: function (delaySend) {
//            editor.updateElement();
            var email_json = $('#form_menu').serializeJSON();
            var attach = new Array();
            for (var a = 1; a < 5; a++) {
            	if($('#category_'+ a + ' option:selected').val() == 101){
            		email_json.attachGold = $("#num_" + a).val();
            	} else if ($('#category_'+ a + ' option:selected').val() == 102) {
            		email_json.attachMoney = $("#num_" + a).val();
            	} else {
            		var item = new Object();
                    item.itemId = $("#item_id_item_" + a).val();
                    item.itemName = $("#item_id_item_" + a).find("option:selected").text();
                    if(0 == $("#category_" + a).val()) {
                    	item.itemNum = $("#num_" + a).val();
                    } else {
                    	if("" == $("#cdTimes_" + a).val()){
                    		item.itemNum = new Date($("#cdTime_" + a).val().replace(new RegExp("-","gm"),"/")).getTime();
                    	} else {
                    		item.itemNum = $("#cdTimes_" + a).val();
                    	}
                    }
                    item.itemCategory = $("#category_" + a).val();
                    attach.push(item);
            	}
            }
            email_json.attach = attach;
            if (delaySend === undefined) {
                if ($('#send').is(':checked') || !$('#delaySend').is(':checked')) {
                    delaySend = true;
                }
            } else {
                delaySend = false;
            }
            var json = JSON.stringify(email_json);
            sysComponents.showHelpMessage(viewLocale.form.save.loading);
            $.post(REPORT_ROOT + '/statistics/email/save', {
                data: json,
                isSendNow: delaySend
            }, function (data, status) {
                goPage(sysPage.currPage);
                if (operType == 'edit') {
                    sysComponents.showHelpMessage(viewLocale.form.save.success);
                } else if (operType == 'add') {
                    mailForm.resetForm();
                    $('.ui-dialog-title').html(viewLocale.form.title.add);
                }
                if (data !== null) {
                    sysComponents.showHelpMessage(viewLocale.form.save.success);
                    mailForm.resetForm();
                } else {
                    sysComponents.showHelpMessage(viewLocale.form.save.fail, 'error');
                }
            });
            $('#menuEdit').hide();
            $("#mail_list").show();
        },

        /**
         * 显示编辑窗口
         *
         * @@param {} type：add,edit,view
         * @param {}
         *            id
         * @param {}
         *            pid
         */
        showEdit: function (type, id) {
            $("#mail_list").hide();
            mailForm.resetForm();
            $('#menuEdit').validate().form();
            operType = type;
            if (operType == 'add') {
            	// 新增邮件时附件的默认显示
            	$('#category_1').val(1);
        		$('#item_id_item_1').html('');
        		sysComponents.getItemByCategoryType('item_id_item_1', 1);
        		$('#num_NtoB_1').hide();
        		$('#cdTimes_NtoB_1').show();
        		$('#cdTime_NtoB_1').show();
        		$('#category_2').val(1);
        		$('#item_id_item_2').html('');
        		sysComponents.getItemByCategoryType('item_id_item_2', 1);
        		$('#num_NtoB_2').hide();
        		$('#cdTimes_NtoB_2').show();
        		$('#cdTime_NtoB_2').show();
        		$('#category_3').val(101);
        		$('#item_id_item_3').html('');
        		$('#num_NtoB_3').show();
        		$('#item_id_NtoB_3').hide();
        		$('#cdTimes_NtoB_3').hide();
        		$('#cdTime_NtoB_3').hide();
        		$('#category_4').val(102);
        		$('#item_id_item_4').html('');
        		$('#num_NtoB_4').show();
        		$('#item_id_NtoB_4').hide();
        		$('#cdTimes_NtoB_4').hide();
        		$('#cdTime_NtoB_4').hide();
                $('.modal-title').html(viewLocale.form.title.add);
                $('#btn_save').show();
            } else {
                if (operType == 'view') {
                    $('.modal-title').html(viewLocale.form.title.view);
                    $('#btn_save').hide();
                } else if (operType == 'edit') {
                    $('.modal-title').html(viewLocale.form.title.edit);
                    $('#btn_save').show();
                }
                operType = 'edit';
                $.post(REPORT_ROOT + '/statistics/email/get', {
                    id: id
                }, function (data) {
                    sysComponents.setValues(data);
                });
                $('#id').val(id);
            }
            $("h4#menuEditLabel").html("新建邮件");
            $('#menuEdit').show();
        },

        /**
         * send
         */
        send: function (id) {
            $.post(REPORT_ROOT + '/statistics/email/send', {
                id: id
            }, function (data, status) {
                if (data) {
                    sysComponents.showHelpMessage('邮件发送成功');
                    mailForm.resetForm();
                    goPage(sysPage.currPage);
                } else {
                    sysComponents.showHelpMessage('邮件发送失败', 'error');
                }
            });
            $('#menuEdit').hide();
            $("#mail_list").show();
        },

        cancle: function () {
            $("#send").attr("checked", false);
            $("#dialog_message_for_send").modal('hide');
        },

        checkValue: function () {
            function chkval() {
                if ($('#allPlayer').is(':checked') && !$('#allGirl').is(':checked')) {
                    $("#playerId").attr({'value': -1, 'readonly': 'readonly'});
                    $("#playerId").val(-1);
                } else if (!$('#allPlayer').is(':checked') && $('#allGirl').is(':checked')) {
                    $("#playerId").attr({'value': -2, 'readonly': 'readonly'});
                    $("#playerId").val(-2);
                } else if ($('#allPlayer').is(':checked') && $('#allGirl').is(':checked')) {
                    $("#playerId").attr({'value': -3, 'readonly': 'readonly'});
                    $("#playerId").val(-3);
                } else if (!$('#allPlayer').is(':checked') && !$('#allGirl').is(':checked')) {
                    $("#playerId").attr({'value': 0, 'readonly': false});
                    $("#playerId").val(0);
                }
            }

            chkval();
            $('#allPlayer').click(function () {
                chkval();
            });
            $('#allGirl').click(function () {
                chkval();
            });
        },

        showOtherReward: function (i) {
            var div = "<div class=\"col-md-12\" id=\"reward" + i + "\">" +
                "<label class=\"col-sm-3 control-label\" for=\"attachId" + i + "\"> 道具" + i + " </label>" +
                "<div class=\"col-sm-3\">" +
                "<select class=\"form-control\" id=\"attachId" + i + "\" name=\"attachId" + i + "\"></select>" +
                "</div>" +
                "<label class=\"col-sm-2 control-label\" for=\"attachNum" + i + "\"> 数量 </label>" +
                "<div class=\"col-sm-3\">" +
                "<input type=\"text\" id=\"attachNum" + i + "\" name=\"attachNum" + i + "\" class=\"form-control\" />" +
                "</div>" +
                "<button type=\"button\" class=\"btn btn-default\" onclick=\"mailForm.delReward(" + i + ");\" >删除</button>" +
                "</div>";
            $("#showOtherReward").append(div);
            sysComponents.getAllItem('attachId' + i);
        },

        delReward: function (j) {
            $("#reward" + j).remove();
            i--;
        },

        addReward: function () {
            if (i < 3) {
                mailForm.showOtherReward(i++);
            }
        }


    };
}();

//编辑项下拉框的的变换
editChange = function (type) {
	if(type == "category_1"){
		 if ($('#category_1 option:selected').val() == 0) {  // 礼物
		        $('#item_id_item_1').html('');
		        sysComponents.getItemByCategoryType('item_id_item_1', 0);
		        $('#_category').val('0');
//		        $("#item_id_NtoB").show();
		        $("#num_NtoB_1").show();
		        $("#cdTimes_NtoB_1").hide();
		        $("#cdTime_NtoB_1").hide();
		    } else { 
		        $('#item_id_item_1').html('');
		        sysComponents.getItemByCategoryType('item_id_item_1', $('#category_1 option:selected').val());
		        $('#_category').val('1');
		        $("#cdTimes_NtoB_1").show();
		        $("#cdTime_NtoB_1").show();
		        $("#num_NtoB_1").hide();
		    }   
	} else if(type == "category_2") {
		 if ($('#category_2 option:selected').val() == 0) {
		        $('#item_id_item_2').html('');
		        sysComponents.getItemByCategoryType('item_id_item_2', 0);
		        $('#_category').val('0');
		        $("#num_NtoB_2").show();
		        $("#cdTimes_NtoB_2").hide();
		        $("#cdTime_NtoB_2").hide();
		    } else {
		        $('#item_id_item_2').html('');
		        sysComponents.getItemByCategoryType('item_id_item_2', $('#category_2 option:selected').val());
		        $('#_category').val('1');
		        $("#cdTimes_NtoB_2").show();
		        $("#cdTime_NtoB_2").show();
		        $("#num_NtoB_2").hide();
		    } 
	} else if(type == "category_3") {
		 if ($('#category_3 option:selected').val() == 0) {
		        $('#item_id_item_3').html('');
		        sysComponents.getItemByCategoryType('item_id_item_3', 0);
		        $('#_category').val('0');
		        $("#item_id_NtoB_3").show();
		        $("#num_NtoB_3").show();
		        $("#cdTimes_NtoB_3").hide();
		        $("#cdTime_NtoB_3").hide();
		    } else if($('#category_3 option:selected').val() == 101 || $('#category_3 option:selected').val() == 102) {
		    	$("#num_NtoB_3").show();
		    	$("#cdTimes_NtoB_3").hide();
			    $("#cdTime_NtoB_3").hide();
		    	$("#item_id_NtoB_3").hide();
		    } else {
		        $('#item_id_item_3').html('');
		        sysComponents.getItemByCategoryType('item_id_item_3', $('#category_3 option:selected').val());
		        $('#_category').val('1');
		        $("#cdTimes_NtoB_3").show();
		        $("#cdTime_NtoB_3").show();
		        $("#item_id_NtoB_3").show();
		        $("#num_NtoB_3").hide();
		    } 
	} else if(type == "category_4") {
		 if ($('#category_4 option:selected').val() == 0) {
		        $('#item_id_item_4').html('');
		        sysComponents.getItemByCategoryType('item_id_item_4', 0);
		        $('#_category').val('0');
		        $("#num_NtoB_4").show();
		        $("#item_id_NtoB_4").show();
		        $("#cdTimes_NtoB_4").hide();
		        $("#cdTime_NtoB_4").hide();
		    } else if($('#category_4 option:selected').val() == 101 || $('#category_4 option:selected').val() == 102) {
		    	$("#num_NtoB_4").show();
		    	$("#cdTimes_NtoB_4").hide();
			    $("#cdTime_NtoB_4").hide();
		    	$("#item_id_NtoB_4").hide();
		    } else {
		        $('#item_id_item_4').html('');
		        sysComponents.getItemByCategoryType('item_id_item_4', $('#category_4 option:selected').val());
		        $('#_category').val('1');
		        $("#cdTimes_NtoB_4").show();
		        $("#cdTime_NtoB_4").show();
		        $("#item_id_NtoB_4").show();
		        $("#num_NtoB_4").hide();
		    } 
	}
   
}
