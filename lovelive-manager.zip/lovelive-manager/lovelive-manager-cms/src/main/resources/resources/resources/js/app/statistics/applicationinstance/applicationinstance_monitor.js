/**
 * Created by Administrator on 2016/4/12 0012.
 */

ApplicationMonitor = function () {

};

ApplicationMonitor.prototype = {
    ids: {},
    init: function (ids) {
        this.ids = ids;
    },
    loadInstanceStatics: function () {
        var self = this;
        self._loadCurrInsStatics();

        setInterval(function () {
            self._loadCurrInsStatics();
        }, 6000); //6 seconds
    },
    _loadCurrInsStatics: function () {
        var self = this;
        for (var key in this.ids) {
            $.post(REPORT_ROOT + "/statistics/monitorLog/", {
                instanceId: Number(this.ids[key])
            }, function (data) {
                var guid = data.instance.guid;
                try {
                    var remark = JSON.parse(data.remark);
                    $('#online_' + guid).html(remark.systemInfo.onlineCount);
                }
                catch (e) {
                    $('#online_' + guid).html("0");
                }
                if (data.normal){
                    $('#instance_' + guid).html("<h4><span class='label label-primary'>正常</span></h4>");
                }else{
                    $('#instance_' + guid).html("<h4><span class='label label-danger'>宕机</span></h4>");
                }


            });
        }

    },
    /**
     * 开始job
     * @param instanceId    实例ID
     */
    startJob: function (instanceId) {
        $.post(REPORT_ROOT + "/statistics/applicationInstance/startMonitor", {
            id: instanceId
        }, function (data) {

        })
    },
    /**
     * 停止Job
     * @param instanceId    实例ID
     * @param jobName       实例对应Job名字
     */
    stopJob: function (instanceId, jobName) {

    }
};

