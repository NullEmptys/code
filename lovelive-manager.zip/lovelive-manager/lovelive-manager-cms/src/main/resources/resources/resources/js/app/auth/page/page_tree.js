var treeId = "tag_tree";
var clkTreeNode = '';
// 叶子节点
var leafs;
onAsyncSuccess = function(event, treeId, treeNode, msg) {
	var _level = 0;

	var _nodes;
	var _childern;
	if (typeof treeNode == 'undefined') {
		var zTree = $.fn.zTree.getZTreeObj(treeId);
		_nodes = zTree.getNodes();
	} else {
		_level = treeNode.level;
		_nodes = [ treeNode ];
		_children = treeNode.children;
		if (_children.length == 0) {
			console.log(treeNode)
			treeNode.isParent = false;
		}
	}

	if (_level == 0) {
		expandNodes(_nodes);
	}
}

expandNodes = function(nodes) {
	if (!nodes)
		return;
	var zTree = $.fn.zTree.getZTreeObj(treeId);
	for (var i = 0, l = nodes.length; i < l; i++) {
		zTree.expandNode(nodes[i], true, false, false);
	}
}

onClick = function(event, treeId, treeNode) {
	clkTreeNode = treeNode;
	showListByTree(clkTreeNode.id);
}

beforeExpand = function(treeId, treeNode) {
	return true;
}
var setting = {
	async : {
		enable : true,
		url : REPORT_ROOT + "/auth/page/getForTree",
		autoParam : [ "id", "pid" ]
	},
	data : {
		simpleData : {
			enable : false
		},
		key : {
			//title : "name",
			children: "subsyspages",
			url: "none"
		}
	},
	view : {
		//expandSpeed : "slow"
	},
	callback : {
		onClick : onClick,
		onAsyncSuccess : onAsyncSuccess,
		beforeExpand : beforeExpand
	}
};

/**
 * 初始化树
 */
initTree = function() {
	// $("#form_tag").validation();
	$.fn.zTree.init($("#" + treeId), setting);
}