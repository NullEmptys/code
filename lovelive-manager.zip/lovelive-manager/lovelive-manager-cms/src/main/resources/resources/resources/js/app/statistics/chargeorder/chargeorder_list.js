sysPage = new SysPage();
var _data;
/**
 * 分页查询
 * 
 * @param {}
 *            search
 * @param {}
 *            currPage
 * @param {}
 *            perPage
 */
showList = function(playerId, channelId, orderType, orderState, startTime, endTime, currPage, pageSize) {
    $.post(REPORT_ROOT + "/statistics/chargeorder/listForPage",
        {
	    	playerId : playerId,
			channelId : channelId,
			orderType : orderType,
			orderState : orderState,
			startTime : startTime,
			endTime : endTime,
			currPage : currPage - 1,
			pageSize : pageSize
        }, function(data) {
            console.info(data);
            var _tpl = '<tr><td align=\'center\'>{playerId}</td><td align=\'center\'>{channelName}</td><td align=\'center\'>{subChannelId}</td><td align=\'center\'>{orderNumber}</td><td align=\'center\'>{goodsName}</td><td align=\'center\'>{payPrice}</td><td align=\'center\'>{orderState}</td><td align=\'center\'>{payway}</td><td align=\'center\'><a title="备注" href="javascript:showRemark(\'{summary}\')">备注</a></td><td align=\'center\'>{orderType}</td><td align=\'center\'>{createTime}</td><td align=\'center\'>{payBackTime}</td><td align=\'center\'>{notifyTime}</td><td align=\'center\'>{receiveNotifyTime}</td><td align=\'center\'>{finishTime}</td>'
                + '</tr>';
            var _html = '';
            $(data.content).each(function(index, element) {
            	if(element.createTime){
            		var newDate = new Date();
            		newDate.setTime(new Number(element.createTime));
            		element.createTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
            	}
            	if(element.payBackTime){
            		var newDate = new Date();
            		newDate.setTime(new Number(element.payBackTime));
            		element.payBackTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
            	}
            	if(element.notifyTime){
            		var newDate = new Date();
            		newDate.setTime(new Number(element.notifyTime));
            		element.notifyTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
            	}
            	if(element.receiveNotifyTime){
            		var newDate = new Date();
            		newDate.setTime(new Number(element.receiveNotifyTime));
            		element.receiveNotifyTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
            	}
            	if(element.finishTime){
            		var newDate = new Date();
            		newDate.setTime(new Number(element.finishTime));
            		element.finishTime = newDate.Format('yyyy-MM-dd HH:mm:ss');
            	}
            	if(element.orderState == 0){
            		element.orderState = '创建订单';
            	} else if(element.orderState == 1){
            		element.orderState = '通知游戏服';
            	} else if(element.orderState == 2){
            		element.orderState = '充值成功';
            	} else if(element.orderState == 3){
            		element.orderState = '充值失败';
            	}
            	if(element.orderType == 1){
            		element.orderType = '正常订单';
            	} else if(element.orderType == 2){
            		element.orderType = '补发订单';
            	}
                _html = _html+nano(_tpl, element);
            });
            $('#menu_list').html(_html);
            // 显示分页
            sysPage.showPage('nav_page', data.totalPages, currPage, data.totalElements);
            $('.bs-tooltip').tooltip();
            showAuth();
        });
}

showRemark = function(summary){
	$('#remark_content').html(summary);
	$('#remark_detail').modal('show');
}

showList_statistics = function(playerId, channelId, orderType, orderState, startTime, endTime,  currPage, pageSize) {
	$.post(REPORT_ROOT + "/statistics/chargeorder/statistics",
		{	playerId : playerId,
			channelId : channelId,
			orderType : orderType,
			orderState : orderState,
			startTime : startTime,
			endTime : endTime,
			currPage : currPage - 1,
			pageSize : pageSize
		},function(data) {
			var _tpl = '<tr><td align=\'center\'>{payPriceAll}</td>'
		        + '</tr>';
			var _html = '';
			 $(data).each(function (index, element) {
		            _html = _html+nano(_tpl, element);
		        })
			$('#statistics_list').html(_html);
			
		});
}

goPage = function(currPage) {
	showList($('#_userId').val(), $('#channelId').val(), $('#orderType').val(), $('#orderState').val(), $('#startTime').val(), $('#endTime').val(), currPage, $('#perPage').val());
}

