/**
 * 定义一个验证对象
 */
var ViewValidator = function() {
	var handleSubmit = function() {
		$('#form_menu').validate({
			errorElement : 'span',
			errorClass : 'help-block',
			focusInvalid : false,
			highlight : function(element) {
				$(element).closest('.form-group').addClass('has-error');
			},
			success : function(label) {
				label.closest('.form-group').removeClass('has-error');
				label.remove();
			},
			errorPlacement : function(error, element) {
				element.parent('div').append(error);
			},
			rules : {
				table_id : {
					required : true,
					digits : true,
					maxlength : 11
				},
				colume_value : {
					required : true,
					maxlength : 100
				}

			},
			messages : {

			}
		});

	}
	return {
		init : function() {
			handleSubmit();
		}
	};

}();

/*
 * 获取地址栏后的参数
 */
$(document).ready(function() {
	var url = window.location.search;
	if (url.indexOf("?") != -1) {
		var str = url.substr(1)
		strs = str.split("=");
		if(strs[1].length==0)
			return;
		$('#_userId').val(strs[1]);
		var channelId = $('#channelId').val();
		var orderType = $('#orderType').val();
		var orderState = $('#orderState').val();
		var startTime = $('#startTime').val();
		var endTime = $('#endTime').val();
		var perPage = $('#perPage').val();
		showList(strs[1], channelId, orderType, orderState, startTime, endTime, 1, perPage);
		showList_statistics(strs[1], channelId, orderType, orderState, startTime, endTime, 1, perPage);
	}
});

// 模糊查询后赋值
callback = function(item) {
	$('#_userId').val(item.playerId);
	$('#_userName').val(item.name);
	var perPage = $('#perPage').val();
	showList(item.playerId,'', '', '', '', '', 1, perPage);
	showList_statistics(item.playerId,'', '', '', '', '', 1, perPage);
}

$('#searching').searchPlayerInfo({
    complete: function (playerInfo) {
        callback(playerInfo);
    }
});