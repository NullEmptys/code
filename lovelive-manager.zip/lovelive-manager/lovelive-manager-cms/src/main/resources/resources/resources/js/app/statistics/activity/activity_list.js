sysPage = new SysPage();
var historyId;
var remoteId;
/**
 * 分页查询
 *
 * @param {}
 *            search
 * @param {}
 *            currPage
 * @param {}
 *            perPage
 */
var activity_list = function () {
    return {
        showHistoryList: function (currPage, pageSize) {
            $
                .post(
                    REPORT_ROOT + "/statistics/activity/listForPage",
                    {
                        currPage: currPage - 1,
                        pageSize: pageSize
                    },
                    function (data) {
                        var _tpl = '<tr><td style="text-align:center">{title}</td><td style="text-align:center">{implClass}</td><td style="text-align:center;  width: 300px;">{broadcastStartTime}&nbsp;\~\&nbsp;{broadcastEndTime}</td><td style="text-align:center;  width: 300px;">{startTime}&nbsp;\~\&nbsp;{endTime}</td><td style="text-align:center"><a title="奖励" href="javascript:activity_list.showReward({id},\'{implClass}\')">奖励</a></td><td style="text-align:center">{status}</td><td style="text-align:center">{publishName}</td><td style="text-align:center">{lastEditorName}</td>'
                            + '<td class="text-center"><span class="btn-group">'
                            + '<a title="'
                            + viewLocale.form.title.edit
                            + '" class="btn bs-tooltip" href="javascript:showEdit(\'edit\',{id});" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
                            + '<a title="'
                            + viewLocale.form.title.del
                            + '" class="btn bs-tooltip" href="javascript:activity_list.showHistoryDel({id});" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></a>'
                            + '</span></td></tr>';
                        var _html = '';
                        $(data.pageItems)
                            .each(
                                function (index, element) {
                                    if (element.broadcastStartTime) {
                                        var newDate = new Date(
                                            element.broadcastStartTime);
                                        element.broadcastStartTime = newDate
                                            .Format('yyyy/MM/dd HH:mm:ss');
                                    }
                                    if (element.broadcastEndTime) {
                                        var newDate = new Date(
                                            element.broadcastEndTime);
                                        element.broadcastEndTime = newDate
                                            .Format('yyyy/MM/dd HH:mm:ss');
                                    }
                                    if (element.startTime) {
                                        var newDate = new Date(
                                            element.startTime);
                                        element.startTime = newDate
                                            .Format('yyyy/MM/dd HH:mm:ss');
                                    }
                                    if (element.endTime) {
                                        var newDate = new Date(
                                            element.endTime);
                                        element.endTime = newDate
                                            .Format('yyyy/MM/dd HH:mm:ss');
                                    }
                                    if (element.implClass) {
                                        if (element.implClass == 'com.gamedo.gameServer.activity.loginReward.LoginRewardActivity') {
                                            element.implClass = '连续登陆';
                                        }
                                    }
                                    if (element.status == 0) {
                                        element.status = '<a class="btn bs-tooltip" href="javascript:activity_list.send(' + element.id + ');" data-original-title="发送">未发送</a>';
                                    } else if (element.status == 1) {
                                        element.status = '已发送';
                                    }
                                    _html = _html + nano(_tpl, element);
                                });
                        $('#local_menu_list').html(_html);

                        // 显示分页
                        sysPage.showPage('nav_page', data.pageCount, data.currPage, data.total);
                        $('.bs-tooltip').tooltip();
                    });
        },

        showRemoteList: function () {
            $.post(REPORT_ROOT + "/statistics/activity/remoteList",
                {},
                function (data) {
                    var _tpl = '<tr><td style="text-align:center">{title}</td><td style="text-align:center">{implClass}</td><td style="text-align:center;  width: 300px;">{broadcastStartTime}&nbsp;\~\&nbsp;{broadcastEndTime}</td><td style="text-align:center;  width: 300px;">{startTime}&nbsp;\~\&nbsp;{endTime}</td><td style="text-align:center"><a title="奖励" href="javascript:activity_list.showRemoteReward({id},\'{implClass}\')">奖励</a></td>'
                        + '<td class="text-center"><span class="btn-group">'
                        + '<a title="'
                        + viewLocale.form.title.edit
                        + '" class="btn bs-tooltip" href="javascript:showRemoteEdit({id});" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
                        + '<a title="'
                        + viewLocale.form.title.del
                        + '" class="btn bs-tooltip" href="javascript:activity_list.showRemoteDel({id});" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></a>'
                        + '</span></td></tr>';
                    var _html = '';
                    $(data).each(
                        function (index, element) {
                            if (element.implClass) {
                                if (element.implClass == 'com.gamedo.gameServer.activity.loginReward.LoginRewardActivity') {
                                    element.implClass = '连续登陆';
                                }
                            }
                            _html = _html + nano(_tpl, element);
                        });
                    $('#menu_list').html(_html);
                    $('.bs-tooltip').tooltip();
                });
        },
        send: function (id) {
            $('.ui-dialog-title').html(viewLocale.prompt);
            $('#remote_publish_activity_id').val(id);
            $('#remote_publish_dialog_message').modal('show');
        },

        doSend: function () {
            var id = $('#remote_publish_activity_id').val();
            $('#remote_publish_dialog_message').modal('hide');
            $.post(REPORT_ROOT + "/statistics/activity/sendActivity", {
                id: id
            }, function (data) {
                if (data) {
                    sysComponents.showHelpMessage(viewLocale.form.save.success);
                } else {
                    sysComponents.showHelpMessage(viewLocale.form.save.fail);
                }

                activity_list.showHistoryList(1, 20);
                activity_list.showRemoteList();
            });
            $('#remote_publish_activity_id').val('');
        },

        showHistoryDel: function (id) {
            $('.ui-dialog-title').html(viewLocale.prompt)
            historyId = id;
            $('#history_dialog_message').modal('show');
        },

        showRemoteDel: function (id) {
            $('.ui-dialog-title').html(viewLocale.prompt)
            remoteId = id;
            $('#remote_dialog_message').modal('show');
        },

        showDels: function () {
            $('.ui-dialog-title').html(viewLocale.prompt)
            delIds = '';
            var _checks = $("input[name='check']");
            $(_checks).each(function (index, element) {
                if ($(element).prop('checked')) {
                    delIds = delIds + $(element).prop('value') + ',';
                }
            });

            if (delIds.length == 0) {
                sysComponents.showHelpMessage(viewLocale.form.del.sel);
                return;
            } else {
                $('#dialog_message').modal('show');
            }
        },

        /**
         * 确定是否删除动作
         *
         * @param {}
         *            id
         */
        doHistoryDel: function () {
            // $('#dialog_message').dialog('close');
            sysComponents.showHelpMessage(viewLocale.form.del.loading);
            $.post(REPORT_ROOT + "/statistics/activity/historyDelete", {
                id: historyId
            }, function (data) {
                sysComponents.showHelpMessage(viewLocale.form.del.success);
                activity_list.showHistoryList(1, 20);
            });
            $('#history_dialog_message').modal('hide');
        },
        doRemoteDel: function () {
            // $('#dialog_message').dialog('close');
            sysComponents.showHelpMessage(viewLocale.form.del.loading);
            $.post(REPORT_ROOT + "/statistics/activity/remoteDelete", {
                id: remoteId
            }, function (data) {
                sysComponents.showHelpMessage(viewLocale.form.del.success);
                activity_list.showRemoteList()
            });
            $('#remote_dialog_message').modal('hide');
        },

        showRemoteReward: function (id, implClass) {
            $('#form_reward').validate().form();
            if ('连续登陆' == implClass) {
                $('.modal-title').html('奖励——' + implClass);
                $('#reward_info').html("");
                this.loadRemoteReward(id);
            } else {
                //alert('else');
            }
            $('#rewardEdit').modal('show');
            $('#btn_award_save').hide();
            $('#addRewardBtn').hide();
        },

        loadRemoteReward: function (id) {
            var self = this;
            $.post(
                REPORT_ROOT + '/statistics/activity/getRemoteReward',
                {
                    id: id
                },
                function (data) {
                    $('#activityId').val(id);
                    $(data).each(function (index, element) {
                        self.createRewardDetail(element);
                    });
                });
        },

        showReward: function (id, implClass) {
            $('#form_reward').validate().form();
            if ('连续登陆' == implClass) {
                $('.modal-title').html('奖励——' + implClass);
                $('#reward_info').html("");
                this.loadReward(id);
            } else {
                alert('else');
            }
            $('#rewardEdit').modal('show');
            $('#btn_award_save').show();
            $('#addRewardBtn').show();
        },

        loadReward: function (id) {
            var self = this;
            $.post(
                REPORT_ROOT + '/statistics/activity/getReward',
                {
                    id: id
                },
                function (data) {
                    $('#activityId').val(id);
                    $(data).each(function (index, element) {
                        self.createRewardDetail(element);
                    });
                });
        },

        createRewardDetail: function (item) {
            var _tpl =
                "<tr id='tr_{id}'>" +
                "<td>" +
                "<label class='control-label' for='title'>奖励类型： </label>" +
                "<select class='form-control' id='rewardType_{id}' name='rewardType[]' onchange='activity_list.onChangeRewardType({id})'>" +
                "<option value='102'>金币</option>" +
                "<option value='101'>钻石</option>" +
                "<option value='0'>礼物</option>" +
                "<option value='1'>服装</option>" +
                "<option value='3'>特效</option>" +
                "<option value='4'>相框</option>" +
                "<option value='2'>动作</option>" +
                "</select>" +
                "</td>" +
                "<td>" +
                "<label class='control-label' for='item_id_{id}'>道具名称： </label>" +
                "<select class='form-control' id='item_id_{id}' name='itemId[]'></select>" +
                "</td>" +
                "<td id='td_num_{id}'>" +
                "<label class='control-label'>数量： </label>" +
                "<input type='number' class='form-control' id='num_{id}' name='num[]' style='width:100px;'/>" +
                "</td>" +
                "<td id='td_cdTimes_{id}'>" +
                "<label class='control-label'>时效/永久： </label>" +
                "<select class='form-control' id='cdTimes_{id}' name='cdTimes[]' >" +
                "</select>" +
                "</td>" +
                "<td id='td_backGroundId_{id}'>" +
                "<label class='control-label'>背景图ID： </label>" +
                "<input type='text' class='form-control' id='backGroundId_{id}' name='backGroundId[]' style='width:120px;'/>" +
                "</td>" +
                "<td style='vertical-align:middle;'><a href='javascript:activity_list.delReward({id});'>删除</a></td>" +
                "</tr>";
            var _html = nano(_tpl, item);
            $('#reward_info').append(_html);
            $('#rewardType_' + item.id).val(item.rewardType + "");
            $('#num_' + item.id).val(item.rewardCounts != undefined ? item.rewardCounts : 0 + "");
            $('#backGroundId_' + item.id).val(item.backgroundId != undefined ? item.backgroundId : "");
            var category = $('#rewardType_' + item.id).val();
            sysComponents.getAllItem("item_id_" + item.id, category, item.rewardId);
            $('#item_id_' + item.id).val(item.rewardId + "");
            if (category == 102 || category == 101 || category == 0) {
                $('#td_num_' + item.id).show();
                $('#td_cdTimes_' + item.id).hide();
            } else {
                $('#td_cdTimes_' + item.id).show();
                $('#td_num_' + item.id).show();
                sysComponents.getClothCdTime("cdTimes_" + item.id, item.cdTimeType + "");
            }
        },

        delReward: function (id) {
            $('#tr_' + id).remove();
        },
        onChangeRewardType: function (id) {
            var category = $('#rewardType_' + id).val();
            sysComponents.getAllItem("item_id_" + id, category);
            if (category == 102 || category == 101 || category == 0) {
                $('#td_num_' + id).show();
                $('#td_cdTimes_' + id).hide();
            } else {
                $('#td_cdTimes_' + id).show();
                $('#td_num_' + id).show();
                sysComponents.getClothCdTime("cdTimes_" + id);
            }
        }

    }
}();
