var delIds;

sysPage = new SysPage();
var applicationMonitor = new ApplicationMonitor();
/**
 * 分页查询
 *
 * @param {}
 *          search
 * @param {}
 *          currPage
 * @param {}
 *          perPage
 */
showList = function (search, currPage, pageSize) {
    $.post(REPORT_ROOT + "/statistics/applicationInstance/listForPage", {
        search: search,
        currPage: currPage - 1,
        pageSize: pageSize
    }, function (data) {
        var _tpl = '<tr>' +
            '<td class="text-center" style="width: 300px;vertical-align:middle;" style="WORD-WRAP: break-word">{channelName}</td>' +
            '<td class="text-center" style="vertical-align:middle;"><a href="javascript:showEdit(\'view\',{id});">{instanceName}</a></td>' +
            '<td class="text-center" style="vertical-align:middle;"><div id="online_{guid}"></div></td>' +
            '<td class="text-center" style="vertical-align:middle;">' +
            '<div id="instance_{guid}"></div>' +
            '</td>'
            + '<td class="text-center" style="vertical-align:middle;"><span class="btn-group">'
            + '<a title="' + viewLocale.form.title.edit + '" class="btn bs-tooltip" href="javascript:showEdit(\'edit\',{id});" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
            + '<a title="' + viewLocale.form.title.del + '" class="btn bs-tooltip" href="javascript:showDel({id});" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></a>'
            //+ '<a title="' + viewLocale.form.title.del + '" class="btn bs-tooltip" href="javascript:startMonitor({id});" data-original-title="启动"><i class="glyphicon glyphicon-trash"></i></a>'
            + '</span></td></tr>';
        var _html = '';
        var ids = [];
        $(data.content).each(function (index, element) {
            console.log(element);
            ids.push(element.id);
            //ids[element.id] = element.guid;
            _html = _html + nano(_tpl, element);
        });
        $('#listView').html(_html);

        applicationMonitor.init(ids);
        applicationMonitor.loadInstanceStatics();

        $('.bs-tooltip').tooltip();
    });
}

goPage = function (currPage) {
    var _search = $('#input_search').val();
    var _perPage = $('#perPage').val();
    showList(_search, currPage, _perPage);
}

showDel = function (ids) {
    $('.ui-dialog-title').html(viewLocale.prompt)
    delIds = ids;
    $('#dialog_message').modal('show');
}

showDels = function () {
    $('.ui-dialog-title').html(viewLocale.prompt)
    delIds = '';
    var _checks = $("input[name='check']");
    $(_checks).each(function (index, element) {
        if ($(element).prop('checked')) {
            delIds = delIds + $(element).prop('value') + ',';
        }
    });

    if (delIds.length == 0) {
        sysComponents.showHelpMessage(viewLocale.form.del.sel);
        return;
    } else {
        $('#dialog_message').modal('show');
    }
};

/**
 * 确定是否删除动作
 *
 * @param {}
 *          id
 */
doDel = function () {
//$('#dialog_message').dialog('close');
    sysComponents.showHelpMessage(viewLocale.form.del.loading);
    var _l = (delIds + '').split(',').length;
    _l = (_l > 1) ? (_l - 1) : _l;
    $.post(REPORT_ROOT + "/statistics/applicationInstance/del", {
        ids: delIds
    }, function (data) {
        if (data.num == _l) {
            sysComponents.showHelpMessage(viewLocale.form.del.success);
        } else if (data.num == 0) {
            sysComponents.showHelpMessage(viewLocale.form.del.fail, 'error');
        } else {
            sysComponents.showHelpMessage(viewLocale.form.del.subSuccess + data.num);
        }
        goPage(sysPage.currPage);
    });
    $('#dialog_message').modal('hide');
};

/**
 * 渠道列表
 */
channelList = function () {
    $.post(REPORT_ROOT + "/statistics/channelInfo/getAll", function (data) {
        var _tpl = '<a href="javascript:showList({id});" id="channelGroup_{id}" class="list-group-item">{channelName}</a>';
        var _html = '';
        $(data).each(function (index, element) {
            _html = _html + nano(_tpl, element);
        });
        $('#channelGroup').html(_html);
    })
};

startMonitor = function (id) {
    applicationMonitor.startJob(id);
};