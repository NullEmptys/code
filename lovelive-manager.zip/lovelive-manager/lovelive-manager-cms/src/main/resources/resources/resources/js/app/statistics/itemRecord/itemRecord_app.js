/**
 *初始化组件
 */
initComponents=function(){
	var group;
	$('#btn_add').click(function () {
        showEdit('add');
    });
	
	$('#btn_save').click(function () {
		if ($('#form_page').valid()) {
			saveEdit();
		}
    });
	
	$('#btn_del').click(function () {
		showDels();
    });
	
	$('#btn_remove').click(function () {
		doDel();
    });
	
	$('#btn_search_type').click(function () {
		if($('#_userId').val()){
			showList($('#_userId').val(), $('#searchType_use').val(), $('#startDate').val(), $('#endDate').val(), 1, $('#perPage').val());
		}
    });
	
//	$("#searchType").change(function() {
//        $("input#searchContent").typeahead('destroy')
//        search('/statistics/player/search');
//    });
	
	$('#perPage').change(function () {
		if($('#_userId').val()){
			showList($('#_userId').val(), $('#searchType_use').val(), $('#startDate').val(), $('#endDate').val(), 1, $('#perPage').val());
		}
    });
	
	$('#checkAll').click(function () {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });
	$('#_userId').val('');
	$('#_userName').val('');
	
    ViewValidator.init();
}