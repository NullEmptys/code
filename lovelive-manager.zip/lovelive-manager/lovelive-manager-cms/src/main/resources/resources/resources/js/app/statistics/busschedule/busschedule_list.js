var delIds;

sysPage = new SysPage();
/**
 * 分页查询
 * 
 * @param {}
 *            search
 * @param {}
 *            currPage
 * @param {}
 *            perPage
 */
showList = function(search, currPage, pageSize) {
	$
			.post(
					REPORT_ROOT + "/statistics/busschedule/listForPage",
					{
						search : search,
						channel_id : $("#channel_id_search").val(),
						currPage : currPage - 1,
						pageSize : pageSize
					},
					function(data) {
						var _tpl = '<tr><td><input value="{id}" type="checkbox" name="check"></td><td><a href="javascript:showEdit(\'view\',{id});">{table_name}</a></td><td>{table_id}</td><td>{colume_name}</td><td>{colume_value}</td><td>{schedule_time}</td><td>{flag}</td><td>{failed}</td>'
								+ '<td class="text-center"><span class="btn-group">'
								+ '<a title="'
								+ viewLocale.form.title.edit
								+ '" class="btn bs-tooltip" href="javascript:showEdit(\'edit\',{id});" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
								+ '<a title="'
								+ viewLocale.form.title.del
								+ '" class="btn bs-tooltip" href="javascript:showDel({id});" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></a>'
								+ '</span></td></tr>';
						var _html = '';
						$(data.content)
								.each(
										function(index, element) {
											if (element.flag == 1)
												element.flag = '是';
											else
												element.flag = '否';
											if (element.failed == 1)
												element.failed = '<span style="color: rgb(255,0,0);">是</span>';
											else
												element.failed = '否';
											element.schedule_time = (element.year == '' ? '每'
													: element.year)
													+ '年'
													+ (element.month == '' ? '每'
															: element.month)
													+ '月'
													+ (element.day == '' ? '每'
															: element.day)
													+ '日'
													+ (element.hour == '' ? '每'
															: element.hour)
													+ '点'
													+ (element.minute == '' ? '每'
															: element.minute)
													+ '分';
											_html = _html + nano(_tpl, element);
										})
						$('#menu_list').html(_html);

						// 显示分页
						sysPage.showPage('nav_page', data.totalPages, currPage,
								data.totalElements);
						$('.bs-tooltip').tooltip();
				        
				        showAuth();
					});
}

goPage = function(currPage) {
	var _search = $('#input_search').val();
	var _perPage = $('#perPage').val();
	showList(_search, currPage, _perPage);
}

showDel = function(ids) {
	$('.ui-dialog-title').html(viewLocale.prompt)
	delIds = ids;
	$('#dialog_message').modal('show');
}

showDels = function() {
	$('.ui-dialog-title').html(viewLocale.prompt)
	delIds = '';
	var _checks = $("input[name='check']");
	$(_checks).each(function(index, element) {
		if ($(element).prop('checked')) {
			delIds = delIds + $(element).prop('value') + ',';
		}
	});

	if (delIds.length == 0) {
		sysComponents.showHelpMessage(viewLocale.form.del.sel);
		return;
	} else {
		$('#dialog_message').modal('show');
	}
}

/**
 * 确定是否删除动作
 * 
 * @param {}
 *            id
 */
doDel = function() {
	// $('#dialog_message').dialog('close');
	sysComponents.showHelpMessage(viewLocale.form.del.loading);
	var _l = (delIds + '').split(',').length;
	_l = (_l > 1) ? (_l - 1) : _l;
	$.post(REPORT_ROOT + "/statistics/busschedule/del", {
		ids : delIds
	}, function(data) {
		if (data.num == _l) {
			sysComponents.showHelpMessage(viewLocale.form.del.success);
		} else if (data.num == 0) {
			sysComponents.showHelpMessage(viewLocale.form.del.fail, 'error');
		} else {
			sysComponents.showHelpMessage(viewLocale.form.del.subSuccess
					+ data.num);
		}
		goPage(sysPage.currPage);
	});
	$('#dialog_message').modal('hide');
}