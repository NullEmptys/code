sysPage = new SysPage();
var _data;
/**
 * 分页查询
 * 
 * @param {}
 *            search
 * @param {}
 *            currPage
 * @param {}
 *            perPage
 */
//直接查询数据库
showList = function(playerId, achievement_id, achievement_type, currPage, pageSize) {
	$.post(REPORT_ROOT + "/statistics/achievement/listForPage",
	        {
		    	playerId : playerId,
		    	achievement_id : achievement_id,
		    	achievement_type : achievement_type,
	        }, function(data) {
		_data = data;
		page(data, currPage, pageSize);
	});
}

// 分页操作
page = function(data, currPage, pageSize) {
	var data1;
	if (data.length > (currPage - 1) * pageSize
			&& data.length <= currPage * pageSize) {
		data1 = data.slice((currPage - 1) * pageSize, data.length);
	} else if (data.length > currPage * pageSize) {
		data1 = data.slice((currPage - 1) * pageSize, currPage * pageSize);
	}
	var totalPages = Math.ceil(data.length / pageSize); // 向上取余
	show(data1, totalPages, currPage, data.length);
}

// 显示列表
show = function(data, totalPages, currPage, total) {
	var _tpl = '<tr><td align=\'center\'>{achieveId}</td><td align=\'center\'>{name}</td><td align=\'center\'>{description}</td><td align=\'center\'>{value}\/\{allValue}</td><td align=\'center\'>{rewarded}</td>'
			+ '<td class="text-center"><span class="btn-group">'
			+ '<a title="'
			+ viewLocale.form.title.edit
			+ '" class="btn bs-tooltip" href="javascript:showEdit(\'edit\',{value},{allValue},\'{rewarded}\',{achieveId});" data-original-title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>'
			+ '</span></td></tr>';
	var _html = '';
	$(data).each(function(index, element) {
		if(Number(element.allValue) > Number(element.value)){
			element.rewarded = '不可领取';
		} else {
			if(element.rewarded == 1){
				element.rewarded = '已领取';
			} else if(element.rewarded == 0){
				element.rewarded = '待领取';
			}
		}
		_html = _html + nano(_tpl, element);
	})
	$('#menu_list').html(_html);
	// 显示分页
	sysPage.showPage('nav_page', totalPages, currPage, total);
	$('.bs-tooltip').tooltip();
	showAuth();
}

goPage = function(currPage) {
	showList($('#_userId').val(), $('#achievement_id').val(), $('#achievement_type').val(), currPage, $('#perPage').val());
}

