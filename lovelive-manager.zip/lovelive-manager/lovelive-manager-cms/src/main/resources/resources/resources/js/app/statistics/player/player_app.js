/**
 *初始化组件
 */
initComponents = function () {
    var group;
    sysComponents.getItemByCategoryType('payPrice', 1);

    $("#btn_charge_record").click(function () {
        if ($("#playerId").val() == 'null' || $("#playerId").val() == '') {
            sysComponents.showHelpMessage("请查询玩家信息后再操作", "error");
        } else
            window.location.href = REPORT_ROOT + '/statistics/chargeorder?playerID=' + $("#playerId").val();
    });

    $("#btn_money_change").click(function () {
        if ($("#playerId").val() == 'null' || $("#playerId").val() == '') {
            sysComponents.showHelpMessage("请查询玩家信息后再操作", "error");
        } else
            window.location.href = REPORT_ROOT + '/statistics/moneyuse?playerID=' + $("#playerId").val();
    });

    $("#btn_item_change").click(function () {
        if ($("#playerId").val() == 'null' || $("#playerId").val() == '') {
            sysComponents.showHelpMessage("请查询玩家信息后再操作", "error");
        } else
            window.location.href = REPORT_ROOT + '/statistics/itemRecord?playerID=' + $("#playerId").val();
    });

    $("#btn_relationship").click(function () {
        if ($("#playerId").val() == 'null' || $("#playerId").val() == '') {
            sysComponents.showHelpMessage("请查询玩家信息后再操作", "error");
        } else
            window.location.href = REPORT_ROOT + '/statistics/girlrelation?playerID=' + $("#playerId").val();
    });

    $("#btn_hasItems").click(function () {
        //持有道具
        if ($("#playerId").val() == 'null' || $("#playerId").val() == '') {
            sysComponents.showHelpMessage("请查询玩家信息后再操作", "error");
        } else
            window.location.href = REPORT_ROOT + '/statistics/playerproperty?playerID=' + $("#playerId").val();
    });

    $("#btn_achievement").click(function () {
        //持有道具
        if ($("#playerId").val() == 'null' || $("#playerId").val() == '') {
            sysComponents.showHelpMessage("请查询玩家信息后再操作", "error");
        } else
            window.location.href = REPORT_ROOT + '/statistics/achievement?playerID=' + $("#playerId").val();
    });

    // 修改二次确认
    $("#btn_change").click(function () {
        if ($('#player_form').validate().form()){
            $('#alter_message').modal('show');
        }
    });
    // 执行修改
    $("#btn_alter").click(function () {
        player_form.update();
    });

    $("#btn_offline").click(function () {
        //强制下线
        if ($("#playerId").val() == 'null' || $("#playerId").val() == '') {
            sysComponents.showHelpMessage("请查询玩家信息后再操作", "error");
        } else
            playerList.offline($("#playerId").val());
    });

    $("#playerType").change(function () {
        var val = $(this).val();
        if(val == "2"){
            $("#girl").show();
        }else{
            $("#girl").hide();
        }
    });

    // 为该玩家充值
//    $("#btn_charge").click(function() {
//    	var playerId = $("#playerId").val()
//    	$("#playerId_charge").val(playerId);
//        $('#playerCharge').modal('show');
//    });
//    
//    // 充值二次确认
//    $("#btn_charge").click(function() {  
//    	$('#alter_charge').show();
//    });
//    
//    // 执行充值
//    $("#button_charge_do").click(function() {
//    	$('#playerCharge').modal('hide');
//    });

    ViewValidator.init();

};