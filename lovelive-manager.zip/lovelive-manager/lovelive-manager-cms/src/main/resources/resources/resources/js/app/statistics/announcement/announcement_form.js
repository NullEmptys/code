/**
 * Created by Administrator on 2016/4/22 0022.
 */
/**
 * 定义一个验证对象
 */
var announcement_form = function() {
	return {
		
		// 重置
		resetForm : function() {
			$('#form_menu')[0].reset();
			$('#id').val('');
		},
	
		// 执行保存动作
		saveEdit : function(operType) {
			var json = JSON.stringify($('#form_menu').serializeJSON());
			sysComponents.showHelpMessage(viewLocale.form.save.loading);
			if($('#_form').val() == 'local'){
				$.post(REPORT_ROOT + '/statistics/announcement/save', {
					data : json
				}, function(data, status) {
					if (operType == 'edit') {
						sysComponents.showHelpMessage(viewLocale.form.save.success);
					} else if (operType == 'add') {
						announcement_form.resetForm();
						$('.ui-dialog-title').html(viewLocale.form.title.add);
					}
					goPage(sysPage.currPage, "local_nav_page");
//					announcement_list.showList(1, $('#local_perPage').val());
				});
			} else if($('#_form').val() == 'server'){
				$.post(REPORT_ROOT + '/statistics/announcement/save_server', {
					data : json
				}, function(data, status) {
					if (data == 0) {
						sysComponents.showHelpMessage(viewLocale.form.save.success);
					} else {
						announcement_form.resetForm();
						$('.ui-dialog-title').html(viewLocale.form.title.add);
					}
					goPage(sysPage.currPage, "server_nav_page");
//					announcement_list.showList_server(1, $('#server_perPage').val());
				});
			}
			$('#menuEdit').modal('hide');
		},
		
		// 显示编辑窗口
		showEdit : function(type, form, id) {
			$('#_form').val(form);
			announcement_form.resetForm();
			$('#form_menu').validate().form();
			$('#operType').val(type);
			if ($('#operType').val() == 'add') {
				$('.modal-title').html('新增');
				$('#btn_save').show();
			} else {
				if ($('#operType').val() == 'view') {
					$('.modal-title').html(viewLocale.form.title.view);
					$('#btn_save').hide();
				} else if ($('#operType').val() == 'edit') {
					$('.modal-title').html('修改');
					$('#btn_save').show();
				}
				$('#operType').val('edit');
				if(form == 'local'){
					$.post(REPORT_ROOT + '/statistics/announcement/get', {
						id : id
					}, function(data) {
						// 时间格式的转换
						data = announcement_list.time(data);
						$('#down_content').val(data.content);
						$('#publisher').val(data.publisher);
						sysComponents.setValues(data);
						announcement_form.requiredType();
					});
				} else if(form == 'server'){
					$.post(REPORT_ROOT + '/statistics/announcement/get_server', {
						id : id
					}, function(data) {
						// 时间格式的转换
						data = announcement_list.time(data);
						$('#down_content').val(data.content);
						$('#publisher').val(data.publisher);
						sysComponents.setValues(data);
						announcement_form.requiredType();
					});
				}
				$('#id').val(id);
			}
			$('#menuEdit').modal('show');
		},
		
		requiredType : function(){
			if($('#type option:selected').val() == 1){
				$("#backGroundId").removeAttr('required');
				$("#title").attr('required','required');
				$("#down_content").attr('required','required');
			} else if($('#type option:selected').val() == 2) {
				$("#backGroundId").attr('required','required');
				$("#title").removeAttr('required');
				$("#down_content").removeAttr('required');
			}
		},
		
		
		// 编辑项下拉框的的变换
//		editChange : function(){
//			if($('#rewardType option:selected').val() != 11 && $('#rewardType option:selected').val() != 11){
//				$('#item_id').html('');
//				sysComponents.getItemByCategoryType('item_id', $('#rewardType option:selected') .val());
//				$('#_category').val('0');
//				$("#item_id_NtoB").show();
//				$("#num_NtoB").show();
//				$("#cdTimes_NtoB").hide();
//				$("#cdTime_NtoB").hide();
//			} else {
//				$('#item_id').html('');
//			}
//		}
		
			
	}
} ();



