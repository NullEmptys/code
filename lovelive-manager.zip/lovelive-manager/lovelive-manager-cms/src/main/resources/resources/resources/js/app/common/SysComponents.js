SysComponents = function () {
}
SysComponents.prototype = {
    /**
     * 获取道具列表
     */
    getAllItem: function (domId, category,itemId) {
        $('#' + domId).html('');
        var url = "/statistics/playerproperty/getAllItem";
        if (category) {
            url = "/statistics/playerproperty/getItems";
            $.post(REPORT_ROOT + url,{
                category:category
            }, function (data) {
                $(data).each(function (index, element) {
                    var _tpl = '<option value="{id}">{name}</option>';
                    var _tpl1 = '<option value="{id}" selected>{name}</option>';
                    if (itemId != element.id) {
                        $('#' + domId).append(nano(_tpl, element));
                    } else {
                        $('#' + domId).append(nano(_tpl1, element));
                    }
                })
            });
        }else{
            $.post(REPORT_ROOT + url, function (data) {
                $(data).each(function (index, element) {
                    var _tpl = '<option value="{id}">{name}</option>';
                    $('#' + domId).append(nano(_tpl, element));
                })
            });
        }

    },
    /**
     * 获取时效列表
     */
    getClothCdTime: function (domId,id) {
        $('#' + domId).html('');
        $.post(REPORT_ROOT + "/statistics/ipocdata/getClothCdTime", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{id}">{title}</option>';
                var _tpl1 = '<option value="{id}" selected>{title}</option>';
                if (id != element.id) {
                    $('#' + domId).append(nano(_tpl, element));
                } else {
                    $('#' + domId).append(nano(_tpl1, element));
                }
            })
        });
    },
    /**
     * 获取系统边栏
     */
    getSyspages: function (id) {
        $('#' + id).html('');
        $.post(REPORT_ROOT + "/systems/page/getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{id}">{name}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 获取系统菜单
     */
    getSysmenus: function (id) {
        $('#' + id).html('');
        $.post(REPORT_ROOT + "/systems/menu/getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{id}">{name}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 获取游戏道具列表
     */
    getGoodsInfos: function (id) {
        $('#' + id).html('');
        $.post(REPORT_ROOT + "/statistics/goodsinfo/getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{goods_id}">{goodsName}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 获取APPID列表
     */
    getAPPIDs: function (id) {
        //$('#' + id).html('');
        $.post(REPORT_ROOT + "/statistics/appid/getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{id}">{appId}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 获取Province列表
     */
    getProvinceInfos: function (id) {
        //$('#' + id).html('');
        $.post(REPORT_ROOT + "/statistics/provinceinfo/getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{id}">{province}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 获取ChannelInfo列表
     */
    getChannelInfos: function (id) {
        //$('#' + id).html('');
        $.post(REPORT_ROOT + "/statistics/channelInfo/getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{channel_id}">{name}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 获取RunProduct列表
     */
    getRunProducts: function (id) {
        //$('#' + id).html('');
        $.post(REPORT_ROOT + "/statistics/runproduct/getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{product_id}">{productName}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 获取GroupInfo列表
     */
    getGroupInfos: function (id) {
        //$('#' + id).html('');
        $.post(REPORT_ROOT + "/statistics/groupinfo/getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{group_id}">{groupName}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 获取GiftInfo列表
     */
    getGiftInfos: function (id) {
        //$('#' + id).html('');
        $.post(REPORT_ROOT + "/statistics/giftinfo/getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{giftId}">{giftTitle}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 获取TaskInfo列表
     */
    getTaskInfos: function (id) {
        //$('#' + id).html('');
        $.post(REPORT_ROOT + "/statistics/taskinfo/getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{task_id}">{taskDetail}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },

    // 由道具类型获取玩家道具列表
    getItemByCategoryType: function (id, categoryType) {
        $.post(REPORT_ROOT + "/statistics/playerproperty/getItemByCategoryType", {
            categoryType: categoryType
        }, function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{id}">{name}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },

    /**
     * 根据数据字典一级code获取数据
     *
     * @param pCode
     * @param comboBoxId:页面组件id
     */
    getDicts: function (pCode, comboBoxId) {
        $.get(REPORT_ROOT + "/sys/dict.htm?action=getDictsByPcode", {
            pCode: pCode
        }, function (data) {
            var _tpl = '<option value="{code}">{displayName}</option>';
            $(data).each(function (index, element) {
                $('#' + comboBoxId).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 获取用户组信息
     *
     * @param {}
     *          默认选中后值
     * @param {}
     *          查询关键字
     * @param {}
     *          comboBoxId
     */
    getGroups: function (search, comboBoxId, value) {
        $('#' + comboBoxId).html('');
        $.get(REPORT_ROOT + "/sys/group.htm?action=search", {
            search: search
        }, function (data) {
            var _tpl = '<option value="{id}">{name}</option>';
            var _tpl1 = '<option value="{id}" selected>{name}</option>';
            $(data).each(function (index, element) {
                if (value != element.id) {
                    $('#' + comboBoxId).append(nano(_tpl, element));
                } else {
                    $('#' + comboBoxId).append(nano(_tpl1, element));
                }
            })
        });
    },
    /**
     * 获取隶属于某一用户组下的角色
     *
     * @param {}
     *          默认选中后值
     * @param {}
     *          查询关键字
     * @param {}
     *          comboBoxId
     */
    getRoles: function (value, groupId, comboBoxId) {
        $('#' + comboBoxId).html('');
        $.get(REPORT_ROOT + "/sys/role.htm?action=getByGroup", {
            groupId: groupId
        }, function (data) {
            var _tpl = '<option value="{id}">{name}</option>';
            var _tpl1 = '<option value="{id}" selected>{name}</option>';
            $(data).each(function (index, element) {
                if (value != element.id) {
                    $('#' + comboBoxId).append(nano(_tpl, element));
                } else {
                    $('#' + comboBoxId).append(nano(_tpl1, element));
                }
            })
            $('#' + comboBoxId).val(value);
        });
    },
    /**
     * 根据Id获取菜单
     *
     * @param {}
     *          pid
     */
    getMenus: function (pid) {
        $.get(REPORT_ROOT + "/sys/menu.htm?action=getMenuByUserId", {
            pid: pid
        }, function (data) {
            var i = 0;
            $(data).each(function (index, element) {
                if (element.url == null) {
                    element.url = '#1';
                }
                if (pid == -1) {
                    $('#navItem').append('<li id="menu' + element.id + '"><a href="'
                        + REPORT_ROOT + element.url + '"><i class="' + element.css + ' floatleft pt10"></i> <span>' + element.name
                        + '</span></a></li>');
                    if (currentMenu == element.id) {
                        $('#menu' + element.id).toggleClass('current');
                    }
                } else {
                    $('#subNavItem').append('<li id="subMenu' + element.id
                        + '"><a href="' + REPORT_ROOT + element.url + '"> '
                        + element.name + '</a></li>');
                    if (subMenu == -1 && i == 0) {
                        subMenu = element.id;
                    }
                    if (subMenu == element.id) {
                        $('#subMenu' + element.id).toggleClass('active');
                    }
                }
                i++;
            })
        });
    },
    /**
     * 获取provider
     */
    getProviders: function (id) {
        $('#' + id).html('');
        $.get(REPORT_ROOT + "/buss/provider.htm?action=getAll", function (data) {
            $(data).each(function (index, element) {
                var _tpl = '<option value="{id}">{name}</option>';
                $('#' + id).append(nano(_tpl, element));
            })
        });
    },
    /**
     * 将json对象根据key值设置到form里的组件里
     *
     * @param {}
     *          data：json对象
     */
    setValues: function (data) {
        for (var key in data) {
            var _obj = $('#' + key);
            if (_obj.attr('type') == 'checkbox') {
                if (data[key] == 1) {
                    _obj.prop("checked", "checked");
                }
            } else {
                if (_obj.is('input') || _obj.is('select')) {
                    _obj.val(data[key]);
                } else if (_obj.is('textarea')) {
                    _obj.text((data[key] == null) ? '' : data[key]);
                    _obj.val((data[key] == null) ? '' : data[key]);
                }
            }
        }
    },
    /**
     * 将数组转为字符串，并以split间隔
     *
     * @param array
     * @param split
     *          间隔符
     */
    array2String: function (array, split) {
        if (typeof array == 'undefined') {
            return '';
        }
        var _str = '';
        $.each(array, function (index, element) {
            _str += element + split
        });
        return _str;
    },
    /**
     * 将字符串转换成数组
     *
     * @param str
     * @param split
     * @returns {*}
     */
    string2array: function (str, split) {
        if ($.trim(str) != '') {
            return str.split(split);
        } else {
            return '';
        }
    },
    showHelpMessage: function (msg, type) {
        toastr.clear();
        if (type == 'success') {
            toastr.success(msg);
        } else if (type == 'error') {
            toastr.error(msg);
        } else if (type == 'warn') {
            toastr.warn(msg);
        } else {
            toastr.info(msg);
        }
    }
}

sysComponents = new SysComponents();