/**
 *初始化组件
 */
initComponents=function(){
	var group;
	$('#btn_add').click(function () {
        showEdit('add');
    });
	
	$('#btn_save').click(function () {
		if ($('#form_menu').valid()) {
			saveEdit();
		}
    });
	
	$('#btn_del').click(function () {
		showDels();
    });
	
	$('#btn_remove').click(function () {
		doDel();
    });
	
	$('#btn_search').click(function () {
        showList($('#input_search').val(), 1, $('#perPage').val());
    });
	
	$('#input_search').bind('keypress', function (event) {
        if (event.keyCode == "13") {
           showList($('#input_search').val(), 1, $('#perPage').val());
        }
    });
	
	$('#perPage').change(function () {
        showList($('#input_search').val(), 1, $('#perPage').val());
    });
	
	$('#checkAll').click(function () {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });
	
//	$('#pname').focus(function(){
//		var id = $('#id').val(); 
//		$('#pname').autocomplete({
//			minLength : 0,
//			source : function(request, response){
//				$.ajax({
//					type:"POST",
//					url: DMP_ROOT + "/sys/menu.htm?action=search",
//					data: { search : request.term,id:id },
//					dataType: "JSON",
//					async: true,
//					success: function(data){
//						response($.grep(data,function(item){
//								return item;
//						}));
//					}
//				});
//			},
//			focus: function(event,ui){
//				$("#pname").val(ui.item.name);
//				return false;
//			},
//			select: function(event,ui){
//				$("#pname").val(ui.item.name);
//				$("#pid").val(ui.item.id);
//				return false;
//			}
//		}).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
//		      return $( "<li>" )
//		        .append( "<a>" + item.name   + "</a>" )
//		        .appendTo( ul );
//		};
//	})
//	
//	$('#pname').blur(function(){
//		var name = $('#pname').val();
//		if($('#pname').val()==""){
//			$("#pid").val("");
//		}
//	})

    showList('', 1, 20);

    ViewValidator.init();
}