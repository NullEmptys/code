SysPage = function() {
	this.currPage = 1;
	this.url = "";
	this.data = false;
}
SysPage.prototype = {
	/**
	 * 构造page组件
	 * 
	 * @param {}
	 *          pageCount
	 * @param {}
	 *          currPage
	 */
	showPage : function(name, pageCount, currPage, total, callback, pageName) {
	    var hdtdmp = 'hdtdmp';
	    if(pageName!==null && pageName!==undefined){
	        hdtdmp = pageName;
	    }
		this.currPage=currPage;
		var _pages_info_div = name + '_info'
		var _pages_info = $('div[name='+_pages_info_div+']');
		var _tpl = '当前第&nbsp;{currPage}&nbsp;页&nbsp;/&nbsp;共&nbsp;{pageCount}&nbsp;页&nbsp;/&nbsp;共&nbsp;{total}&nbsp;条记录'
		var _info = {};
		_info.currPage = currPage;
		_info.pageCount = (pageCount==0)?1:pageCount;
		_info.total = total;

		$(_pages_info).each(function(index, element) {
					$(element).html('');
					$(element).append(nano(_tpl, _info));
				});
		var _pages = $('ul[name=' + name + ']');

		var _start = ((currPage - 4) < 1) ? 1 : ((currPage - 4));
		var _end = ((_start + 8) > pageCount) ? pageCount : (_start + 8);
		if (_end - _start < 8) {
			_start = ((_end - 8) < 1) ? 1 : (_end - 8);
		}
		var _html = '';
		if (pageCount == 1) {
			$(_pages).html('');
			return;
		}
		if (pageCount > 1) {
			var _pre = currPage - 1;
			if (currPage > 1) {
				_html += ('<li><a class="'+hdtdmp+'_page_index" href="#" id="'+hdtdmp+'_page_index_1">首页</a></li>')
				_html += ('<li><a class="'+hdtdmp+'_page_index" id="'+hdtdmp+'_page_index_'
					+ _pre + '">上一页</a></li>')
			}
		}
		for (var i = _start; i <= _end; i++) {
			if (i != currPage) {
				_html += ('<li><a class="'+hdtdmp+'_page_index" href="#" id="'+hdtdmp+'_page_index_' + i
						+ '">' + i + '</a></li>')
			} else {
				_html += ('<li class="active"><a class="'+hdtdmp+'_page_index" id="'+hdtdmp+'_page_index_'
						+ i + '">' + i + '</a></li>')
			}
		}
		if (currPage < pageCount) {
			var _next = currPage + 1;
			_html += ('<li><a class="'+hdtdmp+'_page_index" href="#" id="'+hdtdmp+'_page_index_'
					+ _next + '">下一页</a></li>')
			_html += ('<li><a class="'+hdtdmp+'_page_index" href="#" id="'+hdtdmp+'_page_index_'
					+ pageCount + '">末页</a></li>')
		}
		$(_pages).html(_html)
		var _pindexs = $('.'+hdtdmp+'_page_index');

		$(_pindexs).each(function(index, e) {
					$(e).click(function() {
								var _id = $(this).prop("id");
								_id = _id.substring(_id.lastIndexOf('_') + 1, _id.length);
								if(pageName !== undefined){
									goPage(_id * 1, pageName);
								}else{
									goPage(_id * 1);
								}
								
							})
				});
	}
}
