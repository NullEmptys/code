/**
 * Created by Administrator on 2016/4/22 0022.
 */
/**
 *初始化组件
 */
initComponents = function () {
	
	$('#btn_detail_close').click(function() {
		$("#activity_detail").modal("hide");
	});
	
	$('#btn_del').click(function() {
		announcement_form.showDel();
	});
	
	$('#btn_remove').click(function() {
		if($('#_form').val() == 'local'){
			announcement_list.doDel();
		} else if($('#_form').val() == 'server'){
			announcement_list.doDel_server();
		}
	});
	
	
	$('#perPage').change(function() {
		announcement_list.showList(1, $('#perPage').val());
	});
	
	$('#local_perPage').change(function() {
		announcement_list.showList(1, $('#local_perPage').val());
	});
	$('#server_perPage').change(function() {
		announcement_list.showList_server(1, $('#server_perPage').val());
	});
	
	$('#type').change(function() {
		if($('#type option:selected') .val() == "1"){
			$("#backGroundId").removeAttr('required');
			$("#title").attr('required','required');
			$("#down_content").attr('required','required');
			$("#edit_backGroundId").hide();
//			$("#btn_save").click();  // 触发点击，变换提示项
		} else {
			$("#backGroundId").attr('required','required');
			$("#title").removeAttr('required');
			$("#down_content").removeAttr('required');
			$("#edit_backGroundId").show();
//			$("#btn_save").click();  // 触发点击，变换提示项
		}
	});
	
    $('#btn_new').click(function () {
    	announcement_form.showEdit('add', 'local');
    });
    
    $('#btn_save').click(function () {
        if ($('#form_menu').valid()) {
        	announcement_form.saveEdit($('#operType').val());
        }
    });    
	
	$('#btn_doSend').click(function () {
		announcement_list.doSend();
    });
	
	$('#btn_download').click(function () {
//		$('#down_show').modal('show');
		announcement_list.doDown();
    });
	
//	$('#btn_doDown').click(function () {
//		announcement_list.doDown();
//    });
    
    announcement_list.showList(1, $('#local_perPage').val());
    announcement_list.showList_server(1, $('#server_perPage').val());
  
};