/**
 *初始化组件
 */
initComponents = function () {
    var group;
    $('#btn_add').click(function () {
        showEdit('add');
    });

    $('#btn_save').click(function () {
        if ($('#form_menu').valid()) {
            saveEdit();
        }
    });

    $('#btn_del').click(function () {
        showDels();
    });

    $('#btn_remove').click(function () {
        doDel();
    });

    $('#btn_search').click(function () {
        showList($('#input_search').val(), 1, $('#perPage').val());
    });

    $('#input_search').bind('keypress', function (event) {
        if (event.keyCode == "13") {
            showList($('#input_search').val(), 1, $('#perPage').val());
        }
    });

    $('#perPage').change(function () {
        showList($('#input_search').val(), 1, $('#perPage').val());
    });

    $('#checkAll').click(function () {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });

    $('#btn_auth_save').click(function () {
        saveAuthTree();
    });

    showList('', 1, 20);

    ViewValidator.init();
}