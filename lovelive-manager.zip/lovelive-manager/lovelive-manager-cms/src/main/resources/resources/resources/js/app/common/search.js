(function ($) {
    var defaults = {
        complete: null
    };
    $.fn.searchPlayerInfo = function (options) {
        var self = this;
        var options = $.extend(defaults, options || {});
        var _html = showInputDiv();
        self.append(_html);
        //sysComponents.getChannelInfos('channelId');
        //var $channelId = self.find('#channelId');
        //$channelId.change(function () {
        //    $searchContent.val('');
        //});
        var $searchType = self.find('#searchType');
        var $searchContent = self.find('#searchContent');
        $searchType.change(function () {
            $searchContent.val('');
        });
        $searchContent.typeahead({
                source: function (query, process) {
                    var url = REPORT_ROOT + '/statistics/player/search';
                    var searchType = $.trim($searchType.val());
                    if (searchType === '') {
                        searchType = 1;
                    }
                    $.ajax({
                        url: url,
                        type: 'POST',
                        dataType: 'JSON',
                        data: {
                            "searchType": searchType,
                            "query": query
                        },
                        success: function (data) {
                            if (data.length === 0) {
                                $searchContent.val('');
                                self.typeahead('destroy');
                            }
                            return process(data);
                        }
                    });
                },
                displayText: function (item) {
                    if ($searchType.val() == 1) {
                        return "" + item.playerId;
                    } else if ($searchType.val() == 2) {
                        return "" + item.name;
                    } else {
                        return "" + item.playerId;
                    }
                },
                //autoSelect: true,
                afterSelect: function (playerInfo) {
                    console.log(playerInfo);
                    if ($.isFunction(options.complete)) {
                        options.complete.call(this, playerInfo);
                    }
                }
            }
        );

    };

    var showInputDiv = function () {
        var _html = "<div class=\"form-group\">" +
            "<div class=\"input-group\">" +
            //"<div class=''>" +
            //"<select class='form-control' id='channelId' name='channelId'></select>" +
            //"</div>" +
            "<div class=\"input-group-btn\">" +
            "<select class=\"form-control\" id=\"searchType\" name=\"searchType\">" +
            "<option value=\"1\">账号ID</option>" +
            "<option value=\"2\">角色名</option>" +
            "</select>" +
            "</div>" +
            "<div id=\"showResult\"><input type=\"text\" class=\"form-control\" id=\"searchContent\" value=\"\" placeholder=\"search...\"/></div>" +
            "</div>" +
            "</div>";
        return _html;
    }
})
(window.jQuery);
