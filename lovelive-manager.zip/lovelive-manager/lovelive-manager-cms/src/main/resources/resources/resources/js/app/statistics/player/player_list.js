var PlayerList = function() { };

PlayerList.prototype = {
    chargeRecord: function(id) {
        var src;
        if (id == null) {
            //查询所有 “充值记录”
        } else {
            //查询单个"充值记录"，并将id显示在查询框中
        }
        $("#iframe").attr("src", src);
    },

    changeMoney: function(id) {
        var src;
        if (id == null) {
            //查询所有 “货币获取及消耗”
        } else {
            //查询单个"货币获取及消耗"
        }
        $("#iframe").attr("src", src);
    },

    changeItem: function(id) {
        var src;
        if (id == null) {
            //查询所有 “道具获取及消耗”
        } else {
            //查询单个"道具获取及消耗"
        }
        $("#iframe").attr("src", src);
    },

    relationship: function(id) {
        var src;
        //查询玩家的模特信息
        $("#iframe").attr("src", src);
    },

    hasItems: function(id) {
        var src;
        //玩家持有道具
        $("#iframe").attr("src", src);
    },

    offline: function(id) {
        console.info(id);
        $.post(REPORT_ROOT + '/statistics/player/offline',
            {"id": id}, function(data){
                console.info(typeof(data) === "boolean");
                if((typeof(data) === "boolean" && data === true) ||
                    (typeof(data) === "string" && data === "true")){
                    sysComponents.showHelpMessage("该用户下线成功!");
                }else{
                    sysComponents.showHelpMessage("该用户下线失败!");
                }
        });
    }
}

var playerList = new PlayerList();

