/**
 *初始化组件
 */
initComponents=function(){
	var group;	
	$('#btn_save').click(function () {
		if ($('#form_menu').valid()) {
			saveEdit();
		}
    });
	
	$('#btn_del').click(function () {
		showDels();
    });
	
	$('#btn_remove_open').click(function () {
		$('#openTime').val('');
    });
	
	$('#btn_remove_close').click(function () {
		$('#closeTime').val('');
    });
	
	$('#btn_remove').click(function () {
		doDel();
    });
	
	$('#btn_search').click(function () {
        showList($('#searchContent').val(), 1, $('#perPage').val());
    });
	
	$('#perPage').change(function () {
        showList(1, $('#perPage').val());
    });
	
	$('#checkAll').click(function () {
        $("input[name='check']").prop("checked", $(this).prop("checked"));
    });
	showList(1, $('#perPage').val());
	
}