var delIds;
var delrecipient;
var delmask;
var currId;
var currPage = 1;

sysPage = new SysPage();
/**
 * 分页查询
 *
 * @param {}
 *          search
 * @param {}
 *          currPage
 * @param {}
 *          perPage
 */
showList = function (search, currPage, pageSize) {
    $.post(REPORT_ROOT + "/auth/menu/listForPage", {
    	currId: currId,
        search: search,
        currPage: currPage,
        pageSize: pageSize
    }, function (data) {
        var _tpl = '<tr><th><input value="{name}" type="checkbox" name="check"></th><td>{id}</td><td>{name}</td><td>{maskString}</td>'
            + '<td class="text-center"><span class="btn-group">'
            + '<a title="'+viewLocale.form.title.del+'" class="btn bs-tooltip" href="javascript:showDel({id},\'{name}\',{mask});" data-original-title="Delete"><i class="glyphicon glyphicon-trash"></i></a>'
            + '</span></td></tr>';
        var _html = '';
        $(data.pageItems).each(function (index, element) {
        	switch(element.mask){
        	case 1:
        		element.maskString = 'READ';
        		break;
        	case 2:
        		element.maskString = 'WRITE';
        		break;
        	case 4:
        		element.maskString = 'CREATE';
        		break;
        	case 8:
        		element.maskString = 'DELETE';
        		break;
        	case 16:
        		element.maskString = 'ADMINISTRATION';
        		break;
        	}
            _html = _html+nano(_tpl, element);
        })
        $('#account_list').html(_html);
        
        // 显示分页
        sysPage.showPage('nav_page', data.pageCount, data.currPage, data.total);
        $('.bs-tooltip').tooltip();
        
        showAuth();
    });
}

showListByTree = function (cid) {
	currId = cid;
	$('#id').val(cid);
    var _search = $('#input_search').val();
    var _perPage = $('#perPage').val();
    showList(_search, currPage, _perPage);
}

goPage = function (currPage) {
    var _search = $('#input_search').val();
    var _perPage = $('#perPage').val();
    showList(_search, currPage, _perPage);
}

showDel = function (ids,recipient,mask) {
	$('.ui-dialog-title').html(viewLocale.prompt)
    delIds = ids;
	delrecipient = recipient;
	delmask = mask;
    $('#dialog_message').modal('show');
}

/**
 * 确定是否删除动作
 *
 * @param {}
 *          id
 */
doDel = function () {
    //$('#dialog_message').dialog('close');
    sysComponents.showHelpMessage(viewLocale.form.del.loading);
    var _l = (delIds + '').split(',').length;
    _l = (_l > 1) ? (_l - 1) : _l;
    $.post(REPORT_ROOT + "/auth/menu/del", {
        id: $('#id').val(),
        recipient : delrecipient,
		mask : delmask
    }, function (data) {
        if (data.num == _l) {
            sysComponents.showHelpMessage(viewLocale.form.del.success);
        } else if (data.num == 0) {
            sysComponents.showHelpMessage(viewLocale.form.del.fail, 'error');
        }else {
            sysComponents.showHelpMessage(viewLocale.form.del.subSuccess + data.num);
        }
        goPage(sysPage.currPage);
    });
    $('#dialog_message').modal('hide');
}