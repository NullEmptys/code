package net.gamedo.server.paradise;

import com.github.sd4324530.fastweixin.api.response.BaseResponse;
import com.github.sd4324530.fastweixin.util.JSONUtil;
import com.github.sd4324530.fastweixin.util.NetWorkCenter;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2016/4/9 0009.
 */
public class MailTest /*extends TestCase*/ {
    /*private final static String remoteUrl = "http://localhost:8080/gameServer/app/api/";

    public MailTest(String testName) {
        super(testName);
    }

    public static Test suite() {
        return new TestSuite(MailTest.class);
    }

    //测试发送邮件
    public void testSendMail() {
        Map<String, Object> map = new HashMap<>();
        map.put("targetPlayerId", 30);
        map.put("title", 1);
        map.put("content", 1);
        String postUrl = remoteUrl + "mail/sendMail";
        Map<String, Object> mapObj = doPost(postUrl, map);
        assertTrue("0".equals(mapObj.get("code")));
    }

    private Map<String, Object> doGet(String url) {
        BaseResponse response = NetWorkCenter.get(url);
        return JSONUtil.toMap(response.getErrmsg());
    }

    private Map<String, Object> doPost(String url, Map<String, Object> params) {
        String json = JSONUtil.toJson(params);
        BaseResponse response = NetWorkCenter.post(url, json);
        return JSONUtil.toMap(response.getErrmsg());
    }*/
}
