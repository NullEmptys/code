package net.gamedo.server.paradise;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import net.gamedo.server.paradise.model.primary.monitor.ApplicationInstance;
import net.gamedo.server.paradise.model.primary.monitor.FrequencyMonitorLog;
import net.gamedo.server.paradise.monitor.job.FrequencyMonitorLogGenerator;

/**
 * Created by Administrator on 2016/4/9 0009.
 */
public class MonitorTest extends TestCase {
    public MonitorTest(String testName) {
        super(testName);
    }

    public static Test suite() {
        return new TestSuite(MonitorTest.class);
    }

    public void testMonitor() {
        ApplicationInstance instance = new ApplicationInstance();
//        instance.setMonitorUrl("http://localhost:8080/gameServer/app/api/monitor/ping");
        FrequencyMonitorLogGenerator frequencyMonitorLogGenerator = new FrequencyMonitorLogGenerator(instance);
        FrequencyMonitorLog monitorLog = frequencyMonitorLogGenerator.generate();
        System.out.println(monitorLog.toString());
    }
}
