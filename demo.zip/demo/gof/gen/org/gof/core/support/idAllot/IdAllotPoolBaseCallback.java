package org.gof.core.support.idAllot;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class IdAllotPoolBaseCallback {
	public static final String _result_applyId = "_result_applyId";
}
