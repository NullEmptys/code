package org.gof.core.connsrv;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class ConnectionCallback {
	public static final String _result_pulseConnCheck = "_result_pulseConnCheck";
}
