package org.gof.core.dbsrv;

import org.gof.core.Port;

public class DBPort extends Port {
	public DBPort(String portId) {
		super(portId);
	}
}
