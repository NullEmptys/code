package org.gof.core;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.gof.core.gen.proxy.DistrClass;
import org.gof.core.gen.proxy.DistrMethod;
import org.gof.core.support.PackageClass;

/**
 * 远程调用函数工具类
 */
public class DistrMethodCache {
	public static Map<String, Method> cached = new HashMap<String, Method>();
	
	/**
	 * 初始化
	 * @param packageName
	 */
	public static void init() {
		init("");
	}
	
	/**
	 * 初始化
	 * @param packageName
	 */
	public static void init(String packageName) {
		//符合条件的函数
		Map<Class<?>, List<Method>> methods = findMethods(packageName);
		
		//缓存起来
		for(Entry<Class<?>, List<Method>> entry : methods.entrySet()) {
			Class<?> cls = entry.getKey();
			List<Method> ms = entry.getValue();
			
			for(Method m : ms) {
				cached.put(createKey(cls, m), m);
			}
		}
	}
	
	/**
	 * 根据远程调用关键字来获取函数对象
	 * @param key
	 * @return
	 */
	public static Method getMethod(String key) {
		return cached.get(key);
	}
	
	/**
	 * 获取目录下所有符合条件的类和函数
	 */
	private static Map<Class<?>, List<Method>> findMethods(String packageName) {
		// 获取源文件夹下的所有类
		Set<Class<?>> clazzSet = PackageClass.find(packageName);
		
		// 遍历所有类，取出类中有@DistributedMethod注解的方法
		Map<Class<?>, List<Method>> result = new HashMap<>();
		for(Class<?> clazz : clazzSet) {
			//本类中符合条件的函数
			List<Method> list = new ArrayList<Method>();
			
			// 如果没有@DistrClass注解, 则不处理
			if(!clazz.isAnnotationPresent(DistrClass.class)) {
				continue;
			}
			
			// 遍历所有方法, 如果有DistributedMethod注解，则加入list
			Method[] ms = clazz.getMethods();
			for(Method m : ms) {
				if(m.isAnnotationPresent(DistrMethod.class)) {
					list.add(m);
				}
			}
			
			//记录符合条件的函数
			result.put(clazz, list);
		}
		
		return result;
	}
	
	/**
	 * 创建函数特征码
	 * 类全路径:函数名(参数类型)
	 * @return
	 */
	public static String createKey(Method method) {
		return createKey(method.getDeclaringClass(), method);
	}
	
	/**
	 * 创建函数特征码
	 * 类全路径:函数名(参数类型)
	 * @return
	 */
	public static String createKey(Class<?> cls, Method method) {
		//类全路径
		String clazzName = cls.getName();
		//函数名
		String methodName = method.getName();
		//参数类型字符串
		StringBuilder methodParam = new StringBuilder();
		methodParam.append("(");
		for(Class<?> clazz : method.getParameterTypes()) {
			if(methodParam.length() > 1) methodParam.append(", "); 
			methodParam.append(clazz.getSimpleName());
		}
		methodParam.append(")");
		
		return clazzName + ":" + methodName + methodParam.toString();
	}
}
