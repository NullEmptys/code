package org.gof.core.support;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public abstract class ManagerBase {
	private static final Map<Class<?>, ManagerBase> instances = new ConcurrentHashMap<>();
	
	static {
		init();
	}
	
	/**
	 * 获取唯一实例
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T extends ManagerBase> T getInstance(Class<?> clazz) {
		Object inst = instances.get(clazz);
		if(inst == null) {
			throw new SysException("获取Manager实例时出错：未能找到对应实例，class={}", clazz);
		}
		
		return (T)inst;
		
	}
	
	public static void init() {
		Set<Class<?>> classSet = PackageClass.find();
		try {
			//创建实例
			for (Class<?> clazz : classSet) {
				// 只需要加载ManagerClass注解数据
				if (!Utils.isInstanceof(clazz, ManagerBase.class) || Modifier.isAbstract(clazz.getModifiers())) {
					continue;
				}
				
				// 创建实例
				Object inst = clazz.newInstance();

				instances.put(clazz, (ManagerBase) inst);
			}
			
			//设置标注有@ManagerInject注解的字段的值
			for (Class<?> clazz : classSet) {
				// 只需要加载ManagerClass注解数据
				if (!Utils.isInstanceof(clazz, ManagerBase.class)  || Modifier.isAbstract(clazz.getModifiers())) {
					continue;
				}
				ManagerBase instance = instances.get(clazz);
				Class<?> superClazz = clazz;
				while(superClazz != null && Utils.isInstanceof(superClazz, ManagerBase.class)) {
					Field [] fields = superClazz.getDeclaredFields();
					for (Field field : fields) {
						if (!field.isAnnotationPresent(ManagerInject.class)) {
							continue;
						}
						//有ManagerInject注解的成员
						field.setAccessible(true);
						if(field.get(instance) == null) {
							if(instances.get(field.getType()) == null) {
								throw new SysException("@ManagerInject只能注入ManagerBase子类的实例，当前错误Class={}，Field={}", clazz, field);
							}
							field.set(instance, instances.get(field.getType()));
						}
					}
					
					superClazz = superClazz.getSuperclass();
				}
			}
		} catch (InstantiationException | IllegalAccessException e) {
			throw new SysException(e);
		}
	}
}