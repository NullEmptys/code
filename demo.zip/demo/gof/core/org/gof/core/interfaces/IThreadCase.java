package org.gof.core.interfaces;

public interface IThreadCase {
	public void caseStart();
	public void caseStop();
	public void caseRunOnce();
}