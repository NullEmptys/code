package org.gof.core.gen.callback;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.gof.core.gen.GenBase;
import org.gof.core.support.PackageClass;

/**
 * Callback自动生成类
 * @author Lufeng
 * @date 2013-12-06
 */
public class GenCallback extends GenBase {
	public final String CLASS_SUFFIX = "Callback";
	public final String TEMP_NAME = "Callback.ftl";
	public final Class<GenCallbackFile> ANNOTATION_CLASS= GenCallbackFile.class;
	
	public GenCallback(String packageName, String targetDir) {
		super(packageName, targetDir);
		this.init();
	}
	;
	/**
	 * 初始化class信息，是否能生成等字段
	 */
	private void init() {
		this.canGen = true;		// 默认是true
		
		// 遍历所有类信息, 获取模板信息, 判断是否出错, 出错则初始化异常不能生成
		Map<Class<?>, List<Method>> classes = getClassInfoToGen();
		for(Entry<Class<?>, List<Method>> entry : classes.entrySet()) {
			Class<?> clazz = entry.getKey();
			List<Method> ms = entry.getValue();
			try {
				
				this.rootMaps.add(getRootMap(clazz, ms));
			} catch (Exception e) {
				// 如果获取模板内容异常，表示不能生成
				this.canGen = false;		// 不能生成
				System.err.println("文件存在错误，不继续进行Callback生成了，错误如下：");
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 生成Callback类的核心方法
	 * @param rootMap
	 * @throws Exception
	 */
	@Override
	protected void genFileHandler(Map<String, Object> rootMap) throws Exception {
		// 准备参数生成文件
		String fillName = (String) rootMap.get("callbackName");
		String packName = (String) rootMap.get("packageName");
		String targetFileDir = this.targetDir + PackageClass.packageToPath(packName) + "/";
		
		this.writeFile(targetFileDir, fillName + ".java", TEMP_NAME, rootMap);
	}
	
	/**
	 * 获取生成类Class信息及其Method
	 * @return
	 */
	private Map<Class<?>, List<Method>> getClassInfoToGen() {
		Map<Class<?>, List<Method>> result = new LinkedHashMap<Class<?>, List<Method>>();
		
		// 获取源文件夹下的所有类
		Set<Class<?>> sources = GenBase.getSources(packageName);
		
		// 遍历所有类，取出类中有@DistriCallback注解的方法
		for(Class<?> clazz : sources) {
			Method[] ms = clazz.getDeclaredMethods();
			List<Method> methods = new ArrayList<Method>();
			
			// 遍历所有方法, 如果有@DistriCallback注解，则加入list
			for(Method m : ms) {		
				if(m.isAnnotationPresent(DistrCallback.class)) {
					methods.add(m);
				}
			}
			
			// 如果有@DistriCallback注解的方法, 则加入待创建数据
			if(!methods.isEmpty()){
				// 排序
				Collections.sort(methods, new Comparator<Method>() {
					@Override
					public int compare(Method m1, Method m2) {
						return m1.getName().compareTo(m2.getName());
					}
				});
				
				result.put(clazz, methods);
			}
		}
		
		return result;
	}
	
	/**
	 * 根据class及其methods获取填充模板内容
	 * @param clazz
	 * @param methods
	 * @return
	 */
	private Map<String, Object> getRootMap(Class<?> clazz, List<Method> methods) {
		// 获取实体类名,表名,包名
		String packageName = clazz.getPackage().getName();
		String className = clazz.getSimpleName();
		String callbackName = className + CLASS_SUFFIX;
		
		// 填充Map
		Map<String, Object> rootMap = new LinkedHashMap<String, Object>();
		List<String> methodInfos = new ArrayList<String>();
		rootMap.put("packageName", packageName);
		rootMap.put("callbackName", callbackName);
		rootMap.put("className", className);
		rootMap.put("methods", methodInfos);
		rootMap.put("annotationPack", ANNOTATION_CLASS.getName());
		rootMap.put("annotation", "@" + ANNOTATION_CLASS.getSimpleName());
		
		// 遍历methods，获取方法名等信息
		for (Method m : methods) {
			// 模板所需数据
			String name = m.getName();
			
			methodInfos.add(name);
		}
		
		return rootMap;
	}

}
