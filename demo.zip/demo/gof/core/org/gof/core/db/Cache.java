package org.gof.core.db;

/**
 * 设置读缓存
 * 因为开放后的危险性，暂定屏蔽此功能。
 */
public enum Cache {
	TRUE,
	FALSE
}
