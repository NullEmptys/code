package org.gof.core.scheduler;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
/**
 * 
 * @author hp备注
 *Data 2017/10/22
 *task成员变量对应service jobDetail.map中的key值，启动服务器过程中加载所有schedule,
 *针对所有的schedule到指定时间执行的操作相同，到指定时间将自己的task加入到scheduler队列中，
 *等待轮训线程从队列中执行execute逻辑
 */
public class ScheduleJob implements Job {
	private ScheduleTask task;
	private ConcurrentLinkedQueue<ScheduleTask> scheduler = new ConcurrentLinkedQueue<ScheduleTask>();
	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		task.state = ScheduleTask.STATE_INQUEUE;
		
		//到触发时间后放入时间调度队列
		scheduler.add(task);
	}

	public ScheduleTask getTask() {
		return task;
	}

	public void setTask(ScheduleTask task) {
		this.task = task;
	}

	public ConcurrentLinkedQueue<ScheduleTask> getScheduler() {
		return scheduler;
	}

	public void setScheduler(ConcurrentLinkedQueue<ScheduleTask> scheduler) {
		this.scheduler = scheduler;
	}
}
