package org.gof.demo.platform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Log {
	public static Logger platform = LoggerFactory.getLogger("PLATFORM");
}