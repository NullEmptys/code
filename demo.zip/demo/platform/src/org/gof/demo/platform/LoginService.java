package org.gof.demo.platform;

import org.gof.core.Port;
import org.gof.core.Service;
import org.gof.core.gen.proxy.DistrClass;
import org.gof.core.gen.proxy.DistrMethod;

@DistrClass
public class LoginService extends Service {
	
	public LoginService(Port port) {
		super(port);
	}

	@Override
	public Object getId() {
		return C.SERV_LOGIN;
	}
	
	/**
	 * 登陆验证
	 * @param loginJSON
	 */
	@DistrMethod
	public void check(String userIdentity, String token) {
//		int check = Login.checkToken(userIdentity, token);
//		
//		port.returns(check == Login.SUCCESS);
		port.returns(true);
	}
}
