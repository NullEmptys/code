package org.gof.demo.platform;

import org.gof.core.Port;

public class LoginPort extends Port {
	
	public LoginPort(String name) {
		super(name);
	}
}
