package org.gof.demo.platform;

import org.gof.core.Port;
import org.gof.core.CallPoint;
import org.gof.core.support.Distr;
import org.gof.core.support.Param;
import org.gof.core.support.log.LogCore;
import org.gof.core.gen.proxy.ProxyBase;
import org.gof.core.gen.proxy.GenProxyFile;

@GenProxyFile
public class LoginServiceProxy extends ProxyBase {
	
	private CallPoint remote;
	private Port localPort;
	
	/**
	 * 私有构造函数
	 * 防止实例被私自创建 必须通过newInstance函数
	 */
	private LoginServiceProxy() {}
	
	
	/**
	 * 获取实例
	 * @return
	 */
	public static LoginServiceProxy newInstance(CallPoint targetPoint) {
		return createInstance(targetPoint.nodeId, targetPoint.portId, targetPoint.servId);
	}
	
	/**
	 * 获取实例
	 * @return
	 */
	public static LoginServiceProxy newInstance(String node, String port, Object id) {
		return createInstance(node, port, id);
	}
	
	/**
	 * 创建实例
	 * @param localPort
	 * @param node
	 * @param port
	 * @param id
	 * @return
	 */
	private static LoginServiceProxy createInstance(String node, String port, Object id) {
		LoginServiceProxy inst = new LoginServiceProxy();
		inst.localPort = Port.getCurrent();
		inst.remote = new CallPoint(node, port, id);
		
		return inst;
	}
	
	/**
	 * 监听返回值
	 * @param obj
	 * @param methodName
	 * @param context
	 */
	public void listenResult(Object obj, String methodName, Object...context) {
		listenResult(obj, methodName, new Param(context));
	}
	
	/**
	 * 监听返回值
	 * @param obj
	 * @param methodName
	 * @param context
	 */
	public void listenResult(Object obj, String methodName, Param context) {
		localPort.listenResult(obj, methodName, context);
	}
	
	/**
	 * 等待返回值
	 */
	public Param waitForResult() {
		return localPort.waitForResult();
	}
	
	public void check(String userIdentity, String token) {
		localPort.call(remote, "org.gof.demo.platform.LoginService:check(String, String)", new Object[]{ userIdentity, token });
	}
}
