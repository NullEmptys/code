package com.test;


import java.lang.reflect.InvocationTargetException;
import java.util.function.BiFunction;
import java.util.function.DoublePredicate;


public final class TestFunction {		
	public volatile static long i = 0L;
	public volatile static long j = 0L;
	public volatile static long k = 0L;
	
	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		TestFunction test = new TestFunction();
		
		DoublePredicate pre = test::invoke;
		BiFunction<Double, Double, Double> fun = test::invoke;
		
		long start = System.currentTimeMillis();
		double value0 = 0D;
		//直接调用
		for(i = 0; i < 10000000l; i++) {
			test.invoke(i+10);
		}
		System.out.println(System.currentTimeMillis() - start);
				
		start = System.currentTimeMillis();
		double value1 = 0D;
		//反射执行
		for( j = 0; j < 10000000l; j++) {
			pre.test(j+10);
		}
		System.out.println(System.currentTimeMillis() - start);
		System.out.println(value0 +":"+ value1);
	}
	
	static double index = 0;
	public boolean invoke(double a) {
		Math.sqrt(a+ index++);
		return true;
	}
	
	public double invoke(double a, double b) {
		double result = 0;
		for (int k = 0; k < 4; k++) {
			result += Math.sqrt(a + index++);
			result += Math.sqrt(b + index++);
		}
		return result;
	}
	
	public double invoke(Object[] o) {
		double result = 0;
		for (int k = 0; k < 4; k++) {
			result += Math.sqrt((Double)o[0]+ index++);
			result += Math.sqrt((Double)o[1] + index++);
			result += Math.sqrt((Double)o[2] + index++);
		}
		return result;
	}
}
