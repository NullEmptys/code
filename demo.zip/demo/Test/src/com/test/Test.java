package com.test;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


public final class Test {		
	public volatile static long i = 0L;
	public volatile static long j = 0L;
	public volatile static long k = 0L;
	
	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Method mth1 = Test.class.getMethod("invoke", new Class[]{double.class});
		Method mth2 = Test.class.getMethod("invoke", new Class[] {double.class, double.class, double.class});
		Method mth3 = Test.class.getMethod("invoke", new Class[] {double.class, double.class, double.class, double.class, double.class, double.class});
		
		Test obj = new Test();
		
		long start = System.currentTimeMillis();
		double value0 = 0D;
		//直接调用
		for(i = 0; i < 1000000l; i++) {
			obj.invoke(1);
			obj.invoke( new Object[]{j+1.0, j+2.0, j+3.0});
			obj.invoke( j+1.0, j+2.0, j+3.0, j+4.0, j+5.0, j+6.0);
		}
		System.out.println(System.currentTimeMillis() - start);
				
		start = System.currentTimeMillis();
		double value1 = 0D;
		//反射执行
		for( j = 0; j < 1000000l; j++) {
			value1 = (Double)mth1.invoke(obj, new Object[]{});
			value1 = (Double)mth2.invoke(obj, new Object[]{new Double(j+1.0), j+2.0, j+3.0});
			value1 = (Double)mth3.invoke(obj, new Object[]{j+1.0, j+2.0, j+3.0, j+4.0, j+5.0, j+6.0});
		}
		System.out.println(System.currentTimeMillis() - start);
		System.out.println(value0 + value1);
	}
	
	static double index = 0;
	public double invoke(double a) {
		return a;
	}
	
	public double invoke(Object[] o) {
		double result = 0;
		for (int k = 0; k < 4; k++) {
			result += Math.sqrt((Double)o[0]+ index++);
			result += Math.sqrt((Double)o[1] + index++);
			result += Math.sqrt((Double)o[2] + index++);
		}
		return result;
	}
	
	public double invoke(double a, double b, double c, double d, double e, double f) {
		double result = 0;
		for (int k = 0; k < 4; k++) {
			result += Math.sqrt(a + index++);
			result += Math.sqrt(b + index++);
			result += Math.sqrt(c + index++);
			result += Math.sqrt(d + index++);
			result += Math.sqrt(e + index++);
			result += Math.sqrt(f + index++);
		}
		return result;
	}
}
