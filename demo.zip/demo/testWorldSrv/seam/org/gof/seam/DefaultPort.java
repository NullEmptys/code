package org.gof.seam;

import org.gof.core.Port;
import org.gof.core.support.idAllot.IdAllotPoolBase;
import org.gof.seam.id.IdAllotPool;

public class DefaultPort extends Port  {
	public DefaultPort(String name) {
		super(name);
	}
	
	@Override
	protected IdAllotPoolBase initIdAllotPool() {
		return new IdAllotPool(this);
	}
}