package org.gof.seam;

import java.lang.reflect.Method;

import org.apache.commons.lang3.reflect.MethodUtils;
import org.gof.core.Port;
import org.gof.core.support.ConnectionStatus;
import org.gof.core.support.SeamServiceBase;
import org.gof.demo.worldsrv.character.HumanObjectService;
import org.gof.seam.account.AccountService;

/**
 * 继承父类 CORE会通过接口的返回值进行通信
 */
public class SeamService extends SeamServiceBase  {

	public SeamService(Port port) {
		super(port);
	}
	
	/**
	 * 登陆阶段接收消息函数
	 */
	@Override
	public Method methodAccountMsg() {
		return MethodUtils.getAccessibleMethod(AccountService.class, "msgHandler", long.class, ConnectionStatus.class, byte[].class);
	}

	/**
	 * 游戏阶段接收消息函数
	 */
	@Override
	public Method methodWorldMsg() {
		return MethodUtils.getAccessibleMethod(HumanObjectService.class, "msgHandler", long.class, byte[].class);
	}

	/**
	 * 登陆阶段连接中断消息函数
	 */
	@Override
	public Method methodAccountLost() {
		return MethodUtils.getAccessibleMethod(AccountService.class, "connClosed", long.class);
	}

	/**
	 * 游戏阶段连接中断消息函数
	 */
	@Override
	public Method methodWorldLost() {
		return MethodUtils.getAccessibleMethod(HumanObjectService.class, "connClosed", long.class);
	}

	/**
	 * 登陆阶段连接验证消息函数
	 */
	@Override
	public Method methodAccountCheck() {
		return MethodUtils.getAccessibleMethod(AccountService.class, "connCheck", long.class);
	}

	/**
	 * 游戏阶段连接验证消息函数
	 */
	@Override
	public Method methodWorldCheck() {
		return MethodUtils.getAccessibleMethod(HumanObjectService.class, "connCheck", long.class);
	}
}
