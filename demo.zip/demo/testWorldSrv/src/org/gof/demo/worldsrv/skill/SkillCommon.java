package org.gof.demo.worldsrv.skill;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.gof.core.Port;
import org.gof.core.support.RandomUtils;
import org.gof.core.support.SysException;
import org.gof.core.support.Time;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.character.MonsterObject;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.config.ConfSkill;
import org.gof.demo.worldsrv.config.ConfSkillEffect;
import org.gof.demo.worldsrv.fight.HpLostKey;
import org.gof.demo.worldsrv.human.SkillTempInfo;
import org.gof.demo.worldsrv.human.UnitManager;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.DHpChgOnce;
import org.gof.demo.worldsrv.msg.Msg.DHpChgTar;
import org.gof.demo.worldsrv.msg.Msg.DVector2;
import org.gof.demo.worldsrv.msg.Msg.SCFightHpChg;
import org.gof.demo.worldsrv.msg.Msg.SCFightSkill;
import org.gof.demo.worldsrv.msg.Msg.SCFightSkill.Builder;
import org.gof.demo.worldsrv.skill.logic.AbstractSkillLogic;
import org.gof.demo.worldsrv.skill.logic.SkillLogicManager;
import org.gof.demo.worldsrv.stage.StageManager;
import org.gof.demo.worldsrv.support.I18n;
import org.gof.demo.worldsrv.support.ReasonResult;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.demo.worldsrv.support.enumKey.UnitObjectStateKey;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

public class SkillCommon {
	
	
	protected StageManager stageManager = StageManager.getInstance();
	
	public ConfSkill confSkill;										//技能配置
	public UnitObject unitObj;										//释放者
	public int skillLevel;											//技能等级
	public List<AbstractSkillLogic> logics = new ArrayList<>();	//技能效果
	public Map<String, Integer> temp = new HashMap<>();			//临时信息
	public int comboCount;											//连击次数
	public SCFightSkill.Builder scFightSkill = null;				//技能广播包
	public SCFightHpChg.Builder hpChangeMsg = null;				//技能伤害血量包
	public Vector2D dVec = null;								//人物技能攻击向前追击
	public Set<UnitObject> affectUnits = new LinkedHashSet<>();		//受到技能影响的unit单位id
	
	
	public SkillCommon(UnitObject unitObj, ConfSkill confSkill, int skillLevel) {
		this.unitObj = unitObj;
		this.confSkill = confSkill;
		this.skillLevel = skillLevel;
		
		//初始化技能效果
		try {
			JSONArray ja = JSON.parseArray(confSkill.effects);
			
			for(Object obj : ja) {
				//查找效果配置表
				ConfSkillEffect confSkillEffect = ConfSkillEffect.getBy("level", skillLevel, "effectSn", Utils.intValue(obj.toString()));
				
				//效果表中没有找到
				if(confSkillEffect == null) continue;
				
				//初始化技能效果
				logics.add(SkillLogicManager.getInstance().initLogic(this, confSkillEffect.sn));
			}
		} catch (Exception e) {
			throw new SysException(e);
		}
	}
	
	
	/**
	 * 是否可以施放技能
	 * @return
	 */
	public ReasonResult canCast(SkillParam param) {
		//处于不能释放技能的状态
		if(!unitObj.canCastSkill && confSkill.type != 3) {
			return new ReasonResult(false, I18n.get("fight.canCastSkill.stateCanNotCast"));
		}
		//处于不能普攻的状态
		if(!unitObj.canAttack && confSkill.type == 3) {
			return new ReasonResult(false, I18n.get("fight.canCastSkill.stateCanNotCast"));
		}
		
		//该技能是被动技能，无法施放
		if(!confSkill.active) {
			return new ReasonResult(false, I18n.get("fight.canCastSkill.skillNotActive"));
		}
		
		//施法者死亡
		if(unitObj.isDie()) {
			return new ReasonResult(false, I18n.get("fight.canCastSkill.die"));
		}
		
		//目标死亡1
		if(param.tarUo != null && param.tarUo.isDie()) {
			return new ReasonResult(false, I18n.get("fight.canCastSkill.tarDie"));
		}
		
		//状态受限
		ReasonResult tmp = isLimitNormal();
		if(!tmp.success) {
			return tmp;
		}
		
		//冷却中
		tmp = isCoolingNormal(param);
		if(!tmp.success) {
			return tmp;
		}
		
		
		//目标不合法
		tmp = isLegal(param);
		if(!tmp.success) {
			return tmp;
		}
			
		//不再范围内
		tmp = isScope(param);
		if(!tmp.success) {
			return tmp;
		}

		return new ReasonResult(true, "");
	}
	
	
	/**
	 * 施放技能,第一阶段
	 * @param position
	 */
	public void castFirst(SkillParam position) {
		//技能施放成功
		if(unitObj instanceof MonsterObject) {
			Event.fire(EventKey.MONSTER_SKILL_CAST, "monsterObj", unitObj, "skillSn", confSkill.sn);
		}	
		if(confSkill.shakeFront > 0) {
			//有前摇技能，就是有延迟效果的
			//前摇技能，玩家停止移动,魂将释放则不限制移动
			if(unitObj.running.isRunning()) {
				unitObj.stop();
			}
			
			//计算前摇结束时间
			SkillExcute skillExcute = new SkillExcute(confSkill.sn, position, confSkill.shakeFront, 1);
			unitObj.skillTempInfo.skillToExcute = skillExcute;
			
			//进入前摇状态
			unitObj.toState(UnitObjectStateKey.skill_shake, confSkill.shakeFront);
		} else {
			//怪物释放技能，进入1s的发呆时间（播放释放技能的需要时间）
			if(unitObj.isMonsterObj()) {
				unitObj.toState(UnitObjectStateKey.skill_shake, 1000);
			}
		}
		
		//放技能的时候停止移动,魂将放技能的时候不管
		if(unitObj.running.isRunning()) {
			unitObj.stop();
		}
		
		
		//按效果顺序依次施放
		doLogics(position, 0);
		
		//发送技能命中单位被攻击事件
		fireAttackedEvent();
		
		//广播技能包
		broadSkillMsgFirst(position);

		//造成伤害，判断是否有吸血被动
		int hpLost = getTemp("hurt");
		
		//判断扣血后是否有被动技能触发(吸血)
		SkillParamVO vo = new SkillParamVO();
		Event.fire(EventKey.SKILL_PASSIVE_CHECK, 
							"unitAtk", unitObj,
							"unitDef", null, 
							"skillEventKey", SkillEventKey.EVENT_ON_SKILL_END, 
							"isPartner", false, 
							"vo", vo);
		
		int bloodSuck = (int)(vo.bloodSuckPct * hpLost); 
		if(bloodSuck > 0) {
			//吸血
			UnitManager.getInstance().addHp(unitObj, HpLostKey.SKILL, bloodSuck, unitObj);
		}
		
		//放入技能冷却中
		addCoolDown();
		
		//如果技能只有一个阶段清空本次技能缓存数据，否则第二阶段清空
		if(confSkill.shakeFront == 0) {
			temp.clear();
		}
		
		//发送战斗单元攻击事件
		Event.fire(EventKey.UNIT_ATTACK, "unitObj", unitObj);
		// 发送战斗单元动作事件
		Event.fire(EventKey.UNIT_ACT, "unitObj", unitObj);
		if(unitObj.isHumanObj()) {
			// 发送玩家攻击事件
			Event.fire(EventKey.HUMAN_ATTACK, "humanObj", unitObj);
			// 发送玩家动作事件
			Event.fire(EventKey.HUMAN_ACT, "humanObj", unitObj);
		} else if(unitObj.isMonsterObj()) {
			// 发送怪物攻击事件
			Event.fire(EventKey.MONSTER_ATTACK, "monsterObj", unitObj);
			// 发送怪物动作事件
			Event.fire(EventKey.MONSTER_ACT, "monsterObj", unitObj);
		}
		
	}
	
	/**
	 * 释放技能，第二阶段
	 * @param position
	 */
	public void castSecond(SkillParam position) {
		//按效果顺序依次施放
		doLogics(position, 1);

		//发送技能命中单位被攻击事件
		fireAttackedEvent();
		
		//广播技能包
		broadSKillMsgSecond(position);
		
		//造成伤害，判断是否有吸血被动
		int hpLost = getTemp("hurt");
		
		//判断扣血后是否有被动技能触发(吸血)
		SkillParamVO vo = new SkillParamVO();
		Event.fire(EventKey.SKILL_PASSIVE_CHECK, 
							"unitAtk", unitObj,
							"unitDef", null, 
							"skillEventKey", SkillEventKey.EVENT_ON_SKILL_END, 
							"isPartner", false, 
							"vo", vo);
		
		int bloodSuck = (int)(vo.bloodSuckPct * hpLost); 
		if(bloodSuck > 0) {
			//吸血
			UnitManager.getInstance().addHp(unitObj, HpLostKey.SKILL, bloodSuck, unitObj);
		}
		
		//清空本次技能缓存数据
		temp.clear();
	}
	
	/**
	 * 受限制的状态是否正常
	 * @return
	 */
	public ReasonResult isLimitNormal() {
		return new ReasonResult(true, "");
	}
	
	
	/**
	 * 记录冷却
	 */
	public void addCoolDown() {
		//放入技能冷却中
		SkillTempInfo skillInfo = unitObj.skillTempInfo;
		
		
		//没有冷却
		if(confSkill.coolTime <= 200) return ;
		
		//加入技能冷却
		skillInfo.cooldown.put(confSkill.sn, Port.getTime() + confSkill.coolTime - 200);
	}
	
	/**
	 * 冷却状态是否正常
	 * @return
	 */
	public ReasonResult isCoolingNormal(SkillParam param) {
		SkillTempInfo skillInfo = unitObj.skillTempInfo;
		
		
		//技能处于常规冷却
		if(skillInfo.cooldown.containsKey(confSkill.sn)) {
			if(skillInfo.cooldown.get(confSkill.sn) > System.currentTimeMillis()) {
				return new ReasonResult(false, I18n.get("skill.skillCommon.inCooling"));
			}
		}
		
		return new ReasonResult(true, "");
	}
	
	/** 鼠标点选类型 */
	public static int CLICK_TAR = 1;		//目标是人或者怪
	public static int CLICK_VECTOR = 2;	//目标是坐标
	public static int CLICK_SELF = 3;		//目标是自己
	
	/**
	 * 是否合法目标
	 * @param position
	 * @return
	 */
	public ReasonResult isLegal(SkillParam position) {
		//有目标型
		if(confSkill.clickType == CLICK_TAR && position.tarUo == null) {
			return new ReasonResult(false, I18n.get("fight.isLegal.tarIllegal"));
		}
		
		//坐标型
		if(confSkill.clickType == CLICK_VECTOR && position.tarPos == null) {
			return new ReasonResult(false, I18n.get("fight.isLegal.tarIllegal"));
		}
		
		//如果不是可对自己释放的技能不能攻击自己
		if(confSkill.clickType != CLICK_SELF && unitObj.isHumanObj() && position.tarUo == unitObj) {
			return new ReasonResult(false, I18n.get("skill.checkRight.tarNotSelf"));
		}
		
		//按效果顺序依次施放
		for(AbstractSkillLogic logic : logics) {
			ReasonResult rr = logic.isLegal(position);
			if(!rr.success) {
				return rr;
			}
		}
		
		
		return new ReasonResult(true, "");
	}
	
	public ReasonResult isScope(SkillParam pos) {
		
		float distanceError = 0.5f;
		//目标是自己
		if(confSkill.clickType == CLICK_SELF) {
			return new ReasonResult(true, "");
		}
		
		//自己位置
		Vector2D ownPos = unitObj.posNow;
		
		//目标距离
		double distance = 0;

		//目标是人或者怪物
		if(confSkill.clickType == CLICK_TAR) {
			distance = ownPos.distance(pos.tarUo.posNow);
			
			//如果目标为怪物，则减去目标的碰撞半径
			if(pos.tarUo.isMonsterObj()) {
				distance -= ((MonsterObject)pos.tarUo).conf.collisionRadius;
			}
		} else {
			//目标是坐标
			distance = ownPos.distance(pos.tarPos);
		}
		
		//如果施放技能方为怪物，则减去攻方的碰撞半径
		if(unitObj.isMonsterObj()) {
			distance -= ((MonsterObject)unitObj).conf.collisionRadius;
		}
		distance = Math.max(0, distance);
		
		//距离小于最小射程
		if(distance < confSkill.rangeMin - distanceError) {
			return new ReasonResult(false, I18n.get("skill.skillCommon.scopeNear"));
		}
		
		//距离大于最大射程
		if(distance > confSkill.rangeMax + distanceError) {
			return new ReasonResult(false, I18n.get("skill.skillCommon.scopeFar"));
		}
		
		return new ReasonResult(true, "");
	}
	
	/**
	 * 顺序使用技能效果
	 * @param position
	 */
	private void doLogics(SkillParam position, int period) {
		for(AbstractSkillLogic logic : logics) {
			//两段式：不是当前阶段
			if(logic.conf.period != period) continue;
			
			//判断是否是当前连击次数的逻辑效果
			boolean flag = false;
			String[] comboCounts = logic.conf.comboCount.split(",");
			for(String count : comboCounts) {
				if(Utils.intValue(count) == comboCount) {
					flag = true;
					break;
				}
			}
			if(!flag) continue;
			
			//判断是否应该触发该技能效果
			double rand = RandomUtils.nextDouble();
			if(rand > logic.conf.triggerPct) continue ;
			
			//触发
			if(!logic.canDoSkillEffect(position).success) continue;
			logic.doSkillEffect(position);
		}
	}
	
	public Builder createFightMsg(SkillParam position) {
		//构建技能广播包
		if(scFightSkill == null) {
			scFightSkill = Msg.SCFightSkill.newBuilder();
		}
		
		//释放技能者的id
		scFightSkill.setCastId(unitObj.id);
		//技能id
		scFightSkill.setSkillId(confSkill.sn);
		//技能目标
		if(position.tarUo != null) {
			scFightSkill.setTarId(position.tarUo.id);
		}
		if(position.tarPos != null) {
			scFightSkill.setPos(position.tarPos.toMsg());
		}
		//设置攻击类型是人物攻击
		scFightSkill.setAtkerType(1);
		//将技能造成的掉血信息加入技能包中
		if(hpChangeMsg != null) {
			scFightSkill.setHpChg(hpChangeMsg);
		}
		
		//加入人物攻击追击位移
		if(dVec != null) {
			scFightSkill.setAttPos(dVec.toMsg());
		}
		return scFightSkill;
	}
	
	
	/**
	 * 广播技能：第一阶段
	 * @param position
	 */
	protected void broadSkillMsgFirst(SkillParam position) {
		Builder msg = createFightMsg(position);
		msg.setPeriod(1);
		msg.setAtkerType(1);
		msg.setFinal(position.finalAtk);
		
		//循环本地图玩家,发送技能包
		stageManager.sendMsgToArea(msg, unitObj.stageObj, unitObj.posNow);
		
		//发送完消息后，清空
		scFightSkill = null;
		hpChangeMsg = null;
		dVec = null;
	}
	
	/**
	 * 广播技能消息：第二阶段
	 * @param position
	 */
	protected void broadSKillMsgSecond(SkillParam position) {
		Builder msg = createFightMsg(position);
		msg.setPeriod(2);
		msg.setAtkerType(1);
		msg.setFinal(position.finalAtk);
		
		//循环本地图玩家,发送技能包
		stageManager.sendMsgToArea(msg, unitObj.stageObj, unitObj.posNow);
		
		//发送完消息后，清空
		scFightSkill = null;
		hpChangeMsg = null;
		dVec = null;
	}
	
	/**
	 * 发送技能命中单位被攻击事件
	 */
	private void fireAttackedEvent() {
		//遍历所有受到影响的unit，发目标被攻击事件
		for(UnitObject unitObjAffect : affectUnits) {
			if(unitObjAffect.isDie()) continue;
			
			//根据目标类型发送不同种的受攻击事件
			Event.fire(EventKey.UNIT_BE_ATTACKED, "unitObj", unitObjAffect);
			if(unitObjAffect.isHumanObj()) {
				Event.fire(EventKey.HUMAN_BE_ATTACKED, "attacker", unitObj, "humanObj", unitObjAffect);
			} else if(unitObjAffect.isMonsterObj()) {
				Event.fire(EventKey.MONSTER_BE_ATTACKED, "attacker", unitObj, "monsterObj", unitObjAffect);
			}
		}
		
		//清空受到技能影响的unit单位id
		affectUnits.clear();
	}
	
	/**
	 * 添加技能的缓存
	 * @param key
	 * @param value
	 */
	public void addTemp(String key, int value) {
		if(temp.containsKey(key)) {
			temp.put(key, temp.get(key) + value);
		} else {
			temp.put(key, value);
		}
	}
	
	/**
	 * 获取技能的缓存量
	 * @param key
	 * @return
	 */
	public int getTemp(String key) {
		if(temp.containsKey(key)) {
			return temp.get(key);
		} else {
			return 0;
		}
	}
	
	/**
	 * 将本次造成掉血消息构造进用户造成掉血信息
	 * @param humanObject
	 * @param id
	 * @param dhpChgOnce
	 */
	public void addSkillHpChg(long id, DHpChgOnce.Builder dhpChgOnce) {
		if(hpChangeMsg == null) {
			hpChangeMsg = SCFightHpChg.newBuilder();
		}
		
		boolean flag = false;
		DHpChgTar.Builder dhpTar = DHpChgTar.newBuilder(); 
		dhpTar.setId(id);
		for(DHpChgTar.Builder tmp : hpChangeMsg.getDhpChgTarBuilderList()) {
			if(tmp.getId() != id) continue;
			dhpTar = tmp;
			flag = true;
		}
		
		dhpTar.addDhpChgOnce(dhpChgOnce);
		
		if(!flag) {
			hpChangeMsg.addDhpChgTar(dhpTar);
		}
	}
	
	private boolean canCombo(UnitObject unitObj, ConfSkill confSkill, SkillParam param) {
		//非连击技能
		if(confSkill.combo <= 0) return false;
		//上次释放的技能不是该技能
		if(unitObj.lastSkillSn != confSkill.sn) return false;
		//施法间隔大于1.5s
		if(Port.getTime() - unitObj.lastSkillTime > 1.5 * Time.SEC) return false;
		//超过最大连击次数
		if(comboCount >= confSkill.combo - 1 ) return false;
		
		
		return true;
	}
	
	/**
	 * 计算连击数
	 * @param finalAtk		主动请求连击最后一击
	 */
	public void comboCal(SkillParam param) {
		//判断是否连击
		long now = Port.getTime();
		if(canCombo(unitObj, confSkill, param)) {
			//主动请求连击最后一击的，直接将连击次数设最大值
			if(param.finalAtk) {
				comboCount = confSkill.combo - 1;
			} else {
				//连击数+1
				comboCount += 1;
			}
		} else {
			comboCount = 0;
		}
		
		//设置最近一次释放的技能sn和时间
		unitObj.lastSkillSn = confSkill.sn;
		unitObj.lastSkillTime = now;
		
	}
	
}
