package org.gof.demo.worldsrv.character;

import java.util.List;

import org.gof.core.CallPoint;
import org.gof.core.Port;
import org.gof.core.Service;
import org.gof.core.connsrv.ConnectionProxy;
import org.gof.core.gen.proxy.DistrClass;
import org.gof.core.gen.proxy.DistrMethod;
import org.gof.core.support.MsgHandler;
import org.gof.core.support.Param;
import org.gof.demo.worldsrv.stage.StagePort;
import org.gof.seam.msg.HumanExtendMsgHandler;

@DistrClass(
	importClass = {List.class,  Param.class}
)
public class HumanObjectService extends Service {
	private HumanExtendMsgHandler msgHandler = MsgHandler.getInstance(HumanExtendMsgHandler.class);
	
	//对应的玩家对象
	private final HumanObject humanObj;
	
	/**
	 * 构造函数
	 * @param humanObj
	 */
	public HumanObjectService(HumanObject humanObj, Port port) {
		super(port);
		this.humanObj = humanObj;
	}
	
	/**
	 * 获取所属Port
	 * @return
	 */
	public StagePort getPort() {
		return humanObj.getPort();
	}
	
	/**
	 * 离开地图
	 * @param humanId
	 */
	@DistrMethod
	public void leave() {
		humanObj.stageLeave();
	}
	
	/**
	 * 接受并转发通信消息
	 * @param humanId
	 * @param chunk
	 */
	@DistrMethod
	public void msgHandler(long connId, byte[] chunk) {
		//忽略错误连接ID的请求
		long humanConnId = (long) humanObj.connPoint.servId;
		if(humanConnId != connId) {
			//将发送错误连接的请求连接关了
			CallPoint connPoint = new CallPoint();
			connPoint.nodeId = port.getCallFromNodeId();
			connPoint.portId = port.getCallFromPortId();
			connPoint.servId = connId;
			
			ConnectionProxy prx = ConnectionProxy.newInstance(connPoint);
			prx.close();
			return;
		}
		
		msgHandler.handle(chunk, "humanObj", humanObj);
	}
	
	/**
	 * 连接关闭
	 * @param humanId
	 */
	@DistrMethod
	public void connClosed(long connId) {
		//忽略错误连接ID的请求
		long humanConnId = (long) humanObj.connPoint.servId;
		if(humanConnId != connId) {
			return;
		}
		
		humanObj.connCloseClear();
	}
	
	/**
	 * 连接存活验证
	 * @param humanId
	 */
	@DistrMethod
	public void connCheck(long connId) {
		port.returns(true);
	}
	
	
	
	@DistrMethod
	public void getHuman() {
		getPort().returns(humanObj.dataPers.human);
	}
	
	@Override
	public Object getId() {
		return humanObj.id;
	}
	
	public HumanObject getHumanObj() {
		return humanObj;
	}
	
	
	
}
