package org.gof.demo.worldsrv.skill.logic;

import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.buff.BuffManager;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.config.ConfSkillEffect;
import org.gof.demo.worldsrv.skill.SkillCommon;


/**
 * 技能效果：buff
 * @author new
 *
 */
public class SkillLogic003 extends AbstractSkillLogicActive{
	public int buffSn;			//buffSn			
	
	@Override
	public void init(SkillCommon skillCommon, ConfSkillEffect conf) {
		//父类方法初始化了范围前三个参数
		super.init(skillCommon, conf);
		buffSn = Utils.intValue(conf.param1);
	}

	@Override
	public void doSkillEffectToTar(UnitObject unitDef) {
		//目标加buff
		UnitObject uo = skill.unitObj;
		Long useId = uo.id;
		
		if(useId != null) {
			BuffManager.getInstance().add(unitDef, useId, buffSn);
		}
	}
}
