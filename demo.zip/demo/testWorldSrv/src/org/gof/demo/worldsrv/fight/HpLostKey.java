package org.gof.demo.worldsrv.fight;

/**
 * 扣血类型类型
 * @author lz
 *
 */
public enum HpLostKey {
	SKILL,			//技能伤害
	BUFF,			//debuff伤害
	DOT				//dot伤害
}
