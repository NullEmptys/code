package org.gof.demo.worldsrv.skill;

/**
 * 被动技能触发点枚举
 * @author new
 *
 */
public enum SkillEventKey {
	EVENT_ON_BEFORE_HIT,			//计算命中前
	EVENT_ON_BEFORE_CALC_HURT,		//计算伤害前
	EVENT_ON_BEFORE_CALC_CRIT,		//计算暴击前
	EVENT_ON_BEFORE_HPLOST,			//扣血前
	EVENT_ON_AFT_HPLOST,			//扣血后
	EVENT_ON_TAR_EFFECT_END,		//技能施放对目标效果结束后（攻防双方都有数据）
	EVENT_ON_SKILL_END,				//技能释放结束后(此事件只有攻击方数据)
}
