package org.gof.demo.worldsrv.fight;

import org.gof.core.support.ManagerBase;
import org.gof.core.support.RandomUtils;
import org.gof.demo.worldsrv.character.UnitObject;


public class FightManager extends ManagerBase {
	/**
	 * 获取实例
	 * @return
	 */
	public static FightManager getInstance() {
		return getInstance(FightManager.class);
	}
	
	public int calcPropHitIgnoreDef(UnitObject unitObjAtk, UnitObject unitObjDef, double ignorePct) {
		//伤害系数
		double factor = 0.3;
		
		int def = (int)(unitObjDef.getUnit().getDef() * Math.max(0, 1 - ignorePct));
//		def = def * 1000;
		//计算伤害 MAX{(攻击方攻击 - 防御方防御)， int（1% * 攻击方攻击）}
		return Math.max(unitObjAtk.getUnit().getAtk() - def, (int)(Math.ceil(factor * unitObjAtk.getUnit().getAtk())));
	}
	
	public boolean isHit(UnitObject uoAtk, UnitObject uoDef) {
		return true;
	}
	
	public boolean isCrit(UnitObject uoAtk, UnitObject uoDef) {
		//进攻方防御方用户
		int roll = RandomUtils.nextInt(10000) + 1;
		int value = 30;
		return value >= roll;
	}
}