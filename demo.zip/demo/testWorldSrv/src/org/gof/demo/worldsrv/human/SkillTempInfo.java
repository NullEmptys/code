package org.gof.demo.worldsrv.human;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.gof.core.InputStream;
import org.gof.core.OutputStream;
import org.gof.core.interfaces.ISerilizable;
import org.gof.demo.worldsrv.skill.SkillExcute;

public class SkillTempInfo implements ISerilizable {
	public Map<Integer, Long> globalCool = new HashMap<>();			//公共冷却
	public Map<Integer, Long> cooldown = new HashMap<>();				//技能冷却时间
	public SkillExcute skillToExcute = null;						 	//前摇技能信息
	
	@Override
	public void writeTo(OutputStream out) throws IOException {
		out.write(globalCool);
		out.write(cooldown);
	}

	@Override
	public void readFrom(InputStream in) throws IOException {
		globalCool = in.read();
		cooldown = in.read();
	}
}
