package org.gof.demo.worldsrv.entity;

import org.gof.core.gen.entity.Entity;

@Entity(entityName="Monster", tableName="demo_monster", superEntity=EntityUnit.class)
public enum EntityMonster {
	
	;

}