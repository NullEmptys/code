package org.gof.demo.worldsrv.skill.logic;



/**
 * 主动技能效果
 * @author new
 *
 */
public abstract class AbstractSkillLogicActive extends AbstractSkillLogic{

	
}
