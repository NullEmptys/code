package org.gof.demo.worldsrv.skill.logic;

import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.config.ConfSkillEffect;
import org.gof.demo.worldsrv.fight.DotManager;
import org.gof.demo.worldsrv.skill.SkillCommon;
import org.gof.demo.worldsrv.skill.SkillParam;
import org.gof.demo.worldsrv.support.Vector2D;


/**
 * 技能效果：dot
 * @author new
 *
 */
public class SkillLogic002 extends AbstractSkillLogicActive{
	public int dotSn;			//buffId			
	
	@Override
	public void init(SkillCommon skillCommon, ConfSkillEffect conf) {
		//父类方法初始化了范围前三个参数
		super.init(skillCommon, conf);
		dotSn = Utils.intValue(conf.param1);
	}
	
	@Override
	public void doSkillEffect(SkillParam position) {
		Vector2D vec = position.tarPos;
		UnitObject unitObj = position.tarUo;
		
		if(conf.targetSelf) {
			vec = skill.unitObj.posNow;
			unitObj = skill.unitObj;
		}
		
		DotManager.getInstance().create(skill.unitObj.stageObj, dotSn, skill.unitObj, unitObj, vec);
	}

	@Override
	public void doSkillEffectToTar(UnitObject unitDef) {
		
	}
}
