package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.Port;
import org.gof.core.support.Param;
import org.gof.core.support.RandomUtils;
import org.gof.core.support.Time;

public class AIBevActChangeTick extends AIBevLeaf {

	double delay = 0;
	public AIBevActChangeTick(AI ai) {
		this.ai = ai;
	}
	public AIBevActChangeTick(AI ai, double delay) {
		this.ai = ai;
		this.delay = delay;
	}
	@Override
	public boolean execute(Param param) {
		ai.timerPulse.setTimeNext(Port.getTime() + (int)((RandomUtils.nextDouble() * (1 + delay))* Time.SEC));
		return true;
	}
}
