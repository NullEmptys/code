package org.gof.demo.worldsrv.skill;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.gof.core.support.ManagerBase;
import org.gof.core.support.ManagerInject;
import org.gof.core.support.Param;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.character.MonsterObject;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.config.ConfSkill;
import org.gof.demo.worldsrv.entity.Human;
import org.gof.demo.worldsrv.human.HumanManager;
import org.gof.demo.worldsrv.msg.Msg.DSkill;
import org.gof.demo.worldsrv.stage.StageManager;
import org.gof.demo.worldsrv.support.I18n;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.ReasonResult;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;
import org.gof.demo.worldsrv.support.observer.Listener;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class SkillManager extends ManagerBase {
	@ManagerInject StageManager stageManager;
	@ManagerInject HumanManager humanManager;
	
	/**
	 * 获取实例
	 * @return
	 */
	public static SkillManager getInstance() {
		return getInstance(SkillManager.class);
	}
	
	
	/**
	 * 登录到地图时，初始化技能并且发送技能列表
	 * @param params
	 */
	@Listener(EventKey.HUMAN_STAGE_ENTER)
	public void onHumanLoginStage(Param params) {
		HumanObject humanObj = params.get("humanObj");
		
		//初始化玩家技能
		initSkill(humanObj);
		
	}
	
	/**
	 * 初始化技能
	 * @param unitObj
	 * @return
	 */
	public void initSkill(UnitObject unitObj) {
		//初始化主角技能
		initSkillRole(unitObj);
		
	}
	
	/**
	 * 初始化主角技能
	 * @param unitObj
	 */
	public void initSkillRole(UnitObject unitObj) {
		Human human = null;
		HumanObject humanObj = null;
		if(unitObj.isHumanObj()) {
			humanObj = (HumanObject)unitObj;
			human = humanObj.dataPers.human;
		}
		
		/** 一、主角普通技能 */
		//清空技能
		Map<Integer, SkillCommon> skills = unitObj.skills;
		skills.clear();
		
		//获取主角技能
		JSONObject jo = new JSONObject();
		//玩家
		if(unitObj.isHumanObj()) {
			jo = JSON.parseObject(human.getSkill());
		} else if(unitObj.isMonsterObj()) {
//			//怪物
			if(((MonsterObject) unitObj).ai.conf != null) {
				jo = JSON.parseObject(((MonsterObject) unitObj).ai.conf.skillAll);
			} 
		}
		
		//初始化正常技能
		for(String skillSn : jo.keySet()) {
			ConfSkill confSkill = ConfSkill.get(Integer.valueOf(skillSn));
			SkillCommon skill = new SkillCommon(unitObj, confSkill, jo.getIntValue(skillSn));
			skills.put(Integer.valueOf(confSkill.sn), skill);
		}
		
		
	}
	
	/**
	 * 有前摇技能加入施放队列，无前摇技能直接施放
	 * @param unitObj
	 * @param skillSn
	 * @param param
	 * @param atkerType		1玩家或者怪物本身 2魂将
	 * @param finalAtk		连点或者连击技能最终技
	 */
	public ReasonResult shakeOrCastSkill(UnitObject unitObj, int skillSn, SkillParam param) {
		//判断技能是否能释放
		SkillCommon skill = null;
		
		//主角技能
		if(param.atkerType == 1) {
			skill = unitObj.skills.get(skillSn);
		} else {
		}
		
		//技能不存在
		if(skill == null) {
			Log.fight.error("技能不存在，攻击者id={},技能id={},atkerType={},skillSize={}", unitObj.id, skillSn, param.atkerType, unitObj.skills.size());
			
			
			return new ReasonResult(false, I18n.get("fight.canCastSkill.notExist", skillSn));
		}
		
		//判断是否能施放技能
		ReasonResult result = skill.canCast(param);
		if(!result.success) {
			return result;
		}
		
		//检查是否在前摇状态
//		SkillExcute curSkillExcute = unitObj.skillTempInfo.skillToExcute;
//		if(curSkillExcute != null) {
//			return new ReasonResult(false, I18n.get("fight.canCastSkill.stateInShake"));
//		}
	
		//计算连击
		skill.comboCal(param);
		
		//发攻击前事件
		if(unitObj.isHumanObj()) {
			Event.fire(EventKey.HUMAN_ACTS_BEFORE, "humanObj", (HumanObject)unitObj);
		}
		
		//施放技能
		skill.castFirst(param);
		
		return new ReasonResult(true);
	}
	
	/**
	 * 获取技能列表
	 * @param humanObj
	 * @return
	 */
	public List<DSkill> getSkills(HumanObject humanObj) {
		List<DSkill> result = new ArrayList<>();
		// 获取玩家
		Human human = humanObj.dataPers.human;
		
		// 遍历用户已有技能 判断是否可以升级
		JSONObject jo = JSON.parseObject(human.getSkill());
		for(String key : jo.keySet()) {
			DSkill.Builder dSkill = DSkill.newBuilder();
			int humanSkillId = Utils.intValue(key);
			int humanSkillLv = jo.getIntValue(key);
//			// 获取当前技能信息
//			ConfSkillUpgrade confSkill = ConfSkillUpgrade.getBy("skillId", humanSkillId, "skillLevel", humanSkillLv);
//			// 获取下一级别信息
//			ConfSkillUpgrade confNext = ConfSkillUpgrade.getBy("skillId", confSkill.nextSkillId, "skillLevel", confSkill.nextSkillLevel);
//			
			// 如果满足等级条件，则记录可以升级的技能
			int canUpgrade = 0;
//			if(confNext != null) {
//				canUpgrade = confNext.humanLevel <= human.getLevel() ? 1 : 0;
//			}
			
//			dSkill.setSequence(confSkill.sequence);
			dSkill.setCanUpgrade(canUpgrade);
			dSkill.setSkillSn(humanSkillId);
			dSkill.setSkillLevel(humanSkillLv);
			result.add(dSkill.build());
		}
			
		return result;
	}
	
}
