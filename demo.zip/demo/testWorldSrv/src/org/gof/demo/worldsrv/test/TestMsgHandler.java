package org.gof.demo.worldsrv.test;

import org.gof.core.gen.callback.DistrCallback;
import org.gof.core.support.Param;
import org.gof.core.support.observer.MsgReceiver;
import org.gof.demo.worldsrv.msg.Msg.CSTest;
import org.gof.demo.worldsrv.msg.Msg.SCTest;
import org.gof.demo.worldsrv.msg.MsgIds;
import org.gof.demo.worldsrv.support.Log;
import org.gof.seam.msg.MsgParam;

public class TestMsgHandler {

	/**
	 * 接受机器人发送过来的消息
	 * 
	 * @param param
	 */
	@MsgReceiver(CSTest.class)
	public void onCSTest(MsgParam param) {

		// 从param中获取接受到的消息
		CSTest msg = param.getMsg();
		Log.game.info("Server receive the robot msg.");
		Log.game.info("CSTest Msg ID is [{}] code is [{}] string is [{}]", MsgIds.CSTest, msg.getCscode(), msg.getCsstring());

		//调用Service方法和处理回调
		TestServiceProxy pxy = TestServiceProxy.newInstance();
		pxy.csTestService(MsgIds.CSTest);
		pxy.listenResult(this, TestMsgHandlerCallback._result_onCSTest, "msgId", MsgIds.CSTest);
		
		//往客户端发送消息
		SCTest.Builder send =  SCTest.newBuilder();
		send.setSccode(9528);
		send.setScstring("This is a msg from Server!");
		param.getHumanObject().sendMsg(send);
	}

	/**
	 * onCSTest() 方法的回调方法
	 * 
	 * @param timeout
	 * @param results
	 * @param context
	 */
	@DistrCallback
	public void _result_onCSTest(Param results, Param context) {

		int msgId = context.getInt("msgId");
		Log.game.info("_result_onCSTest {}", msgId);
		
		String str = results.getString();
		Log.game.info("_result_onCSTest Service callback value is {}", str);
	}

}