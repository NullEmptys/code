package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.stage.StageObject;

public class AIBevCondDisTarObj extends AIBevLeaf{

	private double dis = 0;
	public AIBevCondDisTarObj(AI ai, double dis, boolean logic) {
		this.ai = ai;
		nonLogic = logic;
		this.dis = dis;
	}
	public AIBevCondDisTarObj(AI ai, double dis) {
		this.ai = ai;
		this.dis = dis;
	}
	@Override
	public boolean execute(Param param) {
		boolean result = false;
		
		StageObject stageObj = ai.monsterObj.stageObj;
		UnitObject unitObj = stageObj.getUnitObj(ai.targetId);
		if(unitObj != null) {
			if(unitObj.posNow.distance(ai.monsterObj.posNow) > dis) {
				result = true;
			} 
		}
		
		return returnLogic(result);
	}
}
