package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.config.ConfSkill;
import org.gof.demo.worldsrv.skill.SkillManager;
import org.gof.demo.worldsrv.skill.SkillParam;
import org.gof.demo.worldsrv.stage.StageObject;

public class AIBevActCastSkill extends AIBevLeaf {

	public AIBevActCastSkill(AI ai) {
		this.ai = ai;
	}

	@Override
	public boolean execute(Param param) {
		
		int skillSn = Utils.intValue(ai.conf.attack);
		ConfSkill conf = ConfSkill.get(skillSn);
		if(conf == null) {
			return false;
		}
		
		SkillParam skillParam = new SkillParam();
		StageObject stageObj = ai.monsterObj.stageObj;
		UnitObject unitObj = stageObj.getUnitObj(ai.targetId);
		if(unitObj == null) {
			ai.targetId = 0;
			ai.behavior = AIBehaviorKey.NORMAL;
			return false;
		}
		skillParam.tarUo = unitObj;
		skillParam.tarPos = unitObj.posNow;
		skillParam.atkerType = 1; 
		skillParam.finalAtk = false;
		
		SkillManager.getInstance().shakeOrCastSkill(ai.monsterObj, skillSn, skillParam);
		return true;
	}

}
