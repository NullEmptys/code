package org.gof.demo.worldsrv.stage;

import org.gof.core.Service;
import org.gof.core.gen.proxy.DistrClass;
import org.gof.demo.worldsrv.support.D;

@DistrClass(
)
public class StageService extends Service {
	
	
	public StageService(StagePort port) {
		super(port);
	}
	
	@Override
	public Object getId() {
		return D.SERV_STAGE_DEFAULT;
	}

	
}
