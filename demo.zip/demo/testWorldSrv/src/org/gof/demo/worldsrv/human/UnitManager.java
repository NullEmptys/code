package org.gof.demo.worldsrv.human;

import org.gof.core.support.ManagerBase;
import org.gof.core.support.ManagerInject;
import org.gof.core.support.Param;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.character.DotObject;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.character.MonsterObject;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.entity.Unit;
import org.gof.demo.worldsrv.fight.HpLostKey;
import org.gof.demo.worldsrv.msg.Msg.DHpChgOnce;
import org.gof.demo.worldsrv.msg.Msg.DHpChgTar;
import org.gof.demo.worldsrv.msg.Msg.SCFightHpChg;
import org.gof.demo.worldsrv.skill.SkillCommon;
import org.gof.demo.worldsrv.stage.StageManager;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;

public class UnitManager extends ManagerBase {
	@ManagerInject
	HumanManager humanManager;
	@ManagerInject
	StageManager stageManager;
	
	/**
	 * 获取实例
	 * @return
	 */
	public static UnitManager getInstance() {
		return getInstance(UnitManager.class);
	}
	
	/**
	 * 加血
	 * @param unitObjToAdd
	 * @param hpAdd
	 * @param unitObjFire		加血引起者
	 */
	public void addHp(UnitObject unitObjToAdd, HpLostKey hpLostKey, int hpAdd, UnitObject unitObjFire) {
		if(hpAdd <= 0) return ;
		
		long fireId = (unitObjFire == null ? 0 : unitObjFire.id);
		
		//当前剩余血量
		setHpCur(unitObjToAdd, Math.min(getHpMax(unitObjToAdd), getHpCur(unitObjToAdd) + hpAdd));
				
		//将耗血信息耗血的对象血包中
		DHpChgOnce.Builder dhpChgOnce = hpChg(unitObjToAdd, hpLostKey.name(), fireId, hpAdd, 0, false);
		SCFightHpChg.Builder msg = SCFightHpChg.newBuilder();
		
		DHpChgTar.Builder dhpTar = DHpChgTar.newBuilder();
		dhpTar.setId(unitObjToAdd.id);
		dhpTar.addDhpChgOnce(dhpChgOnce);
		
		msg.addDhpChgTar(dhpTar);
		stageManager.sendMsgToArea(msg, unitObjToAdd.stageObj, unitObjToAdd.posNow);
	}
	
	/**
	 * 扣血
	 * @param unitObj
	 * @param hpLoss
	 * @param unitObjFire 攻击方
	 */
	public void reduceHp(UnitObject unitObj, int hpLoss, UnitObject unitObjFire, Param param) {
		if(unitObj.isDie()) return ;
		
		//扣血小于0
		if(hpLoss < 0) return ;
		if(param == null) param = new Param();
		
		HpLostKey hpLostKey = Utils.getParamValue(param, "hpLostKey", HpLostKey.SKILL);
		String hpType = hpLostKey.name();
		
		//是否命中
		boolean isHit = Utils.getParamValue(param, "isHit", true);
		
		//是否暴击
		boolean isCrit = Utils.getParamValue(param, "isCrit", false);
		
		//如果命中并且扣血=0，则返回，正常不会出现这种情况
		if(hpLoss == 0 && isHit) return ;
		
		//正常攻击为0，暴击为1， 闪避为2
		int effect = 0;
		if(!isHit) effect = 2;
		if(isCrit) effect = 1;
		
		/** 一、当前血量减血 */
		//减血
		setHpCur(unitObj, Math.max(0, getHpCur(unitObj) - hpLoss));
		
		//将耗血信息加入到需要接受到掉血广播的人中
		long atkerId = (unitObjFire == null ? 0 : unitObjFire.id);
		DHpChgOnce.Builder dhpChgOnce = hpChg(unitObj, hpType, atkerId, hpLoss, effect, true);
		
		//技能耗血,将掉血包加到技能包里返回
		if(param.containsKey("skill")) {
			SkillCommon skill = param.get("skill");
			
			skill.addSkillHpChg(unitObj.id, dhpChgOnce);
		} else if(param.containsKey("dot")) {
			DotObject dotObj = param.get("dot");
			
			dotObj.addSkillHpChg(unitObj.id, dhpChgOnce);
		} else {
			SCFightHpChg.Builder msg = SCFightHpChg.newBuilder();
			
			DHpChgTar.Builder dhpTar = DHpChgTar.newBuilder();
			dhpTar.setId(unitObj.id);
			dhpTar.addDhpChgOnce(dhpChgOnce);
			
			msg.addDhpChgTar(dhpTar);
			stageManager.sendMsgToArea(msg, unitObj.stageObj, unitObj.posNow);
		}
		
		//如果没有命中则返回
		if(!isHit) return ;
		
		//抛出扣血事件
		int stageSn = unitObj.stageObj.sn;
		Event.fireEx(EventKey.UNIT_HPLOSS, stageSn, "unitObj", unitObj);
		if(unitObj.isHumanObj()) {
			Event.fireEx(EventKey.HUMAN_HPLOSS, stageSn, "humanObj", unitObj);
		} else if(unitObj.isMonsterObj()) {
			if(unitObjFire == null) {
				Event.fireEx(EventKey.MONSTER_HPLOSS_BY_NO_HUMAN, stageSn, "monsterObj", unitObj, "hpLost", hpLoss);
			} else {
				Event.fireEx(EventKey.MONSTER_HPLOSS, stageSn, "monsterObj", unitObj, "atker", unitObjFire, "hpLost", hpLoss);
			}
		}
		
//		//如果被攻击方是怪物，则怪物的最近5次攻击者中加入该玩家
//		if(unitObj.isMonsterObj() && unitObjFire != null) {
//			MonsterObject monsterObj = (MonsterObject)unitObj; 
//			
//			if(monsterObj.attackIds.contains(unitObjFire.id)) {
//				monsterObj.attackIds.remove(unitObjFire.id);
//			}
//			monsterObj.attackIds.add(0, unitObjFire.id);
//			
//			if(monsterObj.attackIds.size() > 5) {
//				monsterObj.attackIds = monsterObj.attackIds.subList(0, 4);
//			}
//		}
		
		//剩余血量大于0，返回
		if(getHpCur(unitObj) > 0) return ;
		
		SkillCommon skill = Utils.getParamValue(param, "skill", null);
		int skillSn = (skill == null ? 0 : skill.confSkill.sn);
		
		//怪物死亡
		if(unitObj instanceof MonsterObject) {
			//让怪物进入死亡
			((MonsterObject)unitObj).die(unitObjFire, "skillSn", skillSn);
		} else if(unitObj instanceof HumanObject) {
			//人物死亡
			((HumanObject)unitObj).die(unitObjFire, "skillSn", skillSn);
		}
	}
	
	public DHpChgOnce.Builder hpChg(UnitObject unitObj, String hpType, long attackerId, int hpChange, int effect, boolean hpLost) {
		Unit unit = unitObj.getUnit();
		DHpChgOnce.Builder dhpChgOnce = DHpChgOnce.newBuilder();
		dhpChgOnce.setHpChange(hpChange);
		dhpChgOnce.setHpType(hpType);
		dhpChgOnce.setHpCur(unit.getHpCur());
		dhpChgOnce.setHpMax(unit.getHpMax());
		dhpChgOnce.setEffect(effect);
		dhpChgOnce.setHpLost(hpLost);
		dhpChgOnce.setAttackerId(attackerId);
		return dhpChgOnce;
	}
	
	/**
	 * 获取unit当前血量
	 * @param unitObj
	 * @return
	 */
	private int getHpCur(UnitObject unitObj) {
		return unitObj.getUnit().getHpCur();
	}
	
	/**
	 * 设置unit当前血量
	 * @param unitObj
	 * @param hpCur
	 */
	private void setHpCur(UnitObject unitObj, int hpCur) {
		unitObj.getUnit().setHpCur(Math.max(0, hpCur));
	}
	
	/**
	 * 获取unit当前最大血量
	 * @param unitObj
	 * @return
	 */
	private int getHpMax(UnitObject unitObj) {
		return unitObj.getUnit().getHpMax();
	}
	
	

}