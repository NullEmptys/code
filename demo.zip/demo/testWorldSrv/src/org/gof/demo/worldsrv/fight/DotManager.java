package org.gof.demo.worldsrv.fight;

import org.gof.core.support.ManagerBase;
import org.gof.demo.worldsrv.character.DotObject;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.config.ConfDot;
import org.gof.demo.worldsrv.stage.StageObject;
import org.gof.demo.worldsrv.support.Vector2D;

public class DotManager extends ManagerBase {
	
	/**
	 * 获取实例
	 * @return
	 */
	public static DotManager getInstance() {
		return getInstance(DotManager.class);
	}

	/**
	 * 地图上加dot
	 * @param unitObj
	 * @param sn
	 * @param vector
	 */
	public void create(StageObject stageObj, int sn, UnitObject unitObjFire, UnitObject unitObjTar, Vector2D vector) {
		ConfDot confDot = ConfDot.get(sn);
		
		DotObject dotObj = new DotObject(stageObj, confDot, unitObjFire, unitObjTar, vector);
		dotObj.init();
		
		dotObj.stageEnter(stageObj);
	}
}
