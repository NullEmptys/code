package org.gof.demo.worldsrv.monster.ai;

import java.util.Collections;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.gof.core.support.Param;
import org.gof.core.support.TickTimer;
import org.gof.demo.worldsrv.character.MonsterObject;
import org.gof.demo.worldsrv.entity.Monster;
import org.gof.demo.worldsrv.support.Log;

public class AIBevActionRevive extends AIBevLeaf {

	public AIBevActionRevive(AI ai) {
		this.ai = ai;
	}
	
	@Override
	public boolean execute(Param param) {
		rebirth(ai.monsterObj);
		return true;
	}	
	
	public void rebirth(MonsterObject monsterObj) {
		// 重设出生点，血量，攻击目标等
		monsterObj.monster.setHpCur(monsterObj.monster.getHpMax());
		Collections.shuffle(monsterObj.posRebirth);
		monsterObj.posBegin.set(monsterObj.posRebirth.get(0));
		monsterObj.posNow.set(monsterObj.posBegin);

		monsterObj.stageShow();
		
		ai.behavior = AIBehaviorKey.NORMAL;

		if (monsterObj.isInWorld() == false) {
			Log.temp.info(ExceptionUtils.getStackTrace(new Throwable()));
		}


	}
}
