package org.gof.demo.worldsrv.pocketLine;


public class PocketLineEventSubKey {
	//删除申请
	public static final String HUMAN_POCKET_LINE_HANDLE_RELATION_FRIEND_APPLY_DEL = "RELATION_FRIEND_APPLY_DEL";
	//删除好友
	public static final String HUMAN_POCKET_LINE_HANDLE_RELATION_FRIEND_DEL = "RELATION_FRIEND_DEL";
	//被别人加黑名单
	public static final String HUMAN_POCKET_LINE_HANDLE_RELATION_BLACK_ADDED = "RELATION_BLACK_ADDED";
	
	//邮件提醒
	public static final String HUMAN_POCKET_LINE_HANDLE_MAIL_REMIND = "MAIL_REMIND"; 
}