package org.gof.demo.worldsrv.support.enumKey;

public enum EnumBevNodeType {
    CONDITION,
    ACTION,
    SEQ_NODE,
    SEL_NODE
}
