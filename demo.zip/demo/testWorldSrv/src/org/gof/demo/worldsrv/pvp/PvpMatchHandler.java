package org.gof.demo.worldsrv.pvp;

import org.gof.core.support.observer.MsgReceiver;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.CSFightPVPMatch;
import org.gof.demo.worldsrv.msg.Msg.CSFightPVPStart;
import org.gof.demo.worldsrv.msg.Msg.DHuman;
import org.gof.demo.worldsrv.msg.Msg.SCFightPVPMatchResult;
import org.gof.demo.worldsrv.msg.Msg.SCFightPVPStartResult;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.seam.msg.MsgParam;

public class PvpMatchHandler {

	@MsgReceiver(CSFightPVPMatch.class)
	public void onCSFightPVPMatch(MsgParam param) {

		DHuman.Builder dHuman = DHuman.newBuilder();
		dHuman.setId(param.getHumanObject().id);
		dHuman.setName("zhujueyujie.prefab");
		dHuman.setLevel(param.getHumanObject().dataPers.human.getLevel());
		dHuman.setSex(param.getHumanObject().dataPers.human.getSex());
		dHuman.setHpCur(param.getHumanObject().dataPers.human.getHpCur());
		dHuman.setHpMax(param.getHumanObject().dataPers.human.getHpMax());
		dHuman.setMpCur(param.getHumanObject().dataPers.human.getMpCur());
		dHuman.setMpMax(param.getHumanObject().dataPers.human.getMpMax());
		dHuman.setProfession(param.getHumanObject().dataPers.human
				.getProfession());

		SCFightPVPMatchResult.Builder send = SCFightPVPMatchResult.newBuilder();
		send.setResultCode(1);
		send.setMatcher(dHuman);
		param.getHumanObject().sendMsg(send);
	}

	@MsgReceiver(CSFightPVPStart.class)
	public void onCSFightPVPStart(MsgParam param) {
		Msg.DInitDataStage.Builder dStage = Msg.DInitDataStage.newBuilder();
		dStage.setPosNow(new Vector2D(param.getHumanObject().posNow.x, param
				.getHumanObject().posNow.y).toMsg());
		dStage.setId(param.getHumanObject().stageObj.id);
		dStage.setSn(param.getHumanObject().stageObj.sn);
//		dStage.setPositions(new Vector2D(param.getHumanObject().posNow.x, param
//				.getHumanObject().posNow.y).toMsg());

		SCFightPVPStartResult.Builder send = SCFightPVPStartResult.newBuilder();
		send.setResultCode(1);
		// send.setStage(dStage);
		param.getHumanObject().sendMsg(send);
	}
}
