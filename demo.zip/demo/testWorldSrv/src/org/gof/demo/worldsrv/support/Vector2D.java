package org.gof.demo.worldsrv.support;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.gof.core.InputStream;
import org.gof.core.OutputStream;
import org.gof.core.interfaces.ISerilizable;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.DVector2;

/**
 * 坐标
 */
public class Vector2D implements ISerilizable {
	public double x;			//横坐标
	public double y;			//纵坐标
	
	public Vector2D() { }
	
	/**
	 * 构造函数
	 * @param x
	 * @param y
	 */
	public Vector2D(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * 将消息位置信息转化本坐标
	 * @param vector2
	 */
	public Vector2D(DVector2 vector2) {
		this(vector2.getX(), vector2.getY());
	}
	
	/**
	 * 将消息位置信息转化本坐标
	 * @param vs
	 * @return
	 */
	public static List<Vector2D> parseFrom(List<DVector2> vs) {
		List<Vector2D> result = new ArrayList<>();
		for(DVector2 v : vs) {
			result.add(new Vector2D(v));
		}
		
		return result;
	}
	
	/**
	 * 将消息位置信息转化本坐标
	 * @param vs
	 * @return
	 */
	public static List<DVector2> toMsgs(List<Vector2D> vs) {
		List<DVector2> result = new ArrayList<>();
		for(Vector2D v : vs) {
			result.add(v.toMsg());
		}
		
		return result;
	}
	
	/**
	 * 转化为消息类型
	 * @return
	 */
	public DVector2 toMsg() {
		Msg.DVector2.Builder msg = Msg.DVector2.newBuilder();
		msg.setX((float)x);	
		msg.setY((float)y);
		
		return msg.build();
	}
	
	/**
	 * 转换为三维float型数组
	 */
	public float[] toFloat3() {
		return new float[]{(float)x, 0, (float)y};
	}
	
	/**
	 * 导航网格的
	 * @return
	 */
	public float[] toDetourFloat3() {
		return new float[]{(float)y, 0, (float)x};
	}
	/**
	 * 设置坐标值
	 * @param vector
	 */
	public void set(Vector2D vector) {
		this.x = vector.x;
		this.y = vector.y;
	}
	
	/**
	 * 获取易读的坐标字符串
	 * @return
	 */
	public String getPosStr() {
		return new StringBuilder("(").append(x).append(",").append(y).append(")").toString();
	}
	
	/**
	 * 两点之间的距离
	 * @param pos
	 * @return
	 */
	public double distance(Vector2D pos) {
		double t1x = this.x;
		double t1y = this.y;
		double t2x = pos.x;
		double t2y = pos.y;
		
		return Math.sqrt(Math.pow((t1x -t2x), 2) + Math.pow((t1y - t2y) , 2));
	}
	
	/**
	 * 从A 指向 B的方向 从C点移动 DIS的距离
	 * @param start
	 * @param end
	 * @param dis
	 * @return
	 */
	public static Vector2D lookAtDis(Vector2D start, Vector2D end, Vector2D org, double dis) {
		Vector2D result = new Vector2D();
		
		if(end.equals(start)) {
			return start;
		}
		double diffX = end.x - start.x;
		double diffY = end.y - start.y;
		
		//实际距离
		double diffTrue = Math.sqrt(Math.pow(diffX, 2) + Math.pow(diffY, 2));
		
		//起始至目标的Sin,Cos值
		double tempSin = diffY / diffTrue;
		double tempCos = diffX / diffTrue;
		
		double dX = tempCos * dis;
		double dY = tempSin * dis;
		
		result.x = org.x + dX;
		result.y = org.y + dY;
		
		return result;
	}
	@Override
	public void writeTo(OutputStream out) throws IOException {
		out.write(x);
		out.write(y);
	}
	
	@Override
	public void readFrom(InputStream in) throws IOException {
		x = in.read();
		y = in.read();
	}
	
	@Override
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		
		if(!(other instanceof Vector2D)) {
			return false;
		}
		
		Vector2D castOther = (Vector2D) other;
		return new EqualsBuilder().append(this.x, castOther.x).append(this.y, castOther.y).isEquals();
	}
	
	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(x).append(y).toHashCode();
	}

	@Override
	public String toString() {
		return new StringBuilder().append("[").append(x).append(",").append(y).append("]").toString();
	}
}
