package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;

public class AIBevSeqenceNode extends AIBevNodeControl{

	@Override
	public boolean execute(Param param) {
        boolean result = true;
        for (AIBevLeaf iterable_element : child) {
        	if(!iterable_element.execute(param)) {
        		return false;
        	}
		}
        return result;
	}

}
