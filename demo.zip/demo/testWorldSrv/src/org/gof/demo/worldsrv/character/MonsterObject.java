package org.gof.demo.worldsrv.character;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.gof.core.Port;
import org.gof.core.PortPulseQueue;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.config.ConfMonster;
import org.gof.demo.worldsrv.entity.Buff;
import org.gof.demo.worldsrv.entity.Monster;
import org.gof.demo.worldsrv.entity.Unit;
import org.gof.demo.worldsrv.monster.ai.AI;
import org.gof.demo.worldsrv.msg.Msg.DStageMonster;
import org.gof.demo.worldsrv.msg.Msg.DStageObject;
import org.gof.demo.worldsrv.msg.Msg.EWorldObjectType;
import org.gof.demo.worldsrv.msg.Msg.SCStageObjectAppear;
import org.gof.demo.worldsrv.msg.Msg.SCStageObjectInfoChange;
import org.gof.demo.worldsrv.skill.SkillManager;
import org.gof.demo.worldsrv.stage.StageObject;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.PropCalcCommon;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.demo.worldsrv.support.enumKey.PropKey;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;


/**
 * 怪物
 */
public class MonsterObject extends UnitObject {
	
	public int sn;							//sn
	public Vector2D posBegin;			//出生位置
	public List<Vector2D> posRebirth = new ArrayList<>();
	public ConfMonster conf;			//基本配置
	public Monster monster = new Monster();
	public boolean active = true;		//是否已经激活
	
	public PropCalcCommon buffPropPlus = new PropCalcCommon();
	
	public Map<Integer, Buff> buffs = new HashMap<>();
	
	public AI ai;
	
	public MonsterObject(StageObject stageObj, int sn, boolean active) {
		super(stageObj);
		
		this.id = Port.applyId();
		this.sn = sn;
		this.conf = ConfMonster.get(sn);
		this.name = conf.name;
		this.active = active;
		//设置monster的配置信息
		if(conf == null) {
			Log.monster.error("地图{}上怪物{}配置不存在", stageObj.sn, sn);
			return;
		}
		
		//初始化怪物
		List<String> propContain = Utils.ofList("atk", "def", "hit", "dodge", "speed");
		for(PropKey prop : PropKey.values()) {
			String propName = prop.name();
			
			if(!propContain.contains(propName)) continue;
			
			// 速度是float，这里int改为Object
			int value = Utils.fieldRead(conf, propName);
			Utils.fieldWrite(this.monster, propName, value);
		}
		
		this.monster.setHpCur(conf.hpMax);
		this.monster.setHpMax(conf.hpMax);
		this.monster.setLevel(conf.level);
		
		//初始化AI
		this.ai = new AI(this);
		//初始化技能
		SkillManager.getInstance().initSkill(this);
	}
	
	
	@Override
	public void startup() {
		//一些初始化工作
		posNow.x = posBegin.x;
		posNow.y = posBegin.y;
		
		posRebirth.add(posBegin);
		
		
		this.stageEnter(stageObj);
	}
	
	@Override
	public Unit getUnit() {
		return monster;
	}
	
	@Override
	public Map<Integer, Buff> getBuffs() {
		return buffs;
	}
	
	@Override
	public PropCalcCommon getPropPlus() {
		return buffPropPlus;
	}
	
	@Override
	public DStageObject.Builder createMsg() {
		//monster特有信息
		DStageMonster.Builder dMonster = DStageMonster.newBuilder();
		dMonster.addAllPosEnd(running.getRunPathMsg());
		dMonster.setMonsterSn(conf.sn);
		dMonster.setHpCur(monster.getHpCur());
		dMonster.setHpMax(monster.getHpMax());
		dMonster.setCollisionRadius((int)(conf.collisionRadius));
		dMonster.setSpeed(monster.getSpeed());
		dMonster.setActive(active);
		
		//共同信息
		DStageObject.Builder dObj = DStageObject.newBuilder();
		dObj.setObjId(id);
		dObj.setType(EWorldObjectType.MONSTER);
		dObj.setPos(posNow.toMsg());
		dObj.setName(name);
		dObj.setMonster(dMonster);
		
		return dObj;
	}
	
	public SCStageObjectAppear.Builder createMsgBorn() {
		SCStageObjectAppear.Builder msgBorn = SCStageObjectAppear.newBuilder();
		msgBorn.setObjAppear(createMsg());
		msgBorn.setType(2);
		
		return msgBorn;
	}
	
	
		
	/**
	 * 怪物出现
	 */
	@Override
	public void stageShow() {
		// 已在地图中的 忽略
		if(inWorld) {
			Log.stageCommon.warn("使活动单元进入地图时发现inWorld状态为true：data={}", this);
			return;
		}

		// 设置状态为在地图中
		inWorld = true;

		// 日志
		if(Log.stageCommon.isInfoEnabled()) {
			Log.stageCommon.info("地图单位进入地图: stageId={}, objId={}, objName={}", stageObj.id, id, name);
		}

		// 通知其他玩家 有地图单元进入视野
		List<HumanObject> humanObjs = stageManager.getHumanObjsInArea(stageObj, posNow);
		for(HumanObject humanObj : humanObjs) {
			humanObj.sendMsg(createMsgBorn());
		}
		
		if(active) {
			//抛出怪物出生事件
			Event.fire(EventKey.MONSTER_BORN, "monsterObj", this);
		}
	}
	
	public SCStageObjectInfoChange.Builder createMsgUpdate() {
		SCStageObjectInfoChange.Builder infoChange = SCStageObjectInfoChange.newBuilder();
		infoChange.setObj(createMsg());
		stageManager.sendMsgToArea(infoChange, stageObj, posNow);
		
		return infoChange;
	}
	
	/**
	 * 怪物死亡，根据怪物配置来确定怪物是否要删除
	 */
	@Override
	public void die(UnitObject killer, Object...params) {
		super.die(killer, params);
		stageObj.getPort().addQueue(new PortPulseQueue("stageObj", stageObj, "worldObj", this) {
			public void execute(Port port) {
				StageObject stageObj = param.get("stageObj");
				WorldObject worldObj = param.get("worldObj");
				
				if(ai != null && ai.conf.timeRefresh <= 0) {
					stageObj._delWorldObj(worldObj);
				}
			}
		});
		
		
	}
	
	@Override
	public void pulse() {
		super.pulse();
		
		if(ai != null) ai.pulse();
//		Log.monster.info("怪物心跳中！");
	}
	
	
	
	
}
