package org.gof.demo.worldsrv.monster.ai;

import java.util.ArrayList;
import java.util.List;

import org.gof.core.Port;
import org.gof.core.support.RandomUtils;
import org.gof.core.support.TickTimer;
import org.gof.core.support.Time;
import org.gof.demo.worldsrv.character.MonsterObject;
import org.gof.demo.worldsrv.config.ConfAI;
import org.gof.demo.worldsrv.msg.Msg.SCStageObjectInfoChange;
import org.gof.demo.worldsrv.stage.StageManager;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;

/**
 * 怪物AI
 */
public class AI {
	public ConfAI conf;
	
	public MonsterObject monsterObj = null; // 所属怪物
	public TickTimer timerPulse = new TickTimer(); // 刷新状态时间
	public long timeCreate; // ai创建时间
	public long timeInFight; // 最后战斗时间
//	public long timeInFindGrid = 0; //找到网格的时间
	public List<Integer> skillList = new ArrayList<>(); // 条件技能队列

	public long targetId; // 攻击目标Id
	public Vector2D tarMovePos;  //现在正在移动的位置
	public AIBehaviorKey behavior;	
	private AIBevNodeControl aiBevRoot;
	protected StageManager stageManager = StageManager.getInstance();
	
	

	public AI(MonsterObject monsterObj) {
		this.monsterObj = monsterObj;
		
		this.conf = ConfAI.get(monsterObj.conf.aiSN);
		
		timerPulse.start(Time.SEC);
		// 创建时间
		timeCreate = Port.getTime();
		
		behavior = AIBehaviorKey.NORMAL;
		initAIBev();
	}

	/**
	 * 自己添加一个行为树
	 */
	public void initAIBev() {
		timerPulse.setTimeNext(Port.getTime() + (int)(RandomUtils.nextDouble() * Time.SEC));
		if(null == aiBevRoot && conf != null) {
			aiBevRoot = new AIBevSelectorNode();//选择节点||
			//死亡复活
			//回巢
			//攻击
			//巡逻
			//发呆
			
			//死亡复活
			if(conf.timeRefresh > 0) {//顺序节点
				//添加顺序节点
				AIBevNodeControl ai1 = new AIBevSeqenceNode();// 序列节点&&
				//添加死亡判断
				AIBevLeaf leaf11 = new AIBevConditionDie(this);//条件节点
				ai1.addChild(leaf11);
				//添加延迟
				AIBevNodeControl ai12 = new AIBevDelayNode(conf.timeRefresh);
				ai1.addChild(ai12);
				//添加复活行为
				AIBevLeaf leaf12 = new AIBevActionRevive(this);
				ai12.addChild(leaf12);
				aiBevRoot.addChild(ai1);
			}
			
			//如果超出了出生点很远的距离那么回到出生地啊
			AIBevNodeControl ai2 = new AIBevSeqenceNode();
			//是否触发回巢
			AIBevConditionDisBirth leaf21 = new AIBevConditionDisBirth(this, conf.radiusChase);
			ai2.addChild(leaf21);
			//启动回巢状态
			AIBevActionToState leaf25 = new AIBevActionToState(this, AIBehaviorKey.BACK);
			ai2.addChild(leaf25);
			//移动
			AIBevActionMoveTarPos leaf22 = new AIBevActionMoveTarPos(this);
			ai2.addChild(leaf22);
			//判断是否离目标点很近了
			AIBevCondDisTarPos leaf23 = new AIBevCondDisTarPos(this, 1);
			ai2.addChild(leaf23);
			//回到一般状态
			AIBevActionToState leaf24 = new AIBevActionToState(this, AIBehaviorKey.NORMAL);
			ai2.addChild(leaf24);
			aiBevRoot.addChild(ai2);
			
			//如果被攻击了 那么攻击打他的人。 
			if(conf.isCounterattackAuto) {
				AIBevNodeControl ai4 = new AIBevSeqenceNode();
				//如果是被攻击
				AIBevCondState leaf41 = new AIBevCondState(this, AIBehaviorKey.ATTACKED);
				ai4.addChild(leaf41);
				//如果是远程的怪物那么移动到对应的位置
				//如果是近战的怪物那么移动到对应的位置
				
				AIBevNodeControl a42 = new AIBevSelectorNode();
				ai4.addChild(a42);
				
				AIBevNodeControl a43 = new AIBevSeqenceNode();
				a42.addChild(a43);
				
////				//距离不OK 
//				AIBevCondDisTarObj leaf44 = new AIBevCondDisTarObj(this, 1.5);
//				a43.addChild(leaf44);
////				//移动
//				AIBevActionMovTarObj leaf45 = new AIBevActionMovTarObj(this, 1);
//				a43.addChild(leaf45);
				
				//怪物重叠 或者 怪物不在范围内都执行移动，也就是说如果怪物不重叠了，并且怪物离目标范围可以放技能 
				AIBevNodeControl a421 = new AIBevSelectorNode();
				a43.addChild(a421);
				AIBevActMovePos9Grid leaf47 = new AIBevActMovePos9Grid(this, conf.grid9Dis, conf.grid9Radius);
				a421.addChild(leaf47);
				AIBevCondDisTarObj leaf44 = new AIBevCondDisTarObj(this, conf.fightDis);
				a421.addChild(leaf44);
				
				AIBevActionMoveTarPos leaf48 = new AIBevActionMoveTarPos(this);
				a43.addChild(leaf48);
				AIBevActChangeTick leaf49 = new AIBevActChangeTick(this, 0.5);
				a43.addChild(leaf49);
				
				//距离OK
				//发射技能
				AIBevNodeControl ai461 = new AIBevDelayNode(conf.timeFireSkill);
				AIBevActCastSkill leaf46 = new AIBevActCastSkill(this);
				ai461.addChild(leaf46);
				a42.addChild(ai461);
				
				aiBevRoot.addChild(ai4);
			}
			
			if(conf.radiusMove > 0) {
				//如果没有被攻击那么巡逻玩
				AIBevNodeControl ai3 = new AIBevSeqenceNode();
				//等一个随机秒数 改变tick的频率
				AIBevActChangeTick leaf31 = new AIBevActChangeTick(this);
				ai3.addChild(leaf31);
				//找到一个随机点
				AIBevActGetRandPos leaf32 = new AIBevActGetRandPos(this, conf.radiusMove);
				ai3.addChild(leaf32);
				//然后开始移动
				AIBevActionMoveTarPos leaf33 = new AIBevActionMoveTarPos(this);
				//延迟一s
				AIBevNodeControl ai34 = new AIBevDelayNode(conf.timePatrol);
				ai34.addChild(leaf33);
				ai3.addChild(ai34);
				
				aiBevRoot.addChild(ai3);
			}
		}
	}
	/**
	 * 定时更新怪物的状态
	 */
	public void pulse() {
		long curr = Port.getTime();
		if (!timerPulse.isPeriod(curr))
			return;

		//执行行为树
		aiBevRoot.execute(null);
	}

	/**
	 * 激活怪物
	 */
	public void activate() {

		if (monsterObj.isInWorld() == false) {
			Log.temp.info("怪物isInWorld = false");
		}

		monsterObj.active = true;
		// 发送信息告诉前端
		SCStageObjectInfoChange.Builder sic = SCStageObjectInfoChange
				.newBuilder();
		sic.setObj(monsterObj.createMsg());
		stageManager.sendMsgToArea(sic, monsterObj.stageObj, monsterObj.posNow);
		// 激活怪，抛出出生事件
		Event.fire(EventKey.MONSTER_BORN, "monsterObj", monsterObj);
	}


	/**
	 * 在朝向目标的方向上选取一个随机的点，该点在以目标为中心半径为radius的圆上，角度在怪物与目标点形成的直线的垂线180°内随机
	 * 
	 * @param begin
	 * @param end
	 * @return
	 */
	public Vector2D getTargetPos(Vector2D begin, Vector2D end, double radius) {
		// 计算出y轴旋逆时针旋转到起点终点构成的向量之间的旋转角
		Vector2D vec = new Vector2D(end.x - begin.x, end.y - begin.y);
		double rotateAngle = getRotateAngle(0, 10, vec.x, vec.y);

		// 在180°内随机一个角度
		int degree = RandomUtils.nextInt(180);
		// 旋转对应的角度
		degree += rotateAngle;
		double angle = Math.PI * (degree) / 180.0;

		// 因为我们的坐标系为y轴向下，跟常规坐标系相反，所以y轴取负值
		double x = end.x + radius * Math.cos(angle);
		double y = end.y - radius * Math.sin(angle);

		// 进行一次检测，避免目标点在阻挡中

		return new Vector2D(x, y);
	}

	/**
	 * 获取向量p1到p2的逆时针旋转角，其中向量p1表示为x1，y1；向量p2表示为x2，y2
	 * 
	 * @param x1
	 * @param y1
	 * @param x2
	 * @param y2
	 * @return
	 */
	public double getRotateAngle(double x1, double y1, double x2, double y2) {
		double epsilon = 1.0e-6;
		double dist, dot, degree, angle;
		if (x1 == x2 && y1 == y2) {
			return 90;
		}

		// normalize，标准化
		dist = Math.sqrt(x1 * x1 + y1 * y1);
		x1 /= dist;
		y1 /= dist;

		dist = Math.sqrt(x2 * x2 + y2 * y2);
		x2 /= dist;
		y2 /= dist;

		// dot product 向量点积
		dot = x1 * x2 + y1 * y2;
		if (Math.abs(dot - 1.0) <= epsilon) {
			angle = 0.0;
		} else if (Math.abs(dot + 10) <= epsilon) {
			angle = Math.PI;
		} else {
			double cross;
			angle = Math.acos(dot);

			// cross product 向量x乘
			cross = x1 * y2 - x2 * y1;

			// vector p2 is clockwise from vector p1
			// with respect to the origin (0.0)
			if (cross > 0) {
				angle = 2 * Math.PI - angle;
			}
		}

		degree = angle * 180.0 / Math.PI;
		return degree;
	}
}
