package org.gof.demo.worldsrv.stage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.gof.core.Node;
import org.gof.core.Port;
import org.gof.core.scheduler.ScheduleTask;
import org.gof.core.support.Distr;
import org.gof.core.support.ManagerBase;
import org.gof.core.support.ManagerInject;
import org.gof.core.support.Param;
import org.gof.core.support.RandomUtils;
import org.gof.core.support.SysException;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.character.WorldObject;
import org.gof.demo.worldsrv.config.ConfMonsterBirth;
import org.gof.demo.worldsrv.config.ConfStage;
import org.gof.demo.worldsrv.monster.MonsterManager;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.SCStageEnterResult;
import org.gof.demo.worldsrv.msg.Msg.SCStageObjectAppear;
import org.gof.demo.worldsrv.msg.Msg.SCStageObjectDisappear;
import org.gof.demo.worldsrv.support.D;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.demo.worldsrv.support.Vector3D;
import org.gof.demo.worldsrv.support.observer.EventKey;
import org.gof.demo.worldsrv.support.observer.Listener;
import org.gof.demo.worldsrv.support.pathFinding.HeightFinding;
import org.gof.demo.worldsrv.support.pathFinding.PathFinding;

import com.google.protobuf.Message.Builder;


public class StageManager extends ManagerBase {
	
	@ManagerInject private MonsterManager monsterManager;
	
	/**
	 * 游戏启动时 创建主地图
	 * @param params
	 * @throws Exception 
	 */
	@Listener(EventKey.GAME_STARTUP_BEFORE)
	public void onGameStartupBefore(Param params) throws Exception {
		Node node = params.get("node");
		
		//初始化地图
		for(int i = 0; i < D.PORT_STAGE_STARTUP_NUM; ++i) {
			//拼PortId
			String portId = D.PORT_STAGE_PREFIX + i;
			
			//验证启动Node
			String nodeId = Distr.getNodeId(portId);
			if(!node.getId().equals(nodeId)) {
				continue;
			}
			
			//创建地图Port
			StagePort portStage = new StagePort(portId);
			portStage.startup(node);
			
			//默认服务
			StageService stageServ = new StageService(portStage);
			stageServ.startup();
			portStage.addService(stageServ);
			
			//测试2个基本场景
//			if(i == 0) {
//				portStage.createCommonSafe(1000);
//				portStage.createCommonSafe(1001);
//			}
			
			//加载下属主地图
			List<ConfStage> stages = ConfStage.findBy(ConfStage.K.portId, portId, ConfStage.K.type, "common");
			for(ConfStage s : stages) {
				portStage.createCommonSafe(s.sn);
			}
		}
	}
	
	/**
	 * 获取实例
	 * @return
	 */
	public static StageManager getInstance() {
		return getInstance(StageManager.class);
	}
	
	/**
	 * 创建普通地图
	 * @param stageSn
	 */
	public StageObject createCommon(int stageSn) {
		StagePort port = (StagePort)Port.getCurrent();

		StageObject stage = new StageObject(port, stageSn, stageSn);
		stage.startup();
		
		return stage;
	}
	
	/**
	 * 发送消息至玩家
	 */
	public void sendMsgToHumans(Builder builder, Collection<HumanObject> humans) {
		for(HumanObject human : humans) {
			human.sendMsg(builder);
		}
	}
	
	/**
	 * 发送消息至地图中的全部玩家
	 */
	public void sendMsgToStage(Builder builder, StageObject stageObj) {
		sendMsgToHumans(builder, stageObj.getHumanObjs().values());
	}

	/**
	 * 发送消息至九宫格中的全部玩家
	 */
	public void sendMsgToArea(Builder builder, StageObject stageObj, Vector2D pos) {
		sendMsgToHumans(builder, getHumanObjsInArea(stageObj, pos));
	}
	
	/**
	 * 获取某张地图中以某个地图格为中心的九宫格
	 * @param stageObjId
	 * @param cellId
	 * @return
	 */
	public List<StageCell> getCellsInArea(StageObject stageObj, StageCell cell) {
		List<StageCell> result = new ArrayList<>();
		
		int i = cell.i;
		int j = cell.j;
		
		int [] is = {i - 1, i, i + 1};
		int [] js = {j - 1, j, j + 1};
		for(int y : js) {
			for(int x : is) {
				StageCell temp = stageObj.getCell(x, y);
				if(temp == null) continue;
				result.add(temp);
			}
		}
		return result;
	}
	
	public List<HumanObject> getHumanObjsInArea(StageObject stageObj, Vector2D pos) {
		//获取九宫格
		StageCell cell = stageObj.getCell(pos);
		List<StageCell> cells = getCellsInArea(stageObj, cell);
		
		//在九宫格中获取玩家
		List<HumanObject> result = new ArrayList<>();
		for(StageCell c : cells) {
			for(HumanObject ho : c.getHumans().values()) {
				result.add(ho);
			}
		}
		
		return result;
	}
	
	/**
	 * 地图单元跨地图格，不只是人，还可能是怪物等
	 * @param cellBegin
	 * @param cellEnd
	 * @param objId
	 */
	public void cellChanged(StageCell cellBegin, StageCell cellEnd, WorldObject obj) {
		//不是同一张地图内
		if(!cellBegin.isInSameStage(cellEnd)) {
			throw new SysException("严重错误！地图单元跨不同地图的地图格");
		}
		//没跨格
		if(cellBegin.equals(cellEnd)) return;
		
		StageObject stageObj = obj.stageObj;
		if(Log.stageMove.isDebugEnabled()) {
			Log.stageMove.debug("地图单元跨地图格子了，objId={}，cellBegin={}，cellEnd={}", obj.id, cellBegin.i + "," + cellBegin.j, cellEnd.i + "," + cellEnd.j);
		}
		//把obj从旧的区域移走，加入到新的区域
		cellBegin.delWorldObject(obj);
		cellEnd.addWorldObject(obj);
		
		//通知旧的区域有地图单位离开
		List<StageCell> cellsLeave = getCellsChangedLeave(stageObj, cellBegin, cellEnd);
		SCStageObjectDisappear.Builder msgObjDisappear = obj.createMsgDisappear();
		for(StageCell cell : cellsLeave) {
			for(HumanObject humanObj : cell.getHumanObjects().values()) {
				if(humanObj.id == obj.id) continue;
				//发送消息
				humanObj.sendMsg(msgObjDisappear);
				if(Log.stageMove.isInfoEnabled()) {
					Log.stageMove.info("移动单元{}从{}的视野中消失", obj.id, humanObj.name);
				}
			}
		}
		
		//通知新的区域有物体进入
		SCStageObjectAppear.Builder msgObjAppear = obj.createMsgAppear();
		
		List<StageCell> cellsNew = this.getCellChangedEnter(stageObj, cellBegin, cellEnd);
		for(StageCell cell : cellsNew) {
			for(HumanObject humanObj : cell.getHumanObjects().values()) {
				if(humanObj.id == obj.id) continue;
				//发送消息
				humanObj.sendMsg(msgObjAppear);
				if(Log.stageMove.isInfoEnabled()) {
					Log.stageMove.info("移动单元{}名字为{}出现在{}的视野中", obj.id, humanObj.name);
				}
			}
		}
		
		//给玩家发送周围信息
		if(obj instanceof HumanObject) {
			HumanObject humanObj = (HumanObject)obj;
			//离开格子中的东西
			for(StageCell cell : cellsLeave) {
				for(WorldObject o : cell.getWorldObjects().values()) {
					humanObj.sendMsg(o.createMsgDisappear());
				}
			}
			//新增格子中的东西
			for(StageCell cell : cellsNew) {
				for(WorldObject wo : cell.getWorldObjects().values()) {
					if(wo.id == obj.id) continue;
					if(!wo.isInWorld()) continue;
					humanObj.sendMsg(wo.createMsgAppear());
				}
			}
		}
	}
	
	/**
	 * 获取进入新区域后，新九宫格对比旧九宫格的增加区域。
	 * @param stageObjId
	 * @param cellBegin
	 * @param cellEnd
	 * @return
	 */
	private List<StageCell> getCellChangedEnter(StageObject stageObj, StageCell cellBegin, StageCell cellEnd) {
		//新旧区域
		List<StageCell> begin = getCellsInArea(stageObj, cellBegin);
		List<StageCell> end = getCellsInArea(stageObj, cellEnd);

		//取出新增部分
		List<StageCell> result = new ArrayList<>();
		for(StageCell c : end) {
			if(begin.contains(c))
				continue;

			result.add(c);
		}

		return result;
	}
	
	/**
	 * 获取进入新区域后，新九宫格对比旧九宫格减少的区域。
	 * @param stageObjId
	 * @param cellBegin
	 * @param cellEnd
	 * @return
	 */
	private List<StageCell> getCellsChangedLeave(StageObject stageObj, StageCell cellBegin, StageCell cellEnd) {
		//新旧区域
		List<StageCell> begin = getCellsInArea(stageObj, cellBegin);
		List<StageCell> end = getCellsInArea(stageObj, cellEnd);
		
		//取出减少部分
		List<StageCell> result = new ArrayList<>();
		for(StageCell c : begin) {
			if(end.contains(c)) continue;
			
			result.add(c);
		}
		
		return result;
	}
	
	
	/**
	  * 通过坐标来获取区九宫格域内所有单元
	 * @param stageObj
	 * @param pos
	 * @return
	 */
	public List<WorldObject> getWorldObjsInArea(StageObject stageObj, Vector2D pos) {
		//获取九宫格
		StageCell cell = stageObj.getCell(pos);
		List<StageCell> cells = this.getCellsInArea(stageObj, cell);
		
		//在九宫格中获取地图单元
		List<WorldObject> result = new ArrayList<>();
		for(StageCell c : cells) {
			for(WorldObject wo : c.getWorldObjects().values()) {
				result.add(wo);
			}
		}
		
		return result;
	}
	
	
	/**
	 * 将玩家拉到当前地图上的某个位置
	 * @param humanObj
	 * @param vector
	 */
	public void pullTo(HumanObject humanObj, Vector2D vector) {
		//原地点发送消失消息
		humanObj.stageHide();
		
		humanObj.posNow = vector;
		
		//通知前端刷新到当前点
		Msg.SCStagePullTo.Builder msgPull = Msg.SCStagePullTo.newBuilder();
		msgPull.setPos(humanObj.posNow.toMsg());
		humanObj.sendMsg(msgPull.build());
		
		SCStageEnterResult.Builder msgER = SCStageEnterResult.newBuilder();
		for(WorldObject o : getWorldObjsInArea(humanObj.stageObj, humanObj.posNow)) {
			if(!o.isInWorld()) continue;
			if(o.equals(humanObj)) continue;

			msgER.addObj(o.createMsg());
		}
		humanObj.sendMsg(msgER);
		
		//从现在的地点出现
		humanObj.stageShow();
	}
	
	/**
	 * 切换地图,尽量用此处方法，这里会加延迟切换并且改变玩家状态
	 * @param humanObj
	 * @param stageTargetId
	 * @param posAppear						//切换地图后的出现位置，为null的话出现在默认位置
	 */
	public void switchTo(final HumanObject humanObj, final long stageTargetId, final Vector2D posAppear) {
		
		Port port = Port.getCurrent();
		
		//切换地图加200ms延迟，并且改变用户状态设置为切换地图中
		port.getService(D.SERV_STAGE_DEFAULT).scheduleOnce(new ScheduleTask() {
			@Override
			public void execute() {
				//切换地图
				StageGlobalServiceProxy prx = StageGlobalServiceProxy.newInstance();
				prx.switchToStage(humanObj, stageTargetId, posAppear);
				
				//设置玩家状态为正在切换地图中
				humanObj.isStageSwitching = true;
			}
		}, 200);
		
	}
	
	
	/**
	 * 生成地图点配置的地图单元
	 */
	public void createObjByConf(StageObject stageObj, ConfMonsterBirth confMonsBirth) {
		double x = confMonsBirth.posX;	
		double y = confMonsBirth.posY;	
		Vector2D pos = new Vector2D(x, y);
		int sn = confMonsBirth.monster1Sn;
		int num = confMonsBirth.monsterNum;
		double radius = confMonsBirth.posParam1;
		
		//生成怪逻辑
		monsterManager.create(stageObj, sn, pos, radius, num, true);
	}
	
	/**
	 * 根据圆心和起始半径，在圆环内随机一个点
	 * @param pos
	 * @param radius
	 * @return
	 */
	public Vector2D randomPosInCircle(Vector2D pos, double radiusMin, double radiusMax) {
		if(radiusMin > radiusMax) {
			throw new SysException("在圆环内随机点出错，小圆半径大于大圆半径");
		}
		//随机位置
		//角度
		int angle = RandomUtils.nextInt(360);
		//半径 TODO 需要改进
		double r = radiusMin + RandomUtils.nextDouble() * (radiusMax - radiusMin);
		//计算位置
		return new Vector2D(pos.x + r * Math.sin(angle), pos.y + r * Math.cos(angle));
	}
	
	
	/**
	 * 获取以pos位置为起点，target为终点的线段，往线段两边扩展width/2，并且从起始点为长度length的矩形区域内的unitObj
	 * @param stageObj
	 * @param pos
	 * @param length
	 * @param width
	 * @return
	 */
	public List<UnitObject> getUnitObjsInRectangle(StageObject stageObj, Vector2D pos, Vector2D target, double height, double width) {
		List<UnitObject> result = new ArrayList<>();
		
		double c = pos.distance(target);
		
		//利用余弦定理计算夹角a的余弦值
		double cosA = (double)(target.x - pos.x) / c;
		double sinA = (double)(target.y - pos.y) / c;
		
		for(UnitObject uo : stageObj.getUnitObjs().values()) {
			//判断距离是否符合要求
			
			Vector2D p = uo.posNow;
			//p绕pos点旋转-A角度到新坐标
			//如果P点绕另一点P0（x0,y0）旋转β到点P1，旋转后位置计算公式如下：
			//dx = x-x0;
			//dy = y-y0;
			//x1=cos(β)*dx-sin(β)*dy+x0;
			//y1=cos(β)*dy+sin(β)*dx+y0;
			double cosB = cosA;
			double sinB = -sinA;
			double dx = p.x - pos.x;
			double dy = p.y - pos.y;
			double x1 = cosB * dx - sinB * dy + pos.x;
			double y1 = cosB * dy + sinB * dx + pos.y;
			
			if(x1 >= pos.x && x1 <= (pos.x + width) && y1 <= (pos.y + height / 2) && pos. y >= pos.y - height / 2) {
				result.add(uo);
			}
		}
		
		return result;
	}
	
	/**
	 * 获取以pos为圆心，半径为radius的圆形区域内的UnitObject
	 * @param stageObj
	 * @param pos
	 * @param radius
	 * @return
	 */
	public List<UnitObject> getUnitObjsInCircle(StageObject stageObj, Vector2D pos, double radius) {
		List<UnitObject> result = new ArrayList<>();
		for(UnitObject uo : stageObj.getUnitObjs().values()) {
			//判断距离是否符合要求
			Vector2D p = uo.posNow;
			if(pos.distance(p) < radius) {
				result.add(uo);
			}
		}
		
		return result;
	}
	
	/**
	 * 获取某张地图上以center为圆心，朝向target，且半径为radius，角度为angle的扇形区域内的UnitObject，isFront用于选择是正面还是背面，true正面
	 * @param stageObj
	 * @param center
	 * @param target
	 * @param radius
	 * @param angle
	 * @param isFront
	 * @return
	 */
	public List<UnitObject> getUnitObjsInSector(StageObject stageObj, Vector2D center, Vector2D target, double radius, int angle, boolean isFront) {
		//如果是取背面，把目标点变为中心点的对称点
		if(!isFront) {
			double x = 2 * target.x - center.x;
			double y = 2 * target.y - center.y;
			target = new Vector2D(x, y);
		}
		
		List<UnitObject> result = new ArrayList<>();
		for(WorldObject wo : stageObj.getWorldObjs().values()) {
			if(!(wo instanceof UnitObject)) continue;
			//如果该UnitObject在扇形区域内
			if(isPosInSector(wo.posNow, center, target, radius, angle)) {
				result.add((UnitObject)wo);
			}
		}
		
		
		return result;
	}
	
	
	/**
	 * 判断点pos是否在以center为圆心，朝向target，且半径为radius，角度为angle的扇形区域内
	 * 余弦定理
	 * @param pos
	 * @param center
	 * @param target
	 * @param radius
	 * @param angle
	 * @return
	 */
	public boolean isPosInSector(Vector2D pos, Vector2D center, Vector2D target, double radius, int angle) {
		//如果点在圆外，直接false
		if(pos.distance(center) > radius) {
			return false;
		}
		//线段长
		double a = target.distance(pos);
		double b = pos.distance(center);
		double c = center.distance(target);
		//利用余弦定理计算夹角a的余弦值
		double cosA = (b * b + c * c - a * a) / (2 * b * c);
		//计算direct到line之间的角度
		double an = Math.acos(cosA);
		an = an * 180 / Math.PI;
		
		//用角度判断
		if((int)an <= angle / 2) {
			return true;
		}
		return false;		
	}
	
	/**
	 * 获得坐标的Z
	 * @param stageSn
	 * @param vec
	 * @return
	 */
	public static boolean getHeight(int stageSn, Vector3D vec) {
//		boolean result = PathFinding.posHeight(stageSn, vec);
		boolean result = HeightFinding.posHeight(stageSn, vec);
		return result;
	}
	/**
	 * 获得坐标的Z
	 * @param stageSn
	 * @param vec
	 * @return
	 */
	public static double getHeightY(int stageSn, Vector2D vec) {
//		Vector3D result = PathFinding.posHeight(stageSn, vec);
		Vector3D result = HeightFinding.posHeight(stageSn, vec);
		return result.y;
	}
	/**
	 * 获得坐标的Z
	 * @param stageSn
	 * @param vec
	 * @return
	 */
	public static Vector3D getHeight(int stageSn, Vector2D pos){
//		Vector3D result = PathFinding.posHeight(stageSn, pos);
		Vector3D result = HeightFinding.posHeight(stageSn, pos);
		return result;
	}
	/**
	 * 如果下一个目标点不能直接到达，那么取起点和终点直线上从起点能到达的最远的点
	 * @param stageSn
	 * @param vec
	 * @return
	 */
	public static Vector2D getRaycastDis(int stageSn, Vector2D posBegin, Vector2D posEnd, int flag) { 
		Vector3D endReal = PathFinding.raycast(stageSn, getHeight(stageSn,posBegin), getHeight(stageSn,posEnd), flag);
		return endReal.toVector2D();
	}
}
