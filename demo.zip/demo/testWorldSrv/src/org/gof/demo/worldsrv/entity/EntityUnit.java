package org.gof.demo.worldsrv.entity;

import org.gof.core.gen.entity.Column;
import org.gof.core.gen.entity.Entity;

@Entity(entityName="Unit", isSuper=true)
public enum EntityUnit {
	@Column(type=int.class, comment="当前等级")
	level,
	@Column(type=int.class, comment="攻击")
	atk,
	@Column(type=int.class, comment="防御")
	def,
	@Column(type=int.class, comment="当前生命")
	hpCur,
	@Column(type=int.class, comment="最大生命")
	hpMax,
	@Column(type=int.class, comment="当前法力")
	mpCur,
	@Column(type=int.class, comment="最大法力")
	mpMax,
	@Column(type=int.class, comment="命中")
	hit,
	@Column(type=int.class, comment="闪避")
	dodge,
	@Column(type=int.class, comment="暴击")
	crit,
	@Column(type=int.class, comment="坚韧")
	tough,
	@Column(type=float.class, comment="速度")
	speed,
	@Column(type=int.class, comment="战斗力")
	combat,
	@Column(type=String.class, comment="PVP模式")
	pvpMode,
	@Column(type=String.class, comment="PVP还原模式")
	pvpModeOriginal,
	@Column(type=int.class, comment="敌我模式下的队伍id,仅敌我模式下有效")
	pvpDiWoId,
	@Column(type=long.class, comment="上次更改PVP模式为和平模式的时间")
	pvpModeTimeToHePing,
	;

}