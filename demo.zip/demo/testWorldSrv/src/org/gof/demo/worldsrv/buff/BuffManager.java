package org.gof.demo.worldsrv.buff;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.gof.core.Port;
import org.gof.core.Record;
import org.gof.core.dbsrv.DBServiceProxy;
import org.gof.core.gen.callback.DistrCallback;
import org.gof.core.support.ManagerBase;
import org.gof.core.support.ManagerInject;
import org.gof.core.support.Param;
import org.gof.core.support.SysException;
import org.gof.core.support.Time;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.character.MonsterObject;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.config.ConfBuff;
import org.gof.demo.worldsrv.entity.Buff;
import org.gof.demo.worldsrv.entity.HumanPropPlus;
import org.gof.demo.worldsrv.fight.FightManager;
import org.gof.demo.worldsrv.fight.HpLostKey;
import org.gof.demo.worldsrv.human.HumanDataPersistance;
import org.gof.demo.worldsrv.human.HumanManager;
import org.gof.demo.worldsrv.human.UnitManager;
import org.gof.demo.worldsrv.monster.MonsterManager;
import org.gof.demo.worldsrv.msg.Msg.DBuff;
import org.gof.demo.worldsrv.msg.Msg.SCBuffAdd;
import org.gof.demo.worldsrv.msg.Msg.SCBuffDispel;
import org.gof.demo.worldsrv.msg.Msg.SCBuffUpdate;
import org.gof.demo.worldsrv.stage.StageManager;
import org.gof.demo.worldsrv.support.HumanInfoChange;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.PropCalcCommon;
import org.gof.demo.worldsrv.support.enumKey.PropExtKey;
import org.gof.demo.worldsrv.support.enumKey.PropKey;
import org.gof.demo.worldsrv.support.enumKey.UnitObjectStateKey;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;
import org.gof.demo.worldsrv.support.observer.Listener;

import com.google.protobuf.Message.Builder;

public class BuffManager extends ManagerBase {
	@ManagerInject
	private StageManager stageManager;
	@ManagerInject
	private UnitManager unitManager;
	@ManagerInject
	private HumanManager humanManager;
	@ManagerInject
	private MonsterManager monsterManager;
	@ManagerInject
	private FightManager fightManager;
	
	public static long INTERVAL_PULSE = 500;
	
	//走通用逻辑，可以在作用时累加，失效时直接减去的字段集合
	private List<String> propNormal;
		
	//不能走通用逻辑，不能累加的各种特殊字段集合
	private List<String> propSpecial;
	
	public BuffManager() {
		propNormal = PropExtKey.toList();
		propNormal.addAll(PropKey.toList());
		
		propSpecial = Utils.ofList(	PropExtKey.hpCur.name(),								//当前血量
												PropExtKey.hpCurPct.name(),						//当前血量系数
												PropExtKey.mpCur.name(),							//当前魔量
												PropExtKey.mpCurPct.name(),						//当前魔量系数
												PropExtKey.hpLoss.name(),							//伤害值
												PropExtKey.hpLossPct.name(),						//伤害系数
												UnitObjectStateKey.stun.name(), 					//眩晕
												UnitObjectStateKey.immobilize.name(), 		//定身
												UnitObjectStateKey.silence.name());				//沉默
	}
	
	/**
	 * 获取实例
	 * @return
	 */
	public static BuffManager getInstance() {
		return getInstance(BuffManager.class);
	}
	
	/**
	 * 为unitObj添加多个buff
	 * @param unitObj		目标
	 * @param idFire			Buff施放者Id
	 * @param buffSnList	buff集合
	 */
	public void add(UnitObject unitObj, long idFire, List<Integer> buffSnList) {
		for(Integer buffSn : buffSnList) {
			this.add(unitObj, idFire, buffSn);
		}
	}
	
	/**
	 * 为unitObj添加一个buff
	 * @param unitObj	目标
	 * @param idFire		Buff施放者Id
	 * @param buffSn	Buffsn
	 */
	public void add(UnitObject unitObj, long idFire, int buffSn) {
		ConfBuff conf = ConfBuff.get(buffSn);
		add(unitObj, idFire, buffSn, conf.propPlusJSON);
	}
	
	/**
	 * 添加一个动态buff，动态是指buff的属性效果值不是在配置表里固定的
	 * @param unitObj
	 * @param idFire
	 * @param buffSn
	 * @param propPlusJSON
	 */
	public void add(UnitObject unitObj, long idFire, int buffSn, String propPlusJSON) {
		ConfBuff conf = ConfBuff.get(buffSn);
		if(conf == null) {
			Log.temp.error("Buff配置不存在sn={},{}", buffSn, new SysException("Buff配置不存在sn=" + buffSn));
			return;
		}
		
		//根据互斥优先级，判断该单位身上是否需要添加该Buff		
		//查看身上是否有同类Buff
		Buff buffInSameType = unitObj.getBuffs().get(conf.type);
		if(buffInSameType != null) {
			//不可叠加
			if(conf.multiple == 0) {
				//根据优先级是否需要把旧的去掉
				if(conf.priority < ConfBuff.get(buffInSameType.getSn()).priority) {
					//新Buff优先级低，什么都不需要做
					return;
				} else {
					//移除旧的低优先级Buff
					remove(unitObj, buffInSameType);
				}
			} else if (conf.multiple == 1) {
				//时间叠加
				buffInSameType.setTimeEnd(buffInSameType.getTimeEnd() + conf.timeExist * Time.SEC);
				
				//buff时间更新了
				SCBuffUpdate.Builder buffUpdate = SCBuffUpdate.newBuilder();
				buffUpdate.setObjId(unitObj.id);
				buffUpdate.setBuff(createMsgBuff(buffInSameType));
				sendMsg(unitObj, buffUpdate, conf);
				
				return;
			}
		}
		
		//添加新Buff
		long curr = Port.getTime();
		Buff buff = new Buff();
		buff.setId(Port.applyId());
		buff.setType(conf.type);
		buff.setSn(buffSn);
		buff.setIdAffect(unitObj.id);
		buff.setIdFire(idFire);
		buff.setPropPlusDefaultJSON(propPlusJSON);
		//时间
		buff.setTimeEnd(curr + conf.timeExist * Time.SEC);
		buff.setTimePulse(curr + conf.timeDelay);
		
		//如果是同一类的Buff，则上下次更新时间保留
		if(buffInSameType != null) {
			buff.setTimePulse(buffInSameType.getTimePulse());
		}
		
		unitObj.getBuffs().put(buff.getType(), buff);
		
		//如果是人身上的buff，且该buff在人下线后需要保留，则持久化
		if(unitObj.isHumanObj() && conf.isReserveOffLine) {
			buff.persist();
		}
		
		//根据Buff的广播类型发送消息，增加新的Buff
		SCBuffAdd.Builder buffAdd = SCBuffAdd.newBuilder();
		buffAdd.setBuff(createMsgBuff(buff));
		buffAdd.setObjId(unitObj.id);
		//给前端发送消息
		sendMsg(unitObj, buffAdd, conf);
		
		//buff直接先作用一次
		if(unitObj instanceof HumanObject) {
			HumanObject humanObj= (HumanObject)unitObj;
			//监听玩家自身属性变化
			HumanInfoChange.listen(humanObj);
		}
		pulseBuff(unitObj, buff);
		
	}
	
	/**
	 * 通过sn获取unitObj身上的Buff
	 * @param unitObj
	 * @param type
	 * @return
	 */
	public Buff getBySn(UnitObject unitObj, int sn) {
		for(Buff buff : unitObj.getBuffs().values()) {
			if(buff.getSn() == sn) {
				return buff;
			}
		}
		return null;
	}
	
	/**
	 * 移除该单位身上的所有Buff
	 * @param unitObj
	 */
	public void removeAll(UnitObject unitObj) {
		List<Buff> removeList = new ArrayList<>();
		for(Buff buff : unitObj.getBuffs().values()) {
			removeList.add(buff);
		}
		//删除Buff
		for(Buff buff : removeList) {
			remove(unitObj, buff);
		}
	}
	
	/**
	 * 移除buff效果
	 * @param unitObj
	 * @param buff
	 */
	public void remove(UnitObject unitObj, Buff buff) {
		//先把buff的影响修正
		PropCalcCommon propMinus = new PropCalcCommon(buff.getPropPlusJSON());
		PropCalcCommon prop;
		
		if(unitObj.isHumanObj()) {
			HumanObject humanObj = (HumanObject)unitObj;
			HumanPropPlus pp = humanObj.dataPers.humanPropPlus;
			
			//监听玩家自身属性变化
			HumanInfoChange.listen(humanObj);
			
			prop = new PropCalcCommon(pp.getBuff());
			prop.minus(propMinus);
			pp.setBuff(prop.toJSONStr());
			
			//重新计算玩家属性
			humanManager.propCalc(humanObj);
		} else {
			MonsterObject monsterObj = (MonsterObject)unitObj;
			prop = monsterObj.buffPropPlus;
			prop.minus(propMinus);
			
			//重新计算怪物属性
			monsterManager.propCalc(monsterObj);
		}	
		//从单元身上移走
		unitObj.getBuffs().remove(buff.getType());
		buff.remove();
		
		//群发消息，Buff消失
		SCBuffDispel.Builder buffDispel = SCBuffDispel.newBuilder();
		buffDispel.setObjId(unitObj.id);
		buffDispel.setSn(buff.getSn());
		ConfBuff confBuff = ConfBuff.get(buff.getSn());
		sendMsg(unitObj, buffDispel, confBuff);
		
	}
	
	/**
	 * 生成包含Buff基本信息的消息
	 * @param buff
	 * @return
	 */
	public DBuff createMsgBuff(Buff buff) {
		ConfBuff conf = ConfBuff.get(buff.getSn());
		DBuff.Builder dBuff = DBuff.newBuilder();
		dBuff.setSn(buff.getSn());
		dBuff.setTimeLeft((int)((conf.timeExistOnline * Time.SEC - buff.getTimeExistOnline())));
		
		return dBuff.build();
	}
	
	/**
	 * 单独更新一个buff
	 * @param unitObj
	 * @param buff
	 */
	public void pulseBuff(UnitObject unitObj, Buff buff) {
		ConfBuff conf = ConfBuff.get(buff.getSn());
		long curr = Port.getTime();
		buff.setTimeExistOnline(buff.getTimeExistOnline() + INTERVAL_PULSE);
		//如果buff下一次生效时间还没到
		if(curr < buff.getTimePulse()) return;
		
		//生效
		affect(unitObj, buff, conf);
		
	}
	
	/**
	 * 更新unitObj身上的buff状态
	 * @param unitObj
	 */
	public void pulse(UnitObject unitObj) {
		Collection<Buff> buffs = unitObj.getBuffs().values();
		if(buffs.size() > 0 && unitObj instanceof HumanObject) {
			HumanObject humanObj= (HumanObject)unitObj;
			//监听玩家自身属性变化
			HumanInfoChange.listen(humanObj);
		}
		//在这里遍历buff
		List<Buff> removeList = new ArrayList<>();
		for(Buff buff : buffs) {
			ConfBuff conf = ConfBuff.get(buff.getSn());
			long curr = Port.getTime();
			//生效过的Buff，如果作用时间或者存在时间到了，则删除
			//最大存在时间如果不配置，为0，则表示这个buff除非累计时间到了，不然可以一直存在
			//最大存在时间如果配置为0，则表示这个buff的在线作用时间不用管，除非最大时间到了
			//如果两个都为0，那么这个buff就一直存在着
			if(buff.isAffected() && ((conf.timeExist > 0 && buff.getTimeExistOnline() >= conf.timeExistOnline * Time.SEC) || (conf.timeExistOnline > 0 && buff.getTimeEnd() < curr))) {
				removeList.add(buff);
				continue;
			}
			//如果两个时间都为0，就是配错了
			if(buff.isAffected() && conf.timeExist <= 0 && conf.timeExistOnline <= 0) {
				removeList.add(buff);
				continue;
			}
			
			//该buff具体的更新操作
			pulseBuff(unitObj, buff);
		}
		
		//移除需要删除的buff 
		for(Buff buff : removeList) {
			remove(unitObj, buff);
		}
	}
	
	/**
	 * 人身上的Buff作用一次
	 * 要统计属性，还有一些作用一次的，特殊处理：hpCur,mpCur,coin,exp,conk(昏迷),freeze(定身)
	 * @param humanObj
	 * @param positive
	 */
	public void affect(UnitObject unitObj, Buff buff, ConfBuff confBuff) {
		PropCalcCommon propDefault = new PropCalcCommon(buff.getPropPlusDefaultJSON());
		//特殊字段，直接增加某些值的，比如说加血，加魔，时间到了不会减去
		for(String key : propSpecial) {
			double value = propDefault.getDouble(key);
			if(value == 0) continue;
			
			UnitObject unitFire = unitObj.stageObj.getUnitObjs().get(buff.getIdFire());
			affectPropSpecial(unitObj, unitFire, key, value);
		}
		
		//普通字段，作用时加上，失效时要减掉的字段
		//组织需要加成的属性
		PropCalcCommon propPlus = new PropCalcCommon();
		for(String key : propNormal) {
			double value = propDefault.getDouble(key);
			if(value == 0.0) continue;
			
			propPlus.plus(key, value);
		}
		
		//把加成效果给真正加上
		PropCalcCommon prop;
		if(unitObj.isHumanObj()) {
			HumanObject humanObj = (HumanObject) unitObj;
			HumanPropPlus pp = humanObj.dataPers.humanPropPlus;
			
			prop = new PropCalcCommon(pp.getBuff());
			prop.plus(propPlus);
			
			pp.setBuff(prop.toJSONStr());
			
			//重新计算玩家属性
			humanManager.propCalc(humanObj);
		} else {
			MonsterObject monsterObj = (MonsterObject) unitObj;
			prop = monsterObj.buffPropPlus;
			prop.plus(propPlus);
			
			//重新计算怪物属性
			monsterManager.propCalc(monsterObj);
		}
		//重新计算并保存buff的加成效果
		PropCalcCommon propBuff = new PropCalcCommon(buff.getPropPlusJSON());
		propBuff.plus(propPlus);
		buff.setPropPlusJSON(propBuff.toJSONStr());
		
		if(!buff.isAffected()) {
			buff.setAffected(true);
		}
	}
	
	
	/**
	 * buff作用时比较特殊的处理逻辑，包括：hpCur,hpCurPct,mpCur,mpCurPct,damageGold,damagePoison,damageCurse,stun(昏迷),immobilize(定身),silence(沉默)
	 * @param humanObj
	 * @param prop
	 * @param value
	 */
	public void affectPropSpecial(UnitObject unitObj, UnitObject unitFire, String prop, double value) {
		//unitFire可能为null!!!!!!!
		int valueInt = (int)value;
		switch(prop) {
			//血量hpCur
			case "hpCur":
				if(valueInt < 0) {
					unitManager.reduceHp(unitObj, Math.abs(valueInt), unitFire, new Param("hpLostKey", HpLostKey.BUFF));
				} else {
					unitManager.addHp(unitObj, HpLostKey.BUFF, Math.abs(valueInt), unitFire);
				}
				break;
			case "hpCurPct":
				valueInt = (int)(unitObj.getUnit().getHpMax() * value);
				if(valueInt < 0) {
					unitManager.reduceHp(unitObj, (int)Math.abs(valueInt), unitFire, new Param("hpLostKey", HpLostKey.BUFF));
				} else {
					unitManager.addHp(unitObj, HpLostKey.BUFF, Math.abs(valueInt), unitFire);
				}
				break;
			//魔量mpCur
			case "mpCur":
				break;
			case "mpCurPct":
				break;
			//伤害值
			case "hoLoss":
				if(valueInt <= 0) break;
				unitManager.reduceHp(unitObj, valueInt, unitFire, new Param("hpLostKey", HpLostKey.BUFF));
				break;
			//伤害系数
			case "hpLossPct":
				if(value <= 0) break;
				valueInt = (int)(unitObj.getUnit().getHpMax() * value);
				unitManager.reduceHp(unitObj, valueInt, unitFire, new Param("hpLostKey", HpLostKey.BUFF));
			//眩晕
			case "stun":
				unitObj.toState(UnitObjectStateKey.stun, valueInt);
				break;
			//定身
			case "immobilize":
				unitObj.toState(UnitObjectStateKey.immobilize, valueInt);
				break;
			//沉默
			case "silence":
				unitObj.toState(UnitObjectStateKey.silence, valueInt);
				break;
			default:
				break;
		}
	}
	
	/**
	 * 根据不同情况，给前端发送消息
	 * @param unitObject
	 * @param builder
	 */
	public void sendMsg(UnitObject unitObj, Builder builder, ConfBuff confBuff) {
		switch(confBuff.msgShowType) {
		//不给前端发送消息
		case 0:
			break;
		//只给自己发
		case 1:
			if(unitObj.isHumanObj()) {
				HumanObject humanObj = (HumanObject)unitObj;
				humanObj.sendMsg(builder);
			}
			break;
		//群发广播
		case 2:
			stageManager.sendMsgToArea(builder, unitObj.stageObj, unitObj.posNow);
			break;
		}
	}
	
	
	/**
	 * 战斗单元死亡，检测是否有需要移出相应的buff
	 * @param param
	 */
	@Listener(EventKey.UNIT_BE_KILLED)
	public void dispelByUnitBeKilled(Param param) {
		UnitObject unitObj = param.get("unitObj");
		// 检测身上是否有buff在单元死亡后不保留
		List<Buff> removeList = new ArrayList<>();
		for(Buff buff : unitObj.getBuffs().values()) {
			ConfBuff confBuff = ConfBuff.get(buff.getSn());
			if(confBuff.isReserveDied)
				continue;
			removeList.add(buff);
		}
		// 移除需要移除的buff
		for(Buff buff : removeList) {
			remove(unitObj, buff);
		}
	}
	
	/**
	 * 驱散unitobj上能被dispelId驱散的buff
	 * @param unitObj
	 * @param dispelId
	 */
	public void dispel(UnitObject unitObj, String dispelSn) {
		List<Buff> dispelList = new ArrayList<>();
		//查找可以被驱散的Buff
		for(Buff buff : unitObj.getBuffs().values()) {
			ConfBuff confBuff = ConfBuff.get(buff.getSn());
			if(dispelSn.equals(confBuff.dispelSn)) {
				dispelList.add(buff);
			}
		}
		//驱散Buff
		for(Buff buff : dispelList) {
			remove(unitObj, buff);
		}
	}
	
	/**
	 * 玩家上线是重新计算buff加成效果
	 * @param param
	 */
	@Listener(EventKey.HUMAN_LOGIN)
	public void onHumanLogin(Param param) {
		HumanObject humanObj = param.get("humanObj");
		HumanPropPlus pp = humanObj.dataPers.humanPropPlus;
		// 先清理旧的效果，再重新计算需要保存的Buff的效果
		pp.setBuff("{}");
		PropCalcCommon buffPropPlus = new PropCalcCommon();
		for(Buff buff : humanObj.getBuffs().values()) {
			buffPropPlus.plus(buff.getPropPlusJSON());
		}
		pp.setBuff(buffPropPlus.toJSONStr());
		
		humanManager.propCalc(humanObj);
	}
	
	/**
	 * 玩家登录游戏后 加载玩家的数据
	 * @param humanObj
	 */
	@Listener(EventKey.HUMAN_DATA_LOAD_BEGIN)
	public void loadHumanData(Param param) {
		HumanObject humanObj = param.get();
		
		//准备环境
		DBServiceProxy prx = DBServiceProxy.newInstance();
		prx.findBy(Buff.tableName, "idAffect", humanObj.id);
		prx.listenResult(this, BuffManagerCallback._result_loadHumanData, "humanObj", humanObj);
		
		//一次加载事件开始
		Event.fire(EventKey.HUMAN_DATA_LOAD_BEGIN_ONE, humanObj);
	}
	
	/**
	 * 玩家登录游戏后 加载玩家的数据返回
	 * @param timeout
	 * @param results
	 * @param context
	 */
	@DistrCallback
	public void _result_loadHumanData(Param results, Param context) {
		//玩家
		HumanObject humanObj = context.get("humanObj");
		HumanDataPersistance data = humanObj.dataPers;
		
		//处理返回数据
		Map<Integer, Buff> buffs = data.buffs;
		for (Record r : results.<List<Record>> get()) {
			// 缓存数据
			Buff buff = new Buff(r);
			buffs.put(buff.getType(), buff);
		}
		
		//一次加载事件结束
		Event.fire(EventKey.HUMAN_DATA_LOAD_FINISH_ONE, humanObj);
	}
}
