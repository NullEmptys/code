package org.gof.demo.worldsrv.test;

import java.util.List;

import org.gof.core.gen.proxy.DistrClass;
import org.gof.core.gen.proxy.DistrMethod;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.common.GamePort;
import org.gof.demo.worldsrv.common.GameServiceBase;
import org.gof.demo.worldsrv.human.HumanManager;
import org.gof.demo.worldsrv.msg.Msg.DBackPos;
import org.gof.demo.worldsrv.support.D;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.Vector2D;

import com.google.protobuf.Message;

/**
 * TestService 测试的Service类
 * @author Change
 *
 */
@DistrClass(
		servId = D.SERV_TEST
)
public class TestService extends GameServiceBase {	
	private TestManager testManager = TestManager.getInstance();
	/**
	 * 初始化数据
	 * @return
	 */
	protected void init() {
		
	}
	
	public TestService(GamePort port) {
		super(port);
	}

	@DistrMethod
	public void csTestService(int msgId) {
		
		Log.game.info("TestService has received CSTest, CODE is [{}]", msgId);
		testManager.reLoadConf();
		port.returns("AAA");
	}	
}
