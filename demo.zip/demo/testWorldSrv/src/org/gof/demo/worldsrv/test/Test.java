package org.gof.demo.worldsrv.test;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


public final class Test {		
	public static long i = 0L;
	public static long j = 0L;
	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Test obj = new Test();
		Method mth = Test.class.getMethod("invoke", double.class, double.class, double.class, double.class, double.class, double.class);
		
		long start = System.currentTimeMillis();
		double value0 = 0D;
		//直接调用
		for(i = 0; i < 10000000l; i++) {
			value0 += obj.invoke( i+0.1, i+0.2, i+0.3, i+0.4, i+0.5, i+0.6);
		}
		System.out.println(System.currentTimeMillis() - start);
				
		start = System.currentTimeMillis();
		double value1 = 0D;
		//反射执行
		for( j = 0; j < 10000000l; j++) {
			value1 = (Double)mth.invoke(obj, j+0.1, j+0.2, j+0.3, j+0.4, j+0.5, j+0.6);
		}
		System.out.println(System.currentTimeMillis() - start);
		System.out.println(value1 + value0);
	}
	
	
	public double invoke(double a, double b, double c, double d, double e, double f) {
		double result = 0;
		result += Math.sqrt(a);
		result += Math.sqrt(b);
		result += Math.sqrt(c);
		result += Math.sqrt(d);
		result += Math.sqrt(e);
		result += Math.sqrt(f);
		result += Math.sqrt(a);
		result += Math.sqrt(b);
		result += Math.sqrt(c);
		result += Math.sqrt(d);
		result += Math.sqrt(e);
		result += Math.sqrt(f);
		result += Math.sqrt(a);
		result += Math.sqrt(b);
		result += Math.sqrt(c);
		result += Math.sqrt(d);
		result += Math.sqrt(e);
		result += Math.sqrt(f);
		return result;
	}
}
