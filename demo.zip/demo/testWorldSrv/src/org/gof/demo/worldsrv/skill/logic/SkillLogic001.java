package org.gof.demo.worldsrv.skill.logic;

import org.gof.core.support.Param;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.config.ConfSkillEffect;
import org.gof.demo.worldsrv.fight.FightManager;
import org.gof.demo.worldsrv.fight.HpLostKey;
import org.gof.demo.worldsrv.human.UnitManager;
import org.gof.demo.worldsrv.skill.SkillCommon;
import org.gof.demo.worldsrv.skill.SkillEventKey;
import org.gof.demo.worldsrv.skill.SkillParamVO;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;


/**
 * 技能效果：直接伤害
 * @author new
 *
 */
public class SkillLogic001 extends AbstractSkillLogicActive{
	//范围加上
	public double pctCommon;		//普攻百分比
	public int addCommon;		//普攻附加纯数值
	
	@Override
	public void init(SkillCommon skillCommon, ConfSkillEffect conf) {
		super.init(skillCommon, conf);
		pctCommon = Utils.doubleValue(conf.param1);
		addCommon = Utils.intValue(conf.param2);
	}

	@Override
	public int calcHurt(UnitObject unitObjDef) {
		UnitObject unitObjAtk = skill.unitObj;
		int hpLost = 0;
		
		//判断计算伤害前是否有被动技能触发（攻击忽视对方防御）
		SkillParamVO vo = new SkillParamVO();
		Event.fire(EventKey.SKILL_PASSIVE_CHECK, 
							"unitAtk", skill.unitObj, 
							"unitDef", unitObjDef, 
							"skillEventKey", SkillEventKey.EVENT_ON_BEFORE_CALC_HURT, 
							"isPartner", false, 
							"vo", vo);
		
		//忽视防御比例
		double ignoreDefPct = vo.ignoreDefPct;
//		Log.temp.info("{} : {}",pctCommon, conf.effectSn);
		//普通伤害
		hpLost += FightManager.getInstance().calcPropHitIgnoreDef(unitObjAtk, unitObjDef, ignoreDefPct) * pctCommon;
		hpLost += addCommon;
		
		
		return hpLost;
	}
	
	@Override
	public void doSkillEffectToTar(UnitObject unitObjDef) {
		int hpLost = calcHpLost(unitObjDef, true);
	
		//判断扣血前攻击方是否有被动技能触发（攻击伤害加成或受攻击伤害减免）
		SkillParamVO vo = new SkillParamVO();
		Event.fire(EventKey.SKILL_PASSIVE_CHECK, 
							"unitAtk", skill.unitObj, 
							"unitDef", unitObjDef, 
							"skillEventKey", SkillEventKey.EVENT_ON_BEFORE_HPLOST, 
							"isPartner", false, 
							"vo", vo);
		
		//扣血 = 伤害 * （1 + 增伤百分比 - 减伤百分比） + 增伤纯数值
		hpLost = (int)(hpLost * (1 + vo.hurtAddPct - vo.hurtAvoidPct) + vo.hurtAdd);
		
		//判断是否命中
		boolean isHit = skill.confSkill.hit ? true : FightManager.getInstance().isHit(skill.unitObj, unitObjDef);
		
		//命中
		if(isHit) {
			boolean isCrit = FightManager.getInstance().isCrit(skill.unitObj, unitObjDef);
			if(isCrit) {
				hpLost *= 2;
			}
			
			//扣血
			UnitManager.getInstance().reduceHp(unitObjDef, hpLost, skill.unitObj, new Param("skill", skill, "isHit", isHit, "isCrit", isCrit, "hpLostKey", HpLostKey.SKILL));
		} else {
			//没有命中
			hpLost = 0;
			
			//扣血
			UnitManager.getInstance().reduceHp(unitObjDef, hpLost, skill.unitObj, new Param("skill", skill, "isHit", isHit, "hpLostKey", HpLostKey.SKILL));
		}
		
		//技能中记录本次伤害
		if(hpLost > 0) {
			skill.addTemp("hurt", hpLost);
			//判断扣血后是否有被动技能触发
			Event.fire(EventKey.SKILL_PASSIVE_CHECK, "unitAtk", skill.unitObj, 
					"unitDef", unitObjDef, 
					"skillEventKey", SkillEventKey.EVENT_ON_AFT_HPLOST, 
					"isPartner", false, 
					"vo", new SkillParamVO());
		}
	}

}
