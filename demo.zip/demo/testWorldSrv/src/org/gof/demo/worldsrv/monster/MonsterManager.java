package org.gof.demo.worldsrv.monster;

import java.util.ArrayList;
import java.util.List;

import org.gof.core.support.ManagerInject;
import org.gof.demo.worldsrv.character.MonsterObject;
import org.gof.demo.worldsrv.entity.Monster;
import org.gof.demo.worldsrv.stage.StageManager;
import org.gof.demo.worldsrv.stage.StageObject;
import org.gof.demo.worldsrv.support.PropCalcCommon;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.demo.worldsrv.support.enumKey.PropExtKey;
import org.gof.demo.worldsrv.support.enumKey.PropKey;

public class MonsterManager extends org.gof.core.support.ManagerBase {
	
	@ManagerInject private StageManager stageManager;
	/**
	 * 获取实例
	 * @return
	 */
	public static MonsterManager getInstance() {
		return getInstance(MonsterManager.class);
	}
	
	/**
	 * 生成怪物
	 * @param stageObj
	 * @param sn		怪物配置SN
	 * @param pos		坐标点	(配置)
	 * @param radius	中心点	(地图XML)
	 * @param num		数量		(配置)
	 * @param active		是否激活  false 站着不动，不能被攻击和攻击
	 * @param face			朝向 角度，0-360度  -1朝着人
	 * @return
	 */
	public List<MonsterObject> create(StageObject stageObj, int sn, Vector2D pos, double radius, int num, boolean active) {
		List<MonsterObject> result = new ArrayList<>();
		if(num <= 0 ) {
			return result;
		}
		for(int i = 0; i < num ; i++) {
			MonsterObject monsterObj = new MonsterObject(stageObj, sn, active);
			monsterObj.posBegin = stageManager.randomPosInCircle(pos, 0, radius);
			
			monsterObj.startup();
			result.add(monsterObj);
		}
		return result;
	}
	
	public void propCalc(MonsterObject monsterObj) {
		Monster monster = (Monster) monsterObj.getUnit();
		//各模块加成属性
		PropCalcCommon propPlus = getPropPlus(monsterObj);
		
		//记录属性计算前的血/魔
		int hpMaxOld = monster.getHpMax();
		int mpMaxOld = monster.getMpMax();
		
		//速度(如果在运镖状态，则不重新计算速度)
		double speed = (monsterObj.conf.speed + propPlus.getInt(PropKey.speed)) * (1 + propPlus.getDouble(PropExtKey.speedPct));
		monster.setSpeed((int)speed);
		
		//计算怪物二级属性
		int atk = monster.getAtk() + propPlus.getInt(PropKey.atk);							//攻击=（力量*力量攻击系数 + 各模块加成）* （1 + 加成系数）
			atk = (int)(atk * (1 + propPlus.getDouble(PropExtKey.atkPct)));
		int def = monster.getDef() + propPlus.getInt(PropKey.def);							//防御=（敏捷*敏捷防御系数 + 各模块加成）* （1 + 加成系数）
			def = (int)(def * (1 + propPlus.getDouble(PropExtKey.defPct)));
		int hpMax = monster.getHpMax() + propPlus.getInt(PropKey.hpMax);			//生命=（体力*体力生命系数 + 各模块加成）* （1 + 加成系数）
			hpMax = (int)(hpMax * (1 + propPlus.getDouble(PropExtKey.hpMaxPct)));
		int mpMax = monster.getMpMax() + propPlus.getInt(PropKey.mpMax);		//法力=（体力*体力法力系数 + 各模块加成）* （1 + 加成系数）
			mpMax = (int)(mpMax * (1 + propPlus.getDouble(PropExtKey.mpMaxPct)));
		
		int hit = monster.getHit() + propPlus.getInt(PropKey.hit);							//命中=（敏捷*敏捷命中系数 + 各模块加成）
		int dodge = monster.getDodge() + propPlus.getInt(PropKey.dodge);			//闪避=（智力*智力闪避系数 + 各模块加成）
		int crit = monster.getCrit() + propPlus.getInt(PropKey.crit);							//暴击=（智力*智力暴击系数 + 各模块加成）
		int tough = monster.getTough() + propPlus.getInt(PropKey.tough);				//坚韧=（力量*力量坚韧系数 + 各模块加成）
		
		//设置上新的二级属性
		monster.setAtk(atk);				
		monster.setDef(def);				
		monster.setHpMax(hpMax);					
		monster.setMpMax(mpMax);					
		monster.setHit(hit);				
		monster.setDodge(dodge);			
		monster.setCrit(crit);				
		monster.setTough(tough);			
		
		
		//计算最终的 血/魔
		double hpNew = monster.getHpCur() * (1.0 * monster.getHpMax() / hpMaxOld);
		double mpNew = monster.getMpCur() * (1.0 * monster.getMpMax() / mpMaxOld);
		
		monster.setHpCur((int)hpNew);
		monster.setMpCur((int)mpNew);
		
		//广播怪物属性变化消息
		stageManager.sendMsgToArea(monsterObj.createMsgUpdate(), monsterObj.stageObj, monsterObj.posNow);
	}
	
	private PropCalcCommon getPropPlus(MonsterObject monsterObj) {
		PropCalcCommon data = new PropCalcCommon();
		
		//buff带来的加成
		data.plus(monsterObj.buffPropPlus);
		
		return data;
	}
}
