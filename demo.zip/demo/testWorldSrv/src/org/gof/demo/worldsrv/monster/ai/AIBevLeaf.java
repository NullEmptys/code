package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;
import org.gof.demo.worldsrv.support.enumKey.EnumBevNodeType;

public abstract class AIBevLeaf {
    protected String name;
    //the layer node in tree , the root node is 0 layer.
    protected int layerIndex = 0;
    protected EnumBevNodeType nodeType;
    
    protected boolean nonLogic = false;
    protected AI ai;
    abstract public boolean execute(Param param);
    
    public boolean returnLogic(boolean result) {
    	if(nonLogic) {
			result = !result;
		}
    	return result;
    }
}
