package org.gof.demo.worldsrv.character;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.gof.core.Port;
import org.gof.core.support.Param;
import org.gof.core.support.TickTimer;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.config.ConfDot;
import org.gof.demo.worldsrv.fight.FightManager;
import org.gof.demo.worldsrv.fight.HpLostKey;
import org.gof.demo.worldsrv.human.UnitManager;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.DHpChgOnce;
import org.gof.demo.worldsrv.msg.Msg.DHpChgTar;
import org.gof.demo.worldsrv.msg.Msg.DStageDot;
import org.gof.demo.worldsrv.msg.Msg.DStageObject;
import org.gof.demo.worldsrv.msg.Msg.EWorldObjectType;
import org.gof.demo.worldsrv.msg.Msg.SCFightDotHpChg;
import org.gof.demo.worldsrv.msg.Msg.SCFightHpChg;
import org.gof.demo.worldsrv.stage.StageManager;
import org.gof.demo.worldsrv.stage.StageObject;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

/**
 * 持续伤害dot
 */
public class DotObject extends TemporaryObject {
	private StageManager stageManager = StageManager.getInstance();
	
	private UnitObject unitObjFire;		//释放dot的unitObj
	private UnitObject unitObjTar;		//初始作用目标
	private ConfDot confDot;
	public List<Long> trrigerList = new ArrayList<>();	//触发事件序列
//	int trrigerIndex = 0;										//触发计数器和trrigerList对应
	private long timeEnd;				//结束时间
	private int scopeType;				//范围类型
	private double scopeParam1;		//范围参数1
	private TickTimer updateTimer;
	public SCFightHpChg.Builder hpChangeMsg = null;				//技能伤害血量包
	
	private long delayPulse;
	
	public DotObject(StageObject stage, ConfDot confDot, UnitObject unitObjFire, UnitObject unitObjTar, Vector2D vec) {
		super(stage);
		long curr = Port.getTime();
		this.unitObjFire = unitObjFire;
		this.unitObjTar = unitObjTar;
		this.confDot = confDot;
		this.timeEnd = curr + confDot.totalTime + this.delayPulse;
		this.posNow = vec;
		this.scopeType = confDot.scopeType;
		this.scopeParam1 = confDot.scopeParam1;
		this.delayPulse = confDot.timeDelay;
		
		JSONArray ja = JSON.parseArray(confDot.interval);
		for(Object obj : ja) {
			//查找效果配置表
			trrigerList.add(Utils.intValue(obj.toString()) + this.delayPulse);
		}
		this.updateTimer = new TickTimer(trrigerList.remove(0));
		
		
	}
	
	
	/**
	 * 初始化，如果给释放者加buff
	 */
	public void init() {
		
	}
	
	/**
	 * 将本次造成掉血消息构造进用户造成掉血信息
	 * @param humanObject
	 * @param id
	 * @param dhpChgOnce
	 */
	public void addSkillHpChg(long id, DHpChgOnce.Builder dhpChgOnce) {
		if(hpChangeMsg == null) {
			hpChangeMsg = SCFightHpChg.newBuilder();
		}
		
		boolean flag = false;
		DHpChgTar.Builder dhpTar = DHpChgTar.newBuilder(); 
		dhpTar.setId(id);
		for(DHpChgTar.Builder tmp : hpChangeMsg.getDhpChgTarBuilderList()) {
			if(tmp.getId() != id) continue;
			dhpTar = tmp;
			flag = true;
		}
		
		dhpTar.addDhpChgOnce(dhpChgOnce);
		
		if(!flag) {
			hpChangeMsg.addDhpChgTar(dhpTar);
		}
	}
	
	@Override
	public void pulse() {
		long curr = Port.getTime();
		
//		if(inWorld == false && delayPulse > timeEnd) {
//			init();
//		}
		
		if(curr > timeEnd) {
			//去除清理功能
			this.stageLeave();
			return ;
		}
		
		if(!updateTimer.isPeriod(Port.getTime())) {
			return ;
		} 
		
		if(trrigerList.size() > 0) {
			updateTimer.start(trrigerList.remove(0));
		}
		
		//如果是跟随人移动的dot，重置dot位置
		if(confDot.moveType == 1) {
			if(confDot.targetSelf) {
				if(unitObjFire == null) {
					this.stageLeave();
					return ;
				}
				
				this.posNow = unitObjFire.posNow;
			} else {
				if(unitObjTar == null) {
					this.stageLeave();
					return ;
				}
				
				this.posNow = unitObjTar.posNow;
			}
		}
		
		//dot作用
		doDot();
		
		//循环本地图玩家,广播血包
		if(hpChangeMsg != null) {
			SCFightDotHpChg.Builder msg = SCFightDotHpChg.newBuilder();
			msg.setDotSn(confDot.sn);
			msg.setHpChg(hpChangeMsg);
			stageManager.sendMsgToArea(msg, stageObj, posNow);
			hpChangeMsg = null;
		}
	}
	
	/**
	 * 获取dot范围内的有效目标
	 * @return
	 */
	public List<UnitObject> getTars() {
		List<UnitObject> tars = new ArrayList<>();
		
		//通过范围筛选目标
		//全地图
		if(scopeType == 1) {
			for(UnitObject unitObj : stageObj.getUnitObjs().values()) {
				tars.add(unitObj);
			}
		} else if(scopeType == 2) {
			//圆形取坐标 圆形内所有的unitObj
			List<UnitObject> unitAll = stageManager.getUnitObjsInCircle(stageObj, posNow, scopeParam1);
			tars.addAll(unitAll);
		} 
		
		//排除一些不符合条件的目标
		Iterator<UnitObject> iter = tars.iterator();
		while(iter.hasNext()) {
			UnitObject unitObjTmp = iter.next();
			//删除inworld = false的unitObj
			if(!unitObjTmp.isInWorld() || unitObjTmp.id == unitObjFire.id) {
				iter.remove();
			}
			
			
			//如果目标是怪物，怪物没激活，则排除,如果是怪物放技能，目标不能有怪物
			if(unitObjTmp.isMonsterObj()) {
				if(!((MonsterObject)unitObjTmp).active) {
					iter.remove();
					continue;
				}
			}
		}
		
		return tars;
	}
	
	/**
	 * dot作用
	 */
	public void doDot() {
		//获取dot范围内的有效目标
		List<UnitObject> tars = getTars();
		
		//遍历dot作用的左右玩家
		for(UnitObject tar : tars) {
			int hpLost = 0;
			
			//普通伤害
			if(unitObjFire != null) {
				hpLost += FightManager.getInstance().calcPropHitIgnoreDef(unitObjFire, tar, 0) * confDot.procCommon;
				hpLost += confDot.addCommon;
				
			}
			
			//dot有伤害
			if(hpLost > 0) {
				//判断是否命中
				if(unitObjFire != null) {
					boolean isHit = FightManager.getInstance().isHit(unitObjFire, tar);
					
					//命中
					if(isHit) {
						boolean isCrit = FightManager.getInstance().isCrit(unitObjFire, tar);
						if(isCrit) {
						}
						
						//扣血
						UnitManager.getInstance().reduceHp(tar, hpLost, unitObjFire, new Param("hpLostKey", HpLostKey.DOT, "dot", this, "isHit", isHit, "isCrit", isCrit));
					} else {
						//没有命中
						hpLost = 0;
						
						//扣血
						UnitManager.getInstance().reduceHp(tar, hpLost, unitObjFire, new Param("hpLostKey", HpLostKey.DOT, "dot", this, "isHit", isHit));
					}
				} else {
					//扣血
					UnitManager.getInstance().reduceHp(tar, hpLost, null, new Param("hpLostKey", HpLostKey.DOT, "dot", this));
				}
				
				//发送怪物或者人受攻击事件
				if(!tar.isDie()) {
					Event.fire(EventKey.UNIT_BE_ATTACKED, "unitObj", tar);
					if(tar.isHumanObj()) {
						Event.fire(EventKey.HUMAN_BE_ATTACKED, "attacker", unitObjFire, "humanObj", tar);
					} else if(tar.isMonsterObj()) {
						Event.fire(EventKey.MONSTER_BE_ATTACKED, "attacker", unitObjFire, "monsterObj", tar);
					}
				}
			}
			
		}
	}

	@Override
	public Msg.DStageObject.Builder createMsg() {
		//玩家信息单元
		DStageDot.Builder dotInfo = DStageDot.newBuilder();
		dotInfo.setDotSn(this.confDot.sn);
		dotInfo.setPos(this.posNow.toMsg());
		dotInfo.setScopeType(this.scopeType);
		dotInfo.setScopeParam1((int) this.scopeParam1);
		dotInfo.setScopeParam2(360);
		
		DStageObject.Builder objInfo = DStageObject.newBuilder();
		objInfo.setObjId(id);
		objInfo.setType(EWorldObjectType.DOT);
		objInfo.setName(name);
		objInfo.setModelSn(modelSn);
		objInfo.setPos(this.posNow.toMsg());
		objInfo.setDot(dotInfo);
		
		return objInfo;
	}
}
