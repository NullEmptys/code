package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;
import org.gof.demo.worldsrv.character.MonsterObject;

public class AIBevCondState extends AIBevLeaf{

	AIBehaviorKey key = AIBehaviorKey.NORMAL;
	public AIBevCondState(AI ai, AIBehaviorKey key, boolean logic) {
		this.ai = ai;
		nonLogic = logic;
		this.key = key;
	}
	public AIBevCondState(AI ai, AIBehaviorKey key) {
		this.ai = ai;
		this.key = key;
	}
	@Override
	public boolean execute(Param param) {
	boolean result = false;
		
		if(ai.behavior == key) {
			return returnLogic(true);
		}
		
		return returnLogic(result);
	}

}
