package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;

public class AIBevActionToState extends AIBevLeaf {

	AIBehaviorKey key = AIBehaviorKey.NORMAL;
	public AIBevActionToState(AI ai, AIBehaviorKey key) {
		this.ai = ai;
		this.key = key;
	}

	@Override
	public boolean execute(Param param) {
		ai.behavior = key;
		return true;
	}
}
