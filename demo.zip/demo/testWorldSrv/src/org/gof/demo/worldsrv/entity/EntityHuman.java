package org.gof.demo.worldsrv.entity;

import org.gof.core.gen.entity.Column;
import org.gof.core.gen.entity.Entity;

@Entity(entityName="Human", tableName="demo_human", superEntity=EntityUnit.class)
public enum EntityHuman {
	@Column(type=int.class, comment="服务器编号")
	serverId,
	@Column(type=String.class, comment="账号", index=true)
	account,
	@Column(type=String.class, comment="姓名", index=true)
	name,
	@Column(type=int.class, comment="职业(1战士,2刺客,3咒术师)")
	profession,
	@Column(type=int.class, comment="性别")
	sex,
	@Column(type=int.class, comment="在线时间")
	timeSecOnline,
	@Column(type=long.class, comment="最后一次登录时间")
	timeLogin,
	@Column(type=long.class, comment="最后一次登出时间")
	timeLogout,
	@Column(type=long.class, comment="角色创建时间")
	timeCreate,
	@Column(type=long.class, comment="角色SessionKey", index = true)
	sessionKey,
	@Column(type=String.class, comment="游戏设置", length=5120)
	gameOptions,
	@Column(type=String.class, comment="玩家挂机设置", length=1024)
	fightAutoOption,
	@Column(type=long.class, comment="当前经验")
	expCur,
	@Column(type=long.class, comment="本级升到下一级所需经验")
	expUpgrade,
	@Column(type=boolean.class, comment="是否在战斗状态(可以不持久化)")
	inFighting,
	@Column(type=long.class, comment="战斗状态截止时间(可以不持久化)")
	fightStateEndTime,
	@Column(type=long.class, comment="血池总量")
	hpPool,
	@Column(type=boolean.class, comment="血池是否正在回血")
	hpPoolRecover,
	@Column(type=long.class, comment="蓝池总量")
	mpPool,
	@Column(type=boolean.class, comment="蓝池是否正在回蓝")
	mpPoolRecover,
	
	/* 人物一级属性 */
	@Column(type=int.class, comment="力量")
	str,
	@Column(type=int.class, comment="敏捷")
	dex,
	@Column(type=int.class, comment="体力")
	con,
	@Column(type=int.class, comment="智力")
	inte,
	
	/* 地图 */
	@Column(type=String.class, comment="地图位置信息，{{id, sn ,x ,y ,common},{}}")
	stageHistory,
	
	/* 技能 */
	@Column(type=String.class, comment="技能", defaults="{}")
	skill,

	
}