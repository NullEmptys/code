package org.gof.demo.worldsrv.skill;

import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.support.Vector2D;

public class SkillParam {
	public UnitObject tarUo;			//目标
	public Vector2D tarPos;				//目标位置
	public int atkerType = 1;			//攻击者类型，1主角，2魂将
	public boolean finalAtk;			//是否是最后一击
	
}
