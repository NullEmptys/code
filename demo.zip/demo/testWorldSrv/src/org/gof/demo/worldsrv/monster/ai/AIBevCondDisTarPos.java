package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;
import org.gof.demo.worldsrv.character.MonsterObject;

public class AIBevCondDisTarPos extends AIBevLeaf{
	private double dis = 0;
	public AIBevCondDisTarPos(AI ai, double dis, boolean logic) {
		this.ai = ai;
		nonLogic = logic;
		this.dis = dis;
	}
	public AIBevCondDisTarPos(AI ai, double dis) {
		this.ai = ai;
		this.dis = dis;
	}
	@Override
	public boolean execute(Param param) {
		boolean result = false;
		
		MonsterObject monObj = ai.monsterObj;
		
		if(monObj.posNow.distance(ai.tarMovePos) < dis) {
			return returnLogic(true);
		} 
		
		return returnLogic(result);
	}

}
