package org.gof.demo.worldsrv.skill.logic;

import java.util.Map;

import org.gof.core.support.ManagerBase;
import org.gof.core.support.SysException;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.config.ConfSkillEffect;
import org.gof.demo.worldsrv.skill.SkillCommon;

public class SkillLogicManager extends ManagerBase {
	public static Map<Integer, Class<? extends AbstractSkillLogic>> skillEffectMap = Utils.ofMap(
			1, SkillLogic001.class ,		//直接伤害
			2, SkillLogic002.class ,		//dot
			3, SkillLogic003.class 		//buff
			);
	
	public static SkillLogicManager getInstance() {
		return getInstance(SkillLogicManager.class);
	}

	/**
	 * 初始化技能效果参数
	 * @param sn	技能效果id
	 * @return
	 */
	public AbstractSkillLogic initLogic(SkillCommon skillCommon, int sn) {
		ConfSkillEffect confSkillEffect = ConfSkillEffect.get(sn);
		
		if(confSkillEffect == null) {
			throw new SysException("技能效果没找到，效果id={}", sn);
		}
		
		//初始化技能效果
		try {
			AbstractSkillLogic skillLogic = (AbstractSkillLogic)skillEffectMap.get(confSkillEffect.logicSn).newInstance();
			skillLogic.init(skillCommon, confSkillEffect);
			return skillLogic;
		} catch (Exception e) {
			throw new SysException(e);
		}
	}
}
