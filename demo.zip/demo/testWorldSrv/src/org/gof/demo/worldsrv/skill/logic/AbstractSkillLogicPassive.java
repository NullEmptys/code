package org.gof.demo.worldsrv.skill.logic;

import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.skill.SkillEventKey;
import org.gof.demo.worldsrv.skill.SkillParamVO;



/**
 * 被动技能效果
 * @author new
 *
 */
public abstract class AbstractSkillLogicPassive extends AbstractSkillLogic{

	public abstract boolean canTrigger(SkillEventKey key, boolean isAtker, boolean isPartner);
	
	/**
	 * 被动技能
	 * @param skillParamVO
	 */
	public abstract void trigger(SkillEventKey key, UnitObject tarUnit, SkillParamVO skillParamVO);
	
}
