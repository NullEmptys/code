package org.gof.demo.worldsrv.support.enumKey;

/**
 * unitObj的状态
 * @author HivenYang
 *
 */
public enum UnitObjectStateKey {
	skillback,
	stun,								//眩晕
	immobilize,					//冻结
	silence,							//沉默
	skill_shake,					//施法前摇
	;
}
