package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;
import org.gof.demo.worldsrv.stage.StageManager;

public class AIBevActGetRandPos extends AIBevLeaf {
	protected StageManager stageManager = StageManager.getInstance();
	private double radius = 0;
	public AIBevActGetRandPos(AI ai, double radius) {
		this.ai = ai;
		this.radius = radius;
	}

	@Override
	public boolean execute(Param param) {
		ai.tarMovePos = stageManager.randomPosInCircle(ai.monsterObj.posBegin, 0, radius);
		return true;
	}

}
