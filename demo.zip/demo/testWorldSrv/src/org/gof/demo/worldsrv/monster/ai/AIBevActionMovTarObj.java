package org.gof.demo.worldsrv.monster.ai;

import java.util.List;

import org.gof.core.support.Param;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.stage.StageManager;
import org.gof.demo.worldsrv.stage.StageObject;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.demo.worldsrv.support.Vector3D;

public class AIBevActionMovTarObj extends AIBevLeaf {

	private double dis = 0;
	public AIBevActionMovTarObj(AI ai, double dis) {
		this.ai = ai;
		this.dis = dis;
	}

	@Override
	public boolean execute(Param param) {
		StageObject stageObj = ai.monsterObj.stageObj;
		UnitObject unitObj = stageObj.getUnitObj(ai.targetId);
		if(unitObj != null) {
			double dis = ai.monsterObj.posNow.distance(unitObj.posNow);
			Vector2D tarPos = Vector2D.lookAtDis(ai.monsterObj.posNow, unitObj.posNow, ai.monsterObj.posNow, dis - this.dis);
			List<Vector3D> path = Utils.ofList(StageManager.getHeight(ai.monsterObj.stageObj.sn, tarPos));
			ai.monsterObj.move(StageManager.getHeight(ai.monsterObj.stageObj.sn, ai.monsterObj.posNow), path);
			return true;
			
			
		} else {
			return false;
		}
	}

}
