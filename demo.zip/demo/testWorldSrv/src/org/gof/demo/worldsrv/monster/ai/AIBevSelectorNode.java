package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;

public class AIBevSelectorNode extends AIBevNodeControl{

	@Override
	public boolean execute(Param param) {
        boolean result = false;
        for (AIBevLeaf iterable_element : child) {
        	if(iterable_element.execute(param)) {
        		return true;
        	}
		}
        return result;
	}
	

}
