package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;
import org.gof.demo.worldsrv.character.MonsterObject;
import org.gof.demo.worldsrv.entity.Monster;

public class AIBevConditionDie extends AIBevLeaf{

	public AIBevConditionDie(AI ai, boolean logic) {
		this.ai = ai;
		nonLogic = logic;
	}
	public AIBevConditionDie(AI ai) {
		this.ai = ai;
	}
	

	@Override
	public boolean execute(Param param) {
		boolean result = false;
		
		MonsterObject monObj = ai.monsterObj;
		
		if(monObj.isDie()) {
			return returnLogic(true);
		}
		
		return returnLogic(result);
	}
}
