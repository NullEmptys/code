package org.gof.demo.worldsrv.character;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.gof.core.Port;
import org.gof.core.support.Param;
import org.gof.core.support.SysException;
import org.gof.core.support.TickTimer;
import org.gof.core.support.Utils;
import org.gof.demo.worldsrv.buff.BuffManager;
import org.gof.demo.worldsrv.entity.Buff;
import org.gof.demo.worldsrv.entity.Unit;
import org.gof.demo.worldsrv.human.SkillTempInfo;
import org.gof.demo.worldsrv.msg.Msg;
import org.gof.demo.worldsrv.msg.Msg.SCStageMoveStop;
import org.gof.demo.worldsrv.msg.Msg.SCStageObjectDisappear;
import org.gof.demo.worldsrv.msg.Msg.SCStageObjectInfoChange;
import org.gof.demo.worldsrv.skill.SkillCommon;
import org.gof.demo.worldsrv.skill.SkillExcute;
import org.gof.demo.worldsrv.stage.StageCell;
import org.gof.demo.worldsrv.stage.StageObject;
import org.gof.demo.worldsrv.support.HumanInfoChange;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.PropCalcCommon;
import org.gof.demo.worldsrv.support.Running;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.demo.worldsrv.support.Vector3D;
import org.gof.demo.worldsrv.support.enumKey.UnitObjectStateKey;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;
import org.gof.demo.worldsrv.support.pathFinding.PathFinding;

/**
 * 角色基类 包含移动、战斗等
 */
public abstract class UnitObject extends WorldObject {
	private BuffManager buffManager = BuffManager.getInstance();
	
	public Running running = new Running(this); // 玩家移动信息

	/** 技能 */
	public final Map<Integer, SkillCommon> skills = new HashMap<>();
	public SkillTempInfo skillTempInfo = new SkillTempInfo(); // 技能信息
	public int lastSkillSn; // 上次释放的技能sn
	public long lastSkillTime;

	public boolean canMove = true; // 是否可移动
	public boolean canCastSkill = true; // 是否可以施放技能
	public boolean canAttack = true;
	
	//Buff更新Timer
	public TickTimer timerBuffPulse = new TickTimer(BuffManager.INTERVAL_PULSE);	
	
	// 能否普通攻击
	// unitObj的状态
	public Map<UnitObjectStateKey, TickTimer> state = new HashMap<>();
	public TickTimer timerStatePulse = new TickTimer(500);

	public abstract Unit getUnit();
	public abstract Map<Integer, Buff> getBuffs();
	public abstract PropCalcCommon getPropPlus();

	public UnitObject(StageObject stageObj) {
		super(stageObj);

	}

	public boolean isDie() {
		return getUnit().getHpCur() <= 0;
	}

	public boolean isHumanObj() {
		return this instanceof HumanObject;
	}

	public boolean isMonsterObj() {
		return this instanceof MonsterObject;
	}

	@Override
	public void pulse() {
		long curr = Port.getTime();
		// 单元移动了
		pulseMove(curr);

		//周期到了，则更新身上的buff
		if(timerBuffPulse.isPeriod(curr)) {
			buffManager.pulse(this);
		}
		
		// 施放可以施放的有前摇的技能
		updateSkill();

		// 更新各种状态
		updateState(curr);

	}

	/**
	 * 待施放技能队列中取可以施放的技能，放技能
	 */
	public void updateSkill() {
		SkillExcute skillToExcute = skillTempInfo.skillToExcute;

		// 如果没有前摇技能，则不管
		if (skillToExcute == null)
			return;

		// 前摇时间没有结束
		if (!skillToExcute.tickTimer.isOnce(Port.getTime()))
			return;

		skillTempInfo.skillToExcute = null;

		SkillCommon skill = null;

		// 主角技能
		if (skillToExcute.atkerType == 1) {
			skill = skills.get(skillToExcute.sn);
		} else {
		}

		// 技能不存在
		if (skill == null) {
			throw new SysException("技能不存在，攻击者id={},技能Sn={}", id,
					skillToExcute.sn);
		}

		skill.castSecond(skillToExcute.tarPos);
	}

	/**
	 * 地图单元移动
	 * 
	 * @param posFrom
	 * @param posTo
	 */
	public void move(Vector3D posFrom, List<Vector3D> posTo) {
		if (!isInWorld())
			return;
		if (!canMove)
			return;
		
		// 移动过于频繁，忽略这次消息
		if (!running.isTimeExpired()) {
			return;
		}
		// 修正起点
		if (isHumanObj()) {
			posFrom.set(running.correctPosFrom(posFrom));
		}

		// 修正所有点，如果连续两个点相同，则移出后一个
		Vector3D pos = new Vector3D();
		pos.set(posFrom);
		Iterator<Vector3D> it = posTo.iterator();
		while (it.hasNext()) {
			Vector3D posNext = it.next();
			if (pos.equals(posNext)) {
				it.remove();
				continue;
			}
			pos.set(posNext);
		}

		// 目标点为空
		if (posTo.isEmpty())
			return;

		if (this.isHumanObj()) {
			Event.fire(EventKey.HUMAN_MOVE_START_BEFORE, "humanObj", this);
			Event.fire(EventKey.HUMAN_ACTS_BEFORE, "humanObj", this);
		}

		// 移动
		running._move(posFrom, posTo, getUnit().getSpeed());

		/*
		 * if(this.isHumanObj()) {
		 * Log.temp.error("地图单元({})开始移动，起始位置{}，接下来的目标为{}。", this.name,
		 * posFrom.getPosStr(), running.getRunPathMsg()); }
		 */

		// 发送消息给前端
		Msg.SCStageMove.Builder move = Msg.SCStageMove.newBuilder();
		move.setObjId(id);
		move.setPosBegin(posFrom.toMsg());
		move.addAllPosEnd(running.getRunPathMsg());
		stageManager.sendMsgToArea(move, stageObj, posNow);

		// 抛出开始移动的事件
		Event.fire(EventKey.UNIT_MOVE_START, "unitObj", this);
		Event.fire(EventKey.UNIT_ACT, "unitObj", this);
		if (this.isHumanObj()) {
			Event.fire(EventKey.HUMAN_MOVE_START, "humanObj", this);
			Event.fire(EventKey.HUMAN_ACT, "humanObj", this);
		} else {
			Event.fire(EventKey.MONSTER_MOVE_START, "monsterObj", this);
			Event.fire(EventKey.MONSTER_ACT, "monsterObj", this);
		}

		// 记录日志
		if (this.isHumanObj()) {
			HumanObject human = (HumanObject) this;
			if (Log.stageMove.isInfoEnabled()) {
				Log.stageMove.info("角色({})开始移动，起始位置{}，接下来的目标为{}。",
						human.dataPers.human.getName(), posFrom.getPosStr(),
						running.getRunPathMsg());
			}
		} else {
			if (Log.stageMove.isInfoEnabled()) {
//				Log.stageMove.info("地图单元({})开始移动，起始位置{}，接下来的目标为{}。", this.name,
//						posFrom.getPosStr(), running.getRunPathMsg());
			}
		}

	}

	/**
	 * 地图单元移动
	 * 
	 * @param timeCurr
	 *            当前时间
	 */
	public void pulseMove(long timeCurr) {
		if (!isInWorld())
			return;
		if (!running.isRunning())
			return;
		// 单元移动了
		StageCell cellBegin = stageCell;
		running._pulse();
		StageCell cellEnd = stageObj.getCell(posNow);
		stageCell = cellEnd;
		// 判断玩家有没有跨地图格了
		if (cellBegin != null && !cellEnd.equals(cellBegin)) { // 跨地图格了
			stageManager.cellChanged(cellBegin, cellEnd, this);
		}
	}

	public void die(UnitObject killer, Object... params) {
		Unit unit = getUnit();
		unit.setHpCur(0);

		// 设置状态
		inWorld = false;

		// 停止移动
		stop();

		Param param = new Param(params);

		long killerId = 0;
		String killerName = "";
		int skillSn = Utils.getParamValue(param, "skillSn", 0);
		if (killer != null) {
			killerId = killer.id;
			killerName = killer.name;
		}

		// 通知其他玩家 有地图单元离开视野
		SCStageObjectDisappear.Builder msg = createMsgDie();
		msg.setKillerId(killerId);
		msg.setKillerName(killerName);
		msg.setSkillSn(skillSn);

		stageManager.sendMsgToArea(msg, stageObj, posNow);
	}

	/**
	 * 强制单元停止
	 * 
	 */
	public void stop() {
		if (!running.isRunning())
			return;

		// 停止移动
		running._stop();

		// 发送消息
		SCStageMoveStop.Builder msgStop = SCStageMoveStop.newBuilder();
		msgStop.setObjId(id);
		msgStop.setPosEnd(posNow.toMsg());
		stageManager.sendMsgToArea(msgStop, stageObj, posNow);
	}

	public SCStageObjectDisappear.Builder createMsgDie() {
		SCStageObjectDisappear.Builder msgObjDisappear = SCStageObjectDisappear
				.newBuilder();
		msgObjDisappear.setObjId(id);
		msgObjDisappear.setType(2);

		return msgObjDisappear;
	}

	/**
	 * 让unitObj进入某种状态，time为持续时间
	 * 
	 * @param stateKey
	 * @param time
	 */
	public void toState(UnitObjectStateKey stateKey, long time) {
		long curr = Port.getTime();
		if (state.get(stateKey) != null) {
			TickTimer timer = state.get(stateKey);
			long timeLeft = timer.getTimeLeft(curr);
			timer.start(Math.max(time, timeLeft));
		} else {
			TickTimer timer = new TickTimer();
			timer.start(time);
			state.put(stateKey, timer);
		}
	}

	/**
	 * 更新unitObj的状态
	 */
	public void updateState(long curr) {
		if (!timerStatePulse.isPeriod(curr))
			return;
		// 如果死亡，则把所有限制状态移出
		if (isDie()) {
			state.clear();
		}

		List<UnitObjectStateKey> removeList = new ArrayList<>();
		boolean canMove = true;
		boolean canCastSkill = true;
		boolean canAttack = true;
		
		for (Entry<UnitObjectStateKey, TickTimer> entry : state.entrySet()) {
			UnitObjectStateKey state = entry.getKey();
			TickTimer timer = entry.getValue();
			// 根据不同的状态进行不同的处理，同时如果时间到了则解除状态
			switch (state) {
			case skillback:
				if (timer.isOnce(curr)) {
					removeList.add(state);
				} else {
					canMove = false;
					canCastSkill = false;
					canAttack = false;
				}
				break;
			case stun:
				if (timer.isOnce(curr)) {
					removeList.add(state);
				} else {
					canMove = false;
					canCastSkill = false;
					canAttack = false;
				}
				break;
			case immobilize:
				if (timer.isOnce(curr)) {
					removeList.add(state);
				} else {
					canMove = false;
				}
				break;
			case silence:
				if (timer.isOnce(curr)) {
					removeList.add(state);
				} else {
					canCastSkill = false;
				}
				break;
			case skill_shake:
				if (timer.isOnce(curr)) {
					removeList.add(state);
				} else {
					canMove = false;
					canCastSkill = false;
					canAttack = false;
				}
				break;
			default:
				break;
			}
		}
		// 发送状态变化消息
		if (!isDie()
				&& (this.canMove != canMove | this.canCastSkill != canCastSkill | this.canAttack != canAttack)) {
			if (this.isHumanObj()) {
				HumanInfoChange.listen((HumanObject) this);
			} else {
				SCStageObjectInfoChange.Builder infoChange = SCStageObjectInfoChange
						.newBuilder();
				infoChange.setObj(((MonsterObject) this).createMsg());
				stageManager.sendMsgToArea(infoChange, stageObj, posNow);
			}
		}

		// 如果不能移动，直接停下来先
		if (!canMove) {
			stop();
		}

		this.canMove = canMove;
		this.canCastSkill = canCastSkill;
		this.canAttack = canAttack;
		// 移走记录
		for (UnitObjectStateKey state : removeList) {
			this.state.remove(state);
		}
	}
}