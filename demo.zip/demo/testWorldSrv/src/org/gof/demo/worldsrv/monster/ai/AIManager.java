package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.ManagerBase;
import org.gof.core.support.Param;
import org.gof.demo.worldsrv.character.MonsterObject;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.support.observer.EventKey;
import org.gof.demo.worldsrv.support.observer.Listener;

/**
 * 怪物AI功能类
 */
public class AIManager extends ManagerBase {

	public static AIManager getInstance() {
		return getInstance(AIManager.class);
	}
	
	@Listener(EventKey.MONSTER_BE_ATTACKED)
	public void onAttacked(Param param) {
		MonsterObject monsterObj = param.get("monsterObj");
		UnitObject unit = param.get("attacker");
		monsterObj.ai.behavior = AIBehaviorKey.ATTACKED;
		monsterObj.ai.targetId = unit.id;
		
	}
}
