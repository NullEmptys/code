package org.gof.demo.worldsrv.skill.logic;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.gof.core.support.RandomUtils;
import org.gof.demo.worldsrv.character.MonsterObject;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.config.ConfSkillEffect;
import org.gof.demo.worldsrv.msg.Msg.DBackPos;
import org.gof.demo.worldsrv.msg.Msg.SCFightSkill;
import org.gof.demo.worldsrv.skill.SkillCommon;
import org.gof.demo.worldsrv.skill.SkillEventKey;
import org.gof.demo.worldsrv.skill.SkillParam;
import org.gof.demo.worldsrv.skill.SkillParamVO;
import org.gof.demo.worldsrv.stage.StageManager;
import org.gof.demo.worldsrv.support.I18n;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.ReasonResult;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.demo.worldsrv.support.enumKey.UnitObjectStateKey;
import org.gof.demo.worldsrv.support.observer.Event;
import org.gof.demo.worldsrv.support.observer.EventKey;

public abstract class AbstractSkillLogic {
	public SkillCommon skill; // 所属技能
	public ConfSkillEffect conf; // 技能效果

	/**
	 * 初始化技能效果对象
	 * 
	 * @param params
	 */
	public void init(SkillCommon skillCommon, ConfSkillEffect confSkillEffect) {
		skill = skillCommon;

		this.conf = confSkillEffect;
	}

	/**
	 * 检查参数是否有问题
	 * 
	 * @param position
	 * @return
	 */
	public ReasonResult isLegal(SkillParam position) {
		// 单体取目标,目标选择不能选自己的，参数传成自己了
		if (conf.scopeType == 1 && !conf.targetSelf) {
			if (position.tarUo == skill.unitObj) {
				return new ReasonResult(false, "该技能目标不能是自己");
			}
		}

		return new ReasonResult(true, "");
	}

	/**
	 * 获取作用目标集合
	 * 
	 * @return
	 */
	public List<UnitObject> getTars(SkillParam position) {
		List<UnitObject> tars = new ArrayList<>();

		// 单体取目标
		if (conf.scopeType == 1) {
			// TODO 判断友好度

			if (conf.targetSelf) {
				tars.add(skill.unitObj);
			} else {
				if (position.tarUo == skill.unitObj) {
					// Inform.user(skill.unitObj.id, Inform.提示错误, "该技能目标不能是自己");
					return tars;
				}
				tars.add(position.tarUo);
			}
		} else if (conf.scopeType == 2) {
			// 目标周围圆形取坐标 圆形内所有的unitObj
			List<UnitObject> unitAll = StageManager.getInstance() .getUnitObjsInCircle(skill.unitObj.stageObj, position.tarPos, conf.scopeParam1);
			tars.addAll(unitAll);
		} else if (conf.scopeType == 3) {
			// 自身朝向扇形取坐标 扇形中的所有unitObj

			// 如果目标点跟自身点重合，做若干修正
			Vector2D vec = position.tarPos;
			if (position.tarPos == skill.unitObj.posNow) {
				vec = new Vector2D(vec.x, vec.y + 0.001);
			}

			List<UnitObject> unitAll = StageManager.getInstance() .getUnitObjsInSector(skill.unitObj.stageObj, skill.unitObj.posNow, vec, conf.scopeParam1, conf.scopeParam2, true);
			tars.addAll(unitAll);
		} else if (conf.scopeType == 4) {
			// 自身朝向后扇形

			// 如果目标点跟自身点重合，做若干修正
			Vector2D vec = position.tarPos;
			if (position.tarPos == skill.unitObj.posNow) {
				vec = new Vector2D(vec.x, vec.y + 0.001);
			}

			List<UnitObject> unitAll = StageManager.getInstance() .getUnitObjsInSector(skill.unitObj.stageObj, skill.unitObj.posNow, vec, conf.scopeParam1, conf.scopeParam2, false);
			tars.addAll(unitAll);
		} else if (conf.scopeType == 5) {
			// 自身朝向矩形
			// 如果目标点跟自身点重合，做若干修正
			Vector2D vec = position.tarPos;
			if (position.tarPos == skill.unitObj.posNow) {
				vec = new Vector2D(vec.x, vec.y + 0.001);
			}

			List<UnitObject> unitAll = StageManager.getInstance().getUnitObjsInRectangle(skill.unitObj.stageObj, skill.unitObj.posNow, vec, conf.scopeParam1, conf.scopeParam2);
			tars.addAll(unitAll);
		}

		// 删除inworld = false的unitObj
		Iterator<UnitObject> iter = tars.iterator();
		while (iter.hasNext()) {
			UnitObject unitObjTmp = iter.next();
			// inworld=false，或者是技能释放者都得排除
			if (!unitObjTmp.isInWorld() || (!conf.targetSelf && unitObjTmp.id == skill.unitObj.id)) {
				iter.remove();
				continue;
			}

			if (unitObjTmp.isDie()) {
				iter.remove();
				continue;
			}

			// 如果目标是怪物，怪物没激活，则排除,如果是怪物放技能，目标不能有怪物
			if (unitObjTmp.isMonsterObj()) {
				if (!((MonsterObject) unitObjTmp).active) {
					iter.remove();
					continue;
				}
			}
		}

		// 取指定最大个数目标,如果是群伤技能的话
		if (conf.scopeType != 1 && conf.targetNum < tars.size() && conf.targetNum != 0) {
			int sizeMinus = tars.size() - conf.targetNum;
			for (int i = 0; i < sizeMinus; i++) {
				tars.remove(RandomUtils.nextInt(tars.size()));
			}
		}

		return tars;
	}

	/**
	 * 是否可以释放
	 * 
	 * @param position
	 * @return
	 */
	public ReasonResult canDoSkillEffect(SkillParam position) {
		// 施法者死亡
		if (skill.unitObj.isDie()) {
			return new ReasonResult(false, I18n.get("fight.canCastSkill.die"));
		}

		// 目标死亡1
		if (position.tarUo != null && position.tarUo.isDie()) {
			return new ReasonResult(false, 	I18n.get("fight.canCastSkill.tarDie"));
		}

		return new ReasonResult(true);
	}

	/**
	 * 对所有目标施放技能效果
	 * 
	 * @param unitAtk
	 * @param position
	 */
	public void doSkillEffect(SkillParam position) {
		// 对技能作用范围内的有效目标进行技能作用
		List<UnitObject> tars = getTars(position);
		for (UnitObject unitDef : tars) {
			skill.affectUnits.add(unitDef);

			// 对单个目标进行技能作用
			doSkillEffectToTar(unitDef);

			// 技能消息中加入受攻击者id
			if (skill.scFightSkill == null) {
				skill.scFightSkill = SCFightSkill.newBuilder();
				
			}
			skill.scFightSkill.addDefId(unitDef.id);
			//计算击退 击倒
//			calcBackDis(unitDef);
			
			// 判断技能结束前是否有被动技能触发（攻击结束后触发buff或者受攻击结束后触发buff）
			SkillParamVO vo = new SkillParamVO();
			Event.fire(EventKey.SKILL_PASSIVE_CHECK, "unitAtk", skill.unitObj, 
																				"unitDef", unitDef, 
																				"skillEventKey", SkillEventKey.EVENT_ON_TAR_EFFECT_END, 
																				"isPartner", false, 
																				"vo", vo);
		}
		
		//计算击退 击倒 人物跟进
		calcBackDis(tars, position);
	}
	
	/**
	 * //计算击退 击倒 这个函数有点长
	 * @param unitDef
	 * @param tars
	 */
	public void calcBackDis(List<UnitObject> tars, SkillParam position) {
		if (conf.impulse <= 0) {
			return;
		}
		
		//计算技能产生伤害目标的整体质量---------------------------------
		List<MonsterObject> downTars = new ArrayList<MonsterObject>();
		List<MonsterObject> backTars = new ArrayList<MonsterObject>();
		double massTotal = 0;
		for (UnitObject unitObject : tars) {
			//如果攻击者人玩家 防守者是怪物
			if (skill.unitObj.isHumanObj() && unitObject.isMonsterObj()) {
				MonsterObject obj = (MonsterObject) unitObject;

				double rand = RandomUtils.nextInt(100) / 100f;
				
				//计算会产生击倒的同学
				double prop = 1 - obj.conf.backDownProp;
				// 判断怪物是否被击倒
				if (rand > prop) {
					downTars.add(obj);
				} else {
					//计算会产生击退的同学
					prop = prop - obj.conf.backProp;
					// 判断怪物是否被击退
					if (rand > prop) {
						backTars.add(obj);
					}
				}
				
			}
		}
		
//		if(downTars.size() == 0 && backTars.size() == 0) {
//			return;
//		}
		
		//根据冲量计算位移--------------------------------------
		for (MonsterObject unitObject : downTars) {
			massTotal += unitObject.conf.mass;
		}
		for (MonsterObject unitObject : backTars) {
			massTotal += unitObject.conf.mass;
		}
		
		double dis = 0;
		if(massTotal == 0) {
			dis = conf.impulse / 40;
		} else {
			//计算位移
			dis = conf.impulse / massTotal;
		}
		// 对距离做特殊处理，不能超过3 FIXME
		if(dis > 12) dis = 12;
		else if(dis < -12) dis = -12;
		
		
		//计算更新所有被攻击者的位置------------------------------------
		Vector2D backPos;
		for (MonsterObject unitObject : downTars) {
			backPos = Vector2D.lookAtDis(skill.unitObj.posNow, unitObject.posNow, unitObject.posNow, dis);
			backPos = StageManager.getRaycastDis(skill.unitObj.stageObj.sn, unitObject.posNow, backPos, skill.unitObj.stageObj.pathFindingFlag);
			//发送消息
			DBackPos.Builder backPosMsg = DBackPos.newBuilder();
			backPosMsg.setId(unitObject.id);
			backPosMsg.setPos(backPos.toMsg());
			backPosMsg.setType(1);
			skill.scFightSkill.addBackPos(backPosMsg);
			//更新怪物的位置
			unitObject.posNow = backPos;
			//更新状态
			unitObject.toState(UnitObjectStateKey.stun, unitObject.conf.backDownTime);
		}
		for (MonsterObject unitObject : backTars) {
			backPos = Vector2D.lookAtDis(skill.unitObj.posNow, unitObject.posNow, unitObject.posNow ,dis);
			backPos = StageManager.getRaycastDis(skill.unitObj.stageObj.sn, unitObject.posNow, backPos, skill.unitObj.stageObj.pathFindingFlag);
			//发送消息
			DBackPos.Builder backPosMsg = DBackPos.newBuilder();
			backPosMsg.setId(unitObject.id);
			backPosMsg.setPos(backPos.toMsg());
			backPosMsg.setType(2);
			skill.scFightSkill.addBackPos(backPosMsg);
			//更新怪物的位置
			unitObject.posNow = backPos;
			//更新状态
			unitObject.toState(UnitObjectStateKey.stun, unitObject.conf.backTime);
		}
		
		//计算人物跟进 -----------------------------
		//这个技能是否需要跟进， 找出自己的目标跟进
		if(skill.unitObj.isHumanObj() && conf.attackMove) {
			
			if(position.tarUo != null && position.tarUo.isMonsterObj()) {
				//如果目标存在 那么跟进目标	
				double temp = skill.unitObj.posNow.distance(position.tarUo.posNow);
				
				if(temp > dis + 1) {
					skill.dVec = Vector2D.lookAtDis(skill.unitObj.posNow, position.tarUo.posNow, skill.unitObj.posNow, dis);
					skill.dVec = StageManager.getRaycastDis(skill.unitObj.stageObj.sn, skill.unitObj.posNow, skill.dVec, skill.unitObj.stageObj.pathFindingFlag);
					skill.unitObj.posNow = skill.dVec;
				} else if(temp > 1) {
					skill.dVec = Vector2D.lookAtDis(skill.unitObj.posNow, position.tarUo.posNow, skill.unitObj.posNow, temp - 1);
					skill.dVec = StageManager.getRaycastDis(skill.unitObj.stageObj.sn, skill.unitObj.posNow, skill.dVec, skill.unitObj.stageObj.pathFindingFlag);
					skill.unitObj.posNow = skill.dVec;
				}
			} else if(position.tarUo == null && position.tarPos != null ){
				//如果位置存在那么跟进位置
				skill.dVec = Vector2D.lookAtDis(skill.unitObj.posNow, position.tarPos, skill.unitObj.posNow, dis);
				skill.dVec = StageManager.getRaycastDis(skill.unitObj.stageObj.sn, skill.unitObj.posNow, skill.dVec, skill.unitObj.stageObj.pathFindingFlag);
//				Log.coreMsg.info("111111{},{},{}",skill.dVec,skill.unitObj.posNow,position.tarPos);
				
				skill.unitObj.posNow = skill.dVec;
			}
			
		}
		
	}
	
	
	public void calcBackDis(UnitObject unitDef) {
		// 判断技能技能是否需要判断冲量
		if (conf.impulse <= 0) {
			return;
		}
		//如果攻击者人玩家 防守者是怪物
		if (skill.unitObj.isHumanObj() && unitDef.isMonsterObj()) {
			MonsterObject obj = (MonsterObject) unitDef;

			double rand = RandomUtils.nextInt(100) / 100f;
			double prop = 1 - obj.conf.backDownProp;
			Vector2D backPos;
			// 判断怪物是否被击倒
			if (rand > prop) {
				//计算位置
				backPos = calcImpulse(obj);
				
				//发送消息
				DBackPos.Builder backPosMsg = DBackPos.newBuilder();
				backPosMsg.setId(obj.id);
				backPosMsg.setPos(backPos.toMsg());
				backPosMsg.setType(2);
				skill.scFightSkill.addBackPos(backPosMsg);
				//更新怪物的位置
				obj.posNow = backPos;
				//更新状态
				unitDef.toState(UnitObjectStateKey.stun, obj.conf.backDownTime);
				
				return;
			}
			
			// 判断怪物是否被击退
			prop = prop - obj.conf.backProp;
			if (rand > prop) {
				//计算位置
				backPos = calcImpulse(obj);
				
				//发送消息
				DBackPos.Builder backPosMsg = DBackPos.newBuilder();
				backPosMsg.setId(obj.id);
				backPosMsg.setPos(backPos.toMsg());
				backPosMsg.setType(2);
				skill.scFightSkill.addBackPos(backPosMsg);
				//更新怪物的位置
				obj.posNow = backPos;
				//更新状态
				unitDef.toState(UnitObjectStateKey.stun, obj.conf.backTime);
				return;
			}
			
		}
	}
	
	public Vector2D calcImpulse(MonsterObject obj) {
		Vector2D result;
		double dis = 0;
		
		//计算位移
		dis = conf.impulse / obj.conf.mass;
		
		result = Vector2D.lookAtDis(skill.unitObj.posNow, obj.posNow, obj.posNow, dis);
		//计算具体的点
		return result;
				
	}

	/**
	 * 对单个目标作用效果
	 * 
	 * @param unitAtk
	 * @param unitDef
	 */
	public abstract void doSkillEffectToTar(UnitObject unitDef);

	/**
	 * 计算伤害,不同的逻辑库会覆盖
	 * 
	 * @return
	 */
	public int calcHurt(UnitObject unitDef) {
		return 0;
	}

	public int calcHpLost(UnitObject unitDef, boolean calcCrit) {
		int hurt = calcHurt(unitDef);

		if (calcCrit) {
			/*
			 * if(FightManager.getInstance().isCrit(skill.unitObj, unitDef)) {
			 * 
			 * }
			 */

			// 判断扣血前攻击方是否有被动技能触发
			// SkillParamVO voAtk = new SkillParamVO();
			// SkillManager.getInstance().doPassiveSkill(unitDef, skill.unitObj,
			// SkillEventKey.EVENT_ON_BEFORE_HIT, false,
			// false, voAtk);

			// TODO 计算暴击闪避

		}

		return hurt;
	}

	// /**
	// * 获取连击的加成比例，如1.2代表比非连击加成伤害20%
	// * @return
	// */
	// public double getComboPct() {
	// if(StringUtils.isBlank(skill.confSkill.combo)) return 1;
	//
	// JSONArray ja = JSON.parseArray(skill.confSkill.combo);
	// if(skill.comboCount > ja.size() - 1) return 1;
	//
	// return ja.getDoubleValue(skill.comboCount);
	// }
}
