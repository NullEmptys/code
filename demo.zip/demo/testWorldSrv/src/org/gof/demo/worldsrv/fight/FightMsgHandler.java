package org.gof.demo.worldsrv.fight;

import org.gof.core.support.observer.MsgReceiver;
import org.gof.demo.worldsrv.character.HumanObject;
import org.gof.demo.worldsrv.character.UnitObject;
import org.gof.demo.worldsrv.config.ConfSkill;
import org.gof.demo.worldsrv.human.HumanManager;
import org.gof.demo.worldsrv.msg.Msg.CSFightAtk;
import org.gof.demo.worldsrv.msg.Msg.CSFightRevive;
import org.gof.demo.worldsrv.skill.SkillCommon;
import org.gof.demo.worldsrv.skill.SkillManager;
import org.gof.demo.worldsrv.skill.SkillParam;
import org.gof.demo.worldsrv.support.I18n;
import org.gof.demo.worldsrv.support.Log;
import org.gof.demo.worldsrv.support.ReasonResult;
import org.gof.demo.worldsrv.support.Vector2D;
import org.gof.seam.msg.MsgParam;

public class FightMsgHandler {
	
	/**
	 * 请求施放技能
	 * @param param
	 */
	@MsgReceiver(CSFightAtk.class)
	public void onCSFightAtk(MsgParam param) {
		HumanObject humanObj = param.getHumanObject();
		CSFightAtk msg = param.getMsg();
		
		//技能sn
		int skillSn = msg.getSkillId();
		ConfSkill conf = ConfSkill.get(skillSn);
		if(conf == null) return ;
		
		SkillParam skillParam = new SkillParam();
		if(msg.hasTarId()) {
			long tarId = msg.getTarId();
			//如果技能释放目标是自己的话
			if(conf.clickType == 3) {
				tarId = humanObj.id;
			}
			
			UnitObject unitObj = humanObj.stageObj.getUnitObjs().get(tarId);
			
			//目标不存在
			if(unitObj == null) {
				return ;
			}
			
			skillParam.tarUo = unitObj;
			skillParam.tarPos = unitObj.posNow;
		}
		
		if(msg.hasPos()) {
			skillParam.tarPos = new Vector2D(msg.getPos());
		}
		
		//技能配置的点选目标是自己
		if(conf.clickType == SkillCommon.CLICK_SELF) {
			skillParam.tarUo = humanObj;
			skillParam.tarPos = humanObj.posNow;
		}
		
		//攻击类型，1人物，2玩家
		skillParam.atkerType = msg.hasAtkerType() ? msg.getAtkerType() : 1;  
		
		//是否是连击或连点技能最终伤害
		skillParam.finalAtk = msg.hasFinal() ? msg.getFinal() : false;
		
		ReasonResult result = SkillManager.getInstance().shakeOrCastSkill(humanObj, skillSn, skillParam);
//		if(!result.success &&msg.getAtkerType() == 1) {
//			Inform.user(humanObj.id, Inform.提示错误, result.reason);
//		}
	}
	
	/**
	 * 人物请求复活
	 * @param param
	 */
	@MsgReceiver(CSFightRevive.class)
	public void onCSFightRevive(MsgParam param) {
		HumanObject humanObj = param.getHumanObject();
		CSFightRevive msg = param.getMsg();
		
		//type: 1回城复活，2原地复活
		int type = 2;
		if(msg.hasType()) {
			type = msg.getType();
		}
		
		if(type != 1 && type != 2) {
			Log.fight.info(I18n.get("common.tip.paramWrong"));
			return ;
		}
		
		ReasonResult result = HumanManager.getInstance().revive(humanObj, type, false);
		if(!result.success) {
			Log.fight.info(result.reason);
			return ;
		}
		
		if(type == 2) {
			Log.fight.info( I18n.get("fight.revive.success1"));
		} else {
			Log.fight.info( I18n.get("fight.revive.success2"));
		}
	}
	
	
}