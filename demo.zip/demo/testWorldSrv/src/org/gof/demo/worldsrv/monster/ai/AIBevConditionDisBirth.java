package org.gof.demo.worldsrv.monster.ai;

import org.gof.core.support.Param;
import org.gof.demo.worldsrv.character.MonsterObject;

public class AIBevConditionDisBirth extends AIBevLeaf{
	private double dis = 0;
	public AIBevConditionDisBirth(AI ai, double dis, boolean logic) {
		this.ai = ai;
		nonLogic = logic;
		this.dis = dis;
	}
	public AIBevConditionDisBirth(AI ai, double dis) {
		this.ai = ai;
		this.dis = dis;
	}
	
	@Override
	public boolean execute(Param param) {
		boolean result = false;
		
		MonsterObject monObj = ai.monsterObj;
		
		if(ai.behavior == AIBehaviorKey.BACK) {
			return returnLogic(true);
		}
		
		if(monObj.posNow.distance(monObj.posBegin) > dis) {
			this.ai.tarMovePos = monObj.posBegin;
			return returnLogic(true);
		}
		
		return returnLogic(result);
	}
}
