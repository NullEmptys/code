package org.gof.demo.worldsrv.human;

import org.gof.core.Port;
import org.gof.core.CallPoint;
import org.gof.core.support.Distr;
import org.gof.core.support.Param;
import org.gof.core.support.log.LogCore;
import org.gof.core.gen.proxy.ProxyBase;
import org.gof.core.gen.proxy.GenProxyFile;
import org.gof.demo.worldsrv.human.HumanGlobalInfo;
import java.util.List;
import com.google.protobuf.Message;

@GenProxyFile
public class HumanGlobalServiceProxy extends ProxyBase {
	private static final String SERV_ID = "humanGlobal";
	
	private CallPoint remote;
	private Port localPort;
	
	/**
	 * 私有构造函数
	 * 防止实例被私自创建 必须通过newInstance函数
	 */
	private HumanGlobalServiceProxy() {}
	
	/**
	 * 获取实例
	 * 大多数情况下可用此函数获取
	 * @param localPort
	 * @return
	 */
	public static HumanGlobalServiceProxy newInstance() {
		String portId = Distr.getPortId(SERV_ID);
		if(portId == null) {
			LogCore.remote.error("通过servId未能找到查找上级Port: servId={}", SERV_ID);
			return null;
		}
		
		String nodeId = Distr.getNodeId(portId);
		if(nodeId == null) {
			LogCore.remote.error("通过portId未能找到查找上级Node: portId={}", portId);
			return null;
		}
		
		return createInstance(nodeId, portId, SERV_ID);
	}
	
	
	/**
	 * 创建实例
	 * @param localPort
	 * @param node
	 * @param port
	 * @param id
	 * @return
	 */
	private static HumanGlobalServiceProxy createInstance(String node, String port, Object id) {
		HumanGlobalServiceProxy inst = new HumanGlobalServiceProxy();
		inst.localPort = Port.getCurrent();
		inst.remote = new CallPoint(node, port, id);
		
		return inst;
	}
	
	/**
	 * 监听返回值
	 * @param obj
	 * @param methodName
	 * @param context
	 */
	public void listenResult(Object obj, String methodName, Object...context) {
		listenResult(obj, methodName, new Param(context));
	}
	
	/**
	 * 监听返回值
	 * @param obj
	 * @param methodName
	 * @param context
	 */
	public void listenResult(Object obj, String methodName, Param context) {
		localPort.listenResult(obj, methodName, context);
	}
	
	/**
	 * 等待返回值
	 */
	public Param waitForResult() {
		return localPort.waitForResult();
	}
	
	public void cancel(long humanId) {
		localPort.call(remote, "org.gof.demo.worldsrv.human.HumanGlobalService:cancel(long)", new Object[]{ humanId });
	}
	
	public void isLogined(String account) {
		localPort.call(remote, "org.gof.demo.worldsrv.human.HumanGlobalService:isLogined(String)", new Object[]{ account });
	}
	
	public void kick(long id, String reason) {
		localPort.call(remote, "org.gof.demo.worldsrv.human.HumanGlobalService:kick(long, String)", new Object[]{ id, reason });
	}
	
	public void register(HumanGlobalInfo status) {
		localPort.call(remote, "org.gof.demo.worldsrv.human.HumanGlobalService:register(HumanGlobalInfo)", new Object[]{ status });
	}
	
	public void sendMsg(long humanId, Message msg) {
		localPort.call(remote, "org.gof.demo.worldsrv.human.HumanGlobalService:sendMsg(long, Message)", new Object[]{ humanId, msg });
	}
	
	public void sendMsgToAll(List excludeIds, Message msg) {
		localPort.call(remote, "org.gof.demo.worldsrv.human.HumanGlobalService:sendMsgToAll(List, Message)", new Object[]{ excludeIds, msg });
	}
	
	public void stageIdModify(long humanId, long stageIdNew, String stageName, String nodeId, String portId) {
		localPort.call(remote, "org.gof.demo.worldsrv.human.HumanGlobalService:stageIdModify(long, long, String, String, String)", new Object[]{ humanId, stageIdNew, stageName, nodeId, portId });
	}
}
