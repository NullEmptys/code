package org.gof.demo.worldsrv.stage;

import org.gof.core.Port;
import org.gof.core.CallPoint;
import org.gof.core.support.Distr;
import org.gof.core.support.Param;
import org.gof.core.support.log.LogCore;
import org.gof.core.gen.proxy.ProxyBase;
import org.gof.core.gen.proxy.GenProxyFile;
import org.gof.demo.worldsrv.character.HumanObject;
import java.util.List;
import com.google.protobuf.Message;
import org.gof.demo.worldsrv.support.Vector2D;

@GenProxyFile
public class StageGlobalServiceProxy extends ProxyBase {
	private static final String SERV_ID = "stageGlobal";
	
	private CallPoint remote;
	private Port localPort;
	
	/**
	 * 私有构造函数
	 * 防止实例被私自创建 必须通过newInstance函数
	 */
	private StageGlobalServiceProxy() {}
	
	/**
	 * 获取实例
	 * 大多数情况下可用此函数获取
	 * @param localPort
	 * @return
	 */
	public static StageGlobalServiceProxy newInstance() {
		String portId = Distr.getPortId(SERV_ID);
		if(portId == null) {
			LogCore.remote.error("通过servId未能找到查找上级Port: servId={}", SERV_ID);
			return null;
		}
		
		String nodeId = Distr.getNodeId(portId);
		if(nodeId == null) {
			LogCore.remote.error("通过portId未能找到查找上级Node: portId={}", portId);
			return null;
		}
		
		return createInstance(nodeId, portId, SERV_ID);
	}
	
	
	/**
	 * 创建实例
	 * @param localPort
	 * @param node
	 * @param port
	 * @param id
	 * @return
	 */
	private static StageGlobalServiceProxy createInstance(String node, String port, Object id) {
		StageGlobalServiceProxy inst = new StageGlobalServiceProxy();
		inst.localPort = Port.getCurrent();
		inst.remote = new CallPoint(node, port, id);
		
		return inst;
	}
	
	/**
	 * 监听返回值
	 * @param obj
	 * @param methodName
	 * @param context
	 */
	public void listenResult(Object obj, String methodName, Object...context) {
		listenResult(obj, methodName, new Param(context));
	}
	
	/**
	 * 监听返回值
	 * @param obj
	 * @param methodName
	 * @param context
	 */
	public void listenResult(Object obj, String methodName, Param context) {
		localPort.listenResult(obj, methodName, context);
	}
	
	/**
	 * 等待返回值
	 */
	public Param waitForResult() {
		return localPort.waitForResult();
	}
	
	public void infoCancel(long stageId) {
		localPort.call(remote, "org.gof.demo.worldsrv.stage.StageGlobalService:infoCancel(long)", new Object[]{ stageId });
	}
	
	public void infoRegister(long stageId, int stageSn, String stageName) {
		localPort.call(remote, "org.gof.demo.worldsrv.stage.StageGlobalService:infoRegister(long, int, String)", new Object[]{ stageId, stageSn, stageName });
	}
	
	public void login(long humanId, CallPoint connPoint, List lastStageIds) {
		localPort.call(remote, "org.gof.demo.worldsrv.stage.StageGlobalService:login(long, CallPoint, List)", new Object[]{ humanId, connPoint, lastStageIds });
	}
	
	public void stageHumanNumAdd(long stageId) {
		localPort.call(remote, "org.gof.demo.worldsrv.stage.StageGlobalService:stageHumanNumAdd(long)", new Object[]{ stageId });
	}
	
	public void stageHumanNumReduce(long stageId) {
		localPort.call(remote, "org.gof.demo.worldsrv.stage.StageGlobalService:stageHumanNumReduce(long)", new Object[]{ stageId });
	}
	
	public void switchToStage(HumanObject humanObj, long stageTargetId, Vector2D posAppear) {
		localPort.call(remote, "org.gof.demo.worldsrv.stage.StageGlobalService:switchToStage(HumanObject, long, Vector2D)", new Object[]{ humanObj, stageTargetId, posAppear });
	}
}
