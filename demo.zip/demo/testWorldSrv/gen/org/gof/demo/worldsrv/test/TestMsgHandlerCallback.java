package org.gof.demo.worldsrv.test;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class TestMsgHandlerCallback {
	public static final String _result_onCSTest = "_result_onCSTest";
}
