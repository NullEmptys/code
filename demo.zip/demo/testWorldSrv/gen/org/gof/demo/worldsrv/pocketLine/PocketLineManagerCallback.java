package org.gof.demo.worldsrv.pocketLine;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class PocketLineManagerCallback {
	public static final String _result_loadHumanDataPocketList = "_result_loadHumanDataPocketList";
}
