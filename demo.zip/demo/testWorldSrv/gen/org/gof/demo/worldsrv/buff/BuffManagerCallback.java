package org.gof.demo.worldsrv.buff;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class BuffManagerCallback {
	public static final String _result_loadHumanData = "_result_loadHumanData";
}
