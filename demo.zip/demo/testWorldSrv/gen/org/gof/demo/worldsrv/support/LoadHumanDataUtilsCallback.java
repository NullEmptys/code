package org.gof.demo.worldsrv.support;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class LoadHumanDataUtilsCallback {
	public static final String _result_loadHumanData = "_result_loadHumanData";
}
