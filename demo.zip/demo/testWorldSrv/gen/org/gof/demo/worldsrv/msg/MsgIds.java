package org.gof.demo.worldsrv.msg;

import java.util.HashMap;
import java.util.Map;

import com.google.protobuf.Message;
import org.gof.core.support.SysException;

public class MsgIds {
	public static final int CSLogin = 11;
	public static final int SCLoginResult = 12;
	public static final int CSAccountReconnect = 21;
	public static final int SCAccountReconnectResult = 22;
	public static final int CSQueryCharacters = 1003;
	public static final int SCQueryCharactersResult = 1004;
	public static final int CSCharacterCreate = 1005;
	public static final int SCCharacterCreateResult = 1006;
	public static final int CSCharacterDelete = 1007;
	public static final int SCCharacterDeleteResult = 1008;
	public static final int CSCharacterLogin = 1009;
	public static final int SCCharacterLoginResult = 1010;
	public static final int SCInitData = 1101;
	public static final int SCHumanKick = 1200;
	public static final int SCHumanInfoChange = 1108;
	public static final int SCStageObjectInfoChange = 1109;
	public static final int CSStageEnter = 1201;
	public static final int SCStageEnterResult = 1202;
	public static final int CSStageSwitch = 1203;
	public static final int SCStageSwitch = 1204;
	public static final int CSStageMove = 1211;
	public static final int SCStageMove = 1212;
	public static final int SCStageSetPos = 1213;
	public static final int CSStageMoveStop = 1214;
	public static final int SCStageMoveStop = 1215;
	public static final int SCStageObjectAppear = 1216;
	public static final int SCStageObjectDisappear = 1217;
	public static final int SCStageMoveTeleport = 1220;
	public static final int CSStageMove2 = 1222;
	public static final int SCStagePullTo = 1226;
	public static final int CSFightAtk = 1301;
	public static final int SCFightAtkResult = 1302;
	public static final int SCFightSkill = 1303;
	public static final int SCFightHpChg = 1304;
	public static final int CSFightRevive = 1310;
	public static final int SCFightStageChange = 1311;
	public static final int SCFightDotHpChg = 1312;
	public static final int SCBuffAdd = 1802;
	public static final int SCBuffUpdate = 1803;
	public static final int SCBuffDispel = 1804;
	public static final int CSBuffDispelByHuman = 1805;
	public static final int CSSkillOpen = 2901;
	public static final int SCSkillResult = 2902;
	public static final int CSSikllUpgrade = 2903;
	public static final int SCSkillUpgradeResult = 2904;
	public static final int SCNewSkillResult = 2905;
	public static final int CSSkillBoardOpen = 2906;
	public static final int SCSkillBoardOpenResult = 2907;
	public static final int CSSkillSet = 2908;
	public static final int SCSkillSetResult = 2909;
	public static final int SCSkillSequence = 2910;
	public static final int CSFightPVPMatch = 3001;
	public static final int SCFightPVPMatchResult = 3002;
	public static final int CSFightPVPStart = 3003;
	public static final int SCFightPVPStartResult = 3004;
	public static final int CSTest = 9901;
	public static final int SCTest = 9902;
	
	//消息CLASS与消息ID的对应关系<消息class, 消息ID>
	private static final Map<Class<? extends Message>, Integer> classToId = new HashMap<>();
	//消息ID与消息CLASS的对应关系<消息ID, 消息class>
	private static final Map<Integer, Class<? extends Message>> idToClass = new HashMap<>();
	
	static {
		//初始化消息CLASS与消息ID的对应关系
		initClassToId();
		//初始化消息ID与消息CLASS的对应关系
		initIdToClass();
	}
	
	/**
	 * 获取消息ID
	 * @param clazz
	 * @return
	 */
	public static int getIdByClass(Class<? extends Message> clazz) {
		return classToId.get(clazz);
	}
	
	/**
	 * 获取消息CLASS
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getClassById(int msgId) {
		return (T) idToClass.get(msgId);
	}
	
	/**
	 * 获取消息名称
	 * @param clazz
	 * @return
	 */
	public static String getNameById(int msgId) {
		try {
			return idToClass.get(msgId).getSimpleName();
		} catch (Exception e) {
			throw new SysException(e, "获取消息名称是发生错误：msgId={0}", msgId);
		}
	}
	
	/**
	 * 初始化消息CLASS与消息ID的对应关系
	 */
	private static void initClassToId() {
		classToId.put(Msg.CSLogin.class, CSLogin);
		classToId.put(Msg.SCLoginResult.class, SCLoginResult);
		classToId.put(Msg.CSAccountReconnect.class, CSAccountReconnect);
		classToId.put(Msg.SCAccountReconnectResult.class, SCAccountReconnectResult);
		classToId.put(Msg.CSQueryCharacters.class, CSQueryCharacters);
		classToId.put(Msg.SCQueryCharactersResult.class, SCQueryCharactersResult);
		classToId.put(Msg.CSCharacterCreate.class, CSCharacterCreate);
		classToId.put(Msg.SCCharacterCreateResult.class, SCCharacterCreateResult);
		classToId.put(Msg.CSCharacterDelete.class, CSCharacterDelete);
		classToId.put(Msg.SCCharacterDeleteResult.class, SCCharacterDeleteResult);
		classToId.put(Msg.CSCharacterLogin.class, CSCharacterLogin);
		classToId.put(Msg.SCCharacterLoginResult.class, SCCharacterLoginResult);
		classToId.put(Msg.SCInitData.class, SCInitData);
		classToId.put(Msg.SCHumanKick.class, SCHumanKick);
		classToId.put(Msg.SCHumanInfoChange.class, SCHumanInfoChange);
		classToId.put(Msg.SCStageObjectInfoChange.class, SCStageObjectInfoChange);
		classToId.put(Msg.CSStageEnter.class, CSStageEnter);
		classToId.put(Msg.SCStageEnterResult.class, SCStageEnterResult);
		classToId.put(Msg.CSStageSwitch.class, CSStageSwitch);
		classToId.put(Msg.SCStageSwitch.class, SCStageSwitch);
		classToId.put(Msg.CSStageMove.class, CSStageMove);
		classToId.put(Msg.SCStageMove.class, SCStageMove);
		classToId.put(Msg.SCStageSetPos.class, SCStageSetPos);
		classToId.put(Msg.CSStageMoveStop.class, CSStageMoveStop);
		classToId.put(Msg.SCStageMoveStop.class, SCStageMoveStop);
		classToId.put(Msg.SCStageObjectAppear.class, SCStageObjectAppear);
		classToId.put(Msg.SCStageObjectDisappear.class, SCStageObjectDisappear);
		classToId.put(Msg.SCStageMoveTeleport.class, SCStageMoveTeleport);
		classToId.put(Msg.CSStageMove2.class, CSStageMove2);
		classToId.put(Msg.SCStagePullTo.class, SCStagePullTo);
		classToId.put(Msg.CSFightAtk.class, CSFightAtk);
		classToId.put(Msg.SCFightAtkResult.class, SCFightAtkResult);
		classToId.put(Msg.SCFightSkill.class, SCFightSkill);
		classToId.put(Msg.SCFightHpChg.class, SCFightHpChg);
		classToId.put(Msg.CSFightRevive.class, CSFightRevive);
		classToId.put(Msg.SCFightStageChange.class, SCFightStageChange);
		classToId.put(Msg.SCFightDotHpChg.class, SCFightDotHpChg);
		classToId.put(Msg.SCBuffAdd.class, SCBuffAdd);
		classToId.put(Msg.SCBuffUpdate.class, SCBuffUpdate);
		classToId.put(Msg.SCBuffDispel.class, SCBuffDispel);
		classToId.put(Msg.CSBuffDispelByHuman.class, CSBuffDispelByHuman);
		classToId.put(Msg.CSSkillOpen.class, CSSkillOpen);
		classToId.put(Msg.SCSkillResult.class, SCSkillResult);
		classToId.put(Msg.CSSikllUpgrade.class, CSSikllUpgrade);
		classToId.put(Msg.SCSkillUpgradeResult.class, SCSkillUpgradeResult);
		classToId.put(Msg.SCNewSkillResult.class, SCNewSkillResult);
		classToId.put(Msg.CSSkillBoardOpen.class, CSSkillBoardOpen);
		classToId.put(Msg.SCSkillBoardOpenResult.class, SCSkillBoardOpenResult);
		classToId.put(Msg.CSSkillSet.class, CSSkillSet);
		classToId.put(Msg.SCSkillSetResult.class, SCSkillSetResult);
		classToId.put(Msg.SCSkillSequence.class, SCSkillSequence);
		classToId.put(Msg.CSFightPVPMatch.class, CSFightPVPMatch);
		classToId.put(Msg.SCFightPVPMatchResult.class, SCFightPVPMatchResult);
		classToId.put(Msg.CSFightPVPStart.class, CSFightPVPStart);
		classToId.put(Msg.SCFightPVPStartResult.class, SCFightPVPStartResult);
		classToId.put(Msg.CSTest.class, CSTest);
		classToId.put(Msg.SCTest.class, SCTest);
	}
	
	/**
	 * 初始化消息ID与消息CLASS的对应关系
	 */
	private static void initIdToClass() {
		idToClass.put(CSLogin, Msg.CSLogin.class);
		idToClass.put(SCLoginResult, Msg.SCLoginResult.class);
		idToClass.put(CSAccountReconnect, Msg.CSAccountReconnect.class);
		idToClass.put(SCAccountReconnectResult, Msg.SCAccountReconnectResult.class);
		idToClass.put(CSQueryCharacters, Msg.CSQueryCharacters.class);
		idToClass.put(SCQueryCharactersResult, Msg.SCQueryCharactersResult.class);
		idToClass.put(CSCharacterCreate, Msg.CSCharacterCreate.class);
		idToClass.put(SCCharacterCreateResult, Msg.SCCharacterCreateResult.class);
		idToClass.put(CSCharacterDelete, Msg.CSCharacterDelete.class);
		idToClass.put(SCCharacterDeleteResult, Msg.SCCharacterDeleteResult.class);
		idToClass.put(CSCharacterLogin, Msg.CSCharacterLogin.class);
		idToClass.put(SCCharacterLoginResult, Msg.SCCharacterLoginResult.class);
		idToClass.put(SCInitData, Msg.SCInitData.class);
		idToClass.put(SCHumanKick, Msg.SCHumanKick.class);
		idToClass.put(SCHumanInfoChange, Msg.SCHumanInfoChange.class);
		idToClass.put(SCStageObjectInfoChange, Msg.SCStageObjectInfoChange.class);
		idToClass.put(CSStageEnter, Msg.CSStageEnter.class);
		idToClass.put(SCStageEnterResult, Msg.SCStageEnterResult.class);
		idToClass.put(CSStageSwitch, Msg.CSStageSwitch.class);
		idToClass.put(SCStageSwitch, Msg.SCStageSwitch.class);
		idToClass.put(CSStageMove, Msg.CSStageMove.class);
		idToClass.put(SCStageMove, Msg.SCStageMove.class);
		idToClass.put(SCStageSetPos, Msg.SCStageSetPos.class);
		idToClass.put(CSStageMoveStop, Msg.CSStageMoveStop.class);
		idToClass.put(SCStageMoveStop, Msg.SCStageMoveStop.class);
		idToClass.put(SCStageObjectAppear, Msg.SCStageObjectAppear.class);
		idToClass.put(SCStageObjectDisappear, Msg.SCStageObjectDisappear.class);
		idToClass.put(SCStageMoveTeleport, Msg.SCStageMoveTeleport.class);
		idToClass.put(CSStageMove2, Msg.CSStageMove2.class);
		idToClass.put(SCStagePullTo, Msg.SCStagePullTo.class);
		idToClass.put(CSFightAtk, Msg.CSFightAtk.class);
		idToClass.put(SCFightAtkResult, Msg.SCFightAtkResult.class);
		idToClass.put(SCFightSkill, Msg.SCFightSkill.class);
		idToClass.put(SCFightHpChg, Msg.SCFightHpChg.class);
		idToClass.put(CSFightRevive, Msg.CSFightRevive.class);
		idToClass.put(SCFightStageChange, Msg.SCFightStageChange.class);
		idToClass.put(SCFightDotHpChg, Msg.SCFightDotHpChg.class);
		idToClass.put(SCBuffAdd, Msg.SCBuffAdd.class);
		idToClass.put(SCBuffUpdate, Msg.SCBuffUpdate.class);
		idToClass.put(SCBuffDispel, Msg.SCBuffDispel.class);
		idToClass.put(CSBuffDispelByHuman, Msg.CSBuffDispelByHuman.class);
		idToClass.put(CSSkillOpen, Msg.CSSkillOpen.class);
		idToClass.put(SCSkillResult, Msg.SCSkillResult.class);
		idToClass.put(CSSikllUpgrade, Msg.CSSikllUpgrade.class);
		idToClass.put(SCSkillUpgradeResult, Msg.SCSkillUpgradeResult.class);
		idToClass.put(SCNewSkillResult, Msg.SCNewSkillResult.class);
		idToClass.put(CSSkillBoardOpen, Msg.CSSkillBoardOpen.class);
		idToClass.put(SCSkillBoardOpenResult, Msg.SCSkillBoardOpenResult.class);
		idToClass.put(CSSkillSet, Msg.CSSkillSet.class);
		idToClass.put(SCSkillSetResult, Msg.SCSkillSetResult.class);
		idToClass.put(SCSkillSequence, Msg.SCSkillSequence.class);
		idToClass.put(CSFightPVPMatch, Msg.CSFightPVPMatch.class);
		idToClass.put(SCFightPVPMatchResult, Msg.SCFightPVPMatchResult.class);
		idToClass.put(CSFightPVPStart, Msg.CSFightPVPStart.class);
		idToClass.put(SCFightPVPStartResult, Msg.SCFightPVPStartResult.class);
		idToClass.put(CSTest, Msg.CSTest.class);
		idToClass.put(SCTest, Msg.SCTest.class);
	}
}

