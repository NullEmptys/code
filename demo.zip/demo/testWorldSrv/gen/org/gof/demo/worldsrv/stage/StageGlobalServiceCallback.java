package org.gof.demo.worldsrv.stage;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class StageGlobalServiceCallback {
	public static final String _result_login = "_result_login";
	public static final String _result_switchToStage = "_result_switchToStage";
}
