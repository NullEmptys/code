package org.gof.seam.account;

import org.gof.core.gen.callback.GenCallbackFile;

@GenCallbackFile
public class AccountMsgHandlerCallback {
	public static final String _result_onCSAccountReconnect = "_result_onCSAccountReconnect";
	public static final String _result_onCSCharacterCreate = "_result_onCSCharacterCreate";
}
