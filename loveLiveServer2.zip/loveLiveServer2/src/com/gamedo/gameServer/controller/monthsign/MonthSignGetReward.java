package com.gamedo.gameServer.controller.monthsign;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.mothsign.MonthSignData;
import com.gamedo.gameServer.entity.monthsign.PlayerMonthSignRec;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.monthsign.GetMonthSignRewardRequestMessage;
import com.gamedo.gameServer.message.monthsign.MonthSignRewardResponseMessage;
import com.gamedo.gameServer.service.monthsign.MonthSignService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.DateUtil;
/**
 * 领取月签奖励
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = OpCode.MONTH_SING_REWARD)
public class MonthSignGetReward extends AbstractController{
	@Autowired
	private PlayerService playerService;
	@Autowired
	private MonthSignService monthSignService;
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.MONTH_SING_REWARD,request,response);
		GetMonthSignRewardRequestMessage requestMessage = (GetMonthSignRewardRequestMessage) packet.getRequestMessage(GetMonthSignRewardRequestMessage.class);
		MonthSignRewardResponseMessage responseMessage = new MonthSignRewardResponseMessage();
		int day = requestMessage.getDay();
		int month = requestMessage.getMonth();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		PlayerMonthSignRec playerMonthSignRec = monthSignService.getPlayerMonthSignRec(player.getId()); // 玩家月签数据
		Map<Integer,MonthSignData> MonthSignDatas = monthSignService.getMonthSignData();

		// 检查领取策划数据
		if (MonthSignDatas == null || !MonthSignDatas.containsKey(day)) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUNT_MONTSIGN_DATA);
			packet.send(responseMessage);
			return;
		}
		if (DateUtil.getMonth(new Date()) != month) {// 跨月的需重刷界面
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NEED_RESET_DATA);
			packet.send(responseMessage);
			return;
		}
		List<Integer> monthSignRec = monthSignService.StringToList(playerMonthSignRec.getMonthSignStr());
		if(monthSignRec != null){
			if (monthSignRec.contains(day)) {// 已经领取过
				responseMessage.setCode(CommonResponseMessage.FALSE);
				responseMessage.setDesc(I18NMessage.IS_GET_DAY_REWARD);
				packet.send(responseMessage);
				return;
			}
		}
		int CanGetday = monthSignService.playerMaxGetDay(playerMonthSignRec);// 可以领取天数上限(累计签到天数)
		if (day > CanGetday) {// 未累积到天数
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_REACH_DAY);
			packet.send(responseMessage);
			return;
		}
		MonthSignData monthSignData = MonthSignDatas.get(day);
		player.getBags().addItem(monthSignData.getItemid(), monthSignData.getNum(), "MonthSignGetReward");
		String getList = null;
		if(playerMonthSignRec.getMonthSignStr() != null){
			getList=playerMonthSignRec.getMonthSignStr() + "," + day;
		}else{
			getList =day + "";
		}
		monthSignService.updatePlayerMonthSignRec(getList,player.getId());
		responseMessage.setCode(CommonResponseMessage.TRUE);
		responseMessage.setItmeId(monthSignData.getItemid());
		responseMessage.setItemNum(monthSignData.getNum());
		packet.send(responseMessage);
	}

}
