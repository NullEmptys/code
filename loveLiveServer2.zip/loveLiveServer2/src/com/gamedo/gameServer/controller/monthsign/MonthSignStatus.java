package com.gamedo.gameServer.controller.monthsign;

import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.monthsign.PlayerMonthSignRec;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.monthsign.MonthSignViewResponseMessage;
import com.gamedo.gameServer.service.monthsign.MonthSignService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.DateUtil;
/**
 * 月签
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = OpCode.MONTH_SIGN_VIEW)
public class MonthSignStatus extends AbstractController{
	@Autowired
	private PlayerService playerService;
	@Autowired
	private MonthSignService monthSignService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.MONTH_SIGN_VIEW,request,response);
		CommonRequestMessage requestMessage = (CommonRequestMessage) packet.getRequestMessage(CommonRequestMessage.class);
		MonthSignViewResponseMessage message = new MonthSignViewResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		PlayerMonthSignRec playerMonthSignRec = monthSignService.getPlayerMonthSignRec(requestMessage.getPlayerID());
		Date now = new Date();
		int dayNum = monthSignService.playerMaxGetDay(playerMonthSignRec);// 当前可领取天数上限(累计天数)
		message.setMonths(DateUtil.getMonth(now));
		message.setGetDayList(monthSignService.StringToList(playerMonthSignRec.getMonthSignStr()));
		message.setGainDay(dayNum);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}
	
}
