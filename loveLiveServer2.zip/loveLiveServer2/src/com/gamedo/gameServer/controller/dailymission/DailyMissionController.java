package com.gamedo.gameServer.controller.dailymission;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.dailyMission.DailyMissionActiveReward;
import com.gamedo.gameServer.entity.dailymission.PlayerActive;
import com.gamedo.gameServer.entity.dailymission.PlayerDailyMission;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.dailyMission.BoxStatus;
import com.gamedo.gameServer.message.dailyMission.DailyMissionData;
import com.gamedo.gameServer.message.dailyMission.DailyMissionResponseMessage;
import com.gamedo.gameServer.message.dailyMission.DayActiveDataMessage;
import com.gamedo.gameServer.service.dailymission.DailyMissionService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.DateUtil;

@Controller
@RequestMapping(value = OpCode.DAILY_MISSION)
public class DailyMissionController extends AbstractController{
	
	@Autowired
	private PlayerService playerService;
	@Autowired
	private DailyMissionService dailyMissionService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.DAILY_MISSION,request,response);
		CommonRequestMessage requestMessage = (CommonRequestMessage) packet.getRequestMessage(CommonRequestMessage.class);
		DailyMissionResponseMessage responseMessage = new DailyMissionResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		List<PlayerDailyMission> dailyMission = dailyMissionService.getPlayerDailMissionByPlayer(player);
		List<DailyMissionData> clientMissionData = new ArrayList<>();
		List<Integer> allMission = new ArrayList<>();//玩家所有任务
		List<Integer> deleteMission = new ArrayList<>();//删除任务
		List<Integer> addMission = new ArrayList<>();//新增任务
		for(PlayerDailyMission playDailMission : dailyMission){
			if(dailyMissionService.getDailyMissionByDefineId(playDailMission.getMissionDefineId()) == null){
				deleteMission.add(playDailMission.getMissionDefineId());
				continue;
			}
			DailyMissionData dailyMissionData = new DailyMissionData();
			dailyMissionData.setMissionDefineId(playDailMission.getMissionDefineId());
			dailyMissionData.setMissionDetail(playDailMission.getMissionDetail());
			dailyMissionData.setStatus(playDailMission.getStatus());
			clientMissionData.add(dailyMissionData);
			allMission.add(playDailMission.getMissionDefineId());
		}
		if(dailyMissionService.getDailyMission().size() > dailyMission.size()){
			for(Integer missionIds : dailyMissionService.getDailyMission().keySet()){
				if(!allMission.contains(missionIds)){
					addMission.add(missionIds);
				}
			}
		}
		//删除任务
		if(deleteMission != null && deleteMission.size() > 0){
			dailyMissionService.deletePlayerDailyMission(player, deleteMission);
		}
		//添加任务
		if(addMission != null && addMission.size() > 0 ){
			dailyMissionService.addPlayerDailyMission(player, addMission);
		}
		PlayerActive playerActive = dailyMissionService.getPlayerDailyMissionActiveRec(player.getId());
		List<BoxStatus> boxs = new ArrayList<>();
		Map<Integer,DailyMissionActiveReward> dailyActiveMap = dailyMissionService.getDailyActiveMap(PlayerActive.DAILY_REWARD);
		for(int activeValue: dailyActiveMap.keySet()){
			BoxStatus boxStatus = new BoxStatus();
			boxStatus.setBoxId(dailyActiveMap.get(activeValue).getId());
			List<Integer> rewrds =DateUtil.StringToList(playerActive.getDailyRewards());
			if(rewrds != null && rewrds.contains(dailyActiveMap.get(activeValue).getNeedActive())){
				boxStatus.setStatus(PlayerDailyMission.STATUS_END);
			}else if(playerActive.getDailyActiveValue() >= dailyActiveMap.get(activeValue).getNeedActive()){
				boxStatus.setStatus(PlayerDailyMission.STATUS_FINISHED);
			}else{
				boxStatus.setStatus(PlayerDailyMission.STATUS_STARTED);
			}
			boxs.add(boxStatus);
		}
		Map<Integer,DailyMissionActiveReward> weekActiveMap = dailyMissionService.getDailyActiveMap(PlayerActive.WEEK_REWARD);
		for(int activeValue: weekActiveMap.keySet()){
			BoxStatus boxStatus = new BoxStatus();
			boxStatus.setBoxId(weekActiveMap.get(activeValue).getId());
			List<Integer> rewrds = DateUtil.StringToList(playerActive.getWeekRewards());
			if(rewrds != null && rewrds.contains(weekActiveMap.get(activeValue).getNeedActive())){
				boxStatus.setStatus(PlayerDailyMission.STATUS_END);
			}else if(playerActive.getWeekActiveValue() >= weekActiveMap.get(activeValue).getNeedActive()){
				boxStatus.setStatus(PlayerDailyMission.STATUS_FINISHED);
			}else{
				boxStatus.setStatus(PlayerDailyMission.STATUS_STARTED);
			}
			boxs.add(boxStatus);
		}
		DayActiveDataMessage playerData = new DayActiveDataMessage();
		playerData.setDailyActiveValue(playerActive.getDailyActiveValue());
		playerData.setWeekActiveValue(playerActive.getWeekActiveValue());
		playerData.setBoxStatus(boxs);
		responseMessage.setDailyMission(clientMissionData);
		responseMessage.setPlayerActive(playerData);
		responseMessage.setCode(CommonResponseMessage.TRUE);
		packet.send(responseMessage);
	}
	
}
