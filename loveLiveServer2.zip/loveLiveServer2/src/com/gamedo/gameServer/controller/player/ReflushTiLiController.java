package com.gamedo.gameServer.controller.player;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.PlayerLevelInfo;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.FlushTiLiResponseMessage;
import com.gamedo.gameServer.service.data.DataService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;
import com.gamedo.gameServer.util.DateUtil;

@Controller
@RequestMapping(value = OpCode.FLUSH_TILI_VALUE)
public class ReflushTiLiController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private DataService dataService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.FLUSH_TILI_VALUE, request, response);
		CommonRequestMessage requestMessage = (CommonRequestMessage) packet
				.getRequestMessage(CommonRequestMessage.class);
		FlushTiLiResponseMessage message = new FlushTiLiResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		PlayerLevelInfo playerLevelInfo = dataService.getPlayerLevelInfo(player.getLevel());
		if (playerLevelInfo == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		if (player.getTili() >= playerLevelInfo.getMaxTiLi()) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		long flushTime = player.getPool().getLong(Const.PROPERTY_PLAYER_TILI_FLUSH_TIME, 0);
		if(flushTime != 0 ){
			Date date = new Date(flushTime);
			int time = DateUtil.getDateDiff(date);
			if(time < (playerLevelInfo.getRecoverTime() - 1)*60*1000){
				message.setCode(CommonResponseMessage.FALSE);
				packet.send(message);
				return;
			}
		}
		PlayerTransaction tx = player.newTransaction("autoRecover");
		player.addTiLi(1, tx, false);
		tx.commit();
		message.setCode(CommonResponseMessage.TRUE);
		message.setTiLiValue(player.getTili());
		if (player.getTili() < playerLevelInfo.getMaxTiLi()) {
			message.setNextFlushValue(System.currentTimeMillis() + playerLevelInfo.getRecoverTime() * 60 * 1000);
			player.getPool().setLong(Const.PROPERTY_PLAYER_TILI_TIME,
					System.currentTimeMillis() + playerLevelInfo.getRecoverTime() * 60 * 1000);
			player.getPool().setLong(Const.PROPERTY_PLAYER_TILI_FLUSH_TIME, System.currentTimeMillis());
		} else {
			player.getPool().setLong(Const.PROPERTY_PLAYER_TILI_TIME, 0);
			message.setNextFlushValue(0);
		}
		message.setUpdateObj(player.changed.sendAndClean());
		packet.send(message);
		playerService.updatePlayer(player);
	}

}
