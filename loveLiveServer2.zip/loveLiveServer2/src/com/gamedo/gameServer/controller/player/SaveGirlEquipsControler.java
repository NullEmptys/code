package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.girl.SaveGirlEquipsRequestMessage;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 保存玩家指定模特当前所穿服装
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.SAVE_GIRL_CLOTH)
public class SaveGirlEquipsControler extends AbstractController {

	@Autowired
	private PlayerService playerService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.SAVE_GIRL_CLOTH, request, response);
		
		SaveGirlEquipsRequestMessage requestMessage = (SaveGirlEquipsRequestMessage) packet
				.getRequestMessage(SaveGirlEquipsRequestMessage.class);
		
		CommonResponseMessage message = new CommonResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setUpdateObj(player.changed.sendAndClean());
		packet.send(message);
		playerService.updatePlayer(player);
		
	}

}
