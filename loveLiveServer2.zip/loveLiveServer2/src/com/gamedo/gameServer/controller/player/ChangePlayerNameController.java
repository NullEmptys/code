package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.ChangeNameRequestMessage;
import com.gamedo.gameServer.message.player.ChangeNameResponseMessage;
import com.gamedo.gameServer.service.data.keyWord.IStringValidator;
import com.gamedo.gameServer.service.data.keyWord.KeyWordService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

/**
 * 修改角色名称
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.CHANGE_PLAYER_NAME)
public class ChangePlayerNameController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private KeyWordService keyWordService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		Packet packet = new Packet(OpCode.CHANGE_PLAYER_NAME, request, response);

		ChangeNameRequestMessage requestMessage = (ChangeNameRequestMessage) packet
				.getRequestMessage(ChangeNameRequestMessage.class);
		
		ChangeNameResponseMessage message = new ChangeNameResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		if(requestMessage.getPlayerName() == null || "".equals(requestMessage.getPlayerName())) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.PLAYER_NAME_IS_NULL);
			packet.send(message);
			return;
		}
		
		Player playerTemp = playerService.findPlayer(requestMessage.getPlayerName());
		if(playerTemp != null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.PLAYER_NAME_REPEAT);
			packet.send(message);
			return;
		}
		
		int valid = keyWordService.isValidName(requestMessage.getPlayerName());
		if(valid == IStringValidator.OK) {
			int changeNameCounts = player.getPool().getInt(Const.PROPERTY_CHANGE_PLAYERNAME_COUNTS);
			if(changeNameCounts > 0) {
				PlayerTransaction tx = player.newTransaction("修改角色名称");
				try {
					player.decMoney(PlayerService.CHANGE_NAME_MONEY, tx, false);
					tx.commit();
				} catch (NoEnoughValueException e) {
					tx.rollback();
					e.printStackTrace();
					message.setCode(CommonResponseMessage.FALSE);
					message.setDesc(I18NMessage.NO_ENOUGH_MONEY);
					packet.send(message);
					return;
				}
			}
			player.getPool().setInt(Const.PROPERTY_CHANGE_PLAYERNAME_COUNTS, changeNameCounts + 1);
			player.setName(requestMessage.getPlayerName());
			message.setCode(CommonResponseMessage.TRUE);
			message.setChangeNameCounts(player.getPool().getInt(Const.PROPERTY_CHANGE_PLAYERNAME_COUNTS));
		}else {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(keyWordService.getValidatorMessage(valid));
		}
		message.setUpdateObj(player.changed.sendAndClean());
		packet.send(message);
		playerService.updatePlayer(player);
	}

}
