package com.gamedo.gameServer.controller.player;

import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.uploadavatar.UploadAvatarRequestMessage;
import com.gamedo.gameServer.message.uploadavatar.UploadAvatarResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.DateUtil;

/**
 * 上传头像
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.UPLOAD_AVATAR)
public class UploadAvatarController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.UPLOAD_AVATAR, request, response);
		UploadAvatarRequestMessage requestMessage = (UploadAvatarRequestMessage) packet
				.getRequestMessage(UploadAvatarRequestMessage.class);
		UploadAvatarResponseMessage message = new UploadAvatarResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		String beforeAvatarUrl = null;
		if(player.getAvatarUrl() != null){
			beforeAvatarUrl = player.getAvatarUrl().split(";")[0];
		}
		StringBuilder sb = new StringBuilder();
		sb.append(requestMessage.getAvrtarUrl());
		sb.append(";");
		sb.append(DateUtil.getDateString(new Date()));
		player.setAvatarUrl(sb.toString());
		playerService.updatePlayer(player);
		message.setCode(CommonResponseMessage.TRUE);
		if(beforeAvatarUrl != null){
			message.setBeforeAvatar(beforeAvatarUrl);
		}
		packet.send(message);
	}

}
