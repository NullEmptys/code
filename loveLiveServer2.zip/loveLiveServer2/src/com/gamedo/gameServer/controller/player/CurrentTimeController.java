package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.player.CurrentTimeResponseMessage;
import com.gamedo.gameServer.service.data.DataService;

/**
 * 服务器当前时间
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.CURRENT_TIME)
public class CurrentTimeController extends AbstractController {

	@Autowired
	private DataService dataService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.CURRENT_TIME,request,response);
		CurrentTimeResponseMessage message = new CurrentTimeResponseMessage();
		message.setCode(CommonResponseMessage.TRUE);
		message.setCurrentTime(System.currentTimeMillis());
		message.setVersion(dataService.loginConfig.getVersion());
		packet.send(message);
	}

}
