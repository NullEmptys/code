package com.gamedo.gameServer.controller.player;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.BuyType;
import com.gamedo.gameServer.constant.Constants;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.BuyConfig;
import com.gamedo.gameServer.data.PlayerLevelInfo;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.BuyTiLiRequestMessage;
import com.gamedo.gameServer.message.player.ConfirmBuyTiLiResponseMessage;
import com.gamedo.gameServer.service.data.DataService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.update.UpdateObject;
import com.gamedo.gameServer.util.Const;

import gnu.trove.map.hash.TIntObjectHashMap;

/**
 * 确认购买体力
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.CONFIRM_BUY_TILI_OR_GOLD)
public class TiliAndGoldBuyController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private DataService dataService;
	@Autowired
	private EventManager eventManager;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.CONFIRM_BUY_TILI_OR_GOLD, request, response);
		BuyTiLiRequestMessage requestMessage = (BuyTiLiRequestMessage) packet
				.getRequestMessage(BuyTiLiRequestMessage.class);

		int id = requestMessage.getBuyPosition();
		ConfirmBuyTiLiResponseMessage message = new ConfirmBuyTiLiResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		TIntObjectHashMap<BuyConfig> buyConfig = dataService.getBuyTiLiAndGoldConfig();
		PlayerLevelInfo levelInfo = dataService.getPlayerLevelInfo(player.getLevel());
		if (buyConfig == null || levelInfo == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		BuyConfig config = buyConfig.get(id);
		if (config == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}

		List<UpdateObject> updates = null;
		if (config.getBuyType() == BuyType.BUY_TILI.getId()) {
			// 当天已购买体力次数
			int buyTiLicounts = player.getPool().getInt(Const.PROPERTY_PLAYER_BUY_TILI_COUNT, 0);
			if (config.getTime() != buyTiLicounts + 1) {
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.DATA_EXCEPTION);
				packet.send(message);
				return;
			}
			int addTili = config.getBaseValue() + config.getExtraValue();
			if (player.getTili() + addTili > levelInfo.getLimitTiLi()) {
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.TI_LI_LIMIT);
				packet.send(message);
				return;
			}
			PlayerTransaction tx = player.newTransaction("buyTiLi");
			try {
				player.decMoney(config.getConsumeItemNum(), tx, true);
				player.addTiLi(addTili, tx, false);
				tx.commit();
				player.getPool().setInt(Const.PROPERTY_PLAYER_BUY_TILI_COUNT, buyTiLicounts + 1);

				eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_BUY_TILI, player));
				playerService.checkTiLi(player);

				updates = player.changed.sendAndClean();
				playerService.updatePlayer(player);
				message.setBuyCount(player.getPool().getInt(Const.PROPERTY_PLAYER_BUY_TILI_COUNT, 0) + 1);
			} catch (NoEnoughValueException e) {
				tx.rollback();
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.NO_ENOUGH_MONEY);
				packet.send(message);
				return;
			}
		} else if (config.getBuyType() == BuyType.BUY_GOLD.getId()) {
			int buyGoldCounts = player.getPool().getInt(Const.PROPERTY_PLAYER_BUY_GOLD_COUNT, 0);
			if (config.getTime() != buyGoldCounts + 1) {
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.DATA_EXCEPTION);
				packet.send(message);
				return;
			}
			PlayerTransaction tx = player.newTransaction("buyGold");
			try {
				player.decMoney(config.getConsumeItemNum(), tx, true);
				player.addGold(config.getBaseValue() + config.getExtraValue(), tx, false);
				tx.commit();
				eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_BUY_GOLD, player));
				player.getPool().setInt(Const.PROPERTY_PLAYER_BUY_GOLD_COUNT, buyGoldCounts + 1);
				updates = player.changed.sendAndClean();
				playerService.updatePlayer(player);

				message.setBuyCount(player.getPool().getInt(Const.PROPERTY_PLAYER_BUY_GOLD_COUNT, 0) + 1);
			} catch (NoEnoughValueException e) {
				tx.rollback();
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.NO_ENOUGH_MONEY);
				packet.send(message);
				return;
			}
		}

		message.setCode(CommonResponseMessage.TRUE);
		message.setUpdateObj(updates);
		packet.send(message);
	}

}
