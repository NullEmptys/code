package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.activity.ActivityService;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.CreatePlayerRequestMessage;
import com.gamedo.gameServer.message.player.CreatePlayerResponseMessage;
import com.gamedo.gameServer.service.announcement.AnnouncementService;
import com.gamedo.gameServer.service.data.keyWord.IStringValidator;
import com.gamedo.gameServer.service.data.keyWord.KeyWordService;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;

/**
 * 创建角色
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.CREATE_PLAYER)
public class CreatePlayerController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private KeyWordService keyWordService;
	@Autowired
	private GirlService girlService;
	@Autowired
	private QuestService questService;
	@Autowired
	private EventManager eventManager;
	@Autowired
	private ActivityService activityService;
	@Autowired
	private AnnouncementService announcementService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		Packet packet = new Packet(OpCode.CREATE_PLAYER, request, response);

		CreatePlayerRequestMessage requestMessage = (CreatePlayerRequestMessage) packet
				.getRequestMessage(CreatePlayerRequestMessage.class);

		CreatePlayerResponseMessage message = new CreatePlayerResponseMessage();

		String userName = requestMessage.getUserName();// 账号名称
		String playerName = requestMessage.getPlayerName();// 角色名称

		if (userName == null || "".equals(userName)) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.LOGIN_PLAYER_DESC);
			packet.send(message);
			return;
		}

		int valid = keyWordService.isValidName(playerName);

		if (valid == IStringValidator.OK) {
			if (playerService.getPlayerByAccountName(userName, requestMessage.getChannelId()) == null) {

				if (playerService.findPlayer(playerName) == null) {
					Player player = playerService.createPlayer(userName, playerName, requestMessage.getIconId(),
							requestMessage.getChannelId(),requestMessage.getSubChannelId());
					player.setRegistIp(packet.getIpAddr());
					player.setLastLoginIp(packet.getIpAddr());
					player.setTotalLoginCounts(player.getTotalLoginCounts() + 1);

					message.setCode(CommonResponseMessage.TRUE);
					message.setDesc(I18NMessage.CREATE_PLAYER_SUCCESS);

					// TODO 创建成功后直接登录
					message.setCurrentTime(System.currentTimeMillis());// 当前服务器时间
					message.setBaseData(player.getPlayerBaseData());
					message.setBagData(player.getPlayerBagData());
//					message.setGirlData(girlService.getPlayerGirlDatas(player));
					// message.setQuestData(questService.getPlayerQuestDatas(player.getId()));
					message.setActivityData(activityService.getActivityData());
					message.setSevenLoginRewardData(activityService.getSevenLoginRewardData(player));
					message.setAnnouncements(announcementService.getAnnouncementData());
					eventManager.addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_LOGINED, player));
					
					playerService.playerLogin(player);
					playerService.updatePlayer(player);
				} else {
					message.setCode(CommonResponseMessage.FALSE);
					message.setDesc(I18NMessage.PLAYER_NAME_REPEAT);
				}
			} else {
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.ALREADY_CREATED);
			}
		} else {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(keyWordService.getValidatorMessage(valid));
		}
		packet.send(message);
	}

}
