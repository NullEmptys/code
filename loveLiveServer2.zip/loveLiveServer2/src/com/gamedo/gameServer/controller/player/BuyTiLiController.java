package com.gamedo.gameServer.controller.player;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.TiLiInfo;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.BuyTiLiResponseMessage;
import com.gamedo.gameServer.service.data.DataService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

/**
 * 购买体力
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.BUY_TILI)
public class BuyTiLiController extends AbstractController{

	@Autowired
	private PlayerService playerService;
	@Autowired
	private DataService dataService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.BUY_TILI,request,response);
		CommonRequestMessage requestMessage = (CommonRequestMessage) packet.getRequestMessage(CommonRequestMessage.class);
		BuyTiLiResponseMessage message = new BuyTiLiResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		//当天已购买体力次数
		int buyTiLicounts = player.getPool().getInt(Const.PROPERTY_PLAYER_BUY_TILI_COUNT, 0);
		
		int maxBuyCounts = dataService.getMaxBuyCounts();//每日最大可购买体力次数
		
		if(buyTiLicounts >= maxBuyCounts) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.BUY_TILI_DESC);
			packet.send(message);
			return;
		}
		
		TiLiInfo info = dataService.getTiLiInfo(buyTiLicounts + 1);
		if(info == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		
		message.setCanBuyCounts(maxBuyCounts - buyTiLicounts);
		message.setTili(10);
		message.setAttributeType(info.getAttributeType());
		message.setValue(info.getValue());
		message.setCode(CommonResponseMessage.TRUE);
		message.setUpdateObj(player.changed.sendAndClean());
		packet.send(message);
	}

}
