package com.gamedo.gameServer.controller.update;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.SyncDataRequestMessage;
import com.gamedo.gameServer.message.player.SyncDataResponseMessage;
import com.gamedo.gameServer.service.dailymission.DailyMissionService;
import com.gamedo.gameServer.service.data.DataService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.update.UpdateObject;
import com.gamedo.gameServer.util.Const;

/**
 * 获取同步数据
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.SYNC_DATA)
public class SyncDataController extends AbstractController{

	@Autowired
	private PlayerService playerService;
	@Autowired
	private DailyMissionService dailyMissionService;
	@Autowired
	private DataService dataService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.SYNC_DATA, request, response);
		
		SyncDataRequestMessage requestMessage = (SyncDataRequestMessage) packet
				.getRequestMessage(SyncDataRequestMessage.class);
		SyncDataResponseMessage message = new SyncDataResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		String token = requestMessage.getToken();
		String lastToken = player.getPool().getString(Const.PROPERTY_LAST_LOGIN_TOKEN);
		if(token == null || "".equals(token)) {
			message.setCode(CommonResponseMessage.TOKEN_ERROR);
			message.setDesc("无效token,请重新登录！");
			packet.send(message);
			return;
		}
		if(!token.equals(lastToken)) {
			System.out.println("==============================lastToken = " + lastToken + ",token = " + token);
			message.setCode(CommonResponseMessage.TOKEN_ERROR);
			message.setDesc("当前账号在另一设备上登录");
			packet.send(message);
			return;
		}
		
		playerService.checkPlayerData(player);
		dailyMissionService.resetDailyMissions(player);
		
		player.setLastOperateTime(System.currentTimeMillis());
		message.setCode(CommonResponseMessage.TRUE);
		message.setVersion(dataService.loginConfig.getVersion());
		List<UpdateObject> updates = player.changed.sendAndClean();
		message.setUpdateObj(updates);
		packet.send(message);
		if(updates!= null && updates.size() > 0) {
			playerService.updatePlayer(player);
		}
	}

}
