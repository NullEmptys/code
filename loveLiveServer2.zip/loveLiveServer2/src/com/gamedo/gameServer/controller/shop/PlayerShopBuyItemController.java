package com.gamedo.gameServer.controller.shop;

import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.constant.Shop;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.shop.ShopItem;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.shop.PlayerItemShop;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.shop.BuyPlayerShopItemResponsetMessage;
import com.gamedo.gameServer.message.shop.PlayerShopBuyItemRequestMessage;
import com.gamedo.gameServer.message.shop.ShopBuyItemRequestMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.shop.ShopService;

/**
 * 购买道具商城道具
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.BUY_PLAYER_SHOP_ITEM)
public class PlayerShopBuyItemController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private ShopService shopService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
	
		Packet packet = new Packet(OpCode.BUY_PLAYER_SHOP_ITEM, request, response);

		PlayerShopBuyItemRequestMessage requestMessage = (PlayerShopBuyItemRequestMessage) packet
				.getRequestMessage(PlayerShopBuyItemRequestMessage.class);
		
		BuyPlayerShopItemResponsetMessage message = new BuyPlayerShopItemResponsetMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		ShopItem shopItem = shopService.shopItems.get(Shop.ITEM_SHOP.getShopId()).get(requestMessage.getId());
		if(shopItem == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_CHOOSE_ITEM);
			packet.send(message);
			return;
		}
		
		ConcurrentHashMap<Integer, PlayerItemShop> playerItems = shopService.getPlayerShopItems(player.getId());
		PlayerItemShop playerItem = playerItems.get(requestMessage.getInstanceId());
		if(playerItem == null || playerItem.getShopItemId() != shopItem.getId()) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_CHOOSE_ITEM);
			packet.send(message);
			return;
		}
		
		if(!(playerItem.getBuyCounts() < shopItem.getCanBuyCount())) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.CURRENT_PERIOD_MAX_COUNTS);
			packet.send(message);
			return;
		}
		
		PlayerTransaction tx = player.newTransaction("buyPlayerShopItem");
		try {
			player.decCurrency(AttributeType.getAttrtType(shopItem.getConsumeType()), shopItem.getConsumeNum(), tx, false);
			player.getBags().addItem(shopItem.getItemId(), 1, tx.getCause());
			tx.commit();
			playerItem.setBuyCounts(playerItem.getBuyCounts() + 1);
			shopService.updatePlayerItemShop(playerItem);
			
			message.setCode(CommonResponseMessage.TRUE);
			message.setInstanceId(playerItem.getId());
			message.setId(shopItem.getId());
			message.setCanBuyCount(shopItem.getCanBuyCount() - playerItem.getBuyCounts());
			message.setUpdateObj(player.changed.sendAndClean());
			
			packet.send(message);
			playerService.updatePlayer(player);
			
		} catch (NoEnoughValueException e) {
			tx.rollback();
			e.printStackTrace();
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
			packet.send(message);
			return;
		}
		
	}

}
