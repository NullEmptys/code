package com.gamedo.gameServer.controller.shop;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.shop.RefreshShopItemData;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.shop.PlayerItemShop;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.shop.RefreshPlayerShopRequestMessage;
import com.gamedo.gameServer.message.shop.ShopItemData;
import com.gamedo.gameServer.message.shop.ShopListResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.shop.ShopService;
import com.gamedo.gameServer.util.Const;

/**
 * 刷新玩家道具商城
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.REFRESH_PLAYER_SHOP_ITEM)
public class RefreshPlayerShopItemController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private ShopService shopService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.REFRESH_PLAYER_SHOP_ITEM, request, response);
		RefreshPlayerShopRequestMessage requestMessage = (RefreshPlayerShopRequestMessage) packet
				.getRequestMessage(RefreshPlayerShopRequestMessage.class);

		ShopListResponseMessage message = new ShopListResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		int refreshCount = player.getPlayerRefreshPlayerShopCounts();
		RefreshShopItemData refreshData = getRefreshShopItemData(refreshCount);
		ConcurrentHashMap<Integer, PlayerItemShop> playerItems = shopService.getPlayerShopItems(player.getId());
		if(requestMessage.getRefreshType() == 1) {
			PlayerTransaction tx = player.newTransaction("refreshPlayerShop");
			try {
				player.decCurrency(AttributeType.getAttrtType(refreshData.getCurrencyType()),
						refreshData.getCurrencyCounts(), tx, false);
				tx.commit();
				playerItems = shopService.refreshPlayerShopItems(player.getId(), playerItems);
				player.setPlayerRefeshShopCounts(refreshCount + 1);
			} catch (NoEnoughValueException e) {
				tx.rollback();
				e.printStackTrace();
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
				packet.send(message);
				return;
			}
		}else {
			playerItems = shopService.checkPlayerItemShopRefresh(player);
		}
		List<ShopItemData> shopItems = shopService.getPlayerShopItemDatas(playerItems);
		message.setShopItems(shopItems);
		message.setUpdateObj(player.changed.sendAndClean());
		message.setNextRefreshTime(player.getPool().getLong(Const.NEXT_REFRESH_PLAYER_SHOP_DATE, 0));
		refreshData = getRefreshShopItemData(player.getPlayerRefreshPlayerShopCounts());
		message.setRefreshCurrencyType(refreshData.getCurrencyType());
		message.setRefreshCurrencyCounts(refreshData.getCurrencyCounts());
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
		playerService.updatePlayer(player);
	}

	private RefreshShopItemData getRefreshShopItemData(int refreshCount) {
		RefreshShopItemData refreshData = null;
		if(refreshCount + 1 < shopService.maxRefreshShopItemData.getRefreshCount()) {
			refreshData = shopService.refreshShopItemDatas.get(refreshCount + 1);
		}else {
			refreshData = shopService.maxRefreshShopItemData;
		}
		return refreshData;
	}
}
