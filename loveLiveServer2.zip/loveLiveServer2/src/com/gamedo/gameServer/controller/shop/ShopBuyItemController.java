package com.gamedo.gameServer.controller.shop;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.constant.Shop;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.item.Item;
import com.gamedo.gameServer.data.shop.ShopItem;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.shop.ShopBuyItemRequestMessage;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.shop.ShopService;

import gnu.trove.map.hash.TIntObjectHashMap;

/**
 * 购买商品
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.BUY_ITEM)
public class ShopBuyItemController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private ItemService itemService;
	@Autowired
	private ShopService shopService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		Packet packet = new Packet(OpCode.BUY_ITEM, request, response);

		ShopBuyItemRequestMessage requestMessage = (ShopBuyItemRequestMessage) packet
				.getRequestMessage(ShopBuyItemRequestMessage.class);

		CommonResponseMessage message = new CommonResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		Item item = itemService.getItemById(requestMessage.getItemId());
		if (item == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_ENGAGEMENT_SHOP_ITEM);
			packet.send(message);
			return;
		}
		TIntObjectHashMap<ShopItem> map = shopService.getShopItemsByShopId(Shop.CLOTH_SHOP.getShopId());
		ShopItem ClothShopConfig = null;
		for (ShopItem shopItem : map.valueCollection()) {
			if (shopItem.getItemId() == requestMessage.getItemId()) {
				ClothShopConfig = shopItem;
				if (shopItem.getLevel() > player.getLevel()) {
					message.setCode(CommonResponseMessage.FALSE);
					message.setDesc(I18NMessage.NOT_FOUND_ENGAGEMENT_SHOP_ITEM);
					packet.send(message);
					return;
				}
				break;
			}
		}
//		PlayerShopBuyRec playerShopBuyRec = shopService.getPlayerShopBuyRec(player.getId());
//		List<Integer> buyRec = JsonUtil.fromJsonList(playerShopBuyRec.getRec(), Integer.class);
//		if(buyRec == null){
//			buyRec = new ArrayList<>();
//		}
//		if (playerShopBuyRec != null && buyRec != null) {
//			if (buyRec.contains(requestMessage.getItemId())) {
//				message.setCode(CommonResponseMessage.FALSE);
//				message.setDesc(I18NMessage.NOT_FOUND_ENGAGEMENT_SHOP_ITEM);
//				packet.send(message);
//				return;
//			}
//		}
		boolean flag = true;
		String desc = "";
		PlayerTransaction tx = player.newTransaction("buyItem");
		try {
			player.decCurrency(AttributeType.getAttrtType(ClothShopConfig.getConsumeType()),
					ClothShopConfig.getConsumeNum(), tx, false);
			player.getBags().addItem(item.getId(), 1, "buyItem");
		} catch (NoEnoughValueException e) {
			flag = false;
			desc = I18NMessage.NO_ENOUGH_CURRENCY;
			e.printStackTrace();
		}
		if (flag) {
			tx.commit();
//			buyRec.add(requestMessage.getItemId());
//			playerShopBuyRec.setRec(JsonUtil.toJson(buyRec));
//			shopService.updatePlayerShopBuyRec(player.getId(), playerShopBuyRec);
			message.setCode(CommonResponseMessage.TRUE);
			message.setUpdateObj(player.changed.sendAndClean());
			packet.send(message);
			playerService.updatePlayer(player);
		} else {
			tx.rollback();
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(desc);
			packet.send(message);
		}
	}

}
