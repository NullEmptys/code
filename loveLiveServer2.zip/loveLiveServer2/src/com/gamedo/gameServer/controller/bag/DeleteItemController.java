package com.gamedo.gameServer.controller.bag;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.bag.DeleteItemRequestMessage;
import com.gamedo.gameServer.message.bag.DeleteItemResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.update.UpdateObject;

/**
 * 丢弃物品
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.DELETE_ITEM)
public class DeleteItemController extends AbstractController{

	@Autowired
	private PlayerService playerService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.DELETE_ITEM,request,response);
		DeleteItemRequestMessage requestMessage = (DeleteItemRequestMessage) packet.getRequestMessage(DeleteItemRequestMessage.class);
		
		DeleteItemResponseMessage message = new DeleteItemResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		PlayerTransaction tx = player.newTransaction("DELETE_ITEM");
		GameItem gameItem = player.getBags().removeGameItem(requestMessage.getItemId(), requestMessage.getInstanceId(), requestMessage.getCounts(), tx, false);
		List<UpdateObject> updates = null;
		if(gameItem != null) {
			tx.commit();
			updates = player.changed.sendAndClean();
			playerService.updatePlayer(player);
			message.setCode(CommonResponseMessage.TRUE);
		}else {
			tx.rollback();
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_ITEM);
		}
		message.setUpdateObj(updates);
		packet.send(message);
	}

}
