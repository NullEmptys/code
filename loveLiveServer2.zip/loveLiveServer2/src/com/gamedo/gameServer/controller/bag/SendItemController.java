package com.gamedo.gameServer.controller.bag;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.ItemCategory;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.Time;
import com.gamedo.gameServer.core.bag.BagGrid;
import com.gamedo.gameServer.core.bag.GirlBagChangedItem;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.item.ItemTemplate;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.bag.SendItemData;
import com.gamedo.gameServer.message.bag.SendItemRequestMessage;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 寄送服装给模特
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.SEND_ITEM)
public class SendItemController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private GirlService girlService;
	@Autowired
	private ItemService itemService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
//		Packet packet = new Packet(OpCode.SEND_ITEM, request, response);
//
//		SendItemRequestMessage requestMessage = (SendItemRequestMessage) packet
//				.getRequestMessage(SendItemRequestMessage.class);
//		CommonResponseMessage message = new CommonResponseMessage();
//		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
//		if (player == null) {
//			message.setCode(CommonResponseMessage.FALSE);
//			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
//			packet.send(message);
//			return;
//		}
//		PlayerGirl playerGirl = girlService.getPlayerGirl(requestMessage.getPlayerID(), requestMessage.getGirlId());
//		if (playerGirl == null) {
//			message.setCode(CommonResponseMessage.FALSE);
//			message.setDesc(I18NMessage.GIRL_UNLOCK);
//			packet.send(message);
//			return;
//		}
//		List<SendItemData> sendItems = requestMessage.getSendItems();
//		if (sendItems != null && sendItems.size() > 0) {
//			for (SendItemData sendItem : sendItems) {
//				if (sendItem != null) {
//					ItemTemplate itemTemplete = itemService.getItemTemplate(sendItem.getItemId());
//					if(itemTemplete != null && itemTemplete.getCategory() == ItemType.CONSUME.getItemType()) {
//						//消耗品不能赠送
//						continue;
//					}
//					PlayerTransaction tx = player.newTransaction("sendItem");
//					BagGrid bagGrid = player.getBags().getBag(sendItem.getBagId())
//							.removeGridGameItem(sendItem.getGridId(), sendItem.getItemId(), 0, 1, tx, false);
//					if (bagGrid != null && bagGrid.getItem() != null) {
//						GameItem item = bagGrid.getItem();
//						BagGrid girlBagGrid = playerGirl.getBags().getBag(sendItem.getBagId())
//								.getGameItem(item.getTemplate().getTempleteId());
//						if (girlBagGrid != null && girlBagGrid.getItem() != null) {
//							GameItem gameItem = girlBagGrid.getItem();
//							if(gameItem.getTemplate().getCategory() == ItemType.CLOTH.getItemType()) {//模特背包不能拥有相同动作
//								// 时效累加
//								if (gameItem.getObsoleteTime() >= 0) {
//									if (item.getTemplate().getObsoleteTime() > 0) {
//										gameItem.setObsoleteTime(
//												gameItem.getObsoleteTime() + item.getTemplate().getObsoleteTime());
//									} else {
//										gameItem.setObsoleteTime((int) (Time.currDate.getTime() / 1000
//												+ item.getTemplate().getObsoleteTime()));
//									}
//									playerGirl.defaultPlayer.changed
//									.addChangedItem(new GirlBagChangedItem(girlBagGrid, playerGirl.getGirlId()));
//									girlService.updatePlayerGirl(playerGirl);
//								}
//								tx.commit();
//							}else {
//								tx.rollback();
//							}
//						} else {
//							ItemTemplate template = itemService.getItemTemplate(item.getTemplate().getTempleteId());
//							GameItem itemTemp = itemService.createGameItem(template);
//							if (template.getCategory() == ItemType.CLOTH.getItemType()) {
//								if (item.getTemplate().getObsoleteTime() == -1) {
//									itemTemp.setObsoleteTime(item.getTemplate().getObsoleteTime());
//								} else {
//									itemTemp.setObsoleteTime((int) (Time.currDate.getTime() / 1000
//											+ item.getTemplate().getObsoleteTime()));
//								}
//							}
//							playerGirl.getBags().addGameItem(itemTemp, 1, tx, false);
//							tx.commit();
//							girlService.updatePlayerGirl(playerGirl);
//						}
//					} else {
//						tx.rollback();
//					}
//				}
//			}
//		}
//		message.setCode(CommonResponseMessage.TRUE);
//		message.setUpdateObj(playerService.sendAndClean(player.getId()));
//		packet.send(message);
//
//		playerService.updatePlayer(player);
	}

}
