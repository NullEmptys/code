package com.gamedo.gameServer.controller.bag;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.bag.BagGrid;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.bag.SellItemRequestMessage;
import com.gamedo.gameServer.message.bag.SellItemResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 出售物品
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.SELL_ITEM)
public class SellItemController extends AbstractController {

	@Autowired
	private PlayerService playerService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.SELL_ITEM, request, response);
		SellItemRequestMessage requestMessage = (SellItemRequestMessage) packet
				.getRequestMessage(SellItemRequestMessage.class);

		SellItemResponseMessage message = new SellItemResponseMessage();
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		PlayerTransaction tx = player.newTransaction("SELL_ITEM");
		BagGrid bagGrid = player.getBags().getBag(requestMessage.getBagId()).removeGridGameItem(
				requestMessage.getGridId(), requestMessage.getItemId(), requestMessage.getInstanceId(),
				requestMessage.getCount(), tx, false);
		if(bagGrid != null) {
			GameItem item = bagGrid.getItem();
			if(item == null) {
				tx.rollback();
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.SELL_ITEM_NOT_FOUND);
				packet.send(message);
				return;
			}
			if(!item.getTemplate().canSell()) {
				tx.rollback();
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc(I18NMessage.ITEM_NOT_SELL);
				packet.send(message);
				return;
			}
			int attributeType = item.getTemplate().currencyType();//出售后获得货币类型
			int price = item.getTemplate().getPrice();
			player.addAttributeByType(AttributeType.getAttrtType(attributeType),price * requestMessage.getCount(),tx);
			tx.commit();
			message.setCode(CommonResponseMessage.TRUE);
			message.setUpdateObj(player.changed.sendAndClean());
			playerService.updatePlayer(player);
		}else {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.SELL_ITEM_NOT_FOUND);
			message.setUpdateObj(player.changed.sendAndClean());
			packet.send(message);
			tx.rollback();
			return;
		}
		packet.send(message);
		playerService.updatePlayer(player);
	}

}
