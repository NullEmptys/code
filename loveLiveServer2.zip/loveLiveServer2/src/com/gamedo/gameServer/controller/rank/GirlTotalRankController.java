package com.gamedo.gameServer.controller.rank;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.rank.GirlTotalRankResponseMessage;
import com.gamedo.gameServer.message.rank.RankGirl;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.rank.RankService;
import com.gamedo.gameServer.util.CommonUtil;

/**
 * 模特使用率周榜
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.GIRL_TOTAL_RANK)
public class GirlTotalRankController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private RankService rankService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.GIRL_TOTAL_RANK, request, response);

		CommonRequestMessage requestMessage = (CommonRequestMessage) packet
				.getRequestMessage(CommonRequestMessage.class);

		GirlTotalRankResponseMessage message = new GirlTotalRankResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

//		List<RankGirl> rankDatas = rankService.getGirlUseRecordRankData();
//		message.setRankData(rankDatas);
		Date mondayDate = CommonUtil.getCurrentMonday();
		Date sundayDate = CommonUtil.getPreviousSunday();
		message.setStartMonth(mondayDate.getMonth() + 1);
		message.setStartDate(mondayDate.getDate());
		message.setEndMonth(sundayDate.getMonth() + 1);
		message.setEndDate(sundayDate.getDate());
		message.setCode(CommonResponseMessage.TRUE);
		message.setUpdateObj(player.changed.sendAndClean());
		packet.send(message);
	}

}
