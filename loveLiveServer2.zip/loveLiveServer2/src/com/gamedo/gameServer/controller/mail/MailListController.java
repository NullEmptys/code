package com.gamedo.gameServer.controller.mail;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.mail.Mail;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.mail.MailInfo;
import com.gamedo.gameServer.message.mail.MailListRequestMessage;
import com.gamedo.gameServer.message.mail.MailListResponseMessage;
import com.gamedo.gameServer.service.mail.MailService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 邮件列表
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.MAIL_LIST)
public class MailListController extends AbstractController{

	@Autowired
	private PlayerService playerService;
	@Autowired
	private MailService mailService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.MAIL_LIST,request,response);
		MailListRequestMessage reqMessage = (MailListRequestMessage) packet.getRequestMessage(MailListRequestMessage.class);
		MailListResponseMessage message = new MailListResponseMessage();
		Player player = playerService.getPlayerById(reqMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		ConcurrentHashMap<Integer, Mail> mails = mailService.getMailList(reqMessage.getPlayerID());
		List<Mail> mailList = new ArrayList<>();
		mailList.addAll(mails.values());
		
		//Collections.sort(mailList, new MailCompartor());
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setMails(getMailInfos(mailList));
		message.setUpdateObj(player.changed.sendAndClean());
		packet.send(message);
	}

	public List<MailInfo> getMailInfos(List<Mail> mails) {
		List<MailInfo> mailInfos = new ArrayList<>();
		for(int i = 0; i < mails.size(); i++) {
			Mail mail = mails.get(i);
			if(mail != null) {
				MailInfo mailInfo = new MailInfo();
				mailInfo.setMailId(mail.getId());
				mailInfo.setSendName(mail.getSendName());//发送者
				mailInfo.setSourceId(mail.getSourceId());//发送者id
				mailInfo.setTitle(mail.getTitle());//邮件标题
				mailInfo.setPostTime(mail.getPostTime().getTime());//邮件发送时间
				mailInfo.setStatus(mail.getStatus());//邮件状态
				int attach = 0;
				if(null!=mail.getAttachments() && mail.getAttachments().getAttachments() != null && mail.getAttachments().getAttachments().length > 0){
					attach = 1;
				}else{
					attach = 0;
				}
				mailInfo.setHaveAttach(attach);//是否有邮件附件
				mailInfo.setReceivedAttach(mail.getReceivedAttach());//
				mailInfos.add(mailInfo);
			}
		}
		return mailInfos;
	}
	
	public class MailCompartor implements Comparator<Mail> {

		@Override
		public int compare(Mail o1, Mail o2) {
			int result = 1;
			if(o1 != null && o2 != null && o1 instanceof Mail && o2 instanceof Mail) {
				Mail mail1 = (Mail)o1;
				Mail mail2 = (Mail)o2;
				if(mail1.getStatus() == MailService.UNREADED && mail2.getStatus() == MailService.READED) {
					return -1;
				}else if(mail1.getStatus() == MailService.READED && mail2.getStatus() == MailService.READED) {
					if(mail1.getPostTime().getTime() > mail2.getPostTime().getTime()) {
						result = -1;
					}
				}
			}
			return result;
		}
		
	}
}
