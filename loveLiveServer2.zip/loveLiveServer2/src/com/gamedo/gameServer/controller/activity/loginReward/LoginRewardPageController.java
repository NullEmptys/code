package com.gamedo.gameServer.controller.activity.loginReward;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.activity.Activity;
import com.gamedo.gameServer.activity.ActivityService;
import com.gamedo.gameServer.activity.loginReward.LoginRewardActivity;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.activity.loginReward.LoginRewardAreaData;
import com.gamedo.gameServer.message.activity.loginReward.LoginRewardPageRequestMessage;
import com.gamedo.gameServer.message.activity.loginReward.LoginRewardPageResponseMessage;
import com.gamedo.gameServer.message.activity.loginReward.SignRewardData;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 7日签到界面
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.LOGIN_REWARD_PAGE)
public class LoginRewardPageController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private ActivityService activityService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.LOGIN_REWARD_PAGE, request, response);

		LoginRewardPageRequestMessage requestMessage = (LoginRewardPageRequestMessage) packet
				.getRequestMessage(LoginRewardPageRequestMessage.class);

		LoginRewardPageResponseMessage message = new LoginRewardPageResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		Activity activity = activityService.getActivity(requestMessage.getActivityId());
		if(!activity.isActive()) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.ACTIVITY_NOT_ACTIVE);
			packet.send(message);
			return;
		}
		
		LoginRewardActivity loginRewardActivity = (LoginRewardActivity) activity.getImpl();
		message.setActivityTitle(activity.getTitle());
		message.setSignCounts(loginRewardActivity.getPlayerSignCounts(player.getId(),activity.getId()));
		List<SignRewardData> signRewards = loginRewardActivity.getPlayerSignRewardData(player.getId(),activity.getId());
		message.setSignRewards(signRewards);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

}
