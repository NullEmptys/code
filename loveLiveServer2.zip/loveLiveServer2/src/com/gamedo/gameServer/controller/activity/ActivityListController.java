package com.gamedo.gameServer.controller.activity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gamedo.gameServer.controller.AbstractController;

/**
 * 活动列表
 * @author libm
 *
 */
public class ActivityListController extends AbstractController {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

	}

}
