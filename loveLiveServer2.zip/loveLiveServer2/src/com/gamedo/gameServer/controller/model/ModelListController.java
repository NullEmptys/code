package com.gamedo.gameServer.controller.model;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonRequestMessage;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.PlayerGirlData;
import com.gamedo.gameServer.message.player.PlayerGirlDataResponseMessage;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 模特列表
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = OpCode.GET_GIRL_LIST)
public class ModelListController extends AbstractController {
	@Autowired
	private GirlService girlService;
	@Autowired
	private PlayerService playerService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.GET_GIRL_LIST, request, response);
		CommonRequestMessage requestMessage = (CommonRequestMessage) packet
				.getRequestMessage(CommonRequestMessage.class);

		PlayerGirlDataResponseMessage message = new PlayerGirlDataResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}

		List<PlayerGirlData> playerGirlDatas = girlService.getPlayerGirlDatas(player);
		message.setCode(CommonResponseMessage.TRUE);
		message.setPlayerGirlDatas(playerGirlDatas);
		packet.send(message);
	}
}
