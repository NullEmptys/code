package com.gamedo.gameServer.controller.model;

import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.constant.Constants;
import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.PlayerGirlBaseDataChangeItem;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.girl.Girl;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.girl.UnlockModelRequestMessage;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 解锁模特
 * 
 * @author IPOC-HUANGPING
 *
 */
@Controller
@RequestMapping(value = OpCode.UNLOCK_MODEL)
public class BuyModelController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private GirlService girlService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.UNLOCK_MODEL, request, response);
		UnlockModelRequestMessage requestMessage = (UnlockModelRequestMessage) packet
				.getRequestMessage(UnlockModelRequestMessage.class);

		CommonResponseMessage responseMessage = new CommonResponseMessage();
		int modelId = requestMessage.getModelId();
		int playerId = requestMessage.getPlayerID();
		Player player = playerService.loadPlayerById(playerId);
		if (player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		Girl model = girlService.getGirl(modelId);
		if (model == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(responseMessage);
			return;
		}
		ConcurrentHashMap<Integer, PlayerGirl> playerModel = girlService.getPlayerGirls(playerId);
		PlayerGirl playerGirl = null;
		if (playerModel.get(modelId) == null) {
			playerGirl = girlService.addPlayerGirl(playerId, model);
		} else {
			playerGirl = playerModel.get(modelId);
		}
		switch (requestMessage.getType()) {
		case 1: {
			// 解锁模特条件
			// if (playerGirl.getStatus() == Constants.SUCCESS) {
			// responseMessage.setCode(CommonResponseMessage.FALSE);
			// responseMessage.setDesc(I18NMessage.GIRL_UNLOCK_FAIL);
			// packet.send(responseMessage);
			// return;
			// }
			PlayerTransaction tx = player.newTransaction("unlockModel");
			try {
				player.decCurrency(AttributeType.getAttrtType(AttributeType.MONEY.getAttributeType()),
						model.getConsumeDiamond(), tx, false);
			} catch (NoEnoughValueException e) {
				responseMessage.setCode(CommonResponseMessage.FALSE);
				responseMessage.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
				packet.send(responseMessage);
				e.printStackTrace();
				return;
			}
			tx.commit();
			playerGirl.setStatus(Constants.SUCCESS);
			girlService.updatePlayerGirl(playerGirl);
			break;
		}
		case 2: {
			// if (playerGirl.getCondtionStatus().contains(Constants.FAIL)) {
			// responseMessage.setCode(CommonResponseMessage.FALSE);
			// responseMessage.setDesc(I18NMessage.GIRL_UNLOCK_FAIL);
			// packet.send(responseMessage);
			// return;
			// }
			PlayerTransaction tx = player.newTransaction("unlockModel");
			try {
				player.decCurrency(AttributeType.getAttrtType(AttributeType.GOLD.getAttributeType()),
						model.getConsumeGold(), tx, false);
			} catch (NoEnoughValueException e) {
				responseMessage.setCode(CommonResponseMessage.FALSE);
				responseMessage.setDesc(I18NMessage.NO_ENOUGH_CURRENCY);
				packet.send(responseMessage);
				e.printStackTrace();
				return;
			}
			tx.commit();
			playerGirl.setStatus(Constants.SUCCESS);
			girlService.updatePlayerGirl(playerGirl);
		}
		}
		PlayerGirlBaseDataChangeItem changeItem = new PlayerGirlBaseDataChangeItem();
		changeItem.setGirlId(playerGirl.getGirlId());
		changeItem.setExp(playerGirl.getExp());
		changeItem.setLevel(playerGirl.getLevel());
		changeItem.setStatus(playerGirl.getStatus());
		player.changed.addChangedItem(changeItem);
		responseMessage.setUpdateObj(player.changed.sendAndClean());// 返回玩家变化数据
		responseMessage.setCode(CommonResponseMessage.TRUE);
		packet.send(responseMessage);
	}

}
