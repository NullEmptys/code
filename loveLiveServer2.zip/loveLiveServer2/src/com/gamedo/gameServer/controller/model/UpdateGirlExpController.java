package com.gamedo.gameServer.controller.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.data.item.Item;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.player.UpdateGirlExpRequestMessage;
import com.gamedo.gameServer.message.player.UpdateGirlExpResponseMessage;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 模特升级
 * 
 * @author liuxing
 *
 */
@Controller
@RequestMapping(value = OpCode.UPDATE_GIRL_EXP)
public class UpdateGirlExpController extends AbstractController {
	@Autowired
	private GirlService girlService;
	@Autowired
	private PlayerService playerService;
	@Autowired
	private ItemService itemService;

	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		this.updateGirlExp(request, response);
	}

	private void updateGirlExp(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.UPDATE_GIRL_EXP, request, response);
		UpdateGirlExpRequestMessage requestMessage = (UpdateGirlExpRequestMessage) packet
				.getRequestMessage(UpdateGirlExpRequestMessage.class);
		UpdateGirlExpResponseMessage message = new UpdateGirlExpResponseMessage();

		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		PlayerGirl playerGirl = girlService.getPlayerGirl(player.getId(), requestMessage.getGirlId());
//		if(playerGirl.getStatus() == Constants.FAIL){
//			message.setCode(CommonResponseMessage.FALSE);
//			message.setDesc(I18NMessage.GIRL_NOT_UNLOCK);
//			packet.send(message);
//			return;
//		}
		Item item = itemService.getItemById(requestMessage.getItemId());
		if(item == null){
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		GameItem gameItem = player.getBags().getGameItem(requestMessage.getItemId());
		if(gameItem == null){
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_ITEM);
			packet.send(message);
			return;
		}
		PlayerGirl chargedPalerGirl = girlService.updateGirlExp(player, requestMessage.getGirlId(),
				item.getValue());
//		PlayerGirl chargedPalerGirl = girlService.updateGirlExp(player, requestMessage.getGirlId(),
//				200);
		if(chargedPalerGirl == null){
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.GIRL_LEVEL_NOT_ENOUGH);
			packet.send(message);
			return;
		}
		if(chargedPalerGirl.getLevel() == -1){
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.GIRL_LEVEL_NOT_ENOUGH);
			packet.send(message);
			return;
		}
		playerService.removeItem(requestMessage.getPlayerID(), item.getId(), 1, "使用道具获得好感度");
		message.setCode(CommonResponseMessage.TRUE);
//		message.setGirlData(girlService.getPlayerGirlData(player, chargedPalerGirl));
		message.setUpdateObj(player.changed.sendAndClean());// 返回玩家变化数据
		packet.send(message);
	}

}
