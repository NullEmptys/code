package com.gamedo.gameServer.controller.quest;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.quest.QuestChapterReward;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.quest.PlayerQuest;
import com.gamedo.gameServer.entity.quest.PlayerQuestChapter;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.quest.ChapterRewardData;
import com.gamedo.gameServer.message.quest.ChapterRewardRequestMessage;
import com.gamedo.gameServer.message.quest.ChapterRewardResponseMessage;
import com.gamedo.gameServer.message.quest.ItemReward;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;

/**
 * 领取章节奖励
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.CHAPTER_REWARD)
public class QuestChapterRewardController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private QuestService questService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.CHAPTER_REWARD, request, response);

		ChapterRewardRequestMessage requestMessage = (ChapterRewardRequestMessage) packet
				.getRequestMessage(ChapterRewardRequestMessage.class);
		
		ChapterRewardResponseMessage message = new ChapterRewardResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		ConcurrentHashMap<Integer, PlayerQuestChapter> playerQuestChapters = questService.getPlayerQuestChapterById(player, requestMessage.getChapterId());
		if(playerQuestChapters == null || playerQuestChapters.isEmpty()) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc("暂未解锁该章节，无法领取奖励~");
			packet.send(message);
			return;
		}
		PlayerQuestChapter playerQuestChapter = playerQuestChapters.get(requestMessage.getCounts());
		if(playerQuestChapter == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		if(playerQuestChapter.getState() == 1) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc("已领");
			packet.send(message);
			return;
		}
		QuestChapterReward chapterReward = questService.questChapterRewards.get(requestMessage.getChapterId()).get(requestMessage.getCounts());
		if(chapterReward == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		ConcurrentHashMap<Integer, PlayerQuest> playerQuests = questService.getPlayerQuestByChapterId(player, requestMessage.getChapterId());
		int superCounts = questService.getSuperCounts(playerQuests);
		if(superCounts < chapterReward.getCounts()) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc("条件不足,继续努力~");
			packet.send(message);
			return;
		}
		
		List<ItemReward> itemRewards = questService.chapterReward(player,chapterReward,playerQuestChapter);
		
		questService.addPlayerQuestChaptersToCache(player.getId() + "_" + playerQuestChapter.getChapterId(), playerQuestChapters);
		
		ChapterRewardData chapterRewardData = questService.getChapterRewardData(playerQuestChapter);
		message.setCode(CommonResponseMessage.TRUE);
		message.setChapterRewardData(chapterRewardData);
		message.setItemRewards(itemRewards);
		message.setUpdateObj(player.changed.sendAndClean());
		
		playerService.updatePlayer(player);
		packet.send(message);
	}

}
