package com.gamedo.gameServer.controller.quest;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.quest.Quest;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.quest.PlayerQuest;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.quest.QuestInfoRequestMessage;
import com.gamedo.gameServer.message.quest.QuestInfoResponseMessage;
import com.gamedo.gameServer.message.quest.QuestRankInfo;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;

/**
 * 任务详情
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.QUEST_INFO)
public class QuestInfoController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private QuestService questService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.QUEST_INFO,request,response);
		
		QuestInfoRequestMessage requestMessage = (QuestInfoRequestMessage) packet.getRequestMessage(QuestInfoRequestMessage.class);
		
		QuestInfoResponseMessage message = new QuestInfoResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		Quest quest = questService.questMap.get(requestMessage.getQuestId());
		if(quest == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		
		PlayerQuest playerQuest = questService.getPlayerQuest(player, quest.getChapterId(),quest.getId());
		if(playerQuest == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc("该任务暂未激活哟~");
			packet.send(message);
			return;
		}
		
		List<QuestRankInfo> questRankInfos = questService.getQuestRankInfos(quest.getId());
		QuestRankInfo selfRank = questService.getSelfQuestRankInfo(player, questRankInfos,playerQuest);
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setQuestRankInfos(questRankInfos);
		message.setSelfRankInfo(selfRank);
		message.setLastClothIds(playerQuest.getLastClothIds());
		message.setMaxScoreClothIds(playerQuest.getMaxScoreClothIds());
		message.setUpdateObj(player.changed.sendAndClean());
		packet.send(message);
		playerService.updatePlayer(player);
		
	}

}
