package com.gamedo.gameServer.controller.quest;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.quest.Quest;
import com.gamedo.gameServer.data.quest.QuestScore;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.entity.quest.PlayerQuest;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.quest.QuestFinishedRequestMessage;
import com.gamedo.gameServer.message.quest.QuestFinishedResponseMessage;
import com.gamedo.gameServer.message.quest.RewardData;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;
import com.gamedo.gameServer.util.Const;

/**
 * 结束任务
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.QUEST_FINISHED)
public class QuestFinishController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private QuestService questService;
	@Autowired
	private GirlService girlService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.QUEST_FINISHED, request, response);

		QuestFinishedRequestMessage requestMessage = (QuestFinishedRequestMessage) packet
				.getRequestMessage(QuestFinishedRequestMessage.class);
		
		QuestFinishedResponseMessage message = new QuestFinishedResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		
		Quest quest = questService.questMap.get(requestMessage.getQuestId());
		if(quest == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(message);
			return;
		}
		
		if(player.getTili() < quest.getConsumeTili()) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_ENOUGH_TILI);
			packet.send(message);
			return;
		}
		
		PlayerQuest playerQuest = questService.getPlayerQuest(player, quest.getChapterId(), quest.getId());
		if(playerQuest == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc("该任务暂未激活~");
			packet.send(message);
			return;
		}
		
		if(quest.getType() == 2) {
			if(playerQuest.getState() == PlayerQuest.FINISHED) {
				message.setCode(CommonResponseMessage.TRUE);
				message.setDesc("该任务只可完成一次");
				packet.send(message);
				return;
			}
		}else{
			if(requestMessage.getClothIds() == null || requestMessage.getClothIds().isEmpty()) {
				message.setCode(CommonResponseMessage.FALSE);
				message.setDesc("请先穿衣服哟~");
				packet.send(message);
				return;
			}
		}
		
		PlayerGirl playerGirl = girlService.getPlayerGirl(player.getId(), requestMessage.getGirlId());
		
		Map<Integer,Integer> clothScore = questService.calcStyleScore(player.getId(),requestMessage.getQuestId(),requestMessage.getGirlId(),requestMessage.getClothIds());
		int realTotalScore = questService.calRealTotalScore(clothScore);
		QuestScore questScore = questService.calcScoreLevel(quest.getId(), realTotalScore);
		RewardData rewardData = questService.finishQuest(player, playerQuest, questScore,requestMessage,playerGirl,realTotalScore);
		
		message.setCode(CommonResponseMessage.TRUE);
		message.setScoreDatas(clothScore);
		if(requestMessage.getMoodData() != null) {
			if((requestMessage.getMoodData().getMoodType() + "").equals(quest.getDisplayMoodTypeStr())) {
				message.setMoodScore(requestMessage.getMoodData().getScore());
			}
		}
		message.setReward(rewardData);
		message.setNextQuestId(quest.getNextQuestId());
		message.setLastUnlockQuestId(player.getPool().getInt(Const.PROPERTY_LAST_UNLOCK_QUEST_ID));
		message.setUpdateObj(player.changed.sendAndClean());
		packet.send(message);
		
		playerService.updatePlayer(player);
	}

}
