package com.gamedo.gameServer.controller.quest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.controller.AbstractController;
import com.gamedo.gameServer.data.quest.QuestChapter;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.io.OpCode;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.message.quest.PlayerQuestChapterData;
import com.gamedo.gameServer.message.quest.QuestChapterRequestMessage;
import com.gamedo.gameServer.message.quest.QuestChapterResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.service.quest.QuestService;

/**
 * 获取玩家任务列表
 * 
 * @author libm
 *
 */
@Controller
@RequestMapping(value = OpCode.QUEST_CHAPTER)
public class QuestChapterController extends AbstractController {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private QuestService questService;
	
	@RequestMapping(method = RequestMethod.POST)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(OpCode.QUEST_CHAPTER, request, response);
		QuestChapterRequestMessage requestMessage = (QuestChapterRequestMessage) packet
				.getRequestMessage(QuestChapterRequestMessage.class);
		
		QuestChapterResponseMessage responseMessage = new QuestChapterResponseMessage();
		
		Player player = playerService.loadPlayerById(requestMessage.getPlayerID());
		if (player == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(responseMessage);
			return;
		}
		
		QuestChapter questChapter = questService.questChapters.get(requestMessage.getChapterId());
		if(questChapter == null) {
			responseMessage.setCode(CommonResponseMessage.FALSE);
			responseMessage.setDesc(I18NMessage.DATA_EXCEPTION);
			packet.send(responseMessage);
			return;
		}
		
		PlayerQuestChapterData chapterData = questService.getPlayerQuestChapterData(player,requestMessage.getChapterId());
		responseMessage.setCode(CommonResponseMessage.TRUE);
		responseMessage.setQuestChapterData(chapterData);
		responseMessage.setUpdateObj(player.changed.sendAndClean());
		packet.send(responseMessage);
	}

}
