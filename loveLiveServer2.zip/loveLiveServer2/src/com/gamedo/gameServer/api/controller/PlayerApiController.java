package com.gamedo.gameServer.api.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.api.message.PlayerBagsDataReponseMessage;
import com.gamedo.gameServer.api.message.PlayerDetailDataReponseMessage;
import com.gamedo.gameServer.api.message.PlayerListDataReponseMessage;
import com.gamedo.gameServer.constant.LoginOutType;
import com.gamedo.gameServer.core.bag.Bag;
import com.gamedo.gameServer.core.bag.BagChangedItem;
import com.gamedo.gameServer.core.bag.BagGrid;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.loginout.LoginOutChange;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.channel.Channel;
import com.gamedo.gameServer.data.girl.Model;
import com.gamedo.gameServer.db.editor.ChannelDao;
import com.gamedo.gameServer.db.editor.ModelDao;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.I18NMessage;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.mysql.jdbc.StringUtils;

/**
 * 玩家API
 * 
 * @author liuxing
 *
 */
@Controller
@RequestMapping(value = "/api/player")
public class PlayerApiController extends BaseApiController {
	@Autowired
	private PlayerService playerService;
	@Autowired
	private GirlService girlService;
	@Autowired
	private ItemService itemService;
	@Autowired
	private ChannelDao channelDao;
	@Autowired
	private ModelDao modelDao;
	private final static String PLAYER_LIST = "/playerList";
	private final static String PLAYER_DETAIL = "/playerDetail";
	private final static String PLAYER_UPDATE = "/updatePlayer";
	private final static String PLAYER_LOGOUT = "/playerLogout";
	private final static String PLAYER_BAGS = "/playerBags";
	private final static String PLAYER_GOLD_UPDATE = "/playerGoldUpdate";
	private final static String PLAYER_MONEY_UPDATE = "/playerMoneyUpdate";
	private final static String PLAYER_UPDATE_ITEM = "/playerUpdateItem";
	private final static String PLAYER_ADD_ITEM = "/playerAddItem";

	/**
	 * 获取渠道玩家列表
	 * 
	 * @return
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public void list(String search, String type, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_LIST, request, response);
		PlayerListDataReponseMessage message = new PlayerListDataReponseMessage();
		List<Map<String, Object>> list = new ArrayList<>();
		logger.debug("查询条件:" + search);
		if (type.equals("name")) {
			list = playerService.findAllByName("" + search + "");
		} else if (type.equals("id")) {
			list = playerService.findAllById("" + search + "");
		}
		message.setCode(CommonResponseMessage.TRUE);
		message.setPlayerBaseList(list);
		packet.send(message);
	}

	/**
	 * 获取玩家基本信息
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{id}/detail", method = RequestMethod.GET)
	public void detail(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_DETAIL, request, response);
		PlayerDetailDataReponseMessage message = new PlayerDetailDataReponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		message.setCode(CommonResponseMessage.TRUE);
		message.setPlayerInfo(player);
		String channelId = (String) message.getPlayerInfo().get("channelId");
		Channel channel = channelDao.findById(player.getChannelId());
		String channelName = "";
		if (channel != null) {
			channelName = channel.getName();
		}
		message.getPlayerInfo().put("channelName", channelId + "-" + channelName);
		packet.send(message);
	}

	/**
	 * 修改金币
	 * 
	 * @param id
	 * @param number
	 * @param type
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/updateGold", method = RequestMethod.POST)
	public void updateGold(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_GOLD_UPDATE, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		int type = (int) json.get("type");
		int number = (int) json.get("number");
		if (type == 1) {
			// 增加
			PlayerTransaction tx = player.newTransaction("GM操作:增加金币" + number);
			player.addGold(number, tx, false);
			tx.commit();
		} else {
			// 减少
			PlayerTransaction tx = player.newTransaction("GM操作:减少金币" + number);
			try {
				player.decGold(number, tx, false);
				tx.commit();
			} catch (NoEnoughValueException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				message.setCode(CommonResponseMessage.FALSE);
			}
		}
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
		playerService.updatePlayer(player);
	}

	/**
	 * 修改钻石
	 * 
	 * @param id
	 * @param number
	 * @param type
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/updateMoney", method = RequestMethod.POST)
	public void updateMoney(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_MONEY_UPDATE, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		int type = (int) json.get("type");
		int number = (int) json.get("number");
		if (type == 1) {
			// 增加
			PlayerTransaction tx = player.newTransaction("GM操作:增加钻石" + number);
			player.addMoney(number, tx, false);
			tx.commit();
		} else {
			// 减少
			PlayerTransaction tx = player.newTransaction("GM操作:减少钻石" + number);
			try {
				player.decMoney(number, tx, false);
				tx.commit();
			} catch (NoEnoughValueException e) {
				message.setCode(CommonResponseMessage.FALSE);
				e.printStackTrace();
			}
		}
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 修改角色基本信息
	 * 
	 * @param id
	 * @param name
	 * @param state
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/updatePlayer", method = RequestMethod.POST)
	public void updatePlayerInfo(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_UPDATE, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		String name = (String) json.get("name");
		int state = (int) json.get("state");
		if (!StringUtils.isNullOrEmpty(name)) {
			player.setName(name);
		}
		player.setState(state);

		int playerType = (int) json.get("playerType");
		player.setPlayerType(playerType);

		int tili = (int) json.get("tili");
		if (player.getTili() != tili) {
			player.setTili(tili, false, "GM修改体力");
		}
		String girlId = (String) json.get("girlId");
		if (!StringUtils.isNullOrEmpty(girlId) && !girlId.equals(Integer.toString(player.getGirlId()))) {
			Model model = modelDao.findById(Integer.parseInt(girlId));
			if (model != null) {
				List<Player> players = playerService.findByGirlId(Integer.parseInt(girlId));
				if (players == null || players.isEmpty()) {
					player.setGirlId(Integer.parseInt(girlId));
				} else {
					message.setCode("3");
					message.setDesc("该模特已被分配");
					packet.send(message);
					return;
				}
			}else{
				message.setCode("4");
				message.setDesc("该模特不存在");
				packet.send(message);
				return;
			}
		} else if (StringUtils.isNullOrEmpty(girlId) || girlId.equals("0")) {
			player.setGirlId(0);
		}

		playerService.updatePlayer(player);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 强制下线
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/playerLogout", method = RequestMethod.GET)
	public void playerLogout(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_LOGOUT, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		playerService.playerLogout(player);
		LoginOutChange dailyChange = new LoginOutChange(LoginOutType.FORCE_LOGIN_OUT.getType(),
				LoginOutType.FORCE_LOGIN_OUT.getDesc());
		player.changed.addChangedItem(dailyChange);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 获取玩家背包数据
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/bags", method = RequestMethod.GET)
	public void getPlayerBags(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_BAGS, request, response);
		PlayerBagsDataReponseMessage message = new PlayerBagsDataReponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		message.setCode(CommonResponseMessage.TRUE);
		message.setBagData(player.getPlayerBagData());
		packet.send(message);
	}

	/**
	 * 修改玩家道具
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/updateItem", method = RequestMethod.POST)
	public void updateItem(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_UPDATE_ITEM, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		Map<String, Object> json = this.getRequestMessage(request);
		int itemId = (int) json.get("itemId");
		Long count = 0l;
		Object num = json.get("num");
		if (num instanceof Integer) {
			count = Long.parseLong(Integer.toString((int) num));
		} else if (num instanceof Long) {
			count = (Long) num;
		}
		int category = (int) json.get("category");

		String cause = "GM修改道具";
		if (category > 0) {
			GameItem gi = player.getBags().updateGameItem(itemId, cause, count);
			if (gi != null) {
				if (playerService.isOnline(player.getId())) {
					BagGrid bagGird = player.getBags().getGameItemBagGrid(itemId);
					player.changed.addChangedItem(new BagChangedItem(bagGird));
				}
				playerService.updatePlayer(player);
			}
		}
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 添加玩家道具
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/addItem", method = RequestMethod.POST)
	public void addItem(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_ADD_ITEM, request, response);
		// CommonResponseMessage message = new CommonResponseMessage();
		PlayerBagsDataReponseMessage message = new PlayerBagsDataReponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		Map<String, Object> json = this.getRequestMessage(request);
		int itemId = (int) json.get("itemId");
		Long count = 0l;
		Object num = json.get("num");
		if (num instanceof Integer) {
			count = Long.parseLong(Integer.toString((int) num));
		} else if (num instanceof Long) {
			count = (Long) num;
		}

		int category = (int) json.get("category");

		String cause = "GM添加道具";
		if (category == 0) {
			// 数量
			if (count < 0) {
				message.setCode(CommonResponseMessage.FALSE);
				packet.send(message);
				return;
			}
			player.getBags().addItem(itemId, Integer.parseInt(Long.toString(count)), cause);
		} else {
			// 时效
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date(Long.parseLong(Long.toString(count)));
			System.out.println("=============" + format.format(date));
			player.getBags().gmAddItem(itemId, 1, cause, Long.parseLong(Long.toString(count)));
		}
		message.setBagData(player.getPlayerBagData());
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
		playerService.updatePlayer(player);
	}

	/**
	 * 删除玩家道具
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/removeItem", method = RequestMethod.POST)
	public void removeItem(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_ADD_ITEM, request, response);
		// CommonResponseMessage message = new CommonResponseMessage();
		PlayerBagsDataReponseMessage message = new PlayerBagsDataReponseMessage();
		Player player = playerService.getPlayerById(id);
		if (player == null) {
			message.setCode(CommonResponseMessage.FALSE);
			message.setDesc(I18NMessage.NOT_FOUND_PLAYER);
			packet.send(message);
			return;
		}
		Map<String, Object> json = this.getRequestMessage(request);
		int bagId = (int) json.get("bagId");
		int gridId = (int) json.get("gridId");
		int itemId = (int) json.get("itemId");
		int category = (int) json.get("category");
		int itemTemplateId = itemService.getItemTemplate(itemId).getId();
		Bag bag = player.getBags().getBag(bagId);
		GameItem gameItem = bag.getGameItemById(itemTemplateId);
		int instanceId = gameItem.getInstanceId();
		PlayerTransaction tx = player.newTransaction("GM操作:删除道具" + itemId);
		if (category == 0) {
			int count = 0;
			Object num = json.get("num");
			if (num instanceof Integer) {
				count = Integer.parseInt(Long.toString((int) num));
			} else if (num instanceof Integer) {
				count = (int) num;
			}
			bag.removeGridGameItem(gridId, itemTemplateId, instanceId, count, tx, false);
			tx.commit();
		} else if (category > 0) {
			bag.removeGameItemInstance(itemTemplateId, instanceId, tx, false);
			tx.commit();
		}
		message.setBagData(player.getPlayerBagData());
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
		playerService.updatePlayer(player);
	}
}
