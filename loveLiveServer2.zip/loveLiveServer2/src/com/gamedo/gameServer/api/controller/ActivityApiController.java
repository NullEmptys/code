package com.gamedo.gameServer.api.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.activity.Activity;
import com.gamedo.gameServer.activity.ActivityService;
import com.gamedo.gameServer.api.message.ActivityDataListReponseMessage;
import com.gamedo.gameServer.api.message.ActivityDataReponseMessage;
import com.gamedo.gameServer.api.message.LoginRewardConfigDataReponseMessage;
import com.gamedo.gameServer.api.message.LoginRewardListDataReponseMessage;
import com.gamedo.gameServer.data.activity.loginReward.LoginReward;
import com.gamedo.gameServer.data.activity.loginReward.LoginRewardConfig;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;

@Controller
@RequestMapping(value = "/api/activity")
public class ActivityApiController extends BaseApiController {
	@Autowired
	private ActivityService activityService;
	private final static String ACTIVITY_LIST = "/activityList";
	private final static String ACTIVITY_UPDATE = "/activityUpdate";
	private final static String ACTIVITY_RELOAD_DATA = "/activityReloadData";

	/**
	 * 获取在线活动列表
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/activityList", method = RequestMethod.GET)
	public void loadActivityList(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(ACTIVITY_LIST, request, response);
		ActivityDataListReponseMessage message = new ActivityDataListReponseMessage();
		activityService.loadActivities();
		List<Activity> list = activityService.getActivities();
		message.setActivityList(list);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 获取在线活动详情
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public void loadActivityById(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(ACTIVITY_UPDATE, request, response);
		ActivityDataReponseMessage message = new ActivityDataReponseMessage();
		Activity activity = activityService.getActivity(id);
		if (activity == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		message.setActivity(activity);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 修改在线活动
	 * 
	 * @param request
	 * @param response
	 * @throws ParseException
	 */
	@RequestMapping(value = "/{id}/activityUpdate", method = RequestMethod.POST)
	public void activityUpdate(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response)
			throws ParseException {
		Packet packet = new Packet(ACTIVITY_UPDATE, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		Activity activity = activityService.getActivity(id);
		if (activity == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date broadcastEndTime = sdf.parse((String) json.get("broadcastEndTime"));
		Date broadcastStartTime = sdf.parse((String) json.get("broadcastStartTime"));
		Date startTime = sdf.parse((String) json.get("startTime"));
		Date endTime = sdf.parse((String) json.get("endTime"));
		activity.setStartTime(startTime);
		activity.setEndTime(endTime);
		activity.setBroadcastEndTime(broadcastEndTime);
		activity.setBroadcastStartTime(broadcastStartTime);
		activity.setTitle((String) json.get("title"));
		activity.setDescription((String) json.get("description"));
		activity.setImplClass((String) json.get("implClass"));
		activityService.updateActivity(activity);
		LoginRewardConfig loginRewardConfig = activityService.loadLoginRewardConfig(id);
		loginRewardConfig.setBackGroundId(
				json.get("backGroundId") == null ? 0 : Integer.parseInt((String) json.get("backGroundId")));
		activityService.updateLoginRewardConfig(loginRewardConfig);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 活动上线
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/activityPublish", method = RequestMethod.POST)
	public void activityPublish(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(ACTIVITY_UPDATE, request, response);
		ActivityDataReponseMessage message = new ActivityDataReponseMessage();
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		Activity activity = new Activity();
		Date broadcastEndTime = new Date((Long) json.get("broadcastEndTime"));
		Date broadcastStartTime = new Date((Long) json.get("broadcastStartTime"));
		Date startTime = new Date((Long) json.get("startTime"));
		Date endTime = new Date((Long) json.get("endTime"));
		activity.setStartTime(startTime);
		activity.setEndTime(endTime);
		activity.setBroadcastEndTime(broadcastEndTime);
		activity.setBroadcastStartTime(broadcastStartTime);
		activity.setTitle((String) json.get("title"));
		activity.setDescription((String) json.get("description"));
		activity.setImplClass((String) json.get("implClass"));
		activity = activityService.saveActivity(activity);
		List<Map<String, Object>> objList = (List<Map<String, Object>>) json.get("objList");
		LoginReward loginReward;
		for (Map<String, Object> map : objList) {
			loginReward = new LoginReward();
			loginReward.setActivityId(activity.getId());
			loginReward.setCdTimeType((int) map.get("cdTimeType"));
			loginReward.setRewardId((int) map.get("rewardId"));
			loginReward.setRewardType((int) map.get("rewardType"));
			loginReward.setRewardCounts((int) map.get("rewardCounts"));
			loginReward.setSignCounts((int) map.get("signCounts"));
			loginReward.setBackgroundId((String)map.get("backGroundId"));
			activityService.saveLoginReward(loginReward);
		}
		LoginRewardConfig loginRewardConfig = new LoginRewardConfig();
		loginRewardConfig.setActivityId(activity.getId());
//		loginRewardConfig.setBackGroundId(
//				json.get("backGroundId") == null ? 0 : Integer.parseInt((String) json.get("backGroundId")));
		activityService.createLoginRewardConfig(loginRewardConfig);
		message.setActivity(activity);
//		activityService.loadActivityById(activity.getId());
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 删除线上活动
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/activityDelete", method = RequestMethod.GET)
	public void activityDelete(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(ACTIVITY_UPDATE, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Activity activity = activityService.getActivity(id);
		if (activity == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		activityService.deleteActivity(id);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 获取活动奖励
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/loadLoginRewards", method = RequestMethod.GET)
	public void loadLoginRewards(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(ACTIVITY_UPDATE, request, response);
		LoginRewardListDataReponseMessage message = new LoginRewardListDataReponseMessage();
		Activity activity = activityService.getActivity(id);
		if (activity == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		if (activity.getImplClass().equals("com.gamedo.gameServer.activity.loginReward.LoginRewardActivity")) {
			message.setLoginRewardList(activityService.loadLoginRewards(id));
			message.setCode(CommonResponseMessage.TRUE);
			packet.send(message);
		}
	}

	@RequestMapping(value = "/{id}/loadLoginRewardConfig", method = RequestMethod.GET)
	public void loadLoginRewardConfig(@PathVariable("id") int id, HttpServletRequest request,
			HttpServletResponse response) {
		Packet packet = new Packet(ACTIVITY_UPDATE, request, response);
		LoginRewardConfigDataReponseMessage message = new LoginRewardConfigDataReponseMessage();
		LoginRewardConfig loginRewardConfig = activityService.loadLoginRewardConfig(id);
		if (loginRewardConfig == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		message.setLoginRewardConfig(loginRewardConfig);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 重新加载活动
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}/reloadData", method = RequestMethod.GET)
	public void reloadData(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(ACTIVITY_RELOAD_DATA, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Activity activity = activityService.getActivity(id);
		if (null != activity && activity.isActive()) {
			activityService.stopActivityById(id);
		}
		activityService.loadActivityById(id);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}
}
