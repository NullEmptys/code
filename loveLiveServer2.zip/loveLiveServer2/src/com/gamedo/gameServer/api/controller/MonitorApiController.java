package com.gamedo.gameServer.api.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.api.message.MonitorDataReponseMessage;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.service.player.PlayerService;

@Controller
@RequestMapping(value = "/api/monitor")
public class MonitorApiController extends BaseApiController {

	@Autowired
	private PlayerService playerService;

	@RequestMapping(value = "/ping", method = RequestMethod.GET)
	public void ping(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet("/ping", request, response);
		MonitorDataReponseMessage message = new MonitorDataReponseMessage();
		Map<String, Object> systemInfo = new HashMap<String, Object>();
		systemInfo.put("onlineCount", playerService.getOnlineCount());
		message.setSystemInfo(systemInfo);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}
}
