package com.gamedo.gameServer.api.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gamedo.gameServer.service.mail.MailService;
import com.gamedo.gameServer.util.JsonUtil;

/**
 * 
 * @author liuxing
 *
 */
public class BaseApiController {
	protected Logger logger = LoggerFactory.getLogger(BaseApiController.class);

	protected Map<String, Object> getRequestMessage(HttpServletRequest request) {
		String content = "";
		java.io.BufferedReader reader = null;
		Map<String, Object> requestMessage = null;
		try {
			reader = request.getReader();// 获得字符流
			StringBuffer sb = new StringBuffer();
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\r\n");
			}
			content = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
				reader = null;
			} catch (Exception e) {
			}
		}
		try {
			requestMessage = (Map<String, Object>) JsonUtil.decodeJson(content, Map.class);
			return requestMessage;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
