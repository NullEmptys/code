package com.gamedo.gameServer.api.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.api.message.ServerInfoConfigDataListReponseMessage;
import com.gamedo.gameServer.api.message.ServerInfoConfigDataReponseMessage;
import com.gamedo.gameServer.api.service.ServerInfoService;
import com.gamedo.gameServer.data.ServerInfoConfig;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;

@Controller
@RequestMapping(value = "/api/serverinfo")
public class ServerInfoController extends BaseApiController {
	@Autowired
	private ServerInfoService serverInfoService;
	private final static String SERVER_INFO_CONFIG_LIST = "/serverInfoList";
	private final static String SERVER_INFO_CONFIG_DETAIL = "/serverInfoDetail";
	private final static String SERVER_INFO_CONFIG_UPDATE = "/serverInfoUpdate";

	/**
	 * 获取服务器信息列表
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/serverInfoList", method = RequestMethod.GET)
	public void getServerConfigInfos(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(SERVER_INFO_CONFIG_LIST, request, response);
		ServerInfoConfigDataListReponseMessage message = new ServerInfoConfigDataListReponseMessage();
		List<ServerInfoConfig> list = serverInfoService.getServerConfigInfos();
		message.setServerInfoList(list);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public void getServerInfoConfigById(@PathVariable("id") int id, HttpServletRequest request,
			HttpServletResponse response) {
		Packet packet = new Packet(SERVER_INFO_CONFIG_DETAIL, request, response);
		ServerInfoConfigDataReponseMessage message = new ServerInfoConfigDataReponseMessage();
		ServerInfoConfig serverInfoConfig = serverInfoService.getServerInfoConfigById(id);
		if (null == serverInfoConfig) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		message.setServerInfoConfig(serverInfoConfig);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	@RequestMapping(value = "/{id}/serverInfoUpdate", method = RequestMethod.POST)
	public void serverInfoUpdate(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response)
			throws ParseException {
		Packet packet = new Packet(SERVER_INFO_CONFIG_UPDATE, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.TRUE);
			packet.send(message);
			return;
		}
		ServerInfoConfig serverInfoConfig = serverInfoService.getServerInfoConfigById(id);
		if (null == serverInfoConfig) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Object openTimeObj = json.get("openTime");
		if (openTimeObj != null) {
			Date openTime = sdf.parse((String) json.get("openTime"));
			serverInfoConfig.setOpenTime(openTime);
		}else{
			serverInfoConfig.setOpenTime(null);
		}
		Object closeTimeObj = json.get("closeTime");
		if (closeTimeObj != null) {
			Date closeTime = sdf.parse((String) json.get("closeTime"));
			serverInfoConfig.setCloseTime(closeTime);
		}else{
			serverInfoConfig.setCloseTime(null);
		}
		Object safetyIpStrObj = json.get("safetyIpStr");
		if (safetyIpStrObj != null) {
			serverInfoConfig.setSafetyIpStr((String) json.get("safetyIpStr"));
		}
		serverInfoService.update(serverInfoConfig);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

}
