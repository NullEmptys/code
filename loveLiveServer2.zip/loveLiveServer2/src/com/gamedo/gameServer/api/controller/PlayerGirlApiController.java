package com.gamedo.gameServer.api.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gamedo.gameServer.api.message.PlayerGirlsDataReponseMessage;
import com.gamedo.gameServer.core.PlayerGirlBaseDataChangeItem;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.entity.player.PlayerGirl;
import com.gamedo.gameServer.exception.GirlSignedException;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.player.PlayerGirlData;
import com.gamedo.gameServer.service.player.GirlService;
import com.gamedo.gameServer.service.player.PlayerService;

/**
 * 玩家模特api
 * 
 * @author liuxing
 */
@Controller
@RequestMapping(value = "/api/playerGirl")
public class PlayerGirlApiController extends BaseApiController {
	@Autowired
	private PlayerService playerService;
	@Autowired
	private GirlService girlService;

	private final static String PLAYER_GIRLS_LIST = "/playerGirls";
	private final static String PLAYER_GIRLS_ADD = "/addPlayerGirl";
	private final static String PLAYER_GIRLS_UPDATE = "/updatePlayerGirl";

	/**
	 * 获取玩家模特列表
	 * 
	 * @param id
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public void queryPlayerGirls(@PathVariable("id") int id, HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_GIRLS_LIST, request, response);
		Player player = playerService.getPlayerById(id);
		List<PlayerGirlData> list = girlService.getPlayerGirlDatas(player);
		List<Map<String, Object>> datas = new ArrayList<>();
		for (PlayerGirlData playerGirlData : list) {
			Map<String, Object> map = new HashMap<>();
			map.put("girlId", playerGirlData.getGirlId());
			map.put("girlName", girlService.getGirl(playerGirlData.getGirlId()).getName());
			map.put("level", playerGirlData.getLevel());
			datas.add(map);
		}
		PlayerGirlsDataReponseMessage message = new PlayerGirlsDataReponseMessage();
		message.setPlayerGirlList(datas);
		message.setCode(CommonResponseMessage.TRUE);
		packet.send(message);
	}

	/**
	 * 新增模特签约
	 * 
	 * @param playerId
	 * @param girlId
	 * @param type
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public void signedPlayerGirl(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_GIRLS_ADD, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		int playerId = (int) json.get("playerId");
		int girlId = (int) json.get("girlId");
		int type = (int) json.get("type");
		PlayerGirl playerGirl = girlService.getPlayerGirl(playerId, girlId);
		if (playerGirl == null) {
			try {
				playerGirl = new PlayerGirl();
				playerGirl.setPlayerId(playerId);
				playerGirl.setGirlId(girlId);
				girlService.addPlayerGirl(playerGirl);
				girlService.girlSigned(playerId, girlId, type);
				if(playerService.isOnline(playerId)) {
					PlayerGirlBaseDataChangeItem changeItem = new PlayerGirlBaseDataChangeItem();
					changeItem.setGirlId(playerGirl.getGirlId());
					changeItem.setExp(playerGirl.getExp());
					changeItem.setLevel(playerGirl.getLevel());
					Player player = playerService.getPlayerById(playerId);
					player.changed.addChangedItem(changeItem);
				}
				message.setCode(CommonResponseMessage.TRUE);
			} catch (GirlSignedException e) {
				message.setCode(CommonResponseMessage.FALSE);
				e.printStackTrace();
			}
		} else {
			message.setCode(CommonResponseMessage.FALSE);
		}

		packet.send(message);
	}

	/**
	 * 修改模特数据
	 * 
	 * @param playerId
	 * @param girlId
	 * @param cdTime
	 * @param level
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public void updatePlayerGirl(HttpServletRequest request, HttpServletResponse response) {
		Packet packet = new Packet(PLAYER_GIRLS_UPDATE, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		Map<String, Object> json = this.getRequestMessage(request);
		if (json == null) {
			message.setCode(CommonResponseMessage.FALSE);
			packet.send(message);
			return;
		}
		int playerId = (int) json.get("playerId");
		int girlId = (int) json.get("girlId");
		long cdTime =Long.parseLong((String) json.get("cdTime"));
		int level = (int) json.get("level");
		PlayerGirl playerGirl = girlService.getPlayerGirl(playerId, girlId);
		if (playerGirl != null) {
			playerGirl.setLevel(level);
			girlService.updatePlayerGirl(playerGirl);
			if(playerService.isOnline(playerId)) {
				PlayerGirlBaseDataChangeItem changeItem = new PlayerGirlBaseDataChangeItem();
				changeItem.setGirlId(playerGirl.getGirlId());
				changeItem.setExp(playerGirl.getExp());
				changeItem.setLevel(playerGirl.getLevel());
				Player player = playerService.getPlayerById(playerId);
				player.changed.addChangedItem(changeItem);
			}
			message.setCode(CommonResponseMessage.TRUE);
		} else {
			message.setCode(CommonResponseMessage.FALSE);
		}

		packet.send(message);
	}
}
