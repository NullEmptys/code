package com.gamedo.gameServer.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gamedo.gameServer.data.ServerInfoConfig;
import com.gamedo.gameServer.db.editor.ServerInfoDao;
import com.gamedo.gameServer.service.serverinfo.ServerInfoConfigService;

@Service
public class ServerInfoService {
	
	@Autowired
	private ServerInfoConfigService serverInfoServie;
	@Autowired
	private ServerInfoDao serverInfoDao;

	public List<ServerInfoConfig> getServerConfigInfos() {
		return serverInfoDao.findAll();
	}

	public ServerInfoConfig getServerInfoConfigById(int id) {
		return serverInfoDao.loadServerInfoConfigById(id);
	}

	public ServerInfoConfig update(ServerInfoConfig serverInfoConfig) {
		ServerInfoConfig obj = serverInfoDao.updateEntity(serverInfoConfig);
		serverInfoServie.loadServerInfoConfigInfos();
		return obj;
	}
}
