package com.gamedo.gameServer.api.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gamedo.gameServer.data.channel.Channel;
import com.gamedo.gameServer.db.editor.ChannelDao;

@Service
public class ChannelService {
	@Autowired
	private ChannelDao channelDao;

	public Channel findById(String channelId) {
		return channelDao.findById(channelId);
	}
}
