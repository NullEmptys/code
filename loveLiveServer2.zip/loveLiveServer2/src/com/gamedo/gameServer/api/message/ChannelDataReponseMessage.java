package com.gamedo.gameServer.api.message;

import com.gamedo.gameServer.data.channel.Channel;
import com.gamedo.gameServer.message.CommonResponseMessage;

public class ChannelDataReponseMessage extends CommonResponseMessage {
	private Channel channel;

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}

}
