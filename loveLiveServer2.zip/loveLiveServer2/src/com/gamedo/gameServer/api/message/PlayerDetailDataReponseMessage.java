package com.gamedo.gameServer.api.message;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.message.CommonResponseMessage;

public class PlayerDetailDataReponseMessage extends CommonResponseMessage implements Serializable {

	private static final long serialVersionUID = 7884337887806400985L;
	private Map<String, Object> playerInfo = new HashMap<>();

	public Map<String, Object> getPlayerInfo() {
		return playerInfo;
	}

	public void setPlayerInfo(Player player) {
		this.playerInfo.put("playerId", player.getId());
		this.playerInfo.put("name", player.getName());
		this.playerInfo.put("level", player.getLevel());
		this.playerInfo.put("glod", player.getGold());
		this.playerInfo.put("money", player.getMoney());
		this.playerInfo.put("achieveValue", player.getAchieveValue());
		this.playerInfo.put("state", player.getState());
		this.playerInfo.put("createTime", player.getCreateTime());
		this.playerInfo.put("registIp", player.getRegistIp());
		this.playerInfo.put("lastLoginTime", player.getLastLoginTime());
		this.playerInfo.put("lastLoginIp", player.getLastLoginIp());
		this.playerInfo.put("lastLogoutTime", player.getLastLogoutTime());
		this.playerInfo.put("totalLoginCounts", player.getTotalLoginCounts());
		this.playerInfo.put("playerType", player.getPlayerType());
		this.playerInfo.put("tili", player.getTili());
		this.playerInfo.put("channelId", player.getChannelId());
		this.playerInfo.put("girlId", player.getGirlId());
	}

}
