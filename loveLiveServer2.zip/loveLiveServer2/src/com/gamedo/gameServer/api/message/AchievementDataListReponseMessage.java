package com.gamedo.gameServer.api.message;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.gamedo.gameServer.message.CommonResponseMessage;

public class AchievementDataListReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = -5684612274242017185L;
	List<Map<String, Object>> achievementList = new ArrayList<Map<String,Object>>();

	public List<Map<String, Object>> getAchievementList() {
		return achievementList;
	}

	public void setAchievementList(List<Map<String, Object>> achievementList) {
		this.achievementList = achievementList;
	}

}
