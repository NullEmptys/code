package com.gamedo.gameServer.api.message;

import java.io.Serializable;
import java.util.List;

import com.gamedo.gameServer.activity.Activity;
import com.gamedo.gameServer.message.CommonResponseMessage;

public class ActivityDataListReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = -6973634890742353800L;
	private List<Activity> activityList;

	public List<Activity> getActivityList() {
		return activityList;
	}

	public void setActivityList(List<Activity> activityList) {
		this.activityList = activityList;
	}

}
