package com.gamedo.gameServer.api.message;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.gamedo.gameServer.message.CommonResponseMessage;

public class MonitorDataReponseMessage extends CommonResponseMessage implements Serializable{
	private static final long serialVersionUID = -7460495836280958947L;
	private Map<String,Object> systemInfo = new HashMap<String,Object>();
	public Map<String, Object> getSystemInfo() {
		return systemInfo;
	}
	public void setSystemInfo(Map<String, Object> systemInfo) {
		this.systemInfo = systemInfo;
	}
	
	
}
