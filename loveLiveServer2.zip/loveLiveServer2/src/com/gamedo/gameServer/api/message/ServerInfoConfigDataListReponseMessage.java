package com.gamedo.gameServer.api.message;

import java.io.Serializable;
import java.util.List;

import com.gamedo.gameServer.data.ServerInfoConfig;
import com.gamedo.gameServer.message.CommonResponseMessage;

public class ServerInfoConfigDataListReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = 9100879217951835995L;
	private List<ServerInfoConfig> serverInfoList;

	public List<ServerInfoConfig> getServerInfoList() {
		return serverInfoList;
	}

	public void setServerInfoList(List<ServerInfoConfig> serverInfoList) {
		this.serverInfoList = serverInfoList;
	}

}
