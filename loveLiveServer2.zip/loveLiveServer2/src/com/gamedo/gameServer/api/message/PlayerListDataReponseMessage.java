package com.gamedo.gameServer.api.message;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonResponseMessage;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerListDataReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = -4335717618074485364L;

	private List<Map<String, Object>> playerBaseList;

	public List<Map<String, Object>> getPlayerBaseList() {
		return playerBaseList;
	}

	public void setPlayerBaseList(List<Map<String, Object>> playerBaseList) {
		this.playerBaseList = playerBaseList;
	}

}
