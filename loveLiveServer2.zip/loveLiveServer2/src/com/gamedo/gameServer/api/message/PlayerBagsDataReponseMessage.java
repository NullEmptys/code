package com.gamedo.gameServer.api.message;

import java.io.Serializable;

import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.message.player.BagData;

public class PlayerBagsDataReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = -5309229918780344693L;
	/** 角色背包数据 */
	private BagData bagData;

	public BagData getBagData() {
		return bagData;
	}

	public void setBagData(BagData bagData) {
		this.bagData = bagData;
	}

}
