package com.gamedo.gameServer.api.message;

import java.io.Serializable;

import com.gamedo.gameServer.activity.Activity;
import com.gamedo.gameServer.message.CommonResponseMessage;

public class ActivityDataReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = 7962056209395747758L;
	private Activity activity;

	public Activity getActivity() {
		return activity;
	}

	public void setActivity(Activity activity) {
		this.activity = activity;
	}

}
