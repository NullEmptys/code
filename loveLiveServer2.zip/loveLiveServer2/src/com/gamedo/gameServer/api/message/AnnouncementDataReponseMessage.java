package com.gamedo.gameServer.api.message;

import java.io.Serializable;

import com.gamedo.gameServer.data.announcement.Announcement;
import com.gamedo.gameServer.message.CommonResponseMessage;

public class AnnouncementDataReponseMessage extends CommonResponseMessage implements Serializable {
	private static final long serialVersionUID = -4972722997115339411L;
	private Announcement announcement;

	public Announcement getAnnouncement() {
		return announcement;
	}

	public void setAnnouncement(Announcement announcement) {
		this.announcement = announcement;
	}

}
