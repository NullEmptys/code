package com.gamedo.gameServer.constant;

/**
 * 排行榜类型
 * @author libm
 *
 */
public enum RankType {

	GIRL_TOTAL_RANK(1,6,"模特人气榜"),
	ACHIEVEMENT_RANK(2,1000,"成就榜单"),
	SINGLE_GIRL_RANK(3,1000,"单个模特使用率榜单");
	
	final int type;
	
	final int rankSize;

	final String desc;
	
	private RankType(int type,int rankSize, String desc) {
		this.type = type;
		this.rankSize = rankSize;
		this.desc = desc;
	}

	public int getType() {
		return type;
	}

	public String getDesc() {
		return desc;
	}

	public static RankType getRankType(int type) {
		for(RankType rankType : RankType.values()) {
			if(rankType != null && rankType.getType() == type) {
				return rankType;
			}
		}
		return null;
	}

	public int getRankSize() {
		return rankSize;
	}
	
	
}
