package com.gamedo.gameServer.constant;

/**
 * 气泡类型
 * @author libm
 *
 */
public enum BubbleType {
 
	CURRENCY(1,"货币"),
	GIFT(2,"礼包"),
	BOMB(3,"炸弹");
	
	final int bubbleType;
	
	final String desc;
	
	private BubbleType(int bubbleType,String desc) {
		this.bubbleType = bubbleType;
		this.desc = desc;
	}

	public int getBubbleType() {
		return bubbleType;
	}

	public String getDesc() {
		return desc;
	}
	
}
