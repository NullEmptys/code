package com.gamedo.gameServer.constant;

/**
 * 
 * @author libm
 *
 */
public enum Shop {

	CLOTH_SHOP(1,"服装商店"),
	ITEM_SHOP(2,"道具商店");
	
	final int shopId;
	
	final String shopName;
	
	private Shop(int shopId,String shopName) {
		this.shopId = shopId;
		this.shopName = shopName;
	}

	public int getShopId() {
		return shopId;
	}

	public String getShopName() {
		return shopName;
	}
	
}
