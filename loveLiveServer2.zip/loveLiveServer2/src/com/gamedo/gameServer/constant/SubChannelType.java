package com.gamedo.gameServer.constant;

/**
 * 渠道类型
 * @author libm
 *
 */
public enum SubChannelType {
	DEFAULT("0","游客"),
	WECHAT("1","微信"),
	QQ("2","腾讯QQ");
	
	final String subChannelId;
	
	final String subChannelName;
	
	private SubChannelType(String subChannelId,String subChannelName) {
		this.subChannelId = subChannelId;
		this.subChannelName = subChannelName;
	}

	public String getSubChannelId() {
		return subChannelId;
	}

	public String getSubChannelName() {
		return subChannelName;
	}
	
}
