package com.gamedo.gameServer.constant;

/**
 * 场景
 * @author libm
 *
 */
public enum Scene {

	GIRL_UI(0,"默认"),
	
	CORE_GAMEPLAY(1,"核心玩法");
	
	final int type;//场景类型
	final String sceneName;//场景名称
	
	private Scene(int type,String sceneName) {
		this.type = type;
		this.sceneName = sceneName;
	}

	public int getType() {
		return type;
	}

	public String getSceneName() {
		return sceneName;
	}
	
	
}
