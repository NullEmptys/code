package com.gamedo.gameServer.constant;

/**
 * 动作分类
 * @author libm
 *
 */
public enum ActionType {

	STAND(1,"站立"),
	LIE(2,"躺"),
	CE_WO(3,"侧卧"),
	PA(4,"趴"),
	GUO_DU(5,"过渡"),
	KAI_CHANG(6,"开场"),
	END(7,"结束"),
	DANCE(8,"舞");
	
	final int actionType;

	final String name;

	private ActionType(int actionType, String name) {
		this.actionType = actionType;
		this.name = name;
	}

	public int getActionType() {
		return actionType;
	}

	public String getName() {
		return name;
	}
}
