package com.gamedo.gameServer.constant;

public enum StyleAttribute {
	BEAUTIFUL(1, "华丽"), 
	SIMPLE(2, "简约"), 
	POLITENESS(3, "优雅"), 
	ACTIVE(4, "活泼"), 
	RIPE(5, "成熟"), 
	LOVELINESS(6,"可爱"), 
	SEXY(7, "性感"), 
	PURE(8, "清纯"), 
	COOL(9, "清凉"), 
	WARM(10, "保暖");

	final private int id;
	final private String desc;

	private StyleAttribute(int id, String desc) {
		this.id = id;
		this.desc = desc;
	}

	public int getId() {
		return id;
	}

	public String getDesc() {
		return desc;
	}
	
	public static StyleAttribute getStyleAttribute(int id){
		StyleAttribute[] styleAtt = StyleAttribute.values();
		if(styleAtt[0].getId() == id){
			return styleAtt[0];
		}
		return null;
	}

}
