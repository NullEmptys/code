package com.gamedo.gameServer.constant;

public enum ScoreLevel {

	FAIL(0,"失败"),
	NOT_BAD(1,"还不错"),
	GOOD(2,"很好"),
	SUPER_PRAISE(3,"超赞"),
	PERFECT(4,"完美");
	
	final int scoreLevel;
	
	final String name;
	
	private ScoreLevel(int scoreLevel,String name) {
		this.scoreLevel = scoreLevel;
		this.name = name;
	}

	public int getScoreLevel() {
		return scoreLevel;
	}

	public String getName() {
		return name;
	}
	
}
