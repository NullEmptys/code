package com.gamedo.gameServer.constant;

/**
 * 系统开关
 * 
 * @author IPOC-HUANGPING
 *
 */
public enum AppOpenType {
	ANNOUNCEMENT(1, "announcement", "公告"), 
	SYSTEM_CONFIG(2, "systemConfig", "系统设置"), 
	SUPPORT(3, "support","后援团"), 
	ENGAGEMENT(4, "engagement", "约会"), 
	DAILYMISSION(5, "dialymission", "活跃度"), 
	CHIEVEMENT(6,"chievement","成就"), 
	PHOTO(7, "photo", "相册"), 
	EMAIL(8, "email", "邮件"), 
	HELPGUIDE(9, "guide", "新手引导");

	private int id;
	private String key;
	private String desc;

	private AppOpenType(int id, String key, String desc) {
		this.id = id;
		this.key = key;
		this.desc = desc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
