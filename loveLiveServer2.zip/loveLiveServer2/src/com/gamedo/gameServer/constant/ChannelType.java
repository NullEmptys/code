package com.gamedo.gameServer.constant;

public enum ChannelType {

	DEFAULT("0","自渠道"),
	APP_STORE("1","苹果"),
	WECHAT("2","微信"),
	QQ("3","QQ"),
	BA_ZHUA_YU("4","八爪鱼"),
	BA_SI("5","百思");
	
	final String channelId;
	
	final String channelName;
	
	private ChannelType(String channelId,String channelName) {
		this.channelId = channelId;
		this.channelName = channelName;
	}

	public String getChannelId() {
		return channelId;
	}

	public String getChannelName() {
		return channelName;
	}
	
	public static ChannelType getChannelType(String channelId) {
		for(ChannelType channelType : ChannelType.values()) {
			if(channelType != null && channelType.getChannelId().equals(channelId)) {
				return channelType;
			}
		}
		return null;
	}
}
