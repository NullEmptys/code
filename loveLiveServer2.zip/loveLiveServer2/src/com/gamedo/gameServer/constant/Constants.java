package com.gamedo.gameServer.constant;

/**
 * 常量池
 * @author IPOC-HUANGPING
 *
 */
public class Constants {
	
	public static final int SUCCESS = 1;//成功标示
	
	public static final int FAIL = 0;//失败标示
	
	public static final int COMMITBUGCOUNT = 3;//最多提交bug次数
	
	public static final int RECORD = 1;//记录数据正常
	
	public static final int TILI_RECOVER_POINT = 1;//体力恢复次数
}
