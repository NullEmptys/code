package com.gamedo.gameServer.constant;

/**
 * 服装类型
 * @author libm
 *
 */
public enum ClothType {

	HAIR(0,"发型"),
	ONE_PIECE(1,"连衣裙"),
	COTE(2,"外套"),
	UP_CLOTH(3,"上装"),
	DOWN_CLOTH(4,"下装"),
	SOCK(5,"袜子"),
	SHOE(6,"鞋"),
	HAIR_PARTS(7,"发饰"),
	GLASS(8,"眼镜"),
	EAR_PARTS(9,"耳饰"),
	FACE_PART(10,"妆容"),
	HAND_PART(11,"手环"),
	RING_PART(12,"戒指"),
	SUIT(13,"套装"),
	BIKINI(14,"比基尼"),
	XIANGLIANG(15,"项链"),
	JIAOHUAN(16,"脚环");
	
	final int clothType;

	final String name;

	private ClothType(int clothType, String name) {
		this.clothType = clothType;
		this.name = name;
	}

	public int getClothType() {
		return clothType;
	}

	public String getName() {
		return name;
	}
	
}
