package com.gamedo.gameServer.constant;

/**
 * 服装子类型
 * @author libm
 *
 */
public enum ClothSubType {

	SCHOOL(0,"校园"),
	SPRING(1,"春天"),
	SUMMER(2,"夏天"),
	SPORT(3,"运动"),
	PARTY(4,"派对"),
	PALACE(5,"宫廷"),
	MUSIC(6,"音乐"),
	QUEEN(7,"女王"),
	WINTER(8,"冬天"),
	LADY(9,"淑女"),
	HOME(10,"居家"),
	OFFICE(11,"办公室"),
	STAR(12,"明星"),
	STRANGE(13,"奇幻"),
	FABLE(14,"童话");
	
	final int clothSubType;

	final String name;

	private ClothSubType(int clothSubType, String name) {
		this.clothSubType = clothSubType;
		this.name = name;
	}

	public int getClothSubType() {
		return clothSubType;
	}

	public String getName() {
		return name;
	}
	
	public static ClothSubType getClothSubType(int clothSubType) {
		for(ClothSubType subType : ClothSubType.values()) {
			if(subType != null && subType.getClothSubType() == clothSubType) {
				return subType;
			}
		}
		return null;
	}
}
