package com.gamedo.gameServer.constant;

/**
 * 场景属性类型
 * @author libm
 *
 */
public enum SceneAttribute {

	LIGHT(1,"白天"),
	NIGHT(2,"晚上");
	
	final int attribute;
	
	final String desc;
	
	private SceneAttribute(int attribute,String desc) {
		this.attribute = attribute;
		this.desc = desc;
	}

	public int getAttribute() {
		return attribute;
	}

	public String getDesc() {
		return desc;
	}
	
	
}
