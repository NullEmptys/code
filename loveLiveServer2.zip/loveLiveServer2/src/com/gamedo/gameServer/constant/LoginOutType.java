package com.gamedo.gameServer.constant;

public enum LoginOutType {
	FORCE_LOGIN_OUT(1,"强制踢下线"),
	STOP_LOGIN_OUT(2,"封号");
	
	private int type;
	private String desc;
	
	private LoginOutType(int type,String desc){
		this.type = type;
		this.desc = desc;
	}
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
