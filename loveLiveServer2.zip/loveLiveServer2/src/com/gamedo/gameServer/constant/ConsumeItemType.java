package com.gamedo.gameServer.constant;

/**
 * 消耗品类型
 * @author libm
 *
 */
public enum ConsumeItemType {

	FOOD(1,"食物"),
	FLOWER(2,"花卉"),
	ORNAMENT(3,"饰品"),
	OTHER(4,"其它");
	
	final int type;
	
	final String name;
	
	private ConsumeItemType(int type,String name) {
		this.type = type;
		this.name = name;
	}

	public int getType() {
		return type;
	}

	public String getName() {
		return name;
	}
	
}
