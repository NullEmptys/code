package com.gamedo.gameServer.constant;

public enum QuestRewardType {

	FIRST_PERFECT(1,"首次完美通关奖励"),
	FIRST_SUCCESS(2,"首次通关奖励"),
	PROBABILITY(3,"通关几率奖励");
	
	final int type;
	
	final String desc;
	
	private QuestRewardType(int type,String desc) {
		this.desc = desc;
		this.type = type;
	}

	public int getType() {
		return type;
	}

	public String getDesc() {
		return desc;
	}
	
}
