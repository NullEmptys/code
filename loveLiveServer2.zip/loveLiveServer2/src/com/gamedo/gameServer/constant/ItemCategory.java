package com.gamedo.gameServer.constant;

/**
 * 物品类型
 * @author libm
 *
 */
public enum ItemCategory {
	CONSUME(0,"消耗品"),
	CLOTH(1,"服装"),
	ACTION(2,"动作"),
	EFFECT(3,"特效"),
	PHOTO_FRAME(4,"相框"),
	XIEZHEN(5,"写真"),
	AVI(6,"视频");
	
	final int itemCategory;

	final String name;

	private ItemCategory(int itemCategory, String name) {
		this.itemCategory = itemCategory;
		this.name = name;
	}

	public int getItemCategory() {
		return itemCategory;
	}

	public String getName() {
		return name;
	}

}
