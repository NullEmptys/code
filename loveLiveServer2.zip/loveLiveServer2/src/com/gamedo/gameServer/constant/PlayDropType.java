package com.gamedo.gameServer.constant;

/**
 * 玩法掉落类型
 * @author libm
 *
 */
public enum PlayDropType {

	DROP_ITEM(1, "掉落服装"),

	DROP_ACTION(2, "掉落动作"),
	
	DROP_EFFECT(3,"掉落特效");

	final int type;
	final String title;

	private PlayDropType(int type,String title) {
		this.type = type;
		this.title = title;
	}

	public int getType() {
		return type;
	}

	public String getTitle() {
		return title;
	}
}
