package com.gamedo.gameServer.message.girl;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonRequestMessage;

/**
 * 
 * @author libm
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SaveGirlEquipsRequestMessage extends CommonRequestMessage{

	/**
	 * 模特id
	 */
	private int girlId;
	
	private List<PlayTypeClothData> playTypeClothData;

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public List<PlayTypeClothData> getPlayTypeClothData() {
		return playTypeClothData;
	}

	public void setPlayTypeClothData(List<PlayTypeClothData> playTypeClothData) {
		this.playTypeClothData = playTypeClothData;
	}

}
