package com.gamedo.gameServer.message.girl;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonRequestMessage;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UnlockModelRequestMessage extends CommonRequestMessage{
	private int type;//使用的类型1钻石2金币
	private int modelId;// 解锁的模特id

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}
	
	
	
}
