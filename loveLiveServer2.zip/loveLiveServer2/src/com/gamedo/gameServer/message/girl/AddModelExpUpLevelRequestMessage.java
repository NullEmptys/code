package com.gamedo.gameServer.message.girl;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonRequestMessage;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AddModelExpUpLevelRequestMessage extends CommonRequestMessage{
	//道具id使用道具获得好感度
	private int itemId;

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	
}
