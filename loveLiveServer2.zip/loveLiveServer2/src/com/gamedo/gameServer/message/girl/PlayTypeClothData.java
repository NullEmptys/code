package com.gamedo.gameServer.message.girl;

import java.util.List;

/**
 * 
 * @author libm
 *
 */
public class PlayTypeClothData {

	/**
	 * 玩法
	 */
	private int playType;
	
	private List<TypeClothData> typeClothData;

	public int getPlayType() {
		return playType;
	}

	public void setPlayType(int playType) {
		this.playType = playType;
	}

	public List<TypeClothData> getTypeClothData() {
		return typeClothData;
	}

	public void setTypeClothData(List<TypeClothData> typeClothData) {
		this.typeClothData = typeClothData;
	}
	
}
