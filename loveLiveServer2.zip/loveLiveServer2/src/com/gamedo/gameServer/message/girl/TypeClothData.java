package com.gamedo.gameServer.message.girl;

import java.util.List;

/**
 * 
 * @author libm
 *
 */
public class TypeClothData {

	/**
	 * 默认   外装    内装
	 */
	private int type;
	
	private List<GirlPartCloth> girlPartCloth;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public List<GirlPartCloth> getGirlPartCloth() {
		return girlPartCloth;
	}

	public void setGirlPartCloth(List<GirlPartCloth> girlPartCloth) {
		this.girlPartCloth = girlPartCloth;
	}
	
}
