package com.gamedo.gameServer.message.girl;

/**
 * 
 * @author libm
 *
 */
public class GirlPartCloth {

	private int part;
	
	private int clothId;
	
	public int getPart() {
		return part;
	}

	public void setPart(int part) {
		this.part = part;
	}

	public int getClothId() {
		return clothId;
	}

	public void setClothId(int clothId) {
		this.clothId = clothId;
	}

}
