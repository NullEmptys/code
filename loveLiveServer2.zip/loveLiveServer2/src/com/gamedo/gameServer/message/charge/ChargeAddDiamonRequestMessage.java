package com.gamedo.gameServer.message.charge;

import com.gamedo.gameServer.message.CommonRequestMessage;

public class ChargeAddDiamonRequestMessage extends CommonRequestMessage{
	private String OrderNum;
	private String goodsId;

	public String getOrderNum() {
		return OrderNum;
	}

	public void setOrderNum(String orderNum) {
		OrderNum = orderNum;
	}


	public String getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}
}
