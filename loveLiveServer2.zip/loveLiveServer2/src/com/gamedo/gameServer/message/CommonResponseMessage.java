package com.gamedo.gameServer.message;

import java.util.ArrayList;
import java.util.List;

import com.gamedo.gameServer.update.UpdateObject;

/**
 * 
 * @author libm
 *
 */
public class CommonResponseMessage {
	
	public static final String TRUE = "0";
	
	public static final String FALSE = "1";
	
	public static final String TOKEN_ERROR = "2";
	
	public static final String SERVER_NOT_OPEN = "3";

	/**求服务器处理客户端请求结果   1：成功  0：失败*/
	private String code = FALSE;
	
	/**状态描述*/
	private String desc;
	
	private List<UpdateObject> updateObj = new ArrayList<>();

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public List<UpdateObject> getUpdateObj() {
		return updateObj;
	}

	public void setUpdateObj(List<UpdateObject> updateObj) {
		this.updateObj = updateObj;
	}

}
