package com.gamedo.gameServer.message;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 
 * @author libm
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonRequestMessage {

	/*角色id*/
	private int playerID;

	public int getPlayerID() {
		return playerID;
	}

	public void setPlayerID(int playerID) {
		this.playerID = playerID;
	}
}
