package com.gamedo.gameServer.message.bag;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonRequestMessage;

/**
 * 出售物品
 * 客户端请求服务器消息内容
 * @author libm
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SellItemRequestMessage extends CommonRequestMessage {

	/**背包id*/
	private int bagId;
	/**背包格id*/
	private int gridId;
	/**物品id*/
	private int itemId;
	private int instanceId;
	/**出售数量*/
	private int count;

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getBagId() {
		return bagId;
	}

	public void setBagId(int bagId) {
		this.bagId = bagId;
	}

	public int getGridId() {
		return gridId;
	}

	public void setGridId(int gridId) {
		this.gridId = gridId;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(int instanceId) {
		this.instanceId = instanceId;
	}
	
}
