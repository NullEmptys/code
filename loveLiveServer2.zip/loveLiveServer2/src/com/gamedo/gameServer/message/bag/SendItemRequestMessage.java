package com.gamedo.gameServer.message.bag;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonRequestMessage;

/**
 * 寄送物品给模特
 * 客户端请求服务器消息内容
 * @author libm
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SendItemRequestMessage extends CommonRequestMessage {

	private int girlId;
	
	private List<SendItemData> sendItems;

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public List<SendItemData> getSendItems() {
		return sendItems;
	}

	public void setSendItems(List<SendItemData> sendItems) {
		this.sendItems = sendItems;
	}

	
	
}
