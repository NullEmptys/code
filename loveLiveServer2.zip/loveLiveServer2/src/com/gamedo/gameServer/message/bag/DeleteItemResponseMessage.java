package com.gamedo.gameServer.message.bag;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 丢弃物品
 * 服务器返回客户端消息内容
 * @author libm
 *
 */
public class DeleteItemResponseMessage extends CommonResponseMessage{

}
