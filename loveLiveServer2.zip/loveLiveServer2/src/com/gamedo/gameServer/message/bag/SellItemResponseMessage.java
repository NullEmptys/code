package com.gamedo.gameServer.message.bag;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 出售物品
 * 服务器返回客户端消息内容
 * @author libm
 *
 */
public class SellItemResponseMessage extends CommonResponseMessage {

	
}
