package com.gamedo.gameServer.message.help;

import com.gamedo.gameServer.message.CommonRequestMessage;

public class HelpGuideRequestMessage extends CommonRequestMessage{
	//新手指导步骤
	private int guideStep;

	public int getGuideStep() {
		return guideStep;
	}

	public void setGuideStep(int guideStep) {
		this.guideStep = guideStep;
	}
	
}
