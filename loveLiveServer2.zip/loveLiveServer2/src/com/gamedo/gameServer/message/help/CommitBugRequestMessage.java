package com.gamedo.gameServer.message.help;

import com.gamedo.gameServer.message.CommonRequestMessage;

/**
 * 提交bug信息
 * @author IPOC-HUANGPING
 *
 */
public class CommitBugRequestMessage extends CommonRequestMessage{
	private String context;

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}
}
