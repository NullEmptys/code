package com.gamedo.gameServer.message.dailyMission;

public class BoxStatus {
	private int boxId;
	private int status;
	
	public int getBoxId() {
		return boxId;
	}
	public void setBoxId(int boxId) {
		this.boxId = boxId;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	
}
