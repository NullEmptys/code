package com.gamedo.gameServer.message.dailyMission;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonRequestMessage;
/**
 * 领取活跃度相关及任务奖励
 * @author IPOC-HUANGPING
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DailyMissionGetRewardRequestMessage extends CommonRequestMessage{
	private int rewardType;//领取的奖励类型1日宝箱 2周宝箱奖励 3任务奖励
	private int missionId;//任务id
	private int activeValue;//领取指定档位的活跃度
	
	public int getRewardType() {
		return rewardType;
	}
	public void setRewardType(int rewardType) {
		this.rewardType = rewardType;
	}
	public int getMissionId() {
		return missionId;
	}
	public void setMissionId(int missionId) {
		this.missionId = missionId;
	}
	public int getActiveValue() {
		return activeValue;
	}
	public void setActiveValue(int activeValue) {
		this.activeValue = activeValue;
	}
}
