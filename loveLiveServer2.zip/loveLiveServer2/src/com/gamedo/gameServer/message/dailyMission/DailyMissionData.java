package com.gamedo.gameServer.message.dailyMission;

import java.io.Serializable;

public class DailyMissionData implements Serializable{

	/**
	 * 序列化
	 */
	private static final long serialVersionUID = 1L;

	private int missionDefineId;
	private int missionDetail;
	private int status;
	
	public int getMissionDefineId() {
		return missionDefineId;
	}
	public void setMissionDefineId(int missionDefineId) {
		this.missionDefineId = missionDefineId;
	}
	public int getMissionDetail() {
		return missionDetail;
	}
	public void setMissionDetail(int missionDetail) {
		this.missionDetail = missionDetail;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
}
