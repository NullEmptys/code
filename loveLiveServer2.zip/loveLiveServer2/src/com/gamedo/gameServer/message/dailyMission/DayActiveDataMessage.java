package com.gamedo.gameServer.message.dailyMission;

import java.io.Serializable;
import java.util.List;

public class DayActiveDataMessage implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**当前日活跃度值*/
	private int dailyActiveValue;
	/**当前周活跃度值*/
	private int weekActiveValue;
	 
	private List<BoxStatus> boxStatus;
	
	public int getDailyActiveValue() {
		return dailyActiveValue;
	}
	public void setDailyActiveValue(int dailyActiveValue) {
		this.dailyActiveValue = dailyActiveValue;
	}
	public int getWeekActiveValue() {
		return weekActiveValue;
	}
	public void setWeekActiveValue(int weekActiveValue) {
		this.weekActiveValue = weekActiveValue;
	}
	public List<BoxStatus> getBoxStatus() {
		return boxStatus;
	}
	public void setBoxStatus(List<BoxStatus> boxStatus) {
		this.boxStatus = boxStatus;
	}
}
