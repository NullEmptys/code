package com.gamedo.gameServer.message.dailyMission;

import com.gamedo.gameServer.message.CommonRequestMessage;

public class PhotographRequestMessage extends CommonRequestMessage{
	//拍摄照片数量
	private int photographNum;

	public int getPhotographNum() {
		return photographNum;
	}

	public void setPhotographNum(int photographNum) {
		this.photographNum = photographNum;
	}
	
	
}
