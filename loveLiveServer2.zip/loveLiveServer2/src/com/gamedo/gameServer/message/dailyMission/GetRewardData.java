package com.gamedo.gameServer.message.dailyMission;

import java.util.List;

public class GetRewardData {
	private List<Integer> rewardIds;
	private List<Integer> rewardTypes;
	private List<Integer> rewardNums;
	
	public List<Integer> getRewardIds() {
		return rewardIds;
	}
	public void setRewardIds(List<Integer> rewardIds) {
		this.rewardIds = rewardIds;
	}
	public List<Integer> getRewardTypes() {
		return rewardTypes;
	}
	public void setRewardTypes(List<Integer> rewardTypes) {
		this.rewardTypes = rewardTypes;
	}
	public List<Integer> getRewardNums() {
		return rewardNums;
	}
	public void setRewardNums(List<Integer> rewardNums) {
		this.rewardNums = rewardNums;
	}
	
	
}
