package com.gamedo.gameServer.message.dailyMission;

import com.gamedo.gameServer.message.CommonRequestMessage;

public class SocialMissionRequestMessage extends CommonRequestMessage{
	private int Type;//点赞类型
	private int girlId ;//模特id

	public int getType() {
		return Type;
	}

	public void setType(int type) {
		Type = type;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}		

}
