package com.gamedo.gameServer.message.dailyMission;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.entity.dailymission.PlayerActive;
import com.gamedo.gameServer.entity.dailymission.PlayerDailyMission;
import com.gamedo.gameServer.message.CommonResponseMessage;
/**
 * 请求每日任务列表返回客户端数据
 * @author IPOC-HUANGPING
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DailyMissionResponseMessage extends CommonResponseMessage{
	private List<DailyMissionData> dailyMission;
	private DayActiveDataMessage playerActive;
	
	public List<DailyMissionData> getDailyMission() {
		return dailyMission;
	}
	public void setDailyMission(List<DailyMissionData> dailyMission) {
		this.dailyMission = dailyMission;
	}
	public DayActiveDataMessage getPlayerActive() {
		return playerActive;
	}
	public void setPlayerActive(DayActiveDataMessage playerActive) {
		this.playerActive = playerActive;
	}
}
