package com.gamedo.gameServer.message.dailyMission;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 领取奖励数据
 * @author IPOC-HUANGPING
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetRewardResponseMessage extends CommonResponseMessage{
	private int rewardType;
	private List<DailyMissionRewardItem> rewardItem;
	private int clentData;
	private int dailyActive;//日活跃度
	private int weekActive;//周活跃度
	private List<Integer> openBoxIds;

	public List<DailyMissionRewardItem> getRewardItem() {
		return rewardItem;
	}

	public void setRewardItem(List<DailyMissionRewardItem> rewardItem) {
		this.rewardItem = rewardItem;
	}

	public int getRewardType() {
		return rewardType;
	}

	public void setRewardType(int rewardType) {
		this.rewardType = rewardType;
	}

	public int getClentData() {
		return clentData;
	}

	public void setClentData(int clentData) {
		this.clentData = clentData;
	}

	public int getDailyActive() {
		return dailyActive;
	}

	public void setDailyActive(int dailyActive) {
		this.dailyActive = dailyActive;
	}

	public int getWeekActive() {
		return weekActive;
	}

	public void setWeekActive(int weekActive) {
		this.weekActive = weekActive;
	}

	public List<Integer> getOpenBoxIds() {
		return openBoxIds;
	}

	public void setOpenBoxIds(List<Integer> openBoxIds) {
		this.openBoxIds = openBoxIds;
	}
}
