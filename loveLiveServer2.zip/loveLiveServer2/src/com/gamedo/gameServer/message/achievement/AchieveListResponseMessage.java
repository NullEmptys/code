package com.gamedo.gameServer.message.achievement;

import java.util.ArrayList;
import java.util.List;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 成就列表
 * 服务器返回客户端消息内容
 * @author libm
 *
 */
public class AchieveListResponseMessage extends CommonResponseMessage {

	private List<AchieveInfo> achieves = new ArrayList<AchieveInfo>();
	
	private AchieveLevelInfo achieveLevelInfo;

	public List<AchieveInfo> getAchieves() {
		return achieves;
	}

	public void setAchieves(List<AchieveInfo> achieves) {
		this.achieves = achieves;
	}

	public AchieveLevelInfo getAchieveLevelInfo() {
		return achieveLevelInfo;
	}

	public void setAchieveLevelInfo(AchieveLevelInfo achieveLevelInfo) {
		this.achieveLevelInfo = achieveLevelInfo;
	}
}
