package com.gamedo.gameServer.message.achievement;

/**
 * 
 * @author libm
 *
 */
public class AchieveLevelInfo {

	/**
	 * 玩家当前完成成就点
	 */
	private int achieveValue;
	/**
	 * 下级所需成就点
	 */
	private int nextLevelAchieveValue;
	/**
	 * 下一个成就等级
	 */
	private int rewardLevel;
	/**
	 * 下一个成就等级奖励道具id
	 */
	private int rewardItemId;
	/**
	 * 下一个成就等级奖励道具数量
	 */
	private int rewardItemCounts;

	public int getAchieveValue() {
		return achieveValue;
	}

	public void setAchieveValue(int achieveValue) {
		this.achieveValue = achieveValue;
	}

	public int getNextLevelAchieveValue() {
		return nextLevelAchieveValue;
	}

	public void setNextLevelAchieveValue(int nextLevelAchieveValue) {
		this.nextLevelAchieveValue = nextLevelAchieveValue;
	}

	public int getRewardLevel() {
		return rewardLevel;
	}

	public void setRewardLevel(int rewardLevel) {
		this.rewardLevel = rewardLevel;
	}

	public int getRewardItemId() {
		return rewardItemId;
	}

	public void setRewardItemId(int rewardItemId) {
		this.rewardItemId = rewardItemId;
	}

	public int getRewardItemCounts() {
		return rewardItemCounts;
	}

	public void setRewardItemCounts(int rewardItemCounts) {
		this.rewardItemCounts = rewardItemCounts;
	}
	
	
}
