package com.gamedo.gameServer.message.achievement;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 领取成就奖励
 * 服务器返回客户端消息内容
 * @author libm
 *
 */
public class GetAchieveRewardResponseMessage extends CommonResponseMessage {

	private AchieveLevelInfo achieveLevelInfo;
	
	/**成就奖励*/
	private int currencyType;
	/**货币数*/
	private int currencyCounts;
	
	/**成就的等级奖励物品id*/
	private int rewardItemId;
	
	private int rewardCounts;
	
	public AchieveLevelInfo getAchieveLevelInfo() {
		return achieveLevelInfo;
	}

	public void setAchieveLevelInfo(AchieveLevelInfo achieveLevelInfo) {
		this.achieveLevelInfo = achieveLevelInfo;
	}

	public int getRewardItemId() {
		return rewardItemId;
	}

	public void setRewardItemId(int rewardItemId) {
		this.rewardItemId = rewardItemId;
	}

	public int getRewardCounts() {
		return rewardCounts;
	}

	public void setRewardCounts(int rewardCounts) {
		this.rewardCounts = rewardCounts;
	}

	public int getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	public int getCurrencyCounts() {
		return currencyCounts;
	}

	public void setCurrencyCounts(int currencyCounts) {
		this.currencyCounts = currencyCounts;
	}
	
}
