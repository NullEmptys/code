package com.gamedo.gameServer.message.achievement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonRequestMessage;

/**
 * 成就列表
 * 客户端请求服务器消息内容
 * @author libm
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AchieveListRequestMessage extends CommonRequestMessage {

	private int category;

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}
	
}
