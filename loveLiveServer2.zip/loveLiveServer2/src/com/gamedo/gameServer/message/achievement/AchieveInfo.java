package com.gamedo.gameServer.message.achievement;

/**
 * 
 * @author libm
 *
 */
public class AchieveInfo {

	/**
	 * 成就id
	 */
	private int achieveId;
	/**
	 * 是否达成
	 * 1、已达成
	 * 0、未达成
	 */
	private int finished;
	/**
	 * 是否领取完成就奖励
	 * 1、已领取
	 * 0、未领取
	 */
	private int rewarded;
	/**
	 * 成就已达成条件值
	 */
	private int value;
	public int getAchieveId() {
		return achieveId;
	}
	public void setAchieveId(int achieveId) {
		this.achieveId = achieveId;
	}
	public int getFinished() {
		return finished;
	}
	public void setFinished(int finished) {
		this.finished = finished;
	}
	public int getRewarded() {
		return rewarded;
	}
	public void setRewarded(int rewarded) {
		this.rewarded = rewarded;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	
	
}
