package com.gamedo.gameServer.message.activity.loginReward;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 7日登录活动 签到
 * 服务器返回客户端消息内容
 * @author libm
 *
 */
public class LoginRewardSignResponseMessage extends CommonResponseMessage{

	/**
	 * 已签到次数
	 */
	private int signCounts;
	
	private SignRewardData rewardData;
	
	private LoginRewardAreaData areaData;

	public int getSignCounts() {
		return signCounts;
	}

	public void setSignCounts(int signCounts) {
		this.signCounts = signCounts;
	}

	public SignRewardData getRewardData() {
		return rewardData;
	}

	public void setRewardData(SignRewardData rewardData) {
		this.rewardData = rewardData;
	}

	public LoginRewardAreaData getAreaData() {
		return areaData;
	}

	public void setAreaData(LoginRewardAreaData areaData) {
		this.areaData = areaData;
	}
	
}
