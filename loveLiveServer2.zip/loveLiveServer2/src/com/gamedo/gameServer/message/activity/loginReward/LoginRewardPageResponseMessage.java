package com.gamedo.gameServer.message.activity.loginReward;

import java.util.List;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 7天登录奖励界面内容
 * @author libm
 *
 */
public class LoginRewardPageResponseMessage extends CommonResponseMessage {

	/**累计签到天数*/
	private int signCounts;
	/**活动标题*/
	private String activityTitle;
	
	private List<SignRewardData> signRewards;
	
	public int getSignCounts() {
		return signCounts;
	}

	public void setSignCounts(int signCounts) {
		this.signCounts = signCounts;
	}

	public String getActivityTitle() {
		return activityTitle;
	}

	public void setActivityTitle(String activityTitle) {
		this.activityTitle = activityTitle;
	}

	public List<SignRewardData> getSignRewards() {
		return signRewards;
	}

	public void setSignRewards(List<SignRewardData> signRewards) {
		this.signRewards = signRewards;
	}

}
