package com.gamedo.gameServer.message.activity.loginReward;

public class LoginRewardAreaData {

	/**照片区域id*/
	private int areaId;
	/**状态  1-已解锁  0-未解锁*/
	private int state;
	
	public int getAreaId() {
		return areaId;
	}
	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	
}
