package com.gamedo.gameServer.message.activity.loginReward;

import java.util.List;

public class SevenLoginRewardData {

	private int activityId;
	/**累计签到天数*/
	private int signCounts;
	/**活动标题*/
	private String activityTitle;
	
	private List<SignRewardData> signRewards;

	public int getSignCounts() {
		return signCounts;
	}

	public void setSignCounts(int signCounts) {
		this.signCounts = signCounts;
	}

	public String getActivityTitle() {
		return activityTitle;
	}

	public void setActivityTitle(String activityTitle) {
		this.activityTitle = activityTitle;
	}

	public List<SignRewardData> getSignRewards() {
		return signRewards;
	}

	public void setSignRewards(List<SignRewardData> signRewards) {
		this.signRewards = signRewards;
	}

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}
	
}
