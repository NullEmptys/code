package com.gamedo.gameServer.message.activity.loginReward;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonRequestMessage;

/**
 * 签到界面
 * 客户端请求服务器消息
 * @author libm
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LoginRewardPageRequestMessage extends CommonRequestMessage {

	/**
	 * 活动id
	 */
	private int activityId;

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}
	
}
