package com.gamedo.gameServer.message.monthsign;

import com.gamedo.gameServer.message.CommonResponseMessage;
/**
 * 领取月签奖励
 * @author IPOC-HUANGPING
 *
 */
public class MonthSignRewardResponseMessage extends CommonResponseMessage{
	private int itmeId;
	private int itemNum;
	
	public int getItmeId() {
		return itmeId;
	}
	public void setItmeId(int itmeId) {
		this.itmeId = itmeId;
	}
	public int getItemNum() {
		return itemNum;
	}
	public void setItemNum(int itemNum) {
		this.itemNum = itemNum;
	}
	
	
}
