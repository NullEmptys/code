package com.gamedo.gameServer.message.monthsign;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.gamedo.gameServer.message.CommonRequestMessage;
/**
 * 领取月签奖励客户端数据
 * @author IPOC-HUANGPING
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetMonthSignRewardRequestMessage extends CommonRequestMessage{
	private int day;
	private int month;
	
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	
	
}
