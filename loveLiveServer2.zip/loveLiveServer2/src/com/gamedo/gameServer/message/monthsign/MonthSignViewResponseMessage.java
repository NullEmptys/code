package com.gamedo.gameServer.message.monthsign;

import java.util.List;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 签到界面返回数据
 * @author IPOC-HUANGPING
 *
 */
public class MonthSignViewResponseMessage extends CommonResponseMessage{
	private int months;//当前时间的月份
	private List<Integer> getDayList;//领取天数记录
	private int gainDay;//累计天数
	
	public int getMonths() {
		return months;
	}
	public void setMonths(int months) {
		this.months = months;
	}
	public List<Integer> getGetDayList() {
		return getDayList;
	}
	public void setGetDayList(List<Integer> getDayList) {
		this.getDayList = getDayList;
	}
	public int getGainDay() {
		return gainDay;
	}
	public void setGainDay(int gainDay) {
		this.gainDay = gainDay;
	}
	
}
