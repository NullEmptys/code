package com.gamedo.gameServer.message;

import com.gamedo.toolkit.i18n.I18NUtil;

/**
 * 国际化消息文本
 * @author libm
 *
 */
public class I18NMessage {

	static{
		I18NUtil.initClass(I18NMessage.class);
	}
	
	public static String NOT_FOUND_PLAYER;//未找到指定玩家
	public static String DATA_EXCEPTION;//数据异常
	public static String LOGIN_PLAYER_DESC;//请输入正确的账号名
	public static String BUY_TILI_DESC;//今日体力购买次数已用尽
	public static String NO_ENOUGH_MONEY;//当前钻石数量不足
	public static String MAX_LIMIT;//超过最大长度限制
	public static String MIN_LIMIT;//没到最小长度限制
	public static String ILLEGAL_CHAR;//出现非法字符
	public static String ILLEGAL_WORD;//包含敏感词
	public static String ERROR_PATTERN;//模式不匹配
	public static String CREATE_PLAYER_SUCCESS;//创建角色成功
	public static String PLAYER_NAME_IS_NULL;//请输入角色名称
	public static String PLAYER_NAME_REPEAT;//该角色名已经存在，请重新选择
	public static String ALREADY_CREATED;//该账号已经创建过角色
	public static String NOT_FOUND_ITEM;//物品不存在
	public static String SELL_ITEM_NOT_FOUND;//未找到指定物品或者物品数量错误
	public static String ITEM_NOT_SELL;//此物品无法丢弃，请妥善保管。
	public static String GIRL_NOT_FOUND;//未找到指定模特
	public static String NOT_CHOOSE_ITEM;//请选择需要购买的商品
	public static String BAG_FULL;//背包满
	public static String NOT_ENOUGH_TILI;//体力不足
	public static String QUEST_NOT_UNLOCK;//该任务尚未解锁
	public static String QUEST_REFRESH_COUNT_NOT_EHOUGH;//今日刷新次数不足
	public static String QUEST_NOT_ALLOWED_TO_REFRESH;//当前无可刷新任务
	public static String QUEST_CAN_NOT_LOCK;//当前只可锁定一个任务
	public static String NOT_FOUND_QUEST;//任务不存在
	public static String QUEST_IS_NOT_LOCKED;//当前任务无须解锁
	public static String QUEST_IS_FINISHED;//该任务已经完成
	public static String QUEST_FAILED;//任务失败
	public static String GIRL_SIGNED_FAILED;//模特签约失败
	public static String GIRL_MAX_LEVEL;//模特已经满级升级失败
	public static String NO_ENOUGH_CURRENCY;//货币不足
	public static String GIRL_NOT_SIGN;//该模特暂未签约
	public static String SCENE_NOT_FOUND;//场景不存在
	public static String GIRL_IS_PERMANET;//模特无须签约
	public static String RESET_GIRL_MOOD_MAXCOUNT;//重置次数不足
	public static String NOT_FOUND_RANK_TYPE;//榜单不存在
	public static String TOTAL_RANK_DESC;//本周{0}月{1}日-{2}月{3}日模特人气
	public static String NOT_FOUND_MAIL;//邮件不存在
	public static String MAIL_ATTACH_RECEIVED;//该邮件已领取
	public static String MAIL_NOT_HAVE_ATTACH;//没有邮件附件
	public static String ACHIEVE_NOT_FINISHED;//成就暂未达成
	public static String ACHIEVE_REWARDED;//不能重复领取
	public static String NOT_FOUNT_MONTSIGN_DATA;//没有找到月签数据
	public static String NEED_RESET_DATA;//需要重置数据
	public static String IS_GET_DAY_REWARD;//领取过该天的奖励
	public static String NOT_REACH_DAY;//没有达到累计天数
	public static String REWARD_TYPE_NOT_FOUNT;//不存在该奖励类型
	public static String REWARD_DATA_NOT_FOUNT;//该宝箱不存在
	public static String GET_REWARD;//领取过该宝箱的奖励
	public static String ACTIVE_NOT_HAVE;//活跃度不足
	public static String DAILY_MISSION_NOT_FOUND;//指定任务不存在
	public static String DAILY_MISSION_NOT_GET;//还没有达成该任务
	public static String DAILY_MISSION_GETED;//领取过该任务奖励
	public static String FINISH_REWARD;//领取成功
	public static String NEXT_DAY_AGAIN;//今日次数已达上限,请改天再来
	public static String NEXT_DAY_COMMIT;//今日没有次数了,明日再来提交哦
	public static String COMMIT_SUCCESS;//提交成功
	public static String PLAYER_FORBIT_LOGIN;//角色尚未解封
	public static String SHE_JIAO_QUEST_REWARD_TITLE;
	public static String SHE_JIAO_QUEST_REWARD_CONTENT;
	public static String ACTIVITY_NOT_ACTIVE;//活动暂未开始
	public static String LOGINREWARD_SIGNED;//今日已签到！
	public static String LOGINREWARD_DESC_1;//已签到完毕
	public static String LOGINREWARD_DESC_2;//再登入{0}天就能领取该奖励哦~
	public static String LOGINREWARD_DESC_3;//亲，该奖励已经领取了哦~
	public static String ENGAGEMENT_DESC_1;//当前已是最高回合
	public static String ENGAGEMENT_DESC_2;//请下一时段再选择约会对象！
	public static String ENGAGEMENT_DESC_3;//请先猜拳
	public static String ENGAGEMENT_DESC_4;//当前已是最高回合
	public static String NOT_FOUND_ENGAGEMENT_SHOP_ITEM;//请选择正确的商品~
	public static String CHOOSE_GIRL;//请选择一个约会对象~
	public static String CHOOSE_MAIL;//请选择一封邮件~
	public static String QUEST_ACCEPTED;//无须重复该任务~
	public static String GIRL_SIGN_OUT_OF_TIME;//该模特签约已过期
	public static String GIRL_UNLOCK_FAIL;//请完成解锁条件再来购买
	public static String GIRL_UNLOCK_OVER;//该模特已解锁完成
	public static String GIRL_NOT_UNLOCK;//该模特尚未解锁
	public static String GIRL_LEVEL_NOT_ENOUGH;//模特等级不能超过玩家等级
	public static String CURRENT_PERIOD_MAX_COUNTS;//当前时间段已达最大可购买个数
	public static String TI_LI_LIMIT;//体力已达上限
}
