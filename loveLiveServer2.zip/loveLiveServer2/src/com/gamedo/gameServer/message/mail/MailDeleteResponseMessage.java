package com.gamedo.gameServer.message.mail;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 删除邮件
 * 服务器返回客户端消息内容
 * @author libm
 *
 */
public class MailDeleteResponseMessage extends CommonResponseMessage{

}
