package com.gamedo.gameServer.message.mail;

/**
 * 邮件信息
 * @author libm
 *
 */
public class MailInfo {

	private int mailId;
	/*发送者id  系统：-1*/
	private int sourceId;
	/*发送邮件人*/
	private String sendName;
	/*邮件标题*/
	private String title;
	/*发送时间*/
	private long postTime;
	/*邮件状态*/
	private int status;
	/*邮件是否包含附件  1-是   0-否*/
	private int haveAttach;
	/*是否领取邮件附件  1-已领取  0-未领取*/
	private int receivedAttach;
	
	public int getMailId() {
		return mailId;
	}
	public void setMailId(int mailId) {
		this.mailId = mailId;
	}
	public int getSourceId() {
		return sourceId;
	}
	public void setSourceId(int sourceId) {
		this.sourceId = sourceId;
	}
	public String getSendName() {
		return sendName;
	}
	public void setSendName(String sendName) {
		this.sendName = sendName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public long getPostTime() {
		return postTime;
	}
	public void setPostTime(long postTime) {
		this.postTime = postTime;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getHaveAttach() {
		return haveAttach;
	}
	public void setHaveAttach(int haveAttach) {
		this.haveAttach = haveAttach;
	}
	public int getReceivedAttach() {
		return receivedAttach;
	}
	public void setReceivedAttach(int receivedAttach) {
		this.receivedAttach = receivedAttach;
	}
	
}
