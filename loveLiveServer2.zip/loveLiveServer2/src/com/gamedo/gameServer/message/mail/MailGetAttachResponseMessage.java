package com.gamedo.gameServer.message.mail;

import java.util.List;

import com.gamedo.gameServer.message.CommonResponseMessage;

public class MailGetAttachResponseMessage extends CommonResponseMessage {
	private List<MailAttachementItem> mailAattachementItem;

	public List<MailAttachementItem> getMailAattachementItem() {
		return mailAattachementItem;
	}

	public void setMailAattachementItem(List<MailAttachementItem> mailAattachementItem) {
		this.mailAattachementItem = mailAattachementItem;
	}
	
	
}
