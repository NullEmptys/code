package com.gamedo.gameServer.message.mail;

import java.util.ArrayList;
import java.util.List;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 阅读邮件 服务器返回客户端消息内容
 * 
 * @author libm
 *
 */
public class MailGetContentResponseMessage extends CommonResponseMessage {

	private int mailId;

	private String content;

	private List<AttachmentInfo> attachs = new ArrayList<>();

	public int getMailId() {
		return mailId;
	}

	public void setMailId(int mailId) {
		this.mailId = mailId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public List<AttachmentInfo> getAttachs() {
		return attachs;
	}

	public void setAttachs(List<AttachmentInfo> attachs) {
		this.attachs = attachs;
	}

}
