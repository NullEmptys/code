package com.gamedo.gameServer.message.mail;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 清理邮箱
 * 服务器返回客户端消息内容
 * @author libm
 *
 */
public class MailClearResponseMessage extends CommonResponseMessage{

	
}
