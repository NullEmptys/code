package com.gamedo.gameServer.message.mail;

/**
 * 
 * @author libm
 *
 */
public class AttachmentInfo {
	
	/**
	 * 
	 */
	private int attachType;
	
	private int rewardId;
	
	private int rewardCounts;

	public int getAttachType() {
		return attachType;
	}

	public void setAttachType(int attachType) {
		this.attachType = attachType;
	}

	public int getRewardId() {
		return rewardId;
	}

	public void setRewardId(int rewardId) {
		this.rewardId = rewardId;
	}

	public int getRewardCounts() {
		return rewardCounts;
	}

	public void setRewardCounts(int rewardCounts) {
		this.rewardCounts = rewardCounts;
	}
	
}
