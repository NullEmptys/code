package com.gamedo.gameServer.message.mail;

import java.util.ArrayList;
import java.util.List;

import com.gamedo.gameServer.message.CommonResponseMessage;

/**
 * 邮件列表
 * 服务器返回客户端消息内容
 * @author libm
 *
 */
public class MailListResponseMessage extends CommonResponseMessage{

	private List<MailInfo> mails = new ArrayList<>();

	public List<MailInfo> getMails() {
		return mails;
	}

	public void setMails(List<MailInfo> mails) {
		this.mails = mails;
	}
	
}
