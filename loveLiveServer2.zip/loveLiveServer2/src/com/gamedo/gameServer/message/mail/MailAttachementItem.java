package com.gamedo.gameServer.message.mail;

public class MailAttachementItem {
	private int rewardType;//奖励类型
	private int itemId;//物品id
	private int itemNum;//物品数量
	
	
	public MailAttachementItem(int rewardTyep,int itemId,int ItemNum){
		this.rewardType = rewardTyep;
		this.itemId = itemId;
		this.itemNum = ItemNum;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getItemNum() {
		return itemNum;
	}
	public void setItemNum(int itemNum) {
		this.itemNum = itemNum;
	}
	public int getRewardType() {
		return rewardType;
	}
	public void setRewardType(int rewardType) {
		this.rewardType = rewardType;
	}
}
