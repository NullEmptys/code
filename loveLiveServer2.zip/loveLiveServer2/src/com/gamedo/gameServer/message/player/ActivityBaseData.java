package com.gamedo.gameServer.message.player;

/**
 * 
 * @author libm
 *
 */
public class ActivityBaseData {

	private int activityId;

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}
	
}
