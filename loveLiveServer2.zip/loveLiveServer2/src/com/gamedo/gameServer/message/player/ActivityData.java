package com.gamedo.gameServer.message.player;

import java.util.List;

/**
 * 活动分类列表
 * @author libm
 *
 */
public class ActivityData {

	/**活动分类
	 * 0、日常活动
	 * 1、定时活动
	 */
	private int category;
	
	/**
	 * 正在运行的活动id
	 */
	private List<Integer> activityIds;

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public List<Integer> getActivityIds() {
		return activityIds;
	}

	public void setActivityIds(List<Integer> activityIds) {
		this.activityIds = activityIds;
	}

}
