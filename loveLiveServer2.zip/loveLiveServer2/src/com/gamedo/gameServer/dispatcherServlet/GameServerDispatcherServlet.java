package com.gamedo.gameServer.dispatcherServlet;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.DispatcherServlet;

import com.gamedo.gameServer.core.impl.SimpleUpdater;
import com.gamedo.gameServer.data.ServerInfoConfig;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.message.CommonResponseMessage;
import com.gamedo.gameServer.service.serverinfo.ServerInfoConfigService;

public class GameServerDispatcherServlet extends DispatcherServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String encoding;

	public void init(ServletConfig config) throws ServletException {
		encoding = config.getInitParameter("encoding");
		super.init(config);
	}

	protected void doService(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String remoteIp = getIpAddr(request);
		Packet packet = new Packet(null, request, response);
		CommonResponseMessage message = new CommonResponseMessage();
		int serverId = SimpleUpdater.getInstance().getServerId();
		ServerInfoConfig serverInfo = ServerInfoConfigService.getInstance().getServerInfoConfig(serverId);
		if(!serverInfo.isSafetyIp(remoteIp)) {
			if (!serverInfo.isOpenNow()) { // 不在开放时间
				Date openTime = serverInfo.getFutureOpenTime();
				if (openTime != null) {
					SimpleDateFormat formatter = new SimpleDateFormat(
							ServerInfoConfig.TIME_STYLE);
					message.setDesc(ServerInfoConfig.WILL_OPEN
							+ formatter.format(openTime));
				} else {
					message.setDesc(ServerInfoConfig.MAINTANCE);
				}
				message.setCode(CommonResponseMessage.SERVER_NOT_OPEN);
				packet.send(message);
				return;
			}
		}
		request.setCharacterEncoding(encoding);
		super.doService(request, response);
	}

	public String getIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("X-Real-IP");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("x-forwarded-for");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}

		if (ip != null) {
			ip = getFirstIp(ip);
		}
		return ip;
	}

	public String getFirstIp(String ipString) {
		String ip = null;
		String[] ipList = ipString.split(",");
		if (ipList != null && ipList.length > 1) {
			ip = ipList[0];
		} else {
			ip = ipString;
		}
		return ip;
	}
}
