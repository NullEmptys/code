package com.gamedo.gameServer.activity;

import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gamedo.gameServer.core.Updatable;

/**
 * 定义一个推广活动。一个活动是一个临时性的服务，在一定时间范围内有效。
 * @author libm
 *
 */
public class Activity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3545148835673765021L;

	public static Logger log = LoggerFactory.getLogger(Activity.class);
	
	protected int id;
	/**活动标题*/
	protected String title;
	/**活动描述*/
	protected String description;
	/**实现类名称*/
	protected String implClass;
	/**广播开始时间*/
	protected Date broadcastStartTime;
	/**广播结束时间*/
	protected Date broadcastEndTime;
	/**活动开始时间*/
	protected Date startTime;
	/**活动结束时间*/
	protected Date endTime;
	/**活动分类 0-日常  1-定时任务*/
	protected int category;
	/**活动类型*/
	protected int type;
	/**是否已启动标志*/
	protected boolean active;
	/**是否有效*/
	protected boolean enabled;
	/**实现类*/
	@JsonIgnore
	protected IActivityImpl impl;
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getImplClass() {
		return implClass;
	}
	
	public void setImplClass(String implClass) {
		this.implClass = implClass;
	}
	
	public void setActive(boolean active) {
		this.active = active;
	}
	
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	public IActivityImpl getImpl() {
		if (impl == null) {
			try {
				Class cls = Class.forName(implClass);
				Constructor c = cls.getConstructor(Activity.class);
				impl = (IActivityImpl)c.newInstance(this);
			} catch (Exception e) {
				log.error(e.toString(), e);
			}
		}
		return impl;
	}
	
	public void setImpl(IActivityImpl impl) {
		this.impl = impl;
	}
	
	/**
	 * 判断当前活动是否正在进行。
	 */
	public boolean isActive() {
		return active;
	}
	
	/**
	 * 启动服务。
	 * @throws Exception
	 */
	public void startup() throws Exception {
		active = true;
		getImpl().startup();
		log.info("启动活动---------activityId=" + id);
	}
	
	/**
	 * 关闭服务。
	 */
	public void shutdown() {
		active = false;
		try {
			getImpl().shutdown();
			log.info("关闭活动---------activityId=" + id);
		} catch (Exception e) {
			log.error(e.toString(),e);
		}
	}
	
	/**
	 * 把当前活动状态保存起来。用于服务器shutdown的时候保存状态。
	 */
	public void save() {
		getImpl().save();
	}
	
	/**
	 * 载入先前保存的状态。用于服务器startup的时候载入上次状态。
	 */
	public void load() {
		getImpl().load();
	}
	
	/**
	 * 清除所有和此活动有关的存储数据。
	 */
	public void clear() {
		getImpl().clear();
	}
	
	/**
	 * 每cycle更新。
	 * @param diff
	 * @return
	 */
	public boolean update() {
		if (getImpl() instanceof Updatable) {
			return ((Updatable)getImpl()).update();
		} else {
			return false;
		}
	}
	
	/**
	 * 判断当前时间是否在活动有效时间段内。
	 */
	public boolean in() {
		long now = System.currentTimeMillis();
		if (now < startTime.getTime() || now >= endTime.getTime()) {
			return false;
		}
		return true;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public Date getBroadcastStartTime() {
		return broadcastStartTime;
	}

	public void setBroadcastStartTime(Date broadcastStartTime) {
		this.broadcastStartTime = broadcastStartTime;
	}

	public Date getBroadcastEndTime() {
		return broadcastEndTime;
	}

	public void setBroadcastEndTime(Date broadcastEndTime) {
		this.broadcastEndTime = broadcastEndTime;
	}
	
}
