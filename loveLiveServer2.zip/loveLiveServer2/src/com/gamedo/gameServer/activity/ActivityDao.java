package com.gamedo.gameServer.activity;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class ActivityDao extends DataGenericHibernateDAO<Activity, Integer> {

	@SuppressWarnings("unchecked")
	public List<Activity> loadActivities() {
		String hql = "from Activity t where t.broadcastStartTime < ?0 and t.broadcastEndTime > ?1";
		return list(hql, new Date(),new Date());
	}

	public Activity loadActivityById(int activityId) {
		String hql = "from Activity t where t.id = ?0";
		return (Activity) uniqueResult(hql, activityId);
	}
}
