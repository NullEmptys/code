package com.gamedo.gameServer.core;

import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.player.Player;

/**
 * 
 * @author libm
 *
 */
public class UseItemContext {

	public Player player;
	public GameItem item;
	public PlayerTransaction tx;
	public int bagId,gridId;
	
	/**
	 * @param player
	 * @param item
	 * @param tx
	 * @param bagId
	 * @param gridId
	 */
	public UseItemContext(Player player,GameItem item,PlayerTransaction tx,int bagId,int gridId){
		this.player = player;
		this.item = item;
		this.tx = tx;
		this.bagId = bagId;
		this.gridId = gridId;
	}
	
}
