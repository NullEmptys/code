package com.gamedo.gameServer.core;

import com.gamedo.gameServer.exception.ItemUseException;

/**
 * 物品使用效果
 * @author libm
 *
 */
public interface ItemEffect {

	/**
	 * 使用物品
	 */
	public void use(UseItemContext context) throws ItemUseException;
	/**
	 * 是否需要异步执行，比如使用数据库或者需要想认证服务器请求
	 * @return
	 */
	public boolean isAsync();
}
