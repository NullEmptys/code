package com.gamedo.gameServer.core.event;

/**
 * 
 * @author libm
 *
 */
public interface ServiceEventListener {

	public int[] getEventTypes();

	public void handleEvent(ServiceEvent event);
}
