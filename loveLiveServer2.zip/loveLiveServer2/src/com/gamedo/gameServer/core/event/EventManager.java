package com.gamedo.gameServer.core.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gamedo.gameServer.core.Updatable;
import com.gamedo.gameServer.core.impl.SimpleUpdater;
import com.gamedo.gameServer.service.AbstractService;

/**
 * 事件管理
 * @author libm
 *
 */
@Component
public class EventManager extends AbstractService implements Updatable,EventManagerMBean{

	@Autowired
	private SimpleUpdater simpleUpdater;
	
	private static EventManager instance;
	
	protected Map<Integer, List<ServiceEventListener>> listeners = new HashMap<Integer, List<ServiceEventListener>>();
	protected Queue<ServiceEvent> events = new ConcurrentLinkedQueue<ServiceEvent>();
	protected static final Logger log = LoggerFactory.getLogger(EventManager.class);
	
	private EventManager() {
		instance = this;
	}
	
	public void registerListener(ServiceEventListener listener) {
		int[] types = listener.getEventTypes();
		for (int type : types) {
			List<ServiceEventListener> lls = listeners.get(type);
			if (lls == null) {
				lls = new ArrayList<ServiceEventListener>();
				listeners.put(type, lls);
			}
			lls.add(listener);
		}
	}
	
	public void unregisterListener(ServiceEventListener listener) {
		for (List<ServiceEventListener> lls : listeners.values()) {
			lls.remove(listener);
		}
	}
	
	public void addEvent(ServiceEvent event) {
		events.add(event);
	}
	
	public boolean update() {
		while (!events.isEmpty()) {
			ServiceEvent evt = events.remove();
			List<ServiceEventListener> lls = listeners.get(evt.type);
			if (lls != null) {
				for (ServiceEventListener l : lls) {
					try {
						
//						long t1 = System.nanoTime();
						
						l.handleEvent(evt);
						
//						long t2 = System.nanoTime();
//						long el3 = (t2 - t1) / 1000000;
						
//						if( el3 > 50){
//							log.info("Event too long["+el3+"]type" + evt.type + "]class[" + l.getClass() + "]");
//						}
						
					} catch (Exception e) {
						//log.error(e, e);
					}
				}
			}
		}
		return false;
	}
	
	public void fireEvent(ServiceEvent event) {
		List<ServiceEventListener> lls = listeners.get(event.type);
		if (lls != null) {
			for (ServiceEventListener l : lls) {
				try {
					l.handleEvent(event);
				} catch (Exception e) {
					//log.error(e, e);
				}
			}
		}
	}

	@Override
	public String getId() {
		return EventManager.class.getName();
	}

	@PostConstruct
	public void startup() throws Exception {
		simpleUpdater.addSyncUpdatable(this);
		super.startup("掌上纵横-IPOC-LOVELIVE:type=服务,name=事件管理");
	}
	
	public static EventManager getInstance() {
		return instance;
	}
}
