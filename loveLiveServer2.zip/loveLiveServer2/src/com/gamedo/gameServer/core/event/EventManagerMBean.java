package com.gamedo.gameServer.core.event;

public interface EventManagerMBean {

}
