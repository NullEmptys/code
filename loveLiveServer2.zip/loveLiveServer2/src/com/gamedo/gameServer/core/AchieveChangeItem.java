package com.gamedo.gameServer.core;

import java.io.Serializable;

import com.gamedo.gameServer.entity.achievement.PlayerAchievement;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.AchieveUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

public class AchieveChangeItem extends ChangedItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5778196651565361283L;

	protected int category;
	
	protected int achieveId;
	
	protected boolean finished;
	
	protected boolean rewarded;
	
	protected int value;
	
	public AchieveChangeItem(PlayerAchievement playerAchieve,int category) {
		this.type = TYPE_ACHIEVE;
		this.category = category;
		this.achieveId = playerAchieve.id;
		this.finished = playerAchieve.finished;
		this.rewarded = playerAchieve.rewarded;
		this.value = playerAchieve.value;
	}
	
	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		
	}

	@Override
	public UpdateObject pack() {
		AchieveUpdateObject updateObject = new AchieveUpdateObject();
		updateObject.setType(this.type);
		updateObject.setAchieveId(achieveId);
		updateObject.setCategory(category);
		updateObject.setFinished(finished == true ? 1 : 0);
		updateObject.setValue(value);
		updateObject.setRewarded(rewarded == true ? 1 : 0);
		return updateObject;
	}

}
