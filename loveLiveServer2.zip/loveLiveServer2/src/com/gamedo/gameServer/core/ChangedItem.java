package com.gamedo.gameServer.core;

import java.io.Serializable;

import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.UpdateObject;

/**
 * 
 * @author libm
 *
 */
public abstract class ChangedItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9129963596383253998L;

	public static final int TYPE_MAX = 255;

	//整形类型
	public static final int TYPE_INT = 0;
	//背包数据
	public static final int TYPE_BAG = 1;
	//任务数据
	public static final int TYPE_QUEST = 2;
	//模特背包
	public static final int TYPE_PLAYERGIRL_BAG = 3;
	//任务章节数据
	public static final int TYPE_PLAYERQUEST_CHAPTER = 4;
	//模特基础数据
	public static final int TYPE_PLAYERGIRL_BASE_DATA = 5;
	//成就数据
	public static final int TYPE_ACHIEVE = 6;
	//约会数据
	public static final int TYPE_ENGAGEMENT= 7;
	//活跃度数据
	public static final int TUPE_DAILY_MISSION = 8;
	//邮件数据
	public static final int TYPE_MAIL = 9;
	//角色退出
	public static final int LOGIN_OUT = 10;
	
	public static final int MONEY = 1;//钻石
	public static final int EXP = 2;
	public static final int LEVELUPEXP = 3; //升下级需要经验
	public static final int GAINEXP =  4; //获得的经验
	public static final int GOLD = 5; //金币
	public static final int LEVEL = 6;//角色等级
	public static final int TILI = 7;//体力
	public static final int PLAYER_GIRL_BAG_CDTIME = 8;//模特背包物品时效变化
	public static final int BAG_ITEMCOUNT = 9;//背包物品数量改变
	public static final int TILI_TIME = 10;//体力恢复倒计时  单位：毫秒
	public static final int DAILY_ACTIVE=11;//日活跃度
	public static final int WEEK_ACTIVE=12;//周活跃度
	
	// 字符串类型
	public static final int TYPE_STRING = 1;
	// 复杂类型
	public static final int TYPE_COMPLEX = 2;

	public static final int BAGGRID = 1;  //改变
	public static final int GRIDCOUNT = 2;//包格数量改变
	public static final int GRIDFULL = 3; //包格满
	public static final int ITEM_COUNT_CHANGED = 4;//物品数量改变
	
	public static final int MAIL_ADD = 0;
	public static final int MAIL_DELETE = 1;
	
	public static final int QUEST_UPDATE = 0;
	public static final int QUEST_ADD = 1;

	protected int type;
	protected int id;
	// 客户端是否需要提醒用户
	public boolean notify;
	
	public ChangedItem() {
		
	}

	protected ChangedItem(int type, int id, boolean notify) {
		this.type = type;
		this.id = id;
		this.notify = notify;
	}

	public int getId() {
		return id;
	}

	public int getType() {
		return type;
	}

	public boolean isNotif() {
		return notify;
	}
	
	

	public abstract boolean merge(ChangedItem other);

	public abstract void makeBroadcastPacket(Packet pt);
	
	public abstract UpdateObject pack();

}
