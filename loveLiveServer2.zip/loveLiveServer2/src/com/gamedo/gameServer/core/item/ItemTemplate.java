package com.gamedo.gameServer.core.item;

/**
 * 物品模板
 * @author libm
 *
 */
public interface ItemTemplate {

	/**
	 * 装备的特殊类型ID。
	 */
	public static final int TYPE_EQUIP = -1;
	
	/**
	 * 模板ID
	 */
	public int getId();
	/**
	 * 模板名字
	 */
	public String getName();
	/**
	 * 物品大类。
	 */
	public int getCategory();
	/**
	 * 物品组，用于归类物品
	 */
	public int getType();
	/**
	 * 物品堆叠最大数量
	 */
	public int getAddition();
	/**
	 * 物品图标
	 */
	public String getIcon();
	/**
	 * 是否是任务物品
	 */
	public boolean isQuestItem();
	/**
	 * 物品等级
	 */
	public int getLevel();
	/**
	 * 物品使用等级
	 */
	public int getUseLevel();
	/**
	 * 物品品质
	 */
	public int getQuality();
	
	/**
	 * 出售后获得货币类型
	 * @return
	 */
	public int currencyType();
	
	/**
	 * 物品价格，如果<=0，代表不能出售
	 */
	public int getPrice();
	/**
	 * 描述
	 */
	public String getDesc();
	/**
	 * 创建时是否需要生成实例Id
	 */
	public boolean isNewInstance();
	/**
	 * 使用信息
	 */
	public ItemUseType getUseType();
	
	/*
	 * 是否有特殊效果
	 */
	public boolean hasEffect();
	
	/**
	 * 是否可删除
	 * @return
	 */
	public boolean canDelete();
	
	/**
	 * 是否可出售
	 * @return
	 */
	public boolean canSell();
	
	/**
	 * 是否可以叠加
	 * @return
	 */
	public boolean canAddition();
	
}
