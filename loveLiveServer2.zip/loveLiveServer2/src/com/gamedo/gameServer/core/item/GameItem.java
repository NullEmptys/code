package com.gamedo.gameServer.core.item;

/**
 * 
 * @author libm
 *
 */
public interface GameItem {

	/**
	 * 通用的insanceId，用于可堆叠的物品，比如材料等等
	 */
	public static final int GENERAL_INSTANCEID = -1;
	
	public static final long GNERAL_ID =  -1L;
	
	/**
	 * 物品的内部ID，只用于服务器自身使用以及日志记录，56-62位表示服务器代码，48-55位表示类型=1，0-47位用于序列生成号，从1开始
	 * @return
	 */
	public long getId();
	
	/**
	 * 物品临时生成的ID，用于客户端以及服务器端唯一索引一个物品，此ID有一个特殊值GENERAL_INSTANCEID，用于可堆叠物品使用
	 * 物品的instanceId总是需要在物品创建的时候 临时生成，并且在两次载入到内存中时，同一个物品都会有不用的InstanceId。
	 * @return
	 */
	public int getInstanceId();
	
	/**
	 * 物品的名字
	 * @return
	 */
	public String getName();
	
	/**
	 * 物品描述
	 */
	public String getDesc();

	/**
	 * 物品创建时间，只有存在单独InstanceId的物品有这个字段，如果没有InstanceId的物品，返回值是-1
	 */
	public long getCreateTime();
	
	/**
	 * 获取物品的模板，模板保存了物品的共性信息，比如物品的绑定类型，堆叠数量等等
	 */
	public ItemTemplate getTemplate();
	
	/**
	 * 获取物品的品质，虽然物品的Template中也存在品质，但是品质可能会根据物品的增强而改变
	 */
	public int getQuality();
	
	/**
	 * 获取物品的售价，虽然物品的售价在Template中也存在，但是售价可能会根据物品的增强而改变
	 */
	public int getPrice();
	
	public GameItemObject getGameItemObject();
	
	public void setGameItemObject(GameItemObject object);
	
	/**
	 * 获取过期时间，此时间是绝对时间，单位是 秒
	 * @return
	 */
	public long getObsoleteTime();
	
	public void setObsoleteTime(long time);
	
}
