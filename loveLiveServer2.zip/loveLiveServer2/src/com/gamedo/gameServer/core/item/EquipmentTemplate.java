package com.gamedo.gameServer.core.item;

/**
 * 
 * @author libm
 *
 */
public interface EquipmentTemplate extends ItemTemplate{

	public int getMapperEquipId();
}
