package com.gamedo.gameServer.core.item;

import java.io.Serializable;
import com.gamedo.gameServer.entity.player.PlayerGirl;

/**
 * 
 * @author libm
 *
 */
public class EquipmentsEx implements Equipments,Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5900818595038913008L;
	
	public static final int MAX_EQU      = 15;
	
	protected Equipment[] equs;
	protected PlayerGirl owner;
	
	@Override
	public void equ(int index, Equipment equ, Equipment unEqu) {
		if(equ==null)
			throw new IllegalArgumentException();
		equs[index] = equ;
	}

	@Override
	public Equipment unEqu(int index) {
		Equipment equ = equs[index];
		if(equ != null) {
			equs[index] = null;
		}
		return equ;
	}

	public EquipmentsEx(PlayerGirl owner) {
		this.owner = owner;
		this.equs = new Equipment[MAX_EQU];
	}

	@Override
	public Equipment getEquipment(int index) {
		return equs[index];
	}
	
	public EquipmentsEx clone(){
		EquipmentsEx c = new EquipmentsEx(owner);
		c.equs = equs;
		return c;
	}

	@Override
	public int getSize() {
		return equs.length;
	}
	
	public Equipment[] getEquips(){
		return equs;
	}

}
