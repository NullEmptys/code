package com.gamedo.gameServer.core.item;

import java.io.DataInputStream;

import com.gamedo.gameServer.exception.PersistenceException;

/**
 * @author libm
 *
 */
public interface Marshaller {

	public int getId();

	public GameItemObject marshaller(DataInputStream stream, GameItem owner) throws PersistenceException;
}
