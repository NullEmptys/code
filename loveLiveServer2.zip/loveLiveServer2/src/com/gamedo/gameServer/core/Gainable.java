package com.gamedo.gameServer.core;

import com.gamedo.gameServer.core.gain.Gain;

/**
 * @author libm
 *
 */
public interface Gainable {

	public void gain(Gain gain);
}
