package com.gamedo.gameServer.core.fall;

import java.util.Random;

import com.gamedo.gameServer.core.gain.Gain;
import com.gamedo.gameServer.core.gain.GameItemGainEntry;
import com.gamedo.gameServer.core.item.EquipmentTemplate;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.item.ItemTemplate;
import com.gamedo.gameServer.service.data.ItemService;
import com.gamedo.gameServer.util.RandomUtil;

/**
 * 
 * @author libm
 *
 */
public class ItemDrop extends RangeDrop {

	protected ItemTemplate template;
	
	protected int cdTimeType;

	public ItemDrop(ItemTemplate template, int min, int max,int cdTimeType) {
		super(min, max);
		this.template = template;
		this.cdTimeType = cdTimeType;
	}

	public void calc(Random rnd, Gain gain) {
		internalCalc(rnd, gain);
	}

	protected void internalCalc(Random rnd, Gain gain) {
		if (template instanceof EquipmentTemplate) {
			GameItem item = ItemService.getInstance().createGameItem(template);
			processGainItem(rnd, item, gain, 1);
		} else {
			int c = RandomUtil.getCount(rnd, min, max);
			if (c > 0) {
				if (template.isNewInstance()) {
					for (int i = 0; i < c; i++) {
						GameItem item = ItemService.getInstance().createGameItem(template);
						processGainItem(rnd, item, gain, 1);
					}
				} else {
					GameItem item = ItemService.getInstance().createGameItem(template);
					processGainItem(rnd, item, gain, c);
				}
			}
		}
	}

	protected void processGainItem(Random rnd, GameItem item, Gain gain, int count) {
		addGainItem(gain, item, count);
	}

	protected void addGainItem(Gain gain, GameItem item, int count) {
		gain .addGainEntry(new GameItemGainEntry(item, count));
	}

}
