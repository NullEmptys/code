package com.gamedo.gameServer.core.fall;

/**
 * 
 * @author libm
 *
 */
public class DropItem {

	public int id;

	/**
	 * 掉落类型
	 * 
	 * 掉落物品：1     掉落装备：2     掉落一个掉落组：3        掉落金钱：4       掉落经验：5
	 */
	public int dropType;

	/**
	 * 掉落组id
	 */
	public int dropGroupId;
	
	public int subGroupId;

	/** 掉落的物品或者组的ID */
	public int dropID;

	/** 该物品掉落的权重 */
	public int dropWeight;

	/** 该物品掉落的最大数量 */
	public int quantityMax;

	/** 该物品掉落的最小数量 */
	public int quantityMin;
	
	/** 是否展示给玩家*/
	public int isShow;
	
	public int cdTimeType;

	public int getDropID() {
		return dropID;
	}

	public void setDropID(int dropID) {
		this.dropID = dropID;
	}

	public int getDropWeight() {
		return dropWeight;
	}

	public void setDropWeight(int dropWeight) {
		this.dropWeight = dropWeight;
	}

	public int getQuantityMax() {
		return quantityMax;
	}

	public void setQuantityMax(int quantityMax) {
		this.quantityMax = quantityMax;
	}

	public int getQuantityMin() {
		return quantityMin;
	}

	public void setQuantityMin(int quantityMin) {
		this.quantityMin = quantityMin;
	}

	public int getDropType() {
		return dropType;
	}

	public void setDropType(int dropType) {
		this.dropType = dropType;
	}

	public int getDropGroupId() {
		return dropGroupId;
	}

	public void setDropGroupId(int dropGroupId) {
		this.dropGroupId = dropGroupId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIsShow() {
		return isShow;
	}

	public void setIsShow(int isShow) {
		this.isShow = isShow;
	}

	public int getSubGroupId() {
		return subGroupId;
	}

	public void setSubGroupId(int subGroupId) {
		this.subGroupId = subGroupId;
	}

	public int getCdTimeType() {
		return cdTimeType;
	}

	public void setCdTimeType(int cdTimeType) {
		this.cdTimeType = cdTimeType;
	}
	
}
