package com.gamedo.gameServer.core.fall;

import java.util.Random;

import com.gamedo.gameServer.core.gain.Gain;

/**
 * 
 * @author libm
 *
 */
public class WeightGroupDrop implements Drop {
    protected int start;
	protected int weight;
	protected Drop drop;
	
	public WeightGroupDrop(int weight,Drop drop){
		this.weight = weight;
		this.drop = drop;
	}
	
	public void calc(Random rnd, Gain gain) {
		drop.calc(rnd, gain);
	}

	public boolean isValid() {
		if (drop instanceof GroupDrop) {
			return ((GroupDrop)drop).isValid();
		} else {
			return true;
		}
	}
}