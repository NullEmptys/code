package com.gamedo.gameServer.core.fall;

public interface GroupDropServiceMBean {

}
