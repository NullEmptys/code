package com.gamedo.gameServer.core.fall;

import java.util.Random;

import com.gamedo.gameServer.core.gain.CurrencyGainEntry;
import com.gamedo.gameServer.core.gain.Gain;
import com.gamedo.gameServer.util.RandomUtil;

/**
 * 货币掉落
 * @author libm
 *
 */
public class CurrencyDrop extends RangeDrop {

	protected int currencyType;
	
	protected CurrencyDrop(int currencyType,int min, int max) {
		super(min, max);
		this.currencyType = currencyType;
	}

	@Override
	public void calc(Random rnd, Gain gain) {
		int m = RandomUtil.getCount(rnd, min, max);
		if(m > 0){
			gain.addGainEntry(new CurrencyGainEntry(currencyType,m));
		}
	}

}
