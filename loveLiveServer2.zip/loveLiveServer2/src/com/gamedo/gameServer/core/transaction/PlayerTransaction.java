package com.gamedo.gameServer.core.transaction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.TransactionException;

/**
 * 
 * @author libm
 *
 */
public class PlayerTransaction extends AbstractTransaction implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8774285327460375529L;
	
	protected Player player;
	protected String cause;
	protected List<GameItem> autoUseItems;
	protected boolean critical;
	
	public PlayerTransaction(Player player, String cause, boolean critical){
		this.player = player;
		this.state = ACTIVE;
		this.cause = cause;
		this.critical = critical;
		this.entities = new LinkedList<TransactionEntity>();
	}
	
	public boolean isCritical(){
		return critical;
	}
	
	public void internalCommit() throws TransactionException {
		if (state != ACTIVE)
			throw new TransactionException();
		for (TransactionEntity entity : entities) {
			entity.commit();
		}
	}
	
	public void internalRollback() throws TransactionException{
		if(state != ACTIVE)
			throw new TransactionException();
		for (TransactionEntity entity : entities) {
			entity.rollback();
		}
	}
	
	public void commit() throws TransactionException {
		player.release(this, true);
		this.state = COMMITED;
	}

	public void rollback() throws TransactionException {
		player.release(this, false);
		this.state = ROLLEDBACK;
	}

	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("[PLAYERTRANSACTION]");
		for(TransactionEntity entity:entities){
			sb.append(entity.toString());
		}
		return sb.toString();
	}
	
	public String getCause() {
		return cause;
	}
	
	public void setCause(String cause) {
		this.cause = cause;
	}
	
	public void addAutoUseItem(GameItem item) {
		if (autoUseItems == null) {
			autoUseItems = new ArrayList<GameItem>(3);
		}
		autoUseItems.add(item);
	}
	
	public List<GameItem> getAutoUseItems() {
		return autoUseItems;
	}
}
