package com.gamedo.gameServer.core;

import java.io.Serializable;
import java.util.List;

import com.gamedo.gameServer.entity.quest.PlayerQuest;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.QuestUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;
import com.gamedo.gameServer.util.JsonUtil;

/**
 * 
 * @author libm
 *
 */
public class QuestChangedItem extends ChangedItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9122357823753092400L;

	public QuestUpdateObject updateObject;
	
	public QuestChangedItem(QuestUpdateObject updateObject) {
		super(TYPE_QUEST,0,false);
		this.updateObject = updateObject;
	}
	
	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		
	}

	@Override
	public UpdateObject pack() {
		return updateObject;
	}

}
