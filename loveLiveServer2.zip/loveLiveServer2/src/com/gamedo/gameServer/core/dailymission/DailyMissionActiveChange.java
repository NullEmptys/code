package com.gamedo.gameServer.core.dailymission;

import java.io.Serializable;

import com.gamedo.gameServer.core.ChangedItem;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.DailyMissionActiveUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

public class DailyMissionActiveChange extends ChangedItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int activeValue;
	
	public DailyMissionActiveChange(int id,int activeValue){
		this.type = TUPE_DAILY_MISSION;
		this.id = id;
		this.activeValue = activeValue;
	}
	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public UpdateObject pack() {
		DailyMissionActiveUpdateObject dailyMissionActive = new DailyMissionActiveUpdateObject();
		dailyMissionActive.setType(this.type);
		dailyMissionActive.setId(id);
		dailyMissionActive.setActiveValue(activeValue);
		return dailyMissionActive;
	}
	
}
