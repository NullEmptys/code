package com.gamedo.gameServer.core;

/**
 * 
 * @author libm
 *
 */
public interface Updater {

	public void addSyncUpdatable(Updatable updatable);
	
	public void addTempSyncRunnable(Runnable runnable);
	
	public void addAsyncUpdatable(Updatable updatable);
	
	public void update();
}
