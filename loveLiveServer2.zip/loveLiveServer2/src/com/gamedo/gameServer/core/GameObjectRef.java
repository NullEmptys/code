package com.gamedo.gameServer.core;

public class GameObjectRef {

	protected int id;
	protected int type;

	public GameObjectRef(int id,int type) {
		this.id = id;
		this.type = type;
	}

	public long getId() {
		return id;
	}

	public int getType(){
		return this.type;
	}
}
