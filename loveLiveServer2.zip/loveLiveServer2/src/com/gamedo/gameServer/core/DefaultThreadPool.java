package com.gamedo.gameServer.core;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gamedo.gameServer.core.impl.SimpleUpdater;
import com.gamedo.gameServer.io.AsyncCall;

import gnu.trove.map.hash.TObjectLongHashMap;

/**
 * 
 * @author libm
 *
 */
@Component
public class DefaultThreadPool implements ThreadPool,Updatable {

	private static final Logger log = LoggerFactory.getLogger(DefaultThreadPool.class);

	protected ExecutorService executor = new MeasureThreadPoolExectuor(8, 64, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());

	protected ArrayBlockingQueue<AsyncCall> calls = new ArrayBlockingQueue<AsyncCall>(256);
	
	@Autowired
	protected SimpleUpdater simpleUpdater; 
	
	@PostConstruct
	public void start() {
		simpleUpdater.addSyncUpdatable(this);
	}
	
	@Override
	public void execute(Runnable call) {
		executor.execute(call);
	}
	
	public void addAsyncCall(AsyncCall call){
		calls.add(call);
	}
	
	@Override
	public boolean update() {
		AsyncCall call = null;
		while((call = calls.poll())!=null){
			try {
				call.callFinish();
				return true;
			} catch (Exception e) {
				log.error(e.toString(),e);
			}
		}
		return false;
	}

	/**
	 * 用来监测是否一个call调用超时，如果超过10s，将会被打印在log中
	 * 
	 * @author libm
	 *
	 */
	static class MeasureThreadPoolExectuor extends ThreadPoolExecutor {

		private TObjectLongHashMap<Runnable> thread2time = new TObjectLongHashMap<Runnable>();

		public MeasureThreadPoolExectuor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit,
				BlockingQueue<Runnable> workQueue, RejectedExecutionHandler handler) {
			super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, handler);
		}

		public MeasureThreadPoolExectuor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit,
				BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory, RejectedExecutionHandler handler) {
			super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, threadFactory, handler);
		}

		public MeasureThreadPoolExectuor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit,
				BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory) {
			super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, threadFactory);
		}

		public MeasureThreadPoolExectuor(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit,
				BlockingQueue<Runnable> workQueue) {
			super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
		}

		@Override
		protected void afterExecute(Runnable r, Throwable t) {
			synchronized (thread2time) {
				long t1 = thread2time.remove(r);
				long interval = (System.nanoTime() - t1) / 1000000L;
				int playerID = -1;
				if (interval > 1000) { // 如果超过10s
					log.info("[CALLTOOLONG]ID[" + playerID + "]CLASS[{}]TIME[{}]", r.getClass().getName(), interval);
				}
			}
		}

		@Override
		protected void beforeExecute(Thread t, Runnable r) {
			synchronized (thread2time) {
				thread2time.put(r, System.nanoTime());
			}
		}
	}

}
