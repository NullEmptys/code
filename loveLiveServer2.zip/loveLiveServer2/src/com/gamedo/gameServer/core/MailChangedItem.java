package com.gamedo.gameServer.core;

import java.io.Serializable;

import com.gamedo.gameServer.entity.mail.Mail;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.MailUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

/**
 * 
 * @author libm
 *
 */
public class MailChangedItem extends ChangedItem implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 113682173076192771L;
	
	private Mail mail;

	public MailChangedItem(Mail mail,int id) {
		this.mail = mail;
		this.id = id;
	}
	
	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {

	}

	@Override
	public UpdateObject pack() {
		MailUpdateObject updateObject = new MailUpdateObject();
		updateObject.setId(id);
		updateObject.setType(ChangedItem.TYPE_MAIL);
		updateObject.setMailId(mail.getId());
		if(id == ChangedItem.MAIL_ADD) {
			updateObject.setStatus(mail.getStatus());
			updateObject.setPostTime(mail.getPostTime().getTime());
			updateObject.setSendName(mail.getSendName());
			updateObject.setSourceId(mail.getSourceId());
			updateObject.setTitle(mail.getTitle());
			int attach = 0;
			if(null!=mail.getAttachments() && mail.getAttachments().getAttachments()!= null && mail.getAttachments().getAttachments().length > 0){
				attach = 1;
			}else{
				attach = 0;
			}
			updateObject.setHaveAttach(attach);//是否有邮件附件
			updateObject.setReceivedAttach(mail.getReceivedAttach());
		}
		return updateObject;
	}

}
