package com.gamedo.gameServer.core;

import java.io.Serializable;

import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.LongPropertyUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

public class LongPropertyChangedItem extends ChangedItem implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3199757030646602435L;
	protected long value;
	protected boolean overwrite;
	protected boolean broadcast;
	
	public LongPropertyChangedItem(int id,long value,boolean notify){
		this(id,value,notify,false);
	}
	
	/**
	 * 
	 * @param id
	 * @param value 
	 * @param notify
	 * @param overwrite merge策略是覆盖还是添加
	 */
	public LongPropertyChangedItem(int id,long value,boolean notify,boolean overwrite){
		this(id,value,notify,overwrite,false);
	}
	
	public LongPropertyChangedItem(int id,long value,boolean notify,boolean overwrite,boolean broadcast){
		super(TYPE_INT,id,notify);
		this.value = value;
		this.overwrite = overwrite;
		this.broadcast = broadcast;
	}
	
	@Override
	public boolean merge(ChangedItem other){
		if(other instanceof IntPropertyChangedItem){
			if(notify==other.notify&&id==other.id){
				if(overwrite){
					value = ((IntPropertyChangedItem)other).value;
				}else{
					value += ((IntPropertyChangedItem)other).value;
				}
				return true;
			}else{
				return false;
			}
		}else
			return false;
	}
	
	@Override
	public UpdateObject pack() {
		LongPropertyUpdateObject obj = new LongPropertyUpdateObject();
		obj.setId(id);
		obj.setType(type);
		obj.setValue(value);
		return obj;
	}
	
	public boolean isBroadcast(){
		return broadcast;
	}
	
	public void makeBroadcastPacket(Packet pt){
		
	}

}
