package com.gamedo.gameServer.core;

import java.io.Serializable;

import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.PlayerGirlBaseDataUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

/**
 * 模特基础数据变化
 * @author libm
 *
 */
public class PlayerGirlBaseDataChangeItem extends ChangedItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -233413631858362390L;

	protected int girlId;
	
	protected int exp;
	
	protected int level;
	
	protected int status;
	
	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		
	}

	@Override
	public UpdateObject pack() {
		PlayerGirlBaseDataUpdateObject object = new PlayerGirlBaseDataUpdateObject();
		object.setType(ChangedItem.TYPE_PLAYERGIRL_BASE_DATA);
		object.setGirlId(girlId);
		object.setExp(exp);
		object.setLevel(level);
		object.setStatus(status);
		return object;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}
