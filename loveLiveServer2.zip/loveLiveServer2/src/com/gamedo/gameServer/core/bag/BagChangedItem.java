package com.gamedo.gameServer.core.bag;

import java.io.Serializable;

import com.gamedo.gameServer.core.ChangedItem;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.BagItemUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

/**
 * 
 * @author libm
 *
 */
public class BagChangedItem extends ChangedItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8801965496990339222L;
	
	protected int itemId;
	protected int instanceId;
	protected GameItem item;
	protected int count;
	protected BagGrid grid;
	
	public BagChangedItem() {
		
	}
	
	public BagChangedItem(BagGrid grid){
		super(TYPE_COMPLEX,BAGGRID,false);
		this.grid = grid;
		this.itemId = grid.item.getTemplate().getId();
		this.instanceId = grid.item.getInstanceId();
	}
	
	public BagChangedItem(BagGrid grid,int itemId,int instanceId){
		super(TYPE_COMPLEX,BAGGRID,false);
		this.grid = grid;
		this.itemId = itemId;
		this.instanceId = instanceId;
	}
	
	public BagChangedItem(GameItem item,int count){
		super(TYPE_BAG,ITEM_COUNT_CHANGED,false);
		this.itemId = item.getTemplate().getId();
		this.instanceId = item.getInstanceId();
		this.item = item;
		this.count = count;
	}
	
	@Override
	public boolean merge(ChangedItem other) {
		if(other instanceof BagChangedItem){
			if(notify==other.notify){
				BagChangedItem o = (BagChangedItem)other;
				if(notify){
					if(item.equals(o.item)){
						count += o.count;
						return true;
					}
					return false;
				}else{
					if(grid.bag.getClass() == o.grid.bag.getClass() && grid.id==o.grid.id && grid.bag.id==o.grid.bag.id){
						grid = o.grid;
						return true;
					}
					return false;
				}
			}else{
				return false;
			}
		}else
			return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		
	}
	
	public BagGrid getGrid() {
		return grid;
	}

	@Override
	public UpdateObject pack() {
		BagItemUpdateObject object = new BagItemUpdateObject();
		object.setType(ChangedItem.TYPE_BAG);
		object.setBagId(grid.bag.id);
		object.setGridId(grid.id);
		object.setItemId(itemId);
		object.setInstanceId(instanceId);
		object.setCount(grid.count);
		if(grid.item != null) {
			object.setCreateTime(grid.item.getCreateTime());
			object.setCdTime(grid.item.getObsoleteTime());
		}
		return object;
	}

}
