package com.gamedo.gameServer.core.bag;

import java.io.Serializable;

import com.gamedo.gameServer.core.ChangedItem;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.Transaction;
import com.gamedo.gameServer.core.transaction.TransactionEntity;

/**
 * 
 * @author libm
 *
 */
public class BagGridTransactionEntity implements TransactionEntity,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2977691443983567466L;
	public static final int BAG = 1;
	public static final int DEPOT = 2;

	BagGrid grid;
	GameItem item;
	int count;
	boolean notify;
	int type;
	Transaction trans;
	
	public BagGridTransactionEntity(Transaction trans, BagGrid grid, GameItem item,
			int count, boolean notify) {
		this(trans, grid, item, count, notify, BAG);
	}
	
	public BagGridTransactionEntity(Transaction trans, BagGrid grid,GameItem item,int count,boolean notify,int type){
		this.trans = trans;
		this.grid = grid;
		this.item = item;
		this.count = count;
		this.notify = notify;
		this.type = type;
	}
	
	public void commit() {
		grid.release(this, true);
	}

	public void rollback() {
		grid.release(this, false);
	}
	
	public ChangedItem[] sync(){
		if(type==DEPOT){
			return null;
		}
		ChangedItem[] ret = null;
		if(notify){
			ret = new ChangedItem[2];
		}else{
			ret = new ChangedItem[1];
		}
		return ret;
	}
	
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("[ENTITY]");
		if(grid!=null){
			sb.append(grid.toString());
		}
		sb.append("COUNT[").append(count).append("]");
		return sb.toString();
	}

	public Transaction getTransaction() {
		return trans;
	}
}
