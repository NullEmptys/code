package com.gamedo.gameServer.core.bag;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gamedo.gameServer.core.ChangedItem;
import com.gamedo.gameServer.core.Time;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.core.transaction.Transaction;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.NoEnoughSpaceException;
import com.gamedo.gameServer.log.Log;


/**
 * 背包
 * @author libm
 *
 */
public class Bag implements Cloneable,BagListener,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3326628263180235013L;

	private static final Logger log = LoggerFactory.getLogger(Bag.class);
	
	Bags bags;
	int id;
	int size;
	int addedSize;
	List<BagGrid> grids;
	Lock lock = new ReentrantLock();
	

	Map<Integer, Set<Integer>> indexes = new TreeMap<Integer, Set<Integer>>();
	
	List<BagListener> listeners = new ArrayList<BagListener>();

	public Bag(Bags bags, int id,int size, int addedSize) {
		this.bags = bags;
		this.id = id;
		this.size = size;
		this.addedSize = addedSize;
		grids = new ArrayList<BagGrid>(getSize());
		for (int i = 0; i < getSize(); i++) {
			BagGrid grid = new BagGrid(i, this);
			grids.add(grid);
			addIndex(-1, grid.id);
		}
		addListener(this);
	}
	
	@Override
	public void arranged(Bag bag) {
		
	}

	@Override
	public void bagExtended(Bag bag, int oldSize, int newSize) {
		bags.owner.changed.addChangedItem(new BagExtendedChangeItem(bag));
	}

	@Override
	public void bagFulled(Bag bag) {
		
	}

	@Override
	public void exchanged(BagGrid source, BagGrid target) {
		
	}

	@Override
	public void itemAdded(BagGrid grid, GameItem item, int count, Transaction tx,boolean notify) {
		if(notify){
			bags.owner.changed.addChangedItem(new BagChangedItem(item,count));
		}
		if(bags.type == 2) {
			GirlBags girlBags = (GirlBags) bags;
			bags.owner.changed.addChangedItem(new GirlBagChangedItem(grid,girlBags.girlId));
		}else {
			bags.owner.changed.addChangedItem(new BagChangedItem(grid));
		}
		
	}

	@Override
	public void itemRemoved(BagGrid grid, GameItem item, int count,
			Transaction tx,boolean notify) {
		if(notify){
			bags.owner.changed.addChangedItem(new BagChangedItem(item,-count));
		}
		if(bags.type == 2) {
			GirlBags girlBags = (GirlBags) bags;
			bags.owner.changed.addChangedItem(new GirlBagChangedItem(grid,girlBags.girlId));
		}else {
			bags.owner.changed.addChangedItem(new BagChangedItem(grid,item.getTemplate().getId(),item.getInstanceId()));
		}
	}

	public void addListener(BagListener bagListener){
		listeners.add(bagListener);
	}
	
	public void removeListener(BagListener bagListener){
		listeners.remove(bagListener);
	}
	
	public Comparator<GameItem> getComparator(){
		return null;
	}
	
	public int getId(){
		return id;
	}
	
	public List<BagGrid> getGrids(){
		return grids;
	}
	
	protected void notifyItemAdded(BagGrid grid,GameItem item,int count,Transaction tx,boolean notify){
		for(BagListener l:listeners){
			l.itemAdded(grid, item, count,tx,notify);
		}
	}
	
	protected void notifyItemRemoved(BagGrid grid,GameItem item,int count,Transaction tx,boolean notify){
		for(BagListener l:listeners){
			l.itemRemoved(grid, item, count,tx,notify);
		}
	}

	protected void addIndex(int itemTemplateId, int gridId) {
		Set<Integer> gs = indexes.get(itemTemplateId);
		if (gs == null) {
			gs = new TreeSet<Integer>();
			indexes.put(itemTemplateId, gs);
		}
		gs.add(gridId);
	}

	protected void removeIndex(int itemTemplateId, int gridId) {
		Set<Integer> gs = indexes.get(itemTemplateId);
		if (gs != null) {
			gs.remove(gridId);
			if (gs.isEmpty()) {
				indexes.put(itemTemplateId, null);
			}
		}
	}

	public int getSize() {
		return size + addedSize;
	}

	public int getAddedSize() {
		return addedSize;
	}
	
	public void removeObsoleteGameItems(){
		lock.lock();
		try{
			long curTime = Time.currDate.getTime();
			for(BagGrid grid : grids){
				if(grid.isEmpty() || (grid.entities != null && grid.entities.size() > 0))
					continue;
				if(grid.count > 0){
					long oTime =  grid.getItem().getObsoleteTime();
					if(oTime != -1 && curTime > oTime){
						removeIndex(grid.getItem().getTemplate().getId(), grid.id);
						addIndex(-1, grid.id);
						GameItem item = grid.item;
						int count = grid.count;
						grid.item = null;
						grid.count = 0;
						itemRemoved(grid, item, count, null, false);
						EventManager.getInstance().addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_REMOVE_ITEM, this.bags.owner, item.getTemplate().getId(),item.getTemplate().getName(),count,"OBSO"));
						Log.getInstance().logRemoveItem(bags.owner, item, count, "OBSO");
					}
				}
			}
		}finally{
			lock.unlock();
		}
	}

	public boolean arrange() {
		lock.lock();
		try {
			Map<GameItem, Integer> tmp = new TreeMap<GameItem, Integer>(
					getComparator());
			try {
				for (BagGrid grid : grids) {
					if (grid.entities != null && grid.entities.size() > 0)
						return false;
					if (grid.item != null && grid.count > 0) {
						Integer value = tmp.get(grid.item);
						if (value != null) {
							tmp.remove(grid.item);
							tmp.put(grid.item, value + grid.count);
						} else {
							tmp.put(grid.item, grid.count);
						}
					}
				}
			} catch (Exception ex) {
				return false;
			}
			indexes.clear();
			for (BagGrid grid : grids) {
				grid.item = null;
				grid.count = 0;
				addIndex(-1, grid.id);
			}
			Iterator<Map.Entry<GameItem, Integer>> ite = tmp.entrySet()
					.iterator();
			while (ite.hasNext()) {
				Map.Entry<GameItem, Integer> entry = ite.next();
				if (entry.getValue() > 1
						&& entry.getKey().getInstanceId() != GameItem.GENERAL_INSTANCEID) {
					boolean added = addGameItem0(entry.getKey(), 1) == 0;
					if(!added){
//						log.info("[BAGARRANGEERROR]"
//								+ LogUtil.getPlayerLogString(owner)
//								+ LogUtil.getGameItemString(entry.getKey(),
//										entry.getValue()));
					}
//					log.info("[BAGARRANGEINSTANCEERROR]"
//							+ LogUtil.getPlayerLogString(owner)
//							+ LogUtil.getGameItemString(entry.getKey(),
//									entry.getValue()));
				} else {
					boolean added = addGameItem0(entry.getKey(), entry
							.getValue()) == 0;
					if (!added) {
//						log.info("[BAGARRANGEERROR]"
//								+ LogUtil.getPlayerLogString(owner)
//								+ LogUtil.getGameItemString(entry.getKey(),
//										entry.getValue()));
					}
				}
			}
			return true;
		} finally {
			lock.unlock();
		}
	}
	
	public Player getOwner(){
		return bags.owner;
	}
	
	protected void notifyExchanged(BagGrid source,BagGrid target){
		for(BagListener l:listeners){
			l.exchanged(source, target);
		}
	}

	public boolean exchange(int sourceId, int targetId, boolean isBag) {
		if (sourceId >= 0 && sourceId <= grids.size() && targetId >= 0
				&& targetId <= grids.size() && sourceId != targetId) {
			lock.lock();
			try {
				BagGrid sourceGrid = grids.get(sourceId);
				BagGrid targetGrid = grids.get(targetId);
				if (sourceGrid.count == 0)
					return false;
				if ((sourceGrid.entities != null && sourceGrid.entities.size() > 0)
						|| (targetGrid.entities != null && targetGrid.entities
								.size() > 0))
					return false;
				if (sourceGrid.isEmpty() && targetGrid.isEmpty())
					return false;
				if (targetGrid.isEmpty()) {
					GameItem item = sourceGrid.item;
					int count = sourceGrid.count;
					sourceGrid.item = null;
					sourceGrid.count = 0;
					removeIndex(-1, targetGrid.id);
					removeIndex(item.getTemplate().getId(), sourceGrid.id);
					targetGrid.item = item;
					targetGrid.count = count;
					addIndex(item.getTemplate().getId(), targetGrid.id);
					addIndex(-1, sourceGrid.id);
					notifyExchanged(sourceGrid,targetGrid);
					return true;
				}
				if (sourceGrid.item.equals(targetGrid.item)) {
					if (targetGrid.count >= targetGrid.item.getTemplate().getAddition())
						return false;
					int v = Math.min(sourceGrid.count,
							targetGrid.item.getTemplate().getAddition()
									- targetGrid.count);
					sourceGrid.count -= v;
					targetGrid.count += v;
					if (sourceGrid.count == 0) {
						removeIndex(sourceGrid.item.getTemplate().getId(), sourceGrid.id);
						sourceGrid.item = null;
						addIndex(-1, sourceGrid.id);
					}
					notifyExchanged(sourceGrid,targetGrid);
					return true;
				} else {
					removeIndex(sourceGrid.item.getTemplate().getId(), sourceGrid.id);
					removeIndex(targetGrid.item.getTemplate().getId(), targetGrid.id);
					GameItem item = sourceGrid.item;
					int count = sourceGrid.count;
					sourceGrid.item = targetGrid.item;
					sourceGrid.count = targetGrid.count;
					targetGrid.item = item;
					targetGrid.count = count;
					addIndex(sourceGrid.item.getTemplate().getId(), sourceGrid.id);
					addIndex(targetGrid.item.getTemplate().getId(), targetGrid.id);
					notifyExchanged(sourceGrid,targetGrid);
					return true;
				}
			} finally {
				lock.unlock();
			}
		} else {
			return false;
		}
	}

	protected Set<Integer> getIndexSet(int itemId) {
		return indexes.get(itemId);
	}

	public int getFreeBagCount() {
		lock.lock();
		try {
			int count = 0;
			for (BagGrid grid : grids) {
				if (grid.isEmpty())
					count++;
			}
			return count;
		} finally {
			lock.unlock();
		}
	}

	
	GameItem removeGameItemIngoreInstanceId0(int itemId,Integer count,PlayerTransaction tx, boolean notify){
		lock.lock();
		try {
			Set<Integer> set = getIndexSet(itemId);
			if (set == null) {
				return null;
			}
			for (int gridId : set) {
				BagGrid grid = grids.get(gridId);
				int v = grid
						.removeGameItem(itemId, grid.item.getInstanceId(), count, tx, notify);
				count -= v;
				if (count == 0)
					return grid.item;
			}
			return null;
		} catch (Exception ex) {
			log.error(ex.toString(), ex);
			return null;
		} finally {
			lock.unlock();
		}
	}
	
	public GameItem removeGameItemIngoreInstanceId(int itemId,int count,PlayerTransaction tx, boolean notify){
		lock.lock();
		try {
			Set<Integer> set = getIndexSet(itemId);
			if (set == null) {
				return null;
			}
			int all = count;
			for (int gridId : set) {
				BagGrid grid = grids.get(gridId);
				int v = grid
						.removeGameItem(itemId, grid.item.getInstanceId(), all, tx, notify);
				all -= v;
				if (all == 0)
					return grid.item;
			}
			return null;

		} catch (Exception ex) {
			log.error(ex.toString(), ex);
			return null;
		} finally {
			lock.unlock();
		}
	}
	
	GameItem removeGameItem0(int itemTemplateId,int instanceId,Integer count,PlayerTransaction tx,boolean notify){
		lock.lock();
		try {
			Set<Integer> set = getIndexSet(itemTemplateId);
			if (set == null) {
				return null;
			}
			for (int gridId : set) {
				BagGrid grid = grids.get(gridId);
				int v = grid
						.removeGameItem(itemTemplateId, instanceId, count, tx, notify);
				count -= v;
				if (count == 0)
					return grid.item;
			}
			return null;
		} catch (Exception ex) {
			log.error(ex.toString(), ex);
			return null;
		} finally {
			lock.unlock();
		}
	}

	public GameItem removeGameItem(int itemTemplateId, int instanceId, int count,
			PlayerTransaction tx, boolean notify) {
		lock.lock();
		try {
			Set<Integer> set = getIndexSet(itemTemplateId);
			if (set == null) {
				return null;
			}
			int all = count;
			for (int gridId : set) {
				BagGrid grid = grids.get(gridId);
				int v = grid
						.removeGameItem(itemTemplateId, instanceId, all, tx, notify);
				all -= v;
				if (all == 0)
					return grid.item;
			}
			return null;

		} catch (Exception ex) {
			log.error(ex.toString(), ex);
			return null;
		} finally {
			lock.unlock();
		}
	}

	public void addGameItemComplete(GameItem item, int count,
			PlayerTransaction tx, boolean notify) throws NoEnoughSpaceException {
		lock.lock();
		try {
			Set<Integer> set = null;
			int all = count;
			if (item.getInstanceId() == GameItem.GENERAL_INSTANCEID) {
				set = getIndexSet(item.getTemplate().getId());
				if (set != null) {
					for (int gridId : set) {
						BagGrid grid = grids.get(gridId);
						int v = grid.addGameItem(item, all, tx, notify);
						all -= v;
						if (all == 0)
							return;
					}
				}
			}
			set = getIndexSet(-1);
			if (set != null) {
				for (int gridId : set) {
					BagGrid grid = grids.get(gridId);
					int v = grid.addGameItem(item, all, tx, notify);
					all -= v;
					if (all == 0)
						return;
				}
			}
			notifyFulled();
			throw new NoEnoughSpaceException();
		} catch (Exception ex) {
			log.error(ex.toString(), ex);
			if (ex instanceof NoEnoughSpaceException)
				throw (NoEnoughSpaceException) ex;
		} finally {
			lock.unlock();
		}
	}
	
	protected void notifyFulled(){
		for(BagListener l:listeners){
			l.bagFulled(this);
		}
	}

	
	/**
	 * 在背包内加入指定数量的物品，物品有可能不会全部加入，返回值是加入以后剩余的数量。如果全部加入成功，那么返回值应该是0，如果一样都没加入，
	 * 那么返回值是指定的数量count
	 * 
	 * @param item
	 * @param count
	 * @return
	 */
	int addGameItem0(GameItem item, int count) {
		lock.lock();
		try {
			Set<Integer> set = null;
			int all = count;
			if (item.getInstanceId() == GameItem.GENERAL_INSTANCEID) {
				set = getIndexSet(item.getTemplate().getId());
				if (set != null) {
					for (int gridId : set) {
						BagGrid grid = grids.get(gridId);
						int v = grid.addGameItem0(item, all);
						all -= v;
						if (all == 0)
							return 0;
					}
				}
			}
			set = getIndexSet(-1);
			if (set != null) {
				for (int gridId : set) {
					BagGrid grid = grids.get(gridId);
					int v = grid.addGameItem0(item, all);
					all -= v;
					if (all == 0)
						return 0;
				}
			}
			return all;
		} catch (Exception ex) {
			log.error(ex.toString(), ex);
			return count;
		} finally {
			lock.unlock();
		}
	}
	
	
	int addGameItem1(GameItem item, int count, PlayerTransaction tx,
			boolean notify) {
		lock.lock();
		try {
			Set<Integer> set = null;
			int all = count;
			if (item.getInstanceId() == GameItem.GENERAL_INSTANCEID) {
				set = getIndexSet(item.getTemplate().getId());
				if (set != null) {
					for (int gridId : set) {
						BagGrid grid = grids.get(gridId);
						int v = grid.addGameItem(item, all, tx, notify);
						all -= v;
						if (all == 0)
							return 0;
					}
				}
			}
			set = getIndexSet(-1);
			if (set != null) {
				for (int gridId : set) {
					BagGrid grid = grids.get(gridId);
					int v = grid.addGameItem(item, all, tx, notify);
					all -= v;
					if (all == 0)
						return 0;
				}
			}
			notifyFulled();
			return all;
		} catch (Exception ex) {
			log.error(ex.toString(), ex);
			return count;
		} finally {
			lock.unlock();
		}
	}
	
	public boolean addGameItem(GameItem item, int count, PlayerTransaction tx,
			boolean notify) {
		lock.lock();
		try {
			Set<Integer> set = null;
			int all = count;
			if (item.getInstanceId() == GameItem.GENERAL_INSTANCEID) {
				set = getIndexSet(item.getTemplate().getId());
				if (set != null) {
					for (int gridId : set) {
						BagGrid grid = grids.get(gridId);
						int v = grid.addGameItem(item, all, tx, notify);
						all -= v;
						if (all == 0)
							return true;
					}
				}
			}
			set = getIndexSet(-1);
			if (set != null) {
				for (int gridId : set) {
					BagGrid grid = grids.get(gridId);
					int v = grid.addGameItem(item, all, tx, notify);
					all -= v;
					if (all == 0)
						return true;
				}
			}
			notifyFulled();
			return false;
		} catch (Exception ex) {
			log.error(ex.toString(), ex);
			return false;
		} finally {
			lock.unlock();
		}
	}
	
	public BagGrid getGrid(int index){
		return grids.get(index);
	}

	/**
	 * 只使用于移除有InstanceId的物品
	 * 
	 * @param itemTemplateId
	 * @param instanceId
	 * @param tx
	 * @param notify
	 * @return
	 */
	public BagGrid removeGameItemInstance(int itemTemplateId,
			int instanceId, PlayerTransaction tx, boolean notify) {
		lock.lock();
		try {
			if (instanceId == GameItem.GENERAL_INSTANCEID)
				throw new IllegalArgumentException();
			for (BagGrid grid : grids) {
				if (grid.removeGameItem(itemTemplateId, instanceId, 1, tx, notify) == 1) {
					return grid;
				}
			}
			return null;
		} catch (Exception e) {
			log.error(e.toString(), e);
			return null;
		} finally {
			lock.unlock();
		}
	}

	public BagGrid removeGameItemInOneGrid(int itemTemplateId,
			int instanceId, int count, PlayerTransaction tx, boolean notify) {
		lock.lock();
		try {
			for (BagGrid grid : grids) {
				if (grid.removeGameItem(itemTemplateId, instanceId, count, tx, notify) == count) {
					return grid;
				}
			}
			return null;
		} catch (Exception e) {
			log.error(e.toString(), e);
			return null;
		} finally {
			lock.unlock();
		}
	}

	public BagGrid removeGridGameItem(int gridId, int itemTemplateId,
			int instanceId, int count, PlayerTransaction tx, boolean notify) {
		lock.lock();
		try {
			if (gridId == -1)
				return removeGameItemInOneGrid(itemTemplateId, instanceId, count, tx,
						notify);
			else if (gridId < 0 || gridId >= getSize())
				return null;
			BagGrid grid = grids.get(gridId);
			if (grid.removeGameItem(itemTemplateId, instanceId, count, tx, notify) == count) {
				return grid;
			}
			return null;
		} catch (Exception e) {
			log.error(e.toString(), e);
			return null;
		} finally {
			lock.unlock();
		}
	}
	
	/**
	 * 拆分物品。
	 * @param gridId 包格ID
	 * @param itemTemplateId 物品模板ID
	 * @param instanceId 物品instanceID
	 * @param count 拆分数量
	 * @throws NoEnoughSpaceException 背包已满
	 * @throws RuntimeException 其他错误
	 */
	public ChangedItem[] splitGridGameItem(int gridId, int itemTemplateId, int count) throws NoEnoughSpaceException {
		lock.lock();
		try {
			if (gridId < 0 || gridId >= getSize()) {
				throw new RuntimeException();
			}
			
			// 查找一个空的包格
			BagGrid newGrid = null;
			for (BagGrid grid : grids) {
				if (grid.isEmpty()) {
					newGrid = grid;
					break;
				}
			}
			if (newGrid == null) {
				throw new NoEnoughSpaceException();
			}
		
			// 从旧格中拆分出物品来
			BagGrid grid = grids.get(gridId);
			GameItem item = grid.split(itemTemplateId, count);
			
			// 在一个空格中加入物品
			newGrid.addGameItem0(item, count);
			
			// 向客户端同步改动
			ChangedItem[] ret = new ChangedItem[2];
			if(bags instanceof GirlBags) {
				
			}else {
				ret[0] = new BagChangedItem(grid,item.getTemplate().getId(),item.getInstanceId());
				ret[1] = new BagChangedItem(newGrid,item.getTemplate().getId(),item.getInstanceId());
			}
			return ret;
		} finally {
			lock.unlock();
		}
	}

	
	/**
	 * 获取指定ID的物品的数量
	 * @param itemTemplateId	物品模板ID
	 * @return			物品数量
	 */
	public int getGameItemCount(int itemTemplateId) {
		int total = 0;
		for (BagGrid g : grids) {
			if (g.item != null && g.item.getTemplate().getId() == itemTemplateId)
				total += g.count;
		}
		return total;
	}
	
	/**
	 * 获取背包物品数量
	 * @return
	 */
	public int getBagItemCounts() {
		int total = 0;
		for (BagGrid g : grids) {
			if (g.item != null)
				total += 1;
		}
		return total;
	}
	
	/**
	 * 获取指定包格位置的物品的数量
	 * @param gridId	包格ID
	 * @return			物品数量
	 */
	public int getGridItemCount(int gridId) {
		int num = 0;
		for (BagGrid g : grids) {
			if (g.item != null && g.id == gridId) {
				num = g.count;
				break;
			}
		}
		return num;
	}

	
	/**
	 * 找到第一个id相同的物品立即返回
	 * 
	 * @param itemTemplateId
	 * @return
	 */
	public BagGrid getGameItem(int itemTemplateId) {
		lock.lock();
		try {
			for (BagGrid g : grids) {
				if (g.item != null && g.item.getTemplate().getId() == itemTemplateId)
					return g;
			}
			return null;
		} finally {
			lock.unlock();
		}
	}
	
	public GameItem getGameItemById(int itemTemplateId) {
		lock.lock();
		try {
			for (BagGrid g : grids) {
				if (g.item != null && g.item.getTemplate().getId() == itemTemplateId)
					return g.item;
			}
			return null;
		} finally {
			lock.unlock();
		}
	}
	
	public GameItem getGameItem(int itemTemplateId,int instanceId){
		lock.lock();
		try {
			for (BagGrid g : grids) {
				if (g.item != null && g.item.getTemplate().getId() == itemTemplateId && g.item.getInstanceId()==instanceId)
					return g.item;
			}
			return null;
		} finally {
			lock.unlock();
		}
	}

	public GameItem getGameItem(int gridId, int itemTemplateId, int instanceId) {
		lock.lock();
		try {
			BagGrid grid = null;
			if (gridId == -1) {
				for (BagGrid g : grids) {
					if (g.item != null && g.item.getInstanceId() == instanceId
							&& g.item.getTemplate().getId() == itemTemplateId) {
						grid = g;
						break;
					}
				}
			} else {
				if (gridId < 0 || gridId >= getSize())
					return null;
				BagGrid g = grids.get(gridId);
				if (g.item != null && g.item.getInstanceId() == instanceId
						&& g.item.getTemplate().getId() == itemTemplateId)
					grid = g;
			}
			if (grid != null) {
				return grid.item;
			}
			return null;
		} finally {
			lock.unlock();
		}
	}

	/**
	 * 将背包扩展到
	 * 
	 * @param count
	 */
	public void extend(int count, boolean isAddedSize) {
		lock.lock();
		try {
			int c = 0;
			if (isAddedSize) {
				c = count - addedSize;
			} else {
				c = count - size;
			}
			if (c <= 0)
				return;
			int oldSize = getSize();
			for (int i = 0; i < c; i++) {
				BagGrid g = new BagGrid(oldSize + i, this);
				grids.add(g);
				addIndex(-1, g.id);
			}
			if (isAddedSize) {
				addedSize = count;
			} else {
				size = count;
			}
			notifyExtended(oldSize,getSize());
		} finally {
			lock.unlock();
		}
	}
	
	protected void notifyExtended(int oldSize,int newSize){
		for(BagListener l:listeners){
			l.bagExtended(this, oldSize, newSize);
		}
	}
	

	

	void lock() {
		lock.lock();
	}

	void unlock() {
		lock.unlock();
	}

	@Override
	public Bag clone() {
		Bag clone = new Bag(bags, id, size, addedSize);
		for (int i = 0, size = grids.size(); i < size; i++) {
			BagGrid cloneBg = clone.grids.get(i);
			BagGrid bg = grids.get(i);
			cloneBg.item = bg.item;
			cloneBg.count = bg.count;
		}
		return clone;
	}
	
	/**
	 * 仅用于测试，使用cheat中的clearbag命令。
	 */
	public void clear(PlayerTransaction tx, boolean notify) {
		for (BagGrid grid : grids) {
			if (grid == null ||  grid.item == null) {
				continue;
			}
			removeGridGameItem(grid.id, grid.item.getTemplate().getId(), grid.item.getInstanceId(), grid.count, tx, notify);
		}
	}

	public int getBagItemCounts(int type) {
		int total = 0;
		for (BagGrid g : grids) {
			if (g.item != null && g.item.getTemplate().getType() == type)
				total += 1;
		}
		return total;
	}

	public int getBagItemForeverCounts(int itemType) {
		int total = 0;
		for (BagGrid g : grids) {
			if (g.item != null && g.item.getTemplate().getType() == itemType && g.item.getObsoleteTime() == -1)
				total += 1;
		}
		return total;
	}
	
}
