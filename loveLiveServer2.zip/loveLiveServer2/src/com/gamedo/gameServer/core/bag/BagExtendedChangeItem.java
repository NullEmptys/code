package com.gamedo.gameServer.core.bag;

import java.io.Serializable;

import com.gamedo.gameServer.core.ChangedItem;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.UpdateObject;

/**
 * 
 * @author libm
 *
 */
public class BagExtendedChangeItem extends ChangedItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2228005557669677828L;
	
	protected Bag bag;

	public BagExtendedChangeItem(Bag bag) {
		super(ChangedItem.TYPE_COMPLEX, ChangedItem.GRIDCOUNT, false);
		this.bag = bag;
	}

	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {

	}

	@Override
	public UpdateObject pack() {
		return null;
	}

}
