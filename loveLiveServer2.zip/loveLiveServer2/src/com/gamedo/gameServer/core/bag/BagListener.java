package com.gamedo.gameServer.core.bag;

import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.Transaction;

/**
 * 
 * @author libm
 *
 */
public interface BagListener {

	public void exchanged(BagGrid source,BagGrid target);
	public void itemAdded(BagGrid grid,GameItem item,int count,Transaction tx,boolean notify);
	public void itemRemoved(BagGrid grid,GameItem item,int count,Transaction tx,boolean notify);
	public void arranged(Bag bag);
	public void bagExtended(Bag bag,int oldSize,int newSize);
	public void bagFulled(Bag bag);
}
