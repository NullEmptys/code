package com.gamedo.gameServer.core.bag;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.core.transaction.Transaction;
import com.gamedo.gameServer.log.Log;


/**
 * 背包格，每个格子有个id，是自身在包中的索引。包格采用两段式进行物品的添加以及删除操作
 * 
 * @author libm
 * 
 */
public class BagGrid implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7683028709944655597L;
	
	protected Bag bag;
	public int id;

	protected GameItem item;
	protected int count;
	protected int wantAddCount;
	protected int wantDecCount;
	protected List<BagGridTransactionEntity> entities = null;

	
	public BagGrid(int id, Bag bag) {
		this.id = id;
		this.bag = bag;
	}
	
	/**
	 * 除了序列化部份，其他程序千萬別用
	 * @param item
	 * @param count
	 */
	public void init(GameItem item,int count){
		if(count < 0)
			throw new IllegalArgumentException();
		this.item = item;
		this.count = count;
		if(this.item!=null&&this.count>0){
			bag.removeIndex(-1, id);
			bag.addIndex(item.getTemplate().getId(), id);
		}
	}

	int addGameItem0(GameItem item, int count) {
		if (count <= 0)
			throw new IllegalArgumentException();
		if (this.item == null) {
			this.item = item;
		} else {
			if (!item.equals(this.item)) {
				return 0;
			}
		}
		int max = item.getTemplate().getAddition();
		if (this.count + this.wantAddCount >= max) {
			return 0;
		} else {
			int v = Math.min(max - this.count - wantAddCount, count);
			this.count += v;
			bag.addIndex(item.getTemplate().getId(), id);
			return v;
		}
	}

	int addGameItem(GameItem item, int count, PlayerTransaction tx,
			boolean notify) {
		if (count <= 0)
			throw new IllegalArgumentException();
		if (this.item == null) {
			this.item = item;
		} else {
			if (!item.equals(this.item)) {
				return 0;
			}
		}
		int max = item.getTemplate().getAddition();
		if (this.count + this.wantAddCount >= max) {
			return 0;
		} else {
			int v = Math.min(max - this.count - wantAddCount, count);
			BagGridTransactionEntity entity = newTransactionEntity(tx, item, v,
					notify);
			tx.addEntity(entity);
			wantAddCount += v;
			return v;
		}
	}

	/**
	 * 
	 * @param itemTemplateId
	 * @param instanceId
	 * @param count
	 * @param tx
	 * @param notify
	 * @return 返回被移除的数量
	 */
	int removeGameItem(int itemTemplateId, int instanceId, int count,
			PlayerTransaction tx, boolean notify) {
		if (count <= 0)
			throw new IllegalArgumentException();
		if (this.item == null || this.count == 0)
			return 0;
//		if (this.item.getTemplate().getId() != itemTemplateId
//				|| this.item.getInstanceId() != instanceId)
//			return 0;
		if (this.item.getTemplate().getId() != itemTemplateId)
			return 0;
		int leave = this.count - this.wantDecCount;
		if (leave >= 0) {
			int v = leave > count ? count : leave;
			BagGridTransactionEntity entity = newTransactionEntity(tx,
					this.item, -v, notify);
			tx.addEntity(entity);
			wantDecCount += v;
			return v;
		} else {
			return 0;
		}
	}

	/**
	 * 从现有包格中拆分出一部分来。
	 * 
	 * @return 返回被移除的数量
	 */
	GameItem split(int itemTemplateId, int count) {
		// 只有可堆叠的物品才能拆分
		if (count <= 0)
			throw new IllegalArgumentException();
		if (this.item == null || this.count == 0)
			throw new IllegalArgumentException();
		if (this.item.getTemplate().getId() != itemTemplateId
				|| this.item.getInstanceId() != GameItem.GENERAL_INSTANCEID) {
			throw new IllegalArgumentException();
		}

		// 检查数量是否够
		int leave = this.count - this.wantDecCount;
		if (leave < count) {
			throw new IllegalArgumentException();
		}

		// 扣除物品，生成新物品
		this.count -= count;
		return this.item;
	}

	private BagGridTransactionEntity newTransactionEntity(Transaction trans,
			GameItem item, int count, boolean notify) {
		if (entities == null) {
			entities = new LinkedList<BagGridTransactionEntity>();
		}
		BagGridTransactionEntity entity = new BagGridTransactionEntity(trans,
				this, item, count, notify);
		entities.add(entity);
		return entity;
	}

	boolean isEmpty() {
		return item == null;
	}

	void release(BagGridTransactionEntity entity, boolean commit) {
		boolean removeOk = entities.remove(entity);
		if (!removeOk) {
			throw new IllegalArgumentException();
		}
		if (commit) {
			if (entity.count > 0) {
				count += entity.count;
				wantAddCount -= entity.count;
				Log.getInstance().logGetItem(bag.getOwner(), item, entity.count, entity.getTransaction().getCause());
			} else {
				count += entity.count;
				wantDecCount += entity.count;
				Log.getInstance().logRemoveItem(bag.getOwner(), item, entity.count, entity.getTransaction().getCause());
			}
		} else {
			if (entity.count > 0) {
				wantAddCount -= entity.count;
			} else {
				wantDecCount += entity.count;
			}
		}
		GameItem oldItem = item; // 有可能在扣除物品以后，包格里就不存在物品了，那么item将被设置成空，这里先保存一下
		if (entities.isEmpty())
			entities = null;
		if (count == 0 && wantAddCount == 0 && wantDecCount == 0) {
			if (item != null) {
				bag.removeIndex(item.getTemplate().getId(), id);
				bag.addIndex(-1, id);
			}
			item = null;
		} else {
			if (item != null) {
				bag.removeIndex(-1, id);
				bag.addIndex(item.getTemplate().getId(), id);
			}
		}
		if (commit) {
			if (entity.count > 0) {
				bag.notifyItemAdded(this, item, entity.count, entity
						.getTransaction(),entity.notify);
			} else {
				bag.notifyItemRemoved(this, oldItem, -entity.count, entity
						.getTransaction(),entity.notify);
				EventManager.getInstance().addEvent(new ServiceEvent(ServiceEvent.EVENT_PLAYER_REMOVE_ITEM, this.bag.bags.owner, oldItem.getTemplate().getId(),oldItem.getTemplate().getName(),-entity.count,entity.getTransaction().getCause()));
			}
		}
	}

//	public byte[] toClientBytes() {
//		ByteArrayOutputStream baos = new ByteArrayOutputStream();
//		DataOutputStream dos = new DataOutputStream(baos);
//		try {
//			dos.write(id);
//			dos.writeShort(count);
//			if (count > 0)
//				dos.write(item.toClientBytes());
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		return baos.toByteArray();
//	}

	public GameItem getItem() {
		return item;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("GRID[").append(id);
		if (item != null) {
			sb.append("ITEM[").append(item.getTemplate().getId()).append(",")
					.append(item.getInstanceId()).append(",").append(count)
					.append("]");
		}
		sb.append("WA[").append(wantAddCount).append("]");
		sb.append("WD[").append(wantDecCount).append("]");
		return sb.toString();
	}

	public int getCount(){
		return count;
	}

}
