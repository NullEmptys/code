package com.gamedo.gameServer.core.cache;

import java.lang.management.ManagementFactory;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.management.MBeanServer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gamedo.gameServer.service.AbstractService;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.management.ManagementService;

/**
 * 缓存管理
 * @author libm
 *
 */
@Service
public class CacheManagerService extends AbstractService implements CacheManagerServiceMBean{

	private Logger logger = LoggerFactory.getLogger(CacheManagerService.class);
	
	@Autowired
	private CacheManager cacheManager;
	
	private static CacheManagerService instance;
	
	public CacheManagerService() {
		
	}
	
	@Override
	public String getId() {
		return CacheManagerService.class.getName();
	}

	@PostConstruct
	public void startup() throws Exception {
		super.startup("掌上纵横-IPOC-LOVELIVE:type=服务,name=缓存服务");
		MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
		
		ManagementService.registerMBeans(cacheManager, mbs, true, true,  
                true, true); 
		instance = this;
	}

	@PreDestroy
	public void shutdown() throws Exception {
		super.shutdown();
	}

	@Override
	public Cache getCache(String cacheName) {
		return cacheManager.getCache(cacheName);
	}

	@Override
	public int getSize(String cacheName) {
		Cache cache = getCache(cacheName);
		if(cache != null) {
			return cache.getSize();
		}
		return 0;
	}

	@SuppressWarnings("deprecation")
	@Override
	public long getMemoryStoreSize(String cacheName) {
		Cache cache = getCache(cacheName);
		if(cache != null) {
			return cache.getMemoryStoreSize();
		}
		return 0;
	}

	@Override
	public long getCacheHits(String cacheName) {
		Cache cache = getCache(cacheName);
		if(cache != null) {
			return cache.getStatistics().cacheHitCount();
		}
		return 0;
	}

	@Override
	public long getCacheMisses(String cacheName) {
		Cache cache = getCache(cacheName);
		if(cache != null) {
			return cache.getStatistics().cacheMissCount();
		}
		return 0;
	}

	public static CacheManagerService getInstance() {
		return instance;
	}

	public CacheManager getCacheManager() {
		return cacheManager;
	}

	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}

}
