package com.gamedo.gameServer.core.cache;

import net.sf.ehcache.Cache;

/**
 * 
 * @author libm
 *
 */
public interface CacheManagerServiceMBean {

	public Cache getCache(String cacheName);
	
	/**
	 * 得到缓存中的对象数
	 * @param cacheName
	 * @return
	 */
	public int getSize(String cacheName);
	
	/**
	 * 得到缓存对象占用内存的大小
	 * @param cacheName
	 * @return
	 */
	public long getMemoryStoreSize(String cacheName);
	
	/**
	 * 得到缓存读取的命中次数
	 * @param cacheName
	 * @return
	 */
	public long getCacheHits(String cacheName);
	
	/**
	 * 得到缓存读取的错失次数 
	 * @param cacheName
	 * @return
	 */
	public long getCacheMisses(String cacheName);
}
