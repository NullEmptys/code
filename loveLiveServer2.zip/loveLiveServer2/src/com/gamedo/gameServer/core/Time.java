package com.gamedo.gameServer.core;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * 
 * @author libm
 *
 */
@Component
public class Time {
	public static final Logger log = LoggerFactory.getLogger(Time.class);

	/**
	 * 从服务器启动开始的当前时间，单位毫秒
	 */
	public static int currTime = 0;
	public static long startTime = 0;
	public static int tick = 0;

	public static int day = 0;
	public static int weekOfYear = 0;

	public static Date currDate = null;
	// public ScheduledExecutorService scheduler =
	// Executors.newScheduledThreadPool(3);
	public static final List<DayListener> dayListeners = new ArrayList<DayListener>();

	@PostConstruct
	public void init() {
		currDate = new Date();
		startTime = currDate.getTime();
		Calendar cal = Calendar.getInstance();
		day = (cal.get(Calendar.YEAR) << 16) | cal.get(Calendar.DAY_OF_YEAR);
		weekOfYear = (cal.get(Calendar.YEAR) << 16) | cal.get(Calendar.WEEK_OF_YEAR);
		// scheduler.scheduleAtFixedRate(new TimePrinter(), 0, 1,
		// TimeUnit.MINUTES);
	}

	public void resetDay() {
		Calendar cal = Calendar.getInstance();
		int newDay = (cal.get(Calendar.YEAR) << 16) | cal.get(Calendar.DAY_OF_YEAR);
		int newWeek = (cal.get(Calendar.YEAR) << 16) | cal.get(Calendar.WEEK_OF_YEAR);
		if (newDay != day) {
			log.info("[DAYCHANGED]OLD[" + day + "]NEW[" + newDay + "]");
			day = newDay;
			for (DayListener l : dayListeners) {
				try {
					l.dayChanged();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (weekOfYear != newWeek) {
			int tempDay = cal.get(Calendar.DAY_OF_WEEK);
			if (tempDay == 2) {// 周一
				log.info("[WEEKCHANGED]OLD[" + weekOfYear + "]NEW[" + newWeek + "]");
				weekOfYear = newWeek;
			}
		}
	}

	public long update() {
		currDate = new Date();
		long t = currDate.getTime() - startTime;
		long ret = t - currTime;
		if (ret < 0) {
			startTime += ret;
			ret = 0;
			t = currTime;
		}
		currTime = (int) t;
		resetDay();
		return ret;
	}

	/**
	 * 把TimeMillis换算成当前系统起始的Int时间
	 * 
	 * @param time
	 * @return
	 */
	public static int elapseTime(long time) {
		return (int) (time - startTime);
	}

	/**
	 * 把当前系统起始的Int时间换算成TimeMillis
	 * 
	 * @param t
	 * @return
	 */
	public static long currentTimeMillis(int t) {
		return startTime + t;
	}

	/**
	 * 取下一天的最早时间
	 * 
	 * @param date
	 * @return
	 */
	public static Date getDateNextDay(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DAY_OF_MONTH, 1);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	public static boolean betweenHour(Date date, int begin, int end) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int hour = cal.get(Calendar.HOUR_OF_DAY);
		return hour >= begin && hour <= end;
	}

	public static void addDayListener(DayListener l) {
		dayListeners.add(l);
	}

	/**
	 * @param args
	 */
	public static void main(String args[]) {
		Calendar cal = Calendar.getInstance();
		int day = (cal.get(Calendar.YEAR) << 16) | cal.get(Calendar.WEEK_OF_YEAR);
		System.out.println(day);
		day = cal.get(Calendar.DAY_OF_WEEK);
		System.out.println(day);
		
		cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, cal.get(Calendar.HOUR_OF_DAY) + 1);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("一个小时后的时间：" + df.format(cal.getTime()));
		System.out.println("当前的时间：" + df.format(new Date()));
	}
}

class TimePrinter implements Runnable {

	public static SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd|HH:mm:ss");

	@Override
	public void run() {
		System.out.println(format.format(new Date()));
	}

}
