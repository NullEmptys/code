package com.gamedo.gameServer.core.loginout;

import java.io.Serializable;

import com.gamedo.gameServer.core.ChangedItem;
import com.gamedo.gameServer.io.Packet;
import com.gamedo.gameServer.update.LoginOutUpdateObject;
import com.gamedo.gameServer.update.UpdateObject;

public class LoginOutChange extends ChangedItem implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String loginOutReason;//下线原因
	
	public LoginOutChange(int outType,String loginOutReason){
		this.type = LOGIN_OUT;
		this.id = outType;
		this.loginOutReason = loginOutReason;
	}
	@Override
	public boolean merge(ChangedItem other) {
		return false;
	}

	@Override
	public void makeBroadcastPacket(Packet pt) {
		
	}

	@Override
	public UpdateObject pack() {
		LoginOutUpdateObject outObject = new LoginOutUpdateObject();
		outObject.setType(this.type);
		outObject.setId(this.id);
		outObject.setLoginOutReason(loginOutReason);
		return outObject;
	}

}
