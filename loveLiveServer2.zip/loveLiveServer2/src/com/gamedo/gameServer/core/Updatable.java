package com.gamedo.gameServer.core;

/**
 * 
 * @author libm
 *
 */
public interface Updatable {

	public boolean update();
}
