package com.gamedo.gameServer.core.gain;

import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.GainException;

/**
 * 
 * @author libm
 *
 */
public interface GainEntry {

	public void apply(Player player, String cause, boolean complete,boolean check) throws GainException;

	public void rollback(Player player);

	public void log(StringBuilder sb);
}
