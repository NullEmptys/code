package com.gamedo.gameServer.core.gain;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.GainException;

/**
 * 
 * @author libm
 *
 */
public class CurrencyGainEntry implements GainEntry {

	protected int currencyType;
	protected int counts;

	public CurrencyGainEntry(int currencyType, int counts) {
		this.currencyType = currencyType;
		this.counts = counts;
	}

	@Override
	public void apply(Player player, String cause, boolean complete, boolean check) throws GainException {
		PlayerTransaction tx = player.newTransaction(cause);
		player.addAttributeByType(AttributeType.getAttrtType(currencyType), counts, tx);
		tx.commit();
	}

	@Override
	public void rollback(Player player) {

	}

	@Override
	public void log(StringBuilder sb) {

	}

	public int getCurrencyType() {
		return currencyType;
	}

	public int getCounts() {
		return counts;
	}
}
