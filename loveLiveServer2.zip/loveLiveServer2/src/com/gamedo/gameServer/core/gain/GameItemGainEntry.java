package com.gamedo.gameServer.core.gain;

import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.entity.player.Player;
import com.gamedo.gameServer.exception.GainException;

/**
 * 
 * @author libm
 *
 */
public class GameItemGainEntry implements GainEntry {

	protected GameItem item;
	protected int count;

	public GameItemGainEntry(GameItem item, int count) {
		this.item = item;
		this.count = count;
	}

	@Override
	public void apply(Player player, String cause, boolean complete, boolean check) throws GainException {
		player.getBags().addItem(item.getTemplate().getId(), count, cause);
	}

	@Override
	public void rollback(Player player) {

	}

	public GameItem getItem() {
		return item;
	}

	public int getCount() {
		return count;
	}

	public void log(StringBuilder sb) {
		// Platform.getLog(Log.class).getGameItemString(sb, item, count);
	}
}
