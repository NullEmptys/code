package com.gamedo.gameServer.db.achievement;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.achievement.AchieveLevelRewardRecord;

/**
 * 
 * @author libm
 *
 */
@Repository
public class AchieveLevelRewardRecordDao extends PlayerGenericHibernateDAO<AchieveLevelRewardRecord, Integer> {

	@SuppressWarnings("unchecked")
	public List<AchieveLevelRewardRecord> loadPlayerAchieveLevelRewardRecords(int playerId) {
		String hql = "from AchieveLevelRewardRecord t where t.playerId = ?0";
		return list(hql, playerId);
	}
}
