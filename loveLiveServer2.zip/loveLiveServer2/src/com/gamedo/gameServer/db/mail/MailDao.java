package com.gamedo.gameServer.db.mail;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.mail.Mail;

/**
 * 
 * @author libm
 *
 */
@Repository
public class MailDao extends PlayerGenericHibernateDAO<Mail, Integer>{

	@SuppressWarnings("unchecked")
	public List<Mail> getMails(int playerId) {
		String hql = "from Mail m where m.playerId = ?0 order by m.postTime asc";
		List<Mail> mails = list(hql, playerId);
		return mails;
	}

	public void deleteMailById(int id) {
		String hql = "delete from Mail where id = ?0";
		delete(hql, id);
	}

}
