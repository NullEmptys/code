package com.gamedo.gameServer.db.quest;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.quest.PlayerQuest;

/**
 * 
 * @author libm
 *
 */
@Repository
public class PlayerQuestDao extends PlayerGenericHibernateDAO<PlayerQuest, Integer>{

	/**
	 * 加载玩家所有关卡数据
	 * @param playerId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<PlayerQuest> loadPlayerQuests(int playerId) {
		String hql = "from PlayerQuest p where p.playerId = ?0";
		return list(hql, playerId);
	}

	@SuppressWarnings("unchecked")
	public List<PlayerQuest> loadPlayerQuestByChapterId(int playerId, int chapterId) {
		String hql = "from PlayerQuest t where t.playerId = ?0 and t.chapterId = ?1";
		return list(hql, playerId,chapterId);
	}

	@SuppressWarnings("unchecked")
	public List<PlayerQuest> loadPlayerQuestsByQuestId(int questId,int maxRankSize) {
		String hql = "from PlayerQuest t where t.questId = ?0 order by t.score desc";
		return limitList(hql, 0, maxRankSize, questId);
	}
	
}
