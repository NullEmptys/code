package com.gamedo.gameServer.db.girl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.girl.GirlUseRecord;

/**
 * 
 * @author libm
 *
 */
@Repository
public class GirlUseRecordDao extends PlayerGenericHibernateDAO<GirlUseRecord, Integer> {

	@SuppressWarnings("unchecked")
	public List<GirlUseRecord> loadGirlUseRecord(int week) {
		String hql = "from GirlUseRecord t where t.week = ?0 order by useCounts desc";
		return list(hql, week);
	}

	public GirlUseRecord findGirlUseRecord(int girlId, int week) {
		String hql = "from GirlUseRecord t where t.week = ?0 and girlId = ?1";
		return (GirlUseRecord) uniqueResult(hql, week,girlId);
	}
}
