package com.gamedo.gameServer.db.girl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.girl.SingleGirlHistoryUseRecord;
import com.gamedo.gameServer.entity.girl.SingleGirlUseRecord;

/**
 * 
 * @author libm
 *
 */
@Repository
public class SingleGirlUseRecordDao extends PlayerGenericHibernateDAO<SingleGirlUseRecord, Integer> {

	/**
	 * 
	 * @param weekOfYear
	 * @param girlId
	 * @param size
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<SingleGirlUseRecord> loadSingleGirlUseRecordRank(int weekOfYear,int girlId,int size) {
		String hql = "from SingleGirlUseRecord t where t.weekOfYear = ?0 and t.girlId = ?1 order by t.useCounts desc";
		return limitList(hql,0, size,weekOfYear,girlId);
	}

	/**
	 * 
	 * @param playerId
	 * @param girlId
	 * @param weekOfYear
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<SingleGirlUseRecord> loadPlayerSingleGirlUseRecord(int playerId,int weekOfYear) {
		String hql = "from SingleGirlUseRecord t where t.playerId = ?0 and t.weekOfYear = ?1";
		return list(hql, playerId,weekOfYear);
	}
	
	public SingleGirlUseRecord loadSingleGirlUseRecordById(int playerId,int girlId,int weekOfYear) {
		String hql = "from SingleGirlUseRecord t where t.playerId = ?0 and t.girlId = ?1 and t.weekOfYear = ?2";
		return (SingleGirlUseRecord) uniqueResult(hql, playerId,girlId,weekOfYear);
	}
}
