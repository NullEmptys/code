package com.gamedo.gameServer.db.shop;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.shop.PlayerItemShop;

/**
 * 
 * @author libm
 *
 */
@Repository
public class PlayerItemShopDao extends PlayerGenericHibernateDAO<PlayerItemShop, Integer> {

	@SuppressWarnings("unchecked")
	public List<PlayerItemShop> loadPlayerItemShopsById(int playerId) {
		String hql = "from PlayerItemShop t where t.playerId = ?0";
		return list(hql, playerId);
	}

	public void deletePlayerItem(int id) {
		String hql = "delete from PlayerItemShop t where t.id = ?0";
		delete(hql, id);
	}
}
