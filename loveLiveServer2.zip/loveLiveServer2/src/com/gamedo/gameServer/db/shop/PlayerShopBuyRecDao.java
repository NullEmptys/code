//package com.gamedo.gameServer.db.shop;
//
//import org.springframework.stereotype.Repository;
//
//import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
//import com.gamedo.gameServer.entity.shop.PlayerShopBuyRec;
//
//@Repository
//public class PlayerShopBuyRecDao extends PlayerGenericHibernateDAO<PlayerShopBuyRec, Integer>{
//	
//	public PlayerShopBuyRec loadPlayerSopBuyRec(int playerId) {
//		
//		String hql = "from PlayerShopBuyRec t where t.playerId = ?0";
//		return (PlayerShopBuyRec) uniqueResult(hql, playerId);
//	}
//	
//}
