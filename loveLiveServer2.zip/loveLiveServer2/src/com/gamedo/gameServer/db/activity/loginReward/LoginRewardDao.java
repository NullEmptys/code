package com.gamedo.gameServer.db.activity.loginReward;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.activity.loginReward.LoginReward;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class LoginRewardDao extends DataGenericHibernateDAO<LoginReward, Integer> {

	public List<LoginReward> loadLoginRewards(int activityId) {
		String hql = "from LoginReward t where t.activityId = ?0";
		return list(hql, activityId);
	}
}
