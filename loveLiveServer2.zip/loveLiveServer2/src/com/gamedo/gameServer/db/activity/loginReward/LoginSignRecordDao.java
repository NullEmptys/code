package com.gamedo.gameServer.db.activity.loginReward;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.activity.loginReward.LoginSignRecord;

/**
 * 
 * @author libm
 *
 */
@Repository
public class LoginSignRecordDao extends PlayerGenericHibernateDAO<LoginSignRecord, Integer> {

	
	public LoginSignRecord loadPlayerLoginSignRecord(int playerId,int activityId) {
	
		String hql = "from LoginSignRecord t where t.playerId = ?0 and t.activityId = ?1";
		return (LoginSignRecord) uniqueResult(hql, playerId,activityId);
	}
}
