package com.gamedo.gameServer.db.player;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.player.Player;

/**
 * 
 * @author libm
 *
 */
@Repository
public class PlayerDao extends PlayerGenericHibernateDAO<Player, Integer> {

	/**
	 * 根据账号名称获取指定角色
	 * 
	 * @param accountName
	 * @return
	 */
	public Player getPlayerByAccountName(String accountName, String channelId) {
		return (Player) uniqueResult("from Player p where p.userName = ?0 and channelId = ?1", accountName, channelId);
	}

	public Player findPlayer(String name) {
		Player p = null;
		try {
			p = (Player) uniqueResult("from Player p where p.name=?0", name);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("name=" + name);
			throw new IllegalArgumentException(e);
		}

		return p;
	}

	public Player findPlayerById(int playerId) {
		return (Player) uniqueResult("from Player p where p.id=?0", playerId);
	}

	public List<Player> loadPlayersByAchieveValue(int size) {
		String hql = "from Player p order by p.achieveValue desc";
		return limitList(hql, 0, size, null);
	}

	public List<Player> findAllByChannel(String channelId) {
		String hql = "from Player p where p.channelId=?0";
		return list(hql, channelId);
	}

	public List<Player> findAllByName(String name) {
		String hql = "from Player p where p.name like '%" + name + "%'";
		return list(hql);
	}

	public List<Player> findAllById(String id) {
		String hql = "from Player p where p.id like '%" + id + "%'";
		return list(hql);
	}
	
	public List<Player> findByGirlId(int girlId){
		String hql = "from Player p where p.girlId=?0";
		return list(hql, girlId);
	}

}
