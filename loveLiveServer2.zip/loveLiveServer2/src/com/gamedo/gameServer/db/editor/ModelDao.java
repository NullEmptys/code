package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.girl.Model;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class ModelDao extends DataGenericHibernateDAO<Model, Integer> {

	public List<Model> loadModels() {
		return findAll();
	}

	public Model findById(int girlId) {
		String hql = "from Model t where t.girlId = ?0";
		try {
			return (Model) uniqueResult(hql, girlId);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("girlId=" + girlId);
			throw new IllegalArgumentException(e);
		}
	}
}
