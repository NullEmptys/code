package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.gamedo.gameServer.data.AppOpenConfig;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;
/**
 * 系统开关
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class AppOpenConfigDao extends DataGenericHibernateDAO<AppOpenConfig, Integer> {
	
	public List<AppOpenConfig> loadAppOpenConfig() {
		return findAll();
	}
}
