package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.quest.Quest;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class QuestDao extends DataGenericHibernateDAO<Quest, Integer>{

	/**
	 * 获取指定章节下的任务
	 * @param chapterId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Quest> loadQuestByChapterId(int chapterId) {
		String hql = "select q from Quest q where q.chapterId = ?0";
		return list(hql, chapterId);
	}
}
