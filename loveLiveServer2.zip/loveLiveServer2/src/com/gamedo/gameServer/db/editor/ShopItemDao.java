package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.shop.ShopItem;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

@Repository
public class ShopItemDao extends DataGenericHibernateDAO<ShopItem, Integer>{
	
	@SuppressWarnings("unchecked")
	public List<ShopItem> loadShopItemsByShopId(int shopId){
		String hql = "from ShopItem t where t.shopId = ?0 ";
		return (List<ShopItem>) list(hql,shopId);
	}
	
}
