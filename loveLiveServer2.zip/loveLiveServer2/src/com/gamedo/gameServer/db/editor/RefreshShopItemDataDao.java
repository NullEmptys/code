package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.shop.RefreshShopItemData;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class RefreshShopItemDataDao extends DataGenericHibernateDAO<RefreshShopItemData, Integer> {

	public List<RefreshShopItemData> loadRefreshShopItemDatas() {
		return findAll();
	}

	public RefreshShopItemData loadMaxRefreshShopItemData() {
		String hql = "from RefreshShopItemData t where t.refreshCount = (select max(refreshCount) from RefreshShopItemData)";
		return (RefreshShopItemData) uniqueResult(hql, null);
	}
}
