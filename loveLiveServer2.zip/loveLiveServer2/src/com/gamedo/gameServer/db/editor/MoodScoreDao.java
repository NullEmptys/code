package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.girl.MoodScore;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class MoodScoreDao extends DataGenericHibernateDAO<MoodScore, Integer> {

	public List<MoodScore> loadMoodScores() {
		return findAll();
	}
}
