package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.mothsign.MonthSignData;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;
/**
 * 策划月签数据
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class MonthSignDataDao extends DataGenericHibernateDAO<MonthSignData, Integer>{
	
	public List<MonthSignData> loadServerConfigInfos() {
		return findAll();
	}
	
}
