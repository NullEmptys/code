package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.girl.Girl;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class GirlDao extends DataGenericHibernateDAO<Girl, Integer> {

	public List<Girl> loadGirls() {
		return findAll();
	}

	public Girl loadGirlById(int girlId) {
		String hql = "from Girl p where p.id = ?0";
		return (Girl) uniqueResult(hql, girlId);
	}
}
