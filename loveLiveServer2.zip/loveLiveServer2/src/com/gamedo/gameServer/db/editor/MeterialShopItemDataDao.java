package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.shop.MeterialShopItemData;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class MeterialShopItemDataDao extends DataGenericHibernateDAO<MeterialShopItemData, Integer> {

	public List<MeterialShopItemData> loadMeterialShopItemDatas() {
		return findAll();
	}
}
