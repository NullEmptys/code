package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.channel.Channel;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class ChannelDao extends DataGenericHibernateDAO<Channel, Integer> {

	public List<Channel> loadChannels() {
		return findAll();
	}

	public Channel findById(String channelId) {
		String hql = "from Channel t where t.channelId = ?0";
		try {
			return (Channel) uniqueResult(hql, channelId);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("channelId=" + channelId);
			throw new IllegalArgumentException(e);
		}
	}
}
