package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.XieZhenGroupReward;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class XieZhenGroupRewardDao extends DataGenericHibernateDAO<XieZhenGroupReward, Integer> {

	public List<XieZhenGroupReward> loadXieZhenGroupRewards() {
		return findAll();
	}
}
