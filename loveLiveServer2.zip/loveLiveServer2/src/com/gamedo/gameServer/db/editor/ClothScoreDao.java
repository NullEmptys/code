package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.equipment.ClothScore;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class ClothScoreDao extends DataGenericHibernateDAO<ClothScore, Integer> {

	public List<ClothScore> loadClothPartScores() {
		return findAll();
	}
}
