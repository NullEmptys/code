package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.scene.Scene;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class SceneDao extends DataGenericHibernateDAO<Scene, Integer> {

	public List<Scene> loadScenes() {
		return findAll();
	}
	
	@SuppressWarnings("unchecked")
	public List<Scene> loadScenesByCategory(int category) {
		String hql = "from Scene t where t.category = ?0";
		return list(hql, category);
	}
}
