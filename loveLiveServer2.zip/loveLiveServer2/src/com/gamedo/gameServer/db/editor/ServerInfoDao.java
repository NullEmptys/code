package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.ServerInfoConfig;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;
/**
 * 策划数据
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class ServerInfoDao extends DataGenericHibernateDAO<ServerInfoConfig, Integer>{
	
	public List<ServerInfoConfig> loadServerConfigInfos() {
		return findAll();
	}
	
	public ServerInfoConfig loadServerInfoConfig(int serverId) {
		String hql = "from ServerInfoConfig t where serverId = ?0";
		return (ServerInfoConfig) uniqueResult(hql, serverId);
	}
	
	public ServerInfoConfig loadServerInfoConfigById(int id) {
		String hql = "from ServerInfoConfig t where id = ?0";
		return (ServerInfoConfig) uniqueResult(hql, id);
	}
}
