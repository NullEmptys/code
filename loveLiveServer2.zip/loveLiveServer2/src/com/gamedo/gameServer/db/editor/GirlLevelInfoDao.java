package com.gamedo.gameServer.db.editor;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.gamedo.gameServer.data.girl.GirlLevelInfo;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;


@SuppressWarnings("unchecked")
@Repository
public class GirlLevelInfoDao extends DataGenericHibernateDAO<GirlLevelInfo, Integer> {
	public List<GirlLevelInfo> loadGirlInfoById() {
		String hql = "from GirlLevelInfo";
		return list(hql);
	}
}
