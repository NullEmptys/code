package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.dailyMission.DailyMissionDefine;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 每日任务配置表
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class DailyMissionDao extends DataGenericHibernateDAO<DailyMissionDefine, Integer>{
	
	public List<DailyMissionDefine> loadDailMissionInfos() {
		return findAll();
	}
}
