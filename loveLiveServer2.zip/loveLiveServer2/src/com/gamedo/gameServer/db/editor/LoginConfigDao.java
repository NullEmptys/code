package com.gamedo.gameServer.db.editor;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.LoginConfig;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class LoginConfigDao extends DataGenericHibernateDAO<LoginConfig, Integer> {

	public LoginConfig loadLoginConfig() {
		String hql = "from LoginConfig t where t.id = ?0";
		return (LoginConfig) uniqueResult(hql, 1);
	}
}
