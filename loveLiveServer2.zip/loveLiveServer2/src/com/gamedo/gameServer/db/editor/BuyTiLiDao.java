package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.BuyConfig;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;
/**
 * 购买体力dao
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class BuyTiLiDao extends DataGenericHibernateDAO<BuyConfig, Integer> {
	
	public List<BuyConfig> loadTiLiAndGoldConfig() {
		return findAll();
	}
}
