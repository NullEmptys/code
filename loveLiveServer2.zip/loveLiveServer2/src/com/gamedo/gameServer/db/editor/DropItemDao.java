package com.gamedo.gameServer.db.editor;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.core.fall.DropItem;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 
 * @author libm
 *
 */
@Repository
public class DropItemDao extends DataGenericHibernateDAO<DropItem, Integer> {

	@SuppressWarnings("unchecked")
	public List<DropItem> loadDropItems(int subGroupId,int dropGroupId) {
		String hql = "from DropItem d where d.subGroupId = ?0 and d.dropGroupId = ?1";
		return list(hql, subGroupId,dropGroupId);
	}
}
