package com.gamedo.gameServer.db.editor;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.dailyMission.DailyMissionActiveReward;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;

/**
 * 每日活跃度奖励配置表
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class DailyActiveRewardDao extends DataGenericHibernateDAO<DailyMissionActiveReward, Integer>{
	
	public List<DailyMissionActiveReward> loadDailyMissionActiveRewardInfos() {
		return findAll();
	}
}
