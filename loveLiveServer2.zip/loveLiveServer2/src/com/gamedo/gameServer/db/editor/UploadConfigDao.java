package com.gamedo.gameServer.db.editor;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.data.UploadConfig;
import com.gamedo.gameServer.db.DataGenericHibernateDAO;


/**
 * 
 * @author libm
 *
 */
@Repository
public class UploadConfigDao extends DataGenericHibernateDAO<UploadConfig, Integer> {

	public UploadConfig loadUploadConfig() {
		String hql = "from UploadConfig t where t.id = ?0";
		return (UploadConfig) uniqueResult(hql, 1);
	}
}
