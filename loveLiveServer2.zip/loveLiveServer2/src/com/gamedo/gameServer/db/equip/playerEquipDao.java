package com.gamedo.gameServer.db.equip;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.equip.PlayerEquip;

/**
 * @author IPOC-HUANGPING
 *
 */
public class playerEquipDao extends PlayerGenericHibernateDAO<PlayerEquip, Integer> {
	
}
