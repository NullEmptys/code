package com.gamedo.gameServer.db.dailyMission;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.dailymission.PlayerDailyMission;
/**
 * 玩家每日任务Dao
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class PlayerDailyMissionDao extends PlayerGenericHibernateDAO<PlayerDailyMission, Integer>{
	
	@SuppressWarnings("unchecked")
	public List<PlayerDailyMission> loadPlayerDailMission(int playerId,int missionCategoryId){
		String hql = "from PlayerDailyMission p where p.playerId = ?0 and p.missionCategoryId = ?1";
		return list(hql, playerId,missionCategoryId);
	}
	
	public void deletPlayerDailyMission(int playerId,int missionCategoryId,int missionDefineId){
		String hql = "delete from PlayerDailyMission p where p.playerId = ?0 and p.missionCategoryId = ?1 and p.missionDefineId = ?2";
		delete(hql, playerId,missionCategoryId,missionDefineId);
	}
	
}
