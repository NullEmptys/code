package com.gamedo.gameServer.db.mothsign;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.PlayerGenericHibernateDAO;
import com.gamedo.gameServer.entity.monthsign.PlayerMonthSignRec;
/**
 * 玩家月签记录
 * @author IPOC-HUANGPING
 *
 */
@Repository
public class PlayerMonthSignDao extends PlayerGenericHibernateDAO<PlayerMonthSignRec, Integer>{
	
	public PlayerMonthSignRec loadPlayerMonthSignRecord(int playerId) {
		
		String hql = "from PlayerMonthSignRec t where t.playerId = ?0";
		return (PlayerMonthSignRec) uniqueResult(hql, playerId);
	}
	
}
