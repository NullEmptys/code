package com.gamedo.gameServer.db.log;

import org.springframework.stereotype.Repository;

import com.gamedo.gameServer.db.LogGenericHibernateDAO;
import com.gamedo.gameServer.entity.log.LoginRecord;

/**
 * 角色登录日志
 * @author libm
 *
 */
@Repository
public class LoginRecordDao extends LogGenericHibernateDAO<LoginRecord, Integer> {

	
}
