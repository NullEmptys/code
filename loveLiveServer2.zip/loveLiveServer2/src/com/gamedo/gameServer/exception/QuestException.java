package com.gamedo.gameServer.exception;

/**
 * 
 * @author libm
 *
 */
public class QuestException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7608038029767582070L;

	public QuestException(String msg){
		super(msg);
	}
}
