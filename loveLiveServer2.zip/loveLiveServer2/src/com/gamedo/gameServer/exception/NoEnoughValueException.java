package com.gamedo.gameServer.exception;

/**
 * 
 * @author libm
 *
 */
public class NoEnoughValueException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7572361438146474471L;

	public NoEnoughValueException() {
	}

	public NoEnoughValueException(String message) {
		super(message);
	}

	public NoEnoughValueException(Throwable cause) {
		super(cause);
	}

	public NoEnoughValueException(String message, Throwable cause) {
		super(message, cause);
	}
}
