package com.gamedo.gameServer.exception;

/**
 * 
 * @author libm
 *
 */
public class ItemUseException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7597767942869273473L;

	public ItemUseException(String message) {
		super(message);
	}
}
