package com.gamedo.gameServer.exception;

public class GirlSignedException extends Exception {
	private static final long serialVersionUID = -6124668620651051233L;

	public GirlSignedException(String message) {
		super(message);
	}

	public GirlSignedException(Throwable cause) {
		super(cause);
	}

	public GirlSignedException(String message, Throwable cause) {
		super(message, cause);
	}
}
