package com.gamedo.gameServer.exception;

/**
 * 
 * @author libm
 *
 */
public class NoEnoughSpaceException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -546288563492825644L;

	public NoEnoughSpaceException(){
		super();
	}
	
	public NoEnoughSpaceException(String msg){
		super(msg);
	}
}
