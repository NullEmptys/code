package com.gamedo.gameServer.data.activity.loginReward;

/**
 * 
 * @author libm
 *
 */
public class LoginReward {

	private int id;
	/**活动id*/
	private int activityId;
	/**累计签到天数*/
	private int signCounts;
	/**奖励类型*/
	private int rewardType;
	/**奖励id*/
	private int rewardId;
	/**奖励数量*/
	private int rewardCounts;
	/**时效类型*/
	private int cdTimeType;
	/**背景图片*/
	private String backgroundId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRewardType() {
		return rewardType;
	}

	public void setRewardType(int rewardType) {
		this.rewardType = rewardType;
	}

	public int getRewardId() {
		return rewardId;
	}

	public void setRewardId(int rewardId) {
		this.rewardId = rewardId;
	}

	public int getRewardCounts() {
		return rewardCounts;
	}

	public void setRewardCounts(int rewardCounts) {
		this.rewardCounts = rewardCounts;
	}
	
	public int getSignCounts() {
		return signCounts;
	}

	public void setSignCounts(int signCounts) {
		this.signCounts = signCounts;
	}

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}

	public int getCdTimeType() {
		return cdTimeType;
	}

	public void setCdTimeType(int cdTimeType) {
		this.cdTimeType = cdTimeType;
	}

	public String getBackgroundId() {
		return backgroundId;
	}

	public void setBackgroundId(String backgroundId) {
		this.backgroundId = backgroundId;
	}

}
