package com.gamedo.gameServer.data.activity.loginReward;

/**
 * 
 * @author libm
 *
 */
public class LoginRewardConfig {

	private int id;
	
	private int activityId;
	/**
	 * 7日登录奖励活动背景图片id
	 */
	private int backGroundId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}

	public int getBackGroundId() {
		return backGroundId;
	}

	public void setBackGroundId(int backGroundId) {
		this.backGroundId = backGroundId;
	}
	
}
