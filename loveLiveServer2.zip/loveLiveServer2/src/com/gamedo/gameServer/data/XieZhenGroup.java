package com.gamedo.gameServer.data;

public class XieZhenGroup {

	private int id;

	private int girlId;
	
	private int groupId;
	
	private int xieZhenId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public int getXieZhenId() {
		return xieZhenId;
	}

	public void setXieZhenId(int xieZhenId) {
		this.xieZhenId = xieZhenId;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

}
