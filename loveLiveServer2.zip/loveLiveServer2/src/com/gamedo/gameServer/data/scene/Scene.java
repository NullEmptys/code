package com.gamedo.gameServer.data.scene;

/**
 * 场景
 * @author libm
 *
 */
public class Scene {

	private int id;
	/**场景id*/
	private int sceneId;
	/**场景名称*/
	private String title;
	/**场景文件名*/
	private String sceneName;
	/**场景图标*/
	private String iconId;
	/**场景模式  1：任务模式   2：自由拍摄模式*/
	private int category;
	/**消耗货币类型*/
	private int currencyType;
	/**消耗货币数*/
	private int currencuCounts;
	/**是否默认选择  0：否 1：是*/
	private int isDefault;
	/**是否免费*/
	private int isFree;
	/**vip是否免费*/
	private int vipFree;
	/**昼夜*/
	private int attribute;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSceneName() {
		return sceneName;
	}
	public void setSceneName(String sceneName) {
		this.sceneName = sceneName;
	}
	public String getIconId() {
		return iconId;
	}
	public void setIconId(String iconId) {
		this.iconId = iconId;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public int getSceneId() {
		return sceneId;
	}
	public void setSceneId(int sceneId) {
		this.sceneId = sceneId;
	}
	public int getCurrencyType() {
		return currencyType;
	}
	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}
	public int getCurrencuCounts() {
		return currencuCounts;
	}
	public void setCurrencuCounts(int currencuCounts) {
		this.currencuCounts = currencuCounts;
	}
	public int getIsDefault() {
		return isDefault;
	}
	public void setIsDefault(int isDefault) {
		this.isDefault = isDefault;
	}
	public int getIsFree() {
		return isFree;
	}
	public void setIsFree(int isFree) {
		this.isFree = isFree;
	}
	public int getVipFree() {
		return vipFree;
	}
	public void setVipFree(int vipFree) {
		this.vipFree = vipFree;
	}
	public int getAttribute() {
		return attribute;
	}
	public void setAttribute(int attribute) {
		this.attribute = attribute;
	}
	
}
