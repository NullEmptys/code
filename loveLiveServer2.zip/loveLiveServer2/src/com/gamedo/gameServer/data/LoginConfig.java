package com.gamedo.gameServer.data;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class LoginConfig {

	public static String WILL_OPEN = "服务器维护中，下一次开放时间是:";
	public static String MAINTANCE = "服务器维护中，开放时间请关注官网。";
	public static String TIME_STYLE = "MM月dd日HH点mm分";
	
	private int id;
	/**
	 * ip白名单
	 */
	private String safetyIpStr;
	/**
	 * 服务器开放时间
	 */
	private Date openTime;
	/**
	 * 服务器停服时间
	 */
	private Date closeTime;
	
	private String version;
	
	/**后援团服务地址*/
	private String sheJiaoServerUrl;
	
	/** 安全ip集 **/
	private static Set<String> safetyIpSet = new HashSet<String>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSafetyIpStr() {
		return safetyIpStr;
	}

	public void setSafetyIpStr(String safetyIpStr) {
		this.safetyIpStr = safetyIpStr;
		if (safetyIpStr != null && safetyIpStr.length() > 0) {
			Set<String> ipSet = new HashSet<String>();
			String[] strArr = safetyIpStr.split(";");
			for (String str : strArr) {
				if (str == null || str.isEmpty())
					continue;
				ipSet.add(str);
			}
		}
	}

	public Date getOpenTime() {
		return openTime;
	}

	public void setOpenTime(Date openTime) {
		this.openTime = openTime;
	}

	public Date getCloseTime() {
		return closeTime;
	}

	public void setCloseTime(Date closeTime) {
		this.closeTime = closeTime;
	}
	
	/** 是否是安全ip **/
	public boolean isSafetyIp(String remoteIp) {
		if (remoteIp == null || remoteIp.isEmpty())
			return false;

		if (safetyIpSet.contains(remoteIp))
			return true;

		/**
		 * 私有IP： A类 10.0.0.0-10.255.255.255 B类 172.16.0.0-172.31.255.255 C类
		 * 192.168.0.0-192.168.255.255 环回地址 127.0.0.1
		 */
		if (remoteIp.equals("127.0.0.1") || remoteIp.equals("0:0:0:0:0:0:0:1") || remoteIp.startsWith("192.168."))
			return true;
		else if (remoteIp.startsWith("172.")) {
			String[] ipArr = remoteIp.split("\\.");
			if (ipArr.length == 4) {
				int secondField = Integer.parseInt(ipArr[1]);
				if (secondField >= 16 && secondField <= 31)
					return true;
			}
		}

		return false;
	}

	/**
	 * 当前时间此游戏区是否开放
	 * 
	 * @return
	 */
	public boolean isOpenNow() {
		Date nowTime = new Date();
		if (openTime != null) {
			if (closeTime != null) {
				if (openTime.equals(closeTime))
					return true;
				else if (openTime.before(closeTime)) {
					if (nowTime.compareTo(openTime) >= 0 && nowTime.before(closeTime))
						return true;
					else
						return false;
				} else {
					if (nowTime.compareTo(closeTime) >= 0 && nowTime.before(openTime))
						return false;
					else
						return true;
				}
			} else {
				if (nowTime.before(openTime))
					return false;
				else
					return true;
			}
		} else {
			if (closeTime != null) {
				if (nowTime.before(closeTime))
					return true;
				else
					return false;
			} else {
				return true;
			}
		}
	}
	
	/***
	 * 获取下一个开放时间
	 * 
	 * @return
	 */
	public Date getFutureOpenTime() {
		Date nowTime = new Date();
		if (openTime != null && nowTime.before(openTime)) {
			return openTime;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
		}

		return null;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getSheJiaoServerUrl() {
		return sheJiaoServerUrl;
	}

	public void setSheJiaoServerUrl(String sheJiaoServerUrl) {
		this.sheJiaoServerUrl = sheJiaoServerUrl;
	}

}
