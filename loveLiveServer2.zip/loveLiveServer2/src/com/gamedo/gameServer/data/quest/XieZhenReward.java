package com.gamedo.gameServer.data.quest;

/**
 * 
 * @author libm
 *
 */
public class XieZhenReward {

	private int id;
	
	/**
	 * 1、普通
	 * 2、稀有
	 * 3、私密
	 */
	private int type;
	/**
	 * 掉落组id
	 */
	private int dropGroupId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getDropGroupId() {
		return dropGroupId;
	}

	public void setDropGroupId(int dropGroupId) {
		this.dropGroupId = dropGroupId;
	}
	
}
