package com.gamedo.gameServer.data.quest;

/**
 * 任务奖励
 * @author libm
 *
 */
public class QuestReward {

	private int id;
	
	/**任务ID*/
	private int questId;
	/**
	 * 奖励条件类型
	 * 1、首次完美过关奖励
	 * 2、首次通关奖励
	 * 3、通关概率掉落
	 */
	private int confitionType;
	
	/**
	 * 奖品类型
	 * 1、货币
	 * 2、物品
	 */
	private int rewardType;
	
	private String title;
	
	private int rewardId;
	/**
	 * 奖励数量
	 */
	private int rewardCounts;
	
	/**
	 * 概率
	 */
	private int ratio;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getQuestId() {
		return questId;
	}

	public void setQuestId(int questId) {
		this.questId = questId;
	}

	public int getRewardType() {
		return rewardType;
	}

	public void setRewardType(int rewardType) {
		this.rewardType = rewardType;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getRewardCounts() {
		return rewardCounts;
	}

	public void setRewardCounts(int rewardCounts) {
		this.rewardCounts = rewardCounts;
	}

	public int getRatio() {
		return ratio;
	}

	public void setRatio(int ratio) {
		this.ratio = ratio;
	}

	public int getConfitionType() {
		return confitionType;
	}

	public void setConfitionType(int confitionType) {
		this.confitionType = confitionType;
	}

	public int getRewardId() {
		return rewardId;
	}

	public void setRewardId(int rewardId) {
		this.rewardId = rewardId;
	}
	
}
