package com.gamedo.gameServer.data.quest;

/**
 * 任务评分
 * @author libm
 *
 */
public class QuestScore {

	private int id;
	/**
	 * 任务id
	 */
	private int questId;
	/**
	 * 评级
	 */
	private int scoreLevel;
	/**
	 * 该评级最低分数
	 */
	private int minScore;
	/**
	 * 该评级最高分数
	 */
	private int maxScore;
	
	/**
	 * 关卡过关基础奖励加成比例
	 */
	private double baseRewardAddRatio;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getQuestId() {
		return questId;
	}

	public void setQuestId(int questId) {
		this.questId = questId;
	}

	public int getScoreLevel() {
		return scoreLevel;
	}

	public void setScoreLevel(int scoreLevel) {
		this.scoreLevel = scoreLevel;
	}

	public int getMinScore() {
		return minScore;
	}

	public void setMinScore(int minScore) {
		this.minScore = minScore;
	}

	public int getMaxScore() {
		return maxScore;
	}

	public void setMaxScore(int maxScore) {
		this.maxScore = maxScore;
	}

	public double getBaseRewardAddRatio() {
		return baseRewardAddRatio;
	}

	public void setBaseRewardAddRatio(double baseRewardAddRatio) {
		this.baseRewardAddRatio = baseRewardAddRatio;
	}

}
