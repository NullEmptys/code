package com.gamedo.gameServer.data.quest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 任务
 * @author libm
 *
 */
public class Quest {

	/**
	 * 任务id
	 */
	private int id;
	
	/**
	 * 章节id
	 */
	private int chapterId;
	/**
	 * 任务类型
	 * 1、剧情关卡
	 * 2、普通关卡
	 * 3、强制关卡
	 */
	private int type;
	
	/**
	 * 任务名称
	 */
	private String name;
	/**
	 * 任务描述
	 */
	private String description;
    /**
     * 开启关卡需玩家等级。
     */
	private int playerLevel;
	/**
	 * 消耗体力数 
	 */
	private int consumeTili;
	/**
	 * 下一领取任务
	 */
	private int nextQuestId;
	
	/**
	 * 指定模特id
	 */
	private int girlId;
	
	/**
	 * 指定服装id
	 * clothId;clothId
	 */
	private String limitClothIdStr;
	
	private List<Integer> limitClothIds;
	
	/**
	 * 限制道具id
	 * itemId=1;itemId=2
	 */
	private String limitItemIdStr;
	
	private Map<Integer,Integer> limitItemIds;
	
	/**
	 * 服装风格条件及权重
	 * styleId=weight;styleId=weight
	 */
	private String clothStyleWeightStr;
	
	private Map<Integer,Double> clothStyleWeights;
	
	/**
	 * 提示信息显示服装风格需求
	 */
	private String displayClothStyleStr;
	
	/**
	 * 情绪条件及其权重
	 * moodTypeStr=weight;moodTypeStr=weight
	 */
	private String moodTypeWeightStr;
	
	private Map<Integer,Double> moodTypeWeights;
	
	/**
	 * 提示信息显示情绪需求
	 */
	private String displayMoodTypeStr;
	
	/**
	 * 服装标签条件
	 * clothLaberId;clothLaberId
	 */
	private String clothLaberStr;
	
	private List<Integer> clothLabers;
	
	/**
	 * 完成任务获得奖励货币类型
	 */
	private int rewardCurrencyType;
	/**
	 * 完成任务获得基础货币数
	 */
	private int rewardBaseCurrencyCounts;
	/**
	 * 完成任务奖励任务经验值数
	 */
	private int exp;
	
	/**
	 * 情节回话id
	 */
	private int dialogId;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getConsumeTili() {
		return consumeTili;
	}

	public void setConsumeTili(int consumeTili) {
		this.consumeTili = consumeTili;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getNextQuestId() {
		return nextQuestId;
	}

	public void setNextQuestId(int nextQuestId) {
		this.nextQuestId = nextQuestId;
	}

	public int getChapterId() {
		return chapterId;
	}

	public void setChapterId(int chapterId) {
		this.chapterId = chapterId;
	}

	public int getPlayerLevel() {
		return playerLevel;
	}

	public void setPlayerLevel(int playerLevel) {
		this.playerLevel = playerLevel;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public String getLimitClothIdStr() {
		return limitClothIdStr;
	}

	public void setLimitClothIdStr(String limitClothIdStr) {
		this.limitClothIdStr = limitClothIdStr;
		if(limitClothIdStr != null && limitClothIdStr.length() > 0) {
			String[] strs = limitClothIdStr.split(";");
			if(strs != null && strs.length > 0) {
				limitClothIds = new ArrayList<>();
				for(String clothId : strs) {
					if(clothId != null) {
						limitClothIds.add(Integer.parseInt(clothId));
					}
				}
			}
		}
	}

	public List<Integer> getLimitClothIds() {
		return limitClothIds;
	}

	public void setLimitClothIds(List<Integer> limitClothIds) {
		this.limitClothIds = limitClothIds;
	}

	public Map<Integer, Integer> getLimitItemIds() {
		return limitItemIds;
	}

	public void setLimitItemIds(Map<Integer, Integer> limitItemIds) {
		this.limitItemIds = limitItemIds;
	}

	public String getClothStyleWeightStr() {
		return clothStyleWeightStr;
	}

	public void setClothStyleWeightStr(String clothStyleWeightStr) {
		this.clothStyleWeightStr = clothStyleWeightStr;
		if(clothStyleWeightStr != null) {
			String[] styleWeightStrs = clothStyleWeightStr.split(";");
			if(styleWeightStrs != null && styleWeightStrs.length > 0) {
				clothStyleWeights = new HashMap<>();
				for(String str : styleWeightStrs) {
					if(str != null) {
						String[] strs = str.split("=");
						if(strs != null && strs.length == 2) {
							clothStyleWeights.put(Integer.parseInt(strs[0]), Double.parseDouble(strs[1]));
						}
					}
				}
			}
		}
	}

	public Map<Integer, Double> getClothStyleWeights() {
		return clothStyleWeights;
	}

	public void setClothStyleWeights(Map<Integer, Double> clothStyleWeights) {
		this.clothStyleWeights = clothStyleWeights;
	}

	public String getDisplayClothStyleStr() {
		return displayClothStyleStr;
	}

	public void setDisplayClothStyleStr(String displayClothStyleStr) {
		this.displayClothStyleStr = displayClothStyleStr;
	}

	public String getMoodTypeWeightStr() {
		return moodTypeWeightStr;
	}

	public void setMoodTypeWeightStr(String moodTypeWeightStr) {
		this.moodTypeWeightStr = moodTypeWeightStr;
		if(moodTypeWeightStr != null) {
			String[] moodWeightStrs = moodTypeWeightStr.split(";");
			if(moodWeightStrs != null && moodWeightStrs.length > 0) {
				moodTypeWeights = new HashMap<>();
				for(String str : moodWeightStrs) {
					if(str != null) {
						String[] strs = str.split("=");
						if(strs != null && strs.length == 2) {
							moodTypeWeights.put(Integer.parseInt(strs[0]), Double.parseDouble(strs[1]));
						}
					}
				}
			}
		}
	}

	public Map<Integer, Double> getMoodTypeWeights() {
		return moodTypeWeights;
	}

	public void setMoodTypeWeights(Map<Integer, Double> moodTypeWeights) {
		this.moodTypeWeights = moodTypeWeights;
	}

	public String getDisplayMoodTypeStr() {
		return displayMoodTypeStr;
	}

	public void setDisplayMoodTypeStr(String displayMoodTypeStr) {
		this.displayMoodTypeStr = displayMoodTypeStr;
	}

	public String getClothLaberStr() {
		return clothLaberStr;
	}

	public void setClothLaberStr(String clothLaberStr) {
		this.clothLaberStr = clothLaberStr;
		if(clothLaberStr != null && clothLaberStr.length() > 0) {
			String[] strs = clothLaberStr.split(";");
			if(strs != null && strs.length > 0) {
				clothLabers = new ArrayList<>();
				for(String laber : strs) {
					if(laber != null) {
						clothLabers.add(Integer.parseInt(laber));
					}
				}
			}
		}
	}

	public List<Integer> getClothLabers() {
		return clothLabers;
	}

	public void setClothLabers(List<Integer> clothLabers) {
		this.clothLabers = clothLabers;
	}

	
	public String getLimitItemIdStr() {
		return limitItemIdStr;
	}

	public void setLimitItemIdStr(String limitItemIdStr) {
		this.limitItemIdStr = limitItemIdStr;
		if(limitItemIdStr != null) {
			limitItemIds = new HashMap<>();
			String[] strs = limitItemIdStr.split(";");
			if(strs != null && strs.length > 0) {
				for(String str : strs) {
					if(str != null) {
						String[] itemIds = str.split("=");
						if(itemIds != null && itemIds.length == 2) {
							limitItemIds.put(Integer.parseInt(itemIds[0]), Integer.parseInt(itemIds[1]));
						}
					}
				}
			}
		}
	}

	public int getRewardCurrencyType() {
		return rewardCurrencyType;
	}

	public void setRewardCurrencyType(int rewardCurrencyType) {
		this.rewardCurrencyType = rewardCurrencyType;
	}

	public int getRewardBaseCurrencyCounts() {
		return rewardBaseCurrencyCounts;
	}

	public void setRewardBaseCurrencyCounts(int rewardBaseCurrencyCounts) {
		this.rewardBaseCurrencyCounts = rewardBaseCurrencyCounts;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}

	public int getDialogId() {
		return dialogId;
	}

	public void setDialogId(int dialogId) {
		this.dialogId = dialogId;
	}
	
}

