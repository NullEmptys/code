package com.gamedo.gameServer.data;

public class UploadConfig {

	private int id;
	/**头像图片存储目录*/
	private String avatarDir;
	/**动态图片存储目录*/
	private String dynamicImageDir;
	/**语音文件存储目录*/
	private String voiceDir;
	/**获取头像url*/
	private String avatarUrl;
	/**动态图片URL*/
	private String dynamicImageUrl;
	/**语音文件URL*/
	private String voiceUrl;
	/**游戏服url*/
	private String gameServerUrl;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAvatarDir() {
		return avatarDir;
	}

	public void setAvatarDir(String avatarDir) {
		this.avatarDir = avatarDir;
	}

	public String getDynamicImageDir() {
		return dynamicImageDir;
	}

	public void setDynamicImageDir(String dynamicImageDir) {
		this.dynamicImageDir = dynamicImageDir;
	}

	public String getVoiceDir() {
		return voiceDir;
	}

	public void setVoiceDir(String voiceDir) {
		this.voiceDir = voiceDir;
	}

	public String getAvatarUrl() {
		return avatarUrl;
	}

	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}

	public String getDynamicImageUrl() {
		return dynamicImageUrl;
	}

	public void setDynamicImageUrl(String dynamicImageUrl) {
		this.dynamicImageUrl = dynamicImageUrl;
	}

	public String getVoiceUrl() {
		return voiceUrl;
	}

	public void setVoiceUrl(String voiceUrl) {
		this.voiceUrl = voiceUrl;
	}

	public String getGameServerUrl() {
		return gameServerUrl;
	}

	public void setGameServerUrl(String gameServerUrl) {
		this.gameServerUrl = gameServerUrl;
	}
	
}
