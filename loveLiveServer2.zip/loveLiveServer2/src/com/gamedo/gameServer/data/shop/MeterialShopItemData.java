package com.gamedo.gameServer.data.shop;

/**
 * 道具商店各商品等级刷新权重
 * @author libm
 *
 */
public class MeterialShopItemData {

	private int id;
	
	public int itemLevel;
	
	public int weight;
	
	public int startWeight;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getItemLevel() {
		return itemLevel;
	}

	public void setItemLevel(int itemLevel) {
		this.itemLevel = itemLevel;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}
	
}
