package com.gamedo.gameServer.data.shop;

import java.io.Serializable;

/**
 * 商店item配置表
 * 
 * @author IPOC-HUANGPING
 *
 */
public class ShopItem implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private int shopId;//商城id 1、服装商城 2、道具商城
	private int type;// 物品类型
	private int itemId;// 服装id
	private int level;// 角色对应的等级或者物品对应等级，根据商城而定
	private int consumeType;// 消耗的物品类型
	private int consumeNum;// 消耗的数量
	private int isDefault;// 是否默认 1、是  0、否
	public int weight;//权重
	public int startWeight;
	public int canBuyCount;//最大可购买个数

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getConsumeType() {
		return consumeType;
	}

	public void setConsumeType(int consumeType) {
		this.consumeType = consumeType;
	}

	public int getConsumeNum() {
		return consumeNum;
	}

	public void setConsumeNum(int consumeNum) {
		this.consumeNum = consumeNum;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public int getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(int isDefault) {
		this.isDefault = isDefault;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getStartWeight() {
		return startWeight;
	}

	public void setStartWeight(int startWeight) {
		this.startWeight = startWeight;
	}

	public int getCanBuyCount() {
		return canBuyCount;
	}

	public void setCanBuyCount(int canBuyCount) {
		this.canBuyCount = canBuyCount;
	}

}
