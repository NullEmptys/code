package com.gamedo.gameServer.data.shop;

/**
 * 
 * @author libm
 *
 */
public class RefreshShopItemData {

	private int id;
	/**刷新次数*/
	private int refreshCount;
	/**刷新商城需消耗货币类型*/
	private int currencyType;
	/**刷新商城需消耗货币数量*/
	private int currencyCounts;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRefreshCount() {
		return refreshCount;
	}

	public void setRefreshCount(int refreshCount) {
		this.refreshCount = refreshCount;
	}

	public int getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(int currencyType) {
		this.currencyType = currencyType;
	}

	public int getCurrencyCounts() {
		return currencyCounts;
	}

	public void setCurrencyCounts(int currencyCounts) {
		this.currencyCounts = currencyCounts;
	}
	
}
