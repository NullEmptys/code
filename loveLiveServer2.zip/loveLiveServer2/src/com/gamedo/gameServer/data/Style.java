package com.gamedo.gameServer.data;

/**
 * 风格
 * @author libm
 *
 */
public class Style {

	private int id;
	
	/**风格名称*/
	private String styleName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStyleName() {
		return styleName;
	}

	public void setStyleName(String styleName) {
		this.styleName = styleName;
	}
	
}
