package com.gamedo.gameServer.data.equipment;

/**
 * 服装风格属性
 * @author libm
 *
 */
public class ItemAttribute {

	private int id;
	/**
	 * 物品id
	 */
	private int itemId;
	/**
	 * 服装风格id
	 */
	private int type;
	/**
	 * 评级分数id
	 */
	private int scoreId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getScoreId() {
		return scoreId;
	}

	public void setScoreId(int scoreId) {
		this.scoreId = scoreId;
	}

}
