package com.gamedo.gameServer.data.equipment;

import com.gamedo.gameServer.data.item.Item;

/**
 * 服装
 * @author libm
 *
 */
public class Equip extends Item{

	/**由于服装时效在寄送给模特后是累积的  映射id*/
	private int mapperEquipId;

	public int getMapperEquipId() {
		return mapperEquipId;
	}

	public void setMapperEquipId(int mapperEquipId) {
		this.mapperEquipId = mapperEquipId;
	}
	
}
