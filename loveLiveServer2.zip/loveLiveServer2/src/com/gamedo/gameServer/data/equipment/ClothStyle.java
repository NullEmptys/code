package com.gamedo.gameServer.data.equipment;

/**
 * 服装风格
 * @author libm
 *
 */
public class ClothStyle {

	private int id;
	
	/**
	 * 风格id
	 */
	private int styleId;
	
	/**
	 * 风格名称
	 */
	private String styleName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStyleId() {
		return styleId;
	}

	public void setStyleId(int styleId) {
		this.styleId = styleId;
	}

	public String getStyleName() {
		return styleName;
	}

	public void setStyleName(String styleName) {
		this.styleName = styleName;
	}
	
}
