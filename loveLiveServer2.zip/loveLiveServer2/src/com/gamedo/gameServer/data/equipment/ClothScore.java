package com.gamedo.gameServer.data.equipment;

/**
 * 
 * @author libm
 *
 */
public class ClothScore {

	private int id;
	/**
	 * 服装部位
	 */
	private int clothPart;
	/**
	 * 评级id
	 */
	private int scoreId;
	/**
	 * 评分
	 */
	private int score;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getScoreId() {
		return scoreId;
	}

	public void setScoreId(int scoreId) {
		this.scoreId = scoreId;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getClothPart() {
		return clothPart;
	}

	public void setClothPart(int clothPart) {
		this.clothPart = clothPart;
	}

}
