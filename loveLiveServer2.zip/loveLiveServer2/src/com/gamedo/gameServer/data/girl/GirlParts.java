package com.gamedo.gameServer.data.girl;

/**
 * 模特初始服装数据
 * @author libm
 *
 */
public class GirlParts {

	private int id;
	
	/**
	 * 模特id
	 */
	private int girlId;
	
	/**
	 * 玩法类型
	 * 0：核心玩法
	 * 1：自由摄影
	 */
	private int playType;
	
	/**
	 * 0:外装
	 * 1:内装 
	 */
	private int type;
	/**
	 * 部位
	 * 0:头发
	 * 1:上装
	 * 2:下装
	 * 3:鞋
	 * 4:套装
	 * 5:配饰1
	 * 6:配饰2
	 * 7:配饰3
	 * 8:配饰4
	 */
	private int part;
	/**
	 * 装备id
	 */
	private int equipId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public int getPart() {
		return part;
	}

	public void setPart(int part) {
		this.part = part;
	}

	public int getEquipId() {
		return equipId;
	}

	public void setEquipId(int equipId) {
		this.equipId = equipId;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getPlayType() {
		return playType;
	}

	public void setPlayType(int playType) {
		this.playType = playType;
	}

	
}
