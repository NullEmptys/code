package com.gamedo.gameServer.data.girl;

import java.io.Serializable;
import java.util.List;

import com.gamedo.gameServer.util.JsonUtil;

/**
 * 模特详细数据表
 * 
 * @author liuxing
 *
 */
public class GirlLevelInfo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id;
	// 模特id
	private int gridId;
	// 模特等级
	private String level;
	// 模特升级所需好感度
	private String exp;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGridId() {
		return gridId;
	}

	public void setGridId(int gridId) {
		this.gridId = gridId;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}
	
	public List<Integer> getListLevel(){
		return JsonUtil.fromJsonList(this.getLevel(), Integer.class);
	}
	
	public List<Integer> getListExp(){
		return JsonUtil.fromJsonList(this.getExp(), Integer.class);
	}
}
