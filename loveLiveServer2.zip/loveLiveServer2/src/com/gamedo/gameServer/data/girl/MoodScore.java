package com.gamedo.gameServer.data.girl;

/**
 * 
 * @author libm
 *
 */
public class MoodScore {

	private int id;
	/**
	 * 情绪类型
	 */
	private int moodType;
	/**
	 * 评级id
	 */
	private int scoreId;
	/**
	 * 评分
	 */
	private int score;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMoodType() {
		return moodType;
	}

	public void setMoodType(int moodType) {
		this.moodType = moodType;
	}

	public int getScoreId() {
		return scoreId;
	}

	public void setScoreId(int scoreId) {
		this.scoreId = scoreId;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
}
