package com.gamedo.gameServer.data.girl;

/**
 * 
 * @author libm
 *
 */
public class ModelScore {

	private int id;
	/**
	 * 模特id
	 */
	private int modelId;
	/**
	 * 模特等级
	 */
	private int level;
	/**
	 * 风格id
	 */
	private int styleId;
	
	private int score;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getStyleId() {
		return styleId;
	}

	public void setStyleId(int styleId) {
		this.styleId = styleId;
	}
	
}
