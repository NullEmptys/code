package com.gamedo.gameServer.data.girl;

import java.util.List;

import com.gamedo.gameServer.util.JsonUtil;

/**
 * 模特数据结构
 * 
 * @author libm
 *
 */
public class Girl {

	private int id;
	/** 名字 */
	private String name;
	/** 头 */
	private String head;
	/** 模特icon */
	private String icon;
	/** 描述 */
	private String description;
	/** 脸 */
	private int faceId;
	/** 性格 */
	private String disposition;
	/** 星座 */
	private String constellation;
	/** 血型 */
	private String blood;
	/** 生日 */
	private String birthday;
	/** 三围 */
	private String measurements;
	/** 身高 */
	private String height;
	/** 职业 */
	private String job;
	/** 喜欢的东西 */
	private String loveAttributeStr;
	/** 讨厌的东西 */
	private String heatAttributeStr;
	/** 兴趣爱好 */
	private String interest;
	/** 简介 */
	private String introduction;
	/** 模特最高等级 */
	private int MaxLv;
	/** 模特风格基础属性值 */
	private String styleBaseValue;
	/** 模特解锁条件 成就id[1,2,3] */
	private String unlockCondition;
	/** 模特解锁消耗金币数量 */
	private int consumeGold;
	/** 模特解锁消耗钻石数量 */
	private int consumeDiamond;
	/** 模特穿着比基尼等级限制 */
	private int wearBikiniLevelLimit;
	/** 模特初始服装[clothId] */
	private String initCloth;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDisposition() {
		return disposition;
	}

	public void setDisposition(String disposition) {
		this.disposition = disposition;
	}

	public String getConstellation() {
		return constellation;
	}

	public void setConstellation(String constellation) {
		this.constellation = constellation;
	}

	public String getBlood() {
		return blood;
	}

	public void setBlood(String blood) {
		this.blood = blood;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getMeasurements() {
		return measurements;
	}

	public void setMeasurements(String measurements) {
		this.measurements = measurements;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getFaceId() {
		return faceId;
	}

	public void setFaceId(int faceId) {
		this.faceId = faceId;
	}

	public String getHead() {
		return head;
	}

	public void setHead(String head) {
		this.head = head;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public int getMaxLv() {
		return MaxLv;
	}

	public void setMaxLv(int maxLv) {
		MaxLv = maxLv;
	}

	public String getStyleBaseValue() {
		return styleBaseValue;
	}

	public void setStyleBaseValue(String styleBaseValue) {
		this.styleBaseValue = styleBaseValue;
	}

	public String getUnlockCondition() {
		return unlockCondition;
	}

	public void setUnlockCondition(String unlockCondition) {
		this.unlockCondition = unlockCondition;
	}

	public int getConsumeGold() {
		return consumeGold;
	}

	public void setConsumeGold(int consumeGold) {
		this.consumeGold = consumeGold;
	}

	public int getConsumeDiamond() {
		return consumeDiamond;
	}

	public void setConsumeDiamond(int consumeDiamond) {
		this.consumeDiamond = consumeDiamond;
	}

	public String getLoveAttributeStr() {
		return loveAttributeStr;
	}

	public void setLoveAttributeStr(String loveAttributeStr) {
		this.loveAttributeStr = loveAttributeStr;
	}

	public String getHeatAttributeStr() {
		return heatAttributeStr;
	}

	public void setHeatAttributeStr(String heatAttributeStr) {
		this.heatAttributeStr = heatAttributeStr;
	}

	public String getInterest() {
		return interest;
	}

	public void setInterest(String interest) {
		this.interest = interest;
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	public int getWearBikiniLevelLimit() {
		return wearBikiniLevelLimit;
	}

	public void setWearBikiniLevelLimit(int wearBikiniLevelLimit) {
		this.wearBikiniLevelLimit = wearBikiniLevelLimit;
	}

	public String getInitCloth() {
		return initCloth;
	}

	public void setInitCloth(String initCloth) {
		this.initCloth = initCloth;
	}

	public List<Integer> getJsonUnlockCondtion() {
		return JsonUtil.fromJsonList(this.getUnlockCondition(), Integer.class);
	}

}
