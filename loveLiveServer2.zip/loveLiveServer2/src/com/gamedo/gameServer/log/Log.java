package com.gamedo.gameServer.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.entity.player.Player;

/**
 * 日志管理
 * @author libm
 *
 */
@Component
public class Log {

	public Logger log = LoggerFactory.getLogger(Log.class);
	
	private static Log instance;
	
	public Log() {
		instance = this;
	}
	
	/**
	 * 获取日志实例
	 * 
	 * @return
	 */
	public static Log getInstance() {
		if(instance == null) {
			instance = new Log();
		}
		return instance;
	}
	
	public StringBuilder getPlayerString(StringBuilder sb,Player player){
		if(player == null){
			sb.append("PLAYERID[-1]ACC[-1]");
		}else{
			sb.append("PLAYERID[");
			sb.append(player.getId());
			sb.append("]NAME[");
			sb.append(player.getName());
			sb.append("]ACCOUNTNAME[");
			sb.append(player.getUserName());
			sb.append("]");
		}
		return sb;
	}
	
	/** 记录玩家获得经验 */
	public void logGetExp(Player p, int oldExp, int exp, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[GETEXP]");
		getPlayerString(sb, p);
		sb.append("oldExp[").append(oldExp).append("]exp[").append(exp).append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}

	/** 记录当前玩家在线数*/
	public void logOnlineCount(int onlineCount) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[ONLINE]COUNT[");
		sb.append(onlineCount);
		sb.append("]");
		log.info(sb.toString());
	}

	/** 升级*/
	public void logLevelUp(Player player, int oldLevel, int oldExp, int level, int exp) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[LEVELUP]");
		getPlayerString(sb, player);
		sb.append("oldLevel[").append(oldLevel).append("]oldExp[").append(oldExp);
		sb.append("]level[").append(level).append("]exp[").append(exp);
		sb.append("]");
		log.info(sb.toString());
	}

	/** 记录玩家获得钻石*/
	public void logGetMoney(Player player, int oldMoney, int money, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[GETMONEY]");
		getPlayerString(sb, player);
		sb.append("oldMoney[").append(oldMoney).append("]money[").append(money).append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}

	/** 记录玩家扣除钻石*/
	public void logRemoveMoney(Player player, int oldMoney, int money, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[REMOVEMONEY]");
		getPlayerString(sb, player);
		sb.append("oldMoney[").append(oldMoney).append("]money[").append(money).append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}

	/** 记录玩家获得金币 */
	public void logGetGold(Player p, int oldGold, int gold, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[GETGOLD]");
		getPlayerString(sb, p);
		sb.append("oldGold[").append(oldGold).append("]gold[").append(gold).append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}

	/** 记录玩家扣除金币*/
	public void logRemoveGold(Player p, int oldGold, int gold, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[REMOVEGOLD]");
		getPlayerString(sb, p);
		sb.append("oldGold[").append(oldGold).append("]gold[").append(gold).append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}

	/** 记录玩家获得体力*/
	public void logAddTiLi(Player player, int oldTili, int tili, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[ADDTILI]");
		getPlayerString(sb, player);
		sb.append("oldTili[").append(oldTili).append("]tili[").append(tili).append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}
	
	/** 记录玩家扣除体力*/
	public void logDecTiLi(Player player, int oldTili, int tili, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[DECTILI]");
		getPlayerString(sb, player);
		sb.append("oldTili[").append(oldTili).append("]tili[").append(tili).append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}
	
	/** 记录玩家获得物品 */
	public void logGetItem(Player p, GameItem item, int count, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[GETITEM]");
		getPlayerString(sb, p);
		sb.append("INFO[");
		getGameItemString(sb, item, count);
		sb.append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}
	
	public void getGameItemString(StringBuilder sb,GameItem item,int count){
		//if(item.getTemplate() instanceof EquipmentTemplate){
			//sb.append("EQU(");
		//}else{
			sb.append("ITEM(");
		//}
		sb.append(item.getId()).append(',');
		sb.append(item.getTemplate().getId()).append(',');
		sb.append(item.getInstanceId()).append(',');
		if(item.getGameItemObject()!=null){
			item.getGameItemObject().dump(sb);
			sb.append(',');
		}
		sb.append(count).append(')');
	}
	
	/** 记录玩家移除物品 */
	public void logRemoveItem(Player p, GameItem item, int count, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[REMOVEITEM]");
		getPlayerString(sb, p);
		sb.append("INFO[");
		getGameItemString(sb, item, count);
		sb.append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}
	
	/** 记录错误物品模板 */
	public void logItemError(int itemId) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[ITEMERROR]");
		sb.append("ITMID[").append(itemId).append("]");
		log.info(sb.toString());
	}

	public void logAddActivityCoin(Player player, int oldActivityCoin, int activityCoin, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[ADD_ACTIVITYCOIN]");
		getPlayerString(sb, player);
		sb.append("oldActivityCoin[").append(oldActivityCoin).append("]activityCoin[").append(activityCoin).append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}

	public void logDecActivityCoin(Player player, int oldActivityCoin, int activityCoin, String cause) {
		StringBuilder sb = new StringBuilder(100);
		sb.append("[DEC_ACTIVITYCOIN]");
		getPlayerString(sb, player);
		sb.append("oldActivityCoin[").append(oldActivityCoin).append("]activityCoin[").append(activityCoin).append("]CAUSE[").append(cause).append("]");
		log.info(sb.toString());
	}
}
