package com.gamedo.gameServer.entity.mail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.BinaryType;
import org.hibernate.usertype.UserType;


/**
 * @author libm
 *
 */
public class MailAttachmentsUserType implements UserType{

	private static final int[] SQL_TYPES = {BinaryType.INSTANCE.sqlType()};
	
	@Override
	public Object assemble(Serializable cached, Object owner) throws HibernateException {
		return cached;
	}

	public Object deepCopy(Object value) throws HibernateException {
		if(value==null)
			return null;
		return ((MailAttachments) value).clone();
	}

	public Serializable disassemble(Object value) throws HibernateException {
		return (Serializable) value;
	}

	public boolean equals(Object x, Object y) throws HibernateException {
		if (x == y)
			return true;
		if (x == null || y == null)
			return false;
		return x.equals(y);
	}

	public int hashCode(Object x) throws HibernateException {
		return x.hashCode();
	}

	public boolean isMutable() {
		return true;
	}

	public Object replace(Object original, Object target, Object owner) {
		return target;
	}

	@SuppressWarnings("rawtypes")
	public Class returnedClass() {
		return MailAttachments.class;
	}

	public int[] sqlTypes() {
		return SQL_TYPES;
	}

	@Override
	public Object nullSafeGet(ResultSet resultSet, String[] names, SessionImplementor arg2, Object owner)
			throws HibernateException, SQLException {
		byte[] bytes = resultSet.getBytes(names[0]);
		if(bytes==null||bytes.length==0)
			return null;
		DataInputStream dis = new DataInputStream(new ByteArrayInputStream(bytes));
		try{
			return MailUtil.getMailAttacmentsFromDB(dis);
		}catch(IOException ex){
			return new HibernateException(ex);
		}
	}

	@Override
	public void nullSafeSet(PreparedStatement statement, Object value, int index, SessionImplementor arg3)
			throws HibernateException, SQLException {
		MailAttachments atts = (MailAttachments)value;
		if (atts == null || atts.getAttachments()==null || atts.getAttachments().length==0)
			statement.setNull(index, SQL_TYPES[0]);
		else {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			DataOutputStream dos = new DataOutputStream(baos);
			try {
				MailUtil.getAttachmentsDBytes(atts, dos);
				statement.setBytes(index, baos.toByteArray());
			} catch (IOException e) {
				throw new HibernateException(e);
			}
		}
	}

}
