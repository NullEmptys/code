package com.gamedo.gameServer.entity.mail;

/**
 * 
 * @author libm
 *
 */
public interface MailAttachment {

	public byte[] toClientBytes();
	public MailAttachment clone();
}
