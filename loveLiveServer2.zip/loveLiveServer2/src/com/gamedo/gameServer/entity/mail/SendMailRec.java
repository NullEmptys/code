package com.gamedo.gameServer.entity.mail;

import java.io.Serializable;

/**
 * 发送全服邮件状态
 * 
 * @author IPOC-HUANGPING
 *
 */
public class SendMailRec implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private int playerId;
	private int gmMailId;// 全服邮件id
	private int state;// 邮件发送状态0未发送，1已发送

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getGmMailId() {
		return gmMailId;
	}

	public void setGmMailId(int gmMailId) {
		this.gmMailId = gmMailId;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

}
