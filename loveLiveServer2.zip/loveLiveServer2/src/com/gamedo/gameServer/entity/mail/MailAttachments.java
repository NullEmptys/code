package com.gamedo.gameServer.entity.mail;

import java.io.Serializable;

/**
 * 邮件附件
 * @author libm
 *
 */
public class MailAttachments implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6494879325366549004L;
	
	protected MailAttachment[] attachments;

	public MailAttachments(MailAttachment[] attachments) {
		this.attachments = attachments;
	}

	public MailAttachment[] getAttachments() {
		return this.attachments;
	}

	@Override
	public MailAttachments clone() {
		MailAttachment[] mas = null;
		if (attachments != null) {
			mas = new MailAttachment[attachments.length];
			for (int i = 0; i < attachments.length; i++) {
				if(attachments[i] != null) {
					mas[i] = attachments[i].clone();
				}
			}
		}
		MailAttachments ret = new MailAttachments(mas);
		return ret;
	}
}
