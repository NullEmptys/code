package com.gamedo.gameServer.entity.mail;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;

import com.gamedo.gameServer.core.item.GameItem;

/**
 * 
 * @author libm
 *
 */
public class ItemMailAttachment implements MailAttachment,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2132215537855986311L;
	protected GameItem item;
	protected int count;
	
	public ItemMailAttachment(GameItem item,int count){
		this.item = item;
		this.count = count;
	}
	
	public GameItem getGameItem(){
		return item;
	}
	
	public int getCount(){
		return count;
	}
	
	public void setCount(int count){
		this.count = count;
	}

	public byte[] toClientBytes() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);
		try{
			dos.write(1); //类型标示，标示物品
			dos.writeInt(item.getTemplate().getId());
			dos.writeLong(item.getInstanceId());
			dos.write(count);
			dos.writeUTF(item.getTemplate().getName());
			dos.writeUTF(item.getTemplate().getIcon());
			dos.write(item.getTemplate().getQuality());
		}catch(IOException ex){
			ex.printStackTrace();
		}
		return baos.toByteArray();
	}
	
	@Override
	public ItemMailAttachment clone(){
		return new ItemMailAttachment(item,count);
	}


}
