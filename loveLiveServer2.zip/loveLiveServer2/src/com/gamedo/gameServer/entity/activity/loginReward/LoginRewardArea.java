package com.gamedo.gameServer.entity.activity.loginReward;

import java.io.Serializable;

/**
 * 
 * @author libm
 *
 */
public class LoginRewardArea implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6716610197921567635L;
	private int id;
	/**角色id*/
	private int playerId;
	/**活动id*/
	private int activityId;
	/**登录奖励活动背景区域id*/
	private int areaId;
	/**区域解锁状态  0-未解锁 1-已解锁*/
	private int state;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getActivityId() {
		return activityId;
	}
	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}
	public int getAreaId() {
		return areaId;
	}
	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	
}
