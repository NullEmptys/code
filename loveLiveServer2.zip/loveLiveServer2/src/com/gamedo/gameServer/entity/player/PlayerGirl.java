package com.gamedo.gameServer.entity.player;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.gamedo.gameServer.core.BaseUnit;
import com.gamedo.gameServer.core.Updatable;
import com.gamedo.gameServer.core.bag.Bag;
import com.gamedo.gameServer.core.bag.BagGrid;
import com.gamedo.gameServer.core.bag.Bags;
import com.gamedo.gameServer.core.bag.GirlBags;
import com.gamedo.gameServer.core.item.Equipments;
import com.gamedo.gameServer.core.item.EquipmentsEx;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.message.player.BagData;
import com.gamedo.gameServer.message.player.BagInfo;
import com.gamedo.gameServer.message.player.BagItemInfo;
import com.gamedo.gameServer.util.Const;
import com.gamedo.gameServer.util.JsonUtil;

/**
 * 模特
 * 
 * @author libm
 *
 */
public class PlayerGirl implements Serializable {
	private static final long serialVersionUID = -5529369192264387491L;

	private int id;

	private int playerId;// 玩家id

	private int girlId;// 模特id
	private int level;// 模特等级
	private int exp;// 模特经验值
	private String conditionState;// 模特解锁条件达成状态0未解锁1解锁
	private int status;//是否已经解锁
	private String styleValue;//风格属性值

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}

	public String getConditionState() {
		return conditionState;
	}

	public void setConditionState(String conditionState) {
		this.conditionState = conditionState;
	}
	
	public List<Integer> getCondtionStatus(){
		return JsonUtil.fromJsonList(this.getConditionState(), Integer.class);
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getStyleValue() {
		return styleValue;
	}

	public void setStyleValue(String styleValue) {
		this.styleValue = styleValue;
	}
	
	public List<Integer> getStyleAttValue(){
		return JsonUtil.fromJsonList(this.getStyleValue(), Integer.class);
	}
}
