package com.gamedo.gameServer.entity.player;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gamedo.gameServer.constant.AttributeType;
import com.gamedo.gameServer.core.BaseUnit;
import com.gamedo.gameServer.core.Changed;
import com.gamedo.gameServer.core.ChangedItem;
import com.gamedo.gameServer.core.IntPropertyChangedItem;
import com.gamedo.gameServer.core.LongPropertyChangedItem;
import com.gamedo.gameServer.core.PropertyPool;
import com.gamedo.gameServer.core.Time;
import com.gamedo.gameServer.core.TransactionIntProperty;
import com.gamedo.gameServer.core.bag.Bag;
import com.gamedo.gameServer.core.bag.BagGrid;
import com.gamedo.gameServer.core.bag.Bags;
import com.gamedo.gameServer.core.event.EventManager;
import com.gamedo.gameServer.core.event.ServiceEvent;
import com.gamedo.gameServer.core.item.GameItem;
import com.gamedo.gameServer.core.transaction.PlayerTransaction;
import com.gamedo.gameServer.data.PlayerLevelInfo;
import com.gamedo.gameServer.entity.achievement.PlayerAchievement;
import com.gamedo.gameServer.exception.NoEnoughValueException;
import com.gamedo.gameServer.exception.TransactionException;
import com.gamedo.gameServer.log.Log;
import com.gamedo.gameServer.message.player.BagInfo;
import com.gamedo.gameServer.message.player.BagItemInfo;
import com.gamedo.gameServer.message.player.BagData;
import com.gamedo.gameServer.message.player.PlayerBaseData;
import com.gamedo.gameServer.service.data.DataService;
import com.gamedo.gameServer.service.player.PlayerService;
import com.gamedo.gameServer.util.Const;

import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

/**
 * 
 * @author libm
 *
 */
public class Player extends BaseUnit implements Serializable {

	private Logger logger = LoggerFactory.getLogger(Player.class);

	/**
	 * 
	 */
	private static final long serialVersionUID = -839954568905206294L;

	private int id;
	/* 账号名称 */
	private String userName;
	/* 角色名称 */
	private String name;
	/* 角色等级 */
	private int level;
	/* 角色iconId */
	private int iconId;
	/* 头像url地址 */
	private String avatarUrl;
	/* 经验值 */
	private int exp;
	/* 钻石 */
	private int money;
	/* 金币 */
	private int gold;
	/* 活动币*/
	private int activityCoin;
	/* 体力 */
	private int tili;
	/* 渠道号 */
	private String channelId;
	/* 子渠道号*/
	private String subChannelId;
	/* 账号类型  */
	private int playerType = 1;
	/* 角色创建时间 */
	private Date createTime;
	/* 角色最后登录时间 */
	private Date lastLoginTime;
	/* 角色最后登出时间 */
	private Date lastLogoutTime;
	/* 角色最后操作时间 */
	private long lastOperateTime;
	/* 加载时间 */
	private Date loadTime;
	/* 成就点 */
	private int achieveValue;
	/* 属性池 */
	private PropertyPool pool = new PropertyPool();
	/* 背包 */
	private Bags bags;
	/* 注册IP */
	private String registIp;
	/* 最后登录IP地址 */
	private String lastLoginIp;
	/* 状态 0-正常 1-封停 2-禁言 */
	private int state;
	/* 封停或者禁言结束时间 */
	private Date stateCdTime;
	/* 累计登录次数 */
	private int totalLoginCounts;
	/* 新手引导步骤 */
	private int guideStep;
	private int girlId;

	protected Lock txLock = new ReentrantLock();

	protected List<PlayerTransaction> transactions = new LinkedList<PlayerTransaction>();

	protected List<GameItem> autoUseItem = new ArrayList<GameItem>(3);

	/**
	 * 刷新出来的任务id key: 难度类型 value: 刷出来的任务id 不需要持久化（保存在pool里）
	 */
	//public TIntObjectMap<TIntList> refreshedQuestIds = new TIntObjectHashMap<TIntList>();

	public TIntObjectMap<PlayerAchievement> achivements = new TIntObjectHashMap<PlayerAchievement>();

	private int signGirlCounts = 0;// 同时签约模特个数
	private int signForeverGirlCounts = 0;// 签约永久模特个数

	protected int maxLevel = 100;

	protected TransactionIntProperty moneyTx;
	protected TransactionIntProperty expTx;
	protected TransactionIntProperty goldTx;
	protected TransactionIntProperty tiliTx;
	protected TransactionIntProperty activityCoinTx;

	public Changed changed;

	public Player() {
		this.moneyTx = new MoneyIntProperty();
		this.expTx = new ExpIntProperty();
		this.goldTx = new GoldIntProperty();
		this.tiliTx = new TiLiIntProperty();
		this.activityCoinTx = new ActivityCoinIntProperty();
		this.changed = new Changed();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int newLevel) {
		if (newLevel != this.level) {
			this.level = newLevel;
			IntPropertyChangedItem ic = new IntPropertyChangedItem(ChangedItem.LEVEL, newLevel, false, true);
			changed.addChangedItem(ic);
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getPlayerType() {
		return playerType;
	}

	public void setPlayerType(int playerType) {
		this.playerType = playerType;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public Date getLastLogoutTime() {
		return lastLogoutTime;
	}

	public void setLastLogoutTime(Date lastLogoutTime) {
		this.lastLogoutTime = lastLogoutTime;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getIconId() {
		return iconId;
	}

	public void setIconId(int iconId) {
		this.iconId = iconId;
	}

	public String getAvatarUrl() {
		return avatarUrl;
	}

	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}

	public int getTili() {
		return tili;
	}

	public void setTili(int tili) {
		this.tili = tili;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getSubChannelId() {
		return subChannelId;
	}

	public void setSubChannelId(String subChannelId) {
		this.subChannelId = subChannelId;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public int getGold() {
		return gold;
	}

	public void setGold(int gold) {
		this.gold = gold;
	}
	
	public int getActivityCoin() {
		return activityCoin;
	}

	public void setActivityCoin(int activityCoin) {
		this.activityCoin = activityCoin;
	}

	public long getLastOperateTime() {
		return lastOperateTime;
	}

	public void setLastOperateTime(long lastOperateTime) {
		this.lastOperateTime = lastOperateTime;
	}

	public Date getLoadTime() {
		return loadTime;
	}

	public String getRegistIp() {
		return registIp;
	}
	
	

	public void setRegistIp(String registIp) {
		this.registIp = registIp;
	}

	public String getLastLoginIp() {
		return lastLoginIp;
	}

	public void setLastLoginIp(String lastLoginIp) {
		this.lastLoginIp = lastLoginIp;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public Date getStateCdTime() {
		return stateCdTime;
	}

	public void setStateCdTime(Date stateCdTime) {
		this.stateCdTime = stateCdTime;
	}

	public int getTotalLoginCounts() {
		return totalLoginCounts;
	}

	public void setTotalLoginCounts(int totalLoginCounts) {
		this.totalLoginCounts = totalLoginCounts;
	}

	public void setLoadTime(Date loadTime) {
		this.loadTime = loadTime;
	}

	public PropertyPool getPool() {
		return pool;
	}

	public void setPool(PropertyPool pool) {
		this.pool = pool;
	}

	public int getLastLoginDay() {
		return getPool().getInt(Const.PROPERTY_LAST_LOGIN_DAY);
	}

	public void setLastLoginDay(int day) {
		int lastLoginDay = getPool().getInt(Const.PROPERTY_LAST_LOGIN_DAY);
		if (lastLoginDay == 0) {
			getPool().setInt(Const.PROPERTY_CONTINU_LOGIN_COUNTS, 1);
		}
		if (day - lastLoginDay == 1) {
			int continuLoinCounts = getPool().getInt(Const.PROPERTY_CONTINU_LOGIN_COUNTS);
			getPool().setInt(Const.PROPERTY_CONTINU_LOGIN_COUNTS, continuLoinCounts + 1);
		} else if (day - lastLoginDay > 1) {
			getPool().setInt(Const.PROPERTY_CONTINU_LOGIN_COUNTS, 1);
		}
		getPool().setInt(Const.PROPERTY_LAST_LOGIN_DAY, day);
	}

	/**
	 * 获取玩家当日所属时段送道具次数
	 * 
	 * @return
	 */
	public int getSendGiftCounts() {
		int lastSendGiftDay = getPool().getInt(Const.PROPERTY_LAST_SEND_GIFT_DAY);
		int lastSendGiftPeriod = getPool().getInt(Const.PROPERTY_LAST_SEND_GIFT_PERIOD);
		if (lastSendGiftDay != Time.day) {
			getPool().setInt(Const.PROPERTY_LAST_SEND_GIFT_DAY, Time.day);
			getPool().setInt(Const.PROPERTY_LAST_SEND_GIFT_PERIOD, getCurrentPeriod());
			getPool().setInt(Const.PROPERTY_SEND_GIFT_COUNTS, 0);
		} else {
			int currentPeriod = getCurrentPeriod();
			if (lastSendGiftPeriod != currentPeriod) {
				getPool().setInt(Const.PROPERTY_SEND_GIFT_COUNTS, 0);
				getPool().setInt(Const.PROPERTY_LAST_SEND_GIFT_PERIOD, getCurrentPeriod());
			}
		}
		return getPool().getInt(Const.PROPERTY_SEND_GIFT_COUNTS);
	}

	public void setSendGiftCounts(int sendGiftCounts) {
		int lastSendGiftDay = getPool().getInt(Const.PROPERTY_LAST_SEND_GIFT_DAY);
		int lastSendGiftPeriod = getPool().getInt(Const.PROPERTY_LAST_SEND_GIFT_PERIOD);
		if (lastSendGiftDay != Time.day) {
			getPool().setInt(Const.PROPERTY_LAST_SEND_GIFT_DAY, Time.day);
			getPool().setInt(Const.PROPERTY_LAST_SEND_GIFT_PERIOD, getCurrentPeriod());
			getPool().setInt(Const.PROPERTY_SEND_GIFT_COUNTS, 0);
		} else {
			int currentPeriod = getCurrentPeriod();
			if (lastSendGiftPeriod != currentPeriod) {
				getPool().setInt(Const.PROPERTY_SEND_GIFT_COUNTS, 0);
				getPool().setInt(Const.PROPERTY_LAST_SEND_GIFT_PERIOD, getCurrentPeriod());
			}
		}
		getPool().setInt(Const.PROPERTY_SEND_GIFT_COUNTS, sendGiftCounts);
	}

	public int getEngagementGuessCounts() {
		int lastGuessDay = getPool().getInt(Const.PROPERTY_LAST_GUESS_DAY);
		int lastGuessPeriod = getPool().getInt(Const.PROPERTY_LAST_GUESS_PERIOD);
		if (lastGuessDay != Time.day) {
			getPool().setInt(Const.PROPERTY_LAST_GUESS_DAY, Time.day);
			getPool().setInt(Const.PROPERTY_LAST_GUESS_PERIOD, getCurrentPeriod());
			getPool().setInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS, 0);
		} else {
			int currentPeriod = getCurrentPeriod();
			if (lastGuessPeriod != currentPeriod) {
				getPool().setInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS, 0);
				getPool().setInt(Const.PROPERTY_LAST_GUESS_PERIOD, getCurrentPeriod());
			}
		}
		return getPool().getInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS);
	}

	public void setEngagementGuessCounts(int guessCounts) {
		int lastGuessDay = getPool().getInt(Const.PROPERTY_LAST_GUESS_DAY);
		int lastGuessPeriod = getPool().getInt(Const.PROPERTY_LAST_GUESS_PERIOD);
		if (lastGuessDay != Time.day) {
			getPool().setInt(Const.PROPERTY_LAST_GUESS_DAY, Time.day);
			getPool().setInt(Const.PROPERTY_LAST_GUESS_PERIOD, getCurrentPeriod());
			getPool().setInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS, 0);
		} else {
			int currentPeriod = getCurrentPeriod();
			if (lastGuessPeriod != currentPeriod) {
				getPool().setInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS, 0);
				getPool().setInt(Const.PROPERTY_LAST_GUESS_PERIOD, getCurrentPeriod());
			}
		}
		getPool().setInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS, guessCounts);
	}

	public int getEngagementGirlId() {
		int lastEngagementDay = getPool().getInt(Const.PROPERTY_LAST_ENGAGEMENT_DAY);
		int lastEngagementPeriod = getPool().getInt(Const.PROPERTY_LAST_ENGAGEMENT_PERIOD);
		if (lastEngagementDay != Time.day) {
			getPool().setInt(Const.PROPERTY_LAST_ENGAGEMENT_DAY, Time.day);
			getPool().setInt(Const.PROPERTY_LAST_ENGAGEMENT_PERIOD, getCurrentPeriod());
			getPool().setInt(Const.PROPERTY_ENGAGEMENT_GIRL_ID, 0);
			getPool().setInt(Const.PROPERTY_SEND_GIFT_COUNTS, 0);
			getPool().setInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS, 0);
		} else {
			int currentPeriod = getCurrentPeriod();
			if (lastEngagementPeriod != currentPeriod) {
				getPool().setInt(Const.PROPERTY_LAST_ENGAGEMENT_PERIOD, getCurrentPeriod());
				getPool().setInt(Const.PROPERTY_ENGAGEMENT_GIRL_ID, 0);
				getPool().setInt(Const.PROPERTY_SEND_GIFT_COUNTS, 0);
				getPool().setInt(Const.PROPERTY_ENGAGEMENT_GUESS_COUNTS, 0);
			}
		}
		return getPool().getInt(Const.PROPERTY_ENGAGEMENT_GIRL_ID);
	}

	public void setEngagementGirlId(int girlId) {
		int lastEngagementDay = getPool().getInt(Const.PROPERTY_LAST_ENGAGEMENT_DAY);
		int lastEngagementPeriod = getPool().getInt(Const.PROPERTY_LAST_ENGAGEMENT_PERIOD);
		if (lastEngagementDay != Time.day) {
			getPool().setInt(Const.PROPERTY_LAST_ENGAGEMENT_DAY, Time.day);
			getPool().setInt(Const.PROPERTY_LAST_ENGAGEMENT_PERIOD, getCurrentPeriod());
		} else {
			int currentPeriod = getCurrentPeriod();
			if (lastEngagementPeriod != currentPeriod) {
				getPool().setInt(Const.PROPERTY_LAST_ENGAGEMENT_PERIOD, getCurrentPeriod());
				getPool().setInt(Const.PROPERTY_ENGAGEMENT_GIRL_ID, 0);
			}
		}
		getPool().setInt(Const.PROPERTY_ENGAGEMENT_GIRL_ID, girlId);
		getPool().setInt(Const.PROPERTY_ENGAGEMENT_GIRL_COUNTS + "_" + girlId,
				getPool().getInt(Const.PROPERTY_ENGAGEMENT_GIRL_COUNTS + "_" + girlId) + 1);
	}

	private int getCurrentPeriod() {
		int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
		if (hour >= 0 && hour < 11) {
			return 1;
		} else if (hour >= 11 && hour < 18) {
			return 2;
		} else if (hour >= 18 && hour <= 23) {
			return 3;
		}
		return 0;
	}

	public Bags getBags() {
		return bags;
	}

	public void setBags(Bags bags) {
		this.bags = bags;
	}

	/** 角色基础数据 */
	public PlayerBaseData getPlayerBaseData() {
		PlayerBaseData baseData = new PlayerBaseData();
		baseData.setPlayerID("" + getId());
		baseData.setName(getName());
		baseData.setIconId("" + getIconId());
		baseData.setLevel("" + getLevel());
		baseData.setExp("" + exp);
		baseData.setGold("" + getGold());
		baseData.setMoney("" + getMoney());
		baseData.setTiLi("" + getTili());
		baseData.setChievementValue(getAchieveValue());
		baseData.setPlayerType(getPlayerType());
		baseData.setChangeNameCounts(getPool().getInt(Const.PROPERTY_CHANGE_PLAYERNAME_COUNTS));
		baseData.setGirlId(getGirlId());
		return baseData;
	}

	/** 角色背包数据 */
	public BagData getPlayerBagData() {
		BagData bagData = new BagData();

		List<BagInfo> bagInfos = new ArrayList<>();
		Bags bags = this.getBags();
		if (bags != null) {
			List<Bag> list = bags.getBags();
			if (list != null && list.size() > 0) {
				for (Bag bag : list) {
					if (bag != null) {
						BagInfo bagInfo = new BagInfo();
						bagInfo.setBagId(bag.getId());
						bagInfo.setItems(getBagItemsById(bag.getId()));
						bagInfos.add(bagInfo);
					}
				}

			}
		}
		bagData.setBags(bagInfos);
		return bagData;
	}

	/**
	 * 获取指定背包中的所有物品详细信息
	 * 
	 * @param bagId
	 *            背包id 0：消耗品类背包 1：服装类背包
	 * @return
	 */
	private List<BagItemInfo> getBagItemsById(int bagId) {
		Bag bag = this.getBags().getBag(bagId);
		if (bag != null) {
			List<BagItemInfo> items = new ArrayList<>();
			List<BagGrid> grids = bag.getGrids();
			if (grids != null && grids.size() > 0) {
				for (BagGrid grid : grids) {
					if (grid != null && grid.getItem() != null) {
						GameItem gameItem = grid.getItem();
						BagItemInfo bagItemInfo = new BagItemInfo();
						bagItemInfo.setGridId(grid.id);
						bagItemInfo.setCount(grid.getCount());
						bagItemInfo.setInstanceId(gameItem.getInstanceId());
						bagItemInfo.setItemId(gameItem.getTemplate().getId());
						bagItemInfo.setCreateTime(gameItem.getCreateTime());
						items.add(bagItemInfo);
					}
				}
			}
			return items;
		}
		return null;
	}

	public PlayerTransaction newTransaction(boolean critical, String cause) {
		txLock.lock();
		try {
			PlayerTransaction tx = new PlayerTransaction(this, cause, critical);
			transactions.add(tx);
			return tx;
		} finally {
			txLock.unlock();
		}
	}

	public PlayerTransaction newTransaction(String cause) {
		return newTransaction(false, cause);
	}

	public void release(PlayerTransaction tx, boolean commit) throws TransactionException {
		txLock.lock();
		try {
			if (transactions.contains(tx)) {
				transactions.remove(tx);
				if (commit) {
					tx.internalCommit();
				} else
					tx.internalRollback();
			} else
				throw new TransactionException();
		} finally {
			txLock.unlock();
		}
		if (commit) {
			List<GameItem> l = tx.getAutoUseItems();
			if (l != null) {
				synchronized (autoUseItem) {
					autoUseItem.addAll(l);
				}
			}
		}
	}

	/**
	 * 获得钻石
	 * 
	 * @param value
	 * @param tx
	 * @param notify
	 */
	public void addMoney(int value, PlayerTransaction tx, boolean notify) {
		if (value > 0) {
			moneyTx.addWithoutException(value, tx, notify);
		}
	}

	/**
	 * 扣除钻石
	 * 
	 * @param value
	 * @param tx
	 * @param notify
	 * @throws NoEnoughValueException
	 */
	public void decMoney(int value, PlayerTransaction tx, boolean notify) throws NoEnoughValueException {
		if (value > 0) {
			moneyTx.dec(value, tx, notify);
		}
	}
	
	/**
	 * 获得活动币
	 * 
	 * @param value
	 * @param tx
	 * @param notify
	 */
	public void addActivityCoin(int value, PlayerTransaction tx, boolean notify) {
		if (value > 0) {
			activityCoinTx.addWithoutException(value, tx, notify);
		}
	}
	
	/**
	 * 扣除活动币
	 * 
	 * @param value
	 * @param tx
	 * @param notify
	 * @throws NoEnoughValueException
	 */
	public void decActivityCoin(int value, PlayerTransaction tx, boolean notify) throws NoEnoughValueException {
		if (value > 0) {
			activityCoinTx.dec(value, tx, notify);
		}
	}

	public void decCurrency(AttributeType currencyType, int value, PlayerTransaction tx, boolean notify)
			throws NoEnoughValueException {
		switch (currencyType) {
		case MONEY:
			decMoney(value, tx, notify);
			break;
		case GOLD:
			decGold(value, tx, notify);
			break;
		case ACTIVITY_COIN:
			decActivityCoin(value, tx, notify);
			break;
		default:
			break;
		}
	}

	protected void setMoney(int money, boolean notify, String cause) {
		if (money >= 0 && this.money != money) {
			int oldMoney = this.money;
			this.money = money;
			addIntPropertyChangedItem(ChangedItem.MONEY, oldMoney, this.money, notify);
			if (this.money > oldMoney) {
				getPool().setLong(Const.PROPERTY_GAIN_MONEY_COUNTS,
						getPool().getLong(Const.PROPERTY_GAIN_MONEY_COUNTS, 0) + (money - oldMoney));
				EventManager.getInstance().addEvent(
						new ServiceEvent(ServiceEvent.EVENT_PLAYER_GAIN_MONEY, this, this.money - oldMoney, cause));
				Log.getInstance().logGetMoney(this, oldMoney, money, cause);
			} else {
				getPool().setLong(Const.PROPERTY_CONSUME_MONEY_COUNTS,
						getPool().getLong(Const.PROPERTY_CONSUME_MONEY_COUNTS, 0) + (oldMoney - money));
				EventManager.getInstance().addEvent(
						new ServiceEvent(ServiceEvent.EVENT_PLAYER_DEC_MONEY, this, oldMoney - this.money, cause));
				Log.getInstance().logRemoveMoney(this, oldMoney, money, cause);
			}
		}
	}

	protected void setExp(int exp, boolean notify, String cause) {
		if (getLevel() >= maxLevel) {
			return;
		}
		if (this.exp != exp) {
			Log.getInstance().logGetExp(this, this.exp, exp, cause);
			int upLevel = DataService.getInstance().getUpLevel(level, exp);
			addIntPropertyChangedItem(ChangedItem.GAINEXP, exp - this.exp, notify, false, false);
			if (upLevel > 0) {
				int oldLevel = level;
				int oldExp = exp;
				int newLevel = 0;

				newLevel = level + upLevel;

				exp -= DataService.getInstance().getUpLevelExp(level, newLevel);

				this.exp = exp;
				addIntPropertyChangedItem(ChangedItem.EXP, this.exp, notify, true, false);
				setLevel(newLevel);
				int upExp = DataService.getInstance().getUpLevelExp(this.level, this.level + 1);
				PlayerService.getInstance().checkTiLi(this);
				addIntPropertyChangedItem(ChangedItem.LEVELUPEXP, upExp, notify, true, false);
				Log.getInstance().logLevelUp(this, oldLevel, oldExp, this.level, this.exp);
			}
			int oldExp = this.exp;
			this.exp = exp;
			addIntPropertyChangedItem(ChangedItem.EXP, oldExp, this.exp, notify);
		}
	}

	public void addExp(int value, PlayerTransaction tx, boolean notify) {
		if (value > 0 && ((long) expTx.getValue() + value) < expTx.getMaxValue()) {
			expTx.addWithoutException(value, tx, notify);
		}
	}

	public void setGold(int gold, boolean notify, String cause) {
		if (gold >= 0 && this.gold != gold) {
			int oldGold = this.gold;
			this.gold = gold;
			if (oldGold != this.gold) {
				addIntPropertyChangedItem(ChangedItem.GOLD, oldGold, this.gold, notify);
				if (this.gold > oldGold) {
					getPool().setLong(Const.PROPERTY_GAIN_GOLD_COUNTS,
							getPool().getLong(Const.PROPERTY_GAIN_GOLD_COUNTS, 0) + (gold - oldGold));
					EventManager.getInstance().addEvent(
							new ServiceEvent(ServiceEvent.EVENT_PLAYER_GAIN_GOLD, this, this.gold - oldGold, cause));
					Log.getInstance().logGetGold(this, oldGold, gold, cause);
				} else {
					getPool().setLong(Const.PROPERTY_CONSUME_GOLD_COUNTS,
							getPool().getLong(Const.PROPERTY_CONSUME_GOLD_COUNTS, 0) + (oldGold - gold));
					EventManager.getInstance().addEvent(
							new ServiceEvent(ServiceEvent.EVENT_PLAYER_DEC_GOLD, this, oldGold - this.gold, cause));
					Log.getInstance().logRemoveGold(this, oldGold, gold, cause);
				}
			}
		}
	}

	/**
	 * 获得金币
	 * 
	 * @param value
	 * @param tx
	 * @param notify
	 */
	public void addGold(int value, PlayerTransaction tx, boolean notify) {
		if (value > 0) {
			goldTx.addWithoutException(value, tx, notify);
		}
	}

	/**
	 * 扣除金币
	 * 
	 * @param value
	 * @param tx
	 * @param notify
	 * @throws NoEnoughValueException
	 */
	public void decGold(int value, PlayerTransaction tx, boolean notify) throws NoEnoughValueException {
		if (value > 0) {
			goldTx.dec(value, tx, notify);
		}
	}

	/**
	 * 获得体力
	 * 
	 * @param value
	 * @param tx
	 * @param notify
	 */
	public void addTiLi(int value, PlayerTransaction tx, boolean notify) {
		if (value > 0) {
			tiliTx.addWithoutException(value, tx, notify);
		}
	}

	public void setTili(int value, boolean notify, String cause) {
		if (value >= 0 && this.tili != value) {
			int oldTili = this.tili;
			this.tili = value;
			if (oldTili != this.tili) {
				addIntPropertyChangedItem(ChangedItem.TILI, oldTili, this.tili, notify);
				if (this.tili > oldTili) {
					Log.getInstance().logAddTiLi(this, oldTili, tili, cause);
				} else {
					Log.getInstance().logDecTiLi(this, oldTili, tili, cause);
				}
			}
		}
	}

	/**
	 * 扣除体力
	 * 
	 * @param value
	 * @param tx
	 * @param notify
	 * @throws NoEnoughValueException
	 */
	public void decTiLi(int value, PlayerTransaction tx, boolean notify) throws NoEnoughValueException {
		if (value > 0) {
			tiliTx.dec(value, tx, notify);
		}
	}

	/**
	 * @brief changed里增加Int类型改变
	 */
	public void addIntPropertyChangedItem(int id, int oldValue, int newValue, boolean notify) {
		if (changed != null) {
			IntPropertyChangedItem ic = new IntPropertyChangedItem(id, newValue, false, true);
			changed.addChangedItem(ic);
			if (notify) {
				IntPropertyChangedItem oic = new IntPropertyChangedItem(id, newValue - oldValue, true);
				changed.addChangedItem(oic);
			}
		}
	}
	
	public void addLongPropertyChangedItem(int id,int oldValue,long value,boolean notify){
		if (changed != null) {
			LongPropertyChangedItem ic = new LongPropertyChangedItem(id, value, false, true);
			changed.addChangedItem(ic);
			if (notify) {
				LongPropertyChangedItem oic = new LongPropertyChangedItem(id, value - oldValue, true);
				changed.addChangedItem(oic);
			}
		}
	}

	/**
	 * @brief changed里增加Int类型改变
	 */
	public void addIntPropertyChangedItem(int id, int value, boolean notify, boolean overwrite, boolean broadcast) {
		if (changed != null) {
			IntPropertyChangedItem ic = new IntPropertyChangedItem(id, value, false, overwrite, broadcast);
			changed.addChangedItem(ic);
			if (notify) {
				IntPropertyChangedItem oic = new IntPropertyChangedItem(id, value, true, overwrite, broadcast);
				changed.addChangedItem(oic);
			}
		}
	}

	class MoneyIntProperty extends TransactionIntProperty implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = -1330004901944843849L;

		@Override
		public int getMaxValue() {
			return Integer.MAX_VALUE;
		}

		@Override
		public int getValue() {
			return money;
		}

		@Override
		protected void modifyValue(int value, boolean notify, String cause) {
			setMoney(money + value, notify, cause);
		}
	}

	class ExpIntProperty extends TransactionIntProperty implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = -4444010440161411912L;

		@Override
		public int getMaxValue() {
			return Integer.MAX_VALUE;
		}

		@Override
		public int getValue() {
			return exp;
		}

		@Override
		protected void modifyValue(int value, boolean notify, String cause) {
			setExp(exp + value, notify, cause);
		}

	}

	class GoldIntProperty extends TransactionIntProperty implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = -5167458280617921784L;

		@Override
		public int getValue() {
			return gold;
		}

		@Override
		public int getMaxValue() {
			return Integer.MAX_VALUE;
		}

		@Override
		protected void modifyValue(int value, boolean notify, String cause) {
			setGold(gold + value, notify, cause);
		}

	}

	class TiLiIntProperty extends TransactionIntProperty implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 7445492311613305686L;

		@Override
		public int getValue() {
			return tili;
		}

		@Override
		public int getMaxValue() {
			return Integer.MAX_VALUE;
		}

		@Override
		protected void modifyValue(int value, boolean notify, String cause) {
			setTili(tili + value, notify, cause);
		}

	}
	
	class ActivityCoinIntProperty extends TransactionIntProperty implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = -1678522168574954594L;

		@Override
		public int getValue() {
			return activityCoin;
		}

		@Override
		public int getMaxValue() {
			return Integer.MAX_VALUE;
		}

		@Override
		protected void modifyValue(int value, boolean notify, String cause) {
			setActivityCoin(activityCoin + value, notify, cause);
		}
		
	}

	public void addAttributeByType(AttributeType attributeType, int currencyCount, PlayerTransaction tx) {

		switch (attributeType) {
		case MONEY:
			addMoney(currencyCount, tx, false);
			break;
		case GOLD:
			addGold(currencyCount, tx, false);
			break;
		case ACTIVITY_COIN:
			addActivityCoin(currencyCount, tx, false);
			break;
		default:
			break;
		}
	}

	public void setActivityCoin(int value, boolean notify, String cause) {
		if (value >= 0 && this.activityCoin != value) {
			int oldActivityCoin = this.activityCoin;
			this.activityCoin = value;
			if (oldActivityCoin != this.activityCoin) {
				addIntPropertyChangedItem(ChangedItem.TILI, oldActivityCoin, this.activityCoin, notify);
				if (this.activityCoin > oldActivityCoin) {
					Log.getInstance().logAddActivityCoin(this, oldActivityCoin, activityCoin, cause);
				} else {
					Log.getInstance().logDecActivityCoin(this, oldActivityCoin, activityCoin, cause);
				}
			}
		}
	}

	public int getAttributeByType(int attributeType) {
		int attributeValue = 0;
		switch (attributeType) {
		case 101:
			attributeValue = getMoney();
			break;
		case 102:
			attributeValue = getGold();
			break;
		case 103:
			attributeValue = getActivityCoin();
			break;
		default:
			break;
		}
		return attributeValue;
	}

	/**
	 * 重置
	 */
	public void resetValueOnday() {
		if (this.getLastLoginDay() != Time.day) {
			this.getPool().setInt(Const.PROPERTY_PLAYER_BUY_TILI_COUNT, 0);// 当天购买体力次数
			this.getPool().setInt(Const.PROPERTY_LOGIN_COUNTS, this.getPool().getInt(Const.PROPERTY_LOGIN_COUNTS) + 1);
			this.getPool().setInt(Const.COMMIT_BUG, 0);// 重置提交bug的次数
			this.setLastLoginDay(Time.day);
			this.getPool().setInt(Const.PROPERTY_PLAYER_BUY_GOLD_COUNT, 0);//当天购买金币次数
			logger.info("每日重置属性playerId=" + this.getId() + ",name=" + this.getName());
		}
	}

	/**
	 * 初始化背包
	 * 
	 * @return
	 */
	public Bags initBags() {
		Bags bags = new Bags(this, 4, 1);
		Bag goodsBag = new Bag(bags, Const.BAG_CONSUME, 1000, 0);// 消耗品背包
		Bag equipBag = new Bag(bags, Const.BAG_EQUIP, 1000, 0);// 服装类背包
		Bag actionBag = new Bag(bags, Const.BAG_ACTION, 50, 0);// 动作类背包
		Bag effectBag = new Bag(bags, Const.BAG_EFFECT, 50, 0);// 特效类背包
		Bag xieZhenBag = new Bag(bags, Const.BAG_XIEZHEN, 50, 0);// 写真类背包
		Bag aviBag = new Bag(bags, Const.BAG_AVI, 50, 0);// 视频类背包
		Bag photoFrameBag = new Bag(bags, Const.BAG_PHOTO_FRAME, 50, 0);// 相框类背包
		bags.addBag(goodsBag);
		bags.addBag(equipBag);
		bags.addBag(actionBag);
		bags.addBag(effectBag);
		bags.addBag(xieZhenBag);
		bags.addBag(aviBag);
		bags.addBag(photoFrameBag);
		return bags;
	}

	public TIntObjectMap<PlayerAchievement> getAchivements() {
		return achivements;
	}

	public void setAchivements(TIntObjectMap<PlayerAchievement> achivements) {
		this.achivements = achivements;
	}

	public void setBuyGoldCounts() {
		int oldBuyGoldCounts = getPool().getInt(Const.PROPERTY_BUT_GOLD_COUNTS);
		getPool().setInt(Const.PROPERTY_BUT_GOLD_COUNTS, oldBuyGoldCounts + 1);
	}

	public void setGainGoldCounts(int gainGoldCounts) {
		int oldGainGoldCounts = getPool().getInt(Const.PROPERTY_GAIN_GOLD_COUNTS);
		getPool().setInt(Const.PROPERTY_GAIN_GOLD_COUNTS, oldGainGoldCounts + gainGoldCounts);
	}

	public int getSignGirlCounts() {
		return signGirlCounts;
	}

	public void setSignGirlCounts(int signGirlCounts) {
		this.signGirlCounts = signGirlCounts;
	}

	public int getSignForeverGirlCounts() {
		return signForeverGirlCounts;
	}

	public void setSignForeverGirlCounts(int signForeverGirlCounts) {
		this.signForeverGirlCounts = signForeverGirlCounts;
	}

	public int getAchieveValue() {
		return achieveValue;
	}

	public void setAchieveValue(int achieveValue) {
		this.achieveValue = achieveValue;
	}

	public int getGuideStep() {
		return guideStep;
	}

	public void setGuideStep(int guideStep) {
		this.guideStep = guideStep;
	}
	
	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public static void main(String args[]) {
		int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
		System.out.println(hour);
	}

	public void addSendGirlGiftCounts(int girlId, int count) {
		int sendGirlGiftCount = this.getPool().getInt(Const.PROPERTY_SEND_GIRL_GIFT_COUNTS + "_" + girlId, 0);
		this.getPool().setInt(Const.PROPERTY_SEND_GIRL_GIFT_COUNTS + "_" + girlId, sendGirlGiftCount + count);
	}

	public void addBuyClothCounts(int type) {
		int buyCounts = this.getPool().getInt(Const.PROPERTY_BUY_CLOTH_COUNTS + "_" + type);
		this.getPool().setInt(Const.PROPERTY_BUY_CLOTH_COUNTS + "_" + type, buyCounts + 1);
		int lastBuyClothDay = this.getPool().getInt(Const.PROPERTY_LAST_BUY_CLOTH_DAY);
		if(Time.day != lastBuyClothDay) {
			if (Time.day - lastBuyClothDay == 1) {
				int continuLoinCounts = getPool().getInt(Const.PROPERTY_CONTINU_BUY_CLOTH_COUNTS);
				getPool().setInt(Const.PROPERTY_CONTINU_BUY_CLOTH_COUNTS, continuLoinCounts + 1);
			} else if (Time.day - lastBuyClothDay > 1) {
				getPool().setInt(Const.PROPERTY_CONTINU_BUY_CLOTH_COUNTS, 1);
			}
			getPool().setInt(Const.PROPERTY_LAST_BUY_CLOTH_DAY, Time.day);
		}
	}

	public int getPlayerRefreshPlayerShopCounts() {
		int lastRefreshDay = getPool().getInt(Const.LAST_REFRESH_PLAYER_SHOP_DAY);
		if(lastRefreshDay != Time.day) {
			getPool().setInt(Const.LAST_REFRESH_PLAYER_SHOP_DAY, Time.day);
			return getPool().setInt(Const.REFRESH_PLAYER_SHOP_COUNT, 0);
		}
		return getPool().getInt(Const.REFRESH_PLAYER_SHOP_COUNT);
	}
	
	public void setPlayerRefeshShopCounts(int count) {
		int lastRefreshDay = getPool().getInt(Const.LAST_REFRESH_PLAYER_SHOP_DAY);
		if(lastRefreshDay != Time.day) {
			getPool().setInt(Const.LAST_REFRESH_PLAYER_SHOP_DAY, Time.day);
		}
		getPool().setInt(Const.REFRESH_PLAYER_SHOP_COUNT, count);
	}
	
}
