package com.gamedo.gameServer.entity.girl;

import java.io.Serializable;

/**
 * 玩家对应所有模特历史使用记录
 * 
 * @author libm
 *
 */
public class SingleGirlHistoryUseRecord implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6547030866916603061L;

	private int id;

	private int playerId;

	private int girlId;

	private int useCounts;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public int getUseCounts() {
		return useCounts;
	}

	public void setUseCounts(int useCounts) {
		this.useCounts = useCounts;
	}
	
}
