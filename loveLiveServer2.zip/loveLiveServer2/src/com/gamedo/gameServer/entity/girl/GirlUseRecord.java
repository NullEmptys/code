package com.gamedo.gameServer.entity.girl;

import java.io.Serializable;

/**
 * 模特使用记录表
 * @author libm
 *
 */
public class GirlUseRecord implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8866931331092058217L;

	private int id;
	
	/**
	 * 模特id
	 */
	private int girlId;
	
	/**
	 * 周
	 */
	private int week;
	
	/**
	 * 模特被使用次数
	 */
	private int useCounts;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGirlId() {
		return girlId;
	}

	public void setGirlId(int girlId) {
		this.girlId = girlId;
	}

	public int getUseCounts() {
		return useCounts;
	}

	public void setUseCounts(int useCounts) {
		this.useCounts = useCounts;
	}

	public int getWeek() {
		return week;
	}

	public void setWeek(int week) {
		this.week = week;
	}
	
}
