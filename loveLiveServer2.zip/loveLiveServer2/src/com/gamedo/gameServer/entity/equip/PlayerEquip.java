package com.gamedo.gameServer.entity.equip;

import java.io.Serializable;
import java.util.Date;

/**
 * @author IPOC-HUANGPING
 *
 */
public class PlayerEquip implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int id;
	private int equipId;// 服装id
	private String attribute;// 服装风格属性值
	private int level;// 服装等级
	private int qualtity;// 服装品质
	private Date createTime;// 获得时间

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEquipId() {
		return equipId;
	}

	public void setEquipId(int equipId) {
		this.equipId = equipId;
	}

	public String getAttribute() {
		return attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getQualtity() {
		return qualtity;
	}

	public void setQualtity(int qualtity) {
		this.qualtity = qualtity;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}