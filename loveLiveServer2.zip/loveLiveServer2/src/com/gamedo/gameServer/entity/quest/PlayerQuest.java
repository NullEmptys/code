package com.gamedo.gameServer.entity.quest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.gamedo.gameServer.util.JsonUtil;

/**
 * 玩家任务
 * @author libm
 *
 */
public class PlayerQuest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2086634928982591866L;
	
	public static final int COMMON = 0;//激活
	public static final int ACCEPTER = 1;//已接受状态
	public static final int FINISHED = 2;//已完成
	
	private int id;
	private int playerId;
	private int chapterId;
	/**章节子关卡id*/
	private int questId;
	private int score;
	/**评级*/
	private int scoreLevel;
	private int state;
	/**完成任务所穿服装*/
	private String lastClothIdsStr;
	private String maxScoreClothIdsStr;
	private List<Integer> lastClothIds;
	private List<Integer> maxScoreClothIds;
	/**首次完美通关奖励 1、已发  0、否*/
	private int perfectRewarded;
	/**首次通关奖励 1、已发  0、否*/
	private int firstSuccessRewarded;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getQuestId() {
		return questId;
	}
	public void setQuestId(int questId) {
		this.questId = questId;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public int getScoreLevel() {
		return scoreLevel;
	}
	public void setScoreLevel(int scoreLevel) {
		this.scoreLevel = scoreLevel;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getChapterId() {
		return chapterId;
	}
	public void setChapterId(int chapterId) {
		this.chapterId = chapterId;
	}
	public String getLastClothIdsStr() {
		return lastClothIdsStr;
	}
	public void setLastClothIdsStr(String lastClothIdsStr) {
		this.lastClothIdsStr = lastClothIdsStr;
	}
	public String getMaxScoreClothIdsStr() {
		return maxScoreClothIdsStr;
	}
	public void setMaxScoreClothIdsStr(String maxScoreClothIdsStr) {
		this.maxScoreClothIdsStr = maxScoreClothIdsStr;
	}
	public List<Integer> getLastClothIds() {
		if(lastClothIds == null) {
			if(lastClothIdsStr != null) {
				lastClothIds = JsonUtil.fromJsonList(lastClothIdsStr, Integer.class);
			}
		}
		return lastClothIds;
	}
	public void setLastClothIds(List<Integer> lastClothIds) {
		this.lastClothIds = lastClothIds;
		if(lastClothIds != null) {
			this.lastClothIdsStr = JsonUtil.toJson(lastClothIds);
		}
	}
	public List<Integer> getMaxScoreClothIds() {
		if(maxScoreClothIds == null) {
			if(maxScoreClothIds != null) {
				maxScoreClothIds = JsonUtil.fromJsonList(maxScoreClothIdsStr, Integer.class);
			}
		}
		return maxScoreClothIds;
	}
	public void setMaxScoreClothIds(List<Integer> maxScoreClothIds) {
		this.maxScoreClothIds = maxScoreClothIds;
		if(maxScoreClothIds != null) {
			this.maxScoreClothIdsStr = JsonUtil.toJson(maxScoreClothIds);
		}
	}
	public int getPerfectRewarded() {
		return perfectRewarded;
	}
	public void setPerfectRewarded(int perfectRewarded) {
		this.perfectRewarded = perfectRewarded;
	}
	public int getFirstSuccessRewarded() {
		return firstSuccessRewarded;
	}
	public void setFirstSuccessRewarded(int firstSuccessRewarded) {
		this.firstSuccessRewarded = firstSuccessRewarded;
	}
}
