package com.gamedo.gameServer.entity.quest;

import java.io.Serializable;

/**
 * 玩家任务章节记录
 * @author libm
 *
 */
public class PlayerQuestChapter implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2795772132719451625L;
	
	public static final int REWARDED = 1;
	
	private int id;
	/**角色id*/
	private int playerId;
	/**章节id*/
	private int chapterId;
	private int counts;
	/**是否领取完章节奖励 0：未达成    1：已领*/
	private int state;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getChapterId() {
		return chapterId;
	}
	public void setChapterId(int chapterId) {
		this.chapterId = chapterId;
	}
	public int getCounts() {
		return counts;
	}
	public void setCounts(int counts) {
		this.counts = counts;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}

}
