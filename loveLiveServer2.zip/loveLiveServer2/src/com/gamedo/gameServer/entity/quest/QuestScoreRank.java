package com.gamedo.gameServer.entity.quest;

import java.io.Serializable;

public class QuestScoreRank implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3135656501022147267L;

	public int playerId;
	
	public int questId;
	
	public int score;

	public QuestScoreRank(int playerId,int questId,int score) {
		this.playerId = playerId;
		this.questId = questId;
		this.score = score;
	}
	
	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getQuestId() {
		return questId;
	}

	public void setQuestId(int questId) {
		this.questId = questId;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	
}
