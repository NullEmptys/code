//package com.gamedo.gameServer.entity.shop;
//
//import java.io.Serializable;
//
///**
// * 玩家服装商场购买记录
// * 
// * @author IPOC-HUANGPING
// *
// */
//public class PlayerShopBuyRec implements Serializable{
//	
//	/**
//	 * 
//	 */
//	private static final long serialVersionUID = 1L;
//	private int id;
//	private int playerId;
//	private String rec;// 玩家购买记录
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public int getPlayerId() {
//		return playerId;
//	}
//
//	public void setPlayerId(int playerId) {
//		this.playerId = playerId;
//	}
//
//	public String getRec() {
//		return rec;
//	}
//
//	public void setRec(String rec) {
//		this.rec = rec;
//	}
//
//}
