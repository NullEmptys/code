package com.gamedo.gameServer.entity.shop;

import java.io.Serializable;

/**
 * 玩家道具商城数据
 * @author libm
 *
 */
public class PlayerItemShop implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3950666472188260213L;

	private int id;
	
	private int playerId;
	/**
	 * 对应于shopItem表内主键Id字段的值
	 */
	private int shopItemId;
	
	private int buyCounts;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getShopItemId() {
		return shopItemId;
	}

	public void setShopItemId(int shopItemId) {
		this.shopItemId = shopItemId;
	}

	public int getBuyCounts() {
		return buyCounts;
	}

	public void setBuyCounts(int buyCounts) {
		this.buyCounts = buyCounts;
	}

}
