package com.gamedo.gameServer.entity.dailymission;

import java.io.Serializable;
import java.util.Date;
/**
 * 每日任务
 * @author IPOC-HUANGPING
 *
 */
public class PlayerDailyMission implements Serializable{

	/**
	 * 序列号
	 */
	private static final long serialVersionUID = 1L;
	/**任务已经开始，还没有达成*/
	public static final int STATUS_STARTED = -1;
	/**任务已经完成，还未领取奖励*/
	public static final int STATUS_FINISHED=0;
	/**已领取任务奖励*/
	public static final int STATUS_END=1;
	
	private int id;
	private int playerId;//玩家id
	private int missionDefineId;//任务定义id DailyMissionData id;
	private int missionCategoryId;//任务分类id
	private int missionProperty;//任务属性id
	private int missionDetail;//任务完成次数
	private int status;//任务状态-1为达成  0 已达成还未领取奖励  1 已领取
	private Date createTime;//任务开始时间
	private Date finishTime;//任务完成时间
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getMissionDefineId() {
		return missionDefineId;
	}
	public void setMissionDefineId(int missionDefineId) {
		this.missionDefineId = missionDefineId;
	}
	public int getMissionCategoryId() {
		return missionCategoryId;
	}
	public void setMissionCategoryId(int missionCategoryId) {
		this.missionCategoryId = missionCategoryId;
	}
	public int getMissionProperty() {
		return missionProperty;
	}
	public void setMissionProperty(int missionProperty) {
		this.missionProperty = missionProperty;
	}
	public int getMissionDetail() {
		return missionDetail;
	}
	public void setMissionDetail(int missionDetail) {
		this.missionDetail = missionDetail;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getFinishTime() {
		return finishTime;
	}
	public void setFinishTime(Date finishTime) {
		this.finishTime = finishTime;
	}
}
