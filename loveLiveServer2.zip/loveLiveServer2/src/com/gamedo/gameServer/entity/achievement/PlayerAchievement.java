package com.gamedo.gameServer.entity.achievement;

import java.io.Serializable;

/**
 * 
 * @author libm
 *
 */
public class PlayerAchievement implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -743905960532854158L;
	
	public int id;
	public boolean finished;
	public int value = 0;
	public boolean rewarded;
	
}
