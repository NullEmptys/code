package com.gamedo.gameServer.entity.achievement;

/**
 * 成就等级奖励领取记录
 * @author libm
 *
 */
public class AchieveLevelRewardRecord {

	private int id;
	/**
	 * 角色id
	 */
	private int playerId;
	/**
	 * 成就等级
	 */
	private int achieveLevel;
	/**
	 * 是否领取
	 * 1、是
	 * 0、否
	 */
	private int rewarded;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getAchieveLevel() {
		return achieveLevel;
	}

	public void setAchieveLevel(int achieveLevel) {
		this.achieveLevel = achieveLevel;
	}

	public int getRewarded() {
		return rewarded;
	}

	public void setRewarded(int rewarded) {
		this.rewarded = rewarded;
	}
	
}
