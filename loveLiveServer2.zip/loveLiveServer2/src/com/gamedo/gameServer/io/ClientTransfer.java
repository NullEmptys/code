package com.gamedo.gameServer.io;

/**
 * 
 * @author libm
 *
 */
public interface ClientTransfer {

	public byte[] toClientBytes();
}
