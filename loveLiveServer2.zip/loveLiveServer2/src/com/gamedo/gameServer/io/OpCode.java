package com.gamedo.gameServer.io;

/**
 * 消息协议号
 * @author libm
 *
 */
public class OpCode {

	public static final String DISPATCH = "/dispatch";
	
	/*创建角色*/
	public static final String CREATE_PLAYER = "/createPlayer";
	/*角色登录*/
	public static final String PLAYER_LOGIN = "/playerLogin";
	/*角色登出*/
	public static final String PLAYER_LOGOUT = "/playerLogout";
	/*修改角色名称*/
	public static final String CHANGE_PLAYER_NAME = "/changeName";
	
	/*邮件列表*/
	public static final String MAIL_LIST = "/mailList";
	/*阅读邮件*/
	public static final String MAIL_GET_CONTENT = "/mailGetContent";
	/*删除邮件*/
	public static final String MAIL_DELETE = "/mailDelete";
	/*清理信箱（删除已读无附件邮件）*/
	public static final String MAIL_CLEAR = "/mailclear";
	/*领取邮件附件*/
	public static final String MAIL_GET_ATTACHMENT = "/getAttachment";
	
	/*充值*/
	public static final String CHARGE = "/charge";
	
	/*购买体力*/
	public static final String BUY_TILI = "/buyTiLi";
	/*确认购买体力或者金币*/
	public static final String CONFIRM_BUY_TILI_OR_GOLD = "/confirmBuy";
	
	/*丢弃物品*/
	public static final String DELETE_ITEM = "/deleteItem";
	/*出售物品*/
	public static final String SELL_ITEM = "/sellItem";
	/*寄送物品*/
	public static final String SEND_ITEM = "/sendItem";
	
	/*保存模特当前穿着*/
	public static final String SAVE_GIRL_CLOTH = "/saveGirlCloth";
	
	/*道具商城列表*/
	public static final String SHOP_ITEM_LIST = "/shopItemList";
	/*购买商品*/
	public static final String BUY_ITEM = "/buyItem";
	/*刷新玩家道具商城*/
	public static final String REFRESH_PLAYER_SHOP_ITEM = "refreshPlayShop";
	/*购买玩家道具商城商品*/
	public static final String BUY_PLAYER_SHOP_ITEM = "buyPlayerShopItem";
	
	/*玩家最后章节任务列表*/
	public static final String QUEST_CHAPTER = "/questChapter";
	/*任务详情*/
	public static final String QUEST_INFO = "/questInfo";
	/*结束任务*/
	public static final String QUEST_FINISHED = "/questFinished";
	/*领取章节奖励*/
	public static final String CHAPTER_REWARD = "chapterReward";
	
	//获取当前玩家对应模特列表
	public static final String GET_GIRL_LIST = "/getGirlList";
	//模特升级
	public static final String UPDATE_GIRL_EXP = "/updateGirlExp";
	//模特续签
	public static final String GIRL_SIGNED = "/girlSigned";
	//重置模特心情
	public static final String RESET_PLAYERGIRL_MOOD = "/resetGirlMood";
	
	//模特周榜
	public static final String GIRL_TOTAL_RANK = "/girlTotalRank";
	//单个模特使用对应榜单
	public static final String SINGLE_GIRL_RANK = "/singleGirlRank";
	//成就榜单
	public static final String ACHIEVEMENT_RANK = "/achievementRank";
	
	//成就列表
	public static final String ACHIEVEMENT_LIST = "/achieveList";
	//领取成就奖励
	public static final String GET_ACHIEVE_REWARD = "/getAchieveReward";
	
	//同步数据
	public static final String SYNC_DATA = "/syncData";
	
	//约会
	public static final String ENGAGEMENT_GIRL = "/engagementGirl";
	//约会送礼
	public static final String SEND_GIFT = "/sendGift";
	//结束送礼
	public static final String FINISH_SEND_GIFT = "/finishSendGift";
	//进入猜拳界面开始猜拳
	public static final String GET_GUESS_ROUND = "/getGuessRound";
	//开始猜拳
	public static final String BEGIN_GUESS = "/beginGuess";
	//继续猜拳
	public static final String CONTINU_GUESS = "/continuGuess";
	//结束猜拳
	public static final String FINISH_GUESS = "/finishGuess";
	
	//社交模块获取角色基本信息
	public static final String GET_USER_INFO = "/userInfo";
	
	//上传头像
	public static final String UPLOAD_AVATAR = "/uploadAvatar";
	//上传头像前验证
	public static final String UPLOAD_CHECK = "/uploadCheck";
	//发放奖励
	public static final String SEND_REWARD = "/sendReward";
	
	//登录签到
	public static final String LOGIN_SIGN = "/loginSign";
	//登录签到界面
	public static final String LOGIN_REWARD_PAGE = "/loginRewardPage";
	//月签界面
	public static final String MONTH_SIGN_VIEW = "/monthSignView";
	//领取月签奖励
	public static final String MONTH_SING_REWARD = "/getMonthSignReward";
	//每日任务列表
	public static final String DAILY_MISSION="/dailyMissionView";
	//领取奖励
	public static final String GET_DAILY_MISSION_REWARD="/getDailyMissionReward";
	//每日任务点赞
	public static final String DAILY_MISSION_SOCIAL = "/socialmission";
	//自由拍摄里拍摄照片
	public static final String PHOTOGRAPH_INFO = "/photographInfo";
	
	//服务器当前时间
	public static final String CURRENT_TIME = "/currentTime";
	//设置新手引导的步骤
	public static final String SET_GUIDE = "/setGuide";
	//提交bug
	public static final String COMMIT_BUG = "/commitBug";
	//充值获得虚拟货币
	public static final String CHARGE_ADD_DIAMON="/appstoreCharge";
	//消费
	public static final String PAY = "/pay";
	
	//通知后援团  任务完成
	public static final String NOTIFY_QUEST_FINISHED = "/mission/done";
	public static final String NOTIFY_SUPPORT = "/user/support";
	/**解锁模特*/
	public static final String UNLOCK_MODEL = "/unlockmodel";
	/**模特升级*/
	public static final String MODEL_UP_LEVEL="/modelLevelUp";
	/*刷新体力值*/
	public static final String FLUSH_TILI_VALUE="/flushTili";
	
}
