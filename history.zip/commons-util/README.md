### 工具类
```
StringUtil      //isEmpty, isNumber
SplitUtil       //字符串拆分
EncryptUtil     //加密 md5 sha1 hmacsha1 hmacsha256 base64
HttpService     //模拟HttpClient
RandomUtil      //随机
MathUtil        //round, mod ...
TimeUtil        //currentTimeMillis, days, daysInWeek (基于1970.1.1时间差)
Collections     //IntHashMap, LongHashMap, ConcurrentHashMap, Bytes, Ints, Longs, SortedQueue, SortedSet
CollectionUtil  //isEmpty
```
