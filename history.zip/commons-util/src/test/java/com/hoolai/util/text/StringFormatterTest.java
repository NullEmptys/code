package com.hoolai.util.text;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 */
public class StringFormatterTest {
    
	
	@Before
	public void startUp(){
	}
	@Test
	public void test1arg() {
		assertEquals("aaacccbbbb",
		StringFormatter.format("aaa{}bbbb", "ccc")
		);
		assertEquals("aaa{d}bbbb",
				StringFormatter.format("aaa{d}bbbb", "ccc")
		);
	}

	@Test
	public void testEscape(){
		assertEquals("aaa{}bbbb",
				StringFormatter.format("aaa\\{}bbbb", "ccc")
		);
	}
	
	@Test
	public void testMultiArgs(){
		assertEquals("aaacccbbbbddddd",
				StringFormatter.format("aaa{}bbbb{}", "ccc", "ddddd")
		);
		assertEquals("aaacccbbbbdddddee",
				StringFormatter.arrayFormat("aaa{}bbbb{}{}", new String[]{"ccc", "ddddd", "ee"})
		);
		
		assertEquals("aaacccbbbbdddddee",
				StringUtil.format("aaa{}bbbb{}{}", new String[]{"ccc", "ddddd", "ee"})
		);
	}

}
