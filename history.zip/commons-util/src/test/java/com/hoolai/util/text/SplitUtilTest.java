package com.hoolai.util.text;

import java.util.Arrays;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;

public class SplitUtilTest {
	
	@SuppressWarnings("serial")
	@Test
	public void test() {
		Assert.assertArrayEquals(SplitUtil.splitToInts("1,2,3"), new int[]{1,2,3});
		Assert.assertEquals(SplitUtil.compact(new int[]{1,2,3}), "1,2,3");
		
		Assert.assertArrayEquals(SplitUtil.splitToLongs("1,2,3"), new long[]{1,2,3});
		Assert.assertEquals(SplitUtil.compact(new long[]{1,2,3}), "1,2,3");
		
		Assert.assertEquals(SplitUtil.splitToIntList("1,2,3"), Arrays.asList(1,2,3));
		Assert.assertEquals(SplitUtil.compactInts(Arrays.asList(1,2,3)), "1,2,3");
		
		Assert.assertEquals(SplitUtil.splitToLongList("1,2,3"), Arrays.asList(1L,2L,3L));
		Assert.assertEquals(SplitUtil.compactLongs(Arrays.asList(1L,2L,3L)), "1,2,3");
		
		Assert.assertEquals(SplitUtil.splitToIntMap("1,2|3,4"), new HashMap<Integer, Integer>(){{put(1, 2);put(3, 4);}});
		Assert.assertEquals(SplitUtil.compactIntMap(new HashMap<Integer, Integer>(){{put(1, 2);put(3, 4);}}), "1,2|3,4");
	}

}
