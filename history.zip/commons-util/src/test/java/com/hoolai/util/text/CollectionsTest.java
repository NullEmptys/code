package com.hoolai.util.text;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.hoolai.util.collection.Ints;
import com.hoolai.util.collection.Longs;
import com.hoolai.util.collection.Range;

public class CollectionsTest {

    @Test
    public void testInts() {
        List<Integer> ints = new Ints();
        ints.add(100);
        ints.remove(0);
        ints.add(0, 300);
        ints.remove(Integer.valueOf(300));
        Assert.assertTrue(ints.isEmpty());
        
        List<Long> longs = new Longs();
        longs.add(100L);
        longs.remove(0);
        longs.add(0, Long.MAX_VALUE);
        longs.remove(Long.valueOf(Long.MAX_VALUE));
        Assert.assertTrue(longs.isEmpty());
        longs.add(-10000L);
        Assert.assertFalse(longs.stream().filter(l->l>0).findAny().isPresent());
        longs.add(10000L);
        Assert.assertTrue(longs.stream().filter(l->l>0).findAny().isPresent());
        
        Assert.assertArrayEquals(new int[]{1,3}, Range.closed(1, 3, 2).stream().mapToInt(Integer::intValue).toArray());
        Assert.assertArrayEquals(new int[]{1,2,3}, Range.closed(1, 3).stream().mapToInt(Integer::intValue).toArray());
        Assert.assertArrayEquals(new int[]{1,2}, Range.open(1, 3).stream().mapToInt(Integer::intValue).toArray());
    }
    
}
