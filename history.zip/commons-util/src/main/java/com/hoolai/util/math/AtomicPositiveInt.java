package com.hoolai.util.math;

import java.util.concurrent.atomic.AtomicInteger;


/**
 * atomic psitive integer
 * @author luzj
 */
public class AtomicPositiveInt {
    
    private final AtomicInteger ai;
    
    public AtomicPositiveInt() {
        ai = new AtomicInteger();
    }
    
    public int generate() {
        for (;;) {
            int current = ai.get();
            int next = current + 1;
            if(next < 1) {
                next = 1;
            }
            if (ai.compareAndSet(current, next))
                return next;
        }
    }

}
