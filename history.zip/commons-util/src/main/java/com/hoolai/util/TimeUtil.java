package com.hoolai.util;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;


/**
 * 时间工具类
 * millis为TimeUtil.currentTimeMillis或者System.currentTimeMillis
 * 除以inDay, InHour结束的方法外 所有数据均表示距1970-1-1 0:0:0的差值
 * @author luzj
 */
public final class TimeUtil {
    
    public final static long defaultOffsetInMillis = TimeZone.getDefault().getRawOffset();
    public final static ZoneOffset defaultOffset = ZoneOffset.ofTotalSeconds((int) TimeUnit.MILLISECONDS.toSeconds(defaultOffsetInMillis));
    
    static TimeSource source = new DefaultStandardTimeSource(defaultOffsetInMillis);
    
    private TimeUtil() {
        //最好还是别用实例了吧
    }
    
    public static long currentTimeMillis(){
        return source.currentTimeMillis();
    }
    public static long currentTimeSeconds(){
        return TimeUnit.MILLISECONDS.toSeconds(source.currentTimeMillis());
    }
    public static long currentTimeDays(){
        return millisToDays(source.currentTimeMillis());
    }
    
    public static int millisToDays(long millis) {
        return (int) TimeUnit.MILLISECONDS.toDays(millis + source.timeDisfference);
    }
    public static int secondsToDays(long seconds) {
        return (int) TimeUnit.MILLISECONDS.toDays(TimeUnit.SECONDS.toMillis(seconds) + source.timeDisfference);
    }
    
    public static long daysToMillis(long days) {
        return TimeUnit.DAYS.toMillis(days) - source.timeDisfference;
    }
    public static long daysToSeconds(long days) {
        return TimeUnit.MILLISECONDS.toSeconds(TimeUnit.DAYS.toMillis(days) - source.timeDisfference);
    }

    //分钟
    public static int minutesInHour() {
        return millisToMinutesInHour(currentTimeMillis());
    }
    public static int millisToMinutesInHour(long millis) {
        return (int) (TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)));
    }
    public static int secondsToMinutesInHour(long seconds) {
        return (int) (TimeUnit.SECONDS.toMinutes(seconds) - TimeUnit.HOURS.toMinutes(TimeUnit.SECONDS.toHours(seconds)));
    }
    
    //小时
    public static int hoursInDay() {
        return millisToHoursInDay(source.currentTimeMillis());
    }
    //距离今天0点的小时数
    public static int millisToHoursInDay(long millis) {
    	return (int) TimeUnit.MILLISECONDS.toHours(millis - daysToMillis(millisToDays(millis)));
    }
    public static int secondsToHoursInDay(long seconds) {
        return (int) TimeUnit.SECONDS.toHours(seconds - daysToSeconds(secondsToDays(seconds)));
    }
    
    //days
    public static int daysInWeek() {
        return daysToDaysInWeek(currentTimeDays());
    }
    
    public static int daysToDaysInWeek(long days) {
        return (int) ((days - 3) % 7);
    }
    
    public static int millisToDaysInWeek(long millis) {
        return daysToDaysInWeek(millisToDays(millis));
    }
    
    public static LocalDate localDate() {
        return localDateTime().toLocalDate();
    }
    
    public static LocalDateTime localDateTime() {
        return LocalDateTime.ofInstant(instant(), defaultOffset);
    }
    
    public static Instant instant() {
        return Instant.ofEpochMilli(currentTimeMillis());
    }
    
    /*------------------For hack Time------------------*/
    
    /**
     * 往后推几小时
     * @param hours
     */
    public static void changeTimeDisfference(int hours) {
        source = new DefaultStandardTimeSource(defaultOffsetInMillis + TimeUnit.HOURS.toMillis(hours));
    }
    
    public static void useHackedStandardSource(){
        if(!(source instanceof HackedStandardTimeSource)){
            source = new HackedStandardTimeSource(defaultOffsetInMillis);
        }
    }
    
    /**
     * 用于测试更改当前时间
     * @param currentTimeMillis
     */
    public static void changeCurrentTimeForTest(long currentTimeMillis) {
        source = new HackedTimeSource(source.timeDisfference, currentTimeMillis);
    }
    
    /**
     * time source
     * @author luzj
     */
    public static abstract class TimeSource {
        
        public final long timeDisfference;
        
        public TimeSource(long timeDisfference) {
            this.timeDisfference = timeDisfference;
        }
        
        public abstract long currentTimeMillis();
        
    }
    
    public static final class DefaultStandardTimeSource extends TimeSource {
        
        public DefaultStandardTimeSource(long timeDisfference) {
            super(timeDisfference);
        }

        @Override
        public long currentTimeMillis() {
            return System.currentTimeMillis();
        }

    }
    
    /**
     * 使用独立线程模拟时间时间变更
     * 可以更改当前时间, 默认使用系统时间
     * 用于时间模拟
     * @author luzj
     */
    public static final class HackedTimeSource extends TimeSource {

        private volatile long currentTimeMillis;
        private volatile long lastExecTime;
        
        public HackedTimeSource(long timeDisfference) {
            this(timeDisfference, System.currentTimeMillis());
        }
        
        public HackedTimeSource(long timeDisfference, long currentTimeMillis) {
            super(timeDisfference);
            this.currentTimeMillis = currentTimeMillis;
            this.lastExecTime = System.currentTimeMillis();
            start();
        }
        
        private void start(){
            Thread t = new Thread(){
                @Override
                public void run() {
                    while(!Thread.interrupted()){
                        long now = System.currentTimeMillis();
                        currentTimeMillis += (now - lastExecTime);
                        lastExecTime = now;
                        try {
                            TimeUnit.SECONDS.sleep(1);
                        } catch (InterruptedException e) {
                            //ignore
                        }
                    }
                }
            };
            t.setDaemon(true);
            t.start();
        }
        
        @Override
        public long currentTimeMillis() {
            return currentTimeMillis;
        }
    }
    
    /**
     * 使用独立线程自增加时间
     * @author luzj
     */
    public static final class HackedStandardTimeSource extends TimeSource {
        
        private volatile long currentTimeMillis;
        
        public HackedStandardTimeSource(long timeDisfference) {
            super(timeDisfference);
        }
        
        {
            currentTimeMillis = System.currentTimeMillis();
            Thread t = new Thread(){
                @Override
                public void run() {
                    while(!Thread.interrupted()){
                        currentTimeMillis = System.currentTimeMillis();
                        try {
                            TimeUnit.MILLISECONDS.sleep(500);
                        } catch (InterruptedException e) {
                            //ignore
                        }
                    }
                }
            };
            t.setDaemon(true);
            t.start();
        }
        
        @Override
        public long currentTimeMillis() {
            return currentTimeMillis;
        }
    }
    
}