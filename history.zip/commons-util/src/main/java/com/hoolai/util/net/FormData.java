package com.hoolai.util.net;

import static com.hoolai.util.net.FormDatas.getBytes;

public class FormData {
    
    String name;
    String filename;
    String contentType;
    String contentTransferEncoding;
    byte[] content;
    
    public FormData withContentType(String contentType) {
        this.contentType = contentType;
        return this;
    }
    public FormData withContentTransferEncoding(String contentTransferEncoding) {
        this.contentTransferEncoding = contentTransferEncoding;
        return this;
    }
    public FormData withContent(byte[] content) {
        this.content = content;
        return this;
    }
    
    public static FormData of(String name) {
        FormData data = new FormData();
        data.name = name;
        return data;
    }
    public static FormData of(String name, String content) {
        return of(name).withContent(getBytes(content));
    }

    public byte[] keyBytes() {
        if(filename == null) {
            return getBytes(String.format("Content-Disposition: form-data; name=\"%s\"", name));
        } else {
            return getBytes(String.format("Content-Disposition: form-data; name=\"%s\"; filename=\"%s\"", name, filename));
        }
    }
    
    public byte[] typeBytes() {
        return getBytes(String.format("Content-Type: %s", contentType));
    }
    
    public byte[] encodingBytes() {
        return getBytes(String.format("Content-Transfer-Encoding: %s", contentTransferEncoding));
    }

    public byte[] valBytes() {
        return content;
    }

}
