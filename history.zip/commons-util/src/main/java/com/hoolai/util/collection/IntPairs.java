package com.hoolai.util.collection;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

public class IntPairs extends AbstractMap<Integer, Integer> {
    
    private static final int DEFAULT_INITIAL_CAPACITY = 32;

    private static final float DEFAULT_LOAD_FACTOR = 0.75f;

    private static final int MAXIMUM_CAPACITY = 1 << 30;

    private transient Entry[] table;

    private transient int size;

    private int threshold;

    private final float loadFactor;
    
    private transient volatile int modCount;

    public IntPairs() {
        this(DEFAULT_INITIAL_CAPACITY);
    }
    public IntPairs(int initialCapacity) {
        this(DEFAULT_INITIAL_CAPACITY, DEFAULT_LOAD_FACTOR);
    }
    public IntPairs(int initialCapacity, float loadFactor) {
        super();
        if (initialCapacity < 0) {
            throw new IllegalArgumentException("Illegal Capacity: " + initialCapacity);
        }
        if (loadFactor <= 0) {
            throw new IllegalArgumentException("Illegal Load: " + loadFactor);
        }
        if (initialCapacity == 0) {
            initialCapacity = 1;
        }
        if (initialCapacity > MAXIMUM_CAPACITY) {
            initialCapacity = MAXIMUM_CAPACITY;
        }

        this.loadFactor = loadFactor;
        table = new Entry[initialCapacity];
        threshold = (int) (initialCapacity * loadFactor);
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    final Entry getEntry(int key) {
        for (Entry e = table[indexFor(key, table.length)]; e != null; e = e.next) {
            if (e.key == key)
                return e;
        }
        return null;
    }
    
    public boolean containsKey(Object key) {
        if(key == null || !(key instanceof Integer)) {
            return false;
        }
        return containsKey(((Integer)key).intValue());
    }

    public boolean containsKey(int key) {
        return getEntry(key) != null;
    }

    static int indexFor(int h, int length) {
        return h & (length - 1);
    }

    public Integer get(Object key) {
        if(key == null || !(key instanceof Integer)) {
            return null;
        }
        return get(((Integer)key).intValue());
    }
    
    public Integer get(int key) {
        Entry tab[] = table;
        int index = indexFor(key, table.length);
        for (Entry e = tab[index]; e != null; e = e.next) {
            if (e.key == key) {
                return e.value;
            }
        }
        return null;
    }

    void resize(int newCapacity) {
        Entry[] oldTable = table;
        int oldCapacity = oldTable.length;
        if (oldCapacity == MAXIMUM_CAPACITY) {
            threshold = Integer.MAX_VALUE;
            return;
        }

        Entry[] newTable = new Entry[newCapacity];
        transfer(newTable);
        table = newTable;
        threshold = (int) (newCapacity * loadFactor);
    }

    void transfer(Entry[] newTable) {
        Entry[] src = table;
        int newCapacity = newTable.length;
        for (int j = 0; j < src.length; j++) {
            Entry e = src[j];
            if (e != null) {
                src[j] = null;
                do {
                    Entry next = e.next;
                    int i = indexFor(e.key, newCapacity);
                    e.next = newTable[i];
                    newTable[i] = e;
                    e = next;
                } while (e != null);
            }
        }
    }

    public Integer put(Integer key, Integer value) {
        Entry tab[] = table;
        int index = indexFor(key, table.length);
        for (Entry e = tab[index]; e != null; e = e.next) {
            if (e.key == key) {
                int old = e.value;
                e.value = value;
                return old;
            }
        }

        modCount++;
        addEntry(key, value, index);
        return 0;
    }

    void addEntry(int key, int value, int bucketIndex) {
        Entry e = table[bucketIndex];
        table[bucketIndex] = new Entry(key, value, e);
        if (++size > threshold) {
            resize(2 * table.length);
        }
    }
    
    public boolean contains(Object value) {
        if (value == null || !(value instanceof Integer)) {
            return false;
        }
        int val = (Integer) value;
        Entry[] tab = table;
        for (int i = tab.length; i-- > 0;) {
            for (Entry e = tab[i]; e != null; e = e.next) {
                if (e.value == val) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean containsValue(Object value) {
        return contains(value);
    }
    
    public Integer remove(Object key) {
        if(key == null || !(key instanceof Integer)) {
            return null;
        }
        return remove(((Integer)key).intValue());
    }

    public Integer remove(int key) {
        Entry tab[] = table;
        int index = indexFor(key, table.length);
        for (Entry e = tab[index], prev = null; e != null; prev = e, e = e.next) {
            if (e.key == key) {
                modCount ++;
                if (prev != null) {
                    prev.next = e.next;
                } else {
                    tab[index] = e.next;
                }
                size--;
                Integer oldValue = e.value;
                e.value = 0;
                return oldValue;
            }
        }
        return null;
    }

    public void clear() {
        modCount ++;
        Entry tab[] = table;
        for (int index = tab.length; --index >= 0;) {
            tab[index] = null;
        }
        size = 0;
    }
    
    private transient Set<java.util.Map.Entry<Integer, Integer>> entrySet = null;
    
    public Set<java.util.Map.Entry<Integer, Integer>> entrySet() {
        Set<java.util.Map.Entry<Integer, Integer>> es = entrySet;
        return es != null ? es : (entrySet = new EntrySet());
    }

    private final class EntrySet extends AbstractSet<java.util.Map.Entry<Integer, Integer>> {
        public Iterator<java.util.Map.Entry<Integer, Integer>> iterator() {
            return new EntryIterator();
        }
        public boolean contains(Object o) {
            if (!(o instanceof Map.Entry))
                return false;
            
            Entry e = (Entry) o;
            Entry candidate = getEntry(e.getKey());
            return candidate != null && candidate.equals(e);
        }
        
        public boolean remove(Object o) {
            if (!(o instanceof Entry))
                return false;
            
            return IntPairs.this.remove(((Entry) o ).key) != null;
        }
        public int size() {
            return size;
        }
        
        public void clear() {
            IntPairs.this.clear();
        }
    }
    
    private final class EntryIterator extends IntHashIterator<java.util.Map.Entry<Integer, Integer>>{
        @Override
        public Entry next() {
            return nextEntry();
        }
    }
    
    private abstract class IntHashIterator<V> implements Iterator<V> {
        Entry next;
        int expectedModCount;
        int index;
        Entry current;

        IntHashIterator() {
            expectedModCount = modCount;
            if (size > 0) {
                Entry[] t = table;
                while (index < t.length && (next = t[index++]) == null);
            }
        }

        public final boolean hasNext() {
            return next != null;
        }

        final Entry nextEntry() {
            if (modCount != expectedModCount)
                throw new ConcurrentModificationException();
            Entry e = next;
            if (e == null)
                throw new NoSuchElementException();

            if ((next = e.next) == null) {
                Entry[] t = table;
                while (index < t.length && (next = t[index++]) == null)
                    ;
            }
            current = e;
            return e;
        }

        public void remove() {
            if (current == null)
                throw new IllegalStateException();
            if (modCount != expectedModCount)
                throw new ConcurrentModificationException();
            int k = current.key;
            current = null;
            IntPairs.this.remove(k);
            expectedModCount = modCount;
        }
    }
    
    public static class Entry implements java.util.Map.Entry<Integer, Integer>{
        final int key;// hash also key, not used key
        int value;
        Entry next;

        Entry(int key, int value, Entry next) {
            this.key = key;
            this.value = value;
            this.next = next;
        }

        public Integer getKey() {
            return key;
        }

        public Integer getValue() {
            return value;
        }

        public Integer setValue(Integer value) {
            int o = this.value;
            this.value = value;
            return o;
        }
    }

}
