package com.hoolai.util.net;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import com.hoolai.util.collection.Bytes;
import com.hoolai.util.log.Log;
import com.hoolai.util.text.CharsetUtil;
import com.hoolai.util.text.StringUtil;

/**
 * 
 * Java http methods util
 * Thread safe
 * @author luzj
 *
 */
public class HttpService {
    
    private final int timeout;// 默认10秒超时
    
    public HttpService() {
        this(10000);
    }
    
    public HttpService(int timeout) {
        this.timeout = timeout;
    }

    //http post, charset utf8
	public Response post(String url, String data, Request... reqs){
        return post(url, data, CharsetUtil.UTF8, reqs);
    }
	//http post
    public Response post(String url, String data, Charset charset, Request... reqs){
        return service(url, data, "POST", charset, reqs);
    }
    
    public Response post(String url, byte[] data, Charset charset, Request... reqs) {
        return service(url, data, "POST", charset, reqs);
    }

    //http put, charset utf8
    public Response put(String url, String data, Request... reqs){
        return put(url, data, CharsetUtil.UTF8, reqs);
    }
    //http put
    public Response put(String url, String data, Charset charset, Request... reqs){
        return service(url, data, "PUT", charset, reqs);
    }
    
  //http delete, charset utf8
    public Response delete(String url, String data, Request... reqs){
        return delete(url, data, CharsetUtil.UTF8, reqs);
    }
    //http delete
    public Response delete(String url, String data, Charset charset, Request... reqs){
        return service(url, data, "DELETE", charset, reqs);
    }
    
    //http options, charset utf8
    public Response options(String url, String data, Request... reqs){
        return options(url, data, CharsetUtil.UTF8, reqs);
    }
    //http options
    public Response options(String url, String data, Charset charset, Request... reqs){
        return service(url, data, "OPTIONS", charset, reqs);
    }
    
    //http get, charset utf8
    public Response get(String url, Request... reqs){
        return get(url, CharsetUtil.UTF8, reqs);
    }
    //http get
    public Response get(String url, Charset charset, Request... reqs){
        return service(url, "", "GET", charset, reqs);
    }
    
    private Response service(String url, String data, String method, Charset charset, Request... reqs){
        byte[] rdata = StringUtil.isEmpty(data) ? null : data.getBytes(charset);
        return service(url, rdata, method, charset, reqs);
    }

    private Response service(String url, byte[] data, String method, Charset charset, Request... reqs){
        HttpURLConnection conn = null;
        try {
            boolean doOutput = data != null;
            conn = buildConn(url, method, doOutput);

            addRequests(conn, reqs);

            if(doOutput) writeReqData(conn, data);
            
            int code = conn.getResponseCode();
            if(code == 200) {
                return new Response(code, conn.getResponseMessage(), readRespContent(conn, charset));
            } else {
                return new Response(code, conn.getResponseMessage(), readRespMessage(conn, charset));
            }
        } catch (Exception ex) {
            //ingore
            Log.warn("Http Service error cause: {}", ex.getMessage());
            return new Response(-1, ex.getMessage(), "");
        } finally {
            if (conn != null) {
                conn.disconnect();
                conn = null;
            }
        }
    }

    private String readRespContent(HttpURLConnection conn, Charset charset) throws IOException {
        InputStream input = null;
        try {
            input = conn.getInputStream();
            return new Bytes(1024).readFrom(input).toString(charset);
        } finally {
            if(input != null) {
                input.close();
            }
        }
    }
    
    private String readRespMessage(HttpURLConnection conn, Charset charset) throws IOException {
        InputStream input = null;
        try {
            input = conn.getErrorStream();
            return new Bytes(1024).readFrom(input).toString(charset);
        } finally {
            if(input != null) {
                input.close();
            }
        }
    }

    private void writeReqData(HttpURLConnection conn, byte[] postData) throws IOException {
        DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
        dos.write(postData);
        dos.flush();
        dos.close();
    }

    private void addRequests(HttpURLConnection conn, Request... reqs) {
        if(reqs == null){
            return;
        }

        for (Request req : reqs) {
            if(req == null){
                continue;
            }
            conn.addRequestProperty(req.key, req.value);
        }
    }
    
    private static boolean httpsNotConfigured = true;
    private HttpURLConnection buildConn(String url, String method, boolean doOutput) throws Exception, IOException {
        URL netURL = new URL(url);
        if(httpsNotConfigured && "https".equals(netURL.getProtocol())) {
            configureHttpsVerifierAndCertificates();
            httpsNotConfigured = false;
        }
        return buildHttpConn(netURL, method, doOutput);
    }
    
    private HttpURLConnection buildHttpConn(URL url, String method, boolean doOutput) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setReadTimeout(timeout);
        conn.setRequestMethod(method);
        conn.setDoOutput(doOutput);
        conn.setDoInput(true);
        return conn;
    }
    
    private static void configureHttpsVerifierAndCertificates() throws Exception {
        configureHttpsVerifier();
        configureHttpsCertificates();
    }

    private static void configureHttpsVerifier() {
        HostnameVerifier hv = new HostnameVerifier() {
            public boolean verify(String urlHostName, SSLSession session) {
                return true;
            }
        };
        HttpsURLConnection.setDefaultHostnameVerifier(hv);
    }
    
    private static void configureHttpsCertificates() throws Exception {
        //  Create a trust manager that does not validate certificate chains:
        javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[1];
        
        javax.net.ssl.TrustManager tm = new miTM();

        trustAllCerts[0] = tm;

        javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("SSL");

        sc.init(null, trustAllCerts, null);

        javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
    }
    
    public static class miTM implements javax.net.ssl.TrustManager, javax.net.ssl.X509TrustManager {
        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
            return null;
        }

        public boolean isServerTrusted(
                java.security.cert.X509Certificate[] certs) {
            return true;
        }

        public boolean isClientTrusted(
                java.security.cert.X509Certificate[] certs) {
            return true;
        }

        public void checkServerTrusted(
                java.security.cert.X509Certificate[] certs, String authType) throws
                java.security.cert.CertificateException {
            return;
        }

        public void checkClientTrusted(
                java.security.cert.X509Certificate[] certs, String authType) throws
                java.security.cert.CertificateException {
            return;
        }
    }

}
