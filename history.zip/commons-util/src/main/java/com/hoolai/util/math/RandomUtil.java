package com.hoolai.util.math;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * 
 * @author luzj
 *
 */
public class RandomUtil {

	private static Random random = new Random();

	private static Random getR() {
		return random;
	}

	/**
	 * 开区间
	 * @return
	 */
	public static int randomOpenNum(int max) {
		return randomOpenNum(0, max);
	}
	
	/**
	 * 开区间
	 * [min, max)
	 * @param min
	 * @param max
	 * @return
	 */
	public static int randomOpenNum(int min, int max) {
		int result = getR().nextInt((max - min) << 5);
		return (result >> 5) + min;
	}
	
	/**
	 * 闭区间
	 * @param max
	 * @return [0, max]
	 */
	public static int randomCloseNum(int max) {
		return randomCloseNum(0, max);
	}

	/**
	 * 闭区间
	 * @param min
	 * @param max
	 * @return [min, max]
	 */
	public static int randomCloseNum(int min, int max) {
		int result = getR().nextInt((max - min + 1) << 5);
		return (result >> 5) + min;
	}

	/**
	 * @param min
	 * @param max
	 * @return [min, max)
	 */
	public static float randomOpenNum(float min, float max) {
		return getR().nextFloat() * (max - min) + min;
	}

	/**
	 * @param choices
	 * @return index
	 */
	public static int randomByChoices(int[] choices) {
		int sum = 0;
		for (int i : choices) {
			sum += i;
		}

		int r = randomCloseNum(1, sum);
		int total = 0;
		for (int i = 0; i < choices.length; i++) {
			total += choices[i];
			if (r <= total) {
				return i;
			}
		}

		throw new IllegalArgumentException("It can't be here!");
	}

	/**
	 * @param choices
	 * @param num
	 * @return index[], 下标数组
	 */
	public static int[] randomByChoices(int[] choices, int num) {
		if (choices.length < num) {
			throw new IllegalArgumentException("choices length must over the num to be randomed");
		}

		int[] ret = new int[num];

		// copy权重数组，防止修改
		int[] tmpChoices = new int[choices.length];

		System.arraycopy(choices, 0, tmpChoices, 0, choices.length);

		for (int i = 0; i < num; i++) {
			int ratioIndex = randomByChoices(tmpChoices);

			ret[i] = ratioIndex;

			tmpChoices[ratioIndex] = 0;
		}
		return ret;
	}

	public static int randomByChoices(float[] choices) {
		float sum = 0;
		for (float i : choices) {
			sum += i;
		}

		float f = getR().nextFloat();

		float total = 0;
		for (int i = 0; i < choices.length; i++) {
			total += choices[i] / sum;
			if (f <= total) {
				return i;
			}
		}

		throw new IllegalArgumentException("It can't be here!");
	}

	/**
	 * 按照百分比随机(src == 50.0f 则认为是如果 nextInt(99) < 50 ? true : false)
	 * @param src
	 * @return
	 */
	public static boolean randomByPercentage(float src) {
		return src > 100? true : getR().nextFloat() < (src / 100f);
	}
	
	public static int randomByPercentage(int[] pers) {
	    int rnd = getR().nextInt(100);
	    int tmp = 0;
	    for (int i = 0; i < pers.length; i++) {
	        tmp += pers[i];
	        if(rnd < tmp) {
	            return i;
	        }
	    }
	    return -1;
	}

	/**
	 * @return
	 */
	public static boolean randomBoolean() {
		return getR().nextBoolean();
	}

	/**
	 * @return [0, 1)
	 */
	public static float randomFloat() {
		return getR().nextFloat();
	}

	/**
	 * 随机count个不大于max的数字
	 * @param max
	 * @param count
	 * @return
	 */
	public static int[] randomMultiNums(int max, int count) {
		int[] num = new int[count];
		for (int i = 0; i < count; i++) {
			num[i] = randomCloseNum(max);
		}
		return num;
	}

	/**
	 * 随机count个不大于max的不重复的数字
	 * @param max
	 * @param count
	 * @return
	 */
	public static int[] randomMultiNoneRepeatedNums(int max, int count) {
		if (count > max + 1) {
			throw new IllegalArgumentException("bad params, too less choice.");
		}
		
		if(count == max + 1) {
			int[] ret = new int[count];
			for (int i = 0; i < count; i++) {
				ret[i] = i;
			}
			return ret;
		}
		
		Set<Integer> numSet = new HashSet<Integer>();
		while (numSet.size() < count) {
			numSet.add(randomCloseNum(max));
		}

		int[] nums = new int[count];
		int i = 0;
		for (Integer num : numSet) {
			nums[i] = num;
			i++;
		}
		return nums;
	}

	/**
	 * 按均分理论随机
	 * 数组中有可能为0的 需要忽略掉 [80,60,50,20]
	 */
	public static int randomByAverageChoice(float[] percentageArr) {
		float choice = randomFloat();
		float occurChoice = 1;
		float totalOccurChoice = 0;
		for (float percentage : percentageArr) {
			occurChoice *= (1 - percentage / 100);
			totalOccurChoice += percentage;
		}
		occurChoice = 1 - occurChoice;

		if (choice < occurChoice) {
			int index = 0;
			float currentIndexChoice = 0;
			for (float percentage : percentageArr) {
				currentIndexChoice += percentage / totalOccurChoice * occurChoice;
				if (choice < currentIndexChoice) {
					return index;
				}
				index++;
			}
		}
		return -1;
	}

}
