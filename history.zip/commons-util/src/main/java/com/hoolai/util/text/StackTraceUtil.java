package com.hoolai.util.text;

import java.io.PrintWriter;
import java.io.StringWriter;

public class StackTraceUtil {
    
    public static String getStackTrace(Throwable t) {
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            t.printStackTrace(pw);
            return sw.toString();
        } catch (Exception ex){
            return t.getMessage();
        }
    }

}
