package com.hoolai.util.net;

/**
 * @author luzj
 */
public class Response {

    /**
     * 状态码
     * http status code
     */
    public final int code;//http response code
    /**
     * http status message
     */
    public final String message;
    /**
     * code 为200时正常返回的请求内容
     */
    public final String content;//
    
    public Response(int code, String message, String content) {
        this.code = code;
        this.message = message;
        this.content = content;
    }
    
    @Override
    public String toString() {
        return "Response [code=" + code + ", message=" + message + ", content=" + content + "]";
    }
    
}
