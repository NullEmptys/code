package com.hoolai.util.text;

import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Formatter;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.SecretKeySpec;


/**
 * 加密工具类
 * @author luzj
 */
public class EncryptUtil {
    
    
    /*----------------------------BASE64------------------------*/
    public static String decodeBase64Url(String context) {
        context = fixPaddingBase64String(fixBase64String(context));
        return new String(Base64.decodeBase64(context.getBytes()));
    }

    private static String fixPaddingBase64String(String base64) {
        int paddingLength = base64.length() % 4 == 0 ? 0 : 4 - base64.length() % 4;
        for (int i = 0; i < paddingLength; i++) {
            base64 += "=";
        }
        return base64;
    }

    private static String fixBase64String(String context) {
        return context.replace("-", "+").replace("_", "/");
    }

    public static String encodeBase64Url(String context) {
        return encodeBase64(context).replace("+", "-").replace("/", "_").replace("=", "");
    }

    public static String encodeBase64(String txt) {
        return Base64.encodeBase64String(txt.getBytes(CharsetUtil.UTF8));
    }

    public static String decodeBase64(String txt) {
        return new String(Base64.decodeBase64(txt.getBytes(CharsetUtil.UTF8)), CharsetUtil.UTF8);
    }
	
	/*----------------------------MD5------------------------*/
	private static final String MD5_ALGORITHM = "MD5";
	
	/**
	 * 使用md5算法加密字符串
	 * @param x
	 * @return
	 */
	public static String md5(String x) {
		return md5_32(x).toString();
	}

	private static StringBuilder md5_32(String x) {
		MessageDigest messageDigest = null;
		try {
			messageDigest = MessageDigest.getInstance(MD5_ALGORITHM);
			messageDigest.reset();
			messageDigest.update(StringUtil.getBytesUtf8(x));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		byte[] byteArray = messageDigest.digest();
		StringBuilder md5SB = new StringBuilder();

		for (int i = 0; i < byteArray.length; i++) {
			if (Integer.toHexString(0xFF & byteArray[i]).length() == 1)
				md5SB.append("0").append(Integer.toHexString(0xFF & byteArray[i]));
			else
				md5SB.append(Integer.toHexString(0xFF & byteArray[i]));
		}

		return md5SB;
	}

	/**
	 * 使用md5算法加密字符串, 16位
	 * @param x
	 * @return
	 */
	public static String md5_16(String x) {
		return md5_32(x).substring(8, 24);
	}

	
	/*----------------------------SHA------------------------*/
	private static final String SHA1_ALGORITHM = "SHA-1";
    private static final String HMAC_SHA1_ALGORITHM = "HMACSHA1";
    private static final String HMAC_SHA256_ALGORITHM = "HMACSHA256";;
    
	/**
	 * 使用hmacSHA1加密并转换成16位字符串
	 * @param key
	 * @param data
	 * @return
	 */
	public static String hmacSHA1(String key, String data) {
		BigInteger hash = new BigInteger(1, hmacSHA1ToBytes(key, data));

		String hmac = hash.toString(16);
		if (hmac.length() % 2 != 0) {
			hmac = "0" + hmac;
		}
		return hmac;
	}

	/**
	 * 使用hmacSHA1算法加密
	 * @param key
	 * @param data
	 * @return
	 */
	public static byte[] hmacSHA1ToBytes(String key, String data) {
		try {
			// Get an hmac_sha1 key from the raw key bytes
			byte[] keyBytes = key.getBytes();
			SecretKeySpec signingKey = new SecretKeySpec(keyBytes, HMAC_SHA1_ALGORITHM);

			// Get an hmac_sha1 Mac instance and initialize with the signing key
			Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);
			mac.init(signingKey);

			return mac.doFinal(data.getBytes());
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @param key
	 * @param data
	 * @return
	 */
	public static String hmacsha256(String key, String data) {
		try {
			return new String(Base64.encodeBase64(hmacsha256ToBytes(key, data)), CharsetUtil.UTF8);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * @param key
	 * @param data
	 * @return
	 */
	public static byte[] hmacsha256ToBytes(String key, String data) {
		try {
			SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(), HMAC_SHA256_ALGORITHM);
			Mac mac = Mac.getInstance(HMAC_SHA256_ALGORITHM);
			mac.init(secretKeySpec);
			return mac.doFinal(data.getBytes());
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 使用hmacSHA1算法加密 并将加密后的内容转换成base64编码
	 * @param key
	 * @param data
	 * @return
	 */
	public static String hmacSHA1ToBase64(String key, String data) {
		byte[] encodeBase64 = Base64.encodeBase64(hmacSHA1ToBytes(key, data));
		return new String(encodeBase64, CharsetUtil.UTF8);
	}
	
	/**
	 * sha1算法
	 * @param scr
	 * @return
	 */
    public static String SHA1(String scr) {
        return SHA1(scr.getBytes());
    }

    public static String SHA1(byte[] bytes) {
        return toHexString(SHA1_0(bytes));
    }

    public static byte[] SHA1_0(byte[] bytes) {
        try {
            MessageDigest md = MessageDigest.getInstance(SHA1_ALGORITHM);
            return md.digest(bytes);
        } catch (NoSuchAlgorithmException nsae) {
            nsae.printStackTrace();
        }
        return null;
    }
    
	public static String toHexString(final byte[] hash) {
		Formatter formatter = new Formatter();
		for (byte b : hash) {
			formatter.format("%02x", b);
		}
		String hexString = formatter.toString();
		formatter.close();
		return hexString;
	}
	
	/*----------------------------AES------------------------*/
    private static final String AES_KEY_ALGORITHM = "AES";
    private static final String AES_CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";
    
    public static byte[] aesGenerateKey() {
        try {
            KeyGenerator kg = KeyGenerator.getInstance(AES_KEY_ALGORITHM);
            kg.init(128);
            return kg.generateKey().getEncoded();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    public static Key aesBytesToKey(byte[] key){
        return new SecretKeySpec(key, AES_KEY_ALGORITHM);
    }
    
    public static Cipher aesKeyToEncryptCipher(Key key) {
        try {
            Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            return cipher;
        } catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    public static byte[] aesEncrypt(byte[] data, byte[] key) {
        return aesEncrypt(data, aesBytesToKey(key));
    }
    
    public static byte[] aesEncrypt(byte[] data, Key key) {
        return aesEncrypt(data, aesKeyToEncryptCipher(key));
    }
    
    public static byte[] aesEncrypt(byte[] data, Cipher cipher) {
        try {
            return cipher.doFinal(data);
        } catch (IllegalBlockSizeException | BadPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }

    public static Cipher aesKeyToDecryptCipher(Key key) {
        try {
            Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key);
            return cipher;
        } catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    public static byte[] aesDecrypt(byte[] data, byte[] key) {
        return aesDecrypt(data, aesBytesToKey(key));
    }
    
    public static byte[] aesDecrypt(byte[] data, Key key) {
        return aesDecrypt(data, aesKeyToDecryptCipher(key));
    }
    
    public static byte[] aesDecrypt(byte[] data, Cipher cipher) {
        try {
            return cipher.doFinal(data);
        } catch (IllegalBlockSizeException | BadPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }
	
	
	/*----------------------------DES------------------------*/
	private static final String DES_KEY_ALGORITHM = "DES";
	private static final String DES_CIPHER_ALGORITHM = "DES/ECB/PKCS5Padding";

    /**
     * 初始化密钥
     * @return byte[] 密钥
     * @throws Exception
     */
    public static byte[] desGenerateKey() throws Exception {
        // 返回生成指定算法的秘密密钥的 KeyGenerator 对象
        KeyGenerator kg = KeyGenerator.getInstance(DES_KEY_ALGORITHM);
        // 初始化此密钥生成器，使其具有确定的密钥大小
        kg.init(56);
        // 生成一个密钥
        SecretKey secretKey = kg.generateKey();
        return secretKey.getEncoded();
    }

    /**
     * 转换密钥
     * @param key 二进制密钥
     * @return Key 密钥
     * @throws Exception
     */
    public static Key desBytesToKey(byte[] key) {
        try {
            // 实例化DES密钥规则
            DESKeySpec dks = new DESKeySpec(key);
            // 实例化密钥工厂
            SecretKeyFactory skf = SecretKeyFactory.getInstance(DES_KEY_ALGORITHM);
            // 生成密钥
            return skf.generateSecret(dks);
        } catch (InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    public static Cipher desKeyToEncryptCipher(Key key) {
        try {
            // 实例化
            Cipher cipher = Cipher.getInstance(DES_CIPHER_ALGORITHM);
            // 使用密钥初始化，设置为加密模式
            cipher.init(Cipher.ENCRYPT_MODE, key);
            return cipher;
        } catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    public static Cipher desKeyToDecryptCipher(Key key) {
        try {
            Cipher cipher = Cipher.getInstance(DES_CIPHER_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key);
            return cipher;
        } catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    
    public static byte[] desEncrypt(byte[] data, byte[] key) {
        return desEncrypt(data, desBytesToKey(key));
    }

    public static byte[] desEncrypt(byte[] data, Key key) {
        return desEncrypt(data, desKeyToDecryptCipher(key));
    }

    public static byte[] desEncrypt(byte[] data, Cipher cipher)  {
        try {
            return cipher.doFinal(data);
        } catch (IllegalBlockSizeException | BadPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }

    public static byte[] desDecrypt(byte[] data, byte[] key) {
        return desDecrypt(data, desBytesToKey(key));
    }

    public static byte[] desDecrypt(byte[] data, Key key) {
        return desDecrypt(data, desKeyToEncryptCipher(key));
    }

    public static byte[] desDecrypt(byte[] data, Cipher cipher) {
        try {
            return cipher.doFinal(data);
        } catch (IllegalBlockSizeException | BadPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }

	
	/*----------------------------RSA------------------------*/
    private static final String RSA_KEY_ALGORITHM = "RSA";
    private static final String RSA_SIGNATURE_ALGORITHM = "MD5WITHRSA";
    
    /**
     * 用私钥对信息生成数字签名
     * @param data
     *            加密数据
     * @param privateKey
     *            私钥
     * @return
     * @throws Exception
     */
    public static String rsaSignature(byte[] data, String privateKey) {
        try {
            // 解密由base64编码的私钥
            byte[] keyBytes = Base64.decodeBase64(privateKey);

            // 构造PKCS8EncodedKeySpec对象
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);

            // KEY_ALGORITHM 指定的加密算法
            KeyFactory keyFactory = KeyFactory.getInstance(RSA_KEY_ALGORITHM);

            // 取私钥匙对象
            PrivateKey priKey = keyFactory.generatePrivate(pkcs8KeySpec);

            // 用私钥对信息生成数字签名
            Signature signature = Signature.getInstance(RSA_SIGNATURE_ALGORITHM);
            signature.initSign(priKey);
            signature.update(data);

            return Base64.encodeBase64String(signature.sign());
        } catch (InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | SignatureException e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * 校验数字签名
     * @param data
     *            加密数据
     * @param publicKey
     *            公钥
     * @param sign
     *            数字签名
     * @return 校验成功返回true 失败返回false
     * @throws Exception
     * 
     */
    public static boolean rsaVerify(byte[] data, String publicKey, String sign) {
        try {
            // 解密由base64编码的公钥
            byte[] keyBytes = Base64.decodeBase64(publicKey);

            // 构造X509EncodedKeySpec对象
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);

            // KEY_ALGORITHM 指定的加密算法
            KeyFactory keyFactory = KeyFactory.getInstance(RSA_KEY_ALGORITHM);

            // 取公钥匙对象
            PublicKey pubKey = keyFactory.generatePublic(keySpec);

            Signature signature = Signature.getInstance(RSA_SIGNATURE_ALGORITHM);
            signature.initVerify(pubKey);
            signature.update(data);

            // 验证签名是否正常
            return signature.verify(Base64.decodeBase64(sign));
        } catch (InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | SignatureException e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * 解密<br>
     * 用私钥解密 http://www.5a520.cn http://www.feng123.com
     * @param data
     * @param key
     * @return
     * @throws Exception
     */
    public static byte[] rsaDecryptByPrivateKey(byte[] data, String key) {
        try {
            // 对密钥解密
            byte[] keyBytes = Base64.decodeBase64(key);

            // 取得私钥
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance(RSA_KEY_ALGORITHM);
            Key privateKey = keyFactory.generatePrivate(pkcs8KeySpec);

            // 对数据解密
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, privateKey);

            return cipher.doFinal(data);
        } catch (InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * 解密<br>
     * 用私钥解密
     * @param data
     * @param key
     * @return
     * @throws Exception
     */
    public static byte[] rsaDecryptByPublicKey(byte[] data, String key) {
        try {
            // 对密钥解密
            byte[] keyBytes = Base64.decodeBase64(key);

            // 取得公钥
            X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance(RSA_KEY_ALGORITHM);
            Key publicKey = keyFactory.generatePublic(x509KeySpec);

            // 对数据解密
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, publicKey);

            return cipher.doFinal(data);
        } catch (InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * 加密<br>
     * 用公钥加密
     * @param data
     * @param key
     * @return
     * @throws Exception
     */
    public static byte[] rsaEncryptByPublicKey(byte[] data, String key) {
        try {
            // 对公钥解密
            byte[] keyBytes = Base64.decodeBase64(key);

            // 取得公钥
            X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance(RSA_KEY_ALGORITHM);
            Key publicKey = keyFactory.generatePublic(x509KeySpec);

            // 对数据加密
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);

            return cipher.doFinal(data);
        } catch (InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }

    /**
     * 加密<br>
     * 用私钥加密
     * @param data
     * @param key
     * @return
     * @throws Exception
     */
    public static byte[] rsaEncryptByPrivateKey(byte[] data, String key) {
        try {
            // 对密钥解密
            byte[] keyBytes = Base64.decodeBase64(key);

            // 取得私钥
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance(RSA_KEY_ALGORITHM);
            Key privateKey = keyFactory.generatePrivate(pkcs8KeySpec);

            // 对数据加密
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, privateKey);

            return cipher.doFinal(data);
        } catch (InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    public static Keys rsaGenerateKeys() {
        try {
            KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(RSA_KEY_ALGORITHM);
            keyPairGen.initialize(1024);
            KeyPair keyPair = keyPairGen.generateKeyPair();
            
            RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();  
            RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
            
            return new Keys(publicKey, privateKey, Base64.encodeBase64String(publicKey.getEncoded()), Base64.encodeBase64String(privateKey.getEncoded()));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    public static class Keys {
        public final RSAPublicKey publicKey;
        public final RSAPrivateKey privateKey;
        public final String publicKeyVal;
        public final String privateKeyVal;
        public Keys(RSAPublicKey publicKey, RSAPrivateKey privateKey, String publicKeyVal, String privateKeyVal) {
            this.publicKey = publicKey;
            this.privateKey = privateKey;
            this.publicKeyVal = publicKeyVal;
            this.privateKeyVal = privateKeyVal;
        }
    }
}

