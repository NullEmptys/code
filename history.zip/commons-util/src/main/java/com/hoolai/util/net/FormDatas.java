package com.hoolai.util.net;

import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

public class FormDatas {

    private List<FormData> datas;
    private String boundary;
    
    public FormDatas() {
        this.datas = new LinkedList<>();
        this.boundary = UUID.randomUUID().toString();
    }
    
    public FormDatas offer(FormData data) {
        datas.add(data);
        return this;
    }
    
    public Request header() {
        return new Request("Content-Type", "multipart/form-data; boundary=" + boundary);
    }

    public byte[] toBytes() {
        if(buf == null) {
            byte[] crlf = getBytes("\r\n");
            byte[] __ = getBytes("--");
            byte[] boundary = getBytes(this.boundary);
            
            append(__).append(boundary);
            for (FormData data : this.datas) {
                append(crlf).append(data.keyBytes());
                if(data.contentType != null) append(crlf).append(data.typeBytes());
                if(data.contentTransferEncoding != null) append(crlf).append(data.encodingBytes());
                append(crlf).append(crlf).append(data.valBytes()); //content开始处多一个换行
                append(crlf).append(__).append(boundary);
            }
            append(__).append(crlf);
        }
        return buf;
    }
    
    
    static byte[] getBytes(String x) {
        return x.getBytes(StandardCharsets.UTF_8);
    }

    private byte[] buf;
    private FormDatas append(byte[] n) {
        if(buf == null) {
            byte[] t = new byte[n.length];
            System.arraycopy(n, 0, t, 0, n.length);
            buf = t;
        } else {
            byte[] o = buf;
            byte[] t = new byte[o.length + n.length];
            System.arraycopy(o, 0, t, 0, o.length);
            System.arraycopy(n, 0, t, o.length, n.length);
            buf = t;
        }
        return this;
    }
    
}
