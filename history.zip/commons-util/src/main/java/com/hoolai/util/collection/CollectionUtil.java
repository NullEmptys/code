package com.hoolai.util.collection;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class CollectionUtil {
    
    public static boolean isEmpty(Map<?, ?> map) {
        return map == null || map.isEmpty();
    }
    
    public static boolean isEmpty(Collection<?> coll) {
        return coll == null || coll.isEmpty();
    }
    
    public static boolean isEmpty(int[] src) {
        return src == null || src.length == 0;
    }
    
    public static boolean isEmpty(long[] src) {
        return src == null || src.length == 0;
    }
    
    public static <T> boolean isEmpty(T[] src) {
        return src == null || src.length == 0;
    }
    
    public static <T> boolean contains(T[] src, T e) {
        if(isEmpty(src)) return false;
        for (T i : src) {
            if(i != null && i.equals(e)) return true;
        }
        return false;
    }
    public static boolean contains(int[] src, int e) {
        if(isEmpty(src)) return false;
        for (int i : src) {
            if(i == e) return true;
        }
        return false;
    }

    public static <T> List<T> asList(T t) {
        List<T> ret = new ArrayList<T>(1);
        ret.add(t);
        return ret;
    }
    
    public static <T> List<T> asList(T t1, T t2) {
        List<T> ret = new ArrayList<T>(2);
        ret.add(t1);
        ret.add(t2);
        return ret;
    }
    
    public static <T> List<T> copy(Collection<T> src) {
        List<T> dest = null;
        synchronized (src) {
            dest = new ArrayList<>(src);
        }
        return dest;
    }
    
    /**
     * 冒泡
     * @param list
     * @param comp
     * @return
     */
    public static <T> void sort(List<T> list, Comparator<T> comp) {
        int len = list.size();
        for (int i = 0; i < len - 1; i++) {// 控制趟数
            for (int j = 0; j < len - i - 1; j++) {
                if (comp.compare(list.get(j), list.get(j + 1)) > 0) {
                    list.set(j, list.set(j+1, list.get(j)));
                }
            }
        }
    }
    
    public static <T> List<T> emptyList() {
        return new ArrayList<T>(0);
    }
    
    public static <K, V> Map<K, List<V>> addToMapList(Map<K, List<V>> map, K k, V v) {
        List<V> vs = map.get(k);
        if(vs == null) {
            vs = new ArrayList<V>();
            map.put(k, vs);
        }
        vs.add(v);
        return map;
    }
    
    public static <V> IntHashMap<List<V>> addToMapList(IntHashMap<List<V>> map, int k, V v) {
        List<V> vs = map.get(k);
        if(vs == null) {
            vs = new ArrayList<V>();
            map.put(k, vs);
        }
        vs.add(v);
        return map;
    }
    
    @SuppressWarnings("rawtypes")
    public static List EMPTY_LIST = new AbstractList() {
        @Override
        public boolean add(Object e) {
            return false;
        }
        @Override
        public Object get(int index) {
            return null;
        }
        @Override
        public Object set(int index, Object element) {
            return null;
        }
        @Override
        public void add(int index, Object element) {
        }
        @Override
        public Object remove(int index) {
            return null;
        }
        @Override
        public int size() {
            return 0;
        }
    };
}
