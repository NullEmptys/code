package com.hoolai.util.collection;

import java.util.AbstractList;
import java.util.Arrays;
import java.util.stream.IntStream;

/**
 * int array list
 * 
 * @author luzj
 *
 */
public class Ints extends AbstractList<Integer> {

    /**
     * The array buffer into which the elements of the ArrayList are stored. The
     * capacity of the ArrayList is the length of this array buffer.
     */
    private int[] elements;

    /**
     * The size of the ArrayList (the number of elements it contains).
     * 
     * @serial
     */
    protected int size;

    /**
     * Constructs an empty list with the specified initial capacity.
     * 
     * @param initialCapacity
     *            the initial capacity of the list
     * @exception IllegalArgumentException
     *                if the specified initial capacity is negative
     */
    public Ints(int initialCapacity) {
        super();
        if (initialCapacity < 0)
            throw new IllegalArgumentException("Illegal Capacity: " + initialCapacity);
        this.elements = new int[initialCapacity];
    }

    /**
     * Constructs an empty list with an initial capacity of ten.
     */
    public Ints() {
        this(10);
    }
    
    public Ints(int[] src) {
        this.reset(src);
    }
    
    public void reset(int[] src) {
        this.elements = src == null ? new int[0] : src;
        this.size = this.elements.length;
    }

    public void trimToSize() {
        int oldCapacity = elements.length;
        if (size < oldCapacity) {
            elements = Arrays.copyOf(elements, size);
        }
    }

    public void ensureCapacity(int minCapacity) {
        int oldCapacity = elements.length;
        if (minCapacity > oldCapacity) {
            int newCapacity = (oldCapacity * 3) / 2 + 1;
            if (newCapacity < minCapacity)
                newCapacity = minCapacity;
            // minCapacity is usually close to size, so this is a win:
            elements = Arrays.copyOf(elements, newCapacity);
        }
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
    
    @Override
    public boolean contains(Object o) {
        if(o == null || !(o instanceof Integer)) {
            return false;
        }
        return contains(((Integer)o).intValue());
    }

    public boolean contains(int o) {
        return indexOf(o) >= 0;
    }
    
    public int indexOf(Object o) {
        if(o == null || !(o instanceof Integer)) {
            return -1;
        }
        return indexOf(((Integer)o).intValue());
    }

    public int indexOf(int o) {
        for (int i = 0; i < size; i++)
            if (o == elements[i])
                return i;
        return -1;
    }

    public int lastIndexOf(Object o) {
    	if(o == null || !(o instanceof Integer)) {
            return -1;
        }
        return lastIndexOf(((Integer)o).intValue());
    }
    
    public int lastIndexOf(int o) {
        for (int i = size - 1; i >= 0; i--)
            if (o == elements[i])
                return i;
        return -1;
    }

    public int[] toIntArray() {
        return Arrays.copyOf(elements, size);
    }
    
    public Integer[] toArray() {
        return IntStream.of(toIntArray()).boxed().toArray(Integer[]::new);
    }
    
    @Override @SuppressWarnings("unchecked")
    public <T> T[] toArray(T[] a) {
        Integer[] datas = toArray();
        if(a.length < size) {
            return (T[]) datas;
        }
        System.arraycopy(datas, 0, a, 0, size);
        if (a.length > size)
            a[size] = null;
        return a;
    }

    // Positional Access Operations
    public Integer get(int index) {
        RangeCheck(index);

        return elements[index];
    }

    public Integer set(int index, Integer element) {
        RangeCheck(index);

        int oldValue = elements[index];
        elements[index] = element;
        return oldValue;
    }

    public boolean add(Integer e) {
        ensureCapacity(size + 1); // Increments modCount!!
        elements[size++] = e;
        return true;
    }

    public void add(int index, Integer element) {
        if (index > size || index < 0)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);

        ensureCapacity(size + 1); // Increments modCount!!
        System.arraycopy(elements, index, elements, index + 1, size - index);
        elements[index] = element;
        size++;
    }

    public Integer remove(int index) {
        RangeCheck(index);

        int oldValue = elements[index];

        int numMoved = size - index - 1;
        if (numMoved > 0)
            System.arraycopy(elements, index + 1, elements, index, numMoved);
        elements[--size] = 0; // Let gc do its work

        return oldValue;
    }
    
    public boolean remove(Object o) {
        if(o == null || !(o instanceof Integer)) {
            return false;
        }
        return removeValue(((Integer)o).intValue());
    }

    public boolean removeValue(int o) {
        for (int index = 0; index < size; index++) {
            if (o == elements[index]) {
                fastRemove(index);
                return true;
            }
        }
        return false;
    }

    /*
     * Private remove method that skips bounds checking and does not return the
     * value removed.
     */
    private void fastRemove(int index) {
        int numMoved = size - index - 1;
        if (numMoved > 0)
            System.arraycopy(elements, index + 1, elements, index, numMoved);
        elements[--size] = 0; // Let gc do its work
    }

    public void clear() {
        // Let gc do its work
        for (int i = 0; i < size; i++)
            elements[i] = 0;

        size = 0;
    }


    /**
     * Removes from this list all of the elements whose index is between
     * <tt>fromIndex</tt>, inclusive, and <tt>toIndex</tt>, exclusive. Shifts
     * any succeeding elements to the left (reduces their index). This call
     * shortens the list by <tt>(toIndex - fromIndex)</tt> elements. (If
     * <tt>toIndex==fromIndex</tt>, this operation has no effect.)
     * 
     * @param fromIndex
     *            index of first element to be removed
     * @param toIndex
     *            index after last element to be removed
     * @throws IndexOutOfBoundsException
     *             if fromIndex or toIndex out of range (fromIndex &lt; 0 ||
     *             fromIndex &gt;= size() || toIndex &gt; size() || toIndex &lt;
     *             fromIndex)
     */
    protected void removeRange(int fromIndex, int toIndex) {
        int numMoved = size - toIndex;
        System.arraycopy(elements, toIndex, elements, fromIndex, numMoved);

        // Let gc do its work
        int newSize = size - (toIndex - fromIndex);
        while (size != newSize)
            elements[--size] = 0;
    }

    /**
     * Checks if the given index is in range. If not, throws an appropriate
     * runtime exception. This method does *not* check if the index is negative:
     * It is always used immediately prior to an array access, which throws an
     * ArrayIndexOutOfBoundsException if index is negative.
     */
    private void RangeCheck(int index) {
        if (index >= size)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
    }

    public void sort() {
        Arrays.sort(elements, 0, size);
    }

}
