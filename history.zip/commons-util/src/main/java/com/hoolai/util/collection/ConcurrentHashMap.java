package com.hoolai.util.collection;

import java.util.Map;

public class ConcurrentHashMap<K, V> extends java.util.concurrent.ConcurrentHashMap<K, V> {

    private static final long serialVersionUID = -4750518238372859196L;
    
    private volatile int size;

    @Override
    public V put(K key, V value) {
        V v = super.put(key, value);
        if(v == null) ++ size;
        return v;
    }

    @Override
    public V putIfAbsent(K key, V value) {
        V v = super.putIfAbsent(key, value);
        if(v == null) ++ size;
        return v;
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> m) {
        super.putAll(m);
        size += m.size();
    }

    @Override
    public V remove(Object key) {
        V v = super.remove(key);
        if(v != null) -- size;
        return v;
    }

    @Override
    public boolean remove(Object key, Object value) {
        if(super.remove(key, value)) {
            -- size;
            return true;
        }
        return false;
    }
    
    /**
     * 并不准确的size方法
     */
    public int size() {
        return size;
    }
    
    public int size(boolean safely) {
        if(safely) this.size = super.size();
        return this.size;
    }
    
}