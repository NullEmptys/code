package com.hoolai.util.collection;

import java.util.Iterator;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * range include upper
 * @author luzj
 */
public class Range implements Iterator<Integer>, Iterable<Integer> {
    
    public static Range open(final int lower, final int upper) {
        return open(lower, upper, 1);
    }
    public static Range open(final int lower, final int upper, final int step) {
        return new Range(lower, upper, step);
    }
    
    public static Range closed(final int lower, final int upper) {
        return closed(lower, upper, 1);
    }
    public static Range closed(final int lower, final int upper, final int step) {
        return new Range(lower, upper + 1, step);
    }
    
    private final int upper;
    private final int step;
    
    private int next;

    private Range(final int lower, final int upper, final int step) {
        this.upper = upper;
        this.step = step;
        this.next = lower;
    }

    @Override
    public boolean hasNext() {
        return next < upper;
    }
    @Override
    public Integer next() {
        int _next = next;
        next += step;
        return _next;
    }
    
    @Override
    public Iterator<Integer> iterator() {
        return this;
    }
    
    public Stream<Integer> stream() {
        return StreamSupport.stream(this.spliterator(), false);
    }
    
}
