package com.hoolai.util.math;

import java.math.BigDecimal;

/**
 * 
 * @author luzj
 * 
 */
public class MathUtil {
    
    /**
     * 百分比加成
     * @param src
     * @param percentage
     * @return
     */
    public static int percentageImprove(int src, int percentage) {
        return Math.round(src / 100f * (100 + percentage));
    }
    public static int percentageImprove(int src, float percentage) {
        return Math.round(src / 100f * (100 + percentage));
    }
    
    /**
     * 百分比
     * @param src
     * @param percentage
     * @return
     */
    public static int percentageSection(int src, int percentage) {
        return Math.round(src / 100f * percentage);
    }
    public static int percentageSection(int src, float percentage) {
        return Math.round(src / 100f * percentage);
    }
    
    /**
     * 换成百分数 x / y * 100
     * @param x
     * @param y
     * @return
     */
    public static int percent(int x, int y) {
        return percent(x, (float) y);
    }
    public static int percent(int x, float y) {
        return Math.round(x / y * 100f);
    }
    
    /**
     * 默认精度 2位
     * @param x
     * @param y
     * @return
     */
    public static float percentKeepPrecision(int x, int y) {
        return percentKeepPrecision(x, y, 2);
    }
    
    public static float percentKeepPrecision(int x, int y, int prec) {
        return new BigDecimal(x * 100f / y).setScale(prec, BigDecimal.ROUND_HALF_UP).floatValue();
    }
    
    /**
     * 百分比0.25
     * @param x
     * @param y
     * @return
     */
    public static float percentRatio(int x, int y) {
        return percentRatio(x, y, 2);
    }
    
    public static float percentRatio(int x, int y, int prec) {
        return new BigDecimal(x * 1f / y).setScale(prec, BigDecimal.ROUND_HALF_UP).floatValue();
    }

    /**
     * 千分比加成
     * @param src
     * @param permillage
     * @return
     */
    public static int permillageImprove(int src, int permillage) {
    	return Math.round(src / 1000f * (1000 + permillage));
    }
    
    /**
     * 千分比
     * @param src
     * @param permillage
     * @return
     */
    public static int permillage(int src, int permillage) {
        return Math.round(src / 1000f * permillage);
    }
    
    /**
     * 获取区间下标
     * @param frontiers sorted
     * @param x (x >= frontiers[i] && x < frontiers[i+1])
     * @return
     */
    public static int rangeIndex(int[] frontiers, int x) {
        if(frontiers != null && frontiers.length > 1) {
            for (int i = 1; i < frontiers.length; i++) {
                if((x < frontiers[i] && x >= frontiers[i - 1]) || ( x > frontiers[i] && x <= frontiers[i - 1])) {
                    return i - 1;
                }
            }
        }
        return -1;
    }
    
	/**
	 * 以mod取整
	 * @param src
	 * @param mod
	 * @return
	 */
	public static int round(int src, int mod) {
		return round((float) src, mod);
	}

	public static int round(float src, int mod) {
		return Math.round(src / mod) * mod;
	}

	public static long round(double src, int mod) {
		return Math.round(src / mod) * mod;
	}

	public static long round(long src, int mod) {
		return round((double) src, mod);
	}

	public static int floor(int src, int mod) {
		return (int) (Math.floor(src / mod) * mod);
	}
	
	public static int ceil(int src, int mod) {
		return (int) (Math.ceil(src / mod) * mod);
	}
	
	/**
	 * MROUND rounds up, away from zero, if the remainder of dividing number by
	 * multiple is greater than or equal to half the value of multiple.
	 * 
	 * @param number
	 *            is the value to round.
	 * @param multiple
	 *            is the multiple to which you want to round number.
	 * @return Returns a number rounded to the desired multiple.
	 */
	public static float mround(double number, float multiple) {
		if (number * multiple < 0)
			throw new IllegalArgumentException("Arguments hava different signs!");
		return Math.round(number / multiple) * multiple;
	}
	
	public static boolean between(int src, int a, int b) {
		if(a < b) {
			return src > a && src < b;
		}
		
		return src > b && src < a;
	}
	
	public static boolean betweenOrEqual(int src, int a, int b) {
		return src == a || src == b || between(src, a, b);
	}
	
	public static boolean between(long src, long a, long b) {
		if(a < b) {
			return src > a && src < b;
		}
		
		return src > b && src < a;
	}
	
	public static boolean betweenOrEqual(long src, long a, long b) {
		return src == a || src == b || between(src, a, b);
	}
	
	//比较 赋值
	public static int equalOrElse(int src, int cond, int e) {
	    return src == cond ? src : e;
	}
	
	public static int inequalOrElse(int src, int cond, int e) {
	    return src != cond ? src : e;
	}
	
	public static int overThenOrElse(int src, int cond, int e) {
	    return src > cond ? src : e;
	}
	
	public static int lessThenOrElse(int src, int cond, int e) {
	    return src < cond ? src : e;
	}
	
}
