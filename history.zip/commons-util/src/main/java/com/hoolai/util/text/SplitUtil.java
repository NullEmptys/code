package com.hoolai.util.text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Pattern;


/**
 * 字符串与数据组的 解析或者拼接
 * 示例
 * int[]   --> String   default --> 1,2,3
 * Map<Integer, Integer> --> String default --> key1,val1|key2,val2
 * @author luzj
 */
public class SplitUtil {
    
    public static final String MAJOR_DELIMITER = ",";//默认的分隔符
    
    public static final String MINOR_DELIMITER = "|";

    private static String[] split0(String src, String regex) {
        return src.split(Pattern.quote(regex));
    }
    
    public static String[] split(String src) {
        return split(src, MAJOR_DELIMITER);
    }
    public static String[] split(String src, String regex) {
        return StringUtil.isEmpty(src) ? new String[0] : split0(src, regex);
    }
    public static List<String> splitToList(String src) {
        return splitToList(src, MAJOR_DELIMITER);
    }
    public static List<String> splitToList(String src, String regex) {
        if(StringUtil.isEmpty(src)) {
            return new ArrayList<String>(0);
        }
        
        String[] tmps = split0(src, regex);
        int len = tmps.length;
        List<String> ret = new ArrayList<String>(len);
        for (int i = 0; i < len; i++) {
            ret.add(tmps[i]);
        }
        return ret;
    }
    

    public static int[]  splitToInts(String src) {
        return splitToInts(src, MAJOR_DELIMITER);
    }
    public static int[] splitToInts(String src, String regex) {
        if(StringUtil.isEmpty(src)) {
            return new int[0];
        }
        
        String[] tmps = split0(src, regex);
        int len = tmps.length;
        int[] ret = new int[len];
        for (int i = 0; i < len; i++) {
            ret[i] = Integer.parseInt(tmps[i]);
        }
        return ret;
    }
    public static List<Integer> splitToIntList(String src) {
        return splitToIntList(src, MAJOR_DELIMITER);
    }
    public static List<Integer> splitToIntList(String src, String regex) {
        if(StringUtil.isEmpty(src)) {
            return new ArrayList<>(0);
        }
        
        String[] tmps = split0(src, regex);
        int len = tmps.length;
        List<Integer> ret = new ArrayList<>(len);
        for (int i = 0; i < len; i++) {
            ret.add(Integer.parseInt(tmps[i]));
        }
        return ret;
    }
    

    /**
     * @param src  '1,2|3,4'
     * @param major ','
     * @param minor '|'
     * @return {1:2, 3:4}
     */
    public static Map<Integer, Integer> splitToIntMap(String src) {
    	return splitToIntMap(src, MAJOR_DELIMITER, MINOR_DELIMITER);
    }
    /**
     * @param src  '1,2|3,4'
     * @param major ','
     * @param minor '|'
     * @return {1:2, 3:4}
     */
    public static Map<Integer, Integer> splitToIntMap(String src, String major, String minor) {
    	Map<Integer, Integer> map = new HashMap<>();
    	if(!StringUtil.isEmpty(src)) {
    		String[] tmps = split0(src, minor);
    		for (String tmp : tmps) {
    			String[] xx = split0(tmp, major);
    			map.put(Integer.parseInt(xx[0]), Integer.parseInt(xx[1]));
			}
    	}
    	return map;
    }
    
    
    /**
     * @param src '1,2'
     * @return [1,2]
     */
    public static long[] splitToLongs(String src) {
        return splitToLongs(src, MAJOR_DELIMITER);
    }
    /**
     * @param src '1,2'
     * @param regex ','
     * @return [1,2]
     */
    public static long[] splitToLongs(String src, String regex) {
    	if(StringUtil.isEmpty(src)) {
    		return new long[0];
    	}
    	
    	String[] tmps = split0(src, regex);
    	int len = tmps.length;
    	long[] ret = new long[len];
    	for (int i = 0; i < len; i++) {
    		ret[i] = Long.parseLong(tmps[i]);
    	}
    	return ret;
    }
    
    public static List<Long> splitToLongList(String src) {
        return splitToLongList(src, MAJOR_DELIMITER);
    }
    public static List<Long> splitToLongList(String src, String regex) {
        if(StringUtil.isEmpty(src)) {
            return new ArrayList<>(0);
        }
        
        String[] tmps = split0(src, regex);
        int len = tmps.length;
        List<Long> ret = new ArrayList<>(len);
        for (int i = 0; i < len; i++) {
            ret.add(Long.parseLong(tmps[i]));
        }
        return ret;
    }
    
    public static <T> List<T> splitToObjList(String src, Function<String, T> toObj) {
    	return splitToObjList(src, MAJOR_DELIMITER, toObj);
    }
    public static <T> List<T> splitToObjList(String src, String regex, Function<String, T> toObj) {
    	if(StringUtil.isEmpty(src)) {
            return new ArrayList<T>(0);
        }
        
        String[] tmps = split0(src, regex);
        int len = tmps.length;
        List<T> ret = new ArrayList<T>(len);
        for (int i = 0; i < len; i++) {
            T obj = toObj.apply(tmps[i]);
            if(obj != null) ret.add(obj);
        }
        return ret;
    }
    
    
    public static String compact(int[] src) {
        return compact(src, MAJOR_DELIMITER);
    }
    public static String compact(int[] src, String regex) {
    	StringBuilder sb = new StringBuilder();
    	for (int i = 0; i < src.length; i++) {
			if(i > 0)
				sb.append(regex);
			sb.append(Integer.toString(src[i]));
		}
		return sb.toString();
	}
    
    public static String compact(long[] src) {
        return compact(src, MAJOR_DELIMITER);
    }
    public static String compact(long[] src, String regex) {
    	StringBuilder sb = new StringBuilder();
    	for (int i = 0; i < src.length; i++) {
    		if(i > 0)
    			sb.append(regex);
    		sb.append(Long.toString(src[i]));
    	}
    	return sb.toString();
    }
    
    public static String compact(String x, String y) {
        return compact(x, y, MAJOR_DELIMITER);
    }
    public static String compact(String x, String y, String regex) {
        return new StringBuilder().append(x).append(regex).append(y).toString();
    }
    
    public static String compact(String[] x) {
        return compact(x, MAJOR_DELIMITER);
    }
    public static String compact(String[] x, String regex) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < x.length; i++) {
            if(i > 0)
                sb.append(regex);
            sb.append(x[i]);
        }
        return sb.toString();
    }
    
    public static <T> String compactObjs(List<T> src, Function<T, String> toStr) {
    	return compactObjs(src, MAJOR_DELIMITER, toStr);
    }
    public static <T> String compactObjs(List<T> src, String regex, Function<T, String> toStr) {
    	StringBuilder sb = new StringBuilder();
        int index = 0;
        for(T element : src ){
            if(index++ > 0)
                sb.append(regex);
            sb.append(toStr.apply(element));
        }
        return sb.toString();
    }
    
    public static String compact(List<String> src) {
        return compact(src, MAJOR_DELIMITER);
    }
    public static String compact(List<String> src, String regex) {
        StringBuilder sb = new StringBuilder();
        int index = 0;
        for(String element : src ){
            if(index++ > 0)
                sb.append(regex);
            sb.append(element);
        }
        return sb.toString();
    }
    
    public static String compactInts(List<Integer> src) {
        return compactInts(src, MAJOR_DELIMITER);
    }
    public static String compactInts(List<Integer> src, String regex) {
        StringBuilder sb = new StringBuilder();
        int index = 0;
        for(Integer element : src ){
            if(index++ > 0)
                sb.append(regex);
            sb.append(element);
        }
        return sb.toString();
    }
    
    public static String compactLongs(List<Long> src) {
        return compactLongs(src, MAJOR_DELIMITER);
    }
    public static String compactLongs(List<Long> src, String regex) {
        StringBuilder sb = new StringBuilder();
        int index = 0;
        for(Long element : src ){
            if(index++ > 0)
                sb.append(regex);
            sb.append(element);
        }
        return sb.toString();
    }
    
    /**
     * @param src  {1:2, 3:4}
     * @param major ','
     * @param minor '|'
     * @return '1,2|3,4'
     */
    public static  String compactIntMap(Map<Integer, Integer> src) {
    	return compactIntMap(src, MAJOR_DELIMITER, MINOR_DELIMITER);
    }
    /**
     * @param src  {1:2, 3:4}
     * @param major ','
     * @param minor '|'
     * @return '1,2|3,4'
     */
    public static String compactIntMap(Map<Integer, Integer> src, String major, String minor) {
    	StringBuilder sb = new StringBuilder();
    	if(src != null) {
    		int index = 0;
    		for (Map.Entry<Integer, Integer> entry : src.entrySet()) {
				if(index++ > 0)
					sb.append(minor);
				sb.append(entry.getKey()).append(major).append(entry.getValue());
			}
    	}
    	return sb.toString();
    }

}
