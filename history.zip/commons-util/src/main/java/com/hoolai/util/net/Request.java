package com.hoolai.util.net;

/**
 * 
 * http请求的rqeust Property
 * header?
 * @author luzj
 *
 */
public class Request {
    
    public final String key;
    
    public final String value;
    
    public Request(String key, String value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public String toString() {
        return "Request [key=" + key + ", value=" + value + "]";
    }
    
}
