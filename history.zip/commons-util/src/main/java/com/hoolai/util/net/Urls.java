package com.hoolai.util.net;

import java.net.MalformedURLException;
import java.net.URL;

public class Urls {
    
    public static String getHttpUrl(String host) {
        return getHttpUrl(host, "");
    }
    public static String getHttpUrl(String host, String uri) {
        return getHttpUrl(host, -1, uri);
    }
    public static String getHttpUrl(String host, int port, String uri) {
        return newHttpURL(host, port, uri).toString();
    }

    public static URL newHttpURL(String host) {
        return newHttpURL(host, -1);
    }
    public static URL newHttpURL(String host, int port) {
        try {
            return new URL("http", host, port, "");
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException(e);
        }
    }
    public static URL newHttpURL(String host, int port, String uri) {
        return newURL(newHttpURL(host, port), uri);
    }
    
    public static String getHost(String url) {
        return newURL(url).getHost();
    }
    
    public static URL newURL(String url) {
        try {
            return new URL(url);
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException(e);
        }
    }
    public static URL newURL(String context, String spec) {
        return newURL(newURL(context), spec);
    }
    public static URL newURL(URL context, String spec) {
        try {
            return new URL(context, spec);
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException(e);
        }
    }
    
    /**
     * @param context requires full http or else url content [http://host/]
     * @param uri
     * @return
     */
    public static String join(String context, String uri) {
        return newURL(newURL(context), uri).toString();
    }

}
