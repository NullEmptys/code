package com.hoolai.util.log;

import org.slf4j.Logger;

/**
 * 
 * 初始化结果
 * @author luzj
 *
 */
public class InitEval {
    
    private Logger logger = Log.getLogger(InitEval.class);
    
    private Object cause;
    
    private String source;
    
    private boolean ret;
    
    private InitEval(boolean ret) {
        this.ret = ret;
    }
    
    public static InitEval failed() {
        return new InitEval(false);
    }
    
    public static InitEval success() {
        return new InitEval(true);
    }
    
    public InitEval naming(String source) {
        this.source = source;
        return this;
    }
    
    public InitEval withCause(Object e) {
        this.cause = e;
        return this;
    }
    
    public void eval() {
        if(ret) {
            logger.info(source + "  成功");
        } else {
            if(cause instanceof Throwable) {
                logger.error(source + "  失败", (Throwable) cause);
            } else {
                logger.error(source + "  失败, cause:{}", cause);
            }
        }
    }
    
}
