package com.hoolai.util.log;

import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hoolai.util.collection.Longs;

public final class Profiler {
    
    static final Logger logger = LoggerFactory.getLogger(Profiler.class);
    
    String name;
    Longs times;
    int step;
    
    
    public Profiler() {
        this("Profiler");
    }
    
    public Profiler(String name) {
        this.name = name;
        this.times = new Longs(2);
        this.step = 1;
        this.step();
    }

    public void step() {
        times.add(System.nanoTime());
    }

    public void log() {
        step();
        sprint(logger::debug);
    }
    
    public void print() {
        step();
        sprint(System.out::println);
    }

    void sprint(Consumer<String> c) {
        int size = times.size();
        while(step < size) {
            long used = times.get(step) - times.get(step - 1);
            c.accept(String.format("%s step %d used: %.2f", name, step, used / 1000000f));
            ++ step;
        }
    }
    
}
