package com.hoolai.util.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hoolai.util.clazz.RelectionUtil;

/**
 * log 代理给logger 核心业务可以自己取log
 * 
 * @author luzj
 */
public class Log {

    private static Logger logger = getLogger(Log.class);

    public static Logger getLogger(String name) {
        return LoggerFactory.getLogger(name);
    }

    public static Logger getLogger(Class<?> clazz) {
        return LoggerFactory.getLogger(clazz);
    }

    private static Logger getLoggerByCaller() {
        return getLogger(RelectionUtil.getCallerClass(2));
    }

    public static boolean isTraceEnabled() {
        return logger.isTraceEnabled();
    }

    public static void trace(String msg) {
        try {
            getLoggerByCaller().trace(msg);
        } catch (Throwable e) {
        }
    }

    public static void trace(String format, Object arg) {
        try {
            getLoggerByCaller().trace(format, arg);
        } catch (Throwable e) {
        }
    }

    public static void trace(String format, Object arg1, Object arg2) {
        try {
            getLoggerByCaller().trace(format, arg1, arg2);
        } catch (Throwable e) {
        }
    }

    public static void trace(String format, Object... arguments) {
        try {
            getLoggerByCaller().trace(format, arguments);
        } catch (Throwable e) {
        }
    }

    public static void trace(String msg, Throwable t) {
        try {
            getLoggerByCaller().trace(msg, t);
        } catch (Throwable e) {
        }
    }

    public static boolean isDebugEnabled() {
        return logger.isDebugEnabled();
    }

    public static void debug(String msg) {
        try {
            getLoggerByCaller().debug(msg);
        } catch (Throwable e) {
        }
    }

    public static void debug(String format, Object arg) {
        try {
            getLoggerByCaller().debug(format, arg);
        } catch (Throwable e) {
        }
    }

    public static void debug(String format, Object arg1, Object arg2) {
        try {
            getLoggerByCaller().debug(format, arg1, arg2);
        } catch (Throwable e) {
        }
    }

    public static void debug(String format, Object... arguments) {
        try {
            getLoggerByCaller().debug(format, arguments);
        } catch (Throwable e) {
        }
    }

    public static void debug(String msg, Throwable t) {
        try {
            getLoggerByCaller().debug(msg, t);
        } catch (Throwable e) {
        }
    }

    public static boolean isInfoEnabled() {
        return logger.isInfoEnabled();
    }

    public static void info(String msg) {
        try {
            getLoggerByCaller().info(msg);
        } catch (Throwable e) {
        }
    }

    public static void info(String format, Object arg) {
        try {
            getLoggerByCaller().info(format, arg);
        } catch (Throwable e) {
        }
    }

    public static void info(String format, Object arg1, Object arg2) {
        try {
            getLoggerByCaller().info(format, arg1, arg2);
        } catch (Throwable e) {
        }
    }

    public static void info(String format, Object... arguments) {
        try {
            getLoggerByCaller().info(format, arguments);
        } catch (Throwable e) {
        }
    }

    public static void info(String msg, Throwable t) {
        try {
            getLoggerByCaller().info(msg, t);
        } catch (Throwable e) {
        }
    }

    public static boolean isWarnEnabled() {
        return logger.isWarnEnabled();
    }

    public static void warn(String msg) {
        try {
            getLoggerByCaller().warn(msg);
        } catch (Throwable e) {
        }
    }

    public static void warn(String format, Object arg) {
        try {
            getLoggerByCaller().warn(format, arg);
        } catch (Throwable e) {
        }
    }

    public static void warn(String format, Object... arguments) {
        try {
            getLoggerByCaller().warn(format, arguments);
        } catch (Throwable e) {
        }
    }

    public static void warn(String format, Object arg1, Object arg2) {
        try {
            getLoggerByCaller().warn(format, arg1, arg2);
        } catch (Throwable e) {
        }
    }

    public static void warn(String msg, Throwable t) {
        try {
            getLoggerByCaller().warn(msg, t);
        } catch (Throwable e) {
        }
    }

    public static boolean isErrorEnabled() {
        return logger.isErrorEnabled();
    }

    public static void error(String msg) {
        try {
            getLoggerByCaller().error(msg);
        } catch (Throwable e) {
        }
    }

    public static void error(String format, Object arg) {
        try {
            getLoggerByCaller().error(format, arg);
        } catch (Throwable e) {
        }
    }

    public static void error(String format, Object arg1, Object arg2) {
        try {
            getLoggerByCaller().error(format, arg1, arg2);
        } catch (Throwable e) {
        }
    }

    public static void error(String format, Object... arguments) {
        try {
            getLoggerByCaller().error(format, arguments);
        } catch (Throwable e) {
        }
    }

    public static void error(String msg, Throwable t) {
        try {
            getLoggerByCaller().error(msg, t);
        } catch (Throwable e) {
        }
    }

}
