package com.hoolai.game.player;

import com.hoolai.action.ActionQueue;

public interface PlayerFactory {

    Player newPlayer(long playerId, ActionQueue queue);

}
