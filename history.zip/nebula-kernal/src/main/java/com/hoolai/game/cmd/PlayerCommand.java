package com.hoolai.game.cmd;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hoolai.game.PlayerLoader;
import com.hoolai.game.player.Player;
import com.hoolai.injection.Inject;
import com.hoolai.net.cmd.Command;
import com.hoolai.net.codec.IMessage;
import com.hoolai.net.session.Session;

public abstract class PlayerCommand<T extends Player> implements Command {
    
    protected static Logger logger = LoggerFactory.getLogger(PlayerCommand.class);
    
    @Inject
    private PlayerLoader playerLoader;
    
    @Override
    public final void execute(Session session, IMessage req) throws Exception {
        long playerId = req.getId();
        T player = playerLoader.getPlayer(playerId);
        if(player != null) {
            execute0(player, req);
        } else {
            logger.error("Player not found [" + playerId + "]");
        }
    }
    
    //for Queued Or Direct
    protected abstract void execute0(T player, IMessage req) throws Exception;

    //for outter exec
    public abstract void execute(T player, IMessage req) throws Exception;

}
