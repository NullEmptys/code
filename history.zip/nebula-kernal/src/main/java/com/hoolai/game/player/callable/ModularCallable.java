package com.hoolai.game.player.callable;

import java.util.HashMap;
import java.util.Map;

import com.hoolai.game.player.Callable;
import com.hoolai.game.player.ModularPlayer;
import com.hoolai.modular.ModularEnigne;
import com.hoolai.modular.Module;
import com.hoolai.modular.ModuleTypeLoader;
import com.hoolai.tools.Generic;

/**
 * 
 * @author luzj
 *
 * @param <T>
 * @param <V>
 */
public abstract class ModularCallable<T extends ModularPlayer, V extends Module<?>> implements Callable<T> {
	
	final static Map<Class<?>, ModuleTypeLoader> loaders = new HashMap<>();
	
	final static ModuleTypeLoader getLoader(Class<?> clazz) {
		ModuleTypeLoader loader = loaders.get(clazz);
		if(loader == null) {
			loader = ModularEnigne.fetchLoader(Generic.analyse(clazz, ModularCallable.class).getByGenericName("V"));
			loaders.put(clazz, loader);
		}
		return loader;
	}
    
    public final void call(T player) {
        call(player, getLoader(this.getClass()).<V>load(player));
    }
    
    protected abstract void call(T player, V module);

}
