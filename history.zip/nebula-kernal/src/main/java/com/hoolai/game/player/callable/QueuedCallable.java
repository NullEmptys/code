package com.hoolai.game.player.callable;

import com.hoolai.action.Action;
import com.hoolai.game.player.Callable;
import com.hoolai.game.player.Player;

public abstract class QueuedCallable<T extends Player> implements Callable<T>{

    @Override
    public final void call(final T player) {
        new Action(player.queue()) {
            @Override
            protected void exec() {
                QueuedCallable.this.exec(player);
            }
        }.checkin();
    }

    protected abstract void exec(T player);

}
