package com.hoolai.game.player;

import com.hoolai.game.PlayerLoader;
import com.hoolai.injection.Bean;
import com.hoolai.injection.Inject;

@Bean(backup=true)
public class DefaultPlayerLoader implements PlayerLoader {
    
    @Inject(nullable=true)
    private PlayerContext playerCtx;
    
    @Override
    public boolean exists(long playerId) {
        return playerCtx.exists(playerId);
    }
    
    @Override
    public <T extends Player> T getPlayer(long playerId) {
        return playerCtx.getPlayerWithLoad(playerId);
    }

}
