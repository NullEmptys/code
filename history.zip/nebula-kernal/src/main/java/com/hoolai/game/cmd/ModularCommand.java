package com.hoolai.game.cmd;

import com.hoolai.game.player.ModularPlayer;
import com.hoolai.modular.ModularBridge;
import com.hoolai.modular.ModularBridge.Type;
import com.hoolai.modular.ModularInject;
import com.hoolai.modular.Module;
import com.hoolai.net.codec.IMessage;

/**
 * module 入口
 * @author luzj
 *
 * @param <T>
 * @param <V>
 */
public abstract class ModularCommand<T extends ModularPlayer, V extends Module<?>> extends PlayerCommand<T> {

    @ModularBridge(Type.ENTRY)
    public void execute(T player, IMessage req) throws Exception {
        //for dynamic override
        //bridge to Descriptor method
    }

    @ModularBridge(Type.BRIDGE)
    public abstract void exec(T player, @ModularInject V module, IMessage req) throws Exception;
    
}
