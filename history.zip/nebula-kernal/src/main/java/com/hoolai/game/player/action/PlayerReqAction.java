package com.hoolai.game.player.action;

import com.hoolai.action.Action;
import com.hoolai.action.ActionQueue;
import com.hoolai.game.cmd.PlayerCmdInvoker;
import com.hoolai.game.cmd.PlayerCommand;
import com.hoolai.game.player.ExceptionHandler;
import com.hoolai.game.player.Player;
import com.hoolai.injection.Inject;
import com.hoolai.injection.Prototype;
import com.hoolai.net.codec.IMessage;

/**
 * 通过player task queue 执行的 request command
 * @author luzj
 */
@Prototype
public class PlayerReqAction<T extends Player> extends Action {
    
    @Inject
    private ExceptionHandler handler;
    
    @Inject
    private PlayerCmdInvoker<T> invoker;
    
    private T player;
    
    private IMessage req;
    
    private PlayerCommand<T> cmd;
    
    public PlayerReqAction(T player, IMessage req, PlayerCommand<T> cmd, ActionQueue queue) {
        super(queue);
        this.player = player;
        this.req = req;
        this.cmd = cmd;
    }

    @Override
    protected void exec() {
        try {
            invoker.invoke(cmd, player, req);
        } catch (Throwable ex) {
            handler.onException(player.getPlayerId(), cmd, req, ex);
        }
    }

    @Override
    public String toString() {
        return "cmd=" + cmd;
    }
    
    protected Class<?> getClazz() {
    	return cmd.getClass();
    }

}
