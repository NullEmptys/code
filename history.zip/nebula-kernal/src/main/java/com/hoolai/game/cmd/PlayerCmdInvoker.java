package com.hoolai.game.cmd;

import com.hoolai.game.player.Player;
import com.hoolai.injection.Bean;
import com.hoolai.net.codec.IMessage;

@Bean(backup = true)
public class PlayerCmdInvoker<T extends Player> {
    public void invoke(PlayerCommand<T> cmd, T player, IMessage req) throws Exception {
        cmd.execute(player, req);
    }
}
