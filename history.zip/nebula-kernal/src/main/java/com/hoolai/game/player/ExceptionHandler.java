package com.hoolai.game.player;

import com.hoolai.injection.Combine;
import com.hoolai.net.cmd.Command;
import com.hoolai.net.codec.IMessage;

@Combine
public interface ExceptionHandler {
    
    public void onException(long playerId, Command cmd, IMessage req, Throwable throwable);

}
