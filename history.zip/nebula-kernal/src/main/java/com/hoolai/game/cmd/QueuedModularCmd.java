package com.hoolai.game.cmd;

import com.hoolai.game.player.ModularPlayer;
import com.hoolai.game.player.action.PlayerReqAction;
import com.hoolai.modular.Module;
import com.hoolai.net.codec.IMessage;


/**
 * 通过player.queue调用
 * @author luzj
 *
 */
public abstract class QueuedModularCmd<T extends ModularPlayer, V extends Module<?>> extends ModularCommand<T, V> {

    @Override
    protected final void execute0(T player, IMessage req) throws Exception {
        new PlayerReqAction<>(player, req, this, player.queue()).checkin();
    }
    
}
