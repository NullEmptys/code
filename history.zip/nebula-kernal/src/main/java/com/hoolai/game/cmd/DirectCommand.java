package com.hoolai.game.cmd;

import com.hoolai.game.player.Player;
import com.hoolai.injection.Inject;
import com.hoolai.net.codec.IMessage;

/**
 * 直接的, 没有经过player.queue
 * @author luzj
 */
public abstract class DirectCommand<T extends Player> extends PlayerCommand<T> {
    
    @Inject
    private PlayerCmdInvoker<T> invoker;
    
    @Override
    protected final void execute0(T player, IMessage req) throws Exception {
        invoker.invoke(this, player, req);
    }
    
    @Override
    public final void execute(T player, IMessage req) throws Exception {
        exec(player, req);
    }

    protected abstract void exec(T player, IMessage req) throws Exception;
    
}
