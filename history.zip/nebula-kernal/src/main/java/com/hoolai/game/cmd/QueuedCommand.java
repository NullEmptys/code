package com.hoolai.game.cmd;

import com.hoolai.game.player.Player;
import com.hoolai.game.player.action.PlayerReqAction;
import com.hoolai.net.codec.IMessage;


/**
 * 通过player.queue调用
 * @author luzj
 *
 */
public abstract class QueuedCommand<T extends Player> extends PlayerCommand<T> {
    
    @Override
    protected final void execute0(T player, IMessage req) throws Exception {
        new PlayerReqAction<>(player, req, this, player.queue()).checkin();
    }

    public final void execute(T player, IMessage req) throws Exception {
        exec(player, req);
    }

    protected abstract void exec(T player, IMessage req) throws Exception;
    
}
