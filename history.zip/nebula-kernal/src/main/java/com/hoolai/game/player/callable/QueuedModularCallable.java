package com.hoolai.game.player.callable;

import com.hoolai.action.Action;
import com.hoolai.game.player.ModularPlayer;
import com.hoolai.modular.Module;

public abstract class QueuedModularCallable<T extends ModularPlayer, V extends Module<?>> extends ModularCallable<T, V> {

    @Override
    protected final void call(final T player, final V module) {
        new Action(player.queue()) {
            @Override
            protected void exec() {
                QueuedModularCallable.this.exec(player, module);
            }
        }.checkin();
    }

    protected abstract void exec(T player, V module);

}
