package com.hoolai.http.service;

import com.hoolai.injection.Combine;

@Combine
public interface RequestInteceptor {
    
    Response intecept(Request req);

}
