package com.hoolai.http.service.rest;

import com.hoolai.http.service.ServiceConfiguration;

public interface RestConfiguration extends ServiceConfiguration {

    RespEncoder getRespEncoder();

    BodyDecoder getBodyDecoder();

}
