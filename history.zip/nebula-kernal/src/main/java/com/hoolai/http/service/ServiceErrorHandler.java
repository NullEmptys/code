package com.hoolai.http.service;

public interface ServiceErrorHandler {
    
    public Response handle(Request req, Throwable e);
    
}
