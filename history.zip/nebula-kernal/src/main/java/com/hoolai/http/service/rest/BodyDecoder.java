package com.hoolai.http.service.rest;

import com.hoolai.http.decode.HttpBody;
import com.hoolai.http.decode.MultiPart;
import com.hoolai.http.decode.QueryString;
import com.hoolai.http.service.Request.Params;
import com.hoolai.tools.Strings;

public interface BodyDecoder {
    
    default Object decode(Class<?> type, HttpBody body) {
        if(type.equals(MultiPart.class)) {
            return body.asMultiPart();
        } else if(type.equals(byte[].class)) {
            return body.asBytes();
        } else if(type.equals(Params.class) || type.equals(QueryString.class)) {
            return body.asParams();
        } else if(type.equals(HttpBody.class)) {
            return body;
        } else if(type.equals(String.class)) {
            return Strings.newStringUtf8(body.asBytes());
        }
        return decode(type, body.asBytes());
    }
	
	public Object decode(Class<?> type, byte[] body);

}
