package com.hoolai.http.service.rest;

import com.hoolai.http.service.Response;

public interface RespEncoder {

	Response encode(Object resp);

}
