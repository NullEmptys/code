package com.hoolai.tools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * kernal log
 * @author luzj
 */
public class KLog {
	
	private static Logger logger = getLogger(KLog.class);
	
	public static Logger getLogger(String name) {
		return LoggerFactory.getLogger(name);
	}
	public static Logger getLogger(Class<?> clazz) {
		return LoggerFactory.getLogger(clazz);
	}
	public static boolean isTraceEnabled() {
		return logger.isTraceEnabled();
	}
	public static void trace(String msg) {
		logger.trace(msg);
	}
	public static void trace(String format, Object arg) {
		logger.trace(format, arg);
	}
	public static void trace(String format, Object arg1, Object arg2) {
		logger.trace(format, arg1, arg2);
	}
	public static void trace(String format, Object... arguments) {
		logger.trace(format, arguments);
	}
	public static void trace(String msg, Throwable t) {
		logger.trace(msg, t);
	}
	public static boolean isDebugEnabled() {
		return logger.isDebugEnabled();
	}
	public static void debug(String msg) {
		logger.debug(msg);
	}
	public static void debug(String format, Object arg) {
		logger.debug(format, arg);
	}
	public static void debug(String format, Object arg1, Object arg2) {
		logger.debug(format, arg1, arg2);
	}
	public static void debug(String format, Object... arguments) {
		logger.debug(format, arguments);
	}
	public static void debug(String msg, Throwable t) {
		logger.debug(msg, t);
	}
	public static boolean isInfoEnabled() {
		return logger.isInfoEnabled();
	}
	public static void info(String msg) {
		logger.info(msg);
	}
	public static void info(String format, Object arg) {
		logger.info(format, arg);
	}
	public static void info(String format, Object arg1, Object arg2) {
		logger.info(format, arg1, arg2);
	}
	public static void info(String format, Object... arguments) {
		logger.info(format, arguments);
	}
	public static void info(String msg, Throwable t) {
		logger.info(msg, t);
	}
	public static boolean isWarnEnabled() {
		return logger.isWarnEnabled();
	}
	public static void warn(String msg) {
		logger.warn(msg);
	}
	public static void warn(String format, Object arg) {
		logger.warn(format, arg);
	}
	public static void warn(String format, Object... arguments) {
		logger.warn(format, arguments);
	}
	public static void warn(String format, Object arg1, Object arg2) {
		logger.warn(format, arg1, arg2);
	}
	public static void warn(String msg, Throwable t) {
		logger.warn(msg, t);
	}
	public static boolean isErrorEnabled() {
		return logger.isErrorEnabled();
	}
	public static void error(String msg) {
		logger.error(msg);
	}
	public static void error(String format, Object arg) {
		logger.error(format, arg);
	}
	public static void error(String format, Object arg1, Object arg2) {
		logger.error(format, arg1, arg2);
	}
	public static void error(String format, Object... arguments) {
		logger.error(format, arguments);
	}
	public static void error(String msg, Throwable t) {
		logger.error(msg, t);
	}
}
