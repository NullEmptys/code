package com.hoolai.net;

import com.hoolai.net.codec.IMessage;

public interface MessageSender {
    
    void sendMessage(long sessionId, IMessage message);

}
