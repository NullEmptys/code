package com.hoolai.net.codec;

import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public class HurgeMessages {
    
    private ConcurrentHashMap<String, HurgeMessage> hurges = new ConcurrentHashMap<>();
    
    public void decode(Message message, Consumer<Message> consumer) {
        String id = getId(message);
        if(id == null) {
            consumer.accept(message);
        } else {
            HurgeMessage hurge = pack(id, message);
            if(hurge.isCompletion()) {
                hurges.remove(id);
                consumer.accept(hurge.toMessage());
            }
        }
    }
    
    private HurgeMessage pack(String id, Message message) {
        HurgeMessage hurge = hurges.get(id);
        if(hurge == null) {
            hurge = new HurgeMessage(getCnt(message));
            hurges.put(id, hurge);
        }
        hurge.add(message);
        return hurge;
    }

    public static int getCnt(Message message) {
        return Integer.parseInt(message.getParam("_cnt"));
    }
    public static String getId(Message message) {
        return message.getParam("_id");
    }
    
    static class HurgeMessage {
        Message[] parts;
        int size;
        int len;
        public HurgeMessage(int cnt) {
            this.parts = new Message[cnt];
            this.size = 0;
        }
        public synchronized boolean add(Message part) {
            if(isCompletion()) return false;
            
            this.parts[size] = part;
            this.size ++;
            this.len += part.getBody().length;
            return true;
        }
        public Message toMessage() {
            byte[] body = new byte[len];
            int st = 0;
            for (Message part : parts) {
                byte[] pb = part.getBody();
                int l = pb.length;
                System.arraycopy(pb, 0, body, st, l);
                st += l;
            }
            Message ret = Message.build(parts[0].getCode());
            ret.setBody(body);
            return ret;
        }
        public boolean isCompletion() {
            return this.size == parts.length;
        }
    }

}
