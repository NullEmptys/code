package com.hoolai.net;

import com.hoolai.injection.Combine;
import com.hoolai.net.cmd.Command;
import com.hoolai.net.codec.IMessage;
import com.hoolai.net.session.Session;

@Combine
public interface LifecycleListener {
    
    public void onSessionRegister(Session session);
    
    public void onMessageRecieve(Session session, IMessage message);
    
    public void onMessageSending(Session session, IMessage message);
    
    public void onSessionUnRegister(Session session);

    public void onCmdException(Session session, Command cmd, IMessage req, Throwable ex);

}
