package com.hoolai.net.handler;

import com.hoolai.net.LifecycleListener;
import com.hoolai.net.MessageInterceptor;
import com.hoolai.net.cmd.CommandContext;
import com.hoolai.net.session.Session;
import com.hoolai.net.session.Session4Server;

import io.netty.channel.ChannelHandlerContext;

public class ClientMessageHandler extends NetMessageHandler {

    public ClientMessageHandler(LifecycleListener listener, CommandContext cmds, MessageInterceptor interceptor) {
        super(listener, cmds, interceptor);
    }

    @Override
    public void channelRegistered(ChannelHandlerContext ctx) throws Exception {
        Session session = new Session4Server(ctx.channel(), listener);
        listener.onSessionRegister(session);
    }
    
}
