package com.hoolai.net.cmd;

public interface CommandBuilder {
    Command build(Class<?> clazz);
}
