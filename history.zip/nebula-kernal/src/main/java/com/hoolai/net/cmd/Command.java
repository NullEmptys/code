package com.hoolai.net.cmd;

import com.hoolai.net.codec.IMessage;
import com.hoolai.net.session.Session;

public interface Command {

	void execute(Session session, IMessage req) throws Exception;

}
