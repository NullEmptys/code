package com.hoolai.modular;

/**
 * 
 * 模块
 * 
 * @author luzj
 *
 * @param <T> sharable interface
 */
public interface Module<T> {
    
    T share();
    
}
