package com.hoolai.modular;

import com.hoolai.injection.Combine;

@Combine
public interface ModuleLoader {
    
    /**
     * 从player中加载某个模块
     * @param player
     * @param clazz
     * @return
     */
    public <T extends Module<?>> T loadModule(ModuleContainer container, Class<T> clazz);
    
}
