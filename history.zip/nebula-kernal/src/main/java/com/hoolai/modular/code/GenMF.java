package com.hoolai.modular.code;

import com.hoolai.modular.ModularEnigne;
import com.hoolai.tools.CtCopier;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;

/**
 * 
 * Generate ModuleContainerFactory by given interface
 * 
 * @author luzj
 *
 */
public class GenMF {

    @SuppressWarnings("unchecked")
    public static <T> T generate(Class<T> mcFactoryInterface) {
        try {
            ClassPool pool = ClassPool.getDefault();
            CtClass ctParent = pool.getCtClass(mcFactoryInterface.getName());

            CtClass ct = pool.makeClass(mcFactoryInterface.getName() + "$$Proxy");
            ct.addInterface(ctParent);

            CtMethod[] methods = ctParent.getDeclaredMethods();
            assert methods.length == 1;
            CtMethod pmethod = methods[0];
            
            CtClass[] params = pmethod.getParameterTypes();
            StringBuilder body = new StringBuilder("{return new ").append(ModularEnigne.fetchMCClassName()).append("(");
            for (int i = 0; i < params.length; i++) {
                if(i > 0) body.append(",");
                body.append("$").append(i+1);
            }
            body.append(");}");
            
            ct.addMethod(CtCopier.copy(pmethod, body.toString(), ct));

            return (T) (ct.toClass().newInstance());
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
    }
    
}
