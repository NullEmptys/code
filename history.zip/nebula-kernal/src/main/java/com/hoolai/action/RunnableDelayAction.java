package com.hoolai.action;

public class RunnableDelayAction extends DelayAction {

    private final Runnable runnable;
    
    public RunnableDelayAction(ActionQueue queue, int delay, Runnable runnable) {
        super(queue, delay);
        this.runnable = runnable;
    }

    @Override
    protected void exec() {
        runnable.run();
    }

}
