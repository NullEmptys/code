package com.hoolai.injection;

@Combine
public interface EventualLoadable {

	public void eventuate();
	
}
