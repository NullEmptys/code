package com.hoolai.injection.code;

import java.lang.reflect.Method;
import java.util.stream.IntStream;

import com.hoolai.injection.Combine;
import com.hoolai.tools.CtCopier;
import com.hoolai.tools.KLog;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.Modifier;
import javassist.NotFoundException;

public class CombineBuilder {
    
    public static final String APPEND_COMBINE_DELEGATE_METHOD = "appendCombineDelegate";
    public static final String REMOVE_COMBINE_DELEGATE_METHOD = "removeCombineDelegate";
    
    public static void combine(Object combine, Object bean) {
        try {
            Method method = combine.getClass().getMethod(APPEND_COMBINE_DELEGATE_METHOD, Object.class);
            method.invoke(combine, bean);
        } catch (Exception e) {
            //ignore
        }
    }

    public static Object buildBean(Class<?> combineClazz) {
        try {
            return buildClass(combineClazz).newInstance();
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
    }

    public synchronized static Class<?> buildClass(Class<?> combineClazz) {
        try {
            Combine combine = combineClazz.getAnnotation(Combine.class);

            Class<?> type = combineClazz;
            ClassPool pool = ClassPool.getDefault();
            CtClass ctParent = pool.get(type.getName());
            String proxyName = type.getName() + "$$CombineProxy";

            Class<?> proxyClass = null;
            try {
                proxyClass = Class.forName(proxyName);
            } catch(ClassNotFoundException e) {}

            if(proxyClass == null) {
                CtClass ctClass = pool.makeClass(proxyName);
                if(Modifier.isInterface(type.getModifiers())) {
                    ctClass.addInterface(ctParent);
                } else {
                    ctClass.setSuperclass(ctParent);
                }

                CtField ctField0 = CtField.make("private final java.util.LinkedList delegates = new java.util.LinkedList();", ctClass);
                ctClass.addField(ctField0);

                CtMethod appendDelegateMethod = CtMethod.make("public void " + APPEND_COMBINE_DELEGATE_METHOD + "(java.lang.Object bean)" + (combine.offerFirst() ? "{this.delegates.addFirst(bean);}" : "{this.delegates.add(bean);}"), ctClass);
                ctClass.addMethod(appendDelegateMethod);
                
                CtMethod removeDelegateMethod = CtMethod.make("public void " + REMOVE_COMBINE_DELEGATE_METHOD + "(java.lang.Object bean) {this.delegates.remove(bean);}", ctClass);
                ctClass.addMethod(removeDelegateMethod);

                CtMethod[] ctMethods = ctParent.getMethods();
                for (CtMethod ctMethod : ctMethods) {
                    if(ctMethod.getDeclaringClass().getName().equals("java.lang.Object")) continue;
                    if(Modifier.isStatic(ctMethod.getModifiers())) continue;
                    if(isDefaultMethod(ctMethod) && !combine.proxyDefaults()) continue;
                    
                    StringBuilder body = new StringBuilder("{")
                    .append("java.util.Iterator it = this.delegates.iterator();")
                    .append("while(it.hasNext()){")
                    .append(combineClazz.getName()).append(" delegate = ").append("(").append(combineClazz.getName()).append(") it.next();");
                    if(ctMethod.getReturnType() == CtClass.voidType) {
                        body
                        .append(tryBlock(combine))
                        .append(invokeBlock(ctMethod))
                        .append(catchBlock(combine))
                        .append("}");//结束while
                    } else if(ctMethod.getReturnType() == CtClass.booleanType) {
                        body
                        .append(tryBlock(combine))
                        .append("boolean r = ")
                        .append(invokeBlock(ctMethod))
                        .append(combine.boolByTrue() ? "if(r) {return true;}" : "if(!r) {return false;}")
                        .append(catchBlock(combine))
                        .append("}")//结束while
                        .append("return ").append(combine.boolByTrue() ? "false" : "true").append(";");
                    } else if(ctMethod.getReturnType().isPrimitive()) {
                    	 body
                    	 .append(tryBlock(combine))
                    	 .append(ctMethod.getReturnType().getName()).append(" r = ")
                         .append(invokeBlock(ctMethod))
                         .append("if(r != 0) {return r;}")
                         .append(catchBlock(combine))
                         .append("}")//结束while
                         .append("return 0;");
                    } else {
                        body
                        .append(tryBlock(combine))
                        .append(ctMethod.getReturnType().getName()).append(" r = ")
                        .append(invokeBlock(ctMethod))
                        .append("if(r != null) {return r;}")
                        .append(catchBlock(combine))
                        .append("}")//结束while
                        .append("return null;");
                    }
                    body.append("}");
                    ctClass.addMethod(CtCopier.copy(ctMethod, body.toString(), ctClass));
                }
                proxyClass = ctClass.toClass();
            }
            return proxyClass;
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
    }

    public static boolean isDefaultMethod(CtMethod ctMethod) {
        return (ctMethod.getModifiers() & (Modifier.ABSTRACT | Modifier.PUBLIC | Modifier.STATIC)) == Modifier.PUBLIC && ctMethod.getDeclaringClass().isInterface();
    }

    private static Object tryBlock(Combine combine) {
		return combine.ignoreError() ? "try{" : "";
	}

	private static Object catchBlock(Combine combine) {
		return combine.ignoreError() ? "}catch(Throwable t){"+KLog.class.getName()+".error(\"combine ignored error\",t);}" : "";
	}

	private static String invokeBlock(CtMethod ctMethod) throws NotFoundException {
    	return new StringBuilder()
		    	.append("delegate.").append(ctMethod.getName()).append("(")
		        .append(String.join(",", IntStream.rangeClosed(1, ctMethod.getParameterTypes().length).mapToObj(idx->"$"+idx).toArray(String[]::new)))
		        .append(");")
		        .toString();
    }
    
}
