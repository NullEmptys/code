package com.hoolai.injection.code;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

import com.hoolai.tools.CtCopier;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMember;
import javassist.CtMethod;
import javassist.CtNewConstructor;
import javassist.NotFoundException;

@SuppressWarnings("unchecked")
public class ProxyBuilder {
    
    private static final String DELEGATE_FIELD_NAME = "_delegate";
    
    private static final String SUPPLIER_FIELD_NAME = "_supplier";
    
    /**
     * has default constructor
     */
    public static boolean canProxy(Class<?> clazz) {
        if(clazz.isInterface()) return true;
        Constructor<?>[] constructors = clazz.getConstructors();
        for (Constructor<?> constructor : constructors) {
            if(constructor.getParameterTypes().length == 0) {
                return true;
            }
        }
        return false;
    }
    
    public static <T> T setDelegate(T bean, Object delegate) {
        return setFieldByName(bean, DELEGATE_FIELD_NAME, delegate);
    }
    
    public static Object getDelegate(Object bean) {
        return getFieldByName(bean, DELEGATE_FIELD_NAME);
    }
    
    public static <T> T setSupplier(T bean, Object supplier) {
        return setFieldByName(bean, SUPPLIER_FIELD_NAME, supplier);
    }

    private static Object getFieldByName(Object bean, String fieldName) {
        try {
            Field field = bean.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            return field.get(bean);
        } catch (Throwable e) {e.printStackTrace();throw new IllegalArgumentException(e);}
    }
    private static <T> T setFieldByName(T bean, String fieldName, Object filedVal) {
        try {
            Field field = bean.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(bean, filedVal);
        } catch (Throwable e) {throw new IllegalArgumentException(e);}
        return bean;
    }
    
    public static <T> T build(T bean) {
        return setDelegate(build(bean.getClass()), bean);
    }
    public static <T> T build(Class<?> type) {
        return build(type, type);
    }
    public static <T> T build(Class<?> type, Object delegate) {
        return setDelegate(build(type, delegate.getClass()), delegate);
    }
    public synchronized static <T> T build(Class<?> type, Class<?> delegate) {
        try {
            ClassPool pool = ClassPool.getDefault();
            CtClass ctParent = pool.get(type.getName());
            String proxyName = delegate.getName() + "$Proxy_";
            
            Class<?> proxyClass = defineClass(proxyName);
            
            if(proxyClass == null) {
                CtClass ctClass = makeCtClassWithParent(pool, ctParent, proxyName);
                
                makeDelegateField(delegate, ctClass);
                
                makeConstructor(ctClass);
                
                makeMethodsInvokeCode(ctParent, ctClass, "");
                
                proxyClass = ctClass.toClass();
            }
            
            return (T) proxyClass.getConstructor().newInstance();
        } catch (Throwable e) {throw new IllegalArgumentException(e);}
    }
    
    public static <T> T buildBySupplier(Class<T> type, Supplier<?> supplier) {
        return setSupplier(buildBySupplier(type), supplier);
    }
    private synchronized static <T> T buildBySupplier(Class<T> type) {
        try {
            ClassPool pool = ClassPool.getDefault();
            CtClass ctParent = pool.get(type.getName());
            String proxyName = type.getName() + "$SProxy_";
            
            Class<?> proxyClass = defineClass(proxyName);
            
            if(proxyClass == null) {
                CtClass ctClass = makeCtClassWithParent(pool, ctParent, proxyName);
                
                makeDelegateField(type, ctClass);
                
                makeSupplierField(ctClass);
                
                makeConstructor(ctClass);
                
                makeMethodsInvokeCode(ctParent, ctClass, makeBeforeBodyCode4Supplier(ctParent));
                
                proxyClass = ctClass.toClass();
            }
            
            return (T) proxyClass.getConstructor().newInstance();
        } catch (Throwable e) {throw new IllegalArgumentException(e);}
    }
    
    private static Class<?> defineClass(String proxyName) {
        Class<?> proxyClass = null;
        try {
            proxyClass = Class.forName(proxyName);
        } catch(ClassNotFoundException e) {}
        return proxyClass;
    }
    
    private static String makeBeforeBodyCode4Supplier(CtClass ctParent) {
        return new StringBuilder()
                .append("if(").append(DELEGATE_FIELD_NAME).append("==null) {")
                .append(DELEGATE_FIELD_NAME).append("=(").append(ctParent.getName()).append(")").append(SUPPLIER_FIELD_NAME).append(".get();")
                .append("}")
                .toString();
    }

    private static <T> void makeMethodsInvokeCode(CtClass ctParent, CtClass ctClass, String beforeBody) throws NotFoundException, CannotCompileException {
        List<CtMethod> ctMethods = getProxyMethods(ctParent);
        for (CtMethod cm : ctMethods) {
            StringBuilder body = new StringBuilder()
                .append("{")
                .append(beforeBody)
                .append(cm.getReturnType()==CtClass.voidType ? "":"return ").append(DELEGATE_FIELD_NAME).append(".").append(cm.getName()).append("(");
            for (int i = 0; i < cm.getParameterTypes().length; i++)
                body.append((i==0 ? "":",")).append("$").append(i+1);
            body.append(");}");
            ctClass.addMethod(CtCopier.copy(cm, body.toString(), ctClass));
        }
    }

    private static void makeSupplierField(CtClass ctClass) throws CannotCompileException {
        ctClass.addField(CtField.make(Supplier.class.getName() + " " + SUPPLIER_FIELD_NAME + ";", ctClass));
    }

    private static <T> void makeDelegateField(Class<?> delegate, CtClass ctClass) throws CannotCompileException {
        ctClass.addField(CtField.make(delegate.getName() + " " + DELEGATE_FIELD_NAME + ";", ctClass));
    }
    
    private static void makeConstructor(CtClass ctClass) throws CannotCompileException, NotFoundException {
        ctClass.addConstructor(CtNewConstructor.make(new CtClass[]{}, new CtClass[0], ctClass));
    }

    private static <T> CtClass makeCtClassWithParent(ClassPool pool, CtClass ctParent, String lazyProxyName) throws CannotCompileException, NotFoundException {
        CtClass ctClass = pool.makeClass(lazyProxyName);
        if(Modifier.isInterface(ctParent.getModifiers())) {
            ctClass.addInterface(ctParent);
        } else {
            ctClass.setSuperclass(ctParent);
        }
        ctClass.addInterface(pool.get(Proxy.class.getName()));
        return ctClass;
    }
    
    private static List<CtMethod> getProxyMethods(CtClass parent) throws NotFoundException {
        Map<String, CtMethod> hash = new HashMap<>();
        getProxyMethods(hash, parent.getName(), parent, new HashSet<>());
        return new ArrayList<>(hash.values());
    }
    
    private static void getProxyMethods(Map<String, CtMethod> hash, String from, CtClass clazz, Set<CtClass> visitedClasses) throws NotFoundException {
        if (Object.class.getName().equals(clazz.getName())) return;
        if (!visitedClasses.add(clazz)) return;

        CtClass[] ifs = clazz.getInterfaces();
        for (int i = 0; i < ifs.length; i++)
            getProxyMethods(hash, from, ifs[i], visitedClasses);

        CtClass parent = clazz.getSuperclass();
        if (parent != null)
            getProxyMethods(hash, from, parent, visitedClasses);

        clazz.defrost();
        CtMethod[] methods = clazz.getDeclaredMethods();
        for (int i = 0; i < methods.length; i++) {
            if (isVisible(methods[i].getModifiers(), from, methods[i])) {
                CtMethod m = methods[i];
                String key = m.getName() + ':' + m.getMethodInfo().getDescriptor();
                CtMethod oldMethod = (CtMethod)hash.put(key, methods[i]); 
                if (null != oldMethod && Modifier.isPublic(oldMethod.getModifiers()) && !Modifier.isPublic(methods[i].getModifiers()) ) {//取public的方法
                    hash.put(key, oldMethod); 
                }
            }
        }
    }
    
    private static boolean isVisible(int mod, String from, CtMember meth) {
        if ((mod & (Modifier.PRIVATE | Modifier.STATIC)) != 0) {
            return false;
        } else if ((mod & (Modifier.PUBLIC | Modifier.PROTECTED)) != 0) {
            return true;
        } else {
            String p = getPackageName(from);
            String q = getPackageName(meth.getDeclaringClass().getName());
            return p == null ? q == null : p.equals(q);
        }
    }

    private static String getPackageName(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? null : name.substring(0, i);
    }
    
    public static interface Proxy {
    }

}
