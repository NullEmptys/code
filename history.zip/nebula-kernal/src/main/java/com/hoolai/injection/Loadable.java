package com.hoolai.injection;


public interface Loadable {
    
    public void load();

}
