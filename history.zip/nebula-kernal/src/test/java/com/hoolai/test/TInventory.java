package com.hoolai.test;

import com.hoolai.modular.ModularLoad;
import com.hoolai.modular.ModularSave;
import com.hoolai.modular.ModularUnload;
import com.hoolai.modular.Module;

public abstract class TInventory implements Module<TSharablePlayer> {

    @ModularLoad("this")
    public abstract boolean load(TestPlayer player);
    @ModularUnload @ModularSave
    public abstract boolean save();
    
    public abstract TSharablePlayer share();
    
}
