package com.hoolai.test;

import com.hoolai.injection.Inject;
import com.hoolai.injection.Prototype;


@Prototype
public class TPrototypeAbst {
    
    @Inject
    private TRepository tRepository;
    
    public void println() {
        System.out.println("I`m tprototypeabst " + tRepository);
    }
    

}
