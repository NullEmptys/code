package com.hoolai.test;

import com.hoolai.injection.Repository;


@Repository
public class TRepository extends TAbsRepo {
    
    public void println() {
        jdbcTemplate.println();
        System.out.println("I`m repository");
    }

}
