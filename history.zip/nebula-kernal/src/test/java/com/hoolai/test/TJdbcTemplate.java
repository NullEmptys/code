package com.hoolai.test;

public class TJdbcTemplate {
    
    public void println() {
        System.out.println("I`m JdbcTmplate!");
    }

}
