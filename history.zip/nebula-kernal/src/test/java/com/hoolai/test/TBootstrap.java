package com.hoolai.test;

import java.util.List;

import com.hoolai.game.GameInitializer;
import com.hoolai.game.player.PlayerContext;
import com.hoolai.game.player.callable.ModularCallable;
import com.hoolai.http.HttpServer;
import com.hoolai.http.service.Http;
import com.hoolai.http.service.Request;
import com.hoolai.http.service.Response;
import com.hoolai.http.service.Service;
import com.hoolai.http.service.ServiceContext;
import com.hoolai.injection.ApplicationContext;
import com.hoolai.injection.code.Codes;
import com.hoolai.modular.ModularType;
import com.hoolai.net.cmd.CommandContext;

public class TBootstrap {
	
	public static void main(String[] args) throws Exception {
        GameInitializer.initialize(TestPlayer.class, 1);
		ApplicationContext.registBean("defaultJdbcTemplate", new TJdbcTemplate());
		ApplicationContext.initialize("com.hoolai.*", "*.jar");
		
		TestPlayer player = ApplicationContext.fetchBean(PlayerContext.class).getPlayerImmediately(10086);
		
		player.load(ModularType.TRANSIENT);
        
        TestCommand object = (TestCommand) ApplicationContext.fetchBean(CommandContext.class).get((short) 100);
        object.execute(player, null);
        
        player.player.println();
        
        new ModularCallable<TestPlayer, TPlayerInventory>() {
            @Override
            public void call(TestPlayer player, TPlayerInventory module) {
                System.out.println("I`m callable : " + player + "\t" + module);
            }
        }.call(player);
        
        player.save();
        player.unload(ModularType.TRANSIENT);
		
		new TPrototype().println();
		
		new TPlayerInfo().println();
		
		final ServiceContext ctx = ApplicationContext.fetchBean(ServiceContext.class);
        ctx.registService("test", new Service() {
            @Override
            public Response service(Request req) {
				List<Class<?>> modifies = Codes.getClasses4Modify(Http.class);
				ctx.finalize(modifies);
                return new Response(modifies.toString());
            }
        });
        HttpServer server = new HttpServer();
        server.start(8090, ctx);
	}

}
