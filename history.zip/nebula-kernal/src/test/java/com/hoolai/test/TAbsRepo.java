package com.hoolai.test;

import com.hoolai.injection.Inject;

public abstract class TAbsRepo {

    @Inject("defaultJdbcTemplate")
    protected TJdbcTemplate jdbcTemplate;
    
}
