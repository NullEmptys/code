package com.hoolai.test;

import com.hoolai.injection.Inject;
import com.hoolai.injection.Loadable;
import com.hoolai.injection.Templates;

@Templates
public class TTemplates implements Loadable {
    
    @Inject
    private TRepository repository;
    
    public void println() {
        System.out.println("I`m templates");
        repository.println();
    }

    @Override
    public void load() {
        System.out.println("Exec templates.load");
    }

}
