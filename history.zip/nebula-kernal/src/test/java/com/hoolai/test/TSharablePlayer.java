package com.hoolai.test;

import org.junit.Ignore;

@Ignore
public interface TSharablePlayer extends TSharable {
	
	void println();

}
