package com.hoolai.test;

import org.junit.Ignore;

import com.hoolai.action.Action;
import com.hoolai.action.ActionExecutor;
import com.hoolai.action.ActionExecutors;
import com.hoolai.action.ActionQueue;

@Ignore
public class ActionQueueTest {
    
    public static void main(String[] args) {
        ActionExecutor executor = ActionExecutors.newCached("Test", 1, 5);
        for (int i = 0; i < 10; i++) {
            final int j = i;
            ActionQueue actionQueue = new ActionQueue(executor);
            (new Action(actionQueue) {
                @Override
                protected void exec() {
                    System.out.println(j);
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }).checkin();
        }
        executor.shutdown();
    }

}
