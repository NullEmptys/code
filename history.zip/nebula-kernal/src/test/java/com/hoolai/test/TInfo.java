package com.hoolai.test;

import com.hoolai.injection.code.JavaBean;

@JavaBean
public class TInfo {

    protected int id;
    
    public TInfo() {
    }
    
    public TInfo(int id) {
    	this.id = id;
    }
    
    public int getId() {
        return this.id;
    }
    
}
