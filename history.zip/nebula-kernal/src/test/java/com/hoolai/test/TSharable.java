package com.hoolai.test;


public interface TSharable {

}
