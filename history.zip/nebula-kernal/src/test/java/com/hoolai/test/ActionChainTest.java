package com.hoolai.test;

import java.util.concurrent.TimeUnit;

import org.junit.Ignore;

import com.hoolai.action.Action;
import com.hoolai.action.ActionChain;
import com.hoolai.action.ActionExecutor;
import com.hoolai.action.ActionExecutors;
import com.hoolai.action.ActionQueue;

@Ignore
public class ActionChainTest {
    
    public static void main(String[] args) throws InterruptedException {
        ActionExecutor executor = ActionExecutors.newFixed("T", 1);
        ActionQueue queue = new ActionQueue(executor);
        ActionChain chain = new ActionChain();
        
        chain.append(new Action(queue) {
            @Override
            public void exec() {
                System.out.println("Ni Hao!!!");
            }
        });
        
        chain.append(new Action(queue) {
            @Override
            public void exec() {
                System.out.println("Say Hello!!!");
            }
        });
        chain.checkin();
        
        TimeUnit.MILLISECONDS.sleep(50);
        executor.shutdown();
    }

}
