package com.hoolai.test;

import org.junit.Ignore;

import com.hoolai.action.ActionQueue;
import com.hoolai.game.player.ModularPlayer;
import com.hoolai.modular.ModularInject;
import com.hoolai.modular.ModularType;

@Ignore
public class TestPlayer extends ModularPlayer {
    
    @ModularInject
    public TSharablePlayer player;

	public TestPlayer(long playerId, ActionQueue queue) {
		super(playerId, queue);
	}

    @Override
    public boolean unloadable(ModularType type) {
        return type == ModularType.TRANSIENT;
    }

    @Override
    public boolean isOnline() {
        return true;
    }

}
