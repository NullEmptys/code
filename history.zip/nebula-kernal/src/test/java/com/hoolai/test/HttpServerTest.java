package com.hoolai.test;

import org.junit.Ignore;

import com.hoolai.http.HttpServer;
import com.hoolai.http.service.Request;
import com.hoolai.http.service.Response;
import com.hoolai.http.service.Service;
import com.hoolai.http.service.ServiceContext;

@Ignore
public class HttpServerTest {

    public static void main(String[] args) {
        ServiceContext ctx = new ServiceContext();
        ctx.registService("test", new Service() {
            @Override
            public Response service(Request req) {
                return new Response("hello world");
            }
        });
        HttpServer server = new HttpServer();
        server.start(8090, ctx);
    }
    
}
