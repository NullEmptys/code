package com.hoolai.test;

import org.junit.Ignore;

import com.hoolai.game.cmd.DirectModularCmd;
import com.hoolai.injection.Inject;
import com.hoolai.net.cmd.Cmd;
import com.hoolai.net.codec.IMessage;

@Ignore
@Cmd(100)
public class TestCommand extends DirectModularCmd<TestPlayer, TPlayerInventory> {
    
    @Inject
    private TTemplates templates;

    @Override
    public void exec(TestPlayer player, TPlayerInventory module, IMessage req) throws Exception {
        player.player.println();
        System.out.println("-------------start exec-------------");
        System.out.println(this);
        System.out.println(player);
        System.out.println(module);
        System.out.println("-------------stop  exec-------------");
        
        templates.println();
    }
	
}